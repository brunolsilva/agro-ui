package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;

@Repository
public class ItemCosseguradoRepository extends BaseDAO {

	@SuppressWarnings("unchecked")
	public List<Object[]> findCosseguradoBySeqCotac(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select distinct ic.tipoPessoa, ic.numeroCPFCNPJ, ic.nomePessoa ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemCossegurado ic ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}

}
