package br.com.tokiomarine.ctpj.endosso.service;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.SolicitanteEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Service
public class EndossoItemService {

	
	private static Logger logger = LogManager.getLogger(EndossoItemService.class.getName());
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private EndossoItemDistribuicaoService endossoItemDistribuicaoService;
	
	@Autowired
	private EndossoItemRelacaoBensService endossoItemRelacaoBensService;
	
	@Autowired
	private EndossoItemOutrosSegurosService endossoItemOutrosSegurosService;
	
	@Autowired
	private EndossoItemSistemaProtecionalService endossoItemSistemaProtecionalService;
	
	@Autowired
	private EndossoItemCosseguradoService endossoItemCosseguradoService;
	
	@Autowired
	private EndossoItemBeneficiarioService endossoItemBeneficiarioService;
	
	@Autowired
	private EndossoItemRelacaoEnderecoService endossoItemRelacaoEnderecoService;
	
	@Autowired
	private EndossoItemNotaService endossoItemNotaService;
	
	@Autowired 
	private EndossoItemClausulaRubricaService endossoItemClausulaRubricaService;
	
	@Autowired
	private EndossoItemCoberturaService endossoItemCoberturaService;
	
	/**
	 * prc_ctp0111
	 */
	public void validarEndossoItem(Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		//verifica se é endosso de item
		if(this.isEndossoItem(endosso.getCodigoTipoEndossoSCT())){
			if(endosso.getListItem() != null && !endosso.getListItem().isEmpty()){
				for(ItemCotacao itemEndosso : endosso.getListItem()){
					//inclusão de item
					if(this.isInclusaoItem(itemEndosso)){
						this.logarAlteracoesItem(itemEndosso, TipoMensagemEndossoEnum.INC_ITEM,"- Inclusão de local de risco ", endosso, alteracoesEndossoList, user);
					} 
					//exclusão de item, solicitante sinistro
					else if (this.isExclusaoItemSolicitanteSinistro(itemEndosso)){
						this.logarAlteracoesItem(itemEndosso, TipoMensagemEndossoEnum.EXC_ITEM_SINISTRO,"- Exclusão de local de risco ", endosso, alteracoesEndossoList, user);
					}
					//exclusão de item
					else if(this.isExclusaoItem(itemEndosso)){
						this.logarAlteracoesItem(itemEndosso, TipoMensagemEndossoEnum.EXC_ITEM,"- Exclusão de local de risco ", endosso, alteracoesEndossoList, user);
					}
					//prorrogação de vigencia
					else if(this.isProrrogacaoVigencia(itemEndosso)){
						this.validarItensProrrogacaoVigencia(endosso, itemEndosso, apolice, alteracoesEndossoList, user);
					}
					else if(itemEndosso.getNumeroItemEndos() != null && itemEndosso.getIdTipoEndosso() != null) {
						this.validarItensApolice(endosso, itemEndosso, apolice, alteracoesEndossoList, user);
					}
				}
			}
		}
	}
	
	private void validarItensProrrogacaoVigencia(Cotacao endosso, ItemCotacao itemEndosso, Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(apolice.getListItemApolice() != null && !apolice.getListItemApolice().isEmpty()){
			for(ItemApolice itemApolice : apolice.getListItemApolice()){
				logger.debug("Validando itens do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
				//verifica se o número do item é o mesmo
				if(itemApolice.getCodigoItemApolice() != null && AssertUtils.compareNull(BigInteger.valueOf(itemApolice.getCodigoItemApolice()), itemEndosso.getNumeroItemEndos())){
					//valida data fim vigencia
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getDataFimVigencia(), itemEndosso.getDataFimVigencia(), TipoMensagemEndossoEnum.PRORROGACAO_VIGENCIA, "- Término de vigência ", endosso, itemEndosso, alteracoesEndossoList, user);
					break;
				}
			}
		}
	}
	
	public void validarItensApoliceReintegracao(Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		//verifica se é endosso de item
		if(this.isReintegracaoIs(endosso.getCodigoTipoEndossoSCT())){
			if(endosso.getListItem() != null && !endosso.getListItem().isEmpty()){
				for(ItemCotacao itemEndosso : endosso.getListItem()){
					if(apolice.getListItemApolice() != null && !apolice.getListItemApolice().isEmpty()){
						for(ItemApolice itemApolice : apolice.getListItemApolice()){
							logger.debug("Validando itens do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
							//verifica se o número do item é o mesmo
							if(itemApolice.getCodigoItemApolice() != null && AssertUtils.compareNull(BigInteger.valueOf(itemApolice.getCodigoItemApolice()), itemEndosso.getNumeroItemEndos())){
								
								logger.debug("Validando coberturas do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
								endossoItemCoberturaService.validarItensCoberturasReintegracao(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
								break;
							}
						}
					}
				}
			}
		}
	}
	
	public void validarItensApoliceReducaoIsPorSinistro(Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		//verifica se é endosso de item
		if(this.isReducaoIs(endosso.getCodigoTipoEndossoSCT())){
			if(endosso.getListItem() != null && !endosso.getListItem().isEmpty()){
				for(ItemCotacao itemEndosso : endosso.getListItem()){
					if(apolice.getListItemApolice() != null && !apolice.getListItemApolice().isEmpty()){
						for(ItemApolice itemApolice : apolice.getListItemApolice()){
							logger.debug("Validando itens do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
							//verifica se o número do item é o mesmo
							if(itemApolice.getCodigoItemApolice() != null && AssertUtils.compareNull(BigInteger.valueOf(itemApolice.getCodigoItemApolice()), itemEndosso.getNumeroItemEndos())){
								logger.debug("Validando coberturas do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
								endossoItemCoberturaService.validarItensCoberturasReducaoIsPorSinistro(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
								break;
							}
						}
					}
				}
			}
		}
	}
	
	private void validarItensApolice(Cotacao endosso, ItemCotacao itemEndosso, Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(apolice.getListItemApolice() != null && !apolice.getListItemApolice().isEmpty()){
			for(ItemApolice itemApolice : apolice.getListItemApolice()){
				logger.debug("Validando itens do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
				//verifica se o número do item é o mesmo
				if(itemApolice.getCodigoItemApolice() != null && AssertUtils.compareNull(BigInteger.valueOf(itemApolice.getCodigoItemApolice()), itemEndosso.getNumeroItemEndos())){
					//valida o cpf/cnpj do segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNumeroCNPJCPFSegurado(), itemEndosso.getNumeroCNPJCPFSegurado(), TipoMensagemEndossoEnum.ALT_TDO, "- CPF/CNPJ(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o nome do segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNomeSegurado(), itemEndosso.getNomeSegurado(), TipoMensagemEndossoEnum.ALT_NOME_SEGURADO, "- Nome(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);				
					//valida o código da região tarifária
					if(AmbienteUtil.isServidorDeProducao()) {
						validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoRegiaoTarifaria(), itemEndosso.getCodigoRegiaoTarifaria(), TipoMensagemEndossoEnum.ALT_REGIAO, "- Região ", endosso, itemEndosso, alteracoesEndossoList, user);
					}
					//valida o código da classe de bonus
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoClasseBonus().getId(), itemEndosso.getCodigoClasseBonus().getId(), TipoMensagemEndossoEnum.ALT_BONUS, "- Classe de bônus ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o código da classe de construção
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoClasseConstrucao(), itemEndosso.getCodigoClasseConstrucao(), TipoMensagemEndossoEnum.ALT_CLASSE_CONSTRUCAO, "- Classe de construção ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o valor risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getValorRiscoBemCalculado(), itemEndosso.getValorRiscoBemCalculado(), TipoMensagemEndossoEnum.ALT_VR, "- VR ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o código da classe de localização
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoClasseLocalizacao(), itemEndosso.getCodigoClasseLocalizacao(), TipoMensagemEndossoEnum.ALT_CLASSE_LOCALIZACAO, "- Classe de localização ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o código da rubrica
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoRubrica(), itemEndosso.getCodigoRubrica(), TipoMensagemEndossoEnum.ALT_RUBRICA, "- Rubrica ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o cep do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getIdCEPLocalRisco(), itemEndosso.getIdCEPLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- CEP ", endosso, itemEndosso, alteracoesEndossoList, user);					
					//valida o endereço do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getEnderecoLocalRisco(), itemEndosso.getEnderecoLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- Endereço ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o numero de endereço do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNumeroEnderecoLocalRisco(), itemEndosso.getNumeroEnderecoLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- Nº End ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o complemento do endereço do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getComplementoEnderecoLocalRisco(), itemEndosso.getNomeComplementoEnderecoLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- Complemento End ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o código do município do endereço do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoMunicipioLocalRisco(), itemEndosso.getCodigoMunicipioLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- Código Município ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o nome do município do endereço do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNomeMunicipioLocalRisco(), itemEndosso.getNomeMunicipioLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- Nome Município ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida o uf do endereço do local de risco
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getIdUFLocalRisco(), itemEndosso.getIdUFLocalRisco(), TipoMensagemEndossoEnum.ALT_LOCAL_RISCO, "- UF ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida pc relac dmp vr
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getPercentualRelacaoDmpVr(), itemEndosso.getPercentualRelacaoDMPValorRisco(), TipoMensagemEndossoEnum.ALT_DMP_VR, "- %DMP/VR ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida ambito geografico
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoAmbitoGeografico(), itemEndosso.getCodigoAmbitoGeografico(), TipoMensagemEndossoEnum.ALT_AMBITO, "- Âmbito Geográfico ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida bem coberto
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoBemCoberto(), itemEndosso.getCodigoBemCoberto(), TipoMensagemEndossoEnum.ALT_BEM_COBERTO, "- Bem Coberto ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida codigo localização
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoLocalizacao(), itemEndosso.getCodigoLocalizacao(), TipoMensagemEndossoEnum.ALT_LOCALIZACAO, "- Localização ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida cep segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getIdCEPSegurado(), itemEndosso.getIdCEPSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- CEP(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);					
					//valida endereco segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getEnderecoSegurado(), itemEndosso.getEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Endereço(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida bairro segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNomeBairroSegurado(), itemEndosso.getNomeBairroSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Bairro(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida numero endereço segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNumeroEnderecoSegurado(), itemEndosso.getNumeroEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Nº End(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida complemento endereço segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getComplementoEnderecoSegurado(), itemEndosso.getNomeComplementoEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Compl End(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida nome municipio endereço segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNomeMunicipioSegurado(), itemEndosso.getNomeMunicipioSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Município(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					//valida uf municipio endereço segurado
					validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getIdUFSegurado(), itemEndosso.getIdUFSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- UF(Segurado) ", endosso, itemEndosso, alteracoesEndossoList, user);
					if(AmbienteUtil.isServidorDeProducao()) {
						//valida seguradora anterior
						validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getCodigoCompanhiaSeguradora(), itemEndosso.getCodigoCompanhiaSeguradora(), TipoMensagemEndossoEnum.ALT_RENOV_CONGENERE, "- Seguradora ", endosso, itemEndosso, alteracoesEndossoList, user);
						//valida numero apolice anterior
						validacaoParametrosEndossoService.compararParametrosItem(itemApolice.getNumeroApoliceCongenere(), itemEndosso.getNumeroApoliceCongenere(), TipoMensagemEndossoEnum.ALT_RENOV_CONGENERE, "- Apólice anterior ", endosso, itemEndosso, alteracoesEndossoList, user);
					}
					
					//valida listas de objetos ligadas ao item
					logger.debug("Validando itens de distribuicao do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemDistribuicaoService.validarItemDistribuicao(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando itens relacao de bens do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemRelacaoBensService.validarItemRelacaoBem(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando outros seguros do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemOutrosSegurosService.validarOutrosSeguros(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando sistemas protecionais do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemSistemaProtecionalService.validarSistemasProtecao(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando cossegurados do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemCosseguradoService.validarCossegurado(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando beneficiarios do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemBeneficiarioService.validarBeneficiario(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando relação de endereços do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemRelacaoEnderecoService.validarRelacaoEndereco(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando notas do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemNotaService.validarNotas(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando clausulas rubrica do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemClausulaRubricaService.validarClausulaRubrica(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					
					logger.debug("Validando coberturas do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" e item endosso de numero "+itemEndosso.getNumeroItem());
					endossoItemCoberturaService.validarItensCoberturas(endosso, itemEndosso, itemApolice, alteracoesEndossoList, user);
					break;
				}
			}
		}
	}
	
	private void logarAlteracoesItem(ItemCotacao itemEndosso,TipoMensagemEndossoEnum tipoMensagem, String descricao, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricao+itemEndosso.getNumeroItem(), user));
	}

	private boolean isInclusaoItem(ItemCotacao itemEndosso){
		return AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(),TipoEndossoEnum.INCLUSAO_ITEM.getId());
	}
	
	private boolean isProrrogacaoVigencia(ItemCotacao itemEndosso){
		return AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(), TipoEndossoEnum.PRORROGACAO_VIGENCIA.getId());
	}
	
	private boolean isExclusaoItemSolicitanteSinistro(ItemCotacao itemEndosso){
		return AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(),TipoEndossoEnum.EXCLUSAO_ITEM.getId()) && 
				AssertUtils.compareNull(itemEndosso.getIdSolicitanteEndosso(),SolicitanteEndossoEnum.SINISTRO);
	}

	private boolean isExclusaoItem(ItemCotacao itemEndosso){
		return AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(),TipoEndossoEnum.EXCLUSAO_ITEM.getId());
	}

	private boolean isReducaoIs(TipoEndossoSctEnum tipoEndosso){
		return tipoEndosso.equals(TipoEndossoSctEnum.REDUCAO_SINISTRO);
	}
	
	private boolean isReintegracaoIs(TipoEndossoSctEnum tipoEndosso){
		return tipoEndosso.equals(TipoEndossoSctEnum.REINTEGRACAO_IS);
	}
	
	private boolean isEndossoItem(TipoEndossoSctEnum tipoEndosso){
		return tipoEndosso.equals(TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO);
	}
}
