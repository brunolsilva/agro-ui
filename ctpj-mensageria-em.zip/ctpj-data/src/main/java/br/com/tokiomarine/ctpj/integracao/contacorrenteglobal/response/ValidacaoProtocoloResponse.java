package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response;

import java.io.Serializable;
import java.util.List;

public class ValidacaoProtocoloResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 5631301816117354470L;
	private Long codigoErro;
	private List<String> mensagens;
	private List<String> mensagensErro;

	public Long getCodigoErro() {
		return codigoErro;
	}

	public void setCodigoErro(Long codigoErro) {
		this.codigoErro = codigoErro;
	}

	public List<String> getMensagens() {
		return mensagens;
	}

	public void setMensagens(List<String> mensagens) {
		this.mensagens = mensagens;
	}

	public List<String> getMensagensErro() {
		return mensagensErro;
	}

	public void setMensagensErro(List<String> mensagensErro) {
		this.mensagensErro = mensagensErro;
	}

}
