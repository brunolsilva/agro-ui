package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request;

import java.io.Serializable;

public class ValidacaoTrocaCorretorRequest implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 3138509740059216593L;
	private String cdApoliceAnterior;
	private String cdCongenere;
	private String cdCorretor;
	private String cdModuloProduto;
	private String cdProcesso;
	private String cdProduto;
	private String cdRamo;
	private String cpfCnpjCliente;
	private String dtInicioVigencia;
	private String nrCEP;
	private String nrItemAnterior;
	private String nrNegocioAnterior;
	private String sistemaChamador;
	private String tipoPessoa;

	public String getCdApoliceAnterior() {
		return cdApoliceAnterior;
	}

	public void setCdApoliceAnterior(String cdApoliceAnterior) {
		this.cdApoliceAnterior = cdApoliceAnterior;
	}

	public String getCdCongenere() {
		return cdCongenere;
	}

	public void setCdCongenere(String cdCongenere) {
		this.cdCongenere = cdCongenere;
	}

	public String getCdCorretor() {
		return cdCorretor;
	}

	public void setCdCorretor(String cdCorretor) {
		this.cdCorretor = cdCorretor;
	}

	public String getCdModuloProduto() {
		return cdModuloProduto;
	}

	public void setCdModuloProduto(String cdModuloProduto) {
		this.cdModuloProduto = cdModuloProduto;
	}

	public String getCdProcesso() {
		return cdProcesso;
	}

	public void setCdProcesso(String cdProcesso) {
		this.cdProcesso = cdProcesso;
	}

	public String getCdProduto() {
		return cdProduto;
	}

	public void setCdProduto(String cdProduto) {
		this.cdProduto = cdProduto;
	}

	public String getCdRamo() {
		return cdRamo;
	}

	public void setCdRamo(String cdRamo) {
		this.cdRamo = cdRamo;
	}

	public String getCpfCnpjCliente() {
		return cpfCnpjCliente;
	}

	public void setCpfCnpjCliente(String cpfCnpjCliente) {
		this.cpfCnpjCliente = cpfCnpjCliente;
	}

	public String getDtInicioVigencia() {
		return dtInicioVigencia;
	}

	public void setDtInicioVigencia(String dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}

	public String getNrCEP() {
		return nrCEP;
	}

	public void setNrCEP(String nrCEP) {
		this.nrCEP = nrCEP;
	}

	public String getNrItemAnterior() {
		return nrItemAnterior;
	}

	public void setNrItemAnterior(String nrItemAnterior) {
		this.nrItemAnterior = nrItemAnterior;
	}

	public String getNrNegocioAnterior() {
		return nrNegocioAnterior;
	}

	public void setNrNegocioAnterior(String nrNegocioAnterior) {
		this.nrNegocioAnterior = nrNegocioAnterior;
	}

	public String getSistemaChamador() {
		return sistemaChamador;
	}

	public void setSistemaChamador(String sistemaChamador) {
		this.sistemaChamador = sistemaChamador;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

}
