package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.GrupoRamo;

@Repository
public class GrupoRamoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public GrupoRamo findByCodigoGrupoCodigoRamo(Integer codigoGrupo, Integer codigoRamo) {
		return (GrupoRamo) mongoTemplate.findOne(
				query(where("codigoGrupo").is(codigoGrupo)
						.and("codigoRamo").is(codigoRamo)), GrupoRamo.class);
	}

}