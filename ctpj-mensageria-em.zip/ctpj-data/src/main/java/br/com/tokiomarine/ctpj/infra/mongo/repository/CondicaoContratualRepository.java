package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.CaracteristicaValorClausulaNota;
import br.com.tokiomarine.ctpj.infra.domain.ClausulaNota;
import br.com.tokiomarine.ctpj.infra.domain.CondicaoContratual;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCondContratual;
import br.com.tokiomarine.ctpj.infra.domain.TabelaCondicaoContratual;
import br.com.tokiomarine.ctpj.infra.enums.TipoClausulaEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCoberturaEnum;
import br.com.tokiomarine.ctpj.service.MailUtilService;

@Repository
public class CondicaoContratualRepository {

	private static final String NAO = "N";
	private static final String SIM = "S";
	
	private static final int TIPO_CLAUSULA_COBERTURA = 3;
	private static final int TIPO_CLAUSULA_RUBRICA = 4;
	private static final int TIPO_CLASULA_SISTEMA_PROTECIONAL = 5;
	
	private static final int CARACTERISTICA_RUBRICA = 7;
	private static final int CARACTERISTICA_SISTEMA_PROTECIONAL= 20;
	private static final int APLICACAO_CLAUSULA_RUBRICA = 3;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private MailUtilService mailUtilService;

	private static Logger logger = LogManager.getLogger(CondicaoContratualRepository.class);

	public TabelaCondicaoContratual findTabCondicaoContratual(Integer codigoGrupoRamo,Integer codigoRamo,String codigoClausula){
		
		return mongoTemplate.findOne(query(
				where("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamo)
				.and("codigoClausula").is(codigoClausula)),TabelaCondicaoContratual.class);
	}

	public List<CondicaoContratual> findCondicaoContratual (Integer grupoRamo,Integer ramo,String clausula,Integer versao) throws RepositoryException{
		List<CondicaoContratual> listCondicaoContratual = new ArrayList<>();
		try{
			listCondicaoContratual = mongoTemplate.find(
					query(
							where("grupoRamo").is(grupoRamo)
							.and("ramo").is(ramo)
							.and("clausula").is(clausula)
							.and("versao").is(versao)
							.and("imagem").exists(false))
					.with(new Sort(Sort.Direction.ASC,"ordem"))
							,CondicaoContratual.class);
					
			if(listCondicaoContratual == null || listCondicaoContratual.isEmpty()) {
//				mailUtilService.sendMailErro(new StringBuilder("Condição Contratual não encontrada para o grupo ramo: "+grupoRamo+" ramo "+ramo+" clausula "+clausula+" versao "+versao));
			}					
		}catch (Exception e) {
			logger.error("Erro na busca de condição contratual grupo ramo: "+grupoRamo+" ramo "+ramo+" clausula "+clausula+" versao "+versao,e);
			throw new RepositoryException("Erro na busca de condição contratual grupo ramo: "+grupoRamo+" ramo "+ramo+" clausula "+clausula+" versao "+versao,e);
		}
		return listCondicaoContratual;
	}

	public List<ProdutoCondContratual> findProdutoCondicaoContratualByProduto (Integer produto,Date dataInicioVigencia){
		return mongoTemplate.find(query(
				where("produto").is(produto)
				.and("tipoClausula").is(TipoClausulaEnum.CAPA)
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null)))
				.with(new Sort(Direction.ASC,"codigoClausula"))
				,ProdutoCondContratual.class);
	}

	public List<ProdutoCondContratual> findProdutoCondicaoContratualByGrupoRamo (Integer produto, Integer codigoGrupoRamo,Integer codigoRamo, Date dataInicioVigencia){
		return mongoTemplate.find(
				query(
						where("produto").is(produto)
						.and("grupoRamo").is(codigoGrupoRamo)
						.and("ramo").is(codigoRamo)
						.and("tipoClausula").is(TipoClausulaEnum.ITEM)
						.and("dataInicioVigencia").lte(dataInicioVigencia)
						.orOperator(
							where("dataTerminoVigencia").gte(dataInicioVigencia),
							where("dataTerminoVigencia").is(null)))
				.with(new Sort(Direction.ASC,"codigoClausula"))
				,ProdutoCondContratual.class);
	}

	public List<ProdutoCondContratual> findProdutoCondicaoContratualByBasica (Integer produto, Integer codigoGrupoRamo,Integer codigoRamo,Integer cobertura,Date dataInicioVigencia){
		return mongoTemplate.find(query(
				where("produto").is(produto)
				.and("grupoRamo").is(codigoGrupoRamo)
				.and("ramo").is(codigoRamo)
				.and("cobertura").is(cobertura)
				.and("tipoClausula").is(TipoClausulaEnum.COBERTURA)
				.and("tipoCobertura").is(TipoCoberturaEnum.BASICA.getId())
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null)))
				.with(new Sort(Direction.ASC,"codigoClausula"))
				,ProdutoCondContratual.class);
	}

	public List<ProdutoCondContratual> findProdutoCondicaoContratualByAdicional(Integer produto, Integer codigoGrupoRamo,Integer codigoRamo,Integer cobertura,Integer coberturaBasica,Date dataInicioVigencia){
		return mongoTemplate.find(query(
				where("produto").is(produto)
				.and("grupoRamo").is(codigoGrupoRamo)
				.and("ramo").is(codigoRamo)
				.and("cobertura").is(cobertura)
				.and("coberturaBasica").is(coberturaBasica)
				.and("tipoClausula").is(TipoClausulaEnum.COBERTURA)
				.and("tipoCobertura").is(TipoCoberturaEnum.ADICIONAL.getId())
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null)))
				.with(new Sort(Direction.ASC,"codigoClausula"))
				,ProdutoCondContratual.class);
	}

	public List<ProdutoCondContratual> findProdutoCondicaoContratualByEspecial(Integer produto, Integer codigoGrupoRamo,Integer codigoRamo,Integer cobertura,Integer coberturaBasica,Integer coberturaAdicional,Date dataInicioVigencia){
		return mongoTemplate.find(query(
				where("produto").is(produto)
				.and("grupoRamo").is(codigoGrupoRamo)
				.and("ramo").is(codigoRamo)
				.and("cobertura").is(cobertura)
				.and("coberturaBasica").is(coberturaBasica)
				.and("coberturaAdicional").is(coberturaAdicional)
				.and("tipoClausula").is(TipoClausulaEnum.COBERTURA)
				.and("tipoCobertura").is(TipoCoberturaEnum.ESPECIAL)
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null)))
				.with(new Sort(Direction.ASC,"codigoClausula"))
				,ProdutoCondContratual.class);
	}
	
	public List<ProdutoCondContratual> findProdutoCondicaoContratualByEEspecial (Integer produto, Integer codigoGrupoRamo,Integer codigoRamo,Integer cobertura,Integer coberturaBasica,Integer coberturaAdicional,Integer coberturaEspecial,Date dataInicioVigencia){
		return mongoTemplate.find(query(
				where("produto").is(produto)
				.and("grupoRamo").is(codigoGrupoRamo)
				.and("ramo").is(codigoRamo)
				.and("cobertura").is(cobertura)
				.and("coberturaBasica").is(coberturaBasica)
				.and("coberturaAdicional").is(coberturaAdicional)
				.and("coberturaEspecial").is(coberturaEspecial)
				.and("tipoClausula").is(TipoClausulaEnum.COBERTURA)
				.and("tipoCobertura").is(TipoCoberturaEnum.ESPECIAL2)
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null)))
				.with(new Sort(Direction.ASC,"codigoClausula"))
				,ProdutoCondContratual.class);
	}

	public ClausulaNota findClausulaNota(Integer codigoGrupoRamo,Integer codigoRamo, Integer codigoClausulaNota, Date dataInicioVigencia){
		return mongoTemplate.findOne(query(
				where("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamo)
				.and("codigoClausulaNota").is(codigoClausulaNota)
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null))
				),ClausulaNota.class);
	}	
	
	/**
	 * Busca uma claúsula nota baseando-se nos parâmetros
	 * 
	 * @param codigoGrupoRamo
	 * @param codigoRamoProduto
	 * @param aplicacaoClausula
	 * @param clausualAutomatica
	 * @param dataCalculo
	 * @return
	 */
	public List<ClausulaNota> findClausulaNota(Integer codigoGrupoRamo, Integer codigoRamoProduto, Integer aplicacaoClausula, String clausualAutomatica, Date dataCalculo){
		Query query = query(
				where("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamoProduto)
				.and("aplicacaoClausula").is(aplicacaoClausula)
				.and("clausulaAutomatica").is(clausualAutomatica)
				.and("dataInicioVigencia").lte(dataCalculo)
				.orOperator(
						where("dataTerminoVigencia").gte(dataCalculo),
						where("dataTerminoVigencia").exists(false))					
				);
		
		return  mongoTemplate.find(query , ClausulaNota.class);
	}	
	
	public ClausulaNota findClausulaNota(Integer codigoClausulaNota, Integer codigoGrupoRamo,Integer codigoRamo, Integer aplicacaoClausula, String clausulaAutomatica, Date dataInicioVigencia){
		return mongoTemplate.findOne(query(
				where("codigoClausulaNota").is(codigoClausulaNota)
				.and("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamo)
				.and("aplicacaoClausula").is(aplicacaoClausula)
				.and("clausulaAutomatica").is(clausulaAutomatica)
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null))
				),ClausulaNota.class);
	}
	
	public ClausulaNota findClausulaNotaManualParaRubrica(Integer codigoClausulaNota, Integer codigoGrupoRamo, Integer codigoRamo, Date dataCalculoCotacao){
		return findClausulaNota(codigoClausulaNota, codigoGrupoRamo, codigoRamo, 3, NAO, dataCalculoCotacao);		
	}
	
	public ClausulaNota findClausulaNotaAutomaticaParaRubrica(Integer codigoClausulaNota, Integer codigoGrupoRamo, Integer codigoRamo, Date dataCalculoCotacao){
		return findClausulaNota(codigoClausulaNota, codigoGrupoRamo, codigoRamo, 3, SIM, dataCalculoCotacao);
	}
	
	public ClausulaNota findClausulaNotaManualParaItemSistemaProtecional(Integer codigoClausulaNota, Integer codigoGrupoRamo, Integer codigoRamo, Date dataCalculoCotacao){
		return findClausulaNota(codigoClausulaNota, codigoGrupoRamo, codigoRamo, 3, NAO, dataCalculoCotacao);
	}
	
	public ClausulaNota findClausulaNotaAutomaticaParaItemSistemaProtecional(Integer codigoClausulaNota, Integer codigoGrupoRamo, Integer codigoRamo, Date dataCalculoCotacao){
		return findClausulaNota(codigoClausulaNota, codigoGrupoRamo, codigoRamo, 3, SIM, dataCalculoCotacao);
	}
	
	public ClausulaNota findClausulaNotaManualParaItemCobertura(Integer codigoClausulaNota, Integer codigoGrupoRamo, Integer codigoRamo, int tipoCobertura, Date dataCalculoCotacao){
		return findClausulaNota(codigoClausulaNota, codigoGrupoRamo, codigoRamo, getAplicacaoClausula(tipoCobertura), NAO, dataCalculoCotacao);
	}
	
	public ClausulaNota findClausulaNotaAutomaticaParaItemCobertura(Integer codigoClausulaNota, Integer codigoGrupoRamo, Integer codigoRamo, int tipoCobertura, Date dataCalculoCotacao){
		return findClausulaNota(codigoClausulaNota, codigoGrupoRamo, codigoRamo, getAplicacaoClausula(tipoCobertura), SIM, dataCalculoCotacao);
	}
	
	private int getAplicacaoClausula(int tipoCobertura) {

		switch (tipoCobertura) {
		case 1:
			return 4;
		case 2:
			return 5;
		case 3:
			return 6;
		case 4:
			return 7;
		}
		
		throw new IllegalArgumentException("O valor " + tipoCobertura + " é um valor inválido de aplicação claúsula para Item Cobertura");
	}
	
	public List<ClausulaNota> findClausulaNota(Integer codigoClausulaNota, Integer aplicacaoClausula, String clausualAutomatica, Date dataCalculo){
		Query query = query(
				where("codigoClausulaNota").is(codigoClausulaNota)
				.and("aplicacaoClausula").is(aplicacaoClausula)
				.and("clausualAutomatica").is(clausualAutomatica)
				.and("dataInicioVigencia").gte(dataCalculo)
				.orOperator(
						where("dataTerminoVigencia").lte(dataCalculo),
						where("dataTerminoVigencia").exists(false))					
				);
		
		return mongoTemplate.find(query , ClausulaNota.class);
	}
	
	public boolean existeClausulaNotaAutomaticaPara(Integer codigoClausulaNota, Integer aplicacaoClausula, Date dataCalculo) {
		return !findClausulaNota(codigoClausulaNota, aplicacaoClausula, SIM, dataCalculo).isEmpty();
	}
	
	public boolean existeClausulaNotaAutomaticaDeRubricaPara(CaracteristicaValorClausulaNota caracValorClausulaNota, Date dataCalculo){
		return existeClausulaNotaAutomaticaDeRubricaPara(caracValorClausulaNota.getCodigoClausulaNota(), dataCalculo);
	}
	
	public boolean existeClausulaNotaAutomaticaDeRubricaPara(Integer codigoClausulaNota, Date dataCalculo){
		return existeClausulaNotaAutomaticaPara(codigoClausulaNota, APLICACAO_CLAUSULA_RUBRICA, dataCalculo);
	}

	public CaracteristicaValorClausulaNota findCaracteristicaValorClausulaNota(CaracteristicaValorClausulaNota caracteristicaValorClausulaNota, Date dataInicioVigencia){
		return mongoTemplate.findOne(query(
				where("caracteristica").is(caracteristicaValorClausulaNota.getCaracteristica())
				.and("codigoGrupoRamo").is(caracteristicaValorClausulaNota.getCodigoGrupoRamo())
				.and("codigoRamo").is(caracteristicaValorClausulaNota.getCodigoRamo())
				.and("tipoClausula").is(caracteristicaValorClausulaNota.getTipoClausula())
				.and("dataInicioVigencia").lte(dataInicioVigencia)
				.orOperator(
						where("dataTerminoVigencia").gte(dataInicioVigencia),
						where("dataTerminoVigencia").is(null))
				),CaracteristicaValorClausulaNota.class);
	}
	
	public List<CaracteristicaValorClausulaNota> findCaracteristicaValorClausulaNotas(Integer codigoGrupoRamo, Integer codigoRamo, Integer caracteristica, Long valorCaracteristica, Integer tipoClausula, Date dataCalculo){
		return  mongoTemplate.find(query(
				where("caracteristica").is(caracteristica)
				.and("valorCaracteristica").is(valorCaracteristica)
				.and("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamo)
				.and("tipoClausula").is(tipoClausula)
				.and("dataInicioVigencia").lte(dataCalculo)
				.orOperator(
						where("dataFimVigencia").gte(dataCalculo), 
						where("dataFimVigencia").is(null)))
				, CaracteristicaValorClausulaNota.class);
	}

	public List<CaracteristicaValorClausulaNota> findCaracteristicaValorClausulaNotasByCobertura(Integer codigoGrupoRamo, Integer codigoRamo, Integer caracteristica, Long valorCaracteristica, Long cobertura, Integer tipoClausula, Date dataCalculo){
		List<CaracteristicaValorClausulaNota> list = mongoTemplate.find(query(
				where("caracteristica").is(caracteristica)
				.and("valorCaracteristica").is(valorCaracteristica)
				.and("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamo)
				.and("cobertura").is(cobertura)
				.and("tipoClausula").is(tipoClausula)
				.and("dataInicioVigencia").lte(dataCalculo)
				.orOperator(
						where("dataFimVigencia").gte(dataCalculo), 
						where("dataFimVigencia").is(null)))
				, CaracteristicaValorClausulaNota.class);
		return list;
	}
	
	public List<CaracteristicaValorClausulaNota> findCaracteristicaValorClausulaNotasParaRubrica(Integer codigoGrupoRamo, Integer codigoRamo, Long valorCaracteristica, Date dataCalculo){
		List<CaracteristicaValorClausulaNota> listCaracteristicaValorClausulaNota = findCaracteristicaValorClausulaNotas(codigoGrupoRamo, codigoRamo, CARACTERISTICA_RUBRICA, valorCaracteristica, TIPO_CLAUSULA_RUBRICA, dataCalculo);
		return listCaracteristicaValorClausulaNota;
	}

	public List<CaracteristicaValorClausulaNota> findCaracteristicaValorClausulaNotasParaItemSistemaProtecinal(Integer codigoGrupoRamo, Integer codigoRamo, Long valorCaracteristica, Date dataCalculo){
		return findCaracteristicaValorClausulaNotas(codigoGrupoRamo, codigoRamo, CARACTERISTICA_SISTEMA_PROTECIONAL, valorCaracteristica, TIPO_CLASULA_SISTEMA_PROTECIONAL, dataCalculo);
	}
	
	public List<CaracteristicaValorClausulaNota> findCaracteristicaValorClausulaNotasParaItemCobertura(Integer codigoGrupoRamo, Integer codigoRamo,Long valorCaracteristica,Long cobertura, Date dataCalculo){
		return findCaracteristicaValorClausulaNotasByCobertura(codigoGrupoRamo, codigoRamo, CARACTERISTICA_RUBRICA, valorCaracteristica, cobertura, TIPO_CLAUSULA_COBERTURA, dataCalculo);
	}

	public List<CaracteristicaValorClausulaNota> findCaracteristicaValorParaCobertura(Integer codigoGrupoRamo, Integer codigoRamo, Integer caracteristica, List<Long> valoresCaracteristica, Integer tipoClausula, Date dataCalculo){
		return mongoTemplate.find(query(
				where("caracteristica").is(caracteristica)
				.and("valorCaracteristica").in(valoresCaracteristica)
				.and("codigoGrupoRamo").is(codigoGrupoRamo)
				.and("codigoRamo").is(codigoRamo)
				.and("tipoClausula").is(tipoClausula)
				.and("dataInicioVigencia").lte(dataCalculo)
				.orOperator(
						where("dataFimVigencia").gte(dataCalculo), 
						where("dataFimVigencia").exists(false))), CaracteristicaValorClausulaNota.class);
	}
}