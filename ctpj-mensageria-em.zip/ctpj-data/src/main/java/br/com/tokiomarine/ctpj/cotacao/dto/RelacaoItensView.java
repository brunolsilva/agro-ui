package br.com.tokiomarine.ctpj.cotacao.dto;


public class RelacaoItensView {

}
