package br.com.tokiomarine.ctpj.blaze.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.blaze.dto.BloqueioAlcadaBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.CotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.DescontoAgravacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCoberturaBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCotacaoBlaze;
import br.com.tokiomarine.ctpj.cotacao.dto.BloqueioAlcadaView;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoAgravacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

public class BlazeParaCotacaoMapper {

	private static Logger logger = LogManager.getLogger(BlazeParaCotacaoMapper.class);

	public void convertBlazeToCotacao(Cotacao cotacao,CotacaoBlaze cotacaoBlaze,User user,BigDecimal coeficienteConversaoMoeda, Apolice apolice) {

		cotacao.setValorPremioContaCorrente(cotacaoBlaze.getValorPremioContaCorrente() != null ? BigDecimal.valueOf(cotacaoBlaze.getValorPremioContaCorrente()) : null);

		cotacao.setValorPremioNET(null);
		cotacao.setValorPremioLiquido(null);
		cotacao.setValorPremioNetMoedaEstrangeira(null);
		cotacao.setValorPremioLiquidoMoedaEstrangeira(null);
		
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO
				&& cotacao.getIdTipoEndosso() == TipoEndossoEnum.CANCELAMENTO_APOLICE
				&& cotacaoBlaze.getDataAlteracao() != null) {
			cotacao.setDataAlteracao(cotacaoBlaze.getDataAlteracao());
		}
		
		for (ItemCotacao itemCotacao : cotacao.getListItem()) {
			Optional<ItemCotacaoBlaze> itemCotacaoBlaze = cotacaoBlaze
					.getListItem()
					.stream()
					.filter(item -> item.getSequencialItemCotacao().equals(itemCotacao.getSequencialItemCotacao().longValue()))
					.findFirst();

			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO
					&& cotacao.getIdTipoEndosso() == TipoEndossoEnum.CANCELAMENTO_APOLICE
					&& cotacaoBlaze.getDataAlteracao() != null) {
				itemCotacao.setDataAlteracao(cotacao.getDataAlteracao());
			}

			if (itemCotacaoBlaze.isPresent()) {
				Integer regiaoTarifaria = null;
				if ((itemCotacaoBlaze.get().getCodigoRegiaoTarifariaBlaze() == null) && (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO)) {					
					Optional<ItemApolice> itemApo = apolice
						.getListItemApolice()
						.stream()
						.filter(ia -> ia.getCodigoItemApolice() == itemCotacaoBlaze.get().getNumeroItem().intValue())
						.findFirst();
					regiaoTarifaria = itemApo.isPresent() ? itemApo.get().getCodigoRegiaoTarifaria(): null;
				} else {
					regiaoTarifaria = itemCotacaoBlaze.get().getCodigoRegiaoTarifariaBlaze();
				}			
				itemCotacao.setCodigoRegiaoTarifaria(regiaoTarifaria);
				for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
					Optional<ItemCoberturaBlaze> itemCoberturaBlaze = itemCotacaoBlaze
							.get()
							.getListItemCobertura()
							.stream()
							.filter(cob -> cob.getSequencialItemCobertura().equals(itemCobertura.getSequencialItemCobertura().longValue()))
							.findFirst();
					if (itemCoberturaBlaze.isPresent()) {
						convertItemCoberturaFranquiaPremio(cotacao,itemCobertura,itemCoberturaBlaze.get(),coeficienteConversaoMoeda);
						itemCobertura.setListDescontoAgravacao(convertListDescontoAgravacao(itemCobertura,itemCoberturaBlaze.get().getListDescontoAgravacao(),user));
					} else {
						logger.error("Cobertura não encontrada na resposta");
					}
				}
			} else {
				logger.error("Item não encontrada na resposta");
			} 
		}
		if(cotacao.getIdTipoEndosso() == TipoEndossoEnum.CANCELAMENTO_ENDOSSO) {
			cotacao.setValorPremioNET(BigDecimal.ZERO);
			cotacao.setValorPremioLiquido(BigDecimal.ZERO);
		}
	}

	public void convertBlazeToCotacaoAceitacao(Cotacao cotacao,CotacaoBlaze cotacaoBlaze,List<BloqueioAlcadaView> listBloqueioAlcadaAutorizado,User user) {
		List<BloqueioAlcada> listBloqueioAlcadaNew = new ArrayList<>();
		for (BloqueioAlcadaBlaze bloqueioAlcadaBlaze : cotacaoBlaze.getListBloqueioAlcada()){
			BloqueioAlcada bloqueioAlcada = new BloqueioAlcada();
			bloqueioAlcada.setCotacao(cotacao);
			bloqueioAlcada.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			bloqueioAlcada.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			bloqueioAlcada.setDescricaoRestricao(bloqueioAlcadaBlaze.getDescricaoRestricao());
			bloqueioAlcada.setCodigoNivelAutorizacao(bloqueioAlcadaBlaze.getCodigoNivelAutorizacao());
			bloqueioAlcada.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			
			bloqueioAlcada.setDescricaoRestricaoCorretor(bloqueioAlcadaBlaze.getDescricaoRestricaoCorretor());
			bloqueioAlcada.setIdAceitacao(
					bloqueioAlcadaBlaze.getAceitacao() != null ? SimNaoEnum.getById(bloqueioAlcadaBlaze.getAceitacao()) : null);
			bloqueioAlcada.setIdApresentaRestricao(
					bloqueioAlcadaBlaze.getApresentaRestricao() != null ? SimNaoEnum.getById(bloqueioAlcadaBlaze.getApresentaRestricao()) : null);
			bloqueioAlcada.setDataAtualizacao(new Date());
			bloqueioAlcada.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			for (BloqueioAlcadaView bloqueioAlcadaAutorizado : listBloqueioAlcadaAutorizado){
				if (bloqueioAlcada.getDescricaoRestricao().equals(bloqueioAlcadaAutorizado.getDescricaoRestricao()) &&
						bloqueioAlcada.getCodigoNivelAutorizacao().equals(bloqueioAlcadaAutorizado.getCodigoNivelAutorizacao())){
					bloqueioAlcada.setCodigoFuncionarioAutorizacao(bloqueioAlcadaAutorizado.getCodigoFuncionarioAutorizacao());
					bloqueioAlcada.setIdAutorizacao(bloqueioAlcadaAutorizado.getIdAutorizacao());
					bloqueioAlcada.setDataAutorizacao(bloqueioAlcadaAutorizado.getDataAutorizacao());
				}
			}
			listBloqueioAlcadaNew.add(bloqueioAlcada);
		}
		cotacao.setListBloqueioAlcada(listBloqueioAlcadaNew);
	}

	private List<DescontoAgravacao> convertListDescontoAgravacao(ItemCobertura itemCobertura,List<DescontoAgravacaoBlaze> listDescontoAgravacaoBlaze,User user) {
		List<DescontoAgravacao> listDescontoAgravacao = new ArrayList<>();
		for (DescontoAgravacaoBlaze descontoAgravacaoBlaze : listDescontoAgravacaoBlaze) {
			DescontoAgravacao itemCoberturaDescontoAgravacao = new DescontoAgravacao();
			itemCoberturaDescontoAgravacao.setItemCobertura(itemCobertura);
			itemCoberturaDescontoAgravacao.setSequencialDescontoAgravo(listDescontoAgravacaoBlaze.indexOf(descontoAgravacaoBlaze));
			itemCoberturaDescontoAgravacao.setNumeroCotacaoProposta(itemCobertura.getNumeroCotacaoProposta());
			itemCoberturaDescontoAgravacao.setVersaoCotacaoProposta(itemCobertura.getVersaoCotacaoProposta());
			itemCoberturaDescontoAgravacao.setCodigoGrupoRamo(itemCobertura.getCodigoGrupoRamoEmissao());
			itemCoberturaDescontoAgravacao.setCodigoCobertura(descontoAgravacaoBlaze.getCodigoCobertura());
			itemCoberturaDescontoAgravacao.setPercentualDescontoAgravacao(BigDecimal.valueOf(descontoAgravacaoBlaze.getPercentualDescontoAgravacao()));
			itemCoberturaDescontoAgravacao.setDescricaoDescontoAgravacao(descontoAgravacaoBlaze.getDescricaoDescontoAgravacao());
			itemCoberturaDescontoAgravacao.setDataAtualizacao(new Date());
			itemCoberturaDescontoAgravacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCoberturaDescontoAgravacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			listDescontoAgravacao.add(itemCoberturaDescontoAgravacao);
		}
		return listDescontoAgravacao;
	}

	private void convertItemCoberturaFranquiaPremio(Cotacao cotacao,ItemCobertura itemCobertura,ItemCoberturaBlaze itemCoberturaBlaze,BigDecimal coeficienteConversaoMoeda) {
		if(itemCobertura.getIdFranquiaInformado() ==  SimNaoEnum.NAO || itemCobertura.getIdFranquiaInformado() == null) {
			itemCobertura.setIdFormaFranquia(FormaFranquiaEnum.getById(itemCoberturaBlaze.getIdFormaFranquia()));
			itemCobertura.setNumeroHorasFranquia(null);
			itemCobertura.setNumeroDiasFranquia(null);
			itemCobertura.setTaxaFranquia(null);
			itemCobertura.setValorFranquia(null);
			itemCobertura.setValorFranquiaMinima(null);
			itemCobertura.setValorFranquiaMaxima(null);
			itemCobertura.setTaxaImportanciaSegurada(null);
			itemCobertura.setTaxaImportanciaSeguradaMinima(null);
			itemCobertura.setTaxaImportanciaSeguradaMaxima(null);
			itemCobertura.setNumeroHorasFranquia(itemCoberturaBlaze.getNumeroHorasFranquia() !=null ? itemCoberturaBlaze.getNumeroHorasFranquia() : null);
			itemCobertura.setNumeroDiasFranquia(itemCoberturaBlaze.getNumeroDiasFranquia() != null ? itemCoberturaBlaze.getNumeroDiasFranquia() : null);
			itemCobertura.setTaxaFranquia(itemCoberturaBlaze.getTaxaFranquia() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getTaxaFranquia()) : null);
			itemCobertura.setValorFranquia(itemCoberturaBlaze.getValorFranquia() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorFranquia()) : null);
			itemCobertura.setValorFranquiaMinima(itemCoberturaBlaze.getValorFranquiaMinima() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorFranquiaMinima()) : null);
			itemCobertura.setValorFranquiaMaxima(itemCoberturaBlaze.getValorFranquiaMaxima() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorFranquiaMaxima()) : null);
			itemCobertura.setTaxaImportanciaSegurada(itemCoberturaBlaze.getTaxaImportanciaSegurada() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getTaxaImportanciaSegurada()) : null);
			itemCobertura.setTaxaImportanciaSeguradaMinima(itemCoberturaBlaze.getTaxaImportanciaSeguradaMinima() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getTaxaImportanciaSeguradaMinima()) : null);
			itemCobertura.setTaxaImportanciaSeguradaMaxima(itemCoberturaBlaze.getTaxaImportanciaSeguradaMaxima() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getTaxaImportanciaSeguradaMaxima()) : null);
		}

		itemCobertura.setValorPremio(null);
		itemCobertura.setValorPremioVigencia(null);
		itemCobertura.setValorPremioReferencial(null);
		itemCobertura.setValorPremioNET(null);
		itemCobertura.setPercentualTaxaCalculoPremio(null);
		itemCobertura.setValorPremio(itemCoberturaBlaze.getValorPremio() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorPremio()) : BigDecimal.ZERO);
		itemCobertura.setValorPremioNET(itemCoberturaBlaze.getValorPremioNET() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorPremioNET()) : null);
		itemCobertura.setValorPremioVigencia(itemCoberturaBlaze.getValorPremioVigencia() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorPremioVigencia()) : null);
		itemCobertura.setValorPremioReferencial(itemCoberturaBlaze.getValorPremioReferencial() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getValorPremioReferencial()) : null);
		itemCobertura.setPercentualTaxaCalculoPremio(itemCoberturaBlaze.getPercentualTaxaCalculoPremio() != null ? BigDecimal.valueOf(itemCoberturaBlaze.getPercentualTaxaCalculoPremio()) : null);
		if(cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA){
			itemCobertura.setValorPremioMoedaEstrangeira(itemCobertura.getValorPremio() != null ? BigDecimalUtil.aplicaCoeficienteConversaoMoedaRealParaDolar(coeficienteConversaoMoeda,itemCobertura.getValorPremio()) : null);
			itemCobertura.setValorPremioNETMoedaEstrangeira(itemCobertura.getValorPremioNET() != null ? BigDecimalUtil.aplicaCoeficienteConversaoMoedaRealParaDolar(coeficienteConversaoMoeda,itemCobertura.getValorPremioNET()) : null);
		}
		cotacao.setValorPremioNET(BigDecimalUtil.safeAdd(cotacao.getValorPremioNET(),itemCobertura.getValorPremioNET()));
		cotacao.setValorPremioLiquido(BigDecimalUtil.safeAdd(cotacao.getValorPremioLiquido(),itemCobertura.getValorPremio()));
		cotacao.setValorPremioNetMoedaEstrangeira(BigDecimalUtil.safeAdd(cotacao.getValorPremioNetMoedaEstrangeira(),itemCobertura.getValorPremioNETMoedaEstrangeira()));
		cotacao.setValorPremioLiquidoMoedaEstrangeira(BigDecimalUtil.safeAdd(cotacao.getValorPremioLiquidoMoedaEstrangeira(),itemCobertura.getValorPremioMoedaEstrangeira()));
	}
}
