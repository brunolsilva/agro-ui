package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemDistribuicaoView;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.enums.ClasseBonusEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCobertura;
import br.com.tokiomarine.ctpj.infra.enums.AplicacaoPeriodoIndenitarioEnum;
import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CoberturaRepository;
import br.com.tokiomarine.ctpj.mapper.CoberturaViewMapper;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.mapper.NumberMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class BaseService {

	private static Logger logger = LogManager.getLogger(CotacaoService.class);

	private NumberMapper numberMapper = new NumberMapper();

	@Autowired
	private CoberturaRepository coberturaRepository;

	@Autowired
	private CalculaSublimiteService calculaSublimiteService;

	public void populaItem(CotacaoView cotacaoView,Cotacao cotacao,int sequencialItemDistribuicao,BigDecimal coeficienteConversaoMoeda) {
		boolean lmiUnico = cotacao.getIdLmiUnico().getLogical();
		ItemCotacaoView itemCotacaoViewPrincipal = null;
		for (ItemCotacaoView itemCotacaoView : cotacaoView.getListItem()) {
			if(lmiUnico) {
				if (itemCotacaoViewPrincipal == null) {
					itemCotacaoViewPrincipal = cotacaoView.getListItem().stream()
							.filter(item -> item.getNumeroItem().equals(BigInteger.ONE))
							.findFirst().orElseThrow(() -> new RuntimeException("Não possui item 1 " + cotacao.getSequencialCotacaoProposta()));
				}
			}
			// Item já existente
			if (itemCotacaoView.getSequencialItemCotacao() != null) {
				Optional<ItemCotacao> itemCotacaoVal = cotacao.getListItem().stream()
						.filter(i -> i.getSequencialItemCotacao().equals(itemCotacaoView.getSequencialItemCotacao()) && 
								i.getNumeroItem().equals(itemCotacaoView.getNumeroItem()) && 
								i.getNumeroCotacaoProposta().equals(cotacaoView.getNumeroCotacaoProposta()) && 
								i.getVersaoCotacaoProposta().equals(cotacaoView.getVersaoCotacaoProposta()))
						.findFirst();
				if (itemCotacaoVal.isPresent()) {
					if(TipoEndossoEnum.EXCLUSAO_ITEM.getId().equals(itemCotacaoView.getIdTipoEndosso())) {
						populaDadosItem(cotacao, itemCotacaoVal.get(),itemCotacaoView);
						itemCotacaoVal.get().setIdExclusaoEndosso(SimNaoEnum.SIM);
						itemCotacaoVal.get().setIdTipoEndosso(itemCotacaoView.getIdTipoEndosso());
						itemCotacaoVal.get().setIdSolicitanteEndosso(itemCotacaoView.getIdSolicitanteEndosso());
						for(ItemCobertura itemCobertura: itemCotacaoVal.get().getListItemCobertura()) {
							itemCobertura.setIdExclusaEndosso(SimNaoEnum.SIM);
						}
					} else {
						sequencialItemDistribuicao = populaDadosItemExistente(cotacaoView, cotacao,
								sequencialItemDistribuicao, coeficienteConversaoMoeda, itemCotacaoView,
								itemCotacaoViewPrincipal, lmiUnico, itemCotacaoVal);
					}
				}
			} else {
				sequencialItemDistribuicao = populaDadosItemNovo(cotacaoView, cotacao, sequencialItemDistribuicao,
						coeficienteConversaoMoeda, itemCotacaoView, itemCotacaoViewPrincipal, lmiUnico);
			}
		}

		if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				itemCotacao.setNomeSegurado(cotacao.getNomeSegurado());
				itemCotacao.setDataInicioVigencia(cotacao.getDataInicioVigencia());
				itemCotacao.setDataFimVigencia(cotacao.getDataFimVigencia());
			}
		}

		if (itemCotacaoViewPrincipal != null) {
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				Optional<ItemCotacaoView> optionalItemCotacaoView = cotacaoView
						.getListItem()
						.stream()
						.filter(itw->itw.getNumeroItem().equals(itemCotacao.getNumeroItem()))
						.findFirst();
				itemCotacao.setDataInicioVigencia(cotacao.getDataInicioVigencia());
				itemCotacao.setDataFimVigencia(cotacao.getDataFimVigencia());
				itemCotacao.setIdTipoPessoa(cotacao.getIdTipoPessoa());
				itemCotacao.setNumeroCNPJCPFSegurado(cotacao.getNumeroCNPJCPFSegurado());				
				itemCotacao.setNomeSegurado(cotacao.getNomeSegurado());					
				itemCotacao.setIdCEPSegurado(cotacao.getIdCEPSegurado());
				itemCotacao.setEnderecoSegurado(cotacao.getEnderecoSegurado());
				itemCotacao.setNumeroEnderecoSegurado(cotacao.getNumeroEnderecoSegurado());
				itemCotacao.setNomeComplementoEnderecoSegurado(cotacao.getNomeComplementoEnderecoSegurado());
				itemCotacao.setNomeBairroSegurado(cotacao.getNomeBairroSegurado());					
				itemCotacao.setNomeMunicipioSegurado(cotacao.getNomeMunicipioSegurado());
				itemCotacao.setIdUFSegurado(cotacao.getIdUFSegurado());
				itemCotacao.setNumeroTelefoneSegurado(cotacao.getNumeroTelefoneSegurado());
				itemCotacao.setNumeroCelularSegurado(cotacao.getNumeroCelularSegurado());
				itemCotacao.setIdEmailSegurado(cotacao.getIdEmailSegurado());
				if (!optionalItemCotacaoView.isPresent() && !TipoEndossoEnum.EXCLUSAO_ITEM.getId().equals(itemCotacao.getIdTipoEndosso()) && lmiUnico) {
					populaCoberturasLMIUnico2(cotacaoView,itemCotacaoViewPrincipal,itemCotacao,coeficienteConversaoMoeda);
				}
			}
		}
		
		definirDadosItensAlteracaoCadastralTDO(cotacaoView, cotacao);
		
		if (cotacao.getIdTipoEndosso() == TipoEndossoEnum.PRORROGACAO_VIGENCIA || cotacao.getIdTipoEndosso() == TipoEndossoEnum.ALTERACAO_CONDICAO_COMERCIAL_DOCUMENTO) {
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				itemCotacao.setDataAlteracao(cotacaoView.getDataAlteracao());
				itemCotacao.setDataFimVigencia(cotacao.getDataFimVigencia());
			}
		}
		
		definirDataAlteracaoItensCancelamentoEndosso(cotacaoView, cotacao);
	}

	private void definirDadosItensAlteracaoCadastralTDO(CotacaoView cotacaoView, Cotacao cotacao) {
		if (TipoEndossoEnum.ALTERACAO_SEGURADO_TDO == cotacao.getIdTipoEndosso() || TipoEndossoEnum.ALTERACAO_DADOS_CADASTRAIS == cotacao.getIdTipoEndosso()) {	
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				itemCotacao.setDataAlteracao(cotacaoView.getDataAlteracao());
				if(TipoEndossoEnum.ALTERACAO_SEGURADO_TDO == cotacao.getIdTipoEndosso()) {
					itemCotacao.setIdTipoPessoa(cotacaoView.getIdTipoPessoa());
					itemCotacao.setNumeroCNPJCPFSegurado(cotacaoView.getNumeroCNPJCPFSegurado());				
					itemCotacao.setNomeSegurado(cotacaoView.getNomeSegurado());					
				}
				itemCotacao.setIdCEPSegurado(cotacaoView.getIdCEPSeguradoNumero());
				itemCotacao.setEnderecoSegurado(cotacaoView.getEnderecoSegurado());
				itemCotacao.setNumeroEnderecoSegurado(cotacaoView.getNumeroEnderecoSegurado());
				itemCotacao.setNomeComplementoEnderecoSegurado(cotacaoView.getNomeComplementoEnderecoSegurado());
				itemCotacao.setNomeBairroSegurado(cotacaoView.getNomeBairroSegurado());					
				itemCotacao.setNomeMunicipioSegurado(cotacaoView.getNomeMunicipioSegurado());
				itemCotacao.setIdUFSegurado(cotacaoView.getIdUFSegurado());
				itemCotacao.setNumeroTelefoneSegurado(cotacaoView.getNumeroTelefoneSegurado());
				itemCotacao.setNumeroCelularSegurado(cotacaoView.getNumeroCelularSegurado());
				itemCotacao.setIdEmailSegurado(cotacaoView.getIdEmailSegurado());
			}
		}
	}

	private void definirDataAlteracaoItensCancelamentoEndosso(CotacaoView cotacaoView, Cotacao cotacao) {
		if (DestinoEmissaoEnum.ACX == cotacaoView.getIdDestinoEmissao() && TipoEndossoEnum.CANCELAMENTO_ENDOSSO == cotacao.getIdTipoEndosso()) {
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				if(cotacaoView.getDataAlteracao().after(itemCotacao.getDataInicioVigencia())) {
					itemCotacao.setDataAlteracao(cotacaoView.getDataAlteracao());
				}
				else {
					itemCotacao.setDataAlteracao(itemCotacao.getDataInicioVigencia());
				}
			}
		}
	}

	private int populaDadosItemNovo(CotacaoView cotacaoView, Cotacao cotacao, int sequencialItemDistribuicao,
			BigDecimal coeficienteConversaoMoeda, ItemCotacaoView itemCotacaoView,
			ItemCotacaoView itemCotacaoViewPrincipal, boolean lmiUnico) {
		ItemCotacao itemCotacao = new ItemCotacao();
		
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO){
			if(lmiUnico && itemCotacaoView.getIdTipoEndosso() == null) {
				itemCotacaoView.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO.getId());
			}
		}
		CotacaoViewMapper.INSTANCE.toItemCotacao(itemCotacaoView,itemCotacao);

		itemCotacao.setCotacao(cotacao);

		itemCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		itemCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());

		populaDadosSeguradoItem(cotacao,itemCotacao);

		populaDadosItem(cotacao,itemCotacao,itemCotacaoView);

		if (itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.NOVO) {
			itemCotacao.setCodigoClasseBonus(ClasseBonusEnum.ZERO);
		}

		sequencialItemDistribuicao = populaItemDistribuicao(cotacaoView.getCodigoMoeda(),itemCotacaoView,itemCotacao,sequencialItemDistribuicao,coeficienteConversaoMoeda);
		populaValoresItem(cotacaoView.getCodigoMoeda(),itemCotacaoView,itemCotacao,coeficienteConversaoMoeda);

		if (lmiUnico) {
			populaCoberturasLMIUnico(cotacaoView,itemCotacaoView,itemCotacao,itemCotacaoViewPrincipal,coeficienteConversaoMoeda);
		} else {
			populaCoberturas(cotacaoView,itemCotacaoView,itemCotacao,coeficienteConversaoMoeda);
		}

		cotacao.getListItem().add(itemCotacao);

		populaProtecional(itemCotacaoView,itemCotacao);
		
		return sequencialItemDistribuicao;
	}

	private int populaDadosItemExistente(CotacaoView cotacaoView, Cotacao cotacao, int sequencialItemDistribuicao,
			BigDecimal coeficienteConversaoMoeda, ItemCotacaoView itemCotacaoView,
			ItemCotacaoView itemCotacaoViewPrincipal, boolean lmiUnico, Optional<ItemCotacao> itemCotacaoVal) {
		if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE ||
				TipoEndossoEnum.isItemAlteracaoInclusao(itemCotacaoView.getIdTipoEndosso(),lmiUnico) ||
				cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.REINTEGRACAO_IS) {
			
			if(lmiUnico && itemCotacaoView.getIdTipoEndosso() == null && cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				itemCotacaoView.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO.getId());
				ItemCotacao itemCotacao = itemCotacaoVal.orElse(null);
				if(itemCotacao == null) {
					throw new RuntimeException("Item não encontrado.");
				} else {
					itemCotacao.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO.getId());
				}
			}

			if(itemCotacaoView.getIdTipoEndosso() == null || cotacao.getCodigoTipoEndossoSCT() != TipoEndossoSctEnum.REINTEGRACAO_IS) {
				ItemCotacao itemCotacao = itemCotacaoVal.orElse(null);
				if(itemCotacao == null) {
					throw new RuntimeException("Item não encontrado.");
				}
				populaDadosSeguradoItem(cotacao,itemCotacao);

				populaProtecional(itemCotacaoView,itemCotacaoVal.get());

				sequencialItemDistribuicao = populaItemDistribuicao(cotacaoView.getCodigoMoeda(),itemCotacaoView,itemCotacaoVal.get(),sequencialItemDistribuicao,coeficienteConversaoMoeda);

				populaValoresItem(cotacaoView.getCodigoMoeda(),itemCotacaoView,itemCotacaoVal.get(),coeficienteConversaoMoeda);
				
				itemCotacaoVal.get().setIdTipoEndosso( itemCotacaoView.getIdTipoEndosso() );

				if (lmiUnico) {
					populaCoberturasLMIUnico(cotacaoView,itemCotacaoView,itemCotacaoVal.get(),itemCotacaoViewPrincipal,coeficienteConversaoMoeda);
				} else {
					populaCoberturas(cotacaoView,itemCotacaoView,itemCotacaoVal.get(),coeficienteConversaoMoeda);
				}

				CotacaoViewMapper.INSTANCE.toItemCotacao(itemCotacaoView,itemCotacaoVal.get());
				
				if (itemCotacaoVal.get().getIdTipoSeguro() == TipoSeguroEnum.NOVO) {
					itemCotacaoVal.get().setCodigoClasseBonus(ClasseBonusEnum.ZERO);
				}
				
				populaDadosItem(cotacao,itemCotacaoVal.get(),itemCotacaoView);
			} else {
				ItemCotacao itemCotacao = itemCotacaoVal.orElse(null);
				if(itemCotacao == null) {
					throw new RuntimeException("Item não encontrado.");
				} else {
					itemCotacao.setIdTipoEndosso(itemCotacaoView.getIdTipoEndosso());
				}

				populaDadosItem(cotacao,itemCotacao,itemCotacaoView);

				if (lmiUnico) {
					populaCoberturasLMIUnico(cotacaoView,itemCotacaoView,itemCotacao,itemCotacaoViewPrincipal,coeficienteConversaoMoeda);
				} else {
					populaCoberturas(cotacaoView,itemCotacaoView,itemCotacaoVal.get(),coeficienteConversaoMoeda);
				}
			}
		}

		return sequencialItemDistribuicao;
	}

	/**
	 * @param cotacaoView
	 * @param itemCotacaoView
	 * @param itemCotacao
	 */
	public void populaCoberturasLMIUnico(CotacaoView cotacaoView,ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,ItemCotacaoView itemCotacaoViewPrincipal,BigDecimal coeficienteConversaoMoeda) {

		if (itemCotacaoView.getNumeroItem().equals(BigInteger.ONE)) {
			populaCoberturas(cotacaoView,itemCotacaoView,itemCotacao,coeficienteConversaoMoeda);
		} else {
			itemCotacaoView.getListCoberturaBasica().clear();

			// copia do item 1
			itemCotacaoViewPrincipal.getListCoberturaBasica().forEach(cobertura -> {
				ItemCoberturaView c = CoberturaViewMapper.INSTANCE.copiaItemCobertura(cobertura);
				itemCotacaoView.getListCoberturaBasica().add(c);
			});

			itemCotacaoViewPrincipal.getListCoberturaAcessoriaDM().forEach(cobertura -> itemCotacaoView.getListCoberturaAcessoriaDM().add(CoberturaViewMapper.INSTANCE.copiaItemCobertura(cobertura)));

			if(itemCotacao != null && itemCotacao.getListItemCobertura() != null) {
				for(ItemCobertura i: itemCotacao.getListItemCobertura()) {
					for(ItemCoberturaView itemCoberturaView: itemCotacaoView.getListCoberturaAcessoriaDM()) {
						if(itemCoberturaView.getCodigoCobertura().equals(i.getCodigoCobertura())) {
							if(i.getIdExclusaEndosso() == SimNaoEnum.SIM && i.getValorImportanciaSegurada() != null && i.getValorImportanciaSegurada().compareTo(BigDecimal.ZERO) == 0) {
								itemCoberturaView.setValorImportanciaSegurada("0,00");
							}
						}
					}
				}
			}

			populaCoberturasLMI(cotacaoView,itemCotacaoView,itemCotacao,coeficienteConversaoMoeda);
		}
	}
	
	public void populaCoberturasLMIUnico2(CotacaoView cotacaoView,ItemCotacaoView itemCotacaoViewPrincipal,ItemCotacao itemCotacao,BigDecimal coeficienteConversaoMoeda) {
		ItemCotacaoView itemCotacaoView = new ItemCotacaoView();
		itemCotacao.setNumeroItem(itemCotacao.getNumeroItem());
		itemCotacaoView.setListCoberturaBasica(new ArrayList<>());
		itemCotacaoViewPrincipal.getListCoberturaBasica().forEach(cobertura -> {
			ItemCoberturaView c = CoberturaViewMapper.INSTANCE.copiaItemCobertura(cobertura);
			itemCotacaoView.getListCoberturaBasica().add(c);
		});

		itemCotacaoView.setListCoberturaAcessoriaDM(new ArrayList<>());
		itemCotacaoViewPrincipal.getListCoberturaAcessoriaDM().forEach(cobertura -> itemCotacaoView.getListCoberturaAcessoriaDM().add(CoberturaViewMapper.INSTANCE.copiaItemCobertura(cobertura)));

		populaCoberturasLMI(cotacaoView,itemCotacaoView,itemCotacao,coeficienteConversaoMoeda);
	}

	private void populaCoberturas(CotacaoView cotacaoView,ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,BigDecimal coeficienteConversaoMoeda) {
		populaCoberturasBasicas(itemCotacaoView,itemCotacao,cotacaoView,coeficienteConversaoMoeda);
		populaCoberturasAdicionaisDM(itemCotacaoView,itemCotacao,cotacaoView,coeficienteConversaoMoeda);
	}

	private void populaCoberturasLMI(CotacaoView cotacaoView,ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,BigDecimal coeficienteConversaoMoeda) {
		populaCoberturasBasicasLMI(itemCotacaoView,itemCotacao,cotacaoView,coeficienteConversaoMoeda);
		populaCoberturasAdicionaisDMLMI(itemCotacaoView,itemCotacao,cotacaoView,coeficienteConversaoMoeda);
	}

	private void populaValoresItem(MoedaEnum moeda,ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,BigDecimal coeficienteConversaoMoeda) {
		if (moeda == MoedaEnum.REAL) {
			BigDecimal valoresOS = BigDecimal.ZERO;

			if (itemCotacao.getListItemOutroSeguro() != null && !itemCotacao.getListItemOutroSeguro().isEmpty()) {
				for (ItemOutroSeguro i : itemCotacao.getListItemOutroSeguro()) {
					valoresOS = valoresOS.add(i.getValorLMG());
				}
			}

			itemCotacao.setValorRiscoBemCalculado(numberMapper.asDecimal(itemCotacaoView.getValorRiscoBemCalculado()));
			if (itemCotacao.getValorRiscoBemCalculado() != null) {
				itemCotacao.setValorRiscoBem(numberMapper.asDecimal(itemCotacaoView.getValorRiscoBemCalculado()).add(valoresOS));
			}

			itemCotacao.setValorMaiorRiscoIsolado(numberMapper.asDecimal(itemCotacaoView.getValorMaiorRiscoIsolado()));

			itemCotacao.setValorRiscoBemMoedaEstrangeira(null);
			itemCotacao.setValorCalculadoMoedaEstrangeira(null);
			itemCotacao.setValorIsoladoMoedaEstrangeira(null);
		} else if (moeda == MoedaEnum.DOLAR_VENDA) {
			BigDecimal valoresOS = BigDecimal.ZERO;

			if (itemCotacao.getListItemOutroSeguro() != null && !itemCotacao.getListItemOutroSeguro().isEmpty()) {
				for (ItemOutroSeguro i : itemCotacao.getListItemOutroSeguro()) {
					valoresOS = valoresOS.add(i.getValorLMGMoedaEstrangeira());
				}
			}

			BigDecimal valorRiscoBemCalculado = numberMapper.asDecimal(itemCotacaoView.getValorRiscoBemCalculado());
			BigDecimal valorRiscoBem = null;
			if (valorRiscoBemCalculado != null) {
				valorRiscoBem = valorRiscoBemCalculado.add(valoresOS);
				itemCotacao.setValorRiscoBem(valorRiscoBem);
			}

			BigDecimal valorMaiorRiscoIsolado = numberMapper.asDecimal(itemCotacaoView.getValorMaiorRiscoIsolado());

			itemCotacao.setValorRiscoBemMoedaEstrangeira(valorRiscoBem);
			itemCotacao.setValorCalculadoMoedaEstrangeira(valorRiscoBemCalculado);
			itemCotacao.setValorIsoladoMoedaEstrangeira(valorMaiorRiscoIsolado);

			if (valorRiscoBem != null) {
				valorRiscoBem = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorRiscoBem);
			}

			if (valorRiscoBemCalculado != null) {
				valorRiscoBemCalculado = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorRiscoBemCalculado);
			}

			if (valorMaiorRiscoIsolado != null) {
				valorMaiorRiscoIsolado = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorMaiorRiscoIsolado);
			}

			itemCotacao.setValorRiscoBem(valorRiscoBem);
			itemCotacao.setValorRiscoBemCalculado(valorRiscoBemCalculado);
			itemCotacao.setValorMaiorRiscoIsolado(valorMaiorRiscoIsolado);
		}

		if (SecurityUtils.isCorretor() || itemCotacao.getCotacao().getCodigoProduto().equals(1851)) {
			itemCotacao.setPercentualRelacaoDMPValorRisco(new BigDecimal("100.00"));
		} else {
			itemCotacao.setPercentualRelacaoDMPValorRisco(new NumberMapper().asDecimal(itemCotacaoView.getPercentualRelacaoDMPValorRisco()));
		}
	}

	/**
	 * Popula os valores monetários dos campos de ItemCobertura de acordo com a moeda selecionada
	 *
	 * @param moeda 1 - REAL, 3 - DOLAR
	 * @param itemCoberturaView Objeto de Tela de Cobertura
	 * @param itemCobertura Classe de Domínio de ItemCobertura
	 */
	private void populaValoresItemCobertura(MoedaEnum moeda,ItemCoberturaView itemCoberturaView,ItemCobertura itemCobertura,BigDecimal coeficienteConversaoMoeda) {
		if (moeda == MoedaEnum.REAL) {
			itemCobertura.setValorImportanciaSegurada(numberMapper.asDecimal(itemCoberturaView.getValorImportanciaSegurada()));
			itemCobertura.setValorRiscoBem(numberMapper.asDecimal(itemCoberturaView.getValorRiscoBem()));

			itemCobertura.setValorISMoedaEstrangeira(null);
			itemCobertura.setValorPremioMoedaEstrangeira(null);
			itemCobertura.setValorRiscoBemMoedaEstrangeira(null);
			itemCobertura.setValorSublimiteMoedaEstrangeira(null);
			itemCobertura.setValorSublimiteOriginalMoedaEstrangeira(null);
		} else if (moeda == MoedaEnum.DOLAR_VENDA) {

			itemCobertura.setValorISMoedaEstrangeira(numberMapper.asDecimal(itemCoberturaView.getValorImportanciaSegurada()));
			itemCobertura.setValorRiscoBemMoedaEstrangeira(numberMapper.asDecimal(itemCoberturaView.getValorRiscoBem()));

			BigDecimal valorImportanciaSegurada = numberMapper.asDecimal(itemCoberturaView.getValorImportanciaSegurada());
			BigDecimal valorRiscoBem = numberMapper.asDecimal(itemCoberturaView.getValorRiscoBem());

			if (valorImportanciaSegurada != null) {
				valorImportanciaSegurada = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorImportanciaSegurada);
			}
			if (valorRiscoBem != null) {
				valorRiscoBem = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorRiscoBem);
			}

			itemCobertura.setValorImportanciaSegurada(valorImportanciaSegurada);
			itemCobertura.setValorRiscoBem(valorRiscoBem);

			itemCobertura.setValorPremio(null);
			itemCobertura.setValorSublimite(null);
			itemCobertura.setValorSublimiteOriginal(null);
		}
	}

	private int populaItemDistribuicao(MoedaEnum moeda,ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,int i,BigDecimal coeficienteConversaoMoeda) {

		/**
		 * Remove os itemDistribuicao e insere novamente
		 */

		Set<ItemDistribuicao> items = new HashSet<>();

		for (ItemDistribuicaoView itemDistribuicaoView : itemCotacaoView.getItemsDistribuicao()) {

			ItemDistribuicao itemDistribuicao = new ItemDistribuicao();

			if (moeda == MoedaEnum.REAL) {
				itemDistribuicao.setValorRiscoBem(numberMapper.asDecimal(itemDistribuicaoView.getValorRiscoBem()));
			} else {

				BigDecimal valorRiscoBem = numberMapper.asDecimal(itemDistribuicaoView.getValorRiscoBem());
				itemDistribuicao.setValorRiscoBemMoedaEstrangeira(valorRiscoBem);

				if (valorRiscoBem != null) {
					valorRiscoBem = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorRiscoBem);
				}

				itemDistribuicao.setValorRiscoBem(valorRiscoBem);

			}

			itemDistribuicao.setDescricaoRiscoBem(itemDistribuicaoView.getDescricaoRiscoBem());
			itemDistribuicao.setIdTipoValorRisco(itemDistribuicaoView.getIdTipoValorRisco());
			itemDistribuicao.setSequencialDistribuicaoValorRisco(new BigInteger(String.valueOf(i)));

			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			itemDistribuicao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemDistribuicao.setDataAtualizacao(new Date());
			itemDistribuicao.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));

			itemDistribuicao.setNumeroCotacaoProposta(itemCotacao.getNumeroCotacaoProposta());
			itemDistribuicao.setVersaoCotacaoProposta(itemCotacao.getVersaoCotacaoProposta());

			itemDistribuicao.setItemCotacao(itemCotacao);
			items.add(itemDistribuicao);

			i++;
		}

		itemCotacao.setListItemDistribuicao(items);
		return i;
	}

	private void populaCoberturasBasicas(ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,CotacaoView cotacaoView,BigDecimal coeficienteConversaoMoeda) {
		for (ItemCoberturaView coberturaBasica : itemCotacaoView.getListCoberturaBasica()) {
			if (coberturaBasica.getSequencialItemCobertura() != null) {
				Optional<ItemCobertura> itemCoberturaVal = itemCotacao.getListItemCobertura().stream()
						.filter(i -> i.getSequencialItemCobertura().equals(coberturaBasica.getSequencialItemCobertura()) && 
								i.getNumeroCotacaoProposta().equals(cotacaoView.getNumeroCotacaoProposta()) && 
								i.getVersaoCotacaoProposta().equals(cotacaoView.getVersaoCotacaoProposta()))
						.findFirst();

				if (itemCoberturaVal.isPresent()) {
					if(itemCotacao.getCotacao().getCodigoTipoEndossoSCT() != TipoEndossoSctEnum.REINTEGRACAO_IS) {
						CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaBasica,itemCoberturaVal.get());
						populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaBasica,itemCoberturaVal.get(),coeficienteConversaoMoeda);
						populaDadosCobertura(itemCoberturaVal.get(),itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
					} else {
						if(verificarReintegracao(itemCotacao, itemCoberturaVal.get().getCodigoCobertura())) {
							User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
							itemCoberturaVal.get().setValorISOriginal(itemCoberturaVal.get().getValorImportanciaSegurada());
							itemCoberturaVal.get().setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
							itemCoberturaVal.get().setDataAtualizacao(new Date());
							itemCoberturaVal.get().setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
							if (itemCotacao.getCotacao().getCodigoMoeda() == MoedaEnum.REAL) {
								itemCoberturaVal.get().setValorImportanciaSegurada(numberMapper.asDecimal(coberturaBasica.getValorImportanciaSegurada()));
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaBasica.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimite(itemCoberturaVal.get().getValorSublimite().add(diferenca));
								}
								itemCoberturaVal.get().setValorISMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorPremioMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorRiscoBemMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteOriginalMoedaEstrangeira(null);
							} else {
								itemCoberturaVal.get().setValorISMoedaEstrangeira(numberMapper.asDecimal(coberturaBasica.getValorImportanciaSegurada()));
								BigDecimal valorImportanciaSegurada = numberMapper.asDecimal(coberturaBasica.getValorImportanciaSegurada());
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaBasica.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(itemCoberturaVal.get().getValorSublimiteMoedaEstrangeira().add(diferenca));
								}
								if (valorImportanciaSegurada != null) {
									valorImportanciaSegurada = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorImportanciaSegurada);
								}
								itemCoberturaVal.get().setValorImportanciaSegurada(valorImportanciaSegurada);
							}
						}
					}
				}

			} else {
				if(itemCotacao.getListItemCobertura() != null && itemCotacao.getIdTipoEndosso() != null && itemCotacao.getIdTipoEndosso().equals(1)) {
					boolean populouExistenteEndosso = false;
					for(ItemCobertura ic: itemCotacao.getListItemCobertura()) {
						if(ic.getCodigoCobertura().equals(coberturaBasica.getCodigoCobertura())) {
							CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaBasica,ic);
							populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaBasica,ic,coeficienteConversaoMoeda);
							populaDadosCobertura(ic,itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
							itemCotacao.getListItemCobertura().forEach(it -> it.setIdExclusaEndosso(SimNaoEnum.NAO));
							
							populouExistenteEndosso = true;
							break;
						}
					}
					if(!populouExistenteEndosso) {
						populaCoberturaNova(itemCotacao,cotacaoView,coberturaBasica,coeficienteConversaoMoeda);
					}
				} else {
					populaCoberturaNova(itemCotacao,cotacaoView,coberturaBasica,coeficienteConversaoMoeda);
				}
			}
		}
	}

	private void populaCoberturasBasicasLMI(ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,CotacaoView cotacaoView,BigDecimal coeficienteConversaoMoeda) {
		for (ItemCoberturaView coberturaBasica : itemCotacaoView.getListCoberturaBasica()) {
			if (coberturaBasica.getSequencialItemCobertura() != null && itemCotacao.getSequencialItemCotacao() != null) {
				Optional<ItemCobertura> itemCoberturaVal = itemCotacao.getListItemCobertura().stream()
						.filter(i -> i.getCodigoCobertura().equals(coberturaBasica.getCodigoCobertura()) && 
								i.getNumeroCotacaoProposta().equals(cotacaoView.getNumeroCotacaoProposta()) && 
								i.getVersaoCotacaoProposta().equals(cotacaoView.getVersaoCotacaoProposta()))
						.findFirst();

				if (itemCoberturaVal.isPresent()) {
					if(itemCotacao.getCotacao().getCodigoTipoEndossoSCT() != TipoEndossoSctEnum.REINTEGRACAO_IS) {
						CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaBasica,itemCoberturaVal.get());
						populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaBasica,itemCoberturaVal.get(),coeficienteConversaoMoeda);
						populaDadosCobertura(itemCoberturaVal.get(),itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
					} else {
						if(verificarReintegracao(itemCotacao, itemCoberturaVal.get().getCodigoCobertura())) {
							User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
							itemCoberturaVal.get().setValorISOriginal(itemCoberturaVal.get().getValorImportanciaSegurada());
							itemCoberturaVal.get().setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
							itemCoberturaVal.get().setDataAtualizacao(new Date());
							itemCoberturaVal.get().setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
							if (itemCotacao.getCotacao().getCodigoMoeda() == MoedaEnum.REAL) {
								itemCoberturaVal.get().setValorImportanciaSegurada(numberMapper.asDecimal(coberturaBasica.getValorImportanciaSegurada()));
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaBasica.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimite(itemCoberturaVal.get().getValorSublimite().add(diferenca));
								}
								itemCoberturaVal.get().setValorISMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorPremioMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorRiscoBemMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteOriginalMoedaEstrangeira(null);
							} else {
								itemCoberturaVal.get().setValorISMoedaEstrangeira(numberMapper.asDecimal(coberturaBasica.getValorImportanciaSegurada()));
								BigDecimal valorImportanciaSegurada = numberMapper.asDecimal(coberturaBasica.getValorImportanciaSegurada());
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaBasica.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(itemCoberturaVal.get().getValorSublimiteMoedaEstrangeira().add(diferenca));
								}
								if (valorImportanciaSegurada != null) {
									valorImportanciaSegurada = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorImportanciaSegurada);
								}
								itemCoberturaVal.get().setValorImportanciaSegurada(valorImportanciaSegurada);
							}
							//populaValorSublimiteOriginal(itemCoberturaVal.get(),cotacaoView.getCodigoMoeda(),coeficienteConversaoMoeda);
						}
					}
				}

			} else {
				if(itemCotacao.getListItemCobertura() != null && itemCotacao.getIdTipoEndosso() != null && itemCotacao.getIdTipoEndosso().equals(1)) {
					boolean populouExistenteEndosso = false;
					for(ItemCobertura ic: itemCotacao.getListItemCobertura()) {
						if(ic.getCodigoCobertura().equals(coberturaBasica.getCodigoCobertura())) {
							CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaBasica,ic);
							populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaBasica,ic,coeficienteConversaoMoeda);
							populaDadosCobertura(ic,itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
							itemCotacao.getListItemCobertura().forEach(it -> it.setIdExclusaEndosso(SimNaoEnum.NAO));
							
							populouExistenteEndosso = true;
							break;
						}
					}
					if(!populouExistenteEndosso) {
						populaCoberturaNova(itemCotacao,cotacaoView,coberturaBasica,coeficienteConversaoMoeda);
					}
				} else {
					populaCoberturaNova(itemCotacao,cotacaoView,coberturaBasica,coeficienteConversaoMoeda);
				}
			}
		}
	}

	private void populaCoberturasAdicionaisDM(ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,CotacaoView cotacaoView,BigDecimal coeficienteConversaoMoeda) {
		for (ItemCoberturaView coberturaDM : itemCotacaoView.getListCoberturaAcessoriaDM()) {
			if (coberturaDM.getSequencialItemCobertura() != null) {
				Optional<ItemCobertura> itemCoberturaVal = itemCotacao.getListItemCobertura().stream()
						.filter(i -> i.getSequencialItemCobertura().equals(coberturaDM.getSequencialItemCobertura()) && 
								i.getNumeroCotacaoProposta().equals(cotacaoView.getNumeroCotacaoProposta()) && 
								i.getVersaoCotacaoProposta().equals(cotacaoView.getVersaoCotacaoProposta()))
						.findFirst();

				if (itemCoberturaVal.isPresent()) {
					if(itemCotacao.getCotacao().getCodigoTipoEndossoSCT() != TipoEndossoSctEnum.REINTEGRACAO_IS) {
						CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaDM,itemCoberturaVal.get());
						populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaDM,itemCoberturaVal.get(),coeficienteConversaoMoeda);
						populaDadosCobertura(itemCoberturaVal.get(),itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
					} else {
						if(verificarReintegracao(itemCotacao, itemCoberturaVal.get().getCodigoCobertura())) {
							User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
							itemCoberturaVal.get().setValorISOriginal(itemCoberturaVal.get().getValorImportanciaSegurada());
							itemCoberturaVal.get().setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
							itemCoberturaVal.get().setDataAtualizacao(new Date());
							itemCoberturaVal.get().setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
							if (itemCotacao.getCotacao().getCodigoMoeda() == MoedaEnum.REAL) {
								itemCoberturaVal.get().setValorImportanciaSegurada(numberMapper.asDecimal(coberturaDM.getValorImportanciaSegurada()));
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaDM.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimite(itemCoberturaVal.get().getValorSublimite().add(diferenca));
								}
								itemCoberturaVal.get().setValorISMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorPremioMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorRiscoBemMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteOriginalMoedaEstrangeira(null);
							} else {
								itemCoberturaVal.get().setValorISMoedaEstrangeira(numberMapper.asDecimal(coberturaDM.getValorImportanciaSegurada()));
								BigDecimal valorImportanciaSegurada = numberMapper.asDecimal(coberturaDM.getValorImportanciaSegurada());
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaDM.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(itemCoberturaVal.get().getValorSublimiteMoedaEstrangeira().add(diferenca));
								}
								if (valorImportanciaSegurada != null) {
									valorImportanciaSegurada = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorImportanciaSegurada);
								}
								itemCoberturaVal.get().setValorImportanciaSegurada(valorImportanciaSegurada);
							}
						}
					}
				}

			} else {
				if(itemCotacao.getIdTipoEndosso() != null && itemCotacao.getIdTipoEndosso().equals(1)) {
					boolean populouExistenteEndosso = false;
					for(ItemCobertura ic: itemCotacao.getListItemCobertura()) {
						if(ic.getCodigoCobertura().equals(coberturaDM.getCodigoCobertura())) {
							CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaDM,ic);
							populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaDM,ic,coeficienteConversaoMoeda);
							populaDadosCobertura(ic,itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
							populaExclusaoEndossoCobertura(coberturaDM, ic);
							populouExistenteEndosso = true;
							break;
						}
					}
					if(!populouExistenteEndosso) {
						populaCoberturaNova(itemCotacao,cotacaoView,coberturaDM,coeficienteConversaoMoeda);
					}
				} else {
					populaCoberturaNova(itemCotacao,cotacaoView,coberturaDM,coeficienteConversaoMoeda);
				}
			}
		}
	}

	private void populaExclusaoEndossoCobertura(ItemCoberturaView coberturaDM, ItemCobertura ic) {
		ic.setIdExclusaEndosso(coberturaDM.getIdExclusaEndosso() ? SimNaoEnum.SIM : SimNaoEnum.NAO);
	}

	private void populaCoberturasAdicionaisDMLMI(ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao,CotacaoView cotacaoView,BigDecimal coeficienteConversaoMoeda) {
		for (ItemCoberturaView coberturaDM : itemCotacaoView.getListCoberturaAcessoriaDM()) {
			if (coberturaDM.getSequencialItemCobertura() != null && itemCotacao.getSequencialItemCotacao() != null) {
				Optional<ItemCobertura> itemCoberturaVal = itemCotacao.getListItemCobertura().stream()
						.filter(i -> i.getCodigoCobertura().equals(coberturaDM.getCodigoCobertura()) && 
								i.getNumeroCotacaoProposta().equals(cotacaoView.getNumeroCotacaoProposta()) && 
								i.getVersaoCotacaoProposta().equals(cotacaoView.getVersaoCotacaoProposta()))
						.findFirst();

				if (itemCoberturaVal.isPresent()) {
					if(itemCotacao.getCotacao().getCodigoTipoEndossoSCT() != TipoEndossoSctEnum.REINTEGRACAO_IS) {
						CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaDM,itemCoberturaVal.get());
						populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaDM,itemCoberturaVal.get(),coeficienteConversaoMoeda);
						populaDadosCobertura(itemCoberturaVal.get(),itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
					} else {
						if(verificarReintegracao(itemCotacao, itemCoberturaVal.get().getCodigoCobertura())) {
							User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
							itemCoberturaVal.get().setValorISOriginal(itemCoberturaVal.get().getValorImportanciaSegurada());
							itemCoberturaVal.get().setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
							itemCoberturaVal.get().setDataAtualizacao(new Date());
							itemCoberturaVal.get().setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
							if (itemCotacao.getCotacao().getCodigoMoeda() == MoedaEnum.REAL) {
								itemCoberturaVal.get().setValorImportanciaSegurada(numberMapper.asDecimal(coberturaDM.getValorImportanciaSegurada()));
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaDM.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimite(itemCoberturaVal.get().getValorSublimite().add(diferenca));
								}
								itemCoberturaVal.get().setValorISMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorPremioMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorRiscoBemMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(null);
								itemCoberturaVal.get().setValorSublimiteOriginalMoedaEstrangeira(null);
							} else {
								itemCoberturaVal.get().setValorISMoedaEstrangeira(numberMapper.asDecimal(coberturaDM.getValorImportanciaSegurada()));
								if(itemCoberturaVal.get().getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
									BigDecimal diferenca = new NumberMapper().asDecimal(coberturaDM.getValorImportanciaSegurada()).subtract(itemCoberturaVal.get().getValorISOriginal());
									itemCoberturaVal.get().setValorSublimiteMoedaEstrangeira(itemCoberturaVal.get().getValorSublimiteMoedaEstrangeira().add(diferenca));
								}
								BigDecimal valorImportanciaSegurada = numberMapper.asDecimal(coberturaDM.getValorImportanciaSegurada());
								if (valorImportanciaSegurada != null) {
									valorImportanciaSegurada = BigDecimalUtil.aplicaCoeficienteConversaoMoedaDolarParaReal(coeficienteConversaoMoeda,valorImportanciaSegurada);
								}
								itemCoberturaVal.get().setValorImportanciaSegurada(valorImportanciaSegurada);
							}
						}
					}
				}

			} else {
				if(itemCotacao.getIdTipoEndosso() != null && itemCotacao.getIdTipoEndosso().equals(1)) {
					boolean populouExistenteEndosso = false;
					for(ItemCobertura ic: itemCotacao.getListItemCobertura()) {
						if(ic.getCodigoCobertura().equals(coberturaDM.getCodigoCobertura())) {
							CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaDM,ic);
							populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaDM,ic,coeficienteConversaoMoeda);
							populaDadosCobertura(ic,itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);
							populaExclusaoEndossoCobertura(coberturaDM, ic);
							populouExistenteEndosso = true;
							break;
						}
					}
					if(!populouExistenteEndosso) {
						populaCoberturaNova(itemCotacao,cotacaoView,coberturaDM,coeficienteConversaoMoeda);
					}
				} else {
					populaCoberturaNova(itemCotacao,cotacaoView,coberturaDM,coeficienteConversaoMoeda);
				}
			}
		}
	}

	private void populaCoberturaNova(ItemCotacao itemCotacao,CotacaoView cotacaoView,ItemCoberturaView coberturaBasica,BigDecimal coeficienteConversaoMoeda) {
		ItemCobertura itemCobertura = new ItemCobertura();

		coberturaBasica.setSequencialItemCobertura(null);
		CoberturaViewMapper.INSTANCE.toCobertura(cotacaoView,coberturaBasica,itemCobertura);
		itemCobertura.setIdFormaFranquia(FormaFranquiaEnum.NAO_HA);
		itemCobertura.setIdTextoFranquia(1);
		if(Arrays.asList(TipoEndossoEnum.INCLUSAO_ITEM.getId(),TipoEndossoEnum.ALTERACAO.getId()).contains(itemCotacao.getIdTipoEndosso())) {
			itemCobertura.setIdControleExclusaoEndosso(SimNaoEnum.SIM);
		}

		if (itemCotacao.getListItemCobertura() == null) {
			itemCotacao.setListItemCobertura(new HashSet<ItemCobertura>());
		}
		itemCobertura.setItemCotacao(itemCotacao);

		populaValoresItemCobertura(cotacaoView.getCodigoMoeda(),coberturaBasica,itemCobertura,coeficienteConversaoMoeda);
		populaDadosCobertura(itemCobertura,itemCotacao.getCotacao().getCodigoProduto(),coeficienteConversaoMoeda);

		itemCobertura.setVersaoCotacaoProposta(itemCotacao.getVersaoCotacaoProposta());
		itemCobertura.setNumeroCotacaoProposta(itemCotacao.getNumeroCotacaoProposta());

		itemCotacao.getListItemCobertura().add(itemCobertura);
	}
	
	private void populaDadosItem(Cotacao cotacao,ItemCotacao itemCotacao, ItemCotacaoView itemCotacaoView) {
		
		populaDadosVigenciaItem(cotacao,itemCotacao,itemCotacaoView);
		
		
		if(Arrays.asList(9650,9651,1860,1861,9652).contains(cotacao.getCodigoProduto())) {
			itemCotacao.setCodigoLocalizacao(1);
		}
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		itemCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		itemCotacao.setDataAtualizacao(new Date());
		itemCotacao.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
	}

	private void populaDadosVigenciaItemPlataforma(Cotacao cotacao,ItemCotacao itemCotacao) {
		itemCotacao.setDataInicioVigencia(cotacao.getDataInicioVigencia());
		itemCotacao.setDataFimVigencia(cotacao.getDataFimVigencia());
		itemCotacao.setDataAlteracao(cotacao.getDataAlteracao());
	}
	
	private void populaDadosVigenciaItem(Cotacao cotacao,ItemCotacao itemCotacao,ItemCotacaoView itemCotacaoView) {
		//se for apólice, o item assume as mesmas datas da cotação
		if(TipoPedidoCotacaoEnum.APOLICE == cotacao.getIdTipoPedidoCotacao()) {
			itemCotacao.setDataInicioVigencia(cotacao.getDataInicioVigencia());
			itemCotacao.setDataAlteracao(cotacao.getDataAlteracao());			
		}
		//se for item novo (endosso), o início de vigência do item será igual a data de alteração da cotação
		else if (itemCotacaoView.getSequencialItemCotacao() == null || (itemCotacao.getIdTipoEndosso() != null && TipoEndossoEnum.INCLUSAO_ITEM.getId().equals(itemCotacao.getIdTipoEndosso()))){
			itemCotacao.setDataInicioVigencia(cotacao.getDataAlteracao());
			itemCotacao.setDataAlteracao(cotacao.getDataAlteracao());			
		}
		//se for um item já existente (endosso) a data de alteração for posterior a data de início de vigência do item 
		else if(cotacao.getDataAlteracao().after(itemCotacao.getDataInicioVigencia())) {
			itemCotacao.setDataAlteracao(cotacao.getDataAlteracao());	
		}
		else if(itemCotacaoView.getIdTipoEndosso() != null) {
			itemCotacao.setDataAlteracao(itemCotacao.getDataInicioVigencia());
		}
		
		//a data de fim de vigência é igual em todos os casos
		itemCotacao.setDataFimVigencia(cotacao.getDataFimVigencia());
	}

	private void populaDadosCobertura(ItemCobertura itemCobertura,Integer codigoProduto,BigDecimal coeficienteConversaoMoeda) {

		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		itemCobertura.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		itemCobertura.setDataAtualizacao(new Date());
		itemCobertura.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
		if(itemCobertura.getItemCotacao().getIdResseguroFacultativo() == SimNaoEnum.SIM) {
			itemCobertura.setIdExigeOficio(SimNaoEnum.SIM);
		} else {
			itemCobertura.setIdExigeOficio(SimNaoEnum.NAO);
		}

		if (itemCobertura.getIdCoberturaAvulsa() == SimNaoEnum.NAO) {
			Cobertura cobertura = coberturaRepository.findCobertura(itemCobertura.getCodigoCobertura());

			if (cobertura != null) {
				itemCobertura.setIdTipoCobertura(cobertura.getTipo());
				itemCobertura.setExigeVagasGaragem(cobertura.getIdVagasGaragem().getLogical());
			}

			if (!itemCobertura.isExigeVagasGaragem()) {
				itemCobertura.setNumeroVagasGaragem(null);
			}
		} else {
			ItemCobertura coberturaBasica = itemCobertura.getItemCotacao().getListItemCobertura()
					.stream()
					.filter(c -> c.getIdTipoCobertura().equals(1))
					.findAny().orElse(null);
			if(coberturaBasica != null) {
				itemCobertura.setCodigoRamoCoberturaContabil(coberturaBasica.getCodigoRamoCoberturaContabil());
				itemCobertura.setCodigoGrupoRamoContabil(coberturaBasica.getCodigoGrupoRamoContabil());
				itemCobertura.setCodigoRamoCoberturaEmissao(coberturaBasica.getCodigoRamoCoberturaEmissao());
				itemCobertura.setCodigoGrupoRamoEmissao(coberturaBasica.getCodigoGrupoRamoEmissao());
			}
		}

		populaDadosProdutoCobertura(itemCobertura);

		if (logger.isDebugEnabled()) {
			logger.debug("antes populaValorSublimiteOriginal");
			logger.debug("cobertura.............................: " + itemCobertura.getSequencialItemCobertura());
			logger.debug("valorImportanciaSegurada..............: " + itemCobertura.getValorImportanciaSegurada());
			logger.debug("valorISMoedaEstrangeira...............: " + itemCobertura.getValorISMoedaEstrangeira());
			logger.debug("valorSublimite........................: " + itemCobertura.getValorSublimite());
			logger.debug("valorSublimiteMoedaEstrangeira........: " + itemCobertura.getValorSublimiteMoedaEstrangeira());
			logger.debug("valorSublimiteOriginal................: " + itemCobertura.getValorSublimiteOriginal());
			logger.debug("valorSublimiteOriginalMoedaEstrangeira: " + itemCobertura.getValorSublimiteOriginalMoedaEstrangeira());
			logger.debug("valorRiscoBem.........................: " + itemCobertura.getValorRiscoBem());
			logger.debug("valorRiscoBemMoedaEstrangeira.........: " + itemCobertura.getValorRiscoBemMoedaEstrangeira() + "\r\n");
		}

		calculaSublimiteService.populaValorSublimiteOriginal(itemCobertura,itemCobertura.getItemCotacao().getCotacao().getCodigoMoeda(),coeficienteConversaoMoeda);

		if (logger.isDebugEnabled()) {
			logger.debug("depois populaValorSublimiteOriginal");
			logger.debug("cobertura.............................: " + itemCobertura.getSequencialItemCobertura());
			logger.debug("valorImportanciaSegurada..............: " + itemCobertura.getValorImportanciaSegurada());
			logger.debug("valorISMoedaEstrangeira...............: " + itemCobertura.getValorISMoedaEstrangeira());
			logger.debug("valorSublimite........................: " + itemCobertura.getValorSublimite());
			logger.debug("valorSublimiteMoedaEstrangeira........: " + itemCobertura.getValorSublimiteMoedaEstrangeira());
			logger.debug("valorSublimiteOriginal................: " + itemCobertura.getValorSublimiteOriginal());
			logger.debug("valorSublimiteOriginalMoedaEstrangeira: " + itemCobertura.getValorSublimiteOriginalMoedaEstrangeira());
			logger.debug("valorRiscoBem.........................: " + itemCobertura.getValorRiscoBem());
			logger.debug("valorRiscoBemMoedaEstrangeira.........: " + itemCobertura.getValorRiscoBemMoedaEstrangeira() + "\r\n");
		}
	}

	public void populaDadosProdutoCobertura(ItemCobertura itemCobertura) {
		ProdutoCobertura produtoCobertura = coberturaRepository.findProdutoCobertura(itemCobertura.getItemCotacao().getCotacao().getCodigoProduto(),itemCobertura.getCodigoCobertura());

		if (produtoCobertura != null) {
			itemCobertura.setCodigoGrupoRamoEmissao(produtoCobertura.getGrupoRamoEmissao());
			itemCobertura.setCodigoRamoCoberturaEmissao(produtoCobertura.getRamoEmissao());
			itemCobertura.setCodigoGrupoRamoContabil(produtoCobertura.getGrupoRamoContabil());
			itemCobertura.setCodigoRamoCoberturaContabil(produtoCobertura.getRamoContabil());

			itemCobertura.setCodigoLimiteAgrupamento(produtoCobertura.getCodigoLimiteAgrupamento());
			itemCobertura.setTipoIS(produtoCobertura.getTipoIS());

			if (produtoCobertura.getAplicacaoPeriodoIndenitario() == AplicacaoPeriodoIndenitarioEnum.NAO_UTILIZA_TABELA) {
				itemCobertura.setCodigoPeriodoIndenitario(null);
			} else {
				itemCobertura.setExigePeriodoIndenitario(true);
			}
			itemCobertura.setIdLucrosCessantes(produtoCobertura.getLucrosCessantes());
			itemCobertura.setIdDanosMateriais(produtoCobertura.getDanosMateriais());
			itemCobertura.setFormaLimiteIS(produtoCobertura.getFormaLimiteIS() == null ? false : produtoCobertura.getFormaLimiteIS().getLogical());
			itemCobertura.setExigeValorRisco(produtoCobertura.getExigeValorRisco().getLogical());
			if (itemCobertura.getIdTipoCobertura().equals(1)) {
				itemCobertura.setExigeValorRisco(false);
			}

			itemCobertura.setLiberaSublimite(produtoCobertura.getLiberaSublimite().getLogical());
		}
	}
	
	private void populaDadosSeguradoItem(Cotacao cotacao,ItemCotacao itemCotacaoVal) {
		itemCotacaoVal.setNumeroCNPJCPFSegurado(cotacao.getNumeroCNPJCPFSegurado());

		itemCotacaoVal.setNomeSegurado(cotacao.getNomeSegurado());
		itemCotacaoVal.setIdTipoPessoa(cotacao.getIdTipoPessoa());
		itemCotacaoVal.setCodigoAtividadePrincipal(cotacao.getCodigoAtividadePrincipal());
		itemCotacaoVal.setDescricaoAtividadePrincipal(cotacao.getDescricaoAtividadePrincipal());

		if (cotacao.getIdCEPSegurado() != null) {
			itemCotacaoVal.setIdCEPSegurado(cotacao.getIdCEPSegurado());
		} else {
			itemCotacaoVal.setIdCEPSegurado(null);
		}

		itemCotacaoVal.setEnderecoSegurado(cotacao.getEnderecoSegurado());
		itemCotacaoVal.setNumeroEnderecoSegurado(cotacao.getNumeroEnderecoSegurado());
		itemCotacaoVal.setNomeComplementoEnderecoSegurado(cotacao.getNomeComplementoEnderecoSegurado());
		itemCotacaoVal.setNomeBairroSegurado(cotacao.getNomeBairroSegurado());
		itemCotacaoVal.setNomeMunicipioSegurado(cotacao.getNomeMunicipioSegurado());
		itemCotacaoVal.setIdUFSegurado(cotacao.getIdUFSegurado());
		itemCotacaoVal.setIdEmailSegurado(cotacao.getIdEmailSegurado());
		itemCotacaoVal.setNumeroDDDSegurado(cotacao.getNumeroDDDSegurado());
		itemCotacaoVal.setNumeroTelefoneSegurado(cotacao.getNumeroTelefoneSegurado());
		itemCotacaoVal.setNumeroDDDCelularSegurado(cotacao.getNumeroDDDCelularSegurado());
		itemCotacaoVal.setNumeroCelularSegurado(cotacao.getNumeroCelularSegurado());
		itemCotacaoVal.setCoeficienteConversaoMoeda(cotacao.getCoeficienteConversaoMoeda());
		itemCotacaoVal.setDataConversaoValorRisco(cotacao.getDataConversaoValorRisco());
	}

	private void populaProtecional(ItemCotacaoView itemCotacaoView,ItemCotacao itemCotacao) {
		if (itemCotacaoView.getProtecionais() != null && !itemCotacaoView.getProtecionais().isEmpty()) {
			List<Long> novosProtecionais = new ArrayList<>(itemCotacaoView.getProtecionais());

			if (itemCotacao.getListItemSistemaProtecional() == null) {
				itemCotacao.setListItemSistemaProtecional(new HashSet<>());
			}

			for (ItemSistemaProtecional protecional : itemCotacao.getListItemSistemaProtecional()) {
				if (novosProtecionais.contains(protecional.getCodigoSistemaProtecional())) {
					novosProtecionais.remove(protecional.getCodigoSistemaProtecional());
				}
			}

			if (!novosProtecionais.isEmpty()) {
				for (Long protecional : novosProtecionais) {
					ItemSistemaProtecional itemSistemaProtecional = new ItemSistemaProtecional();
					itemSistemaProtecional.setCodigoSistemaProtecional(protecional);

					User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

					itemSistemaProtecional.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
					itemSistemaProtecional.setDataAtualizacao(new Date());
					itemSistemaProtecional.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));

					itemSistemaProtecional.setItemCotacao(itemCotacao);
					itemSistemaProtecional.setNumeroCotacaoProposta(itemCotacao.getNumeroCotacaoProposta());
					itemSistemaProtecional.setVersaoCotacaoProposta(itemCotacao.getVersaoCotacaoProposta());

					itemCotacao.getListItemSistemaProtecional().add(itemSistemaProtecional);
				}
			}
		}
	}

	public void populaComissao(CotacaoView cotacaoView,Cotacao cotacao) {
		if(!Arrays.asList(TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO, TipoEndossoSctEnum.REINTEGRACAO_IS).contains(cotacao.getCodigoTipoEndossoSCT())) {
			if (cotacao.getListComissaoCotacao() == null || cotacao.getListComissaoCotacao().isEmpty()) {
				if (!StringUtils.isEmpty(cotacaoView.getPercentualComissao())) {
					List<ItemCobertura> coberturas = cotacao.getListItem().stream().flatMap(item -> item.getListItemCobertura().stream()).collect(Collectors.toList());
	
					if (coberturas.stream()
							.filter(it -> it.getCoberturaPrincipal() == null
									&& (it.getCodigoGrupoRamoEmissao() == null
									|| it.getCodigoRamoCoberturaEmissao() == null))
							.count() > 0) {
						return;
					}
	
					Comparator<ItemCobertura> comparator = Comparator.comparing(ItemCobertura::getCodigoGrupoRamoEmissao).thenComparing(ItemCobertura::getCodigoRamoCoberturaEmissao);
	
					Set<ItemCobertura> semDuplicadas = new TreeSet<>(comparator);
					semDuplicadas.addAll(coberturas);
	
					Set<ComissaoCotacao> comissoes = new HashSet<>();
	
					for (ItemCobertura cob : semDuplicadas) {
						if (cob.getCodigoGrupoRamoEmissao() != null && cob.getCodigoRamoCoberturaEmissao() != null) {
							ComissaoCotacao comissao = new ComissaoCotacao();
							comissao.setCodigoGrupoRamo(cob.getCodigoGrupoRamoEmissao());
							comissao.setCodigoRamo(cob.getCodigoRamoCoberturaEmissao());
							comissao.setPercentualComissao(new NumberMapper().asDecimal(cotacaoView.getPercentualComissao()));
							comissao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
							comissao.setUsuarioAtualizacao(cotacao.getUsuarioAtualizacao());
							comissao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
							comissao.setCodigoGrupo(cotacao.getCodigoGrupo());
							comissao.setDataAtualizacao(new Date());
							comissao.setCotacao(cotacao);
							comissoes.add(comissao);
						}
					}
	
					cotacao.setListComissaoCotacao(comissoes);
				}
			} else {
				// TODO deleta todas as comissões e inclui de novo
				for (ComissaoCotacao comissao : cotacao.getListComissaoCotacao()) {
					comissao.setPercentualComissao(new BigDecimal(cotacaoView.getPercentualComissao().replaceAll(",","\\.")));
				}
			}
		}
	}

	private boolean verificarReintegracao(ItemCotacao itemCotacao, Integer codigoCobertura) {
		boolean lmiUnico = itemCotacao.getCotacao().getIdLmiUnico().getLogical();
		if(lmiUnico) {
			for(ItemCotacao item: itemCotacao.getCotacao().getListItem()) {
				if(item.getListItemSinistro() != null) {
					for(ItemSinistro itemSinistro: item.getListItemSinistro()) {
						if(itemSinistro.getListItemCoberturaSinistro() != null) {
							for(ItemCoberturaSinistro ics: itemSinistro.getListItemCoberturaSinistro()) {
								if(ics.getCodigoCobertura().equals(codigoCobertura)) {
									return true;
								}
							}
						}
					}
				}
			}
		} else {
			if(itemCotacao.getListItemSinistro() != null && itemCotacao.getIdTipoEndosso() != null) {
				for(ItemSinistro itemSinistro: itemCotacao.getListItemSinistro()) {
					if(itemSinistro.getListItemCoberturaSinistro() != null) {
						for(ItemCoberturaSinistro ics: itemSinistro.getListItemCoberturaSinistro()) {
							if(ics.getCodigoCobertura().equals(codigoCobertura)) {
								return true;
							}
						}
					}
				}
			}
		}

		return false;
	}
}