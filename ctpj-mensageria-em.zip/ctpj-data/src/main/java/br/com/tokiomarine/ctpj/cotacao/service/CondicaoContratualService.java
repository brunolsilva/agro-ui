package br.com.tokiomarine.ctpj.cotacao.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.CondicaoContratualCotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemRamoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.CondicaoContratualCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCondContratual;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCoberturaEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CondicaoContratualRepository;
@Transactional
@Service
public class CondicaoContratualService {

	private static Logger logger = LogManager.getLogger(CondicaoContratualService.class);

	@Autowired
	private CondicaoContratualRepository condicaoContratualRepository;

	@Autowired
	private CondicaoContratualCotacaoRepository condicaoContratualCotacaoRepository;

	@Autowired
	private ItemRamoRepository itemRamoRepository;

	@LogPerformance
	public void gerarCondicaoContratualApolice(Cotacao cotacao,User user) throws ServiceException {
		List<ProdutoCondContratual> listaProdutoCondContratual = new ArrayList<>();
		List<ProdutoCondContratual> listaProdutoCondContratualFull = new ArrayList<>();
		try {
			condicaoContratualCotacaoRepository.deleteBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			listaProdutoCondContratualFull.addAll(gerarCondicaoContratualProduto(cotacao));
			listaProdutoCondContratualFull.addAll(gerarCondicaoContratualItemRamo(cotacao));
			listaProdutoCondContratualFull.addAll(gerarCondicaoContratualItemCobertura(cotacao));

			List<ProdutoCondContratual> lista = new ArrayList<>(listaProdutoCondContratualFull);

			Comparator<ProdutoCondContratual> comparator = Comparator
					.comparing(ProdutoCondContratual::getCodigoClausula)
					.thenComparing(ProdutoCondContratual::getRamo);

			Set<ProdutoCondContratual> semDuplicadas = new TreeSet<>(comparator);
			
			for(ProdutoCondContratual item: lista) {
				semDuplicadas.add(item);
			}
			
			listaProdutoCondContratual = semDuplicadas.stream().collect(Collectors.toList());
			
			condicaoContratualCotacaoRepository.saveList(gerarListaCondicacaoContratual(cotacao, listaProdutoCondContratual,user));
			
		} catch (HibernateException re) {
			logger.error("Erro ao processar condição contratual: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro geral ao processar condição contratual: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public List<ProdutoCondContratual> gerarCondicaoContratualProduto(Cotacao cotacao){
		return condicaoContratualRepository.findProdutoCondicaoContratualByProduto(cotacao.getCodigoProduto(),cotacao.getDataInicioVigencia());
	}

	public List<ProdutoCondContratual> gerarCondicaoContratualItemRamo(Cotacao cotacao) throws ServiceException {
		List<Object[]> ItemRamoGrupoRamoRamo = itemRamoRepository.findGrupoRamoRamoEmissao(cotacao.getSequencialCotacaoProposta());
		List<ProdutoCondContratual> listaProdutoCondContratual = new ArrayList<>();
		try{
			for (Object[] grr : ItemRamoGrupoRamoRamo) {
				Integer codigoGrupoRamo = (Integer) grr[0];
				Integer codigoRamo = (Integer) grr[1];
				listaProdutoCondContratual.addAll(condicaoContratualRepository.findProdutoCondicaoContratualByGrupoRamo(cotacao.getCodigoProduto(),codigoGrupoRamo,codigoRamo,cotacao.getDataInicioVigencia()));
			}
		} catch (HibernateException re) {
			logger.error("Erro ao processar condição contratual item ramo: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro geral ao processar condição contratual item ramo: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return listaProdutoCondContratual;
	}

	public List<ProdutoCondContratual> gerarCondicaoContratualItemCobertura(Cotacao cotacao)  throws ServiceException {
		List<ProdutoCondContratual> listaProdutoCondContratual = new ArrayList<>();
		try{
			for (ItemCotacao itemCotacao : cotacao.getListItem()){
				for (ItemCobertura itemCoberturaBasica : itemCotacao
						.getListItemCobertura()
						.stream()
						.filter(cb->cb.getIdCoberturaAvulsa().equals(SimNaoEnum.NAO) &&
						cb.getIdTipoCobertura().equals(TipoCoberturaEnum.BASICA.getId()))
						.collect(Collectors.toList())){
					listaProdutoCondContratual.addAll(condicaoContratualRepository.findProdutoCondicaoContratualByBasica(
							cotacao.getCodigoProduto(),
							itemCoberturaBasica.getCodigoGrupoRamoEmissao(),
							itemCoberturaBasica.getCodigoRamoCoberturaEmissao(),
							itemCoberturaBasica.getCodigoCobertura(),
							cotacao.getDataInicioVigencia()));
					for (ItemCobertura itemCoberturaAdicional : itemCotacao
							.getListItemCobertura()
							.stream()
							.filter(ca->ca.getIdCoberturaAvulsa().equals(SimNaoEnum.NAO) && 
									ca.getIdTipoCobertura().equals(TipoCoberturaEnum.ADICIONAL.getId()) && 
									ca.getCoberturaPrincipal().equals(itemCoberturaBasica.getCodigoCobertura()))
							.collect(Collectors.toList())){
						listaProdutoCondContratual.addAll(condicaoContratualRepository.findProdutoCondicaoContratualByAdicional(
								cotacao.getCodigoProduto(),
								itemCoberturaAdicional.getCodigoGrupoRamoEmissao(),
								itemCoberturaAdicional.getCodigoRamoCoberturaEmissao(),
								itemCoberturaAdicional.getCodigoCobertura(),
								itemCoberturaBasica.getCodigoCobertura(),
								cotacao.getDataInicioVigencia()));

						for (ItemCobertura itemCoberturaEspecial : itemCotacao
								.getListItemCobertura()
								.stream()
								.filter(ce->ce.getIdCoberturaAvulsa().equals(SimNaoEnum.NAO) &&
										ce.getIdTipoCobertura().equals(TipoCoberturaEnum.ESPECIAL.getId()) && 
										ce.getCoberturaPrincipal().equals(itemCoberturaAdicional.getCodigoCobertura()))
								.collect(Collectors.toList())){
							listaProdutoCondContratual.addAll(condicaoContratualRepository.findProdutoCondicaoContratualByEspecial(
									cotacao.getCodigoProduto(),
									itemCoberturaEspecial.getCodigoGrupoRamoEmissao(),
									itemCoberturaEspecial.getCodigoRamoCoberturaEmissao(),
									itemCoberturaEspecial.getCodigoCobertura(),
									itemCoberturaBasica.getCodigoCobertura(),
									itemCoberturaAdicional.getCodigoCobertura(),
									cotacao.getDataInicioVigencia()));
							
							for (ItemCobertura itemCoberturaEEspecial : itemCotacao
									.getListItemCobertura()
									.stream()
									.filter(cee->cee.getIdCoberturaAvulsa().equals(SimNaoEnum.NAO) &&
											cee.getIdTipoCobertura().equals(TipoCoberturaEnum.ESPECIAL2.getId()) && 
											cee.getCoberturaPrincipal().equals(itemCoberturaEspecial.getCodigoCobertura()))
									.collect(Collectors.toList())){
							
								listaProdutoCondContratual.addAll(condicaoContratualRepository.findProdutoCondicaoContratualByEEspecial(
										cotacao.getCodigoProduto(),
										itemCoberturaEEspecial.getCodigoGrupoRamoEmissao(),
										itemCoberturaEEspecial.getCodigoRamoCoberturaEmissao(),
										itemCoberturaEEspecial.getCodigoCobertura(),
										itemCoberturaBasica.getCodigoCobertura(),
										itemCoberturaAdicional.getCodigoCobertura(),
										itemCoberturaEspecial.getCodigoCobertura(),
										cotacao.getDataInicioVigencia()));
							}
						}
					}
				}
			}
		} catch (HibernateException re) {
			logger.error("Erro ao processar condição contratual item cobertura: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro geral ao processar condição contratual item cobertura: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return listaProdutoCondContratual;
	}

	public List<CondicaoContratualCotacao> gerarListaCondicacaoContratual (Cotacao cotacao,List<ProdutoCondContratual> listaProdutoCondicacaoContratual,User user)  throws ServiceException {
		List<CondicaoContratualCotacao> listaCondContratual = new ArrayList<>();
		CondicaoContratualCotacao	condicaoContratual;
		try{
			for (ProdutoCondContratual produtoCondContratual : listaProdutoCondicacaoContratual) {
				condicaoContratual = new CondicaoContratualCotacao();
				condicaoContratual.setCotacao(cotacao);
				condicaoContratual.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
				condicaoContratual.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
				condicaoContratual.setCodigoGrupoRamo(produtoCondContratual.getGrupoRamo());
				condicaoContratual.setCodigoRamoClausula(produtoCondContratual.getRamo());
				condicaoContratual.setCodigoClausula(produtoCondContratual.getCodigoClausula());
				condicaoContratual.setCodigoVersao(produtoCondContratual.getVersao());
				condicaoContratual.setDataAtualizacao(new Date());	
				condicaoContratual.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				condicaoContratual.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				listaCondContratual.add(condicaoContratual);
			}
		} catch (HibernateException re) {
			logger.error("Erro ao gerar lista condição contratual: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro geral ao gerar lista condição contratual: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return listaCondContratual;
	}
}