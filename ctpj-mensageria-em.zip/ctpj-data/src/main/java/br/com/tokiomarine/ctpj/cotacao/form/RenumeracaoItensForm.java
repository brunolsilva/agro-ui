package br.com.tokiomarine.ctpj.cotacao.form;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.RenumeracaoItem;

public class RenumeracaoItensForm implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5821411584956801648L;
	
	
	private BigInteger sequencialCotacaoProposta;
	private List<RenumeracaoItem> itensRenumeracao;
	
	private User user;
	
	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}
	
	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}
	
	public List<RenumeracaoItem> getItensRenumeracao() {
		return itensRenumeracao;
	}
	
	public void setItensRenumeracao(List<RenumeracaoItem> itensRenumeracao) {
		this.itensRenumeracao = itensRenumeracao;
	}

	
	public User getUser() {
		return user;
	}

	
	public void setUser(User user) {
		this.user = user;
	}
	
	
	
	
}
