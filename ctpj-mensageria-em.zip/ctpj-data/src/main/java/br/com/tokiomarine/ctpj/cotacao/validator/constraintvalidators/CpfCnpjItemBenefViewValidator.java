package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.math.BigInteger;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.CpfCnpjItemBenefView;

/**
 * Valida o número de CPF/CNPJ do dto ItemBeneficiarioView
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class CpfCnpjItemBenefViewValidator implements ConstraintValidator<CpfCnpjItemBenefView, ItemBeneficiarioView> {

	@Override
	public void initialize(CpfCnpjItemBenefView constraintAnnotation) {		
		
	}

	@Override
	public boolean isValid(ItemBeneficiarioView item, ConstraintValidatorContext constraintValidatorContext) {		
		String tipoPessoa = item.getTipoPessoa();
		String numeroCPFCNPJ = item.getNumeroCPFCNPJ();
		BigInteger numeroItemCotacao = item.getNumeroItemCotacao();
		
		constraintValidatorContext.disableDefaultConstraintViolation();
		
		//Não foram informados o tipo pessoa e o número de CPF/CNPJ -> válido
		if(tipoPessoa == null && numeroCPFCNPJ == null)
			return true;
		
		//Não foi fornecido o tipoPessoa, mas não foi fornecido o CPF/CNPJ -> válido
		if(tipoPessoa != null && numeroCPFCNPJ == null)
			return true;
		
		//Não foi informado o tipo pessoa -> inválido
		if(tipoPessoa == null && numeroCPFCNPJ != null){
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao +  " - Informar o tipo da pessoa")
			.addConstraintViolation();
			return false;
		}
		
		//tipo pessoa inválido -> inválido
		if(!"F".equals(tipoPessoa) && !"J".equals(tipoPessoa)){
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao +  " - Tipo da pessoa inválido")
			.addConstraintViolation();
			
			return false;
		}
		
		//Valida o número de CPF/CNPJ
		if(tipoPessoa.equals("F")){
			if(ValidaCpfCnpj.isValidCPF(numeroCPFCNPJ))
				return true;
			
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao +  " - Número do CPF inválido")
			.addConstraintViolation();
			return false;
		}else{
			if(ValidaCpfCnpj.isValidCNPJ(numeroCPFCNPJ))
				return true;
			
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao +  " - Número do CNPJ inválido")
			.addConstraintViolation();
			return false;
		}	
		
	}
	

}
