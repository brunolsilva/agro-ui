package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.domain.cotacao.JurosParcelamentoCotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.FormaPagamento;

@Repository
public class FormaPagamentoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static Logger logger = LogManager.getLogger(FormaPagamentoRepository.class);

	public FormaPagamento findFormaPagamentoByCodigo(Integer codigo)  throws RepositoryException{

		FormaPagamento formaPagamento = null;

		logger.info("Buscando Forma de Pagamento by codigo: "+codigo);

		try{
			formaPagamento = mongoTemplate.findOne(
				query(where("codigo").is(codigo)
							), FormaPagamento.class);
		}catch (Exception e) {
			logger.error("Erro na Busca do Forma de Pagamento by codigo, codigo numero: "+codigo,e);
			throw new RepositoryException("Erro na Busca de Pagamento by codigo, codigo numero: "+codigo,e);
		}
		return formaPagamento;
	}

	public Map<Integer, FormaPagamento> findFormaPagamentoByJuros(List<JurosParcelamentoCotacao> juros) {
		List<FormaPagamento> formas = mongoTemplate.find(
				query(
						where("codigo").in(
								juros.stream().map(JurosParcelamentoCotacao::getCodigoFormaPagamento).collect(Collectors.toList()))
					),
				FormaPagamento.class);

		return formas.stream().collect(Collectors.toMap(FormaPagamento::getCodigo, Function.identity()));
	}

	public Map<Integer, FormaPagamento> findFormasPagamentoByCodigo(List<Integer> codigos) {
		List<FormaPagamento> formas = mongoTemplate.find(
				query(where("codigo").in(codigos)),FormaPagamento.class);

		return formas.stream().collect(Collectors.toMap(FormaPagamento::getCodigo, Function.identity()));
	}
}
