package br.com.tokiomarine.ctpj.integracao.backoffice.request;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreditoDisponivelRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8886134612294318759L;

	@JsonProperty("p_cd_banco")
	private Long numeroBanco;

	@JsonProperty("p_cd_pedido_cotacao")
	private BigInteger numeroCotacaoProposta;

	@JsonProperty("p_id_tipo_recebimento")
	private String idTipoRecebimento;

	@JsonProperty("p_nr_nosso_numero")
	private String numeroNossoNumeroTitulo;

	@JsonProperty("p_vl_recebimento")
	private BigDecimal valorCredito;

	@JsonProperty("p_cd_matricula")
	private String codigoMatricula;
	
	public Long getNumeroBanco() {
		return numeroBanco;
	}

	public void setNumeroBanco(Long numeroBanco) {
		this.numeroBanco = numeroBanco;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public String getIdTipoRecebimento() {
		return idTipoRecebimento;
	}

	public void setIdTipoRecebimento(String idTipoRecebimento) {
		this.idTipoRecebimento = idTipoRecebimento;
	}

	public String getNumeroNossoNumeroTitulo() {
		return numeroNossoNumeroTitulo;
	}

	public void setNumeroNossoNumeroTitulo(String numeroNossoNumeroTitulo) {
		this.numeroNossoNumeroTitulo = numeroNossoNumeroTitulo;
	}

	public BigDecimal getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(BigDecimal valorCredito) {
		this.valorCredito = valorCredito;
	}

	public String getCodigoMatricula() {
		return codigoMatricula;
	}

	public void setCodigoMatricula(String codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	@Override
	public String toString() {
		return "ConsultaCreditoDisponivelRequest [numeroBanco=" + numeroBanco + ", numeroCotacaoProposta=" + numeroCotacaoProposta + 
				", idTipoRecebimento=" + idTipoRecebimento + ", numeroNossoNumeroTitulo=" + numeroNossoNumeroTitulo + 
				", valorCredito=" + valorCredito + ", codigoMatricula=" + codigoMatricula +"]";
	}

}
