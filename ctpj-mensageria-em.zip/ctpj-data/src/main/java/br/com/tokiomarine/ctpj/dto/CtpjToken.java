package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;

import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;

public class CtpjToken implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 4246411245203056895L;
	private String token;
	private GrupoUsuarioEnum cdGrpEnum;
	private Integer cdUsuro;
	private SolicitacaoCotacao solicitacaoCotacao;
	private boolean fake;
	private StringBuilder sbMemoria;

	public CtpjToken() {
		super();
	}

	public CtpjToken(String token, Integer cdGrp, Integer cdUsuro) {
		super();
		this.token = token;
		this.cdGrpEnum = GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(cdGrp);
		this.cdUsuro = cdUsuro;
	}

	public CtpjToken(String token, GrupoUsuarioEnum cdGrpEnum, Integer cdUsuro) {
		super();
		this.token = token;
		this.cdGrpEnum = cdGrpEnum;
		this.cdUsuro = cdUsuro;
	}

	public CtpjToken(String token,SolicitacaoCotacao solicitacaoCotacao) {
		super();
		this.token = token;
		this.solicitacaoCotacao = solicitacaoCotacao;
	}

	public CtpjToken(String token,SolicitacaoCotacao solicitacaoCotacao, boolean fake) {
		super();
		this.token = token;
		this.solicitacaoCotacao = solicitacaoCotacao;
		this.fake = fake;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public GrupoUsuarioEnum getCdGrpEnum() {
		return cdGrpEnum;
	}

	public void setCdGrpEnum(GrupoUsuarioEnum cdGrp) {
		this.cdGrpEnum = cdGrp;
	}

	public Integer getCdUsuro() {
		return cdUsuro;
	}

	public void setCdUsuro(Integer cdUsuro) {
		this.cdUsuro = cdUsuro;
	}

	public SolicitacaoCotacao getSolicitacaoCotacao() {
		return solicitacaoCotacao;
	}

	public void setSolicitacaoCotacao(SolicitacaoCotacao solicitacaoCotacao) {
		this.solicitacaoCotacao = solicitacaoCotacao;
	}

	public boolean isFake() {
		return fake;
	}


	public void setFake(boolean fake) {
		this.fake = fake;
	}

	public StringBuilder getSbMemoria() {
		return sbMemoria;
	}

	public void setSbMemoria(StringBuilder sbMemoria) {
		this.sbMemoria = sbMemoria;
	}

	
	
	




}
