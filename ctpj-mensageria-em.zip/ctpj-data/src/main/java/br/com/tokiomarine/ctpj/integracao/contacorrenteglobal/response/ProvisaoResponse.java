package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response;

import java.io.Serializable;
import java.util.List;

public class ProvisaoResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -6920324997328594873L;
	private Long codigoErro;
	private List<String> mensagens = null;
	private List<String> mensagensErro = null;
	private Boolean retorno;
	private String numeroProtocoloProvisao;

	public Long getCodigoErro() {
		return codigoErro;
	}

	public void setCodigoErro(Long codigoErro) {
		this.codigoErro = codigoErro;
	}

	public List<String> getMensagens() {
		return mensagens;
	}

	public void setMensagens(List<String> mensagens) {
		this.mensagens = mensagens;
	}

	public List<String> getMensagensErro() {
		return mensagensErro;
	}

	public void setMensagensErro(List<String> mensagensErro) {
		this.mensagensErro = mensagensErro;
	}

	public Boolean getRetorno() {
		return retorno;
	}

	public void setRetorno(Boolean retorno) {
		this.retorno = retorno;
	}

	public String getNumeroProtocoloProvisao() {
		return numeroProtocoloProvisao;
	}

	public void setNumeroProtocoloProvisao(String numeroProtocoloProvisao) {
		this.numeroProtocoloProvisao = numeroProtocoloProvisao;
	}
}
