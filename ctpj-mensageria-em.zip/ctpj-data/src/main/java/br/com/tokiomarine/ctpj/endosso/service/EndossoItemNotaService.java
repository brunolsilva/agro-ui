package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemNotaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemNotaService {
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0127
	 */
	public void validarNotas(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiNota = itemEndosso.getListItemNota() != null && !itemEndosso.getListItemNota().isEmpty();
		boolean itemApolicePossuiNota = itemApolice.getListItemNotaApolice() != null && !itemApolice.getListItemNotaApolice().isEmpty();
		
		//1 - percorre as notas do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiNota){			
			for(ItemNota itemEndossoNota : itemEndosso.getListItemNota()){
				boolean notaExiste = false;
				if(itemApolicePossuiNota){
					for(ItemNotaApolice itemApolNota : itemApolice.getListItemNotaApolice()){
						if(AssertUtils.compareNull(itemEndossoNota.getCodigoSequencia(),itemApolNota.getCodigoSequencia())){
							//valida descricao nota
							validacaoParametrosEndossoService.compararParametrosItemSemDePara(itemApolNota.getDescricaoNota(), itemEndossoNota.getDescricaoNota(), TipoMensagemEndossoEnum.ALT_NOTA, endosso, itemEndosso, alteracoesEndossoList, user);
							
							notaExiste = true;
							break;
						}						
					}
				}
				
				//se a nota não existir
				if(!notaExiste){ 
					logarInclusaoNota(itemEndossoNota,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as notas da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiNota){
			for(ItemNotaApolice itemApolNota : itemApolice.getListItemNotaApolice()){
				boolean notaExiste = false;
				if(itemEndossoPossuiNota){
					for(ItemNota itemEndossoNota : itemEndosso.getListItemNota()){
						if(AssertUtils.compareNull(itemEndossoNota.getCodigoSequencia(),itemApolNota.getCodigoSequencia())){
							notaExiste = true;
							break;
						}
					}
				}
				
				if(!notaExiste){
					logarExclusaoNota(itemApolNota,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoNota(ItemNota itemEndossoNota, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_NOTA, itemEndossoNota.getCodigoSequencia().toString(), user));
	}
	
		
	private void logarExclusaoNota(ItemNotaApolice itemApolNota, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_NOTA, itemApolNota.getCodigoSequencia().toString(), user));
	}
	
}
