package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.InspecaoEndosso;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoGrupoProduto;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoGrupoRubrica;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoGrupoValidade;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoInspecao;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Repository
public class InspecaoInfraRepository {

	private static final String RAMO = "ramo";
	private static final String DATA_INICIO_VIGENCIA = "dataInicioVigencia";
	private static final String DATA_TERMINO_VIGENCIA = "dataTerminoVigencia";
	private static final String GRUPO_RAMO = "grupoRamo";
	private static final String COBERTURA = "cobertura";
	private static final String CARACTERISTICA = "caracteristica";
	private static final String VALOR_CARACTERISTICA = "valorCaracteristica";
	private static final String TIPOALTERACAO = "tipoAlteracao";
	private static final String PRODUTO = "produto";
	private static final String TIPOSEGURO = "tipoSeguro";
	private static final String RUBRICA = "rubrica";
	private static final String CODIGO_GRUPO = "codigoGrupo";
	
	@Autowired
	private MongoTemplate mongoTemplate;

	public InspecaoEndosso findInspecaoEndosso(Integer grupoRamo, Integer ramo, Integer tipoAlteracao,Date dataCalculoCotacao) {
		return (InspecaoEndosso) mongoTemplate.findOne(
				query(where(GRUPO_RAMO).is(grupoRamo)
						.and(RAMO).is(ramo)
						.and(TIPOALTERACAO).is(tipoAlteracao)
						.and(DATA_INICIO_VIGENCIA).lte(dataCalculoCotacao)
						.orOperator(
								where(DATA_TERMINO_VIGENCIA).gte(dataCalculoCotacao),
								where(DATA_TERMINO_VIGENCIA).is(null))
						), InspecaoEndosso.class);
	}
	
	public ProdutoInspecao findProdutoInspecao(Integer produto, Integer grupoRamo, Integer ramo, TipoSeguroEnum tipoSeguro, Integer cobertura, Long codigoRubrica, Integer codigoClasseConstrucao, Integer codigoLocalizacao, BigDecimal valorImportanciaSegurada,Date dataInicioVigencia) {

		Criteria c1 =  new Criteria();
		c1.orOperator(where(COBERTURA).is(null).and(CARACTERISTICA).is(null).and(VALOR_CARACTERISTICA).is(null),
				where(COBERTURA).is(cobertura).and(CARACTERISTICA).is(null).and(VALOR_CARACTERISTICA).is(null),
				where(COBERTURA).is(cobertura).and(CARACTERISTICA).is(Caracteristicas.ATIVIDADE.codigo()).and(VALOR_CARACTERISTICA).is(codigoRubrica),
				where(COBERTURA).is(cobertura).and(CARACTERISTICA).is(Caracteristicas.CLASSE_CONSTRUCAO.codigo()).and(VALOR_CARACTERISTICA).is(codigoClasseConstrucao.longValue()),
				where(COBERTURA).is(cobertura).and(CARACTERISTICA).is(Caracteristicas.LOCALIZACAO.codigo()).and(VALOR_CARACTERISTICA).is(codigoLocalizacao.longValue()),
				where(COBERTURA).is(null).and(CARACTERISTICA).is(Caracteristicas.ATIVIDADE.codigo()).and(VALOR_CARACTERISTICA).is(codigoRubrica),
				where(COBERTURA).is(null).and(CARACTERISTICA).is(Caracteristicas.CLASSE_CONSTRUCAO.codigo()).and(VALOR_CARACTERISTICA).is(codigoClasseConstrucao.longValue()),
				where(COBERTURA).is(null).and(CARACTERISTICA).is(Caracteristicas.LOCALIZACAO.codigo()).and(VALOR_CARACTERISTICA).is(codigoLocalizacao.longValue()));

		Optional<ProdutoInspecao> produtoInspecao = mongoTemplate.find(
				query(where(PRODUTO).is(produto)
						.and(GRUPO_RAMO).is(grupoRamo)
						.and(RAMO).is(ramo)
						.and(TIPOSEGURO).is(tipoSeguro)
						.andOperator(c1)
						.and(DATA_INICIO_VIGENCIA).lte(dataInicioVigencia)
						.orOperator(
								where(DATA_TERMINO_VIGENCIA).gte(dataInicioVigencia),
								where(DATA_TERMINO_VIGENCIA).is(null))
						), ProdutoInspecao.class)
				.stream()
				.filter(ob->BigDecimalUtil.menorIgual(ob.getValorImportanciaSegurada(),valorImportanciaSegurada))
				.findFirst();
		return produtoInspecao.isPresent() ? produtoInspecao.get() : null;
		
	}

	public InspecaoGrupoRubrica findInspecaoGrupoRubrica (Integer produto,Long rubrica,Date dataInicioVigencia){
		Optional<InspecaoGrupoRubrica> inspecaoGrupoRubrica = mongoTemplate.find(
				query(where(PRODUTO).is(produto)
				.and(CARACTERISTICA).is(Caracteristicas.ATIVIDADE.codigo())
				.and(RUBRICA).is(rubrica)
				.and(DATA_INICIO_VIGENCIA).lte(dataInicioVigencia)
				.orOperator(
						where(DATA_TERMINO_VIGENCIA).gte(dataInicioVigencia),
						where(DATA_TERMINO_VIGENCIA).is(null))
				), InspecaoGrupoRubrica.class)
				.stream()
				.findFirst();
		
		return inspecaoGrupoRubrica.isPresent() ? inspecaoGrupoRubrica.get() : null;
	}

	public InspecaoGrupoProduto findInspecaoGrupoProduto(Integer produto,Date dataInicioVigencia){
		Optional<InspecaoGrupoProduto> inspecaoGrupoProduto = mongoTemplate.find(
			query(where(PRODUTO).is(produto)
			.and(DATA_INICIO_VIGENCIA).lte(dataInicioVigencia)
			.orOperator(
					where(DATA_TERMINO_VIGENCIA).gte(dataInicioVigencia),
					where(DATA_TERMINO_VIGENCIA).is(null))
			), InspecaoGrupoProduto.class)
			.stream()
			.findFirst();
		
		return inspecaoGrupoProduto.isPresent() ? inspecaoGrupoProduto.get() : null;
		
	}
	
	public InspecaoGrupoValidade findInspecaoGrupoValidade(Integer codigoGrupo){
		Optional<InspecaoGrupoValidade> inspecaoGrupoValidade = mongoTemplate.find(
				query(where(CODIGO_GRUPO).is(codigoGrupo))
				, InspecaoGrupoValidade.class)
			.stream()
			.findFirst();	
		return inspecaoGrupoValidade.isPresent() ? inspecaoGrupoValidade.get() : null;
	}
	
}
