package br.com.tokiomarine.ctpj.dto;

import java.math.BigDecimal;

public class CorretorFranqueadorView {

	private BigDecimal percFranqueado;
	private String codCorretorFranqueador;
	private String nomCorretorFranqueador;
	private BigDecimal percFranqueador;
	
	public BigDecimal getPercFranqueado() {
		return percFranqueado;
	}
	
	public void setPercFranqueado(BigDecimal percFranqueado) {
		this.percFranqueado = percFranqueado;
	}
	
	public String getCodCorretorFranqueador() {
		return codCorretorFranqueador;
	}
	
	public void setCodCorretorFranqueador(String codCorretorFranqueador) {
		this.codCorretorFranqueador = codCorretorFranqueador;
	}

	public String getNomCorretorFranqueador() {
		return nomCorretorFranqueador;
	}
	
	public void setNomCorretorFranqueador(String nomCorretorFranqueador) {
		this.nomCorretorFranqueador = nomCorretorFranqueador;
	}
	
	public BigDecimal getPercFranqueador() {
		return percFranqueador;
	}

	public void setPercFranqueador(BigDecimal percFranqueador) {
		this.percFranqueador = percFranqueador;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codCorretorFranqueador == null) ? 0 : codCorretorFranqueador.hashCode());
		result = prime * result + ((nomCorretorFranqueador == null) ? 0 : nomCorretorFranqueador.hashCode());
		result = prime * result + ((percFranqueado == null) ? 0 : percFranqueado.hashCode());
		result = prime * result + ((percFranqueador == null) ? 0 : percFranqueador.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CorretorFranqueadorView other = (CorretorFranqueadorView) obj;
		if (codCorretorFranqueador == null) {
			if (other.codCorretorFranqueador != null)
				return false;
		} else if (!codCorretorFranqueador.equals(other.codCorretorFranqueador))
			return false;
		if (nomCorretorFranqueador == null) {
			if (other.nomCorretorFranqueador != null)
				return false;
		} else if (!nomCorretorFranqueador.equals(other.nomCorretorFranqueador))
			return false;
		if (percFranqueado == null) {
			if (other.percFranqueado != null)
				return false;
		} else if (!percFranqueado.equals(other.percFranqueado))
			return false;
		if (percFranqueador == null) {
			if (other.percFranqueador != null)
				return false;
		} else if (!percFranqueador.equals(other.percFranqueador))
			return false;
		return true;
	}

}
