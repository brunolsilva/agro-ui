package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.util.DateUtil;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BloqueioAlcadaView implements Serializable {

	private static final long serialVersionUID = 9129102205560840858L;
	
	private BigInteger sequencialCotacaoProposta;
	private BigInteger sequencialBloqueioAlcada;
	private String descricaoRestricao;
	private Integer codigoNivelAutorizacao;
	private SimNaoEnum idAutorizacao;
	private Date dataAutorizacao;
	private Integer codigoFuncionarioAutorizacao;
	private String nomeFuncionarioAutorizacao;
	private String observacaoParecerLiberacaoBloqueio;
	private String identificadorDocstorebloqueio;
	private String descricaoRestricaoCorretor;
	private SimNaoEnum idApresentaRestricao;
	
	public BloqueioAlcadaView() {
		/**
		 * Construtor vazio
		 */
	}

	public BloqueioAlcadaView(String descricaoRestricao, Integer codigoNivelAutorizacao, SimNaoEnum idAutorizacao,
			Date dataAutorizacao, Integer codigoFuncionarioAutorizacao) {
		super();
		this.descricaoRestricao = descricaoRestricao;
		this.codigoNivelAutorizacao = codigoNivelAutorizacao;
		this.idAutorizacao = idAutorizacao;
		this.dataAutorizacao = dataAutorizacao;
		this.codigoFuncionarioAutorizacao = codigoFuncionarioAutorizacao;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}
	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}
	public BigInteger getSequencialBloqueioAlcada() {
		return sequencialBloqueioAlcada;
	}
	public void setSequencialBloqueioAlcada(BigInteger sequencialBloqueioAlcada) {
		this.sequencialBloqueioAlcada = sequencialBloqueioAlcada;
	}
	public String getDescricaoRestricao() {
		return descricaoRestricao;
	}
	public void setDescricaoRestricao(String descricaoRestricao) {
		this.descricaoRestricao = descricaoRestricao;
	}
	public Integer getCodigoNivelAutorizacao() {
		return codigoNivelAutorizacao;
	}
	public void setCodigoNivelAutorizacao(Integer codigoNivelAutorizacao) {
		this.codigoNivelAutorizacao = codigoNivelAutorizacao;
	}
	public SimNaoEnum getIdAutorizacao() {
		return idAutorizacao;
	}
	public void setIdAutorizacao(SimNaoEnum idAutorizacao) {
		this.idAutorizacao = idAutorizacao;
	}
	public Date getDataAutorizacao() {
		return dataAutorizacao;
	}
	public void setDataAutorizacao(Date dataAutorizacao) {
		this.dataAutorizacao = dataAutorizacao;
	}
	public Integer getCodigoFuncionarioAutorizacao() {
		return codigoFuncionarioAutorizacao;
	}
	public void setCodigoFuncionarioAutorizacao(Integer codigoFuncionarioAutorizacao) {
		this.codigoFuncionarioAutorizacao = codigoFuncionarioAutorizacao;
	}
	public String getNomeFuncionarioAutorizacao() {
		return nomeFuncionarioAutorizacao;
	}
	public void setNomeFuncionarioAutorizacao(String nomeFuncionarioAutorizacao) {
		this.nomeFuncionarioAutorizacao = nomeFuncionarioAutorizacao;
	}
	public String getDataCompletaFormatada(){
		return DateUtil.formataSemHora(dataAutorizacao);
	}
	
	public String getObservacaoParecerLiberacaoBloqueio() {
		return observacaoParecerLiberacaoBloqueio;
	}
	
	public void setObservacaoParecerLiberacaoBloqueio(String observacaoParecerLiberacaoBloqueio) {
		this.observacaoParecerLiberacaoBloqueio = observacaoParecerLiberacaoBloqueio;
	}
	
	public String getIdentificadorDocstorebloqueio() {
		return identificadorDocstorebloqueio;
	}
	
	public void setIdentificadorDocstorebloqueio(String identificadorDocstorebloqueio) {
		this.identificadorDocstorebloqueio = identificadorDocstorebloqueio;
	}

	public String getDescricaoRestricaoCorretor() {
		return descricaoRestricaoCorretor;
	}

	public void setDescricaoRestricaoCorretor(String descricaoRestricaoCorretor) {
		this.descricaoRestricaoCorretor = descricaoRestricaoCorretor;
	}

	public SimNaoEnum getIdApresentaRestricao() {
		return idApresentaRestricao;
	}

	public void setIdApresentaRestricao(SimNaoEnum idApresentaRestricao) {
		this.idApresentaRestricao = idApresentaRestricao;
	}

	@Override
	public String toString() {
		return "BloqueioAlcadaView [sequencialCotacaoProposta=" + sequencialCotacaoProposta
				+ ", sequencialBloqueioAlcada=" + sequencialBloqueioAlcada + ", descricaoRestricao="
				+ descricaoRestricao + ", codigoNivelAutorizacao=" + codigoNivelAutorizacao + ", idAutorizacao="
				+ idAutorizacao + ", dataAutorizacao=" + dataAutorizacao + ", codigoFuncionarioAutorizacao="
				+ codigoFuncionarioAutorizacao + ", nomeFuncionarioAutorizacao=" + nomeFuncionarioAutorizacao
				+ ", observacaoParecerLiberacaoBloqueio=" + observacaoParecerLiberacaoBloqueio
				+ ", identificadorDocstorebloqueio=" + identificadorDocstorebloqueio + ", descricaoRestricaoCorretor="
				+ descricaoRestricaoCorretor + ", idApresentaRestricao=" + idApresentaRestricao + "]";
	}	
}