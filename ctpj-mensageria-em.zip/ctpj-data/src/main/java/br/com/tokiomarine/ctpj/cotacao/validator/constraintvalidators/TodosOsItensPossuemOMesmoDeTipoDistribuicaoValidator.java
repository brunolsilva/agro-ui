package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.dto.ListOfItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.TodosOsItensPossuemOMesmoTipoDeDistribuicao;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class TodosOsItensPossuemOMesmoDeTipoDistribuicaoValidator implements ConstraintValidator<TodosOsItensPossuemOMesmoTipoDeDistribuicao, ListOfItemBeneficiarioView> {

	
	@Override
	public void initialize(TodosOsItensPossuemOMesmoTipoDeDistribuicao constraintAnnotation) {
		
	}

	@Override
	public boolean isValid(ListOfItemBeneficiarioView listOfItemView, ConstraintValidatorContext constraintValidatorContext) {
		if(listOfItemView.isEmpty() || listOfItemView.size() == 1)
			return true;
		
		constraintValidatorContext.disableDefaultConstraintViolation();	
		return validaSeTodosPossuemOMesmoTipoDeDistruicao(listOfItemView, constraintValidatorContext);
	}
	
	private boolean validaSeTodosPossuemOMesmoTipoDeDistruicao(ListOfItemBeneficiarioView listOfItemView, ConstraintValidatorContext constraintValidatorContext){
		Collection<List<ItemBeneficiarioView>> itensPorItemCotacao = listOfItemView.stream().collect(Collectors.groupingBy(ItemBeneficiarioView::getNumeroItemCotacao)).values();
		boolean ehValido = true;
		
		for (List<ItemBeneficiarioView> list : itensPorItemCotacao) {
			if(!todosPossuemMesmoTipoDistribuicao(list, constraintValidatorContext))
				ehValido = false;
		}		
		
		return ehValido;
	}
	
	private boolean todosPossuemMesmoTipoDistribuicao(List<ItemBeneficiarioView> listItem, ConstraintValidatorContext constraintValidatorContext) {
		constraintValidatorContext.disableDefaultConstraintViolation();	
		
		boolean percentualDistribuicao = ehPercentualDistribuicao(listItem.get(0));
		
		for (ItemBeneficiarioView itemView : listItem) {
			if(ehPercentualDistribuicao(itemView) != percentualDistribuicao){
				constraintValidatorContext.buildConstraintViolationWithTemplate("É obrigatório que todos os beneficiários do item cotação " + itemView.getNumeroItemCotacao() + " possuam o mesmo tipo de distribuição (Percentual ou Valor), sendo que para Percentual de Distribuição, este deve ser preenchido").addConstraintViolation();
				return false;
			}
		}
		
		
		return true;
	}

	private boolean ehPercentualDistribuicao(ItemBeneficiarioView itemView){
		return itemView.getPercentualDistribuicao() != null;
	}

}
