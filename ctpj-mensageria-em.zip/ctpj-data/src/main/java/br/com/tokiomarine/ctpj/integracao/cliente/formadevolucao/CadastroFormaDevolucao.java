package br.com.tokiomarine.ctpj.integracao.cliente.formadevolucao;

import br.com.tokiomarine.cliente.dto.FormaDevolucaoCliente;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.integracao.cliente.request.FormaDevolucaoRequest;

public interface CadastroFormaDevolucao {
	FormaDevolucaoRequest bindToRequest(Cotacao cotacao,FormaDevolucaoCliente formaDevolucao,PropostaView propostaView);
	
	Boolean dadosValidos(Cotacao cotacao);
}