package br.com.tokiomarine.ctpj.cotacao.relatorios.memoriacalculo;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 * 
 * Gerador de RelatórioMemoriaCalculo em XLS
 *
 */

@Component
public class GeradorRelatorioMemoriaCalculoXLS extends GeradorRelatorioMemoriaCalculoPlanilha {

	@Override
	protected Workbook getWorkbook() {
		return new HSSFWorkbook();
	}

}
