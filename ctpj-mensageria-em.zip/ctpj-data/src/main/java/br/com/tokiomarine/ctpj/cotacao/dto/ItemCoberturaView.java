package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemCoberturaView implements Serializable {

	private static final long serialVersionUID = 440128849756819835L;

	private BigInteger sequencialItemCobertura;
	private Integer codigoCobertura;
	private String descricaoCobertura;
	private Boolean idCoberturaAvulsa = Boolean.FALSE;
	private Integer codigoRamoCobertura;
	private String valorImportanciaSegurada;
	private String valorRiscoBem;
	private String valorSublimite;
	private String valorSublimiteOriginal;
	private FormaFranquiaEnum idFormaFranquia;
	private Integer idTextoFranquia;
	private Boolean idLMR;
	private Integer codigoGrupoRamo;
	private String valorISMoedaEstrangeira;
	private String valorSublimiteMoedaEstrangeira;
	private String valorSublimiteOriginalMoedaEstrangeira;
	private Integer idTipoCobertura;
	private String descricaoComplementoCobertura;
	private Boolean idExclusaEndosso = Boolean.FALSE;
	private String percentualTaxaCalculoPremio;
	
	private Boolean idLucrosCessantes = Boolean.FALSE;
	private Boolean idDanosMateriais = Boolean.FALSE;

	private Integer codigoPeriodoIndenitario;
	private BigDecimal numeroMultiploFranquia;
	private BigDecimal numeroMultiploPrejuizo;
	private Integer numeroVagasGaragem;
	private boolean exigeVagasGaragem;
	private boolean exigeValorRisco;
	private boolean exigeIS;
	private Integer coberturaPrincipal;
	
	private String descricaoCoberturaAjustada;

	private List<Integer> periodosIndenitarios  = new ArrayList<>();
	private List<BigDecimal> multiplosPrejuizo = new ArrayList<>();
	private List<BigDecimal> multiplosFranquia = new ArrayList<>();
	private List<CoberturaValor> valoresCobertura = new ArrayList<>();

	public BigInteger getSequencialItemCobertura() {
		return sequencialItemCobertura;
	}

	public void setSequencialItemCobertura(BigInteger sequencialItemCobertura) {
		this.sequencialItemCobertura = sequencialItemCobertura;
	}

	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}

	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}

	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}

	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}

	public Boolean getIdCoberturaAvulsa() {
		return idCoberturaAvulsa;
	}

	public void setIdCoberturaAvulsa(Boolean idCoberturaAvulsa) {
		this.idCoberturaAvulsa = idCoberturaAvulsa;
	}

	public Integer getCodigoRamoCobertura() {
		return codigoRamoCobertura;
	}

	public void setCodigoRamoCobertura(Integer codigoRamoCobertura) {
		this.codigoRamoCobertura = codigoRamoCobertura;
	}

	public String getValorImportanciaSegurada() {
		return valorImportanciaSegurada;
	}

	public void setValorImportanciaSegurada(String valorImportanciaSegurada) {
		this.valorImportanciaSegurada = valorImportanciaSegurada;
	}

	public String getValorSublimite() {
		return valorSublimite;
	}

	public void setValorSublimite(String valorSublimite) {
		this.valorSublimite = valorSublimite;
	}

	public String getValorSublimiteOriginal() {
		return valorSublimiteOriginal;
	}

	public void setValorSublimiteOriginal(String valorSublimiteOriginal) {
		this.valorSublimiteOriginal = valorSublimiteOriginal;
	}

	public FormaFranquiaEnum getIdFormaFranquia() {
		return idFormaFranquia;
	}

	public void setIdFormaFranquia(FormaFranquiaEnum idFormaFranquia) {
		this.idFormaFranquia = idFormaFranquia;
	}

	public Integer getIdTextoFranquia() {
		return idTextoFranquia;
	}

	public void setIdTextoFranquia(Integer idTextoFranquia) {
		this.idTextoFranquia = idTextoFranquia;
	}

	public Boolean getIdLMR() {
		return idLMR;
	}

	public void setIdLMR(Boolean idLMR) {
		this.idLMR = idLMR;
	}

	public Integer getCodigoGrupoRamo() {
		return codigoGrupoRamo;
	}

	public void setCodigoGrupoRamo(Integer codigoGrupoRamo) {
		this.codigoGrupoRamo = codigoGrupoRamo;
	}

	public String getValorISMoedaEstrangeira() {
		return valorISMoedaEstrangeira;
	}

	public void setValorISMoedaEstrangeira(String valorISMoedaEstrangeira) {
		this.valorISMoedaEstrangeira = valorISMoedaEstrangeira;
	}

	public String getValorSublimiteMoedaEstrangeira() {
		return valorSublimiteMoedaEstrangeira;
	}

	public void setValorSublimiteMoedaEstrangeira(String valorSublimiteMoedaEstrangeira) {
		this.valorSublimiteMoedaEstrangeira = valorSublimiteMoedaEstrangeira;
	}

	public String getValorSublimiteOriginalMoedaEstrangeira() {
		return valorSublimiteOriginalMoedaEstrangeira;
	}

	public void setValorSublimiteOriginalMoedaEstrangeira(String valorSublimiteOriginalMoedaEstrangeira) {
		this.valorSublimiteOriginalMoedaEstrangeira = valorSublimiteOriginalMoedaEstrangeira;
	}

	public Integer getIdTipoCobertura() {
		return idTipoCobertura;
	}

	public void setIdTipoCobertura(Integer idTipoCobertura) {
		this.idTipoCobertura = idTipoCobertura;
	}
	
	public String getPercentualTaxaCalculoPremio() {
		return percentualTaxaCalculoPremio;
	}
	
	public void setPercentualTaxaCalculoPremio(String percentualTaxaCalculoPremio) {
		this.percentualTaxaCalculoPremio = percentualTaxaCalculoPremio;
	}

	public Boolean getIdLucrosCessantes() {
		return idLucrosCessantes;
	}

	public void setIdLucrosCessantes(Boolean idLucrosCessantes) {
		this.idLucrosCessantes = idLucrosCessantes;
	}

	public Boolean getIdDanosMateriais() {
		return idDanosMateriais;
	}

	public void setIdDanosMateriais(Boolean idDanosMateriais) {
		this.idDanosMateriais = idDanosMateriais;
	}

	public Integer getCodigoPeriodoIndenitario() {
		return codigoPeriodoIndenitario;
	}

	public void setCodigoPeriodoIndenitario(Integer codigoPeriodoIndenitario) {
		this.codigoPeriodoIndenitario = codigoPeriodoIndenitario;
	}

	public BigDecimal getNumeroMultiploFranquia() {
		return numeroMultiploFranquia;
	}

	public void setNumeroMultiploFranquia(BigDecimal numeroMultiploFranquia) {
		this.numeroMultiploFranquia = numeroMultiploFranquia;
	}

	public BigDecimal getNumeroMultiploPrejuizo() {
		return numeroMultiploPrejuizo;
	}

	public void setNumeroMultiploPrejuizo(BigDecimal numeroMultiploPrejuizo) {
		this.numeroMultiploPrejuizo = numeroMultiploPrejuizo;
	}

	public boolean isExigeValorRisco() {
		return exigeValorRisco;
	}

	public void setExigeValorRisco(boolean exigeValorRisco) {
		this.exigeValorRisco = exigeValorRisco;
	}

	public String getValorRiscoBem() {
		return valorRiscoBem;
	}

	public void setValorRiscoBem(String valorRiscoBem) {
		this.valorRiscoBem = valorRiscoBem;
	}

	public String getDescricaoComplementoCobertura() {
		return descricaoComplementoCobertura;
	}

	public void setDescricaoComplementoCobertura(String descricaoComplementoCobertura) {
		this.descricaoComplementoCobertura = descricaoComplementoCobertura;
	}

	public Boolean getIdExclusaEndosso() {
		return idExclusaEndosso;
	}

	public void setIdExclusaEndosso(Boolean idExclusaEndosso) {
		this.idExclusaEndosso = idExclusaEndosso;
	}

	public List<CoberturaValor> getValoresCobertura() {
		return valoresCobertura;
	}

	public void setValoresCobertura(List<CoberturaValor> valoresCobertura) {
		this.valoresCobertura = valoresCobertura;
	}

	public List<Integer> getPeriodosIndenitarios() {
		return periodosIndenitarios;
	}

	public void setPeriodosIndenitarios(List<Integer> periodosIndenitarios) {
		this.periodosIndenitarios = periodosIndenitarios;
	}

	public List<BigDecimal> getMultiplosPrejuizo() {
		return multiplosPrejuizo;
	}

	public void setMultiplosPrejuizo(List<BigDecimal> multiplosPrejuizo) {
		this.multiplosPrejuizo = multiplosPrejuizo;
	}

	public List<BigDecimal> getMultiplosFranquia() {
		return multiplosFranquia;
	}

	public void setMultiplosFranquia(List<BigDecimal> multiplosFranquia) {
		this.multiplosFranquia = multiplosFranquia;
	}

	public Integer getNumeroVagasGaragem() {
		return numeroVagasGaragem;
	}

	public void setNumeroVagasGaragem(Integer numeroVagasGaragem) {
		this.numeroVagasGaragem = numeroVagasGaragem;
	}

	public boolean isExigeVagasGaragem() {
		return exigeVagasGaragem;
	}

	public void setExigeVagasGaragem(boolean exigeVagasGaragem) {
		this.exigeVagasGaragem = exigeVagasGaragem;
	}

	public boolean isExigeIS() {
		return exigeIS;
	}

	public void setExigeIS(boolean exigeIS) {
		this.exigeIS = exigeIS;
	}

	public Integer getCoberturaPrincipal() {
		return coberturaPrincipal;
	}

	public void setCoberturaPrincipal(Integer coberturaPrincipal) {
		this.coberturaPrincipal = coberturaPrincipal;
	}

	public String getDescricaoCoberturaAjustada() {
		return descricaoCoberturaAjustada;
	}

	public void setDescricaoCoberturaAjustada(String descricaoCoberturaAjustada) {
		this.descricaoCoberturaAjustada = descricaoCoberturaAjustada;
	}
}