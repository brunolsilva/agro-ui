package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import br.com.tokiomarine.ctpj.type.ProdutosEnum;

public class ValidationRegistry {
	
	private ValidationRegistry() { }
	
	private static Map<Integer, ProdutoValidator> validators = new ConcurrentHashMap<>();

	static {
		validators.put(ProdutosEnum.EMPRESARIAL_LMI.codigo(), new EmpresarialLmiValidator());
		validators.put(ProdutosEnum.RN_LOCAL_A_LOCAL.codigo(), new RnLocalValidator());
		validators.put(ProdutosEnum.RISCOS_OPERACIONAIS.codigo(), new RnLmiValidator());
		validators.put(ProdutosEnum.EMPRESARIAL_LOCAL_A_LOCAL.codigo(), new EmpresarialLocalValidator());
		validators.put(ProdutosEnum.RN_LOCAL_A_LOCAL_EMPRESARIAL.codigo(), new RNLocal1860Validator());
		validators.put(ProdutosEnum.RN_LMI_EMPRESARIAL.codigo(), new RNLMIEmpresarialValidator());
		validators.put(ProdutosEnum.EMPRESARIAL_LMI_NOVO.codigo(), new EmpresarialLmiNovoValidator());
	}
	
	public static Map<Integer, ProdutoValidator> getValidators() {
		return validators;
	}
}
