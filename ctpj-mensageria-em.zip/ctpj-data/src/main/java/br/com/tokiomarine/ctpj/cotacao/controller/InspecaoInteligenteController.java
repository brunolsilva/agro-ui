package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.Date;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.cotacao.service.InspecaoInteligenteService;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.InspecaoInteligente;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.response.AtualizaFluxoResponse;

@Controller
public class InspecaoInteligenteController {
	
	private static Logger logger = LogManager.getLogger(GradePldController.class);
	
	@Autowired
	private InspecaoInteligenteService inspecaoInteligenteService;

	@GetMapping(value = "/rest/inspecaoInteligente/solicitaDadosGeraisItemInspecao")
	public ResponseEntity<Object> buscarDadosInspecaoInteligente(
			@RequestParam(value = "numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam(value = "numeroItemCotacao") BigInteger numeroItemCotacao){
		ResultadoREST<InspecaoInteligente> resultado = new ResultadoREST<>();
		try {
			resultado.setRetornoObj(inspecaoInteligenteService.buscarDadosInspecaoInteligente(numeroCotacaoProposta,numeroItemCotacao));
			resultado.setCodigo(0);
			resultado.setSuccess(true);
			resultado.setMensagem("Sucesso");
			return new ResponseEntity<Object>(resultado,HttpStatus.OK);
		} catch (Exception e) {
			resultado.setCodigo(99);
			resultado.setSuccess(false);
			resultado.setMensagem(ExceptionUtils.getFullStackTrace(e));
			return new ResponseEntity<Object>(resultado,HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/rest/inspecaoInteligente/atualizaFluxo")
	public @ResponseBody
	ResponseEntity<Object> geraPedidoInspecao(
			@RequestParam(value = "numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam(value = "numeroItemCotacao") BigInteger numeroItemCotacao,
			@RequestParam(value = "versaoCotacaoProposta") Integer versaoCotacaoProposta,
			@RequestParam(value = "idParecerInspecao") Integer idParecerInspecao,
			@RequestParam(value = "idStatusFluxoInspecao") Integer idStatusFluxoInspecao) {
		AtualizaFluxoResponse resultado = new AtualizaFluxoResponse();
		try {
			logger.info("Chamando o REST SERVICE de Inspeção no Controller");
			logger.info("Parametros de entrada antes do tratamento");
			logger.info("cdPedidoCotacao: "+numeroCotacaoProposta);
			logger.info("cdItemPedidoCotacao: "+numeroItemCotacao);
			logger.info("cdVersaoPedidoCotacao: "+versaoCotacaoProposta);
			logger.info("cdParecerInspecao: "+idParecerInspecao);
			logger.info("cdStatusFluxoInspecao: "+idStatusFluxoInspecao);
			inspecaoInteligenteService.requestValidatorAtualizarFluxoInspecao(numeroCotacaoProposta,numeroItemCotacao,versaoCotacaoProposta,idParecerInspecao,idStatusFluxoInspecao);
			inspecaoInteligenteService.processarAtualizacaoFluxoInspecaoInteligente(numeroCotacaoProposta,numeroItemCotacao,versaoCotacaoProposta,idParecerInspecao,idStatusFluxoInspecao);
			resultado.setCodigoRetorno(0);
			resultado.setDescricaoMensagem("Sucesso");
			resultado.setTimestamp(new Date());
			return new ResponseEntity<Object>(resultado,HttpStatus.OK);
		} catch (ServiceException se) {
			resultado.setCodigoRetorno(99);
			resultado.setDescricaoMensagem(ExceptionUtils.getFullStackTrace(se));
			resultado.setTimestamp(new Date());
			return new ResponseEntity<Object>(resultado,HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			resultado.setCodigoRetorno(99);
			resultado.setDescricaoMensagem(ExceptionUtils.getFullStackTrace(e));
			resultado.setTimestamp(new Date());
			return new ResponseEntity<Object>(resultado,HttpStatus.BAD_REQUEST);
		}
	}	

}
