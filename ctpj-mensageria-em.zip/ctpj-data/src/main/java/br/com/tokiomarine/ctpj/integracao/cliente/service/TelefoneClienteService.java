package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import br.com.tokiomarine.cliente.dto.persistencia.TelefoneCliente;
import br.com.tokiomarine.ctpj.type.ServicosClienteEnum;
import br.com.tokiomarine.ctpj.type.TelefoneClienteEnum;

@Service
public class TelefoneClienteService extends BaseClienteService {
	public List<TelefoneCliente> consultarTelefoneCliente(Object[] parametros) {

		TelefoneCliente[] telefonesClienteResponse = null;
		try {

			URI uri = endpointBuilderService.obterUri(getParametroGeral(),
					ServicosClienteEnum.PESQUISAR_LISTA_TELEFONES_POR_CODIGO, parametros);

			telefonesClienteResponse = restTemplate.getForObject(uri, TelefoneCliente[].class);
		} catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Consultar Telefones Cliente ", e);
		}
		return Arrays.asList(telefonesClienteResponse);
	}

	public TelefoneCliente carregarTelefonePorTipo(List<TelefoneCliente> telefonesCliente, TelefoneClienteEnum tipo) {

		if (telefonesCliente == null || telefonesCliente.isEmpty()) {
			return null;
		}

		return telefonesCliente.stream().filter(t -> t.getTpTelef().equals(tipo.value())).findFirst().orElse(null);

	}
}
