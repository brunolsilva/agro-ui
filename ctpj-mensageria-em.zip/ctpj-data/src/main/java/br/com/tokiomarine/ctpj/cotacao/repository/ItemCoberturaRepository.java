package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoAgravacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class ItemCoberturaRepository extends BaseDAO {

	private static final String FIND_ITEM_COBERTURA_BY_ITEM_COTACAO = "select cob " + "from ItemCotacao ic " + "join ic.listItemCobertura cob " + "where  ic.sequencialItemCotacao = :sequencialItemCotacao ";

	private static final String FIND_ITEM_COBERTURA_BY_ITENS_COTACAO = "select  cob " + "from ItemCotacao ic " + "join ic.listItemCobertura cob " + "where  ic.sequencialItemCotacao in (:seqsItemCotacao)";

	private static final String FIND_ITEM_COBERTURA_BY_ITEM_COTACAO_AND_COD_COBERTURA = "select icob " + "from ItemCobertura icob " + "where icob.itemCotacao.sequencialItemCotacao = :seqItemCotacao and codigoCobertura =:codCobertura";

	@SuppressWarnings("unchecked")
	public List<ItemCobertura> findItemCoberturaByItemCotacao(BigInteger sequencialItemCotacao) {
		Query query = getCurrentSession().createQuery(FIND_ITEM_COBERTURA_BY_ITEM_COTACAO);
		query.setParameter("sequencialItemCotacao",sequencialItemCotacao);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	public List<ItemCobertura> findItemCoberturaByItemsCotacao(List<ItemCotacao> ics) {
		Query query = getCurrentSession().createQuery(FIND_ITEM_COBERTURA_BY_ITENS_COTACAO);
		query.setParameterList("seqsItemCotacao",ics.stream().map(ic -> ic.getSequencialItemCotacao()).collect(Collectors.toList()));

		return query.list();
	}

	public List<ItemCobertura> findItemCoberturaByItemCotacao(ItemCotacao itemCotacao) {
		return findItemCoberturaByItemCotacao(itemCotacao.getSequencialItemCotacao());
	}

	public ItemCobertura findItemCoberturaByItemCotacaoAndCodCobertura(BigInteger seqItemCotacao,Integer codCobertura) {
		ItemCobertura itemCobertura = (ItemCobertura) getCurrentSession().createQuery(FIND_ITEM_COBERTURA_BY_ITEM_COTACAO_AND_COD_COBERTURA).setParameter("seqItemCotacao",seqItemCotacao).setParameter("codCobertura",codCobertura).setMaxResults(1).uniqueResult();

		return itemCobertura;
	}

	@SuppressWarnings("unchecked")
	public List<ItemCobertura> findItensCoberturaByItensCotacaoAndCodCobertura(Collection<BigInteger> itensCotacao,Integer codCobertura) {
		String hql = new StringBuilder()
				.append("select icob ")
				.append("from ItemCobertura icob ")
				.append("where icob.itemCotacao.sequencialItemCotacao in (:itensCotacao) and codigoCobertura = :codCobertura ")
				.toString();		
		
		return getCurrentSession()
				.createQuery(hql)
				.setParameterList("itensCotacao", itensCotacao)
				.setParameter("codCobertura",codCobertura)
				.list();
	}	
	
	@SuppressWarnings("unchecked")
	public List<ItemCobertura> findItensCoberturaByCotacaoAndCodCobertura(BigInteger seqCotacao,Integer codCobertura) {
		String hql = new StringBuilder()
				.append("select icob ")
				.append("from ItemCobertura icob ")
				.append("where icob.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao and codigoCobertura =:codCobertura")
				.toString();		
		
		List<ItemCobertura> itens = getCurrentSession()
				.createQuery(hql)
				.setParameter("seqCotacao",seqCotacao)
				.setParameter("codCobertura",codCobertura)
				.list();

		return itens;
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> findGrupoRamoRamoEmissaoCobertura(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select distinct ic.codigoGrupoRamoEmissao, ic.codigoRamoCoberturaEmissao, ic.codigoCobertura ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemCobertura ic ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}

	@SuppressWarnings("unchecked")
	public Object[] findValorRiscoBySeqItemAndIdTipoCobertura(BigInteger sequencialItemCotacao,Integer idTipoCobertura) {
		StringBuilder sb = new StringBuilder();

		if (idTipoCobertura == 1) {
			sb.append("select sum(i.valorRiscoBem), sum(i.valorRiscoBemMoedaEstrangeira)");
		} else {
			sb.append("select sum(ic.valorRiscoBem), sum(ic.valorRiscoBemMoedaEstrangeira) ");
		}

		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemCobertura ic ");
		sb.append("where  i.sequencialItemCotacao = :sequencialItemCotacao ");
		sb.append("and    ic.idTipoCobertura = :idTipoCobertura");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialItemCotacao",sequencialItemCotacao);
		query.setParameter("idTipoCobertura",idTipoCobertura);

		return (Object[]) query.uniqueResult();
	}

	public List<Object[]> findSubLimiteByCodCobertura(BigInteger sequencialCotacaoProposta,Integer codigoCobertura) {
		StringBuilder sb = new StringBuilder();
		sb.append("select i.numeroItem,ic.valorSublimite,ic.valorSublimiteMoedaEstrangeira ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemCobertura ic ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		sb.append("and    ic.codigoCobertura = :codigoCobertura ");
		sb.append("and    coalesce(ic.valorSublimite, 0) != ic.valorSublimiteOriginal ");
		sb.append("order by i.numeroItem ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		query.setParameter("codigoCobertura",codigoCobertura);
		return (List<Object[]>) query.list();
	}

	public List<Object[]> findItensNCompreendidosBySeqItemCodCobertura(BigInteger sequencialItemCotacao,Integer codigoCobertura) {
		StringBuilder sb = new StringBuilder();
		sb.append("select i.numeroItem");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemCobertura ic ");
		sb.append("where  i.sequencialItemCotacao = :sequencialItemCotacao ");
		sb.append("and    ic.codigoCobertura = :codigoCobertura ");
		sb.append("minus ");
		sb.append("select i.numeroItem");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemCobertura ic ");
		sb.append("where  i.sequencialItemCotacao = :sequencialItemCotacao ");
		sb.append("and    ic.codigoCobertura = :codigoCobertura ");

		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialItemCotacao",sequencialItemCotacao);
		query.setParameter("codigoCobertura",codigoCobertura);
		return (List<Object[]>) query.list();
	}

	public List<ItemCobertura> getCoberturasById(List<BigInteger> ids) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from   ItemCobertura cob ");
		hql.append(" where cob.sequencialItemCobertura in (:ids) ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameterList("ids",ids);

		return (List<ItemCobertura>) query.list();
	}

	public void updateList(List<ItemCobertura> listaItemCobertura) {
		for (ItemCobertura itemCobertura : listaItemCobertura) {
			getCurrentSession().update(itemCobertura);
		}
	}

	public ItemCobertura find(BigInteger id) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from   ItemCobertura cob ");
		hql.append(" where cob.sequencialItemCobertura = :id ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("id",id);

		return (ItemCobertura) query.uniqueResult();
	}

	public void save(ItemCobertura itemCobertura) {
		Cotacao cotacao = itemCobertura.getItemCotacao().getCotacao();
		cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
		getCurrentSession().save(itemCobertura);
		getCurrentSession().save(cotacao);
	}

	public ItemCobertura findCoberturaItemUm(BigInteger cotacao,Integer codigoCobertura) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from	ItemCobertura cob ");
		hql.append(" where	cob.codigoCobertura = :codigoCobertura ");
		hql.append(" and	cob.itemCotacao.cotacao.sequencialCotacaoProposta = :cotacao ");
		hql.append(" and	cob.itemCotacao.numeroItem = :numeroItem ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("codigoCobertura",codigoCobertura);
		query.setParameter("cotacao",cotacao);
		query.setParameter("numeroItem",BigInteger.ONE);

		return (ItemCobertura) query.uniqueResult();
	}

	public List<ItemCobertura> findCoberturasByItem(ItemCotacao itemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from	ItemCobertura cob ");
		hql.append(" where	cob.itemCotacao = :itemCotacao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("itemCotacao",itemCotacao);

		return (List<ItemCobertura>) query.list();
	}

	public List<ItemCobertura> findCoberturasBasicasItemUm(BigInteger cotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from	ItemCobertura cob ");
		hql.append(" where	cob.itemCotacao.cotacao.sequencialCotacaoProposta = :cotacao ");
		hql.append(" and	cob.itemCotacao.numeroItem = :numeroItem ");
		hql.append(" and	cob.idTipoCobertura = 1 ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao",cotacao);
		query.setParameter("numeroItem",BigInteger.ONE);

		return (List<ItemCobertura>) query.list();
	}

	public List<ItemCobertura> findCoberturasExigeOficio(CotacaoView cotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from   ItemCobertura cob ");
		hql.append(" where	cob.numeroCotacaoProposta	=	:numeroCotacaoProposta ");
		hql.append(" and 	cob.versaoCotacaoProposta	=	:versaoCotacaoProposta ");
		hql.append(" and	cob.idExigeOficio			=	:idExigeOficio ");
		hql.append(" and	cob.idExclusaEndosso		=	:idExclusaEndosso ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",cotacao.getNumeroCotacaoProposta());
		query.setParameter("versaoCotacaoProposta",cotacao.getVersaoCotacaoProposta());
		query.setParameter("idExigeOficio",SimNaoEnum.SIM);
		query.setParameter("idExclusaEndosso",SimNaoEnum.NAO);

		return (List<ItemCobertura>) query.list();
	}

	@LogPerformance
	public Optional<ItemCobertura> findDadosRessegurador(BigInteger cotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from   ItemCobertura 	cob, ");
		hql.append(" 		ItemCotacao  	item ");
		hql.append(" where  item.cotacao.sequencialCotacaoProposta = :cotacao ");
		hql.append(" and    cob.itemCotacao.sequencialItemCotacao 	= 	item.sequencialItemCotacao");
		hql.append(" and	cob.idExigeOficio			=	:idExigeOficio ");
		hql.append(" and	cob.idExclusaEndosso		=	:idExclusaEndosso ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao",cotacao);
		query.setParameter("idExigeOficio",SimNaoEnum.SIM);
		query.setParameter("idExclusaEndosso",SimNaoEnum.NAO);
		List<ItemCobertura> coberturas = (List<ItemCobertura>) query.list();
		if (coberturas != null && !coberturas.isEmpty()) {
			return Optional.of(coberturas.get(0));
		} else {
			return Optional.empty();
		}
	}

	public void deleteDescontoAgravacao(Cotacao cotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select desconto ");
		hql.append(" from   DescontoAgravacao desconto ");
		hql.append(" where	desconto.versaoCotacaoProposta		=	:versaoCotacaoProposta ");
		hql.append(" and	desconto.numeroCotacaoProposta		=	:numeroCotacaoProposta ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("versaoCotacaoProposta",cotacao.getVersaoCotacaoProposta());
		query.setParameter("numeroCotacaoProposta",cotacao.getNumeroCotacaoProposta());

		List<DescontoAgravacao> descontos = (List<DescontoAgravacao>) query.list();

		for (DescontoAgravacao desconto : descontos) {
			getCurrentSession().delete(desconto);
		}

		getCurrentSession().flush();
	}

	public List<ItemCobertura> getCoberturasBySequencialItemCotacao(BigInteger sequencialCotacaoProposta) {
		
		StringBuilder hql = new StringBuilder();
		hql.append("	Select	cob  ");
		hql.append("	from	ItemCotacao				ic  ");
		hql.append("	join	ic.listItemCobertura	cob  ");
		hql.append("	where	ic.cotacao.sequencialCotacaoProposta	=	:sequencialCotacaoProposta ");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (List<ItemCobertura>) query.list();
		
	}
	
	@Transactional
	@LogPerformance
	public List<ItemCobertura> getCoberturasByItem(
			BigInteger numeroCotacaoProposta, Integer versao, BigInteger numeroItem) {
		
		StringBuilder hql = new StringBuilder();
		hql.append("	Select	cob  ");
		hql.append("	from	ItemCotacao				item  ");
		hql.append("	join	item.listItemCobertura	cob  ");
		hql.append("	where	item.numeroCotacaoProposta			=	:numeroCotacaoProposta ");
		hql.append("	and		item.numeroItem						=	:numeroItem ");
		hql.append("	and		item.versaoCotacaoProposta			=	:versao ");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		query.setParameter("numeroItem", numeroItem);
		query.setParameter("versao", versao);

		return (List<ItemCobertura>) query.list();
		
	}
	
	@LogPerformance
	public List<ItemCobertura> getCoberturasByItem(BigInteger numeroCotacaoProposta, Integer versao) {
		
		StringBuilder hql = new StringBuilder();
		hql.append("	Select	cob  ");
		hql.append("	from	ItemCotacao				item  ");
		hql.append("	join	item.listItemCobertura	cob  ");
		hql.append("	and		item.versaoCotacaoProposta			=	:versao ");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		query.setParameter("versao", versao);

		return (List<ItemCobertura>) query.list();
		
	}
}
