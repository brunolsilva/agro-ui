package br.com.tokiomarine.ctpj.cotacao.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.ServicoCotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ServicoCotacao;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoServico;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ServicoRepository;

@Service
public class ServicoCotacaoService  {

	private static Logger logger = LogManager.getLogger(ServicoCotacaoService.class);

	@Autowired
	private ServicoRepository servicoRepository; 
	
	@Autowired
	private ServicoCotacaoRepository servicoCotacaoRepository;
	
	@LogPerformance
	public void gerarServicoCotacao(Cotacao cotacao,User user) throws ServiceException {
		try{
			List<ProdutoServico> listProdutoServico = servicoRepository.findProdutoServico(cotacao.getCodigoProduto(),cotacao.getDataInicioVigencia());
			servicoCotacaoRepository.delete(cotacao.getSequencialCotacaoProposta());
			List<ServicoCotacao> listServicoCotacao = gerarListaProdutoServico(cotacao,listProdutoServico,user);
			servicoCotacaoRepository.saveList(listServicoCotacao);
		}catch (Exception e) {
			logger.error(String.format("Erro ao incluir serviços para a cotação com sequencial %s ", cotacao.getSequencialCotacaoProposta()),e);
			throw new ServiceException(e.getMessage(),e);
		}
		
	}

	@SuppressWarnings("null")
	private List<ServicoCotacao> gerarListaProdutoServico(Cotacao cotacao,List<ProdutoServico> listProdutoServico,User user) throws ServiceException {
		List<ServicoCotacao> listServicoCotacao = new ArrayList<>();
		try{
			for(ProdutoServico produtoServico : listProdutoServico){
				ServicoCotacao servicoCotacao = new ServicoCotacao();
				servicoCotacao.setCotacao(cotacao);
				servicoCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
				servicoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
				servicoCotacao.setCodigoProduto(produtoServico.getProduto());
				servicoCotacao.setCodidoServico(produtoServico.getServico());
				servicoCotacao.setDataInicioVigencia(produtoServico.getDataInicioVigencia());
				servicoCotacao.setDataTerminoVigencia(produtoServico.getDataTerminoVigencia());
				servicoCotacao.setNumeroDDDTelefone(produtoServico.getDddTelefone());
				servicoCotacao.setNumeroTelefone(produtoServico.getNumeroTelefone() != null ? produtoServico.getNumeroTelefone().intValue() : null);
				servicoCotacao.setNumeroDDDCelular(produtoServico.getDddCelular());
				servicoCotacao.setNumeroCelular(produtoServico.getNumeroCelular() != null ? produtoServico.getNumeroCelular().intValue(): null);
				servicoCotacao.setDataAtualizacao(new Date());
				servicoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				servicoCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				listServicoCotacao.add(servicoCotacao);
			}
		}catch(Exception e){
			throw new ServiceException("Erro ao gerar lista produto Servico",e);
		}
		return listServicoCotacao;
	}
}
