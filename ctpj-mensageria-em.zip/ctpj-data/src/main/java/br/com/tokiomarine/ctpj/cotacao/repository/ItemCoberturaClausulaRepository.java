package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class ItemCoberturaClausulaRepository extends BaseDAO{
	
	private static final String BUSCA_POR_ITEM_COBERTURA_AND_COD_CLAUSULA = 
			"select icc " +
			"from ItemCoberturaClausula icc " +
			"where icc.itemCobertura.sequencialItemCobertura = :seqItemCobertura and icc.codigoClausula = :codClausula";
	
	private static final String BUSCA_POR_ITEM_COTACAO_E_ITEM_COBERTURA_E_CLAUSULA = 
			"select icc " +
			"from ItemCoberturaClausula icc " +
			"where icc.itemCobertura.itemCotacao.sequencialItemCotacao = :seqItemCotacao and icc.itemCobertura.sequencialItemCobertura = :seqItemCobertura  and icc.codigoClausula = :codClausula";
	
	private static final String BUSCA_POR_COTACAO_E_CLAUSULA = 
			"select icc " +
			"from ItemCoberturaClausula icc " +
			"where icc.itemCobertura.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao and icc.codigoClausula = :codClausula";
	
	private static final String EXCLUI_POR_COTACAO = 
			"delete from ItemCoberturaClausula icc1 " + 
			"where icc1 in ( " +
					"select icc2 " + 
					"from ItemCoberturaClausula icc2 " +
					"where icc2.itemCobertura.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao  and icc2.idClausulaAutomatica = :clausulaAutomatica)";
	
	private static final String EXCLUI_POR_ITEM_COTACAO = 
			"delete from ItemCoberturaClausula icc1 " + 
			"where icc1 in ( " +
					"select icc2 " + 
					"from ItemCoberturaClausula icc2 " +
					"where icc2.itemCobertura.itemCotacao.sequencialItemCotacao = :seqItemCotacao and icc2.idClausulaAutomatica = :clausulaAutomatica)";
	
	public ItemCoberturaClausula salvaItem(ItemCoberturaClausula itemCoberturaClausula){
		getCurrentSession().save(itemCoberturaClausula);
		return itemCoberturaClausula;
	}
	
	public ItemCoberturaClausula buscaPorItemCoberturaECodClausula(BigInteger seqItemCobertura, Integer codClausula){
		ItemCoberturaClausula itemCoberturaClausula = (ItemCoberturaClausula) getCurrentSession()
		.createQuery(BUSCA_POR_ITEM_COBERTURA_AND_COD_CLAUSULA)
		.setParameter("seqItemCobertura", seqItemCobertura).setParameter("codClausula", codClausula)
		.setMaxResults(1)
		.uniqueResult();
		
		return itemCoberturaClausula;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemCoberturaClausula> buscaPorItemCotacaoEItemCoberturaEClausula(BigInteger seqItemCotacao, BigInteger seqItemCobertura, Integer codClausula){
		List<ItemCoberturaClausula> itemCoberturaClausula = getCurrentSession()
		.createQuery(BUSCA_POR_ITEM_COTACAO_E_ITEM_COBERTURA_E_CLAUSULA)
		.setParameter("seqItemCotacao", seqItemCotacao)
		.setParameter("seqItemCobertura", seqItemCobertura)
		.setParameter("codClausula", codClausula)
		.list();
		
		return itemCoberturaClausula;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemCoberturaClausula> buscaPorCotacaoEClausula(BigInteger seqCotacao, Integer codClausula) {
		List<ItemCoberturaClausula> itemCoberturaClausula = getCurrentSession()
				.createQuery(BUSCA_POR_COTACAO_E_CLAUSULA)
				.setParameter("seqCotacao", seqCotacao)
				.setParameter("codClausula", codClausula)
				.list();
				
		return itemCoberturaClausula;
	}
	
	public void excluiClausulasManuaisPorCotacao(BigInteger seqCotacao){
		getCurrentSession()
		.createQuery(EXCLUI_POR_COTACAO)
		.setParameter("seqCotacao", seqCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	@LogPerformance
	public void excluiClausulasAutomaticasPorCotacao(Cotacao cotacao){
		getCurrentSession()
		.createQuery(EXCLUI_POR_COTACAO)
		.setParameter("seqCotacao", cotacao.getSequencialCotacaoProposta())
		.setParameter("clausulaAutomatica", SimNaoEnum.SIM)
		.executeUpdate();
	}
	
	public void excluiClausulasManuaisPorItemCotacao(BigInteger seqItemCotacao){
		getCurrentSession()
		.createQuery(EXCLUI_POR_ITEM_COTACAO)
		.setParameter("seqItemCotacao", seqItemCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	public boolean existeClausulaGravada(BigInteger seqItemCotacao, BigInteger seqItemCobertura, Integer codClausula){
		return !buscaPorItemCotacaoEItemCoberturaEClausula(seqItemCotacao, seqItemCobertura, codClausula).isEmpty();
	}

	public void salvaItens(List<ItemCoberturaClausula> itensCoberturaClausula) {
		for(ItemCoberturaClausula itemCoberturaClausula: itensCoberturaClausula) {
			getCurrentSession().save(itemCoberturaClausula);
		}
	}
	
}
