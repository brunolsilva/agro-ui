package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCosseguradoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemCosseguradoService {

	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0118
	 */
	public void validarCossegurado(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiCossegurado = itemEndosso.getListItemCossegurado() != null && !itemEndosso.getListItemCossegurado().isEmpty();
		boolean itemApolicePossuiCossegurado = itemApolice.getListItemCosseguradoApolice() != null && !itemApolice.getListItemCosseguradoApolice().isEmpty();
		
		//1 - percorre os cossegurados do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiCossegurado){			
			for(ItemCossegurado itemEndossoCossegurado : itemEndosso.getListItemCossegurado()){
				boolean cosseguradoExiste = false;
				if(itemApolicePossuiCossegurado){
					for(ItemCosseguradoApolice itemApoliceCossegurado : itemApolice.getListItemCosseguradoApolice()){
						if(AssertUtils.compareNull(itemEndossoCossegurado.getNumeroCossegurado(),itemApoliceCossegurado.getNumeroCossegurado())){
							//valida tipo pessoa
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceCossegurado.getTipoPessoa().getId(), itemEndossoCossegurado.getTipoPessoa().getId(), TipoMensagemEndossoEnum.ALT_COSSEGURADO, "- Tipo Pessoa: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida cpf cnpj
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceCossegurado.getNumeroCPFCNPJ(), itemEndossoCossegurado.getNumeroCPFCNPJ(), TipoMensagemEndossoEnum.ALT_COSSEGURADO, "- CNPJ/CPF: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida nome pessoa
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceCossegurado.getNomePessoa(), itemEndossoCossegurado.getNomePessoa(), TipoMensagemEndossoEnum.ALT_COSSEGURADO, "- Nome: ", endosso, itemEndosso, alteracoesEndossoList, user);

							cosseguradoExiste = true;
							break;
						}						
					}
				}
				
				//se o cossegurado não existir
				if(!cosseguradoExiste){ 
					logarInclusaoCossegurado(itemEndossoCossegurado,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os cossegurados da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiCossegurado){
			for(ItemCosseguradoApolice itemApoliceCossegurado : itemApolice.getListItemCosseguradoApolice()){
				boolean cosseguradoExiste = false;
				if(itemEndossoPossuiCossegurado){
					for(ItemCossegurado itemEndossoCossegurado : itemEndosso.getListItemCossegurado()){
						if(AssertUtils.compareNull(itemEndossoCossegurado.getNumeroCossegurado(),itemApoliceCossegurado.getNumeroCossegurado())){
							cosseguradoExiste = true;
							break;
						}
					}
				}
				
				if(!cosseguradoExiste){
					logarExclusaoCossegurado(itemApoliceCossegurado,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoCossegurado(ItemCossegurado itemEndossoCossegurado, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_COSSEGURADO, itemEndossoCossegurado.getNumeroCossegurado().toString(), user));
	}
	
		
	private void logarExclusaoCossegurado(ItemCosseguradoApolice itemApoliceCossegurado, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_COSSEGURADO, itemApoliceCossegurado.getNumeroCossegurado().toString(), user));
	}
}
