package br.com.tokiomarine.ctpj.cotacao.repository;

import static org.hibernate.criterion.Restrictions.eq;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.persistence.ParameterMode;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.procedure.ProcedureOutputs;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaAdicionar;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaExclusao;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.CotacaoComProduto;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CoberturaRepository;
import br.com.tokiomarine.ctpj.util.PersistenceCloner;

@Repository
public class CotacaoRepository extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(CotacaoRepository.class);

	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;

	@Autowired
	private CoberturaRepository coberturaRepository;

	public Cotacao findByNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c from Cotacao c ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and c.versaoCotacaoProposta = (select max(c2.versaoCotacaoProposta) from Cotacao c2 ");
		hql.append(" where c2.numeroCotacaoProposta = :numeroCotacaoProposta)");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Cotacao) query.uniqueResult();
	}

	public Cotacao findById(BigInteger sqCotac) {

		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);
		Cotacao cotacao = (Cotacao) query.uniqueResult();
		cotacao.getListItem();
		return cotacao;
	}

	@LogPerformance
	public Cotacao findCompleta(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c from Cotacao c ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac ");
		hql.append(" order by i.numeroItem ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public Cotacao findComPrimeiroItem(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c from Cotacao c ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac ");
		hql.append(" where i.numeroItem = 1 ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}


	@LogPerformance
	public Cotacao findCotacaoParcelamento(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listComissaoCotacao comissao ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public Cotacao findCotacaoComItem(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" inner join fetch c.listItem i ");
		hql.append(" left  join fetch i.listItemCrivo cr ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoContaCorrente(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" inner join fetch c.listContaCorrenteGlobal ccg ");
		hql.append(" inner join fetch c.listComissaoCotacao comissao ");
		hql.append(" left join fetch c.listDescontoCCG desctCcg ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoParcelamentoRecebimento(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listOpcaoParcelamento ");
		hql.append(" left join fetch c.listRecebimento ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}

	
	@LogPerformance
	public Cotacao findCotacaoJurosParcelamento(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listJurosParcelamento ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public Cotacao findCotacaoTela(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listComissaoCotacao comissao ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemSistemaProtecional");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" left join fetch i.listItemDistribuicao ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoTelaLMI(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listComissaoCotacao comissao ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemSistemaProtecional");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" left join fetch i.listItemDistribuicao ");
		hql.append(" where 	c.sequencialCotacaoProposta = :sqCotac ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoTelaByNumeroCotacao(BigInteger numeroCotacaoProposta) {
		Query query = getCurrentSession().createQuery("SELECT c FROM Cotacao c "
				+ " left join fetch c.listComissaoCotacao comissao " 
				+ " left join fetch c.listItem i " 
				+ " left join fetch i.listItemSistemaProtecional" 
				+ " left join fetch i.listItemCobertura " 
				+ " where c.numeroCotacaoProposta = :numeroCotacaoProposta" 
				+ " and c.versaoCotacaoProposta = (" 
					+ "	Select max(c2.versaoCotacaoProposta) from  Cotacao c2 " 
					+ "	where c2.numeroCotacaoProposta = c.numeroCotacaoProposta)");
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Cotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public Cotacao findCotacaoTelaByNumeroCotacaoBloqueada(BigInteger numeroCotacaoProposta) {
		Query query = getCurrentSession().createQuery("SELECT c FROM Cotacao c "
				+ " left join fetch c.listComissaoCotacao comissao " 
				+ " left join fetch c.listItem i " 
				+ " left join fetch i.listItemSistemaProtecional" 
				+ " left join fetch i.listItemCobertura " 
				+ " where c.numeroCotacaoProposta = :numeroCotacaoProposta" 
				+ " and c.versaoCotacaoProposta = 1");
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Cotacao) query.uniqueResult();
	}

	// public void deleteProtecionais(ItemCotacao itemCotacao, List<Long> protecionais) {
	// StringBuilder hql = new StringBuilder();
	// hql.append(String.format(" delete %s p where p.itemCotacao.sequencialItemCotacao = :itemCotacao ",
	// ItemSistemaProtecional.class.getCanonicalName()));
	// hql.append(" and p.codigoSistemaProtecional not in (:protecionais)");
	//
	// Query query = getCurrentSession().createQuery(hql.toString());
	// query.setParameter("itemCotacao", itemCotacao.getSequencialItemCotacao());
	// query.setParameterList("protecionais", protecionais);
	//
	// int excluidos = query.executeUpdate();
	// logger.info(String.format("Foram excluídos %d items", excluidos));
	// }

	public void deleteProtecionais(ItemCotacao itemCotacao,List<Long> protecionais) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select p from ItemSistemaProtecional p ");
		hql.append(" where  p.itemCotacao = :itemCotacao ");
		hql.append(" and p.codigoSistemaProtecional not in (:protecionais)");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("itemCotacao",itemCotacao);
		query.setParameterList("protecionais",protecionais);

		List<ItemSistemaProtecional> itemSistemaProtecionais = (List<ItemSistemaProtecional>) query.list();

		logger.info(String.format("Mandando para a exclusão %s protecionais da cotacao %s",itemSistemaProtecionais.size(),itemCotacao.getCotacao().getSequencialCotacaoProposta()));

		for (ItemSistemaProtecional itemSistemaProtecional : itemSistemaProtecionais) {
			itemSistemaProtecional.setItemCotacao(null);
			for (Iterator<ItemSistemaProtecional> iterator = itemCotacao.getListItemSistemaProtecional().iterator() ; iterator.hasNext() ;) {
				ItemSistemaProtecional item = iterator.next();
				if (item.getSequencialItemSistemaProtecional().equals(itemSistemaProtecional.getSequencialItemSistemaProtecional())) {
					iterator.remove();
				}
			}
			getCurrentSession().delete(itemSistemaProtecional);
		}
	}

	public void addProtecionais(ItemCotacao itemCotacao,List<Long> protecionais) {
		for (Long protecional : protecionais) {
			ItemSistemaProtecional itemSistemaProtecional = new ItemSistemaProtecional();
			itemSistemaProtecional.setCodigoSistemaProtecional(protecional);

			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

			itemSistemaProtecional.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemSistemaProtecional.setDataAtualizacao(new Date());
			itemSistemaProtecional.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));

			itemSistemaProtecional.setItemCotacao(itemCotacao);
			itemSistemaProtecional.setNumeroCotacaoProposta(itemCotacao.getNumeroCotacaoProposta());
			itemSistemaProtecional.setVersaoCotacaoProposta(itemCotacao.getVersaoCotacaoProposta());
		}
	}

	@LogPerformance
	public Cotacao update(Cotacao cotacao) {
		cotacao = (Cotacao) getCurrentSession().merge(cotacao);
		getCurrentSession().flush();
		return cotacao;
	}

	public Cotacao save(Cotacao cotacao) {
		getCurrentSession().persist(cotacao);
		return cotacao;
	}

	public ItemCotacao save(ItemCotacao itemCotacao) {
		getCurrentSession().persist(itemCotacao);
		return itemCotacao;
	}

	public ItemCotacao update(ItemCotacao itemCotacao) {
		getCurrentSession().merge(itemCotacao);
		return itemCotacao;
	}

	public void excluiItem(BigInteger item) {
		logger.info("Exclusão do item " + item);
		ItemCotacao itemCotacao = getCurrentSession().load(ItemCotacao.class,item);
		Cotacao cotacao = itemCotacao.getCotacao();
		cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);

		getCurrentSession().save(cotacao);
		getCurrentSession().delete(itemCotacao);
		getCurrentSession().flush();
	}

	public ResultadoREST<CoberturaAdicionar> excluiItemCobertura(List<CoberturaExclusao> coberturas) {
		try {
			logger.info("Exclusão dos itemCoberturas " + coberturas);

			ResultadoREST<CoberturaAdicionar> resultado = new ResultadoREST<>();
			List<CoberturaAdicionar> coberturasExcluidas = new ArrayList<>();

			SimNaoEnum lmiUnico = null;
			Cotacao cotacao = null;

			StringBuilder hql = new StringBuilder();
			hql.append(" select cobertura.sequencialItemCobertura");
			hql.append(" from 		Cotacao 				cotacao ");
			hql.append(" inner join cotacao.listItem 		item ");
			hql.append(" inner join item.listItemCobertura 	cobertura ");
			hql.append(" where cotacao.sequencialCotacaoProposta = :sqCotacao ");
			hql.append(" and 	cobertura.codigoCobertura = (select cob.codigoCobertura");
			hql.append("										from 		Cotacao 		cot ");
			hql.append(" 									 	inner join  cot.listItem it ");
			hql.append(" 									 	inner join  it.listItemCobertura 	cob ");
			hql.append(" 										where  cot.sequencialCotacaoProposta = :sqCotacao ");
			hql.append(" 										and 	cob.sequencialItemCobertura = :sqCobertura) ");

			Query query = getCurrentSession().createQuery(hql.toString());

			if (!coberturas.isEmpty()) {
				ItemCobertura itemCobertura = getCurrentSession().get(ItemCobertura.class,coberturas.get(0).getSqCobertura());
				cotacao = itemCobertura.getItemCotacao().getCotacao();
				lmiUnico = cotacao.getIdLmiUnico();
			}

			for (CoberturaExclusao coberturaExclusao : coberturas) {
				/**
				 * LMI UNICO e Exclusão na tela de Cotação
				 */
				if (lmiUnico == SimNaoEnum.SIM && "COTACAO".equals(coberturaExclusao.getOrigem())) {
					query.setParameter("sqCotacao",coberturaExclusao.getSqCotacao());
					query.setParameter("sqCobertura",coberturaExclusao.getSqCobertura());
					List<BigInteger> coberturasParaExcluir = (List<BigInteger>) query.list();
					for (BigInteger c : coberturasParaExcluir) {
						ItemCobertura ic = getCurrentSession().get(ItemCobertura.class,c);
						if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && ic.getIdControleExclusaoEndosso() != SimNaoEnum.SIM) {
							deleteItemCoberturaEndosso(ic);
						} else {
							deleteItemCobertura(ic);
						}
						coberturasExcluidas.add(new CoberturaAdicionar(ic.getItemCotacao().getSequencialItemCotacao(),ic.getCodigoCobertura()));
					}
				} else {
					/**
					 * LMI UNICO e Exclusão na tela de Sublimite
					 */
					if (lmiUnico == SimNaoEnum.SIM) {
						// busca os filhos
						ItemCobertura itemCobertura = getCurrentSession().get(ItemCobertura.class,coberturaExclusao.getSqCobertura());
						List<ItemCobertura> coberturasDoItem = itemCoberturaRepository.findCoberturasByItem(itemCobertura.getItemCotacao());
						List<ValidacaoLote> listaValidacao = new ArrayList<>();
						coberturasDoItem.stream()
								.filter(it -> !it.getIdTipoCobertura().equals(1)
										&& itemCobertura.getCodigoCobertura().equals(it.getCoberturaPrincipal())
										&& it.getIdExclusaEndosso() == SimNaoEnum.NAO)
								.collect(Collectors.toList())
								.forEach(it -> listaValidacao.add(new ValidacaoLote(0, String.format(
										"Para remover esta Cobertura é necessário remover antes a cobertura %s!",
										it.getDescricaoCobertura()))));

						if (!listaValidacao.isEmpty()) {
							resultado.setSuccess(false);
							resultado.setListaValidacaoLote(listaValidacao);
							return resultado;
						}

						if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && itemCobertura.getIdControleExclusaoEndosso() != SimNaoEnum.SIM) {
							deleteItemCoberturaEndosso(itemCobertura);
						} else {
							deleteItemCobertura(itemCobertura);
						}
						coberturasExcluidas.add(new CoberturaAdicionar(itemCobertura.getItemCotacao().getSequencialItemCotacao(),itemCobertura.getCodigoCobertura()));
					} else {
						/**
						 * NÃO LMI
						 */
						ItemCobertura itemCobertura = getCurrentSession().get(ItemCobertura.class,coberturaExclusao.getSqCobertura());
						if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && itemCobertura.getIdControleExclusaoEndosso() != SimNaoEnum.SIM) {
							deleteItemCoberturaEndosso(itemCobertura);
						} else {
							deleteItemCobertura(itemCobertura);
						}
						coberturasExcluidas.add(new CoberturaAdicionar(itemCobertura.getItemCotacao().getSequencialItemCotacao(),itemCobertura.getCodigoCobertura()));
					}
				}
			}

			getCurrentSession().flush();

			resultado.setListaRetorno(coberturasExcluidas);
			resultado.setSuccess(true);

			return resultado;
		} catch (Exception e) {
			logger.error("Erro na exclusao de coberturas " + coberturas, e);
			throw new RuntimeException("Erro na exclusao de coberturas " + coberturas, e);
		}
	}

	public List<Integer> recuperaPais(ItemCotacao itemCotacao,Integer coberturaBasicas,Integer codigoCobertura) {
		CotacaoView cotacaoView = new CotacaoView();
		cotacaoView.setCodigoProduto(itemCotacao.getCotacao().getCodigoProduto());
		cotacaoView.setSequencialCotacaoProposta(itemCotacao.getCotacao().getSequencialCotacaoProposta());
		cotacaoView.setDataCotacao(itemCotacao.getCotacao().getDataCotacao());

		List<Cobertura> coberturas = coberturaRepository.findCoberturasAdicionais(
				TipoPedidoCotacaoEnum.ENDOSSO == itemCotacao.getCotacao().getIdTipoPedidoCotacao() ? true : false);
		Map<Integer,List<CoberturaHierarquiaView>> todasDM = coberturaRepository.findCoberturasAdicionaisDMView(cotacaoView,Arrays.asList(coberturaBasicas),coberturas);

		List<Integer> pais = new ArrayList<>();
		Integer codigoCoberturaOriginal = codigoCobertura;

		for (int i = 0 ; i < 3 ; i++) {
			for (CoberturaHierarquiaView c : todasDM.get(coberturaBasicas)) {
				if (c.getCodigoCobertura().equals(codigoCoberturaOriginal)) {
					if (c.getCoberturaPai() != null) {
						pais.add(c.getCoberturaPai().get(0));
						codigoCoberturaOriginal = c.getCoberturaPai().get(0);
					} else {
						break;
					}
				}
			}
		}

		return pais;
	}

	public void deleteItemCobertura(ItemCobertura itemCobertura) {
		Cotacao cotacao = itemCobertura.getItemCotacao().getCotacao();
		cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
		getCurrentSession().save(cotacao);
		getCurrentSession().delete(itemCobertura);
	}

	public void deleteItemCobertura(List<ItemCobertura> coberturas) {
		for (ItemCobertura itemCobertura : coberturas) {
			getCurrentSession().delete(itemCobertura);
		}
	}

	public void deleteItemCobertura(List<Integer> coberturas, BigInteger sequencialItemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cobertura from ItemCobertura cobertura ");
		hql.append(" where	cobertura.itemCotacao.sequencialItemCotacao = :sequencialItemCotacao ");		
		hql.append(" and	cobertura.codigoCobertura		in (:coberturas) ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialItemCotacao", sequencialItemCotacao);
		query.setParameterList("coberturas", coberturas);
		List<ItemCobertura> retorno = (List<ItemCobertura>) query.list();
		for(ItemCobertura itemCobertura: retorno) {
			getCurrentSession().delete(itemCobertura);
		}
	}

	private void deleteItemCoberturaEndosso(ItemCobertura itemCobertura) {
		Cotacao cotacao = itemCobertura.getItemCotacao().getCotacao();
		cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
		itemCobertura.setIdExclusaEndosso(SimNaoEnum.SIM);
		getCurrentSession().save(cotacao);
		getCurrentSession().save(itemCobertura);
	}

	public Object[] getCotacaoVersaoMoeda(BigInteger sqCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();

		hql.append(" select c.numeroCotacaoProposta, c.versaoCotacaoProposta, c.codigoMoeda from Cotacao c ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotacao ");

		Query query = getCurrentSession().createQuery(hql.toString());

		query.setParameter("sqCotacao",sqCotacao);

		return (Object[]) query.uniqueResult();
	}

	public Integer countItems(BigInteger sqCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select count(1) ");
		hql.append(" 	from ItemCotacao item ");
		hql.append(" where item.cotacao.sequencialCotacaoProposta = :sqCotacao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotacao",sqCotacao);
		return ((Long) query.uniqueResult()).intValue();
	}

	public ItemCotacao findItem(BigInteger sqItemCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select item ");
		hql.append(" 	from ItemCotacao item ");
		hql.append(" where item.sequencialItemCotacao = :sqItemCotacao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqItemCotacao",sqItemCotacao);
		return (ItemCotacao) query.uniqueResult();
	}

	public List<ItemCotacao> getItemsComEndereco(BigInteger sqCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select item ");
		hql.append(" from ItemCotacao item ");
		hql.append(" where item.cotacao.sequencialCotacaoProposta = :sqCotacao ");
		hql.append(" order by item.numeroItem");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotacao",sqCotacao);

		return (List<ItemCotacao>) query.list();
	}

	public List<ItemCotacao> getItemsSemInspecao(BigInteger sqCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();

		hql.append(" select item ");
		hql.append(" from ItemCotacao item ");
		hql.append(" where item.cotacao.sequencialCotacaoProposta = :sqCotacao ");
		hql.append(" and	not exists (select 1 from ItemInspecao itemInspec where item = itemInspec.itemCotacao) ");
		hql.append(" order by item.numeroItem");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotacao",sqCotacao);
		List<ItemCotacao> items = (List<ItemCotacao>) query.list();
		if(items != null && !items.isEmpty()) {
			if(items.get(0).getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				List<ItemCotacao> itemsEndosso = new ArrayList<>();
				for(ItemCotacao item: items) {
					if(TipoEndossoEnum.isItemAlteracaoInclusao(item.getIdTipoEndosso(), items.get(0).getCotacao().getIdLmiUnico().getLogical())) {
						itemsEndosso.add(item);
					}
				}
				return itemsEndosso;
			}
		}

		return items;
	}

	public void deleteItemDistribuicao(Cotacao cotacao) {

		List<ItemDistribuicao> itemsDistribuicao = new ArrayList<>();
		for(ItemCotacao item: cotacao.getListItem()) {
			if(item != null) {
				itemsDistribuicao.addAll(item.getListItemDistribuicao());
			}
		}

		if (itemsDistribuicao != null && !itemsDistribuicao.isEmpty()) {
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				if(itemCotacao != null) {
					for (Iterator<ItemDistribuicao> iterator = itemCotacao.getListItemDistribuicao().iterator() ; iterator.hasNext() ;) {
						ItemDistribuicao item = iterator.next();
						getCurrentSession().delete(item);
						iterator.remove();
					}
				}
			}
		}

		getCurrentSession().flush();
	}

	public void deleteItemDistribuicao(ItemCotacao itemCotacao) {
		if (itemCotacao.getListItemDistribuicao() != null && !itemCotacao.getListItemDistribuicao().isEmpty()) {
			logger.info("Início delete da lista de ItemDist " + itemCotacao.getNumeroItem() + " " + itemCotacao.getCotacao().getSequencialCotacaoProposta());

			List<BigInteger> ids = itemCotacao.getListItemDistribuicao().stream().map(ItemDistribuicao::getSequencialItemDistribuicao).collect(Collectors.toList());
			List<ItemDistribuicao> itemsDistribuicao = itemCotacao.getListItemDistribuicao().stream().filter(it -> ids.contains(it.getSequencialItemDistribuicao())).collect(Collectors.toList());

			if (!ids.isEmpty()) {
				for (ItemDistribuicao itemDistribuicao : itemsDistribuicao) {
					itemDistribuicao.setItemCotacao(null);
					for (Iterator<ItemDistribuicao> iterator = itemCotacao.getListItemDistribuicao().iterator() ; iterator.hasNext() ;) {
						ItemDistribuicao item = iterator.next();
						itemDistribuicao.setItemCotacao(null);
						if (item.getSequencialItemDistribuicao().equals(itemDistribuicao.getSequencialItemDistribuicao())) {
							iterator.remove();
							getCurrentSession().delete(itemDistribuicao);
						}
					}
				}
			}

			logger.info("Fim delete da lista de ItemDist " + itemCotacao.getNumeroItem() + " " + itemCotacao.getCotacao().getSequencialCotacaoProposta());
		}
	}

	@LogPerformance
	public boolean isCotacaoLMI(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("select c.idLmiUnico from Cotacao c where c.sequencialCotacaoProposta = :sqCotacao");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotacao",sqCotac);

		SimNaoEnum lmi = (SimNaoEnum) query.uniqueResult();

		return lmi.getLogical();
	}
	
	@LogPerformance
	public Cotacao duplicaCotacaoExistente2(Cotacao origem, Cotacao destino) {
		destino.getListItem().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListItem().clear();

		destino.getListAlteracaoEndosso().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListAlteracaoEndosso().clear();
		
		destino.getListBloqueioAlcada().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListBloqueioAlcada().clear();
		
		destino.getListComissaoCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListComissaoCotacao().clear();
		
		destino.getListCondicaoContratual().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListCondicaoContratual().clear();
		
		destino.getListContaCorrenteGlobal().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListContaCorrenteGlobal().clear();
		
		destino.getListCorretagemCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListCorretagemCotacao().clear();
		
		destino.getListCosseguroCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListCosseguroCotacao().clear();
		
		destino.getListDescontoCCG().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListDescontoCCG().clear();
		
		destino.getListHistoricoSituacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListHistoricoSituacao().clear();
		
		destino.getListOpcaoParcelamento().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListOpcaoParcelamento().clear();
		
		destino.getListRecebimento().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListRecebimento().clear();
		
		destino.getListItem().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListItem().clear();
		
		destino.getListClausulaCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListClausulaCotacao().clear();
		
		destino.getListNotaCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListNotaCotacao().clear();
		
		destino.getListServicoCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListServicoCotacao().clear();
		
		destino.getListJurosParcelamento().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListJurosParcelamento().clear();
		
		destino.getControlesFichaRegistrada().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getControlesFichaRegistrada().clear();
		
		destino.getPareceresCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getPareceresCotacao().clear();
		
		if(destino.getDocumentoDigital() != null) {
			getCurrentSession().delete(destino.getDocumentoDigital());
		}

		logger.info("FLUSH 1");
		System.out.println("0 " + destino.getListItem());
		getCurrentSession().update(destino);
		System.out.println("1 " + destino.getListItem());
		getCurrentSession().save(destino);
		System.out.println("2 " + destino.getListItem());
		getCurrentSession().saveOrUpdate(destino);
		System.out.println("3 " + destino.getListItem());
		getCurrentSession().flush();
		logger.info("FLUSH 2");
		return destino;
	}
	
	@LogPerformance
	public Cotacao duplicaCotacaoExistente(Cotacao origem, Cotacao destino) {
		destino.getListItem().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListItem().clear();

		destino.getListAlteracaoEndosso().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListAlteracaoEndosso().clear();
		
		destino.getListBloqueioAlcada().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListBloqueioAlcada().clear();
		
		destino.getListComissaoCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListComissaoCotacao().clear();

		destino.getListCondicaoContratual().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListCondicaoContratual().clear();
		
		destino.getListContaCorrenteGlobal().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListContaCorrenteGlobal().clear();
		
		destino.getListCorretagemCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListCorretagemCotacao().clear();
		
		destino.getListCosseguroCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListCosseguroCotacao().clear();
		
		destino.getListDescontoCCG().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListDescontoCCG().clear();
		
		destino.getListHistoricoSituacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListHistoricoSituacao().clear();
		
		destino.getListOpcaoParcelamento().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListOpcaoParcelamento().clear();
		
		destino.getListRecebimento().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListRecebimento().clear();
		
		destino.getListItem().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListItem().clear();
		
		destino.getListClausulaCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListClausulaCotacao().clear();
		
		destino.getListNotaCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListNotaCotacao().clear();
		
		destino.getListServicoCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListServicoCotacao().clear();
		
		destino.getListJurosParcelamento().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getListJurosParcelamento().clear();
		
		destino.getControlesFichaRegistrada().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getControlesFichaRegistrada().clear();
		
		destino.getPareceresCotacao().forEach(it -> {
			getCurrentSession().delete(it);
		});
		destino.getPareceresCotacao().clear();
		
		if(destino.getDocumentoDigital() != null) {
			getCurrentSession().delete(destino.getDocumentoDigital());
		}
		getCurrentSession().flush();

		return generateCopyToPersistCotacaoDuplicacao(origem, destino);
	}
	
	@LogPerformance
	public List<ItemCotacao> duplicaItem(ItemCotacao itemCotacao, int quantidade, int ultimoItem) throws HibernateException {
		List<ItemCotacao> items = new ArrayList<>();
		for(int i = 0; i < quantidade; i++) {
			items.add(generateCopyToPersistItem(itemCotacao));
		}

		for(ItemCotacao item: items) {
			item.setNumeroItem(new BigInteger(String.valueOf(++ultimoItem)));
		}
		return items;
	}
	
	@LogPerformance
	public Cotacao duplicaCotacao(Cotacao cotacao) throws HibernateException {
		return generateCopyToPersistCotacao(cotacao);
	}
	
	@LogPerformance
	public Cotacao novaVersaoCotacao(Cotacao cotacao) throws HibernateException {
		return generateCopyToPersistCotacaoNovaVersao(cotacao);
	}
	
	private Cotacao generateCopyToPersistCotacao(Cotacao cotacao) {
		return new PersistenceCloner<Cotacao>(cotacao).generateCopyToPersist();
	}

	private Cotacao generateCopyToPersistCotacaoNovaVersao(Cotacao cotacao) {
		return new PersistenceCloner<Cotacao>(cotacao).generateCopyToPersistNovaVersao();
	}
	
	private Cotacao generateCopyToPersistCotacaoDuplicacao(Cotacao origem,Cotacao destino) {
		return new PersistenceCloner<Cotacao>(origem,destino).generateCopyToDuplicacao();
	}
	
	private ItemCotacao generateCopyToPersistItem(ItemCotacao itemCotacao) {
		return new PersistenceCloner<ItemCotacao>(itemCotacao).generateCopyToPersist();
	}

	public CotacaoView findCotacaoCabecalho(BigInteger cotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		try {

			hql.append(" select sequencialCotacaoProposta 	as sequencialCotacaoProposta, ");
			hql.append(" 		numeroCotacaoProposta 		as numeroCotacaoProposta, ");
			hql.append(" 		versaoCotacaoProposta 		as versaoCotacaoProposta, ");
			hql.append(" 		idTipoSeguro 				as idTipoSeguro, ");
			hql.append(" 		codigoProduto 				as codigoProduto, ");
			hql.append(" 		nomeProduto 				as nomeProduto, ");
			hql.append(" 		dataCotacao 				as dataCotacao, ");
			hql.append(" 		dataCalculo 				as dataCalculo, ");
			hql.append(" 		codigoCorretorACSEL 		as codigoCorretorACSEL, ");
			hql.append(" 		nomeCorretor 				as nomeCorretor, ");
			hql.append(" 		idControleCalculo			as idControleCalculo, ");
			hql.append(" 		idTipoSeguro 				as idTipoSeguro, ");
			hql.append("        idTipoEndosso               as idTipoEndosso, ");
			hql.append("        idTipoPedidoCotacao         as idTipoPedidoCotacao, ");
			hql.append("        idSolicitanteEndosso        as idSolicitanteEndosso, ");
			hql.append("        emailCorretorInspecao       as emailCorretorInspecao, ");
			hql.append("        idControleCalculo           as idControleCalculo, ");
			hql.append("        codigoTipoEndossoSCT        as codigoTipoEndossoSCT, ");
			hql.append("        codigoSituacao              as codigoSituacaoReadOnly, ");
			hql.append("        idDestinoEmissao            as idDestinoEmissao ");
			hql.append(" from 	Cotacao ");
			hql.append(" where 	sequencialCotacaoProposta = :cotacao ");

			Query query = getCurrentSession().createQuery(hql.toString()).setParameter("cotacao",cotacao).setResultTransformer(new AliasToBeanResultTransformer(CotacaoView.class));

			CotacaoView cotacaoView = (CotacaoView) query.uniqueResult();

			return cotacaoView;
		} catch (Exception e) {
			throw new RepositoryException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoComItemRenumeracao(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" join fetch c.listItem i ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);

		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Integer getNrNovaVersaoCotacao(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT max(c.versaoCotacaoProposta) + 1 FROM Cotacao c ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Integer) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoCondicaoContratual(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listCondicaoContratual condicaoContratual ");
		hql.append(" where c.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		hql.append(" order by condicaoContratual.codigoRamoClausula, condicaoContratual.codigoClausula");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}

	public Cotacao findCotacaoByMaiorNrCotacPpota(BigInteger numeroCotacaoProposta) throws HibernateException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c from Cotacao c ");
		hql.append(" where  c.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and    c.versaoCotacaoProposta = (Select  max(c2.versaoCotacaoProposta) ");
		hql.append("                                   from    Cotacao c2 ");
		hql.append("                                   where   c2.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append("                                   and     c2.dataTransmissaoProposta is not null) ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Cotacao) query.uniqueResult();

	}

	@LogPerformance
	public Cotacao findCotacaoItemInspecaoCompletaBySeqCotacao(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c from Cotacao c ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemRamoEmissao");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" where c.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public Cotacao findCotacaoComItemInspecao(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c from Cotacao c ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemInspecao");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" where c.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoItemInspecaoBySeqItemInspecao(BigInteger sequencialItemInspecao) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" inner join fetch c.listItem i ");
		hql.append(" inner join fetch i.listItemInspecao ii ");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" where ii.sequencialItemInspecao = :sequencialItemInspecao ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialItemInspecao",sequencialItemInspecao);
		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoItemInspecaoByNumeroCotacAndNumeroItem(BigInteger numeroCotacaoProposta,BigInteger numeroItem) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" left join fetch i.listItemSistemaProtecional");
		hql.append(" left join fetch i.listItemCobertura ");
		hql.append(" left join fetch i.listItemDistribuicao ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and c.versaoCotacaoProposta = (select max(c2.versaoCotacaoProposta) ");
		hql.append("                                from   Cotacao c2 ");
		hql.append("                                where  c2.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append("                                and    c2.dataTransmissaoProposta is not null) ");
		hql.append(" and i.numeroItem = :numeroItem ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.setParameter("numeroItem",numeroItem);
		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoByNrCotacAndVsCotac(BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" inner join fetch c.listItem i ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and c.versaoCotacaoProposta = :versaoCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.setParameter("versaoCotacaoProposta",versaoCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public List<ItemCotacao> findByCotacaoAndCdRubrica(BigInteger seqCotacao,Long codRubrica) {
		String hql = new StringBuilder().append("select ic ").append("from ItemCotacao ic ").append("where ic.cotacao.sequencialCotacaoProposta = :seqCotacao ").append("and ic.codigoRubrica = :codRubrica").toString();

		return getCurrentSession().createQuery(hql).setParameter("seqCotacao",seqCotacao).setParameter("codRubrica",codRubrica).list();
	}

	@SuppressWarnings("unchecked")
	public List<ItemCotacao> findItemByCotacao(BigInteger seqCotacao) {
		String hql = new StringBuilder().append("select ic ").append("from ItemCotacao ic ").append("where ic.cotacao.sequencialCotacaoProposta = :seqCotacao ").toString();

		return getCurrentSession().createQuery(hql).setParameter("seqCotacao",seqCotacao).list();
	}

	@LogPerformance
	public Cotacao findCotacaoByNrCotacMaxVs(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" SELECT a FROM Cotacao a ");
		hql.append(" where a.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and a.versaoCotacaoProposta = (select max(c2.versaoCotacaoProposta) ");
		hql.append("                                from   Cotacao c2 ");
		hql.append("                                where  c2.numeroCotacaoProposta = :numeroCotacaoProposta )");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<Recebimento> findCotacaoRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" SELECT r FROM Cotacao c ,");
		hql.append(" Recebimento r ");
		hql.append(" where c.numeroCotacaoProposta = r.numeroCotacaoProposta ");
		hql.append(" and c.sequencialCotacaoProposta = :sequencialCotacaoProposta ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return query.list();
	}

	@LogPerformance
	public boolean existeCotacaoNrCotac(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" SELECT count(*) FROM Cotacao a ");
		hql.append(" where a.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and a.versaoCotacaoProposta = (select max(c2.versaoCotacaoProposta) ");
		hql.append("                                from   Cotacao c2 ");
		hql.append("                                where  c2.numeroCotacaoProposta = :numeroCotacaoProposta )");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		Long count = (Long) query.uniqueResult();

		if (count == null || count.intValue() <= 0) {
			return false;
		}
		return true;
	}

	@LogPerformance
	public Cotacao findCotacaoPareceres(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.pareceresCotacao pareceres ");
		hql.append(" where c.sequencialCotacaoProposta = :sqCotac");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotac",sqCotac);
		return (Cotacao) query.uniqueResult();
	}

	public Cotacao findByCodigoApoliceRenovada(Long codigoApoliceRenovada) {
		Cotacao cotacao = (Cotacao) getCurrentSession().createCriteria(Cotacao.class).add(eq("codigoApoliceRenovada",codigoApoliceRenovada)).setMaxResults(1).uniqueResult();

		return cotacao;
	}

	@LogPerformance
	public Cotacao findCotacaoNotas(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listNotaCotacao notas ");
		hql.append(" where c.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoNotas(BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listNotaCotacao notas ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta");
		hql.append(" and c.versaoCotacaoProposta = :versaoCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.setParameter("versaoCotacaoProposta",versaoCotacaoProposta);
		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public Cotacao findCotacaoComItensCotacao(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT c FROM Cotacao c ");
		hql.append(" left join fetch c.listItem i ");
		hql.append(" where c.sequencialCotacaoProposta = :sequencialCotacaoProposta");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (Cotacao) query.uniqueResult();
	}

	@LogPerformance
	public List<ItemCotacao> findItensCotacaoAndItemNotas(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT i FROM ItemCotacao i ");
		hql.append(" left join fetch i.listItemNota l ");
		hql.append(" where i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (List<ItemCotacao>) query.list();
	}

	@LogPerformance
	public ItemCotacao findItensCotacaoAndItemNotaBySequencialItemCotacao(BigInteger sequencialItemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT i FROM ItemCotacao i ");
		hql.append(" left join fetch i.listItemNota l ");
		hql.append(" where i.sequencialItemCotacao = :sequencialItemCotacao");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialItemCotacao",sequencialItemCotacao);

		return (ItemCotacao) query.uniqueResult();
	}

	public Cotacao findCotacaoDeApoliceEndossada(BigInteger numeroCotacaoProposta,Integer codigoRamoProdutoEndossada,Long codigoApoliceEndossada) {
		StringBuilder hql = new StringBuilder();
		hql.append(" SELECT c FROM Cotacao c");
		hql.append(" left join fetch c.listComissaoCotacao comissao ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta");
		hql.append(" and c.versaoCotacaoProposta = (select max(c2.versaoCotacaoProposta) from   Cotacao c2 where  c2.numeroCotacaoProposta = :numeroCotacaoProposta )");
		hql.append(" and c.codigoRamoProdutoEndossada = :codigoRamoProdutoEndossada");
		hql.append(" and c.codigoApoliceEndossada = :codigoApoliceEndossada");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.setParameter("codigoRamoProdutoEndossada",codigoRamoProdutoEndossada);
		query.setParameter("codigoApoliceEndossada",codigoApoliceEndossada);

		return (Cotacao) query.uniqueResult();

	}

	public TreeMap<Integer,Object> findVersoes(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("select versaoCotacaoProposta, sequencialCotacaoProposta from Cotacao where numeroCotacaoProposta = :numeroCotacaoProposta order by versaoCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		List<Object[]> retorno = query.list();
		TreeMap<Integer,Object> map = new TreeMap<>();
		for (Object[] r : retorno) {
			map.put((Integer) r[0],r[1]);
		}
		return map;
	}

	public boolean existeCotacaoDuplicada(BigInteger numeroCotacaoProposta) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select	count(1) ");
		hql.append(" from	Cotacao c ");
		hql.append(" where  c.numeroCotacaoProposta = :numeroCotacaoProposta  ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		Long count = (Long) query.uniqueResult();

		if (count == null || count.intValue() <= 0) {
			return false;
		}
		return true;
	}

	@LogPerformance
	public Integer getNrMaxVersaoCotacaoByNrCotacao(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT max(c.versaoCotacaoProposta) FROM Cotacao c ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Integer) query.uniqueResult();
	}

	@LogPerformance
	public List<AlteracaoEndosso> findAlteracaoEndossoByItemCotacao(ItemCotacao itemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT a FROM AlteracaoEndosso a ");
		hql.append(" where a.cotacao = :cotacao ");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao",itemCotacao.getCotacao());
		
		return (List<AlteracaoEndosso>) query.list();
	}

	public List<ItemRamoEmissao> findItemRamoEmissaoByItemCotacao(ItemCotacao itemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT i FROM ItemRamoEmissao i ");
		hql.append(" where i.itemCotacao = :itemCotacao");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("itemCotacao",itemCotacao);
		
		return (List<ItemRamoEmissao>) query.list();
	}

	public List<ItemSinistro> findItemSinistro(Set<ItemCotacao> items) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT i FROM ItemSinistro i ");
		hql.append(" where i.itemCotacao in (:items)");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameterList("items", items);

		return (List<ItemSinistro>) query.list();
	}

	public Cotacao findByNumeroAndVersao(BigInteger numeroCotacaoProposta, Integer versao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" from	Cotacao	c ");
		hql.append(" where	c.numeroCotacaoProposta	=	:numeroCotacaoProposta ");
		hql.append(" and	c.versaoCotacaoProposta		=	:versao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		query.setParameter("versao", versao);

		return (Cotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public Boolean isOrcamentoRamoCpfCnpj(BigInteger numeroCotacaoProposta) {
		/*StringBuilder hql = new StringBuilder();
		hql.append(" select count(0) from Cotacao c ");
		hql.append(" inner join fetch c.listItem i ");
		hql.append(" inner join fetch i.listItemRamoEmissao ir ");
		hql.append(" where c.numeroCotacaoProposta <> :numeroCotacaoProposta ");
		hql.append(" and c.codigoCorretorACSEL <> :codigoCorretorACSEL ");
		hql.append(" and c.dataCotacao between add_months(trunc(sysdate()),-6) and trunc(sysdate()) ");
		hql.append(" and c.codigoSituacao not in (454) ");
		hql.append(" and i.codigoRubrica <> :codigoRubrica");
		hql.append(" and ir.codigoRamo = :codigoRamo ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",sqCotac);
		query.setParameter("codigoCorretorACSEL",sqCotac);
		query.setParameter("codigoRubrica",sqCotac);
		query.setParameter("codigoRamo", sqCotac);

		return (((Long) query.uniqueResult()).intValue() > 0);*/
		return false;
	}

	@LogPerformance
	public CotacaoComProduto findCotacao(BigInteger numeroCotacao, Long codigoCorretor) {
		StringBuilder hql = new StringBuilder();

		hql.append(" select numeroCotacaoProposta 		as numeroCotacao, ");
		hql.append(" 		codigoProduto		 		as produto, ");
		hql.append(" 		codigoCorretorACSEL		 	as corretor, ");
		hql.append(" 		dataCotacao		 			as dataCotacao ");
		hql.append(" from 	Cotacao ");
		hql.append(" where 	numeroCotacaoProposta 		= :numeroCotacao ");
		hql.append(" and 	versaoCotacaoProposta 		= 1 ");
		hql.append(" and 	codigoCorretorACSEL 		= :codigoCorretor ");

		Query query = getCurrentSession()
				.createQuery(hql.toString())
				.setParameter("numeroCotacao",numeroCotacao)
				.setParameter("codigoCorretor", String.valueOf(codigoCorretor))
				.setMaxResults(1)
				.setResultTransformer(new AliasToBeanResultTransformer(CotacaoComProduto.class));

		return (CotacaoComProduto) query.uniqueResult();
	}
	

	
	public void merge(Cotacao cotacao) {
		getCurrentSession().merge(cotacao);
	}
	
	public void flush() {
		getCurrentSession().flush();
	}
	
	@LogPerformance
	public Cotacao updateTransmissao(Cotacao cotacao) throws RepositoryException {
		cotacao = (Cotacao) getCurrentSession().merge(cotacao);
		getCurrentSession().flush();
		
		calcularParcelamentoRamo(cotacao);

		return cotacao;
	}

	public void calcularParcelamentoRamo(Cotacao cotacao) throws RepositoryException {
		try {
			if(cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) != 0) {
				OpcaoParcelamento opcao = cotacao.getListOpcaoParcelamento().stream()
						.filter(it -> it.getIdParcelamentoEscolhido() == SimNaoEnum.SIM)
						.findAny()
						.orElse(null);
				
				if(opcao != null) {
					BigInteger opcaoParcelamentoSelecionada = opcao.getSequencialOpcaoParcelamento();
					ProcedureCall procedure = getCurrentSession()
							.createStoredProcedureCall("ctpj0001_001.prc_calculaParcRamo")
							.registerParameter0("p_sq_opcao_parcm", BigInteger.class, ParameterMode.IN)
							.registerParameter0("p_mens", String.class, ParameterMode.OUT);
					
					procedure.getParameterRegistration("p_sq_opcao_parcm").bindValue(opcaoParcelamentoSelecionada);
					
					ProcedureOutputs output = procedure.getOutputs();
					String pMens = (String) output.getOutputParameterValue("p_mens"); 								
					
			        super.validaRetornoDaProcedure(pMens);
				}
			}
		} catch (Exception e) {
			logger.error("Erro ao chamar procedure geraMensagemEndosso: " + e);
			throw new RepositoryException(e.getMessage(),e);			
		}
	}
	
	@LogPerformance
	public Boolean hasVspByNumeroCotacao(BigInteger numeroCotacaoProposta) {
		
		StringBuilder hql = new StringBuilder();
		hql.append(" select	count(0) from Cotacao c ");
		hql.append(" where c.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and c.icVsp = :icVsp");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.setParameter("icVsp", SimNaoEnum.SIM);

		return (((Long) query.uniqueResult()).intValue() > 0);
		
	}
}
