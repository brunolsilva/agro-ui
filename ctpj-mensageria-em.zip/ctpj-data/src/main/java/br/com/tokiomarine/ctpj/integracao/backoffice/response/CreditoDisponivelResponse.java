package br.com.tokiomarine.ctpj.integracao.backoffice.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreditoDisponivelResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4662952050550727558L;

	@JsonProperty("cd_agencia")
	private Long numeroAgencia;

	@JsonProperty("cd_banco")
	private Long numeroBanco;

	private String nomeBanco;

	@JsonProperty("cd_pedido_cotacao")
	private BigInteger numeroCotacaoPropostaRecusada;

	@JsonProperty("id_tipo_recebimento")
	private String idTipoRecebimento;

	@JsonProperty("nr_nosso_numero")
	private BigInteger numeroNossoNumeroTitulo;

	@JsonProperty("vl_credito")
	private BigDecimal valorCredito;

	@JsonProperty("p_mensagem")
	private String mensagem;

	@JsonProperty("p_mens")
	private String mensagemErro;

	@JsonProperty("codigoRetorno")
	private String codigoRetorno;

	@JsonProperty("descricaoCodigoRetorno")
	private String descricaoCodigoRetorno;

	public Long getNumeroAgencia() {
		return numeroAgencia;
	}

	public void setNumeroAgencia(Long numeroAgencia) {
		this.numeroAgencia = numeroAgencia;
	}

	public Long getNumeroBanco() {
		return numeroBanco;
	}

	public void setNumeroBanco(Long numeroBanco) {
		this.numeroBanco = numeroBanco;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public BigInteger getNumeroCotacaoPropostaRecusada() {
		return numeroCotacaoPropostaRecusada;
	}

	public void setNumeroCotacaoPropostaRecusada(BigInteger numeroCotacaoPropostaRecusada) {
		this.numeroCotacaoPropostaRecusada = numeroCotacaoPropostaRecusada;
	}

	public String getIdTipoRecebimento() {
		return idTipoRecebimento;
	}

	public void setIdTipoRecebimento(String idTipoRecebimento) {
		this.idTipoRecebimento = idTipoRecebimento;
	}

	public BigInteger getNumeroNossoNumeroTitulo() {
		return numeroNossoNumeroTitulo;
	}

	public void setNumeroNossoNumeroTitulo(BigInteger numeroNossoNumeroTitulo) {
		this.numeroNossoNumeroTitulo = numeroNossoNumeroTitulo;
	}

	public BigDecimal getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(BigDecimal valorCredito) {
		this.valorCredito = valorCredito;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getMensagemErro() {
		return mensagemErro;
	}

	public void setMensagemErro(String mensagemErro) {
		this.mensagemErro = mensagemErro;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	@Override
	public String toString() {
		return "CreditoDisponivelResponse [numeroAgencia=" + numeroAgencia + ", numeroBanco=" + numeroBanco + ", nomeBanco=" + nomeBanco + 
				", numeroCotacaoPropostaRecusada=" + numeroCotacaoPropostaRecusada + ", idTipoRecebimento=" + idTipoRecebimento + 
				", numeroNossoNumeroTitulo=" + numeroNossoNumeroTitulo + ", valorCredito=" + valorCredito + ", mensagem=" + mensagem + 
				", mensagemErro=" + mensagemErro + ", codigoRetorno=" + codigoRetorno + ", descricaoCodigoRetorno=" + descricaoCodigoRetorno + "]";
	}
	
	

}
