package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DataMinimaVencimentoView implements Serializable {

	private static final long serialVersionUID = 8198157762117769080L;

	private String codigoRetorno;
	private String descricaoCodigoRetorno;
	private String p_dt_min;

	public String getCodigoRetorno() {
		return codigoRetorno;
	}
	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}
	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}
	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}
	public String getP_dt_min() {
		return p_dt_min;
	}
	public void setP_dt_min(String p_dt_min) {
		this.p_dt_min = p_dt_min;
	}

	@Override
	public String toString() {
		return "DataMinimaVencimentoView [codigoRetorno=" + codigoRetorno + ", descricaoCodigoRetorno="
				+ descricaoCodigoRetorno + ", p_dt_min=" + p_dt_min + "]";
	}
}