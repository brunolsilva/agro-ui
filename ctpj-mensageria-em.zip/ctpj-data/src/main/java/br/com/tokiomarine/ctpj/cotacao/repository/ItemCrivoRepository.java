package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCrivo;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;

@Repository
public class ItemCrivoRepository extends BaseDAO{

	public ItemCrivo save(ItemCrivo itemCrivo) throws HibernateException{
		super.getCurrentSession().save(itemCrivo);
		return itemCrivo;
	}

	public int deleteItemCrivo(BigInteger sequencialItemCrivo) throws HibernateException {
		StringBuilder sb = new StringBuilder();
		sb.append("DELETE FROM ItemCrivo i where i.sequencialItemCrivo = :sequencialItemCrivo");
		Query query = getCurrentSession().createQuery(sb.toString())
				.setParameter("sequencialItemCrivo",sequencialItemCrivo);
		return query.executeUpdate();
	}
	
	public ItemCrivo findItemCrivoByItemCotacao(BigInteger sequencialItemCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		try {
			hql.append(" select ic from ItemCrivo ic ");
			hql.append(" where	ic.itemCotacao.sequencialItemCotacao = :sequencialItemCotacao ");
			Query query = getCurrentSession().createQuery(hql.toString());
			query.setParameter("sequencialItemCotacao", sequencialItemCotacao);
			return (ItemCrivo) query.uniqueResult();
		} catch(Exception e) {
			throw new RepositoryException(e.getMessage(), e);
		}
	}
	
	public List<ItemCrivo> findItemsCrivoByItemCotacao(List<BigInteger> sequencialItemCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		try {
			hql.append(" select ic from ItemCrivo ic ");
			hql.append(" where	ic.itemCotacao.sequencialItemCotacao in (:sequencialItemCotacao) ");
			Query query = getCurrentSession().createQuery(hql.toString());
			query.setParameterList("sequencialItemCotacao", sequencialItemCotacao);
			return (List<ItemCrivo>) query.list();
		} catch(Exception e) {
			throw new RepositoryException(e.getMessage(), e);
		}
	}

	public ItemCrivo update(ItemCrivo itemCrivo) throws HibernateException{
		super.getCurrentSession().update(itemCrivo);
		return itemCrivo;
	}

	
}
