package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.IgnoraAceitacao;

@Repository
public class IgnoraAceitacaoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public Optional<IgnoraAceitacao> findCotacao(BigInteger cotacao) {
		return Optional.ofNullable(mongoTemplate.findOne(
				query(where("cotacao").is(cotacao) ), IgnoraAceitacao.class));
	}
}