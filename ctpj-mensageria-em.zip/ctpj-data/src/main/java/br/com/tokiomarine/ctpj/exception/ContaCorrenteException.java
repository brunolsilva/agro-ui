package br.com.tokiomarine.ctpj.exception;


public class ContaCorrenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9171581685685953098L;
	
	public ContaCorrenteException(String message) {
		super(message);
	}

	public ContaCorrenteException(String message,Throwable cause) {
		super(message,cause);
	}

}
