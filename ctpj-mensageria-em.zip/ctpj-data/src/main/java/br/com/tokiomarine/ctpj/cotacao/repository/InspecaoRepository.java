package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.enums.ParecerInspecaoEnum;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Repository
public class InspecaoRepository extends BaseDAO{
	
	private static final String LISTA_ITENS_INSPECAO_POR_COTACAO = 
			"select itemInspec " +
			"from ItemInspecao itemInspec " + 
				"join itemInspec.itemCotacao itemCot " +	
				"join itemCot.cotacao cot " +
			"where " +
				"cot.sequencialCotacaoProposta = :sequencialCotacaoProposta " +
			"order by itemCot.numeroItem ";
	
	private static final String BUSCA_ITEM_INSPECAO_POR_ITEM_COTACAO =
			"select itemInspec " +
			"from ItemInspecao itemInspec " + 
				"join itemInspec.itemCotacao itemCot " +
			"where " +
				"itemCot.sequencialItemCotacao = :sequencialItemCotacao ";

	private static final String EXCLUI_ITENS_INSPECAO_POR_COTACAO = 
			" delete from ItemInspecao insp " +
			" where insp.numeroCotacaoProposta = :numeroCotacaoProposta ";

	/**
	 * Salva uma entidade ItemInspecao na base de dados
	 * 
	 * @param item ItemInspecao a ser salvo
	 * @return Item atualizado com a chave primária
	 */
	@LogPerformance
	public ItemInspecao salvaItemInspecao(ItemInspecao item){
		getCurrentSession().persist(item);
		return item;
	}
	
	public List<ItemInspecao> salvaItemInspecao(List<ItemInspecao> itens){
		itens.forEach(item -> salvaItemInspecao(item));
		return itens;
	}
	
	@LogPerformance
	@SuppressWarnings("unchecked")
	public List<ItemInspecao> listaItensInspecaoPorCotacao(BigInteger sequencialCotacaoProposta){
		Query query = getCurrentSession().createQuery(LISTA_ITENS_INSPECAO_POR_COTACAO);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		return (List<ItemInspecao>) query.list();
	}
	
	@LogPerformance
	public ItemInspecao buscaItemInspecaoPorItemCotacao(ItemCotacao itemCotacao){
		return buscaItemInspecaoPorItemCotacao(itemCotacao.getSequencialItemCotacao());
	}
	
	@LogPerformance
	public ItemInspecao buscaItemInspecaoPorItemCotacao(BigInteger sequencialItemCotacao){
		Query query = getCurrentSession().createQuery(BUSCA_ITEM_INSPECAO_POR_ITEM_COTACAO);
		query.setParameter("sequencialItemCotacao", sequencialItemCotacao);
		
		return (ItemInspecao) query.uniqueResult();
	}

	@LogPerformance
	public void excluiItemInspecao(BigInteger idItemInspecao) {
		ItemInspecao itemInspecao = new ItemInspecao();
		itemInspecao.setSequencialItemInspecao(idItemInspecao);
		getCurrentSession().delete(itemInspecao );
	}

	public void update(ItemInspecao itemInspecao) {
		itemInspecao = (ItemInspecao) getCurrentSession().merge(itemInspecao);
		getCurrentSession().flush();
	}

	public Date buscarDataRelatorioUltimaInspecao(ItemCotacao itemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select  max(insp.dataRelatorio) ");
		hql.append(" from 	 ItemInspecao      insp ");
		hql.append(" join    insp.itemCotacao  item ");
		hql.append(" join    item.cotacao	       cota ");    
		hql.append(" where	 cota.codigoApoliceEmitida     = :codigoApoliceRenovada ");
		hql.append(" and     cota.codigoRamoProdutoEmitida = :codigoRamoProdutoRenovada ");
		hql.append(" and     item.numeroItem               = :numeroItemRenovada ");
		hql.append(" and     insp.numeroRelatorio          != null ");
		hql.append(" and	 (insp.idParecer               = :parecerNomal ");
		hql.append(" or      insp.idParecer                = :parecerNomalMelhorias ) ");  

		Query query = getCurrentSession().createQuery(hql.toString());
		
		query.setParameter("codigoApoliceRenovada", itemCotacao.getCodigoApoliceRenovada().longValue());
		query.setParameter("codigoRamoProdutoRenovada", itemCotacao.getCodigoRamoProdutoRenovada());
		query.setParameter("numeroItemRenovada", new BigInteger(itemCotacao.getCodigoItemRenovada().toString()));
		query.setParameter("parecerNomal", ParecerInspecaoEnum.NORMAL);
		query.setParameter("parecerNomalMelhorias", ParecerInspecaoEnum.NORMAL_COM_MELHORIAS);
		
		return (Date) query.uniqueResult();
	}

	@LogPerformance
	@SuppressWarnings("unchecked")
	public List<ItemInspecao> buscarDuplicidadeItemInspecao(ItemCotacao itemCotacao) {
		StringBuilder hql = new StringBuilder();

		hql.append(" select itemInspec ");
		hql.append(" from   ItemInspecao itemInspec "); 
		hql.append(" join   itemInspec.itemCotacao itemCot ");	
		hql.append(" join   itemCot.cotacao cot ");
		hql.append(" where  cot.numeroCotacaoProposta != :numeroCotacaoProposta ");
		hql.append(" and	trunc(cot.dataCotacao) between	trunc(:dataInicio) and trunc(:dataFim) ");
		hql.append(" and	coalesce(cot.codigoSituacao,0) not in (309,314,320,459,433) ");
		hql.append(" and	coalesce(itemCot.idCEPLocalRisco,0) = :idCEPLocalRisco ");
		hql.append(" and	coalesce(itemCot.numeroEnderecoLocalRisco,0) =	:numeroEnderecoLocalRisco ");
		hql.append(" and	coalesce(itemCot.nomeComplementoEnderecoLocalRisco,'XX') = :nomeComplementoEnderecoLocalRisco ");
		hql.append(" and	coalesce(itemCot.codigoRubrica,0) =	:codigoRubrica ");
		hql.append(" and	coalesce(cot.codigoCorretorACSEL,'X') =	:codigoCorretorACSEL ");
		hql.append(" and	itemCot.idTipoPessoa = :idTipoSegurado ");
		hql.append(" and	itemCot.numeroCNPJCPFSegurado =	:numeroCNPJCPFSegurado ");
		hql.append(" and	itemInspec.dataAgendamento is not null ");

		Query query = getCurrentSession().createQuery(hql.toString());

		query.setParameter("numeroCotacaoProposta", itemCotacao.getNumeroCotacaoProposta());
		query.setParameter("dataInicio", DateUtils.addDays(new Date(),-90));
		query.setParameter("dataFim", new Date());
		query.setParameter("idCEPLocalRisco", itemCotacao.getIdCEPLocalRisco() != null ? itemCotacao.getIdCEPLocalRisco() : 0);
		query.setParameter("numeroEnderecoLocalRisco", itemCotacao.getNumeroEnderecoLocalRisco() != null ? itemCotacao.getNumeroEnderecoLocalRisco() : 0);
		query.setParameter("nomeComplementoEnderecoLocalRisco", itemCotacao.getNomeComplementoEnderecoLocalRisco() != null ? itemCotacao.getNomeComplementoEnderecoLocalRisco() : "XX" );
		query.setParameter("codigoRubrica", itemCotacao.getCodigoRubrica() != null ? itemCotacao.getCodigoRubrica() : 0);
		query.setParameter("codigoCorretorACSEL", itemCotacao.getCotacao().getCodigoCorretorACSEL() != null ? itemCotacao.getCotacao().getCodigoCorretorACSEL() : "X");
		query.setParameter("idTipoSegurado", itemCotacao.getIdTipoPessoa());
		query.setParameter("numeroCNPJCPFSegurado", itemCotacao.getNumeroCNPJCPFSegurado());

		return (List<ItemInspecao>) query.list();
	}

	@LogPerformance
	public List<ItemInspecao> findItemInspecaoByNrCotacAndVsCotacAndNrItem(BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta, BigInteger numeroItemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT ii FROM ItemInspecao ii ");
		hql.append(" where ii.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and ii.versaoCotacaoPropostaSolicitacao = :versaoCotacaoProposta");
		hql.append(" and ii.numeroItemSolicitacao = :numeroItemCotacao");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.setParameter("versaoCotacaoProposta",versaoCotacaoProposta);
		query.setParameter("numeroItemCotacao",numeroItemCotacao);
		return (List <ItemInspecao>) query.list();
	}

	public int excluiItemInspecaoPorCotacao(BigInteger numeroCotacaoProposta){
		int retorno = getCurrentSession()
				.createQuery(EXCLUI_ITENS_INSPECAO_POR_COTACAO)
				.setParameter("numeroCotacaoProposta", numeroCotacaoProposta)
				.executeUpdate();
		getCurrentSession().flush();
		return retorno;
	}
	
}
