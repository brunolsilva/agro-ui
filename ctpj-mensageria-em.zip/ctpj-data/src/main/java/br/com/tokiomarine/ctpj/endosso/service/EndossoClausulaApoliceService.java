package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ClausulaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.ClausulaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoClausulaApoliceService {
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	/**
	 * prc_ctp0135
	 */
	public void validarClausulaApolice(Produto produto, Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		boolean endossoPossuiClausulaApolice = endosso.getListClausulaCotacao() != null && !endosso.getListClausulaCotacao().isEmpty();
		boolean apolicePossuiClausulaApolice = apolice.getListClausulaApolice() != null && !apolice.getListClausulaApolice().isEmpty();
		
		//1 - percorre as clausulas apolice do endosso e compara com as da apólice
		//no caso de a apólice possuir mesma clausula que o endosso, porém a versão for diferente, loga que houve alteração
		//no caso de a apólice não possuir uma clausula que o endosso possua, loga que houve inclusão
		if(endossoPossuiClausulaApolice){			
			for(ClausulaCotacao clausCotacao : endosso.getListClausulaCotacao()){
				boolean clausulaExiste = false;
				if(apolicePossuiClausulaApolice){
					for(ClausulaApolice clausApolice : apolice.getListClausulaApolice()){
						if(this.isClausulaEquals(clausApolice, clausCotacao)){
							validacaoParametrosEndossoService.compararParametrosEndossoSemDePara(clausApolice.getDescricao(), clausCotacao.getDescricaoClausula(),TipoMensagemEndossoEnum.ALT_CLAUSULA,produto, endosso, alteracoesEndossoList, user);
							clausulaExiste = true;
							break;
						}						
					}
				}
				
				//se a clausula não existe
				if(!clausulaExiste){
					logarInclusaoClausulaApolice(clausCotacao, produto, endosso, alteracoesEndossoList, user); 
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as clausulas da apólice e compara com as do endosso
		// no caso de o endosso não possuir alguma clausula que está na apólice, loga que a mesma foi excluída 
		if(apolicePossuiClausulaApolice){
			for(ClausulaApolice clausApolice : apolice.getListClausulaApolice()){
				boolean clausulaExiste = false;
				if(endossoPossuiClausulaApolice){
					for(ClausulaCotacao clausCotacao : endosso.getListClausulaCotacao()){
						if(this.isClausulaEquals(clausApolice, clausCotacao)){
							clausulaExiste = true;
							break;
						}
					}
				}
				
				if(!clausulaExiste){
					logarExclusaoClausulaApolice(clausApolice, produto, endosso, alteracoesEndossoList, user);
				}
			}
		}
		//2 - fim
	}//
	
	private boolean isClausulaEquals(ClausulaApolice clausApolice, ClausulaCotacao clausCotacao){
		return AssertUtils.compareNull(clausApolice.getCodigoGrupoRamo(), clausCotacao.getCodigoGrupoRamo()) &&
				AssertUtils.compareNull(clausApolice.getCodigoRamo(), clausCotacao.getCodigoRamo()) &&
				AssertUtils.compareNull(clausApolice.getCodigoClausulaNota(), clausCotacao.getCodigoClausula());
	}
	
	private void logarInclusaoClausulaApolice(ClausulaCotacao clausCotacao, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(clausCotacao.getCodigoClausula()+" do grupo "+clausCotacao.getCodigoGrupoRamo()+" ramo "+clausCotacao.getCodigoRamo());
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, TipoMensagemEndossoEnum.INC_CLAUSULA, descricaoAlteracao.toString(), user));
	}
	
	private void logarExclusaoClausulaApolice(ClausulaApolice clausApolice, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(clausApolice.getCodigoClausulaNota()+" do grupo "+clausApolice.getCodigoGrupoRamo()+" ramo "+clausApolice.getCodigoRamo());
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, TipoMensagemEndossoEnum.EXC_CLAUSULA, descricaoAlteracao.toString(), user));
	}
}
