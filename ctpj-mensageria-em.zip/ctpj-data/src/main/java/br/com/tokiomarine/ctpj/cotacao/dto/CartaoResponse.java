package br.com.tokiomarine.ctpj.cotacao.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CartaoResponse {
	@JsonProperty("id")
	private String id;
	@JsonProperty("number")
	private String numero;
	@JsonProperty("holder")
	private String portador;
	@JsonProperty("expMonth")
	private Integer mesExpiracao;
	@JsonProperty("expYear")
	private Integer anoExpiracao;
	@JsonProperty("cvv")
	private String cvv;
	@JsonProperty("brand")
	private String bandeira;
	@JsonProperty("gateway")
	private String gateway;
	@JsonProperty("customer")
	private ClienteCartao cliente = new ClienteCartao();

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNumero() {
		return this.numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getPortador() {
		return this.portador;
	}

	public void setPortador(String portador) {
		this.portador = portador;
	}

	public Integer getMesExpiracao() {
		return this.mesExpiracao;
	}

	public void setMesExpiracao(Integer mesExpiracao) {
		this.mesExpiracao = mesExpiracao;
	}

	public Integer getAnoExpiracao() {
		return this.anoExpiracao;
	}

	public void setAnoExpiracao(Integer anoExpiracao) {
		this.anoExpiracao = anoExpiracao;
	}

	public String getCvv() {
		return this.cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getBandeira() {
		return this.bandeira;
	}

	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	public String getGateway() {
		return this.gateway;
	}

	public void setGateway(String gateway) {
		this.gateway = gateway;
	}

	public ClienteCartao getCliente() {
		return this.cliente;
	}

	public void setCliente(ClienteCartao cliente) {
		this.cliente = cliente;
	}

	@Override
	public String toString() {
		return "CartaoResponse [id=" + id + ", numero=" + numero + ", portador=" + portador + ", mesExpiracao="
				+ mesExpiracao + ", anoExpiracao=" + anoExpiracao + ", cvv=" + cvv + ", bandeira=" + bandeira
				+ ", gateway=" + gateway + ", cliente=" + cliente + "]";
	}
}