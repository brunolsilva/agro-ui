
package br.com.tokiomarine.ctpj.integracao.crivo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de anonymous complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="riscosHelperVO" type="{http://helper.vo.apps.co.tokiomarine.com.br}RequestGrandesRiscosHelperVO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "riscosHelperVO"
})
@XmlRootElement(name = "execute", namespace = "http://service.co.tokiomarine.com.br")
public class Execute {

    @XmlElement(namespace = "http://service.co.tokiomarine.com.br", required = true)
    protected RequestGrandesRiscosHelperVO riscosHelperVO;

    /**
     * Obt�m o valor da propriedade riscosHelperVO.
     * 
     * @return
     *     possible object is
     *     {@link RequestGrandesRiscosHelperVO }
     *     
     */
    public RequestGrandesRiscosHelperVO getRiscosHelperVO() {
        return riscosHelperVO;
    }

    /**
     * Define o valor da propriedade riscosHelperVO.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestGrandesRiscosHelperVO }
     *     
     */
    public void setRiscosHelperVO(RequestGrandesRiscosHelperVO value) {
        this.riscosHelperVO = value;
    }

}
