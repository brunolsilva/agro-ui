package br.com.tokiomarine.ctpj.infra.mongo.service;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.FormaPagamento;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaPagamentoRepository;

@Service
public class FormaPagamentoService {

	private static Logger logger = LogManager.getLogger(BancoService.class);

	@Autowired
	private FormaPagamentoRepository repository;

	public FormaPagamento findFormaPagamentoByCodigo(Integer codigo)  throws ServiceException{
		try {
			return repository.findFormaPagamentoByCodigo(codigo);
		} catch (RepositoryException e) {
			logger.error("Erro na Busca da Forma de Pagamento by codigo",e);
			throw new ServiceException("Erro na Busca da Forma de Pagamento by codigo",e);
		}
	}

}
