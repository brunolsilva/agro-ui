package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.Ressegurador;

@Repository
public class ResseguradorRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static Logger logger = LogManager.getLogger(ResseguradorRepository.class);

	public List<Ressegurador> findAll() throws RepositoryException {
		try {
			return mongoTemplate.findAll(Ressegurador.class);
		}catch (Exception e) {
			logger.error("Erro na Busca do Ressegurador ", e);
			throw new RepositoryException("Erro na Busca do Ressegurador", e);
		}
	}
	
	public Optional<Ressegurador> findByCodigoRessegurador(Long codigo){
		Query query = query(where("codigo").is(codigo));
		return Optional.ofNullable(mongoTemplate.findOne(query , Ressegurador.class));
	}
}
