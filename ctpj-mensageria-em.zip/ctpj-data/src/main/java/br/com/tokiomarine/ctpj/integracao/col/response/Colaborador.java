package br.com.tokiomarine.ctpj.integracao.col.response;

import java.io.Serializable;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

public class Colaborador implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -1387414833424089567L;

	Integer matricula;

	String nome;

	String cargo;

	SimNaoEnum ferias;

	String depto;

	Integer centroCusto;

	public Integer getMatricula() {
		return matricula;
	}

	public void setMatricula(Integer matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public SimNaoEnum getFerias() {
		return ferias;
	}

	public void setFerias(SimNaoEnum ferias) {
		this.ferias = ferias;
	}

	public String getDepto() {
		return depto;
	}

	public void setDepto(String depto) {
		this.depto = depto;
	}

	public Integer getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(Integer centroCusto) {
		this.centroCusto = centroCusto;
	}

}
