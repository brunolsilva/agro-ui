package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class OpcaoPactoPagtoCotacaoRepository extends BaseDAO {

	public Date findDtMaxAlteracaoItem(BigInteger sequencialCotacaoProposta) {

		Query query = getCurrentSession().createSQLQuery(
				"select max(dt_alter) "
						+ "from ctp0111_item_cotac "
						+ "where sq_cotac_ppota = :sequencialCotacaoProposta ");
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);

		return (Date) query.uniqueResult();
	}

	public Date findDtAlteracaoInicioVigenciaPedido(BigInteger sequencialCotacaoProposta) {

		Query query = getCurrentSession().createSQLQuery(
				"select nvl(dt_alter,dt_inico_vigen) "
				+"from ctp0100_cotac_ppota "
				+"where sq_cotac_ppota = :sequencialCotacaoProposta");
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);

		return (Date) query.uniqueResult();
	}

	public void saveList(List<OpcaoParcelamento> listaOpcaoParcelamentoPagamentoCotacao) {
		for (OpcaoParcelamento opcaoParcelamento : listaOpcaoParcelamentoPagamentoCotacao) {
			getCurrentSession().save(opcaoParcelamento);
		}
	}

	@SuppressWarnings("unchecked")
	public List<OpcaoParcelamento> list(BigInteger codigoCotacao) {
		return (List<OpcaoParcelamento>) getCurrentSession()
				.createQuery("select op from OpcaoParcelamento op where op.cotacao.sequencialCotacaoProposta = :codigoCotacao")
				.setParameter("codigoCotacao", codigoCotacao)
				.list();
	}

	public Date findMinDataTermino(BigInteger sequencialCotacaoProposta) {
		Query query = getCurrentSession().createSQLQuery(
				"select min(dt_fim_vigen) "
						+ "from ctp0111_item_cotac "
						+ "where sq_cotac_ppota = :sequencialCotacaoProposta ");
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);

		return (Date) query.uniqueResult();

	}

	public boolean isEntradaBoleto(BigInteger sequencialCotacaoProposta) throws HibernateException{

		boolean ret = true;

		StringBuilder hql = new StringBuilder();
		hql.append("	select	count(1) ");
		hql.append("	from	OpcaoParcelamento o  ");
		hql.append("	where	o.idparcelamentoescolhido = "+SimNaoEnum.SIM.getId());
		hql.append("	and		o.codigoFormaPagamento = "+1);
		hql.append("	and		o.idEntrada = "+SimNaoEnum.SIM.getId());
		hql.append("	and		o.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");

		Query query  = this.getCurrentSession().createQuery(hql.toString()).setParameter("o.cotacao.sequencialCotacaoProposta",sequencialCotacaoProposta);

		Long count = (Long) query.uniqueResult();
		if(count == null || count.equals(0L)  ){
			ret = false;
		}
		return ret;


	}

}
