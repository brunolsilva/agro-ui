package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

public class CoberturaDanosMateriaisValidator extends BaseCoberturaValidator {

	private static Logger logger = LogManager.getLogger(CoberturaDanosMateriaisValidator.class);

	public List<ValidacaoLote> validacaoDadosCoberturaDM(Cotacao cotacao) {
		logger.info("Início validação coberturas básicas");
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		if(cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
			logger.info("verificaObrigatoriedadeItemUm");
			verificaObrigatoriedadeItemUm(listaValidacao,cotacao);
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				dadosBasicosCoberturaDM(listaValidacao, itemCotacao);
			}
		} else {
			logger.info("verificaObrigatoriedadeItem");
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				if(verificaObrigatoriedade(listaValidacao, itemCotacao)) {
					dadosBasicosCoberturaDM(listaValidacao, itemCotacao);
				}
			}
		}

		return listaValidacao;
	}

	private void dadosBasicosCoberturaDM(List<ValidacaoLote> listaValidacao, ItemCotacao itemCotacao) {
		MoedaEnum moeda = itemCotacao.getCotacao().getCodigoMoeda();
		Map<Integer, Integer> duplicadas = new HashMap<>();
		ajustarCoberturasDuplicadas(itemCotacao);
		for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
			if(duplicadas.put(itemCobertura.getCodigoCobertura(), 1) != null) {
				logger.info("duplicidade " + "");
				listaValidacao.add(new ValidacaoLote(
						itemCotacao.getNumeroItem().intValue(),
						String.format("Favor verificar se a cobertura %s foi incluída mais de uma vez para este local de risco", 
								itemCobertura.getDescricaoCobertura())));
				break;
			}
		}

		for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
			if(verificaDadosBasicos(itemCobertura)) {
				if(itemCobertura.getCodigoCobertura() == null) {
					listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), "Obrigatório informar a Cobertura Danos Materiais"));
				} else if(itemCobertura.getIdCoberturaAvulsa() == SimNaoEnum.NAO) {
					validaValoresCoberturaDM(itemCobertura, moeda, listaValidacao, itemCotacao.getNumeroItem().intValue());
				} else if(itemCobertura.getIdCoberturaAvulsa() == SimNaoEnum.SIM && !StringUtils.isEmpty(itemCobertura.getDescricaoCobertura())) {
					validaCoberturaCoberturaAvulsa(itemCobertura, listaValidacao, itemCotacao.getNumeroItem().intValue());
					validaValoresCoberturaDM(itemCobertura, moeda, listaValidacao, itemCotacao.getNumeroItem().intValue());
				}
			}
		}
	}
	
	private boolean possuiCoberturasDuplicadas(ItemCotacao itemCotacao) {
		HashSet<Integer> codigosCobertura = new HashSet<>();
		for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
			if(!codigosCobertura.add(itemCobertura.getCodigoCobertura())) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * se houver alguma cobertura excluída que tenha sido adicionada novamente, reativa a excluída com os dados da cobertura adicionada.
	 * @param itemCotacao
	 */
	private void ajustarCoberturasDuplicadas(ItemCotacao itemCotacao) {
		if(possuiCoberturasDuplicadas(itemCotacao)) {
			//Coberturas Inativas = coberturas excluídas (ic_exclu_endos)
			List<ItemCobertura> coberturasInativas = itemCotacao.getListItemCobertura().stream().filter(c -> c.getIdExclusaEndosso().equals(SimNaoEnum.SIM)).collect(Collectors.toList());
			
			for(ItemCobertura cobertura : coberturasInativas) {
				Optional<ItemCobertura> optItemCobertura = itemCotacao.getListItemCobertura().stream().filter(c -> c.getIdExclusaEndosso().equals(SimNaoEnum.NAO) && c.getCodigoCobertura().equals(cobertura.getCodigoCobertura())).findFirst();
				if(optItemCobertura.isPresent()) {
					ItemCobertura itemCoberturaExcluir = optItemCobertura.get();
					bindCoberturas(itemCoberturaExcluir, cobertura);
					itemCotacao.getListItemCobertura().remove(itemCoberturaExcluir);
				}
			}
		}

	}
	
	private void bindCoberturas(ItemCobertura origem, ItemCobertura destino) {
		destino.setIdCoberturaAvulsa(origem.getIdCoberturaAvulsa());
		destino.setDescricaoComplementoCobertura(origem.getDescricaoComplementoCobertura());
		destino.setCodigoGrupoRamoContabil(origem.getCodigoGrupoRamoContabil());
		destino.setCodigoRamoCoberturaContabil(origem.getCodigoRamoCoberturaContabil());
		destino.setCodigoGrupoRamoEmissao(origem.getCodigoGrupoRamoEmissao());
		destino.setCodigoRamoCoberturaEmissao(origem.getCodigoRamoCoberturaEmissao());
		destino.setValorImportanciaSegurada(origem.getValorImportanciaSegurada());
		destino.setValorSublimite(origem.getValorSublimite());
		destino.setValorSublimiteOriginal(origem.getValorSublimiteOriginal());
		destino.setNumeroMultiploFranquia(origem.getNumeroMultiploFranquia());
		destino.setNumeroMultiploPrejuizo(origem.getNumeroMultiploPrejuizo());
		destino.setIdFormaFranquia(origem.getIdFormaFranquia());
		destino.setNumeroHorasFranquia(origem.getNumeroHorasFranquia());
		destino.setNumeroDiasFranquia(origem.getNumeroDiasFranquia());
		destino.setTaxaFranquia(origem.getTaxaFranquia());
		destino.setValorFranquia(origem.getValorFranquia());
		destino.setValorFranquiaMinima(origem.getValorFranquiaMinima());
		destino.setValorFranquiaMaxima(origem.getValorFranquiaMaxima());
		destino.setTaxaImportanciaSegurada(origem.getTaxaImportanciaSegurada());
		destino.setTaxaImportanciaSeguradaMinima(origem.getTaxaImportanciaSeguradaMinima());
		destino.setTaxaImportanciaSeguradaMaxima(origem.getTaxaImportanciaSeguradaMaxima());
		destino.setIdTextoFranquia(origem.getIdTextoFranquia());
		destino.setDescricaoTextoFranquia(origem.getDescricaoTextoFranquia());
		destino.setCodigoPeriodoIndenitario(origem.getCodigoPeriodoIndenitario());
		destino.setIdLMR(origem.getIdLMR());
		destino.setValorPremio(origem.getValorPremio());
		destino.setValorPremioVigencia(origem.getValorPremioVigencia());
		destino.setValorPremioNET(origem.getValorPremioNET());
		destino.setValorPremioNETMoedaEstrangeira(origem.getValorPremioNETMoedaEstrangeira());
		destino.setValorPremioReferencial(origem.getValorPremioReferencial());
		destino.setPercentualPremioDepositoMinimo(origem.getPercentualPremioDepositoMinimo());
		destino.setValorISMoedaEstrangeira(origem.getValorISMoedaEstrangeira());
		destino.setValorPremioMoedaEstrangeira(origem.getValorPremioMoedaEstrangeira());
		destino.setPercentualTaxaCalculoPremio(origem.getPercentualTaxaCalculoPremio());
		destino.setValorSublimiteMoedaEstrangeira(origem.getValorSublimiteMoedaEstrangeira());
		destino.setValorSublimiteOriginalMoedaEstrangeira(origem.getValorSublimiteMoedaEstrangeira());
		destino.setIdDanosMateriais(origem.getIdDanosMateriais());
		destino.setIdLucrosCessantes(origem.getIdLucrosCessantes());
		destino.setIdTipoCobertura(origem.getIdTipoCobertura());
		destino.setIdExigeOficio(origem.getIdExigeOficio());
		destino.setCodigoRessegurador(origem.getCodigoRessegurador());
		destino.setIdOficioRessegurador(origem.getIdOficioRessegurador());
		destino.setDataEmissaoOficio(origem.getDataEmissaoOficio());
		destino.setDescricaoFranquia(origem.getDescricaoFranquia());
		destino.setValorRiscoBem(origem.getValorRiscoBem());
		destino.setValorRiscoBemMoedaEstrangeira(origem.getValorRiscoBemMoedaEstrangeira());
		destino.setIdExclusaEndosso(origem.getIdExclusaEndosso());
		destino.setIdFranquiaInformado(origem.getIdFranquiaInformado());
		destino.setIdLmrDiferente(origem.getIdLmrDiferente());
		destino.setNumeroVagasGaragem(origem.getNumeroVagasGaragem());
		destino.setIdSublimiteInformado(origem.getIdSublimiteInformado());
		destino.setIdOrigemApolice(origem.getIdOrigemApolice());
		destino.setIdAjustamentoPremio(origem.getIdAjustamentoPremio());
		destino.setValorPremioParteFixa(origem.getValorPremioParteFixa());
		destino.setValorPremioParteAjustavel(origem.getValorPremioParteAjustavel());
		destino.setCoberturaPrincipal(origem.getCoberturaPrincipal());
		destino.setIdControleExclusaoEndosso(origem.getIdControleExclusaoEndosso());
	}

	private boolean verificaDadosBasicos(ItemCobertura itemCobertura) {
		return itemCobertura.getIdTipoCobertura() != null && !itemCobertura.getIdTipoCobertura().equals(1);
	}

	//TODO verificar exclusão endosso
	private boolean verificaObrigatoriedade(List<ValidacaoLote> listaValidacao, ItemCotacao itemCotacao) {
		logger.info("verificaObrigatoriedade");
		if(itemCotacao.getListItemCobertura().stream().filter(it -> it.getIdTipoCobertura() != null && it.getIdTipoCobertura() > 1).count() == 0L) {
			listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), "Obrigatório informar pelo menos uma Cobertura Adicional"));
			return false;
		}

		return true;
	}

	private boolean verificaObrigatoriedadeItemUm(List<ValidacaoLote> listaValidacao, Cotacao cotacao) {
		ItemCotacao itemCotacao = cotacao.getListItem().stream()
				.filter(it -> it.getNumeroItem().equals(BigInteger.ONE))
				.findAny().orElseThrow(() -> new RuntimeException("Não possui item 1 " + cotacao.getSequencialCotacaoProposta()));
		if(itemCotacao.getListItemCobertura().stream().filter(it -> it.getIdTipoCobertura() != null && it.getIdTipoCobertura() > 1).count() == 0L) {
			listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), "Obrigatório informar pelo menos uma Cobertura Adicional"));
			return false;
		}

		return true;
	}
}