package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.form.RenumeracaoItensForm;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.ItemCotacaoRenumeracaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping(value = "/renumeracao")
public class RenumeracaoItensController extends AbstractController {
	
	
	private static Logger logger = LogManager.getLogger(RenumeracaoItensController.class);
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private ItemCotacaoRenumeracaoService itemCotacaoHistoricoService;
	
	
	@LogPerformance
	@GetMapping(value = "/{sqCotacao}")
	public String renumeracao(@ModelAttribute("renumeracaoItensForm") RenumeracaoItensForm form,@PathVariable BigInteger sqCotacao, ModelMap model, HttpServletRequest request) {
		String view = Paginas.renumeracaoItens.value();
		try {
			
			logger.info("entrada /renumeracao/"+sqCotacao);
			
			Cotacao cotacao = cotacaoService.findCotacaoComItemRenumeracao(sqCotacao);
			
			model.addAttribute("cotacao", cotacao);
			model.addAttribute("produto", cotacao.getNomeProduto());
			model.addAttribute("numeroCotacaoProposta", cotacao.getNumeroCotacaoProposta());
			model.addAttribute("sqCotacao", cotacao.getSequencialCotacaoProposta());
			model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(cotacao.getSequencialCotacaoProposta()));
		} catch (Exception e) {
			logger.error("Erro ao renumerar Itens da cotação: ", e);
			view = Paginas.error.value();
		}
		return view;
	}
	
	@LogPerformance
	@PostMapping(value = "/renumerarItens")
	public String renumerarItens(@ModelAttribute("renumeracaoItensForm") RenumeracaoItensForm form, ModelMap model, HttpServletRequest request) {
		String view = Paginas.renumeracaoItens.value();
		try {
			
			logger.info("/renumerarItens");
			
			form.setUser(super.getUser());
			
			
			itemCotacaoHistoricoService.backupNumeracaoItemCotacao(form);
			
			itemCotacaoHistoricoService.renumeraItemCotacao(form);
			
			Cotacao cotacao = cotacaoService.findCotacaoComItemRenumeracao(form.getSequencialCotacaoProposta());
			
			model.addAttribute("cotacao", cotacao);
			model.addAttribute("produto", cotacao.getNomeProduto());
			model.addAttribute("numeroCotacaoProposta", cotacao.getNumeroCotacaoProposta());
			model.addAttribute("sqCotacao", cotacao.getSequencialCotacaoProposta());
			model.addAttribute("msgRenumeracao", "Itens renumerados com sucesso!");
		} catch (Exception e) {
			logger.error("Erro ao renumerar Itens da cotação: ", e);
			view = Paginas.error.value();
		}
		return view;
	}

}
