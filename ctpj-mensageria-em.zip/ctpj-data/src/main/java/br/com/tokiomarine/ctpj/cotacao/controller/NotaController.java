package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemNotaView;
import br.com.tokiomarine.ctpj.cotacao.dto.NotaCotacaoEIemForm;
import br.com.tokiomarine.ctpj.cotacao.dto.NotaCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.NotaCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

@RequestMapping(value = "/nota")
@Controller
public class NotaController extends AbstractController {
	
	private static Logger logger= LogManager.getLogger(NotaController.class);
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private NotaCotacaoService notaCotacaoService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;
	
	@LogPerformance
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String notas(@PathVariable BigInteger sequencialCotacaoProposta, Model model) {

		try {
			Cotacao cotacao = cotacaoService.findCotacaoComItensCotacao(sequencialCotacaoProposta);
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				cotacao.setListItem(
						cotacao.getListItem().stream()
							.filter(it -> Arrays.asList(1,6).contains(it.getIdTipoEndosso()))
							.collect(Collectors.toSet()));
			}
			List<ItemCotacao> listItem = cotacaoService.findItensCotacaoAndItemNotas(sequencialCotacaoProposta);
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				listItem = new ArrayList<>(listItem.stream()
						.filter(it -> Arrays.asList(1,6).contains(it.getIdTipoEndosso()))
						.collect(Collectors.toList()));
			}
			Optional<BigInteger> numeroMinimo = listItem.stream().map(ItemCotacao::getNumeroItem).min(Comparator.naturalOrder());
			List<ItemNotaView> itensNotasView = notaCotacaoService.getListItensNotaView(listItem, numeroMinimo.isPresent() ? numeroMinimo.get(): BigInteger.ONE);

			List<ItemCotacao> listItens = null;
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
				listItens = cotacao.getListItem()
						.stream()
						.sorted(Comparator.comparing(ItemCotacao::getNumeroItem))
						.collect(Collectors.toList());
			} else {
				listItens = cotacao.getListItem()
						.stream()
						.filter(it -> Arrays.asList(1,6).contains(it.getIdTipoEndosso()))
						.sorted(Comparator.comparing(ItemCotacao::getNumeroItem))
						.collect(Collectors.toList());
			}			
			model.addAttribute("listItens", listItens);
			model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(cotacao.getSequencialCotacaoProposta()));
			model.addAttribute("cotacao", cotacao);
			model.addAttribute("itensNotasView", itensNotasView);
			model.addAttribute("readOnly",isReadOnly(cotacao));
		} catch (Exception e) {
			logger.error("Erro ao recuperar as ItemNotas/NotaCotacao ", e);
			return Paginas.error.value();
		}
		
		return Paginas.nota.value();
	}
	
	private boolean isReadOnly(Cotacao cotacao) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario);
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se é usuário do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}
	
	@LogPerformance
	@GetMapping(value = "/delete/{sequencialNota}/{isItem}")
	public ResponseEntity<ResultadoREST<String>> delete(@PathVariable BigInteger sequencialNota,@PathVariable boolean isItem) {

		logger.info("Inicio delete Nota da Cotação");

		ResultadoREST<String> resultado = new ResultadoREST<>();

		try {
			notaCotacaoService.deleteNotaCotacao(sequencialNota,isItem);
			resultado.setMensagem("Nota da Cotação excluido com Sucesso!");
			resultado.setSuccess(true);
		} catch(Exception e) {
			logger.error("Erro do deletar nota cotação ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}

		logger.info("Fim do delete Nota Cotação");

		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}
		
	@LogPerformance
	@PostMapping(value = "/saveNota/{isItem}")
	public @ResponseBody ResultadoREST<String> saveNota(@RequestBody NotaCotacaoEIemForm notaForm,@PathVariable boolean isItem) {
		ResultadoREST<String> resultado = new ResultadoREST<>();
		try {
			if(!StringUtils.isBlank(notaForm.getNota().getNota())) {
				notaCotacaoService.saveNota(notaForm,isItem);
			}
			resultado.setSuccess(true);
		} catch (Exception e) {
			resultado.setSuccess(false);
			logger.error("Erro ao salvar nota cotacao ",e);
		}
		return resultado;
	}
	
	@LogPerformance
	@GetMapping(value = "/findByItem/{sequencialItemCotacao}")
	public ResponseEntity<ResultadoREST<ItemNotaView>> findByItem(@PathVariable BigInteger sequencialItemCotacao) {
		ResultadoREST<ItemNotaView> resultado = new ResultadoREST<>();
		try {
			ItemCotacao itemCotacao = cotacaoService.findItensCotacaoAndItemNotaBySequencialItemCotacao(sequencialItemCotacao);
			List<ItemNotaView> itensNotasview = notaCotacaoService.getListItensNotaView(itemCotacao);
			resultado.setListaRetorno(itensNotasview);
			resultado.setSuccess(true);
		} catch (Exception e) {
			resultado.setSuccess(false);
			logger.error("Erro ao Buscar Nota ",e);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}
	
	@LogPerformance
	@GetMapping(value = "/findByCotacao/{sequencialCotacaoProposta}")
	public ResponseEntity<ResultadoREST<NotaCotacaoView>> findByCotacao(@PathVariable BigInteger sequencialCotacaoProposta) {
		ResultadoREST<NotaCotacaoView> resultado = new ResultadoREST<>();
		try {
			Cotacao cotacao = cotacaoService.findCotacaoNotas(sequencialCotacaoProposta);
			List<NotaCotacaoView> notas = notaCotacaoService.getListNotaCotacaoView(cotacao);
			resultado.setListaRetorno(notas);
			resultado.setSuccess(true);
		} catch (Exception e) {
			resultado.setSuccess(false);
			logger.error("Erro ao Buscar Nota ",e);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}
	
	@LogPerformance
	@PostMapping(value = "/atualizarNota/{isItem}")
	public @ResponseBody ResultadoREST<String> atualizarNota(@RequestBody NotaCotacaoEIemForm notaForm,@PathVariable boolean isItem) {
		ResultadoREST<String> resultado = new ResultadoREST<>();
		try {
			notaCotacaoService.atualizarNota(notaForm,isItem);
			resultado.setSuccess(true);
		} catch (Exception e) {
			resultado.setSuccess(false);
			logger.error("Erro ao atualizar nota cotação ",e);
		}
		return resultado;
	}
	
}
