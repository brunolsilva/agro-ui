package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaCalculo;
import br.com.tokiomarine.ctpj.infra.mongo.repository.MemoriaCalculoRepository;
import br.com.tokiomarine.ctpj.mapper.MemoriaCalculoMapper;

/**
 * Serviços relacionados a memória cálculo
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Service
public class MemoriaCalculoService {

	@Autowired
	private MemoriaCalculoRepository repository;
	
	/**
	 * Salva uma Memória Cálculo relacionada a uma determinada cotação
	 * 
	 * @param cotacao Cotação para a qual será salva uma memória Cálculo. Observação: Esta o objeto da Cotação deve estar completo (não pode ser proxy que representam seus atributos)
	 */
	public void salvaMemoriaCalculoDe(Cotacao cotacao){
		repository.save(MemoriaCalculoMapper.getInstance().createFrom(cotacao));
	}
	
	/**
	 * Busca memória cálculos
	 * 
	 * @param seqCotacao identificador da Cotação para a qual queremos recuperar a mémoria cálculo
	 * @return a Memória Cálculo para uma determinada cotação
	 */
	public MemoriaCalculo buscaMemorias(BigInteger seqCotacao) {
		return repository.findOne(seqCotacao);
	}

}
