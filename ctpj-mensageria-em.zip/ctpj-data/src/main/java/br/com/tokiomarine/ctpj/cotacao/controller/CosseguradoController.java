package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCosseguradoView;
import br.com.tokiomarine.ctpj.cotacao.service.CosseguradoService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.FranquiaService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ControllerInternalErrorException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.mapper.ItemCosseguradoMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

/**
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Controller
@RequestMapping("/cossegurado")
public class CosseguradoController {
	private static final Logger logger = LogManager.getLogger(CosseguradoController.class);
	@Autowired
	private FranquiaService franquiaService;
	@Autowired
	private CosseguradoService cosseguradoService;
	@Autowired
	private ItemCosseguradoMapper mapper;
	@Autowired
	private CotacaoService cotacaoService;
	@Autowired
	private PerfilComercialService perfilComercialService;	
	
	@GetMapping("/{idCotacao}")
	public String home(@PathVariable("idCotacao") BigInteger sequencialCotacaoProposta,  Model model){
		List<ItemCotacao> itens;
		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(sequencialCotacaoProposta);
			itens = franquiaService.getItemsComEndereco(sequencialCotacaoProposta);
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			model.addAttribute("readOnly", isReadOnly(cotacaoView));
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}
		List<ItemCosseguradoView> itensCossegurados = mapper.toListOfItemCosseguradoView(cosseguradoService.listaItensCosseguradoPorCotacao(sequencialCotacaoProposta));
		model.addAttribute("itensCotacao", itens);
		model.addAttribute("sequencialCotacaoProposta", sequencialCotacaoProposta);
		model.addAttribute("itensCossegurados",itensCossegurados);
		return Paginas.cossegurado.value();
	}
	
	private boolean isReadOnly(CotacaoView cotacaoView) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario) && !cotacaoView.getCodigoSituacaoReadOnly().equals(CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao().intValue());
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se � usu�rio do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}
	
	@PostMapping("/itens")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<?> salvaItemCossegurado(@RequestBody @Valid ItemCosseguradoView itemView){
		ItemCossegurado itemCossegurado = mapper.toItemCossegurado(itemView);
		
		if(!itemView.getIncluirParaTodos()){
			ItemCossegurado itemIncluso = cosseguradoService.incluiItemCossegurado(itemCossegurado);
			return ResponseEntity.ok(mapper.toItemCosseguradoView(itemIncluso));
		}		
		
		try {
			List<ItemCossegurado> itensInclusos = cosseguradoService.incluiItemCosseguradoParaTodosItensDaCotacao(itemCossegurado, itemView.getSequencialCotacaoProposta());
			return ResponseEntity.ok(mapper.toListOfItemCosseguradoView(itensInclusos));
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}		
		
	}
	
	@DeleteMapping("/itens/{idItemCossegurado}")
	@ResponseStatus(HttpStatus.OK)
	public void excluiItemCossegurado(@PathVariable("idItemCossegurado") BigInteger idItemCossegurado){
		cosseguradoService.excluiItemCossegurado(idItemCossegurado);
	}
	
	@ModelAttribute(name="tiposPessoa")
	private List<TipoSeguradoEnum> getTipoPessoa(){
		return Arrays.asList(TipoSeguradoEnum.values());
	}

}
