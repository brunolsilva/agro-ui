package br.com.tokiomarine.ctpj.dto;

import java.util.Date;

public class RetornoCorretorFranqueador {

	private Integer codModProduto;
	private String codCorretor;
	private Date dataReferencia;
	
	public RetornoCorretorFranqueador(Integer codModProduto, String codCorretor, Date dataReferencia) {
		super();
		this.codModProduto = codModProduto;
		this.codCorretor = codCorretor;
		this.dataReferencia = dataReferencia;
	}

	public Integer getCodModProduto() {
		return codModProduto;
	}
	
	public void setCodModProduto(Integer codModProduto) {
		this.codModProduto = codModProduto;
	}
	
	public String getCodCorretor() {
		return codCorretor;
	}
	
	public void setCodCorretor(String codCorretor) {
		this.codCorretor = codCorretor;
	}
	
	public Date getDataReferencia() {
		return dataReferencia;
	}
	
	public void setDataReferencia(Date dataReferencia) {
		this.dataReferencia = dataReferencia;
	}

}
