package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemCotacaoPremioFranquiaView implements Serializable {

	private static final long serialVersionUID = 7989564235520374411L;

	private BigInteger sequencialItemCotacao;
	private BigInteger numeroItem;
	private TipoSeguroEnum idTipoSeguro;
	private String idCEPLocalRisco;
	private String enderecoLocalRisco;
	private String nomeBairroLocalRisco;
	private Long numeroEnderecoLocalRisco;
	private String nomeComplementoEnderecoLocalRisco;
	private Integer codigoMunicipioLocalRisco;
	private String nomeMunicipioLocalRisco;
	private String idUFLocalRisco;
	private String descricaoItem;
	private List<ItemCoberturaPremioFranquiaView> listCoberturaBasica = new ArrayList<>();
	private List<ItemCoberturaPremioFranquiaView> listCoberturaDemais = new ArrayList<>();

	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}

	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}

	public BigInteger getNumeroItem() {
		return numeroItem;
	}

	public void setNumeroItem(BigInteger numeroItem) {
		this.numeroItem = numeroItem;
	}

	public TipoSeguroEnum getIdTipoSeguro() {
		return idTipoSeguro;
	}

	public void setIdTipoSeguro(TipoSeguroEnum idTipoSeguro) {
		this.idTipoSeguro = idTipoSeguro;
	}

	public String getIdCEPLocalRisco() {
		if (idCEPLocalRisco != null && !idCEPLocalRisco.isEmpty()) {
			try {
				idCEPLocalRisco = StringUtils.leftPad(idCEPLocalRisco.replaceAll("-",""),8,"0");
			} catch (Exception e) {
				idCEPLocalRisco = null;
			}
		} else {
			idCEPLocalRisco = null;
		}
		return idCEPLocalRisco;
	}

	public void setIdCEPLocalRisco(String idCEPLocalRisco) {
		this.idCEPLocalRisco = idCEPLocalRisco;
	}

	public String getEnderecoLocalRisco() {
		return enderecoLocalRisco;
	}

	public void setEnderecoLocalRisco(String enderecoLocalRisco) {
		this.enderecoLocalRisco = enderecoLocalRisco;
	}

	public String getNomeBairroLocalRisco() {
		return nomeBairroLocalRisco;
	}

	public void setNomeBairroLocalRisco(String nomeBairroLocalRisco) {
		this.nomeBairroLocalRisco = nomeBairroLocalRisco;
	}

	public Long getNumeroEnderecoLocalRisco() {
		return numeroEnderecoLocalRisco;
	}

	public void setNumeroEnderecoLocalRisco(Long numeroEnderecoLocalRisco) {
		this.numeroEnderecoLocalRisco = numeroEnderecoLocalRisco;
	}

	public String getNomeComplementoEnderecoLocalRisco() {
		return nomeComplementoEnderecoLocalRisco;
	}

	public void setNomeComplementoEnderecoLocalRisco(String nomeComplementoEnderecoLocalRisco) {
		this.nomeComplementoEnderecoLocalRisco = nomeComplementoEnderecoLocalRisco;
	}

	public Integer getCodigoMunicipioLocalRisco() {
		return codigoMunicipioLocalRisco;
	}

	public void setCodigoMunicipioLocalRisco(Integer codigoMunicipioLocalRisco) {
		this.codigoMunicipioLocalRisco = codigoMunicipioLocalRisco;
	}

	public String getNomeMunicipioLocalRisco() {
		return nomeMunicipioLocalRisco;
	}

	public void setNomeMunicipioLocalRisco(String nomeMunicipioLocalRisco) {
		this.nomeMunicipioLocalRisco = nomeMunicipioLocalRisco;
	}

	public String getIdUFLocalRisco() {
		return idUFLocalRisco;
	}

	public void setIdUFLocalRisco(String idUFLocalRisco) {
		this.idUFLocalRisco = idUFLocalRisco;
	}

	public Long getIdCEPLocalRiscoNumero() {
		if(getIdCEPLocalRisco() != null && !getIdCEPLocalRisco().isEmpty()) {
			return Long.valueOf(idCEPLocalRisco);
		} else {
			return null;
		}
	}

	public void setDescricaoItem(String descricaoItem) {
		this.descricaoItem = descricaoItem;
	}

	public String getDescricaoItem() {
		StringBuilder sb = new StringBuilder();
		sb.append("Item: ").append(this.numeroItem);
		sb.append(this.enderecoLocalRisco != null && !this.enderecoLocalRisco.isEmpty() ? " - "+this.enderecoLocalRisco : ""); 
		sb.append(this.numeroEnderecoLocalRisco != null ? ", "+this.numeroEnderecoLocalRisco : ""); 
		sb.append(this.nomeBairroLocalRisco != null && !this.nomeBairroLocalRisco.isEmpty() ? " - "+this.nomeBairroLocalRisco : ""); 
		sb.append(this.idUFLocalRisco != null && !this.idUFLocalRisco.isEmpty() ? " - "+this.idUFLocalRisco : ""); 
		sb.append(this.idCEPLocalRisco != null && !this.idCEPLocalRisco.isEmpty() ? " - "+this.idCEPLocalRisco : ""); 
		return sb.toString(); 
	}

	public List<ItemCoberturaPremioFranquiaView> getListCoberturaDemais() {
		return listCoberturaDemais;
	}

	public void setListCoberturaDM(List<ItemCoberturaPremioFranquiaView> listCoberturaDemais) {
		this.listCoberturaDemais = listCoberturaDemais;
	}

	public List<ItemCoberturaPremioFranquiaView> getListCoberturaBasica() {
		return listCoberturaBasica;
	}

	public void setListCoberturaBasica(List<ItemCoberturaPremioFranquiaView> listCoberturaBasica) {
		this.listCoberturaBasica = listCoberturaBasica;
	}

}