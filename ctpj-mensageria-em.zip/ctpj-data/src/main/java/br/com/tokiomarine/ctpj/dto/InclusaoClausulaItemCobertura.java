package br.com.tokiomarine.ctpj.dto;

public class InclusaoClausulaItemCobertura{
	private Integer valorCaracteristica;
	private Integer clausulaNota;
	private Integer codCobertura;	
	private String descricaoClausula;
	private boolean imprime;	

	public Integer getValorCaracteristica() {
		return valorCaracteristica;
	}

	public void setValorCaracteristica(Integer valorCaracteristica) {
		this.valorCaracteristica = valorCaracteristica;
	}

	public Integer getClausulaNota() {
		return clausulaNota;
	}

	public void setClausulaNota(Integer clausulaNota) {
		this.clausulaNota = clausulaNota;
	}

	public Integer getCodCobertura() {
		return codCobertura;
	}

	public void setCodCobertura(Integer codCobertura) {
		this.codCobertura = codCobertura;
	}

	public String getDescricaoClausula() {
		return descricaoClausula;
	}

	public void setDescricaoClausula(String descricaoClausula) {
		this.descricaoClausula = descricaoClausula;
	}

	public boolean isImprime() {
		return imprime;
	}

	public void setImprime(boolean imprime) {
		this.imprime = imprime;
	}

}
