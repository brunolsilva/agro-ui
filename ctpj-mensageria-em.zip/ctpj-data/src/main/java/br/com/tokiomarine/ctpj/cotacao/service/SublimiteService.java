package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaAdicionar;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemSublimiteView;
import br.com.tokiomarine.ctpj.cotacao.dto.SublimiteView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.SublimiteRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCobertura;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CoberturaRepository;
import br.com.tokiomarine.ctpj.mapper.CoberturaViewMapper;
import br.com.tokiomarine.ctpj.mapper.NumberMapper;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class SublimiteService {

	private static Logger logger = LogManager.getLogger(SublimiteService.class);

	@Autowired
	private SublimiteRepository sublimiteRepository;

	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private CoberturaRepository coberturaRepository;

	@LogPerformance
	public ResultadoREST<String> saveSublimite(List<ItemSublimiteView> sublimites) throws ServiceException {
		try {
			ResultadoREST<String> resultado = new ResultadoREST<>();
			List<ValidacaoLote> listaValidacao = validaSublimite(sublimites);
			
			if(listaValidacao.isEmpty()) {
				sublimiteRepository.saveSublimite(sublimites, sublimites.get(0).getSqCotacao());
				resultado.setSuccess(true);
			} else {
				resultado.setSuccess(false);
				resultado.setListaValidacaoLote(listaValidacao);
			}
			return resultado;
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	public Map<String, List<SublimiteView>> getSublimites(BigInteger sqCotacao) throws ServiceException {
		try {
			List<SublimiteView> sublimites = sublimiteRepository.getSublimites(sqCotacao);
			List<ItemCotacao> itemsCotacao = cotacaoRepository.getItemsComEndereco(sqCotacao);
			final List<ItemCotacao> itemsCotacaoFiltrados;
			final List<SublimiteView> sublimitesFiltrados;

			List<ProdutoCobertura> produtosCobertura = new ArrayList<>();
			
			if(!itemsCotacao.isEmpty()) {
				if(itemsCotacao.get(0).getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
					sublimitesFiltrados = new ArrayList<>(sublimites.stream()
							.filter(it -> it.getIdExclusaEndosso() == SimNaoEnum.NAO)
							.collect(Collectors.toList()));
					itemsCotacaoFiltrados = new ArrayList<>(
							itemsCotacao.stream()
							.filter(it -> Arrays.asList(1,6).contains(it.getIdTipoEndosso()))
							.collect(Collectors.toList()));
				} else {
					itemsCotacaoFiltrados = new ArrayList<>(itemsCotacao);
					sublimitesFiltrados = new ArrayList<>(sublimites);
				}
				List<Integer> codigosCobertura = sublimitesFiltrados.stream().map(SublimiteView::getCodigoCobertura).distinct().collect(Collectors.toList());
				produtosCobertura = coberturaRepository.findProdutoCobertura(itemsCotacao.get(0).getCotacao().getCodigoProduto(),codigosCobertura);
			} else {
				itemsCotacaoFiltrados = new ArrayList<>(itemsCotacao);
				sublimitesFiltrados = new ArrayList<>(sublimites);
			}

			List<Integer> coberturasItemUm = sublimitesFiltrados.stream()
					.filter(sub -> sub.getNumeroItem().equals(BigInteger.ONE))
					.map(SublimiteView::getCodigoCobertura)
					.collect(Collectors.toList());

			List<BigInteger> items = sublimitesFiltrados.stream()
					.map(SublimiteView::getNumeroItem)
					.distinct()
					.collect(Collectors.toList());

			for(SublimiteView sub: sublimitesFiltrados) {
				sub.setItems(items);
			}

			List<SublimiteView> sublimitesFiltrados2 = sublimitesFiltrados.stream()
					.filter(sub -> coberturasItemUm.contains(sub.getCodigoCobertura()))
					.collect(Collectors.toList());

			Map<String, List<SublimiteView>> sublimitesPorLinha = sublimitesFiltrados2.stream()
					.collect(
							Collectors.groupingBy(SublimiteView::getDescricaoCobertura,LinkedHashMap::new,Collectors.toList()));

			for(final BigInteger numeroItem: items) {
				sublimitesPorLinha.forEach((k,v) -> {
					List<BigInteger> itemsSubLimite = v.stream().map(SublimiteView::getNumeroItem).collect(Collectors.toList());
					if(!itemsSubLimite.contains(numeroItem)) {
						Integer codigoCobertura = v.stream()
								.filter(s -> s.getNumeroItem().equals(BigInteger.ONE))
								.map(SublimiteView::getCodigoCobertura)
								.findFirst()
								.orElse(null);

						BigInteger sequencialItemCotacao = itemsCotacaoFiltrados.stream()
								.filter(i -> i.getNumeroItem().equals(numeroItem))
								.map(ItemCotacao::getSequencialItemCotacao)
								.findAny()
								.orElse(null);

						v.add(new SublimiteView(numeroItem, codigoCobertura, sequencialItemCotacao));
					}
				});
			}

			for(ProdutoCobertura produtoCobertura: produtosCobertura) {
				List<SublimiteView> svs = sublimitesPorLinha.values().stream().flatMap(it -> it.stream()).collect(Collectors.toList());
				for(SublimiteView sv: svs) {
					if(sv.getCodigoCobertura().equals(produtoCobertura.getCobertura())) {
						sv.setLiberaSublimite(produtoCobertura.getLiberaSublimite().getLogical());
					}
				}
			}

			sublimitesPorLinha.values().forEach(it -> it.sort(Comparator.comparing(SublimiteView::getNumeroItem)));
			
			return sublimitesPorLinha;
		} catch (Exception e) {
			logger.error("Erro ao carregar os sublimites ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	public ResultadoREST<SublimiteView> adicionaCobertura(CoberturaAdicionar coberturaAdicionar) throws ServiceException {
		logger.info("Inicio adicionaCobertura " + coberturaAdicionar);
		ResultadoREST<SublimiteView> resultado = new ResultadoREST<>();

		try {
			/**
			 * Recuperar os pais dessa cobertura no cliente
			 * Recuperar todas as coberturas do item
			 * Se não tem algum dos pais, alerta
			 */
			ItemCobertura itemUmCobertura = itemCoberturaRepository.findCoberturaItemUm(coberturaAdicionar.getCotacao(),coberturaAdicionar.getCodigoCobertura());
			ItemCotacao itemCotacao = cotacaoRepository.findItem(coberturaAdicionar.getSequencialItemCotacao());
			Integer coberturaBasicaItemUm = itemCoberturaRepository.findCoberturasBasicasItemUm(coberturaAdicionar.getCotacao())
					.stream()
					.map(ItemCobertura::getCodigoCobertura)
					.findAny()
					.orElse(null);

			List<Integer> parents = cotacaoRepository.recuperaPais(itemCotacao, coberturaBasicaItemUm, coberturaAdicionar.getCodigoCobertura());

			/**
			 * Recupera as cobertura 'pais' da cobertura adicionada
			 */
			List<ItemCobertura> coberturasDoItem = itemCoberturaRepository.findCoberturasByItem(itemCotacao);

			List<Integer> codigosCoberturas = coberturasDoItem.stream()
					.map(ItemCobertura::getCodigoCobertura)
					.collect(Collectors.toList());

			List<ValidacaoLote> listaValidacao = new ArrayList<>();

			for(Integer cob: parents) {
				if(!codigosCoberturas.contains(cob)) {
					Cobertura cobertura = coberturaRepository.findCobertura(cob);
					logger.info("cobertura " + cobertura.getCodigo());
					listaValidacao.add(
							new ValidacaoLote(0,String.format("Para adicionar esta Cobertura é necessário incluir a cobertura %s!", cobertura.getDescricao()))
					);
				}
			}

			if(!listaValidacao.isEmpty()) {
				resultado.setSuccess(false);
				resultado.setListaValidacaoLote(listaValidacao);
				return resultado;
			}

			ItemCobertura itemCobertura;
			itemCobertura = itemCoberturaRepository.findItemCoberturaByItemCotacaoAndCodCobertura(itemCotacao.getSequencialItemCotacao(),itemUmCobertura.getCodigoCobertura());
			if(itemCobertura == null) {
				itemCobertura = CoberturaViewMapper.INSTANCE.copiaItemCobertura(itemUmCobertura);
				itemCobertura.setValorSublimite(itemCobertura.getValorSublimiteOriginal());
				itemCobertura.setIdSublimiteInformado(SimNaoEnum.NAO);
				itemCobertura.setItemCotacao(itemCotacao);
			} else {
				itemCobertura.setIdExclusaEndosso(SimNaoEnum.NAO);
			}

			itemCoberturaRepository.save(itemCobertura);

			SublimiteView sublimiteView = new SublimiteView();

			if(itemCotacao.getCotacao().getCodigoMoeda() ==  MoedaEnum.REAL) {
				sublimiteView.setValorRiscoBem(itemCobertura.getValorRiscoBem());
				sublimiteView.setValorImportanciaSegurada(itemCobertura.getValorImportanciaSegurada());
				sublimiteView.setValorSublimite(itemCobertura.getValorSublimite());
				sublimiteView.setValorSublimiteOriginal(itemCobertura.getValorSublimiteOriginal());
			} else {
				sublimiteView.setValorRiscoBem(itemCobertura.getValorRiscoBemMoedaEstrangeira());
				sublimiteView.setValorImportanciaSegurada(itemCobertura.getValorISMoedaEstrangeira());
				sublimiteView.setValorSublimite(itemCobertura.getValorSublimiteMoedaEstrangeira());
				sublimiteView.setValorSublimiteOriginal(itemCobertura.getValorSublimiteOriginalMoedaEstrangeira());
			}
			
			sublimiteView.setNumeroItem(itemCobertura.getItemCotacao().getNumeroItem());
			sublimiteView.setCodigoCobertura(itemCobertura.getCodigoCobertura());
			sublimiteView.setSequencialItemCotacao(itemCobertura.getItemCotacao().getSequencialItemCotacao());
			sublimiteView.setSequencialItemCobertura(itemCobertura.getSequencialItemCobertura());
			sublimiteView.setSequencialCotacaoProposta(itemCobertura.getItemCotacao().getCotacao().getSequencialCotacaoProposta());
			sublimiteView.setDescricaoCobertura(itemCobertura.getDescricaoCobertura());
			ProdutoCobertura produtoCobertura = coberturaRepository.findProdutoCobertura(itemCotacao.getCotacao().getCodigoProduto(),itemCobertura.getCodigoCobertura());
			if(produtoCobertura != null) {
				sublimiteView.setLiberaSublimite(produtoCobertura.getLiberaSublimite().getLogical());
			}

			resultado.setSuccess(true);
			resultado.setRetornoObj(sublimiteView);

			return resultado;
		} catch (Exception e) {
			logger.error("Erro ao adicionar cobertura (Sublimite) " + coberturaAdicionar, e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	private List<ValidacaoLote> validaSublimite(List<ItemSublimiteView> sublimites) {
		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		List<ProdutoCobertura> produtoCoberturas = getProdutoCoberturas(sublimites);
		
		for(ItemSublimiteView sublimite: sublimites) {
			if(isSublimiteLiberado(produtoCoberturas, sublimite)) {
				BigDecimal valorSublimite = new NumberMapper().asDecimal(sublimite.getValorSublimite());
				if(valorSublimite == null || valorSublimite.compareTo(BigDecimal.ZERO) == 0) {
					listaValidacao.add(
							new ValidacaoLote(sublimite.getNumeroItem().intValue(), "Favor informar o valor do sublimite da cobertura "
									+ sublimite.getDescricaoCobertura()));
				}

				BigDecimal valorSublimiteOriginal = new NumberMapper().asDecimal(sublimite.getValorSublimiteOriginal());
				if(valorSublimite != null && BigDecimalUtil.maior(valorSublimite, valorSublimiteOriginal)) {
					listaValidacao.add(
							new ValidacaoLote(sublimite.getNumeroItem().intValue(), "O Valor do Sublimite da Cobertura "
									+ sublimite.getDescricaoCobertura() + " não pode ser maior que o Sublimite Original"));
				}				
			}
		}

		return listaValidacao;
	}

	private boolean isSublimiteLiberado(List<ProdutoCobertura> produtoCoberturas, ItemSublimiteView sublimite) {

		if (produtoCoberturas == null || produtoCoberturas.isEmpty()) {
			return false;
		}

		Predicate<ProdutoCobertura> filtroProdutoCobertura = sublimite.getCoberturaPrincipal() == null
				? getFiltroProdutoCoberturaBasica(sublimite)
				: getFiltroProdutoCoberturaDemais(sublimite);

		Optional<ProdutoCobertura> optProdutoCobertura = produtoCoberturas.stream().filter(filtroProdutoCobertura)
				.findFirst();

		return optProdutoCobertura.isPresent() && SimNaoEnum.SIM == optProdutoCobertura.get().getLiberaSublimite();

	}

	private Predicate<ProdutoCobertura> getFiltroProdutoCoberturaBasica(ItemSublimiteView sublimite){
		return p -> p.getCobertura().equals(sublimite.getCodigoCobertura()) && p.getCoberturaPrincipal() == null;
	}

	private Predicate<ProdutoCobertura> getFiltroProdutoCoberturaDemais(ItemSublimiteView sublimite){
		return p -> p.getCobertura().equals(sublimite.getCodigoCobertura()) && p.getCoberturaPrincipal().equals(sublimite.getCoberturaPrincipal());
	}

	private List<ProdutoCobertura> getProdutoCoberturas(List<ItemSublimiteView> sublimites) {
		Optional<ItemSublimiteView> optSublimite = sublimites.stream().filter(s -> s.getCoberturaPrincipal() != null && s.getCoberturaPrincipal() > 0).findFirst();
		if(!optSublimite.isPresent()) {
			return new ArrayList<>();
		}
		List<Integer> codigosCobertura = sublimites.stream().map(ItemSublimiteView::getCodigoCobertura).distinct().collect(Collectors.toList());
		Cotacao cotacao = cotacaoRepository.findById(optSublimite.get().getSqCotacao());
		return coberturaRepository.findProdutoCobertura(cotacao.getCodigoProduto(),codigosCobertura,optSublimite.get().getCoberturaPrincipal());
	}
}