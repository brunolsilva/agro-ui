package br.com.tokiomarine.ctpj.integracao.backoffice.request;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AvisoCreditoManualRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6042169205546291757L;

	@JsonProperty("p_nr_aviso_credito")
	private BigInteger numeroAvisoCredito;

	@JsonProperty("p_cd_pedido_cotacao")
	private BigInteger numeroCotacaoProposta;

	@JsonProperty("p_id_movimentacao")
	private String idMovimentacao;

	@JsonProperty("codigoRetorno")
	private String codigoRetorno;

	@JsonProperty("p_cd_matricula")
	private String codigoMatricula;

	@JsonProperty("descricaoCodigoRetorno")
	private String descricaoCodigoRetorno;

	@JsonProperty("erroBD")
	private String erroBD;

	public BigInteger getNumeroAvisoCredito() {
		return numeroAvisoCredito;
	}

	public void setNumeroAvisoCredito(BigInteger numeroAvisoCredito) {
		this.numeroAvisoCredito = numeroAvisoCredito;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public String getIdMovimentacao() {
		return idMovimentacao;
	}

	public void setIdMovimentacao(String idMovimentacao) {
		this.idMovimentacao = idMovimentacao;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getCodigoMatricula() {
		return codigoMatricula;
	}

	public void setCodigoMatricula(String codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	public String getErroBD() {
		return erroBD;
	}

	public void setErroBD(String erroBD) {
		this.erroBD = erroBD;
	}

	@Override
	public String toString() {
		return "AvisoCreditoManualRequest [numeroAvisoCredito=" + numeroAvisoCredito + ", numeroCotacaoProposta=" + numeroCotacaoProposta + ", idMovimentacao=" + idMovimentacao + 
				", codigoRetorno=" + codigoRetorno + ", codigoMatricula=" + codigoMatricula + ", descricaoCodigoRetorno=" + descricaoCodigoRetorno + ", erroBD=" + erroBD + "]";
	}
	
}
