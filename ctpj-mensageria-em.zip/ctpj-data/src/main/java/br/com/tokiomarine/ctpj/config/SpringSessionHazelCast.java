package br.com.tokiomarine.ctpj.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.session.hazelcast.config.annotation.web.http.EnableHazelcastHttpSession;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.config.SerializerConfig;
import com.hazelcast.core.HazelcastInstance;

import br.com.tokiomarine.ctpj.type.CTP;

@EnableHazelcastHttpSession(maxInactiveIntervalInSeconds = 3600)
public class SpringSessionHazelCast {

	@Bean(destroyMethod = "shutdown")
	public HazelcastInstance hazelcastInstance() {
		
		String hzName = "dev";
		String hzPass = "Tokio*123";
		String[] hzAddress = new String[]{"192.168.57.65:5701","192.168.57.67:5702"};
		String s = System.getenv(CTP.HAZELCAST_URL.value());
		if (s != null) {
			String[] arr = StringUtils.split(s,";"); 
			hzName = arr[0];
			hzPass = arr[1];
			hzAddress = StringUtils.split(arr[2],"|");
		}
		ClientConfig clienteConfig = new ClientConfig();
		clienteConfig.getGroupConfig().setName(hzName).setPassword(hzPass);
		for (String s2 : hzAddress) {
			clienteConfig.getNetworkConfig().addAddress(s2);
		}
		
		SerializerConfig serializerConfig = new SerializerConfig()
				.setImplementation(new ObjectStreamSerializer())
				.setTypeClass(Object.class);
		
		clienteConfig.getSerializationConfig().addSerializerConfig(serializerConfig);
		
		clienteConfig.setProperty("hazelcast.logging.type", "none");
				
		return HazelcastClient.newHazelcastClient(clienteConfig);
	}
	
	@Bean
	public CookieSerializer cookieSerializer() {
		DefaultCookieSerializer serializer = new DefaultCookieSerializer();
		serializer.setCookieName("SESSION"); // <1>
		serializer.setCookiePath("/"); // <2>
		//serializer.setDomain
		return serializer;
	}
	
}
