package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;

@Component
public class TipoSeguroValidator {

	private static Logger logger = LogManager.getLogger(TipoSeguroValidator.class);
	
	public List<ValidacaoLote> validacaoItemTipoSeguro(Cotacao cotacao) {
		logger.info("Início validação tipo seguro " + cotacao.getSequencialCotacaoProposta());
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		for(ItemCotacao item: cotacao.getListItem()) {
			
			if(item.getIdTipoSeguro() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(), "Obrigatório informar o Tipo de Seguro"));
				continue;
			}
			
			if(item.getIdTipoSeguro() == TipoSeguroEnum.NOVO) {
				item.setCodigoRamoProdutoRenovada(null);
				item.setCodigoApoliceRenovada(null);
				item.setCodigoItemRenovada(null);
				item.setNumeroApoliceCongenere(null);
				item.setCodigoCompanhiaSeguradora(null);
				item.setPercentualSinistralidade(null);
			}

			if(item.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_CONGENERE) {
				item.setCodigoRamoProdutoRenovada(null);
				item.setCodigoApoliceRenovada(null);
				item.setCodigoItemRenovada(null);
				if(item.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (item.getIdTipoEndosso() != null && item.getIdTipoEndosso() == 6)) {
					validaCongenere(listaValidacao, item);
				}
			}
			
			if(item.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO) {
				item.setNumeroApoliceCongenere(null);
				item.setCodigoCompanhiaSeguradora(null);
				validaRenovacaoTokio(listaValidacao, item);
			}
		}
		
		logger.info("Fim validação tipo seguro " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}

	private void validaRenovacaoTokio(List<ValidacaoLote> listaValidacao, ItemCotacao item) {
		if(item.getCodigoRamoProdutoRenovada() == null 
				|| item.getCodigoApoliceRenovada() == null 
				|| item.getCodigoItemRenovada() == null 
				|| item.getCodigoClasseBonus() == null) {
			listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(), "Insira os dados de renovação deste local no campo Dados da Renovação"));
		} else if(item.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
			if(item.getPercentualSinistralidade() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(), "Insira os dados de renovação deste local no campo Dados da Renovação"));
			}
		}
	}

	private void validaCongenere(List<ValidacaoLote> listaValidacao, ItemCotacao item) {
		if(item.getCodigoCompanhiaSeguradora() == null 
				|| StringUtils.isBlank(item.getNumeroApoliceCongenere())
				|| item.getCodigoClasseBonus() == null) {
			listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(), "Insira os dados de renovação deste local no campo Dados da Renovação"));
		}
	}
}
