package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.exception.HibernateException;

@Repository
public class RecebimentoRepository extends BaseDAO {

	public Recebimento getRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws HibernateException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select r ");
		hql.append(" from Recebimento r ");
		hql.append(" where cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");

		Query query = this.getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		Recebimento recebimento = (Recebimento) query.uniqueResult();
		return recebimento;
	}
	
	public Recebimento getRecebimentoByNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) throws HibernateException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select r ");
		hql.append(" from Recebimento r ");
		hql.append(" where cotacao.numeroCotacaoProposta = :numeroCotacaoProposta ");

		Query query = this.getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		return (Recebimento) query.uniqueResult();
	}

	public Long getSequencialRecebimentoOffLine() throws HibernateException {

		StringBuilder sqlNative = new StringBuilder();
		sqlNative.append("select a_seq.nextval from dual");

		Query query = this.getCurrentSession().createSQLQuery(sqlNative.toString());

		Long sequencia = (Long) query.uniqueResult();

		return sequencia;
	}

	public void save(Recebimento recebimento) throws HibernateException{
		super.getCurrentSession().save(recebimento);
	}

	public void deleteRecebimento(BigInteger numeroCotacaoProposta) throws HibernateException {
		StringBuilder hql = new StringBuilder();
		hql.append(" delete from Recebimento r  ");
		hql.append(" where	numeroCotacaoProposta = :numeroCotacaoProposta ");
		Query query = this.getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
		query.executeUpdate();
	}	
	

	public Long countRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws HibernateException {

		StringBuilder hql = new StringBuilder();
		hql.append(" select count(*) ");
		hql.append(" from Recebimento r ");
		hql.append(" where r.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");

		Query query = this.getCurrentSession().createQuery(hql.toString()).setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		Long countRecebimento = (Long) query.uniqueResult();

		return countRecebimento;

	}

	public Integer getSequencialControleRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws HibernateException {
		StringBuilder hql = new StringBuilder();
		hql.append("	select	coalesce(max(r.sequencialControleRecebimento),0)+1 ");
		hql.append("	from	Recebimento r  ");
		hql.append("	where	cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query query = this.getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (Integer) query.uniqueResult();
	}

	public Recebimento findRecebimentoBySequencialRecebimento(BigInteger sequencialRecebimento) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select r ");
		hql.append(" from Recebimento r ");
		hql.append(" where sequencialRecebimento = :sequencialRecebimento ");

		Query query = this.getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialRecebimento",sequencialRecebimento);

		Recebimento recebimento = (Recebimento) query.uniqueResult();
		return recebimento;

	}	
	
	public Recebimento findRecebimentoByNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select r ");
		hql.append(" from Recebimento r ");
		hql.append(" where numeroCotacaoProposta = :numeroCotacaoProposta ");

		Query query = this.getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);

		Recebimento recebimento = (Recebimento) query.uniqueResult();
		return recebimento;

	}	
}
