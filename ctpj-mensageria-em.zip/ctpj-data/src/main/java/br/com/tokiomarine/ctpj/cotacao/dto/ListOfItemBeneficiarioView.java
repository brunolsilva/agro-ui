package br.com.tokiomarine.ctpj.cotacao.dto;

import br.com.tokiomarine.ctpj.cotacao.validator.collections.ValidList;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.TodosOsItensPossuemOMesmoTipoDeDistribuicao;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.TotalPercentuaisDistribIgual100Porcento;

/**
 * Encapsula uma lista de ItemBeneficiarioView
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@TotalPercentuaisDistribIgual100Porcento()
@TodosOsItensPossuemOMesmoTipoDeDistribuicao()
public class ListOfItemBeneficiarioView extends ValidList<ItemBeneficiarioView> {

}
