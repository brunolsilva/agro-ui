package br.com.tokiomarine.ctpj.cotacao.dto;

public class AvisoCreditoManualView {

	private String numeroAvisoCredito;
	private String tipoRecebimento;
	private String situacao;
	private String valorCredito;
	private String idCreditoUtilizado;
	private String idCreditoBloqueado;
	private String idAvisoCreditoManual;

	public AvisoCreditoManualView() {}

	public AvisoCreditoManualView(String numeroAvisoCredito,String tipoRecebimento,String situacao,String valorCredito,String idCreditoUtilizado,String idCreditoBloqueado,String idAvisoCreditoManual) {
		super();
		this.numeroAvisoCredito = numeroAvisoCredito;
		this.tipoRecebimento = tipoRecebimento;
		this.situacao = situacao;
		this.valorCredito = valorCredito;
		this.idCreditoUtilizado = idCreditoUtilizado;
		this.idCreditoBloqueado = idCreditoBloqueado;
		this.idAvisoCreditoManual = idAvisoCreditoManual;
	}

	public String getNumeroAvisoCredito() {
		return numeroAvisoCredito;
	}

	public void setNumeroAvisoCredito(String numeroAvisoCredito) {
		this.numeroAvisoCredito = numeroAvisoCredito;
	}

	public String getTipoRecebimento() {
		return tipoRecebimento;
	}

	public void setTipoRecebimento(String tipoRecebimento) {
		this.tipoRecebimento = tipoRecebimento;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(String valorCredito) {
		this.valorCredito = valorCredito;
	}

	public String getIdCreditoUtilizado() {
		return idCreditoUtilizado;
	}

	public void setIdCreditoUtilizado(String idCreditoUtilizado) {
		this.idCreditoUtilizado = idCreditoUtilizado;
	}

	public String getIdCreditoBloqueado() {
		return idCreditoBloqueado;
	}

	public void setIdCreditoBloqueado(String idCreditoBloqueado) {
		this.idCreditoBloqueado = idCreditoBloqueado;
	}

	public String getIdAvisoCreditoManual() {
		return idAvisoCreditoManual;
	}

	public void setIdAvisoCreditoManual(String idAvisoCreditoManual) {
		this.idAvisoCreditoManual = idAvisoCreditoManual;
	}

}
