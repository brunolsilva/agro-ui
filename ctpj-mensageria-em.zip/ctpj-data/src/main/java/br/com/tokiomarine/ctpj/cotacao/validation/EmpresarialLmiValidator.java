package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;

public class EmpresarialLmiValidator implements ProdutoValidator {

	private static Logger logger = LogManager.getLogger(EmpresarialLmiValidator.class);

	@LogPerformance
	public List<ValidacaoLote> valida(Cotacao cotacao, Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto) {
		logger.info("Início da validação do LMI Empresarial " + cotacao.getSequencialCotacaoProposta());

		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		LmiValidator lmiValidator = new LmiValidator();
		DistribuicaoVrValidator distribuicaoVrValidator = new DistribuicaoVrValidator();
		TipoSeguroValidator tipoSeguroValidator = new TipoSeguroValidator();
		CoberturaBasicaValidator coberturaBasicaValidator = new CoberturaBasicaValidator();
		CoberturaDanosMateriaisValidator coberturaDMValidator = new CoberturaDanosMateriaisValidator();
		if(cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.REINTEGRACAO_IS) {
			ReintegracaoISValidator reintegracaoISValidator = new ReintegracaoISValidator();
			listaValidacao.addAll(reintegracaoISValidator.valida(cotacao));
		}

		//OutroSeguroValidator outroSeguroValidator = new OutroSeguroValidator();
		ValorEmRiscoValidator valorEmRiscoValidator = new ValorEmRiscoValidator();

		listaValidacao.addAll(lmiValidator.validacaoBasica(cotacao,caracteristicasDoProduto));
		listaValidacao.addAll(tipoSeguroValidator.validacaoItemTipoSeguro(cotacao));
		listaValidacao.addAll(distribuicaoVrValidator.validacaoItemDistribuicao(cotacao));
		listaValidacao.addAll(coberturaBasicaValidator.validacaoCoberturaBasica(cotacao));
		listaValidacao.addAll(coberturaDMValidator.validacaoDadosCoberturaDM(cotacao));
		//listaValidacao.addAll(outroSeguroValidator.valida(cotacao));
		listaValidacao.addAll(valorEmRiscoValidator.valida(cotacao));

		logger.info("Fim da validação do LMI Empresarial " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}
}