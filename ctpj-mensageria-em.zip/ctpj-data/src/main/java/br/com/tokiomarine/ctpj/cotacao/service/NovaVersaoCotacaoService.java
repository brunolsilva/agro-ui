package br.com.tokiomarine.ctpj.cotacao.service;

import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.ClausulaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CondicaoContratualCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ContaCorrenteGlobal;
import br.com.tokiomarine.ctpj.domain.cotacao.ControleFichaRegistrada;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoAgravacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoCCG;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemAeronave;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDadosObra;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarcacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarque;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemPiloto;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemQBR;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamo;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoEndereco;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.domain.cotacao.JurosParcelamentoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.ParecerCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.domain.cotacao.ServicoCotacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Service
@Transactional(rollbackFor = {Exception.class})
public class NovaVersaoCotacaoService {

	private static Logger logger = LogManager.getLogger(NovaVersaoCotacaoService.class);

	@LogPerformance
	public void bindCotacaoNovaVersao(Cotacao cotacao, Cotacao cotacaoOrigem, User user,boolean isVsp) throws ServiceException {

		logger.info("ajustando Cotacao");

		// Reseta as informações que deve ser limpadas na nova versão, para os casos de apólice		
		cotacao.setSequencialCotacaoProposta(null);
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE && !isVsp) {
//			cotacao.setValorPremioAjustavelMoedaEstrangeira(null);
//			cotacao.setValorPremioFixaMoedaEstrangeira(null);
//			cotacao.setValorPremioLiquido(null);
//			cotacao.setValorPremioLiquidoMoedaEstrangeira(null);
//			cotacao.setValorPremioNET(null);
//			cotacao.setValorPremioNetMoedaEstrangeira(null);
//			cotacao.setValorPremioParteAjustavel(null);
//			cotacao.setValorPremioParteFixa(null);
		}
		
		cotacao.setCodigoSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getSituacao().intValue());
		cotacao.setNomeSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getDescricao());
		cotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
		cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		cotacao.setDataAtualizacao(Calendar.getInstance().getTime());

		if (cotacao.getListBloqueioAlcada() != null && !cotacao.getListBloqueioAlcada().isEmpty()) {
			this.bindBloqueioAlcada(cotacao.getListBloqueioAlcada(),cotacao,user);
		}	
		
		if (cotacao.getListDescontoCCG() != null && !cotacao.getListDescontoCCG().isEmpty()) {
			this.bindDescontoCCG(cotacao.getListDescontoCCG(),cotacao,user);
		}

		if (cotacao.getListContaCorrenteGlobal() != null && !cotacao.getListContaCorrenteGlobal().isEmpty()) {
			this.bindContaCorrenteGlobal(cotacao.getListContaCorrenteGlobal(),cotacao,user);
		}

		if (cotacao.getListServicoCotacao() != null && !cotacao.getListServicoCotacao().isEmpty()) {
			this.bindServicoCotacao(cotacao.getListServicoCotacao(),cotacao,user);
		}	

		if (cotacao.getListOpcaoParcelamento() != null && !cotacao.getListOpcaoParcelamento().isEmpty()) {
			this.bindOpcaoParcelamento(cotacao.getListOpcaoParcelamento(),cotacao,user);
		}

		if (cotacao.getListJurosParcelamento() != null && !cotacao.getListJurosParcelamento().isEmpty()) {
			this.bindJurosParcelamento(cotacao.getListJurosParcelamento(),cotacao,user);
		}	
	
		if (cotacao.getControlesFichaRegistrada() != null && !cotacao.getControlesFichaRegistrada().isEmpty()) {
			this.bindControlesFichaRegistrada(cotacao.getControlesFichaRegistrada(),cotacao,user);
		}	
		
		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			this.bindComissaoCotacao(cotacao.getListComissaoCotacao(),cotacao,user);
		}
		
		if (cotacao.getListCorretagemCotacao() != null && !cotacao.getListCorretagemCotacao().isEmpty()) {
			this.bindCorretagemCotacao(cotacao.getListCorretagemCotacao(),cotacao,user);
		}
		
		if (cotacao.getListCosseguroCotacao() != null && !cotacao.getListCosseguroCotacao().isEmpty()) {
			this.bindCosseguroCotacao(cotacao.getListCosseguroCotacao(),cotacao,user);
		}
		
//		if (cotacao.getListRecebimento() != null && !cotacao.getListRecebimento().isEmpty()) {
//			this.bindRecebimento(cotacao.getListRecebimento(),cotacao,user);
//		}
		
		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			this.bindComissaoCotacao(cotacao.getListComissaoCotacao(),cotacao,user);
		}
		
		if (cotacao.getListNotaCotacao() != null && !cotacao.getListNotaCotacao().isEmpty()) {
			this.bindNotaCotacao(cotacao.getListNotaCotacao(),cotacao,user);
		}
		
		if (cotacao.getListCondicaoContratual() != null && !cotacao.getListCondicaoContratual().isEmpty()) {
			this.bindCondicaoContratual(cotacao.getListCondicaoContratual(),cotacao,user);
		}

		if (cotacao.getListItem() != null && !cotacao.getListItem().isEmpty()) {
			this.bindItemCotacao(cotacao.getListItem(),cotacao,user);
		}
		
		if(cotacao.getPareceresCotacao() != null && !cotacao.getPareceresCotacao().isEmpty()){
			this.bindParecerCotacao(cotacao.getPareceresCotacao(), cotacao, user);
		}
		
		if (cotacao.getListAlteracaoEndosso() != null && !cotacao.getListAlteracaoEndosso().isEmpty()) {
			this.bindAlteracaoEndosso(
					cotacao.getListAlteracaoEndosso(),
					cotacao.getListItem(),
					cotacao.getListItem().stream()
						.flatMap(item -> item.getListItemCobertura().stream())
						.collect(Collectors.toList()),
					cotacao,user);
		}
		
		if (isVsp) {
			cotacao.setIcVsp(SimNaoEnum.SIM);
		} else {
			cotacao.setIcVsp(SimNaoEnum.NAO);
		}

		cotacao.setSequencialCotacaoPropostaOrigem(cotacaoOrigem.getSequencialCotacaoProposta() == null ? null : cotacaoOrigem.getSequencialCotacaoProposta());

	}

	private void bindAlteracaoEndosso(
			List<AlteracaoEndosso> listAlteracaoEndosso, 
			Set<ItemCotacao> items, List<ItemCobertura> coberturas, 
			Cotacao cotacao, User user) {
		for (AlteracaoEndosso alteracaoEndosso : listAlteracaoEndosso) {
			if(alteracaoEndosso.getItemCotacao() != null) {
				for(ItemCotacao item: items) {
					if(item.getNumeroItem().equals(alteracaoEndosso.getItemCotacao().getNumeroItem())) {
						alteracaoEndosso.setItemCotacao(item);
					}
				}
			}
			
			if(alteracaoEndosso.getItemCobertura() != null) {
				for(ItemCobertura cobertura: coberturas) {
					if(cobertura.getItemCotacao().getNumeroItem().equals(alteracaoEndosso.getItemCotacao().getNumeroItem())) {
						if(cobertura.getCodigoCobertura().equals(alteracaoEndosso.getItemCobertura().getCodigoCobertura())) {
							alteracaoEndosso.setItemCobertura(cobertura);
						}
					}
				}
			}
			alteracaoEndosso.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			alteracaoEndosso.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			alteracaoEndosso.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			alteracaoEndosso.setDataAtualizacao(Calendar.getInstance().getTime());
			alteracaoEndosso.setCotacao(cotacao);
		}
	}

	private void bindBloqueioAlcada(List<BloqueioAlcada> listBloqueioAlcada, Cotacao cotacao, User user) {
		for (BloqueioAlcada bloqueioAlcada : listBloqueioAlcada) { 
			bloqueioAlcada.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			bloqueioAlcada.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			bloqueioAlcada.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			bloqueioAlcada.setDataAtualizacao(Calendar.getInstance().getTime());
			bloqueioAlcada.setCotacao(cotacao);
		}	
	}

	private void bindComissaoCotacao(Set<ComissaoCotacao> listComissaoCotacao,Cotacao cotacao, User user) {
		for (ComissaoCotacao comissaoCotacao : listComissaoCotacao) {
			comissaoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			comissaoCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			comissaoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			comissaoCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			comissaoCotacao.setCotacao(cotacao);
		}
	}

	private void bindContaCorrenteGlobal(Set<ContaCorrenteGlobal> listContaCorrenteGlobal, Cotacao cotacao, User user) {
		for (ContaCorrenteGlobal contaCorrenteGlobal : listContaCorrenteGlobal) {
			contaCorrenteGlobal.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			contaCorrenteGlobal.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			contaCorrenteGlobal.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			contaCorrenteGlobal.setDataAtualizacao(Calendar.getInstance().getTime());
			contaCorrenteGlobal.setCotacao(cotacao);
		}
	}

	private void bindDescontoCCG(List<DescontoCCG> listDescontoCCG, Cotacao cotacao, User user) {
		for (DescontoCCG descontoCCG : listDescontoCCG) {
			descontoCCG.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			descontoCCG.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			descontoCCG.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			descontoCCG.setDataAtualizacao(Calendar.getInstance().getTime());
			descontoCCG.setCotacao(cotacao);
		}
	}

	private void bindServicoCotacao(List<ServicoCotacao> listServicoCotacao, Cotacao cotacao, User user) {
		for (ServicoCotacao servicoCotacao : listServicoCotacao) {
			servicoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			servicoCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			servicoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			servicoCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			servicoCotacao.setCotacao(cotacao);
		}
	}

	private void bindJurosParcelamento(List<JurosParcelamentoCotacao> listJurosParcelamento, Cotacao cotacao, User user) {
		for (JurosParcelamentoCotacao jurosParcelamentoCotacao : listJurosParcelamento) {
			jurosParcelamentoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			jurosParcelamentoCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			jurosParcelamentoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			jurosParcelamentoCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			jurosParcelamentoCotacao.setCotacao(cotacao);
		}
	}

	private void bindOpcaoParcelamento(List<OpcaoParcelamento> listOpcaoParcelamento, Cotacao cotacao, User user) {
		for (OpcaoParcelamento opcaoParcelamento : listOpcaoParcelamento) {
			opcaoParcelamento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			opcaoParcelamento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			opcaoParcelamento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			opcaoParcelamento.setDataAtualizacao(Calendar.getInstance().getTime());
			opcaoParcelamento.setCotacao(cotacao);
		}
	}

	private void bindControlesFichaRegistrada(List<ControleFichaRegistrada> controlesFichaRegistrada, Cotacao cotacao, User user) {
		for (ControleFichaRegistrada controleFichaRegistrada : controlesFichaRegistrada) {
			controleFichaRegistrada.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			controleFichaRegistrada.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			controleFichaRegistrada.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			controleFichaRegistrada.setDataAtualizacao(Calendar.getInstance().getTime());
			controleFichaRegistrada.setCotacao(cotacao);
		}
	}

	private void bindCorretagemCotacao(List<CorretagemCotacao> listCorretagemCotacao,Cotacao cotacao,User user) {
		for (CorretagemCotacao corretagemCotacao : listCorretagemCotacao) {
			corretagemCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			corretagemCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			corretagemCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			corretagemCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			corretagemCotacao.setCotacao(cotacao);
		}
	}

	private void bindCosseguroCotacao(Set<CosseguroCotacao> listCosseguroCotacao,Cotacao cotacao,User user) {
		for (CosseguroCotacao cosseguroCotacao : listCosseguroCotacao) {
			cosseguroCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			cosseguroCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			cosseguroCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			cosseguroCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			cosseguroCotacao.setCotacao(cotacao);
		}
	}

	private void bindRecebimento(Set<Recebimento> listRecebimento,Cotacao cotacao,User user) {
		for (Recebimento recebimento : listRecebimento) {
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			recebimento.setDataAtualizacao(Calendar.getInstance().getTime());
			recebimento.setCotacao(cotacao);
		}
	}

	private void bindClausulaCotacao(List<ClausulaCotacao> listClausulaCotacao,Cotacao cotacao,User user) {
		for (ClausulaCotacao clausulaCotacao : listClausulaCotacao) {
			clausulaCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			clausulaCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			clausulaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			clausulaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			clausulaCotacao.setCotacao(cotacao);
		}
	}

	private void bindNotaCotacao(List<NotaCotacao> listNotaCotacao,Cotacao cotacao,User user) {
		for (NotaCotacao notaCotacao : listNotaCotacao) {
			notaCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			notaCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			notaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			notaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			notaCotacao.setCotacao(cotacao);
		}
	}
	
	private void bindCondicaoContratual(List<CondicaoContratualCotacao> listCondicaoContratual, Cotacao cotacao, User user) {
		for (CondicaoContratualCotacao condicaoContratualCotacao : listCondicaoContratual) {
			condicaoContratualCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			condicaoContratualCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			condicaoContratualCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			condicaoContratualCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			condicaoContratualCotacao.setCotacao(cotacao);
		}
	}
	
	private void bindParecerCotacao(List<ParecerCotacao> listParecerCotacao, Cotacao cotacao, User user){
		for (ParecerCotacao parecerCotacao : listParecerCotacao) {
			parecerCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			parecerCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			parecerCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			parecerCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			parecerCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			parecerCotacao.setCotacao(cotacao);
		}
	}


	private void bindItemCotacao(Set<ItemCotacao> listItemCotacao,Cotacao cotacao,User user) {
		for (ItemCotacao itemCotacao : listItemCotacao) {
			
			itemCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemCotacao.setValorCalculadoMoedaEstrangeira(null);
			
			itemCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCotacao.setCotacao(cotacao);
			
			//TODO - Precisa saber se o item Ajustamento entra na nova versão
			itemCotacao.setListItemAjustamentoPremio(null);

			if(itemCotacao.getListItemAeronave() != null && !itemCotacao.getListItemAeronave().isEmpty()){
				this.bindItemAeronave(itemCotacao.getListItemAeronave(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemBeneficiario() != null && !itemCotacao.getListItemBeneficiario().isEmpty()){
				this.bindItemBeneficiario(itemCotacao.getListItemBeneficiario(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemCossegurado() != null && !itemCotacao.getListItemCossegurado().isEmpty()){
				this.bindItemCossegurado(itemCotacao.getListItemCossegurado(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemDadosObra() != null && !itemCotacao.getListItemDadosObra().isEmpty()){
				this.bindItemDadosObra(itemCotacao.getListItemDadosObra(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemDistribuicao() != null && !itemCotacao.getListItemDistribuicao().isEmpty()){
				this.bindItemDistribuicao(itemCotacao.getListItemDistribuicao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemEmbarcacao() != null && !itemCotacao.getListItemEmbarcacao().isEmpty()){
				this.bindItemEmbarcacao(itemCotacao.getListItemEmbarcacao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemEmbarque() != null && !itemCotacao.getListItemEmbarque().isEmpty()){
				this.bindItemEmbarque(itemCotacao.getListItemEmbarque(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemInspecao() != null && !itemCotacao.getListItemInspecao().isEmpty()){
				this.bindItemInspecao(itemCotacao.getListItemInspecao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemNota() != null && !itemCotacao.getListItemNota().isEmpty()){
				this.bindItemNota(itemCotacao.getListItemNota(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemOutroSeguro() != null && !itemCotacao.getListItemOutroSeguro().isEmpty()){
				this.bindItemOutroSeguro(itemCotacao.getListItemOutroSeguro(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemPiloto() != null && !itemCotacao.getListItemPiloto().isEmpty()){
				this.bindItemPiloto(itemCotacao.getListItemPiloto(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemQBR() != null && !itemCotacao.getListItemQBR().isEmpty()){
				this.bindItemQBR(itemCotacao.getListItemQBR(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemRelacaoBem() != null && !itemCotacao.getListItemRelacaoBem().isEmpty()){
				this.bindItemRelacaoBem(itemCotacao.getListItemRelacaoBem(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemRelacaoEndereco() != null && !itemCotacao.getListItemRelacaoEndereco().isEmpty()){
				this.bindItemRelacaoEndereco(itemCotacao.getListItemRelacaoEndereco(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemSistemaProtecional() != null && !itemCotacao.getListItemSistemaProtecional().isEmpty()){
				this.bindItemSistemaProtecional(itemCotacao.getListItemSistemaProtecional(),itemCotacao,cotacao,user);
			}
			
//			if(itemCotacao.getListItemClausula() != null && !itemCotacao.getListItemClausula().isEmpty()){
//				this.bindClausulaItem(itemCotacao.getListItemClausula(),itemCotacao,cotacao,user);
//			}
		
			if(itemCotacao.getListItemRamo() != null && !itemCotacao.getListItemRamo().isEmpty()){
				this.bindItemRamo(itemCotacao.getListItemRamo(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemRamoEmissao() != null && !itemCotacao.getListItemRamoEmissao().isEmpty()){
				this.bindItemRamoEmissao(itemCotacao.getListItemRamoEmissao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemCobertura() != null && !itemCotacao.getListItemCobertura().isEmpty()){
				this.bindItemCobertura(itemCotacao.getListItemCobertura(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemSinistro() != null && !itemCotacao.getListItemSinistro().isEmpty()){
				this.bindItemSinistro(itemCotacao.getListItemSinistro(),itemCotacao,cotacao,user);
			}
		}
	}

	private void bindItemAeronave(List<ItemAeronave> listItemAeronave,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemAeronave itemAeronave : listItemAeronave) {
			itemAeronave.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemAeronave.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemAeronave.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemAeronave.setDataAtualizacao(Calendar.getInstance().getTime());
			itemAeronave.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemBeneficiario(List<ItemBeneficiario> listItemBeneficiario,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemBeneficiario itemBeneficiario : listItemBeneficiario) {
			itemBeneficiario.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemBeneficiario.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemBeneficiario.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemBeneficiario.setDataAtualizacao(Calendar.getInstance().getTime());
			itemBeneficiario.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemCossegurado(List<ItemCossegurado> listItemCossegurado,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemCossegurado itemCossegurado : listItemCossegurado) {
			itemCossegurado.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemCossegurado.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCossegurado.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCossegurado.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCossegurado.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemDadosObra(List<ItemDadosObra> listItemDadosObra,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemDadosObra itemDadosObra : listItemDadosObra) {
			itemDadosObra.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemDadosObra.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemDadosObra.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemDadosObra.setDataAtualizacao(Calendar.getInstance().getTime());
			itemDadosObra.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemDistribuicao(Set<ItemDistribuicao> listItemDistribuicao,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemDistribuicao itemDistribuicao : listItemDistribuicao) {
			itemDistribuicao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemDistribuicao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemDistribuicao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemDistribuicao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemDistribuicao.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemEmbarcacao(List<ItemEmbarcacao> listItemEmbarcacao,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemEmbarcacao itemEmbarcacao : listItemEmbarcacao) {
			itemEmbarcacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemEmbarcacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemEmbarcacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemEmbarcacao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemEmbarcacao.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemEmbarque(List<ItemEmbarque> listItemEmbarque,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemEmbarque itemEmbarque : listItemEmbarque) {
			itemEmbarque.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemEmbarque.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemEmbarque.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemEmbarque.setDataAtualizacao(Calendar.getInstance().getTime());
			itemEmbarque.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemInspecao(Set<ItemInspecao> listItemInspecao,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemInspecao itemInspecao : listItemInspecao) {
			itemInspecao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemInspecao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemInspecao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemInspecao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemInspecao.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemNota(List<ItemNota> listItemNota,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemNota ItemNota : listItemNota) {
			ItemNota.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			ItemNota.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			ItemNota.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			ItemNota.setDataAtualizacao(Calendar.getInstance().getTime());
			ItemNota.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemOutroSeguro(List<ItemOutroSeguro> listItemOutroSeguro,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemOutroSeguro itemOutroSeguro : listItemOutroSeguro) {
			itemOutroSeguro.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemOutroSeguro.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemOutroSeguro.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemOutroSeguro.setDataAtualizacao(Calendar.getInstance().getTime());
			itemOutroSeguro.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemPiloto(List<ItemPiloto> listItemPiloto,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemPiloto itemPiloto : listItemPiloto) {
			itemPiloto.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemPiloto.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemPiloto.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemPiloto.setDataAtualizacao(Calendar.getInstance().getTime());
			itemPiloto.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemQBR(List<ItemQBR> listItemQBR,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemQBR itemQBR : listItemQBR) {
			itemQBR.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemQBR.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemQBR.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemQBR.setDataAtualizacao(Calendar.getInstance().getTime());
			itemQBR.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemRelacaoBem(List<ItemRelacaoBem> listItemRelacaoBem,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemRelacaoBem itemRelacaoBem : listItemRelacaoBem) {
			itemRelacaoBem.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemRelacaoBem.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemRelacaoBem.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemRelacaoBem.setDataAtualizacao(Calendar.getInstance().getTime());
			itemRelacaoBem.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemRelacaoEndereco(List<ItemRelacaoEndereco> listItemRelacaoEndereco,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemRelacaoEndereco itemRelacaoEndereco : listItemRelacaoEndereco) {
			itemRelacaoEndereco.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemRelacaoEndereco.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemRelacaoEndereco.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemRelacaoEndereco.setDataAtualizacao(Calendar.getInstance().getTime());
			itemRelacaoEndereco.setItemCotacao(itemCotacao);
		}

	}

	private void bindItemSistemaProtecional(Set<ItemSistemaProtecional> listItemSistemaProtecional,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemSistemaProtecional itemSistemaProtecional : listItemSistemaProtecional) {
			itemSistemaProtecional.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemSistemaProtecional.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemSistemaProtecional.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemSistemaProtecional.setDataAtualizacao(Calendar.getInstance().getTime());
			itemSistemaProtecional.setItemCotacao(itemCotacao);
		}

	}
	
	private void bindItemRamo(List<ItemRamo> listItemRamo, ItemCotacao itemCotacao, Cotacao cotacao, User user) {
		for (ItemRamo itemRamo : listItemRamo) {
			itemRamo.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			
			//Zera o prêmio caso foi calculado
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
				//itemRamo.setValorPremio(null);
				//itemRamo.setValorPremioMoedaEstrangeira(null);
			}
			itemRamo.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemRamo.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemRamo.setDataAtualizacao(Calendar.getInstance().getTime());
			itemRamo.setItemCotacao(itemCotacao);
		}
	}

	private void bindItemRamoEmissao(Set<ItemRamoEmissao> listItemRamoEmissao, ItemCotacao itemCotacao, Cotacao cotacao, User user) {
		for (ItemRamoEmissao itemRamoEmissao : listItemRamoEmissao) {
			itemRamoEmissao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			
			//Zera o prêmio caso foi calculado
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
//				itemRamoEmissao.setValorPremio(null);
//				itemRamoEmissao.setValorPremioMoedaEstrangeira(null);
//				itemRamoEmissao.setValorPremioNet(null);
//				itemRamoEmissao.setValorPremioNetMoedaEstrangeira(null);
//				itemRamoEmissao.setValorPremioReferencial(null);
//				itemRamoEmissao.setValorPremioVigencia(null);
			}
			
			itemRamoEmissao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemRamoEmissao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemRamoEmissao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemRamoEmissao.setItemCotacao(itemCotacao);
		}
	}
		
	private void bindItemCobertura(Set<ItemCobertura> listItemCobertura,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemCobertura itemCobertura : listItemCobertura) {
			
			itemCobertura.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			// Quando é gerada uma nova versão deve zerar o Oficio Ressegurador e Prêmios
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
//				itemCobertura.setIdOficioRessegurador("N");
//				itemCobertura.setValorPremio(null);
//				itemCobertura.setValorPremioMoedaEstrangeira(null);
//				itemCobertura.setValorPremioNET(null);
//				itemCobertura.setValorPremioParteAjustavel(null);
//				itemCobertura.setValorPremioParteFixa(null);
//				itemCobertura.setValorPremioReferencial(null);
//				itemCobertura.setValorPremioVigencia(null);
			}
			itemCobertura.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCobertura.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCobertura.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCobertura.setItemCotacao(itemCotacao);
			
			if(itemCobertura.getListDescontoAgravacao() != null &&  !itemCobertura.getListDescontoAgravacao().isEmpty()){
				this.bindDescontoAgravacao(itemCobertura.getListDescontoAgravacao(),itemCobertura,cotacao,user);
			}
			
			if(itemCobertura.getListaItemCoberturaClausula() != null &&  !itemCobertura.getListaItemCoberturaClausula().isEmpty()){
				this.bindClausulaItemCobertura(itemCobertura.getListaItemCoberturaClausula(),itemCobertura,cotacao,user);
			}
			
			if(itemCobertura.getListItemEquipamentoFranquia() != null && !itemCobertura.getListItemEquipamentoFranquia().isEmpty()){
				this.bindItemEquipamentoFranquia(itemCobertura.getListItemEquipamentoFranquia(),itemCobertura,cotacao,user);
			}
			
		}

	}
	
	private void bindItemSinistro(Set<ItemSinistro> listItemSinistro,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemSinistro itemSinistro : listItemSinistro) {
			itemSinistro.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemSinistro.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemSinistro.setDataAtualizacao(Calendar.getInstance().getTime());
			itemSinistro.setItemCotacao(itemCotacao);

			if(itemSinistro.getListItemCoberturaSinistro() != null && !itemSinistro.getListItemCoberturaSinistro().isEmpty()) {
				this.bindItemCoberturaSinistro(itemSinistro.getListItemCoberturaSinistro(),itemSinistro,cotacao,user);
			}
		}

	}

	private void bindItemCoberturaSinistro(Set<ItemCoberturaSinistro> listItemCoberturaSinistro,
			ItemSinistro itemSinistro, Cotacao cotacao, User user) {
		for (ItemCoberturaSinistro itemCoberturaSinistro : listItemCoberturaSinistro) {
			itemCoberturaSinistro.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCoberturaSinistro.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCoberturaSinistro.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCoberturaSinistro.setItemSinistro(itemSinistro);
		}
	}

	private void bindDescontoAgravacao(List<DescontoAgravacao> listDescontoAgravacao, ItemCobertura itemCobertura, Cotacao cotacao, User user) {
		for (DescontoAgravacao descontoAgravacao : listDescontoAgravacao) {
			descontoAgravacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			descontoAgravacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			descontoAgravacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			descontoAgravacao.setDataAtualizacao(Calendar.getInstance().getTime());
			descontoAgravacao.setItemCobertura(itemCobertura);
		}
		
	}

	private void bindClausulaItemCobertura(List<ItemCoberturaClausula> listClausulaItemCobertura,ItemCobertura itemCobertura,Cotacao cotacao,User user) {
		for (ItemCoberturaClausula clausulaItemCobertura : listClausulaItemCobertura) {
			clausulaItemCobertura.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			clausulaItemCobertura.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			clausulaItemCobertura.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			clausulaItemCobertura.setDataAtualizacao(Calendar.getInstance().getTime());
			clausulaItemCobertura.setItemCobertura(itemCobertura);
		}
	}

	private void bindItemEquipamentoFranquia(List<ItemEquipamentoFranquia> listItemEquipamentoFranquia,ItemCobertura itemCobertura,Cotacao cotacao,User user) {
		for (ItemEquipamentoFranquia itemEquipamentoFranquia : listItemEquipamentoFranquia) {
			itemEquipamentoFranquia.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemEquipamentoFranquia.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemEquipamentoFranquia.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemEquipamentoFranquia.setDataAtualizacao(Calendar.getInstance().getTime());
			itemEquipamentoFranquia.setItemCobertura(itemCobertura);
		}
	}
}
