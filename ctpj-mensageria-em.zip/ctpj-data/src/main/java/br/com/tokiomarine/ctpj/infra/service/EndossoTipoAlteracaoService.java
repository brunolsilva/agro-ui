package br.com.tokiomarine.ctpj.infra.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.infra.domain.EndossoTipoAlteracao;
import br.com.tokiomarine.ctpj.infra.mongo.repository.EndossoTipoAlteracaoRepository;

@Service
public class EndossoTipoAlteracaoService {
	
	@Autowired
	private EndossoTipoAlteracaoRepository repository;
	
	public EndossoTipoAlteracao buscaEndossoTipoAlteracao(Integer codigo){
		EndossoTipoAlteracao endosso = repository.findEndossoTipoAlteracao(codigo);
		return endosso;
	}

}
