package br.com.tokiomarine.ctpj.apolice.repository;


import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigInteger;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.MongoItemApolice;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
@Repository
public class ApoliceRepository {
	
	@Autowired
	@Qualifier("ctpjBackOffice")
	private MongoTemplate mongoTemplate;

	private static Logger logger = LogManager.getLogger(ApoliceRepository.class);

	public Apolice findApoliceBySeqCotacProp(BigInteger sequencialCotacaoProposta)  throws RepositoryException{

		Apolice apolice = null;

		logger.info("Buscando apolice by sequencialCotacaoProposta: "+sequencialCotacaoProposta);

		try{
			apolice = mongoTemplate.findOne(
				query(where("sequencialCotacaoProposta").is(sequencialCotacaoProposta)
							), Apolice.class);
		}catch (Exception e) {
			logger.error("Erro na busca da apólice, sequencialCotacaoProsposta: "+sequencialCotacaoProposta,e);
			throw new RepositoryException("Erro na busca da apólice, sequencialCotacaoProsposta: "+sequencialCotacaoProposta,e);
		}
		return apolice;
	}

	public Apolice findById(String id) {
		ObjectId objectId = new ObjectId(id);
		Apolice apolice = mongoTemplate.findById(objectId, Apolice.class);
		if (apolice.getListItemMongoApolice() != null && !apolice.getListItemMongoApolice().isEmpty()) {
			for (MongoItemApolice mongoApoliceItem : apolice.getListItemMongoApolice()) {
				if (mongoApoliceItem.getIdMongoApolice() != null) {
					Apolice apoliceItem = mongoTemplate.findById(new ObjectId(mongoApoliceItem.getIdMongoApolice()), Apolice.class);
					if (apoliceItem.getListItemApolice() != null && !apoliceItem.getListItemApolice().isEmpty()) {
						if (apolice.getListItemApolice() == null) {
							apolice.setListItemApolice(apoliceItem.getListItemApolice());
						}else{
							apolice.getListItemApolice().addAll(apoliceItem.getListItemApolice());
						}
					}
				}
			}
		}
		return apolice;
	}
	
	public Optional<ItemApolice> findItemApoliceById(String id) {
		Apolice apolice = this.findById(id);
		if(apolice != null && apolice.getListItemApolice() != null && !apolice.getListItemApolice().isEmpty()) {
			return Optional.of(apolice.getListItemApolice().get(0));
		}
		return Optional.empty();
	}
	
	public void save(Apolice apolice) throws RepositoryException {
		try{
			mongoTemplate.save(apolice);
		}catch (Exception e) {
			logger.error("Erro ao salvar apólice, codigoApolice: "+apolice.getCodigoApolice(),e);
			throw new RepositoryException("Erro na busca da apólice, codigoApolice: "+apolice.getCodigoApolice(),e);
		}
	}
}
