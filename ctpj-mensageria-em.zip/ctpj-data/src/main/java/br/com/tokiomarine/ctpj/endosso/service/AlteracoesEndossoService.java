package br.com.tokiomarine.ctpj.endosso.service;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.enums.EndossoSolicitanteMensagemEnum;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.domain.EndossoTipoAlteracao;
import br.com.tokiomarine.ctpj.infra.domain.Produto;

@Service
public class AlteracoesEndossoService {
	
	
	public AlteracaoEndosso bindToDomain(Produto produto, Cotacao endosso,TipoMensagemEndossoEnum tipoMensagem, String descricaoAlteracao,User user){

		AlteracaoEndosso alteracaoEndosso = new AlteracaoEndosso();
		alteracaoEndosso.setCotacao(endosso);
		alteracaoEndosso.setCodigoTipoAlteracao(tipoMensagem.getCodigo());
		alteracaoEndosso.setCodigoGrupoRamo(produto.getGrupoRamo());
		alteracaoEndosso.setCodigoRamo(produto.getRamoProduto());
		String descricaoTipoRegistro = tipoMensagem.getDescricao()+descricaoAlteracao;
		alteracaoEndosso.setDescricaoTipoRegistro(StringUtils.substring(descricaoTipoRegistro, 0, 498));
		alteracaoEndosso.setUsuarioAtualizacao(user.getCdUsuro().longValue());
		alteracaoEndosso.setNumeroCotacaoProposta(endosso.getNumeroCotacaoProposta());
		alteracaoEndosso.setVersaoCotacaoProposta(endosso.getVersaoCotacaoProposta());
		alteracaoEndosso.setDataAtualizacao(new Date());
		alteracaoEndosso.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		return alteracaoEndosso;
	}
	
	public AlteracaoEndosso bindToDomain(Produto produto, Cotacao endosso, EndossoTipoAlteracao endTipoAlteracao, EndossoSolicitanteMensagemEnum endSolicMsgEnum,User user){
		//monta a mensagem
		String descricaoAlteracao = endSolicMsgEnum.getMensagem();

		if(endTipoAlteracao != null && endTipoAlteracao.getDescricao() != null && !endTipoAlteracao.getDescricao().isEmpty()){
			descricaoAlteracao = endTipoAlteracao.getDescricao() + descricaoAlteracao;
		}
		AlteracaoEndosso alteracaoEndosso = new AlteracaoEndosso();
		alteracaoEndosso.setCotacao(endosso);
		alteracaoEndosso.setCodigoTipoAlteracao(endSolicMsgEnum.getTipoMensagem().getCodigo());
		alteracaoEndosso.setCodigoGrupoRamo(produto.getGrupoRamo());
		alteracaoEndosso.setCodigoRamo(produto.getRamoProduto());
		alteracaoEndosso.setDescricaoTipoRegistro(StringUtils.substring(descricaoAlteracao, 0, 498));
		alteracaoEndosso.setUsuarioAtualizacao(user.getCdUsuro().longValue());
		alteracaoEndosso.setNumeroCotacaoProposta(endosso.getNumeroCotacaoProposta());
		alteracaoEndosso.setVersaoCotacaoProposta(endosso.getVersaoCotacaoProposta());
		alteracaoEndosso.setDataAtualizacao(new Date());
		alteracaoEndosso.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		return alteracaoEndosso;
	}
	/**itens**/
	public AlteracaoEndosso bindToDomain(Cotacao endosso, ItemCotacao itemEndosso,TipoMensagemEndossoEnum tipoMensagem, String descricaoAlteracao,User user){
		ItemRamoEmissao itemRamoEmissao = getItemRamoEmissaoFromItemCotacao(itemEndosso);
		AlteracaoEndosso alteracaoEndosso = new AlteracaoEndosso();
		alteracaoEndosso.setCotacao(endosso);
		alteracaoEndosso.setCodigoTipoAlteracao(tipoMensagem.getCodigo());
		alteracaoEndosso.setCodigoGrupoRamo(itemRamoEmissao.getCodigoGrupoRamo());
		alteracaoEndosso.setCodigoRamo(itemRamoEmissao.getCodigoRamo());
		alteracaoEndosso.setItemCotacao(itemEndosso);
		String descricaoTipoRegistro = tipoMensagem.getDescricao()+descricaoAlteracao;
		alteracaoEndosso.setDescricaoTipoRegistro(StringUtils.substring(descricaoTipoRegistro, 0, 498));
		alteracaoEndosso.setUsuarioAtualizacao(user.getCdUsuro().longValue());
		alteracaoEndosso.setNumeroCotacaoProposta(endosso.getNumeroCotacaoProposta());
		alteracaoEndosso.setVersaoCotacaoProposta(endosso.getVersaoCotacaoProposta());
		alteracaoEndosso.setDataAtualizacao(new Date());
		alteracaoEndosso.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		return alteracaoEndosso;
	}
	
	public AlteracaoEndosso bindToDomain(Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,TipoMensagemEndossoEnum tipoMensagem, String descricaoAlteracao,User user){
		ItemRamoEmissao itemRamoEmissao = getItemRamoEmissaoFromItemCotacao(itemEndosso);
		AlteracaoEndosso alteracaoEndosso = new AlteracaoEndosso();
		alteracaoEndosso.setCotacao(endosso);
		alteracaoEndosso.setCodigoTipoAlteracao(tipoMensagem.getCodigo());
		alteracaoEndosso.setCodigoGrupoRamo(itemRamoEmissao.getCodigoGrupoRamo());
		alteracaoEndosso.setCodigoRamo(itemRamoEmissao.getCodigoRamo());
		alteracaoEndosso.setItemCotacao(itemEndosso);
		String descricaoTipoRegistro = tipoMensagem.getDescricao()+descricaoAlteracao;
		alteracaoEndosso.setDescricaoTipoRegistro(StringUtils.substring(descricaoTipoRegistro, 0, 498));
		alteracaoEndosso.setItemCobertura(itemCobertura);
		alteracaoEndosso.setUsuarioAtualizacao(user.getCdUsuro().longValue());
		alteracaoEndosso.setNumeroCotacaoProposta(endosso.getNumeroCotacaoProposta());
		alteracaoEndosso.setVersaoCotacaoProposta(endosso.getVersaoCotacaoProposta());
		alteracaoEndosso.setDataAtualizacao(new Date());
		alteracaoEndosso.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		return alteracaoEndosso;
	}
	
	private ItemRamoEmissao getItemRamoEmissaoFromItemCotacao(ItemCotacao itemCotacao){
		return itemCotacao.getListItemRamoEmissao().iterator().next();//TODO confirmar se está certo
	}
}
