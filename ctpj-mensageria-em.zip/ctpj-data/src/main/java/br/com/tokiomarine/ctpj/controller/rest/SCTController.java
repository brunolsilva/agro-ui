package br.com.tokiomarine.ctpj.controller.rest;

import java.math.BigInteger;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.RelatorioService;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.TipoRelatorioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.sct.form.PesquisaInconsistenciaForm;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;
import br.com.tokiomarine.ctpj.util.DateUtil;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Controller
public class SCTController {

	private static Logger logger = LogManager.getLogger(SCTController.class);

	@Autowired
	private CotacaoService service;

	@Autowired
	private RelatorioService relatorioService;

	@PostMapping(value = "/rest/insereSolicitacao")
	public @ResponseBody ResponseEntity<Object> insereSolicitacao(@RequestBody SolicitacaoCotacao requestSct) {

		String msg = null;
		ResultadoREST<String> responseSct = new ResultadoREST<String>();

		try {

			responseSct.setSuccess(true);
			responseSct.setMensagem("Solicitação inserida com sucesso! ");
			// service.save(requestSct);

		} catch (Exception e) {
			msg = "Erro ao inserir uma solicitação de Cotação no CTPJ \n";
			msg = msg.concat("Request: \n").concat(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(requestSct));
			responseSct.setSuccess(false);
			responseSct.setMensagem(msg.concat(" - erro: ").concat(e.getMessage()));
			logger.error(msg,e);
		}

		return new ResponseEntity<Object>(responseSct,HttpStatus.OK);

	}

	@LogPerformance
	@GetMapping(value = "/relatorio/inconsistenciaCtpj/{numeroCotacaoProposta}")
	public String inconsistenciaCtpj(@PathVariable(value = "numeroCotacaoProposta") Long numeroCotacaoProposta,HttpSession session,HttpServletRequest request,HttpServletResponse response,ModelMap model) {

		try {
			logger.info("Entrando inconsistencia CTPJ");
			model.addAttribute("numeroCotacaoProposta",numeroCotacaoProposta);
			return Paginas.inconsistenciaCtpj.value();
		} catch (final Exception e) {
			model.put("mensagem",e.getMessage());
			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro",e);
			return Paginas.error.value();
		}
	}

	@LogPerformance
	@PostMapping(value = "/relatorio/geraXlsxInconsistenciaCtpj")
	@ResponseBody
	public void geraXlsxInconsistenciaCtpj(@ModelAttribute("pesquisaInconsistenciaForm") PesquisaInconsistenciaForm form,HttpSession session,HttpServletRequest request,HttpServletResponse response) {
		ServletContext context = request.getServletContext();

		byte[] data = null;

		try {
			data = relatorioService.exportXLS(form.getNumeroCotacaoProposta(),context);
			response.setContentType(TipoRelatorioEnum.XLS_CONTENT_TYPE.getText());
			String headerValue = TipoRelatorioEnum.ATTACHMENT_FILENAME.getText().concat(form.getNumeroCotacaoProposta() + "_").concat(DateUtil.dataNomeArquivo()).concat(TipoRelatorioEnum.FILE_TYPE_XLS.getText());
			response.setHeader(TipoRelatorioEnum.CONTENT_DISPOSITION.getText(),headerValue);
			response.setContentLength(data.length);
			response.getOutputStream().write(data);
			response.getOutputStream().flush();
		} catch (Exception e) {
			logger.error("Erro ao gerar XLS inconsistenciaCtpj : ",e);
		}
	}
	
	@LogPerformance
	@GetMapping(value = "/duplica/{numeroCotacao}/{numeroNovo}")
	public @ResponseBody ResultadoREST<Object> duplica(@PathVariable BigInteger numeroCotacao, @PathVariable BigInteger numeroNovo) throws ServiceException {
		service.duplicaCotacao(numeroCotacao,numeroNovo,SecurityUtils.getCurrentUser());
		return null;
	}

}
