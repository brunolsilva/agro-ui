package br.com.tokiomarine.ctpj.cotacao.dto;

public class CreditoDisponivelView {

	private String tipoRecebimento;
	private String banco;
	private String agencia;
	private String nossoNumeroTitulo;
	private String valorCredito;
	private String idCreditoDisponivel;

	public CreditoDisponivelView() {}

	public CreditoDisponivelView(String tipoRecebimento,String banco,String agencia,String nossoNumeroTitulo,String valorCredito,String idCreditoDisponivel) {
		super();
		this.tipoRecebimento = tipoRecebimento;
		this.banco = banco;
		this.agencia = agencia;
		this.nossoNumeroTitulo = nossoNumeroTitulo;
		this.valorCredito = valorCredito;
		this.idCreditoDisponivel = idCreditoDisponivel;
	}

	public String getTipoRecebimento() {
		return tipoRecebimento;
	}

	public void setTipoRecebimento(String tipoRecebimento) {
		this.tipoRecebimento = tipoRecebimento;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getNossoNumeroTitulo() {
		return nossoNumeroTitulo;
	}

	public void setNossoNumeroTitulo(String nossoNumeroTitulo) {
		this.nossoNumeroTitulo = nossoNumeroTitulo;
	}

	public String getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(String valorCredito) {
		this.valorCredito = valorCredito;
	}

	public String getIdCreditoDisponivel() {
		return idCreditoDisponivel;
	}

	public void setIdCreditoDisponivel(String idCreditoDisponivel) {
		this.idCreditoDisponivel = idCreditoDisponivel;
	}

	@Override
	public String toString() {
		return "CreditoDisponivelView [tipoRecebimento=" + tipoRecebimento + ", banco=" + banco + ", agencia=" + agencia + ", nossoNumeroTitulo=" + nossoNumeroTitulo + ", valorCredito=" + valorCredito + ", idCreditoDisponivel=" + idCreditoDisponivel + "]";
	}

}
