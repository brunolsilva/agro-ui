package br.com.tokiomarine.ctpj.cotacao.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.type.Paginas;

/**
 * Controller da página opcoesDeEndosso.jsp
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Controller
@RequestMapping("opcoesDeEndosso")
public class OpcoesDeEndossoController {
	
	@GetMapping
	public String page(){
		return Paginas.opcoesDeEndosso.value();
	}

}
