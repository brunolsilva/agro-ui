package br.com.tokiomarine.ctpj.controller.rest;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.dto.ResultadoREST;

@Controller
public class LogController {

	private static Logger logger = LogManager.getLogger(LogController.class);

	@RequestMapping(value = "/rest/log-level/{logLevel}",method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<Object> mudaLogLevel(@PathVariable(value = "logLevel") String nivelDeLogEscolhido) {

		String logLevelstr = "";
		boolean alterado = false;

		if ("trace".equalsIgnoreCase(nivelDeLogEscolhido) || "t".equalsIgnoreCase(nivelDeLogEscolhido)) {

			logLevelstr = "TRACE";
			LogManager.getRootLogger().setLevel(Level.TRACE);
			alterado = true;
			logger.trace(LogManager.getRootLogger().getLevel());
		} else if ("debug".equalsIgnoreCase(nivelDeLogEscolhido) || "d".equalsIgnoreCase(nivelDeLogEscolhido)) {

			logLevelstr = "DEBUG";
			LogManager.getRootLogger().setLevel(Level.DEBUG);
			alterado = true;
			logger.debug(LogManager.getRootLogger().getLevel());
		} else if ("info".equalsIgnoreCase(nivelDeLogEscolhido) || "i".equalsIgnoreCase(nivelDeLogEscolhido)) {

			logLevelstr = "INFO";
			LogManager.getRootLogger().setLevel(Level.INFO);
			alterado = true;
			logger.info(LogManager.getRootLogger().getLevel());
		} else if ("warn".equalsIgnoreCase(nivelDeLogEscolhido) || "w".equalsIgnoreCase(nivelDeLogEscolhido)) {

			logLevelstr = "WARN";
			LogManager.getRootLogger().setLevel(Level.WARN);
			alterado = true;
			logger.warn(LogManager.getRootLogger().getLevel());
		} else if ("error".equalsIgnoreCase(nivelDeLogEscolhido) || "e".equalsIgnoreCase(nivelDeLogEscolhido)) {

			logLevelstr = "ERROR";
			LogManager.getRootLogger().setLevel(Level.ERROR);
			alterado = true;
			logger.error(LogManager.getRootLogger().getLevel());
		}

		String msgRetorno = "";

		if (alterado) {
			msgRetorno = "log level: " + logLevelstr;
		} else {
			msgRetorno = "erro: informe o nivel de log: trace, debug, info, warn ou error ";
		}

		logger.info(msgRetorno);

		ResultadoREST<String> resultadoREST = new ResultadoREST<String>();
		resultadoREST.setSuccess(true);
		resultadoREST.setMensagem(msgRetorno);

		return new ResponseEntity<Object>(resultadoREST,HttpStatus.OK);
	}

}
