package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemRubricaClausulaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRubricaClausula;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemClausulaRubricaService {
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0212
	 */
	public void validarClausulaRubrica(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiClausulaRubrica = itemEndosso.getListItemRubricaClausula() != null && !itemEndosso.getListItemRubricaClausula().isEmpty();
		boolean itemApolicePossuiClausulaRubrica = itemApolice.getListItemRubricaClausulaApolice() != null && !itemApolice.getListItemRubricaClausulaApolice().isEmpty();
		
		//1 - percorre as clausulas rubrica do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiClausulaRubrica){			
			for(ItemRubricaClausula itemEndossoRubClaus : itemEndosso.getListItemRubricaClausula()){
				boolean clausRubricaExiste = false;
				if(itemApolicePossuiClausulaRubrica){
					for(ItemRubricaClausulaApolice itemApolRubClaus : itemApolice.getListItemRubricaClausulaApolice()){
						if(this.isEquals(itemEndossoRubClaus, itemApolRubClaus)){
							//valida descricao clausula
							this.compararParametrosDescricaoClausula(itemApolRubClaus.getDescricaoClausula(), itemEndossoRubClaus.getDescricaoClausula(), endosso, itemEndosso, itemEndossoRubClaus, alteracoesEndossoList, user);
							clausRubricaExiste = true;
							break;
						}						
					}
				}
				
				//se a clausula não existir
				if(!clausRubricaExiste){ 
					logarInclusaoClausula(itemEndossoRubClaus,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as clausulas rubrica da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiClausulaRubrica){
			for(ItemRubricaClausulaApolice itemApolRubClaus : itemApolice.getListItemRubricaClausulaApolice()){
				boolean clausRubricaExiste = false;
				if(itemEndossoPossuiClausulaRubrica){
					for(ItemRubricaClausula itemEndossoRubClaus : itemEndosso.getListItemRubricaClausula()){
						if(this.isEquals(itemEndossoRubClaus, itemApolRubClaus)){
							clausRubricaExiste = true;
							break;
						}
					}
				}
				
				if(!clausRubricaExiste){
					logarExclusaoClausula(itemApolRubClaus,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoClausula(ItemRubricaClausula itemEndossoRubClaus, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		String descricao = itemEndossoRubClaus.getCodigoClausula()+" do grupo "+itemEndossoRubClaus.getCodigoGrupoRamo()+" ramo "+itemEndossoRubClaus.getCodigoRamo()+" rubrica "+itemEndossoRubClaus.getCodRubrica();
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_CLAUSULA, descricao, user));
	}
	
		
	private void logarExclusaoClausula(ItemRubricaClausulaApolice itemApolRubClaus, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		String descricao = itemApolRubClaus.getCodigoClausula()+" do grupo "+itemApolRubClaus.getCodigoGrupoRamo()+" ramo "+itemApolRubClaus.getCodigoRamo()+" rubrica "+itemApolRubClaus.getCodRubrica();
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_CLAUSULA, descricao, user));
	}
	
	private boolean isEquals(ItemRubricaClausula itemEndossoRubClaus, ItemRubricaClausulaApolice itemApolRubClaus){
		return AssertUtils.compareNull(itemEndossoRubClaus.getCodRubrica(), itemApolRubClaus.getCodRubrica()) &&
				AssertUtils.compareNull(itemEndossoRubClaus.getCodigoGrupoRamo(), itemApolRubClaus.getCodigoGrupoRamo()) &&
				AssertUtils.compareNull(itemEndossoRubClaus.getCodigoRamo(), itemApolRubClaus.getCodigoRamo()) &&
				AssertUtils.compareNull(itemEndossoRubClaus.getCodigoClausula(), itemApolRubClaus.getCodigoClausula());
	}
	
	private void compararParametrosDescricaoClausula(String parametro1, String parametro2,Cotacao endosso,ItemCotacao itemEndosso,ItemRubricaClausula itemEndossoRubClaus,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1,parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append("Rubrica " + itemEndossoRubClaus.getCodRubrica());
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso,itemEndosso, TipoMensagemEndossoEnum.ALT_CLAUSULA, descricaoAlteracao.toString(), user));
		}
	}
}
