package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

public class ReintegracaoISValidator {

	public List<ValidacaoLote> valida(Cotacao cotacao) {
		List<ValidacaoLote> validacao = new ArrayList<>(0);
		for(ItemCotacao item: cotacao.getListItem()) {
			if(item.getListItemSinistro() != null) {
				for(ItemSinistro itemSinistro: item.getListItemSinistro()) {
					if(itemSinistro.getListItemCoberturaSinistro() != null) {
						for(ItemCoberturaSinistro ics: itemSinistro.getListItemCoberturaSinistro()) {
							ItemCobertura itemCobertura = cotacao.getListItem().stream()
									.filter(it -> it.getNumeroItem().equals(BigInteger.valueOf(ics.getItemSinistro().getCodigoItemApoliceEndossada()))
											&& TipoEndossoEnum.REINTEGRA_IS_SINISTRO.getId().equals(it.getIdTipoEndosso()))
									.flatMap(it -> it.getListItemCobertura().stream())
									.filter(cob -> cob.getCodigoCobertura().equals(ics.getCodigoCobertura()))
									.findAny().orElse(null);
							if(itemCobertura != null) {
								BigDecimal valorPagamentoIndenizacao = ics.getValorPagamentoIndenizacao();
								BigDecimal valorJaReintegrado = BigDecimalUtil.nvl(ics.getValorISReintegrada(), BigDecimal.ZERO);
								BigDecimal valorReintegracaoMaximo = valorPagamentoIndenizacao.subtract(valorJaReintegrado);

								BigDecimal diferencaIS = itemCobertura.getValorImportanciaSegurada().subtract(itemCobertura.getValorISOriginal());
								if(diferencaIS.signum() == -1 || diferencaIS.compareTo(valorReintegracaoMaximo) > 0) {
									validacao.add(new ValidacaoLote(itemCobertura.getItemCotacao().getNumeroItem().intValue(), String.format("O valor permitido de reintegração é de até %s", valorReintegracaoMaximo)));
								} else {
									ics.setValorISReintegrada(diferencaIS.add(valorJaReintegrado));
									ics.setDataAtualizacao(new Date());
									ics.setUsuarioAtualizacao(SecurityUtils.getCurrentUser().getCdUsuro().longValue());
									ics.setCodigoGrupo(SecurityUtils.getCurrentUser().getGrupoUsuario().getCdGrp());
								}
							}
						}
					}
				}
			}
		}

		return validacao;
	}
}