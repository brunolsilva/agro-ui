package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DadosAgenciaView implements Serializable {

	private static final long serialVersionUID = -9103565396026675100L;

	private String codigoRetorno;
	private String descricaoCodigoRetorno;
	private Integer p_cd_banco;
	private Long p_cd_agencia;
	private String p_ds_tipo;
	private String p_cd_banco_out;
	private String p_cd_agencia_out;
	private String p_nr_telefone;
	private String p_ds_endereco;
	private String p_cd_cep;
	private String p_ds_bairro;
	private String p_ds_cidade;
	private String p_nm_agencia;

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	public Integer getP_cd_banco() {
		return p_cd_banco;
	}

	public void setP_cd_banco(Integer p_cd_banco) {
		this.p_cd_banco = p_cd_banco;
	}

	public Long getP_cd_agencia() {
		return p_cd_agencia;
	}

	public void setP_cd_agencia(Long p_cd_agencia) {
		this.p_cd_agencia = p_cd_agencia;
	}

	public String getP_ds_tipo() {
		return p_ds_tipo;
	}

	public void setP_ds_tipo(String p_ds_tipo) {
		this.p_ds_tipo = p_ds_tipo;
	}

	public String getP_cd_banco_out() {
		return p_cd_banco_out;
	}

	public void setP_cd_banco_out(String p_cd_banco_out) {
		this.p_cd_banco_out = p_cd_banco_out;
	}

	public String getP_cd_agencia_out() {
		return p_cd_agencia_out;
	}

	public void setP_cd_agencia_out(String p_cd_agencia_out) {
		this.p_cd_agencia_out = p_cd_agencia_out;
	}

	public String getP_nr_telefone() {
		return p_nr_telefone;
	}

	public void setP_nr_telefone(String p_nr_telefone) {
		this.p_nr_telefone = p_nr_telefone;
	}

	public String getP_ds_endereco() {
		return p_ds_endereco;
	}

	public void setP_ds_endereco(String p_ds_endereco) {
		this.p_ds_endereco = p_ds_endereco;
	}

	public String getP_cd_cep() {
		return p_cd_cep;
	}

	public void setP_cd_cep(String p_cd_cep) {
		this.p_cd_cep = p_cd_cep;
	}

	public String getP_ds_bairro() {
		return p_ds_bairro;
	}

	public void setP_ds_bairro(String p_ds_bairro) {
		this.p_ds_bairro = p_ds_bairro;
	}

	public String getP_ds_cidade() {
		return p_ds_cidade;
	}

	public void setP_ds_cidade(String p_ds_cidade) {
		this.p_ds_cidade = p_ds_cidade;
	}

	public String getP_nm_agencia() {
		return p_nm_agencia;
	}

	public void setP_nm_agencia(String p_nm_agencia) {
		this.p_nm_agencia = p_nm_agencia;
	}

	@Override
	public String toString() {
		return "DadosAgenciaView [codigoRetorno=" + codigoRetorno + ", descricaoCodigoRetorno=" + descricaoCodigoRetorno
				+ ", p_cd_banco=" + p_cd_banco + ", p_cd_agencia=" + p_cd_agencia + ", p_ds_tipo=" + p_ds_tipo
				+ ", p_cd_banco_out=" + p_cd_banco_out + ", p_cd_agencia_out=" + p_cd_agencia_out + ", p_nr_telefone="
				+ p_nr_telefone + ", p_ds_endereco=" + p_ds_endereco + ", p_cd_cep=" + p_cd_cep + ", p_ds_bairro="
				+ p_ds_bairro + ", p_ds_cidade=" + p_ds_cidade + ", p_nm_agencia=" + p_nm_agencia + "]";
	}
}