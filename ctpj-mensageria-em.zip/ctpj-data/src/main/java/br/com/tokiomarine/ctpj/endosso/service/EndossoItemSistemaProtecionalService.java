package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemSistemaProtecionalApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemSistemaProtecionalService {
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0117
	 */
	public void validarSistemasProtecao(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiSistemasProtecao = itemEndosso.getListItemSistemaProtecional() != null && !itemEndosso.getListItemSistemaProtecional().isEmpty();
		boolean itemApolicePossuiSistemasProtecao = itemApolice.getListItemSistemaProtecionalApolice() != null && !itemApolice.getListItemSistemaProtecionalApolice().isEmpty();
		
		//1 - percorre os sistemas de proteção do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiSistemasProtecao){			
			for(ItemSistemaProtecional itemEndossoSistProt : itemEndosso.getListItemSistemaProtecional()){
				boolean sistProtExiste = false;
				if(itemApolicePossuiSistemasProtecao){
					for(ItemSistemaProtecionalApolice itemApolSistProt : itemApolice.getListItemSistemaProtecionalApolice()){
						if(AssertUtils.compareNull(itemEndossoSistProt.getCodigoSistemaProtecional(),itemApolSistProt.getCodigoSistemaProtecional())){
							sistProtExiste = true;
							break;
						}						
					}
				}
				
				//se o item relacao bem não existir
				if(!sistProtExiste){ 
					logarInclusaoSistemaProtecional(itemEndossoSistProt,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os sistemas protecionais da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiSistemasProtecao){
			for(ItemSistemaProtecionalApolice itemApolSistProt : itemApolice.getListItemSistemaProtecionalApolice()){
				boolean sistProtExiste = false;
				if(itemEndossoPossuiSistemasProtecao){
					for(ItemSistemaProtecional itemEndossoSistProt : itemEndosso.getListItemSistemaProtecional()){
						if(AssertUtils.compareNull(itemEndossoSistProt.getCodigoSistemaProtecional(),itemApolSistProt.getCodigoSistemaProtecional())){
							sistProtExiste = true;
							break;
						}
					}
				}
				
				if(!sistProtExiste){
					logarExclusaoItem(itemApolSistProt,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoSistemaProtecional(ItemSistemaProtecional itemEndossoSistProt, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_SISTEMA_PROTEC, itemEndossoSistProt.getCodigoSistemaProtecional().toString(), user));
	}
	
		
	private void logarExclusaoItem(ItemSistemaProtecionalApolice itemApolSistProt, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_SISTEMA_PROTEC, itemApolSistProt.getCodigoSistemaProtecional().toString(), user));
	}
}
