package br.com.tokiomarine.ctpj.integracao.col.response;

import java.io.Serializable;

public class ColaboradorMatriculaResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5478217458001096176L;
	private Long matricula;
	private String nome;
	private String email;
	private String loginAD;

	public Long getMatricula() {
		return matricula;
	}

	public void setMatricula(Long matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLoginAD() {
		return loginAD;
	}

	public void setLoginAD(String loginAD) {
		this.loginAD = loginAD;
	}

}
