package br.com.tokiomarine.ctpj.dto;

import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.util.VariaveisAmbienteUtil;

public class CDN {

	public CDN() {
		publico = "https://cdnpub.tokiomarine.com.br/portal_static/publico";//VariaveisAmbienteUtil.getCdnPublico();
		restrito = VariaveisAmbienteUtil.getCdnRestrito();
		versao = CTP.cdnVersao.value();
	}

	private final String publico;
	private final String restrito;
	private final String versao;

	public String getPublico() {
		return publico;
	}

	public String getRestrito() {
		return restrito;
	}

	public String getVersao() {
		return versao;
	}

}
