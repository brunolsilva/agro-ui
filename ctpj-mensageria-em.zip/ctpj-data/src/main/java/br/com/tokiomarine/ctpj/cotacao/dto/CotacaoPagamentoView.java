package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CotacaoPagamentoView implements Serializable{

	private static final long serialVersionUID = 4492177347420559452L;

	private BigInteger cotacao;
	private BigDecimal entrada;
	private BigDecimal demais;
	private BigDecimal total;
	private BigDecimal premioLiquido;
	private String formaPagamento;
	private String plano;
	private String idImpressao;
	private BigInteger opcaoSelecionada;
	private BigInteger sqOpcao;

	public BigDecimal getEntrada() {
		return entrada;
	}

	public void setEntrada(BigDecimal entrada) {
		this.entrada = entrada;
	}

	public BigDecimal getDemais() {
		return demais;
	}

	public void setDemais(BigDecimal demais) {
		this.demais = demais;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getPlano() {
		return plano;
	}

	public void setPlano(String plano) {
		this.plano = plano;
	}

	public BigInteger getCotacao() {
		return cotacao;
	}

	public void setCotacao(BigInteger cotacao) {
		this.cotacao = cotacao;
	}

	public BigInteger getOpcaoSelecionada() {
		return opcaoSelecionada;
	}

	public void setOpcaoSelecionada(BigInteger opcaoSelecionada) {
		this.opcaoSelecionada = opcaoSelecionada;
	}

	public BigDecimal getPremioLiquido() {
		return premioLiquido;
	}

	public void setPremioLiquido(BigDecimal premioLiquido) {
		this.premioLiquido = premioLiquido;
	}

	public String getIdImpressao() {
		return idImpressao;
	}

	public void setIdImpressao(String idImpressao) {
		this.idImpressao = idImpressao;
	}

	public BigInteger getSqOpcao() {
		return sqOpcao;
	}

	public void setSqOpcao(BigInteger sqOpcao) {
		this.sqOpcao = sqOpcao;
	}
}