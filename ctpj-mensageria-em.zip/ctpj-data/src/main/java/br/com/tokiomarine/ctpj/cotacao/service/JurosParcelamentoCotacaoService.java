package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.JurosPagamentoCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.JurosParcelamentoCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.repository.JurosParcelamentoCotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.JurosParcelamentoCotacao;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.FormaPagamento;
import br.com.tokiomarine.ctpj.infra.domain.FormaParcelamento;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaPagamentoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaParcelamentoRepository;
import br.com.tokiomarine.ctpj.mapper.JurosParcelamentoCotacaoMapper;
import br.com.tokiomarine.ctpj.mapper.NumberMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Service
@Transactional(rollbackFor = {ServiceException.class,Exception.class})
public class JurosParcelamentoCotacaoService {

	@Autowired
	private JurosParcelamentoCotacaoRepository jurosParcelamentoCotacaoRepository;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private FormaPagamentoRepository formaPagamentoRepository;
	
	@Autowired
	private FormaParcelamentoRepository formaParcelamentoRepository;


	public List<JurosPagamentoCotacaoView> toListOfJurosPagamentoCotacaoView(BigInteger sequencialCotacaoProposta){

		List<JurosParcelamentoCotacaoView> listaJurosParcelamentoCotacaoView = toListOfJurosParcelamentoCotacaoView(sequencialCotacaoProposta);
		List<JurosPagamentoCotacaoView> listaJurosPagamentoCotacaoView = new ArrayList<>();
		
		Comparator<JurosParcelamentoCotacaoView> comparator = Comparator.comparing(JurosParcelamentoCotacaoView::getCodigoFormaPagamento)
				.thenComparing(JurosParcelamentoCotacaoView::getDescricaoFormaPagamento);
		
		Set<JurosParcelamentoCotacaoView> semDuplicadas = new TreeSet<>(comparator);
		semDuplicadas.addAll(listaJurosParcelamentoCotacaoView);
		
		for (JurosParcelamentoCotacaoView jurosParcelamentoCotacaoView : semDuplicadas) {
			JurosPagamentoCotacaoView jurosPagamentoCotacaoView = new JurosPagamentoCotacaoView();
			jurosPagamentoCotacaoView.setCodigoFormaPagamento(jurosParcelamentoCotacaoView.getCodigoFormaPagamento());
			jurosPagamentoCotacaoView.setDescricaoFormaPagamento(jurosParcelamentoCotacaoView.getDescricaoFormaPagamento());
			listaJurosPagamentoCotacaoView.add(jurosPagamentoCotacaoView);
		}
		
		for (JurosPagamentoCotacaoView jurosPagamentoCotacaoView: listaJurosPagamentoCotacaoView){
			List<JurosParcelamentoCotacaoView> listaJurosPagamentoParcelamentoCotacaoView= new ArrayList<>();
			for (JurosParcelamentoCotacaoView jurosParcelamentoCotacaoView : listaJurosParcelamentoCotacaoView
					.stream()
					.filter(j->j.getCodigoFormaPagamento().equals(jurosPagamentoCotacaoView.getCodigoFormaPagamento()))
					.collect(Collectors.toList())){
				listaJurosPagamentoParcelamentoCotacaoView.add(jurosParcelamentoCotacaoView);
			}
			jurosPagamentoCotacaoView.setListaJurosParcelamentoCotacao(listaJurosPagamentoParcelamentoCotacaoView);
		}
		
		return listaJurosPagamentoCotacaoView;
	}
	
	public List<JurosParcelamentoCotacaoView> toListOfJurosParcelamentoCotacaoView(BigInteger sequencialCotacaoProposta){
		return  toListOfJurosParcelamentoCotacaoView(jurosParcelamentoCotacaoRepository
				.list(sequencialCotacaoProposta))
				.stream()
				.sorted(Comparator.comparing(JurosParcelamentoCotacaoView::getDescricaoFormaPagamento)
						.thenComparing(JurosParcelamentoCotacaoView::getDecricaoFormaParcelamento))
				.collect(Collectors.toList())
				;		
	}
	
	public List<JurosParcelamentoCotacaoView> toListOfJurosParcelamentoCotacaoView(List<JurosParcelamentoCotacao> listaJurosParcelamentoCotacao){
		List<JurosParcelamentoCotacaoView> listaJurosParcelamentoCotacaoView = new ArrayList<>();

		Map<Integer, FormaPagamento> listaFormaPagamento = formaPagamentoRepository.findFormasPagamentoByCodigo(
				listaJurosParcelamentoCotacao
				.stream()
				.map(JurosParcelamentoCotacao::getCodigoFormaPagamento)
				.collect(Collectors.toList()));
		
		Map<Integer, FormaParcelamento> listaFormaParcelamento = formaParcelamentoRepository.findFormasParcelamentoByCodigo(
				listaJurosParcelamentoCotacao
				.stream()
				.map(JurosParcelamentoCotacao::getCodigoFormaParcelamento)
				.collect(Collectors.toList()));

		listaJurosParcelamentoCotacao.forEach(jurosParcelamentoCotacao -> {
			listaJurosParcelamentoCotacaoView.add(JurosParcelamentoCotacaoMapper.toJurosParcelamentoCotacaoView(jurosParcelamentoCotacao,
					listaFormaPagamento.get(jurosParcelamentoCotacao.getCodigoFormaPagamento()),
					listaFormaParcelamento.get(jurosParcelamentoCotacao.getCodigoFormaParcelamento())));
		});
		
		return listaJurosParcelamentoCotacaoView;
	}

	public void updateJurosParcelamentoCotacao(JurosParcelamentoCotacaoView jurosParcelamentoCotacaoView) throws ServiceException {
		User user = SecurityUtils.getCurrentUser();
		JurosParcelamentoCotacao jurosParcelamentoCotacao = jurosParcelamentoCotacaoRepository
				.findBySequencialJurosParcelamentoCotacao(jurosParcelamentoCotacaoView.getSequencialJurosParcelamentoCotacao());
		jurosParcelamentoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		jurosParcelamentoCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
		jurosParcelamentoCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
		if (jurosParcelamentoCotacao.getPercentualJuros().compareTo(new NumberMapper().asDecimal(jurosParcelamentoCotacaoView.getPercentualJuros())) != 0){
			jurosParcelamentoCotacao.setPercentualJuros(new NumberMapper().asDecimal(jurosParcelamentoCotacaoView.getPercentualJuros()));
			jurosParcelamentoCotacaoRepository.update(jurosParcelamentoCotacao);
			
			Cotacao cotacao = cotacaoService.findCotacaoByNrCotacAndVsCotac(jurosParcelamentoCotacao.getNumeroCotacaoProposta(),jurosParcelamentoCotacao.getVersaoCotacaoProposta());
			cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
			cotacaoService.saveCotacao(cotacao);			
		}
	}

}
