package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CosseguroView implements Serializable {

	private static final long serialVersionUID = 9129102205560840858L;

	private Integer codigoCompanhiaSeguradora;
	private String nomeCompanhiaSeguradora;
	private String percentualCosseguro;
	private String percentualComissaoDiferenciada;
	private BigInteger sequencialCotacaoProposta;

	public Integer getCodigoCompanhiaSeguradora() {
		return codigoCompanhiaSeguradora;
	}

	public void setCodigoCompanhiaSeguradora(Integer codigoCompanhiaSeguradora) {
		this.codigoCompanhiaSeguradora = codigoCompanhiaSeguradora;
	}

	public String getNomeCompanhiaSeguradora() {
		return nomeCompanhiaSeguradora;
	}

	public void setNomeCompanhiaSeguradora(String nomeCompanhiaSeguradora) {
		this.nomeCompanhiaSeguradora = nomeCompanhiaSeguradora;
	}

	public String getPercentualCosseguro() {
		return percentualCosseguro;
	}

	public void setPercentualCosseguro(String percentualCosseguro) {
		this.percentualCosseguro = percentualCosseguro;
	}

	public String getPercentualComissaoDiferenciada() {
		return percentualComissaoDiferenciada;
	}

	public void setPercentualComissaoDiferenciada(String percentualComissaoDiferenciada) {
		this.percentualComissaoDiferenciada = percentualComissaoDiferenciada;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}
}