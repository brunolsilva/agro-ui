package br.com.tokiomarine.ctpj.cotacao.service;

import java.net.URL;

import javax.xml.namespace.QName;

import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.dadosconta.AgenciaVO;
import br.com.tokiomarine.ctpj.integracao.dadosconta.FEBWS;
import br.com.tokiomarine.ctpj.integracao.dadosconta.FEBWS_Service;

@Service
public class AgenciaService {
	
	private final static String URL_FEBWS_WSDL= "http://srvprtapp003a.tokiomarine.com.br:9080/FEBWS/br.com.tokiomarine.seguradora.feb.consulta.FEBWS?wsdl";
	private final static String NAME_SERVICE_CONSULTA_AGENCIA= "FEBWS";
	
	@LogPerformance
	public AgenciaVO consultaAgencia(String banco, String agencia) throws ServiceException {
		try {
			QName SERVICE_NAME = new QName(NAME_SERVICE_CONSULTA_AGENCIA, NAME_SERVICE_CONSULTA_AGENCIA);
			URL uri = new URL(URL_FEBWS_WSDL);

			FEBWS_Service ss = new FEBWS_Service(uri,SERVICE_NAME);
			FEBWS port = ss.getFEBWSPort();
			
			return port.infoAgencia(banco, agencia);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage(), e);
		}
	}

}
