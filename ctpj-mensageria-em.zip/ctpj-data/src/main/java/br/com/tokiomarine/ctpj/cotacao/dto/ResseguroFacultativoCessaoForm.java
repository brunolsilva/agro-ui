package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.NotNull;

public class ResseguroFacultativoCessaoForm implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer numeroItemFaixa;

	@NotNull(message = "Valor IS/LMG inicial é obrigatório")
	private BigDecimal valorInicial;

	@NotNull(message = "Valor IS/LMG final é obrigatório")
	private BigDecimal valorFinal;

	@NotNull(message = "Percentual cedido é obrigatório")
	private BigDecimal percentualCedido;
	
	@NotNull(message = "Percentual retido é obrigatório")
	private BigDecimal percentualRetido;

	private List<ResseguroFacultativoFaixaForm> resseguroFacultativoFaixaList;

	public Integer getNumeroItemFaixa() {
		return numeroItemFaixa;
	}

	public void setNumeroItemFaixa(Integer numeroItemFaixa) {
		this.numeroItemFaixa = numeroItemFaixa;
	}

	public BigDecimal getValorInicial() {
		return valorInicial;
	}

	public void setValorInicial(BigDecimal valorInicial) {
		this.valorInicial = valorInicial;
	}

	public BigDecimal getValorFinal() {
		return valorFinal;
	}

	public void setValorFinal(BigDecimal valorFinal) {
		this.valorFinal = valorFinal;
	}

	public BigDecimal getPercentualCedido() {
		return percentualCedido;
	}

	public void setPercentualCedido(BigDecimal percentualCedido) {
		this.percentualCedido = percentualCedido;
	}

	public List<ResseguroFacultativoFaixaForm> getResseguroFacultativoFaixaList() {
		return resseguroFacultativoFaixaList;
	}

	public void setResseguroFacultativoFaixaList(List<ResseguroFacultativoFaixaForm> resseguroFacultativoFaixaList) {
		this.resseguroFacultativoFaixaList = resseguroFacultativoFaixaList;
	}

	public BigDecimal getPercentualRetido() {
		return percentualRetido;
	}

	public void setPercentualRetido(BigDecimal percentualRetido) {
		this.percentualRetido = percentualRetido;
	}

	@Override
	public String toString() {
		return "ResseguroFacultativoCessaoForm [numeroItemFaixa=" + numeroItemFaixa + ", valorInicial=" + valorInicial + ", valorFinal=" + valorFinal + ", percentualCedido=" + percentualCedido + ", resseguroFacultativoFaixaList=" + resseguroFacultativoFaixaList + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numeroItemFaixa == null) ? 0 : numeroItemFaixa.hashCode());
		result = prime * result + ((percentualCedido == null) ? 0 : percentualCedido.hashCode());
		result = prime * result + ((percentualRetido == null) ? 0 : percentualRetido.hashCode());
		result = prime * result + ((resseguroFacultativoFaixaList == null) ? 0 : resseguroFacultativoFaixaList.hashCode());
		result = prime * result + ((valorFinal == null) ? 0 : valorFinal.hashCode());
		result = prime * result + ((valorInicial == null) ? 0 : valorInicial.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResseguroFacultativoCessaoForm other = (ResseguroFacultativoCessaoForm) obj;
		if (numeroItemFaixa == null) {
			if (other.numeroItemFaixa != null)
				return false;
		} else if (!numeroItemFaixa.equals(other.numeroItemFaixa))
			return false;
		if (percentualCedido == null) {
			if (other.percentualCedido != null)
				return false;
		} else if (!percentualCedido.equals(other.percentualCedido))
			return false;
		if (percentualRetido == null) {
			if (other.percentualRetido != null)
				return false;
		} else if (!percentualRetido.equals(other.percentualRetido))
			return false;
		if (resseguroFacultativoFaixaList == null) {
			if (other.resseguroFacultativoFaixaList != null)
				return false;
		} else if (!resseguroFacultativoFaixaList.equals(other.resseguroFacultativoFaixaList))
			return false;
		if (valorFinal == null) {
			if (other.valorFinal != null)
				return false;
		} else if (!valorFinal.equals(other.valorFinal))
			return false;
		if (valorInicial == null) {
			if (other.valorInicial != null)
				return false;
		} else if (!valorInicial.equals(other.valorInicial))
			return false;
		return true;
	}

}
