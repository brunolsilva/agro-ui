package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

public class CoberturaBasicaValidator {

	private static Logger logger = LogManager.getLogger(CoberturaBasicaValidator.class);
	
	public List<ValidacaoLote> validacaoCoberturaBasica(Cotacao cotacao) {
		logger.info("Inicio da validacao de Cobertura Basica " + cotacao.getSequencialCotacaoProposta());
		
		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		
		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			dadosBasicosCobertura(listaValidacao, itemCotacao);
		}
		
		logger.info("Fim da validacao de Cobertura Basica " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}

	private void dadosBasicosCobertura(List<ValidacaoLote> listaValidacao, ItemCotacao itemCotacao) {
		MoedaEnum moeda = itemCotacao.getCotacao().getCodigoMoeda();
		
		for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
			if(itemCobertura.getIdTipoCobertura() != null && itemCobertura.getIdTipoCobertura().equals(1)) {
				if(itemCobertura.getCodigoCobertura() == null) {
					listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), "Obrigatório informar a Cobertura Básica"));
				}
				
				validaValoresCoberturaBasica(itemCobertura, moeda, listaValidacao, itemCotacao.getNumeroItem().intValue());
			} else if(itemCobertura.getCodigoCobertura() == null) {
				listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), "Obrigatório informar a Cobertura Básica"));
			}
		}
	}

	private void validaValoresCoberturaBasica(
			ItemCobertura itemCobertura,
			MoedaEnum moeda,
			List<ValidacaoLote> listaValidacao,
			Integer numeroItem) {
		if(moeda == MoedaEnum.REAL) {
			if(itemCobertura.getValorImportanciaSegurada() == null) {
				listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o LMI"));
			} else {
				BigDecimal percentualLimiteCobertura = itemCobertura.getPerfilCalculoCoberturaLimiteIs().getPercentualLimiteCobertura();
				BigDecimal valorMaximoIS = itemCobertura.getPerfilCalculoCoberturaLimiteIs().getValorMaximoIS();
				BigDecimal valorMinimoIS = itemCobertura.getPerfilCalculoCoberturaLimiteIs().getValorMinimoIS();

				if(valorMaximoIS != null && itemCobertura.getValorImportanciaSegurada() != null) {
					if(BigDecimalUtil.maior(itemCobertura.getValorImportanciaSegurada(),valorMaximoIS)) {
						itemCobertura.setValorImportanciaSegurada(valorMaximoIS);
						itemCobertura.setDescricaoCoberturaAjustada(
								String.format("A contratação da cobertura %s,<br> está limitada ao mínimo de R$%s e o máximo de R$%s",
								itemCobertura.getDescricaoCobertura(),
								BigDecimalUtil.formatBigDecimal(valorMinimoIS,2),
								BigDecimalUtil.formatBigDecimal(valorMaximoIS,2)
						));
					}
				}

				if(itemCobertura.getItemCotacao().getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
					if(valorMinimoIS != null && itemCobertura.getValorImportanciaSegurada() != null) {
						if(BigDecimalUtil.menor(itemCobertura.getValorImportanciaSegurada(),valorMinimoIS)) {
							itemCobertura.setValorImportanciaSegurada(valorMinimoIS);
							itemCobertura.setDescricaoCoberturaAjustada(
									String.format("A contratação da cobertura %s,<br> está limitada ao mínimo de R$%s e o máximo de R$%s",
									itemCobertura.getDescricaoCobertura(),
									BigDecimalUtil.formatBigDecimal(valorMinimoIS,2),
									BigDecimalUtil.formatBigDecimal(valorMaximoIS,2)
							));
						}
					}
				}
			}
		} else {
			if(itemCobertura.getValorISMoedaEstrangeira() == null) {
				listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o LMI"));
			}
		}
		
		if(itemCobertura.getIdTipoCobertura().equals(1)) {
			validaISVR(moeda, itemCobertura,listaValidacao);
		}
	}

	private void validaISVR(MoedaEnum moeda, ItemCobertura itemCobertura, List<ValidacaoLote> listaValidacao) {
		if((moeda == MoedaEnum.REAL && itemCobertura.getValorImportanciaSegurada() != null && itemCobertura.getItemCotacao().getValorRiscoBemCalculado() != null) 
				|| (moeda == MoedaEnum.DOLAR_VENDA && itemCobertura.getValorISMoedaEstrangeira() != null && itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira() != null)) {
			BigDecimal isVR = BigDecimal.ZERO;
			
			if (itemCobertura.getItemCotacao().getCotacao().getIdLmiUnico().equals(SimNaoEnum.SIM)){
				isVR = BigDecimalUtil.truncComDecimais(5,BigDecimalUtil.truncComDecimais(5,itemCobertura.getValorSublimite()
						.multiply(BigDecimalUtil.truncComDecimais(5,new BigDecimal("100")),MathContext.DECIMAL128)));
			}else{
				isVR = BigDecimalUtil.truncComDecimais(5,BigDecimalUtil.truncComDecimais(5,itemCobertura.getValorImportanciaSegurada()
						.multiply(BigDecimalUtil.truncComDecimais(5,new BigDecimal("100")),MathContext.DECIMAL128)));
			}

			BigDecimal resultado = BigDecimalUtil.truncComDecimais(5,isVR.divide(BigDecimalUtil.truncComDecimais(5,itemCobertura.getItemCotacao().getValorRiscoBemCalculado()),MathContext.DECIMAL128));

			BigDecimal isVRMin = itemCobertura.getPerfilCalculoCoberturaLimiteIs().getPercentualISVRMin();
			BigDecimal isVRMax = itemCobertura.getPerfilCalculoCoberturaLimiteIs().getPercentualISVRMax();

			if(!BigDecimalUtil.maiorIgual(resultado,isVRMin)) {
				itemCobertura.setValorImportanciaSegurada(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
				itemCobertura.setDescricaoCoberturaAjustada("O LMI mínimo para a cobertura Básica é de 40% do Valor em Risco.");
			}

			if(!BigDecimalUtil.menorIgual(resultado,isVRMax)) {
				itemCobertura.setValorImportanciaSegurada(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
				itemCobertura.setDescricaoCoberturaAjustada("O LMI da cobertura Básica esta limitado em até 100% do Valor em Risco.");
			}
		}
	}
}