package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.ProdutoServico;
import br.com.tokiomarine.ctpj.infra.domain.Servico;

@Repository
public class ServicoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public Servico findServicoByCodigo(Integer codigo) {
		return mongoTemplate.findOne(query(where("codigo").is(codigo)),Servico.class);
	}

	public List<ProdutoServico> findProdutoServico(Integer produto,Date dataInicioVigencia) {
		return mongoTemplate.find(query(where("produto").is(produto).and("dataInicioVigencia").lte(new Date()).orOperator(where("dataTerminoVigencia").gte(new Date()),where("dataTerminoVigencia").is(null))

		).with(new Sort(Direction.ASC,"servico")),ProdutoServico.class);
	}

}
