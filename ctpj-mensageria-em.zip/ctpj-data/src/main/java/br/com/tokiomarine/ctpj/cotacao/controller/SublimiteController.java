package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaAdicionar;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemSublimiteView;
import br.com.tokiomarine.ctpj.cotacao.dto.SublimiteView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.SublimiteService;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;

@Controller
@RequestMapping(value = "/sublimite")
public class SublimiteController extends AbstractController {
	
	private static Logger logger = LogManager.getLogger(FranquiaController.class);
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private SublimiteService sublimiteService;
	
	@LogPerformance
	@GetMapping(value = "/{sqCotacao}")
	public String sublimites(@PathVariable BigInteger sqCotacao, Model model, HttpServletRequest request) {

		limpaMensagens(request);

		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(sqCotacao);
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			Map<String, List<SublimiteView>> sublimites = sublimiteService.getSublimites(sqCotacao);

			model.addAttribute("sublimites",sublimites);
			sublimites.forEach((k,v) -> {
				v.get(0).getItems().sort(null);
				model.addAttribute("items", v.get(0).getItems());
			});

			model.addAttribute("produto", cotacaoView.getNomeProduto());
			model.addAttribute("numeroCotacaoProposta", cotacaoView.getNumeroCotacaoProposta());
			model.addAttribute("sqCotacao", cotacaoView.getSequencialCotacaoProposta());
			model.addAttribute("readOnly",
					CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly() 
					|| cotacaoView.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.REINTEGRACAO_IS);
		} catch (ServiceException e) {
			logger.error("Erro ao carregar os sublimites: ", e);
		}

		return "/cotacao/cobertura/sublimite";
	}

	@LogPerformance
	@PostMapping(value = "/saveSublimite")
	public @ResponseBody ResultadoREST<String> saveSublimite(@RequestBody List<ItemSublimiteView> sublimites) {
		ResultadoREST<String> resultado = new ResultadoREST<>();
		try {
			return sublimiteService.saveSublimite(sublimites);
		} catch(ServiceException e) {
			logger.error("Erro ao atualizar os sublimites ", e);
			resultado.setSuccess(false);
			return resultado;
		}
	}

	@LogPerformance
	@PostMapping(value = "/adicionaCobertura")
	public @ResponseBody ResultadoREST<SublimiteView> saveSublimite(@RequestBody CoberturaAdicionar coberturaAdicionar) {
		ResultadoREST<SublimiteView> resultado = new ResultadoREST<>();
		try {
			resultado = sublimiteService.adicionaCobertura(coberturaAdicionar);
			return resultado;
		} catch(Exception e) {
			logger.error("Erro ao Inserir Cobertura (Sublimite) ", e);
			resultado.setSuccess(false);
			return resultado;
		}
	}
}