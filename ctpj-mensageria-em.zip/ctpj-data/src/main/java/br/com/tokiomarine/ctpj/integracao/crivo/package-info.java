@javax.xml.bind.annotation.XmlSchema(namespace = "http://helper.vo.apps.co.tokiomarine.com.br", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.tokiomarine.ctpj.integracao.crivo;
