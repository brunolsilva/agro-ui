package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.dto.ListOfItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.TotalPercentuaisDistribIgual100Porcento;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class TotalPercentuaisDistribIgual100PorcentoValidator implements ConstraintValidator<TotalPercentuaisDistribIgual100Porcento, ListOfItemBeneficiarioView> {

	private static final BigDecimal CEM = BigDecimal.valueOf(100.0);
	
	@Override
	public void initialize(TotalPercentuaisDistribIgual100Porcento constraintAnnotation) {
		
	}

	@Override
	public boolean isValid(ListOfItemBeneficiarioView listOfItemView, ConstraintValidatorContext validatorContext) {
		if(listOfItemView.isEmpty())
			return true;
		
		boolean ehValido = true;
		
		Map<BigInteger, List<ItemBeneficiarioView>> beneficiariosPorNumeroItemCotacao = listOfItemView.stream()
				.filter(beneficiario -> beneficiario.getPercentualDistribuicao() != null)
				.collect(Collectors.groupingBy(ItemBeneficiarioView::getNumeroItemCotacao));
		
		for(BigInteger nroItemCotacao : beneficiariosPorNumeroItemCotacao.keySet()){
			BigDecimal somaPercentualDistribuicao = beneficiariosPorNumeroItemCotacao.get(nroItemCotacao).stream().map(ItemBeneficiarioView::getPercentualDistribuicao).reduce(BigDecimal.ZERO, (a, b) -> a.add(b));
			
			if(!(somaPercentualDistribuicao.compareTo(CEM) == 0)){
				ehValido = false;
				validatorContext.disableDefaultConstraintViolation();
				validatorContext.buildConstraintViolationWithTemplate("A soma dos valores da distribuição percentual para o item " + nroItemCotacao + " deve ser igual a 100%").addConstraintViolation();
			}	
				
		}		
		
		return ehValido;
	}
}
