package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import java.math.BigDecimal;

import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorMonetarioRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorPercentualRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorStringRelatorio;

public class DadosRelatorioCessao {

	private static final FormatadorStringRelatorio FORMATADOR_STRING = new FormatadorStringRelatorio();
	private static final FormatadorMonetarioRelatorio FORMATADOR_MONETARIO = new FormatadorMonetarioRelatorio();
	private static final FormatadorPercentualRelatorio FORMATADOR_PERCENTUAL = new FormatadorPercentualRelatorio();
	
	private Integer faixa;
	private BigDecimal valorInicial;
	private BigDecimal valorFinal;
	private BigDecimal percentualCedidoEmResseguro;	
	private BigDecimal percentualRetidoEmResseguro;

	public DadosRelatorioCessao(){
		
	}
	
	public DadosRelatorioCessao(Integer faixa, BigDecimal valorInicial, BigDecimal valorFinal, BigDecimal percentualCedidoEmResseguro) {
		this.faixa = faixa;
		this.valorInicial = valorInicial;
		this.valorFinal = valorFinal;
		this.percentualCedidoEmResseguro = percentualCedidoEmResseguro;
	}

	public String getFormatedFaixa() {
		return FORMATADOR_STRING.asString(faixa);
	}

	public String getValorInicial() {
		return FORMATADOR_MONETARIO.asMoney(valorInicial);
	}

	public String getFormatedValorFinal() {
		return FORMATADOR_MONETARIO.asMoney(valorFinal);
	}

	public String getFormatedPercentualCedidoEmResseguro() {
		return FORMATADOR_PERCENTUAL.asPercent(percentualCedidoEmResseguro);
	}
	
	public String getFormatedPercentulRetidoEmResseguro(){
		return FORMATADOR_PERCENTUAL.asPercent(percentualRetidoEmResseguro); 
	}

	public void setFaixa(Integer faixa) {
		this.faixa = faixa;
	}

	public void setValorInicial(BigDecimal valorInicial) {
		this.valorInicial = valorInicial;
	}

	public void setValorFinal(BigDecimal valorFinal) {
		this.valorFinal = valorFinal;
	}

	public void setPercentualCedidoEmResseguro(BigDecimal percentualCedidoEmResseguro) {
		this.percentualCedidoEmResseguro = percentualCedidoEmResseguro;
	}

	public BigDecimal getPercentualRetidoEmResseguro() {
		return percentualRetidoEmResseguro;
	}

	public void setPercentualRetidoEmResseguro(BigDecimal percentualRetidoEmResseguro) {
		this.percentualRetidoEmResseguro = percentualRetidoEmResseguro;
	}

}
