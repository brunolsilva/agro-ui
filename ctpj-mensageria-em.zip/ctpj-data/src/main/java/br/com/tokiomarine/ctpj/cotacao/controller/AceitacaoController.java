package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.BloqueioAlcadaView;
import br.com.tokiomarine.ctpj.cotacao.service.AceitacaoCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.type.Paginas;

/**
 * @author Ricardo Neves Braga
 * @since 06/03/2017
 * @version 1.0
 * 
 */
@Controller
@RequestMapping("/aceitacao")
public class AceitacaoController extends AbstractController {
	
	private static final Logger logger = LogManager.getLogger(AceitacaoController.class);
	
	@Autowired
	private AceitacaoCotacaoService aceitacaoCotacaoService;
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@LogPerformance
	@GetMapping("/{idCotacao}")
	public String listaBloqueioAlcada(@PathVariable("idCotacao") BigInteger sequencialCotacaoProposta, Model model){
		
		List<BloqueioAlcadaView> listaBloqueioAlcadaView;
		try {
			listaBloqueioAlcadaView = aceitacaoCotacaoService.listaBloqueioAlcadaPorCotacao(sequencialCotacaoProposta);
			model.addAttribute("listaBloqueioAlcada", listaBloqueioAlcadaView);
			model.addAttribute("sequencialCotacaoProposta", sequencialCotacaoProposta);
			model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(sequencialCotacaoProposta));
			model.addAttribute("nivelAutorizacaoUsuarioLogado", super.getUser().getCdNivelAutz());
		} catch (ServiceException e) {
			logger.error(String.format("Falha ao listar bloqueios [%s]", sequencialCotacaoProposta), e);
			return Paginas.error.value();
		}

		return Paginas.aceitacao.value();
	}
	
	@LogPerformance
	@PostMapping(value = "/atualizar")
	public ResponseEntity<ResultadoREST<BloqueioAlcadaView>> salvar(@RequestBody List<BloqueioAlcadaView> aprovacoes) {

		logger.info("Inicio atualizar aprovações de alcada");

		ResultadoREST<BloqueioAlcadaView> resultado = new ResultadoREST<>();

		try {
			aceitacaoCotacaoService.atualizar(aprovacoes,super.getUser());
			resultado.setMensagem("Dados atualizados com Sucesso!");
			resultado.setSuccess(true);
		} catch(Exception e) {
			logger.error("Erro ao atualizar dados de alçada ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}

		logger.info("Fim atualizar dados de aprovações de alcada");

		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}
	
	
}
