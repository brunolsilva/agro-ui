package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.JurosParcelamentoCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.JurosParcelamentoCotacaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.type.Paginas;

@RequestMapping(value = "/juros")
@Controller
public class JurosParcelamentoController extends AbstractController {

	private static Logger logger = LogManager.getLogger(JurosParcelamentoController.class);

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private JurosParcelamentoCotacaoService jurosParcelamentoCotacaoService;

	@LogPerformance
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String page(@PathVariable BigInteger sequencialCotacaoProposta,@RequestHeader(value = "referer", required = false) String referer, Model model) throws ServiceException{
		Cotacao cotacao = cotacaoService.findCotacaoTela(sequencialCotacaoProposta);
		CotacaoView cotacaoView = CotacaoViewMapper.INSTANCE.toCotacaoView(cotacao);
		model.addAttribute("cotacao",cotacaoView);
		model.addAttribute("cabecalhoCotacao", cotacaoView);
		model.addAttribute("listaJurosPagamentoCotacao", jurosParcelamentoCotacaoService.toListOfJurosPagamentoCotacaoView(sequencialCotacaoProposta));
		model.addAttribute("origem", referer);
		model.addAttribute("readOnly", CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly());
		return Paginas.juros.value();
	}

	@LogPerformance
	@PostMapping(value = "/atualizarJuros")
	public @ResponseBody ResultadoREST<String> atualizarJurosParcelamentoCotacao(@RequestBody JurosParcelamentoCotacaoView jurosParcelamentoCotacaoView) {
		ResultadoREST<String> resultado = new ResultadoREST<>();
		try {
			jurosParcelamentoCotacaoService.updateJurosParcelamentoCotacao(jurosParcelamentoCotacaoView);
			resultado.setSuccess(true);
		} catch (Exception e) {
			resultado.setSuccess(false);
			logger.error("Erro ao atualizar juros parcelamento.",e);
		}
		return resultado;
	}
	
}