package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.Column;

import org.hibernate.Query;
import org.hibernate.annotations.Type;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.BloqueioAlcadaView;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class BloqueioAlcadaRepository extends BaseDAO{

	public BloqueioAlcada save(BloqueioAlcada bloqueioAlcada) throws HibernateException{
		super.getCurrentSession().persist(bloqueioAlcada);
		return bloqueioAlcada;
	}
	
	@SuppressWarnings("unchecked")
	public List<BloqueioAlcada> list(BigInteger sequencialCotacaoProposta) {
		return (List<BloqueioAlcada>) getCurrentSession()
				.createQuery("select ba from BloqueioAlcada ba where ba.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta")
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.list();
	}	

	public void delete(BigInteger cotacao) {
		List<BloqueioAlcada> listBloqueioAlcada = list(cotacao);
		for(BloqueioAlcada bloqueio: listBloqueioAlcada) {
			getCurrentSession().delete(bloqueio);
		}

		getCurrentSession().flush();
	}

	public void delete(Cotacao cotacao) {
		for(BloqueioAlcada bloqueio: cotacao.getListBloqueioAlcada()) {
			getCurrentSession().delete(bloqueio);
		}

		cotacao.getListBloqueioAlcada().clear();

		getCurrentSession().flush();
	}

	public List<BloqueioAlcada> listaMensagensBloqueio(BigInteger cotacao) {		
		StringBuilder hql = new StringBuilder();
		
		hql.append(" select b "
				+ "	 from BloqueioAlcada b where b.cotacao.sequencialCotacaoProposta = :cotacao ");
		hql.append(" and  ( b.idAutorizacao = :nao ");
		hql.append(" 		or  b.idAutorizacao = null) ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao", cotacao);
		query.setParameter("nao", SimNaoEnum.NAO);

		List<BloqueioAlcada> mensagens = (List<BloqueioAlcada>)query.list();

		return mensagens;
	}
	
	public void atualiza(List<BloqueioAlcadaView> aprovacoes, User user) {
		for (BloqueioAlcadaView lista : aprovacoes) {
			StringBuilder hql = new StringBuilder();
			hql.append(" update BloqueioAlcada b ");
			hql.append(" set b.idAutorizacao = :sim ");
			hql.append(" ,b.codigoFuncionarioAutorizacao = :cdUsuro ");
			hql.append(" ,b.nomeFuncionarioAutorizacao = :nmUsuro ");
			hql.append(" ,b.dataAutorizacao = sysdate() ");
			hql.append(" ,b.observacaoParecerLiberacaoBloqueio = :observacaoParecerLiberacaoBloqueio ");
			hql.append(" ,b.dataAtualizacao = sysdate() ");
			hql.append(" ,b.codigoGrupo = :codigoGrupo ");
			hql.append(" ,b.usuarioAtualizacao = :usuarioAtualizacao ");
			hql.append(" where b.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
			hql.append(" and   b.sequencialBloqueioAlcada = :sequencialBloqueioAlcada");
			
			Query query = getCurrentSession().createQuery(hql.toString());
			query.setParameter("sim", SimNaoEnum.SIM);
			query.setParameter("cdUsuro", user.getCdUsuro());
			query.setParameter("nmUsuro", user.getNmUsuro());
			query.setParameter("sequencialBloqueioAlcada", lista.getSequencialBloqueioAlcada());
			query.setParameter("sequencialCotacaoProposta", lista.getSequencialCotacaoProposta());
			query.setParameter("sequencialBloqueioAlcada", lista.getSequencialBloqueioAlcada());
			query.setParameter("observacaoParecerLiberacaoBloqueio", lista.getObservacaoParecerLiberacaoBloqueio());
			query.setParameter("codigoGrupo", user.getGrupoUsuario().getId());
			query.setParameter("usuarioAtualizacao", user.getCdUsuro().longValue());
			query.executeUpdate();
		}
	}
}