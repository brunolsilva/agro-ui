
package br.com.tokiomarine.ctpj.integracao.dadosconta;

public class InfoAgencia {

}
