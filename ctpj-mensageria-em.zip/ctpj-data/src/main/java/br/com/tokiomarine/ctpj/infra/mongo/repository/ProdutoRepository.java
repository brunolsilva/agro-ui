package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.PrazoSeguroCorretor;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCancelamentoFaltaPagamento;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristicaImpressao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoSusep;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;

@Repository
public class ProdutoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	public Produto findByCodigo(Integer codigo) {
		return mongoTemplate.findOne(
				query(where("codigo").is(codigo)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))
							), Produto.class);
	}
	
	public Produto findByCaracBemKme(Long caracBem) {
		return mongoTemplate.findOne(
				query(where("idCaracBemKme").is(caracBem.intValue())
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))
							), Produto.class);
	}

	public List<ProdutoCaracteristica> findCaracsByProduto(Integer codigoProduto)  {
		return mongoTemplate.find(
				query(where("produto").is(codigoProduto)), ProdutoCaracteristica.class);
	}

	public ProdutoSusep findProdutoSusepByProduto(Integer codigoProduto, Integer codigoGrupoRamo, Integer codigoRamo, Date dataInicioVigencia){
		return mongoTemplate.findOne(
				query(where("produto").is(codigoProduto)
						.and("codigoGrupoRamo").is(codigoGrupoRamo)
						.and("codigoRamo").is(codigoRamo)
						.and("dataInicioVigencia").lte(dataInicioVigencia)
						.orOperator(
								where("dataTerminoVigencia").gte(dataInicioVigencia),
								where("dataTerminoVigencia").is(null))
						),ProdutoSusep.class);
	}

	public ProdutoCaracteristicaImpressao findProdutoCaracteristicaImpressao(Integer codigoProduto, Integer codigoCaracteristica,Date dataInicioVigencia)  {
		return mongoTemplate.findOne(
				query(
						where("produto").is(codigoProduto)
						.and("caracteristica").is(codigoCaracteristica)
						.and("dataInicioVigencia").lte(dataInicioVigencia)
						.orOperator(
							where("dataTerminoVigencia").gte(dataInicioVigencia),
							where("dataTerminoVigencia").is(null))
						), ProdutoCaracteristicaImpressao.class);
	}
	
	public ProdutoControle findProdutoControleByCodigoAndVigencia(Integer codigoProduto, Date dataInicioVigencia)  {
		return mongoTemplate.findOne(
				query(
						where("produto").is(codigoProduto)
						.and("dataInicioVigencia").lte(dataInicioVigencia)
						.orOperator(
							where("dataTerminoVigencia").gte(dataInicioVigencia),
							where("dataTerminoVigencia").is(null))
						), ProdutoControle.class);
	}

	public ProdutoSusep findProdutoSusepByProduto(Integer codigoProduto){
		return mongoTemplate.findOne(query(where("produto").is(codigoProduto) ),ProdutoSusep.class);
	}
	
	public ProdutoCancelamentoFaltaPagamento findProdutoCancelamentoFaltaPagamentobyProduto (Integer codigoProduto, BigDecimal relacaoPremioTotal) {
		List<ProdutoCancelamentoFaltaPagamento> list = mongoTemplate.find(
				query(where("produto").is(codigoProduto)
						.and("inativo").is(false)
						), ProdutoCancelamentoFaltaPagamento.class);
		if (list != null && !list.isEmpty()) {
			return list.stream()
					.filter(it -> it.getPercentualPremioTotalPago().compareTo(relacaoPremioTotal) >= 0)
					.sorted(Comparator.comparing(ProdutoCancelamentoFaltaPagamento::getPercentualPremioTotalPago))
					.collect(Collectors.toList())
					.get(0);
		}
		return new ProdutoCancelamentoFaltaPagamento();
	}

	public int findDiasVigenciaFutura(TipoSeguroEnum tipoSeguroEnum, Integer produto) {
		PrazoSeguroCorretor prazo = mongoTemplate.findOne(
				query(
						where("produto").is(produto)
						.and("tipoSeguro").is(tipoSeguroEnum.getId())
						), PrazoSeguroCorretor.class);
		if(prazo == null) {
			return 30;
		}
		return prazo.getDias();
	}
}
