package br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Formatador para Data usadas em relatórios
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class FormatadorDateRelatorio {
	
	private SimpleDateFormat formatter;
	
	/**
	 * Gera um novo objeto que formata as datas no formato <b>dd/MM/yyyy</br>
	 */
	public FormatadorDateRelatorio(){
		this("dd/MM/yyyy");
	}
	
	/**
	 * Gera um novo ojeto que formata das data no formato indicado como parâmetro
	 * 
	 * @param pattern the pattern describing the date and time format
	 */
	public FormatadorDateRelatorio(String pattern){
		this.formatter = new SimpleDateFormat(pattern);
	}
	
	/**
	 * Formata uma data como String
	 * 
	 * @param data
	 * @param defaultValue Valor que será usado caso a data seja igual a Null
	 * @return Uma String representado a data formatada
	 */
	public String asFormatedDate(Date data, String defaultValue){
		return data == null ? defaultValue : formatter.format(data);
	}
	
	/**
	 * Formata uma data como String
	 * 
	 * @param data
	 * @return Uma String representado a data formatada ou caso a data seja null, uma string vazia
	 */
	public String asFormatedDate(Date data){
		return asFormatedDate(data, "");
	}	

}
