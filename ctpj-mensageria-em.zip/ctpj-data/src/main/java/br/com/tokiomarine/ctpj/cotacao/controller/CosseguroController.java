package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CosseguroView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CosseguroService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.infra.domain.CompanhiaSeguradora;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;

@Controller
@RequestMapping(value = "/cosseguro")
public class CosseguroController extends AbstractController {

	private static final Logger logger = LogManager.getLogger(CosseguroController.class);

	@Autowired
	private CosseguroService cosseguroService;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private CotacaoService cotacaoService;

	@LogPerformance
	@GetMapping(value = "/distribuicao")
	public String index(@RequestParam BigInteger cotacao, Model model, HttpServletRequest request) {

		limpaMensagens(request);

		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(cotacao);
			List<CompanhiaSeguradora> ciasSeguradora = caracteristicaService.findCiasSeguradora();
			List<CosseguroView> cosseguros = cosseguroService.findCossegurosByCotacao(cotacao);
			model.addAttribute("cosseguros",cosseguros);
			model.addAttribute("ciasSeguradora",ciasSeguradora);
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			model.addAttribute("readOnly", CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly());
			return "/cotacao/cosseguro";
		} catch(Exception e) {
			logger.error("Erro ao carregar a página de distribuicao de cosseguro: " + cotacao, e);
			return "/cotacao/cosseguro";
		}
	}

	@LogPerformance
	@PostMapping(value = "/salvar")
	public ResponseEntity<ResultadoREST<CosseguroView>> salvar(@RequestBody List<CosseguroView> cosseguros) {

		logger.info("Inicio salvar dados do cosseguro ");

		ResultadoREST<CosseguroView> resultado = new ResultadoREST<>();

		try {
			cosseguroService.salvar(cosseguros);
			resultado.setMensagem("Dados salvos com Sucesso!");
			resultado.setSuccess(true);

			logger.info("Fim salvar dados do cosseguro ");

			return new ResponseEntity<>(resultado, HttpStatus.OK);
		} catch(Exception e) {
			logger.error("Erro ao carregar a página de distribuicao de corretagem ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}
	}
}