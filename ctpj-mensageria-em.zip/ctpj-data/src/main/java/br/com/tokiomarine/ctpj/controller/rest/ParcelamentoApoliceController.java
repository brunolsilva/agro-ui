package br.com.tokiomarine.ctpj.controller.rest;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.apolice.service.ParcelamentoApoliceService;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.integracao.acsel.response.ParcelamentoApoliceAcselResponse;
import br.com.tokiomarine.ctpj.request.ParcelamentoApoliceRequest;
import br.com.tokiomarine.ctpj.sct.response.EntradaCadastroCotacaoResponse;
import br.com.tokiomarine.ctpj.type.RetornoREST;

@Controller
public class ParcelamentoApoliceController {
	
	@Autowired
	private ParcelamentoApoliceService parcelamentoApoliceService;
	
	/**
	 * retorna os dados de parcelamento de uma apólice
	 * @param request
	 * @return
	 * @throws RepositoryException
	 */
	@PostMapping(value = "/rest/parcelamentoApolice")
	@ResponseBody
	//
	public ResponseEntity<ParcelamentoApoliceAcselResponse> importar(@RequestBody ParcelamentoApoliceRequest request){
		
		ParcelamentoApoliceAcselResponse response = parcelamentoApoliceService.consultaParcelamentoApolice(request);
		if(response.getCodigo().equals(RetornoREST.sucesso.codigo())) {
			return new ResponseEntity<>(response,HttpStatus.OK); 
		}
		
		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
