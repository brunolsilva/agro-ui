package br.com.tokiomarine.ctpj.integracao.cliente.formadevolucao;

import br.com.tokiomarine.cliente.dto.FormaDevolucaoCliente;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.integracao.cliente.request.FormaDevolucaoRequest;

/**
 * cria a request para forma de devolução em recibo
 * 
 * @author T804294
 *
 */
public class CadastroFormaDevolucaoRecibo implements CadastroFormaDevolucao {

	@Override
	public FormaDevolucaoRequest bindToRequest(Cotacao cotacao,FormaDevolucaoCliente formaDevolucao,PropostaView propostaView) {
		FormaDevolucaoRequest request = new FormaDevolucaoRequest();
		request.setCdClien(cotacao.getCodigoCliente());
		request.setTpDevol(FormaDevolucaoApoliceEnum.RECIBO.getTipoDevolucao());
		
		if(formaDevolucao != null) {
			request.setIdFormaDevol(formaDevolucao.getIdFormaDevol());
		}
		return request;
	}

	@Override
	public Boolean dadosValidos(Cotacao cotacao) {
		return true;
	}

}
