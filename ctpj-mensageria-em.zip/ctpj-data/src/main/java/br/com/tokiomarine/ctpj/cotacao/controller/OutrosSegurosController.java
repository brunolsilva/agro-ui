package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemOutroSeguroView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.FranquiaService;
import br.com.tokiomarine.ctpj.cotacao.service.OutrosSegurosService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.CompanhiaSeguradora;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.mapper.OutroSeguroMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Controller
@RequestMapping("/outrosSeguros")
public class OutrosSegurosController extends AbstractController {

	private static Logger logger = LogManager.getLogger(OutrosSegurosController.class);
	
	@Autowired
	private OutrosSegurosService outrosSegurosService;
	
	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private FranquiaService franquiaService;

	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;
	

	@LogPerformance
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String home(@PathVariable BigInteger sequencialCotacaoProposta, Model model, HttpServletRequest request) {

		limpaMensagens(request);

		try {
			Cotacao cotacao = cotacaoService.findCompleta(sequencialCotacaoProposta);
			List<ItemOutroSeguroView> outrosSeguros = OutroSeguroMapper.INSTANCE.toOSView(outrosSegurosService.list(sequencialCotacaoProposta));
			List<CompanhiaSeguradora> ciasSeguradora = caracteristicaService.findCiasSeguradora();
			model.addAttribute("items", franquiaService.getItemsComEndereco(sequencialCotacaoProposta));
			model.addAttribute("outrosSeguros", outrosSeguros);
			model.addAttribute("ciasSeguradora", ciasSeguradora);
			model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(sequencialCotacaoProposta));
			model.addAttribute("readOnly",isReadOnly(cotacao));
		} catch (Exception e) {
			logger.error("Erro ", e);
		}
		
		return "/cotacao/outrosSeguros";
	}
	
	private boolean isReadOnly(Cotacao cotacao) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario);
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se � usu�rio do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}

	@LogPerformance
	@PostMapping(value = "/save")
	public ResponseEntity<ResultadoREST<ItemOutroSeguroView>> save(@RequestBody ItemOutroSeguro outroSeguro) {
		ResultadoREST<ItemOutroSeguroView> resultado = new ResultadoREST<>();
		try {
			ItemOutroSeguro os = outrosSegurosService.save(outroSeguro);
			ItemOutroSeguroView osView = OutroSeguroMapper.INSTANCE.toOSView(os);
			
			resultado.setRetornoObj(osView);
			resultado.setSuccess(true);
			return new ResponseEntity<>(resultado, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Erro ao incluir Outro Seguro ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}
	}

	@LogPerformance
	@GetMapping(value = "/delete/{id}")
	public ResponseEntity<ResultadoREST<Object>> excluir(@PathVariable BigInteger id) {
		ResultadoREST<Object> resultado = new ResultadoREST<>();
		try {
			outrosSegurosService.delete(id);
			resultado.setSuccess(true);
			return new ResponseEntity<>(resultado, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Erro ao excluir Outro Seguro ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}
	}
}
