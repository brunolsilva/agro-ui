package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativoFaixa;

@Repository
public class ResseguroFacultativoFaixaRepository extends BaseDAO{
	
	public BigInteger save(ResseguroFacultativoFaixa rff){
		return (BigInteger) getCurrentSession().save(rff);
	}

}
