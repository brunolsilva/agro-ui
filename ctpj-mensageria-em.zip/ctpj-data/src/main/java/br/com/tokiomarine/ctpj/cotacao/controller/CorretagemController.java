package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CorretagemView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CorretagemService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.dto.CorretorFranqueadorView;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.ModuloProdutoEnum;
import br.com.tokiomarine.ctpj.enums.OrigemContratacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.integracao.service.CorretorBaseUnicaService;
import br.com.tokiomarine.ctpj.mapper.CorretorMapper;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Controller
@RequestMapping(value = "/corretagem")
public class CorretagemController extends AbstractController {

	private static final Logger logger = LogManager.getLogger(CorretagemController.class);

	@Autowired
	private CorretagemService corretagemService;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private CorretorBaseUnicaService corretorBaseUnicaService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;
	
	@LogPerformance
	@GetMapping(value = "/distribuicao")
	public String index(@RequestParam BigInteger cotacao, Model model, HttpServletRequest request) {

		limpaMensagens(request);

		logger.info("Inicio - Carregando tela de distribuicao de corretagem da cotacao " + cotacao);

		try {
			List<CorretagemCotacao> corretagensCotacao = corretagemService.findCorretagensByCotacao(cotacao);
			List<CorretagemView> corretagens = new ArrayList<>();
			for(CorretagemCotacao corretagem: corretagensCotacao) {
				corretagens.add(CotacaoViewMapper.INSTANCE.toCorretagemCotacaoView(corretagem));
			}
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(cotacao);
			model.addAttribute("dadosCotacao", cotacaoView);
			model.addAttribute("corretagens",corretagens);
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			model.addAttribute("readOnly", isReadOnly(cotacaoView));
			
			CorretorFranqueadorView corretorFranqueador = corretagemService.getCorretorFranqueador(
					ModuloProdutoEnum.getByProdutoAndOrigem(cotacaoView.getCodigoProduto(), getOrigemContratacao()).getCodigoModuloProduto(),
					cotacaoService.findById(cotacao), new Date());
			if(corretorFranqueador != null) {
				model.addAttribute("readOnly", true);
			}
			
		} catch(Exception e) {
			logger.error("Erro ao carregar a página de distribuicao de corretagem ", e);
			return "/cotacao/corretagem";
		}

		logger.info("Fim - Carregando tela de distribuicao de corretagem da cotacao " + cotacao);

		return "/cotacao/corretagem";
	}
	
	private boolean isReadOnly(CotacaoView cotacaoView) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario) && !cotacaoView.getCodigoSituacaoReadOnly().equals(CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao().intValue());
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se é usuário do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}

	@LogPerformance
	@GetMapping(value = "/corretor")
	public @ResponseBody List<Corretor> index(@RequestParam String q) {
		logger.info("Início Busca de Corretor pelo Nome");

		try {
			return CorretorMapper.INSTANCE.fromCorretorBaseUnicaListToCorretorList(corretorBaseUnicaService.findCorretoresByNome(q));
		} catch(Exception e) {
			logger.error("Falha na busca de corretores ", e);
			return Collections.<Corretor>emptyList();
		}
	}

	@LogPerformance
	@PostMapping(value = "/salvar")
	public ResponseEntity<ResultadoREST<CorretagemView>> salvar(@RequestBody List<CorretagemView> corretagens) {

		logger.info("Inicio salvar dados do corretagem ");

		ResultadoREST<CorretagemView> resultado = new ResultadoREST<>();

		try {
			corretagemService.salvar(corretagens);
			resultado.setMensagem("Dados salvos com Sucesso!");
			resultado.setSuccess(true);
		} catch(Exception e) {
			logger.error("Erro ao carregar a página de distribuicao de corretagem ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}

		logger.info("Fim salvar dados do corretagem ");

		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}
	
	private Integer getOrigemContratacao() {
		Integer origemContratacao = OrigemContratacaoEnum.ORIGEM_CORRETOR.getId();
		if(!SecurityUtils.isCorretor()) {
			origemContratacao = OrigemContratacaoEnum.ORIGEM_SUBSCRITOR.getId();
		}
		return origemContratacao;
	}
}
