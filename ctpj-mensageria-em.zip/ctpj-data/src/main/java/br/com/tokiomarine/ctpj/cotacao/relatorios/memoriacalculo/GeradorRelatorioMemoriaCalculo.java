package br.com.tokiomarine.ctpj.cotacao.relatorios.memoriacalculo;

import java.io.OutputStream;

import br.com.tokiomarine.ctpj.cotacao.relatorios.RelatorioException;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaCalculo;

public interface GeradorRelatorioMemoriaCalculo {

	byte[] gera(MemoriaCalculo memoriaCalculo) throws RelatorioException;

	OutputStream geraOutputStream(MemoriaCalculo memoriaCalculo) throws RelatorioException;

}