package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Service
public class CalculaSublimiteService {

	/**
	 * Sublimite original == menor entre IS da Cobertura e VR do item
	 * O valor do sublimite é limitado ao valor do sublimite original
	 */
	public void populaValorSublimiteOriginal(ItemCobertura itemCobertura,MoedaEnum moeda,BigDecimal coeficienteConversaoMoeda) {
		if(itemCobertura.getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.SIM) {
			if(moeda == MoedaEnum.REAL) {
				if(itemCobertura.isExigeValorRisco()) {
					if(BigDecimalUtil.safeMenorIgual(itemCobertura.getValorImportanciaSegurada(), itemCobertura.getValorRiscoBem())) {
						itemCobertura.setValorSublimiteOriginal(itemCobertura.getValorImportanciaSegurada());
					} else {
						itemCobertura.setValorSublimiteOriginal(itemCobertura.getValorRiscoBem());
					}
					
					if(itemCobertura.getIdSublimiteInformado() != SimNaoEnum.SIM) {
						itemCobertura.setValorSublimite(itemCobertura.getValorSublimiteOriginal());
					} else if(BigDecimalUtil.safeMenorIgual(itemCobertura.getValorSublimiteOriginal(),itemCobertura.getValorSublimite())) {
						if(itemCobertura.getValorSublimite() != null) {
							itemCobertura.setValorSublimite(itemCobertura.getValorSublimiteOriginal());
							itemCobertura.setIdSublimiteInformado(SimNaoEnum.NAO);
						}
					}
					
				} else {
					if(itemCobertura.getValorImportanciaSegurada() != null && itemCobertura.getItemCotacao().getValorRiscoBemCalculado() != null) {
						if(BigDecimalUtil.menorIgual(itemCobertura.getValorImportanciaSegurada(),itemCobertura.getItemCotacao().getValorRiscoBemCalculado())) {
							itemCobertura.setValorSublimiteOriginal(itemCobertura.getValorImportanciaSegurada());
						} else {
							itemCobertura.setValorSublimiteOriginal(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
						}

						if(itemCobertura.getIdSublimiteInformado() != SimNaoEnum.SIM) {
							itemCobertura.setValorSublimite(itemCobertura.getValorSublimiteOriginal());
						} else if(BigDecimalUtil.safeMenorIgual(itemCobertura.getValorSublimiteOriginal(),itemCobertura.getValorSublimite())) {
							if(itemCobertura.getValorSublimite() != null) {
								itemCobertura.setValorSublimite(itemCobertura.getValorSublimiteOriginal());
								itemCobertura.setIdSublimiteInformado(SimNaoEnum.NAO);
							}
						}
					}
				}
			} else {
				if(itemCobertura.isExigeValorRisco()) {
					if(BigDecimalUtil.safeMenorIgual(itemCobertura.getValorISMoedaEstrangeira(), itemCobertura.getValorRiscoBemMoedaEstrangeira())) {
						itemCobertura.setValorSublimiteOriginalMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
					} else {
						itemCobertura.setValorSublimiteOriginalMoedaEstrangeira(itemCobertura.getValorRiscoBemMoedaEstrangeira());
					}
					
					if(itemCobertura.getIdSublimiteInformado() != SimNaoEnum.SIM) {
						itemCobertura.setValorSublimiteMoedaEstrangeira(itemCobertura.getValorSublimiteOriginal());
					} else if(BigDecimalUtil.safeMenorIgual(itemCobertura.getValorSublimiteOriginal(),itemCobertura.getValorSublimiteMoedaEstrangeira())) {
						if(itemCobertura.getValorSublimite() != null) {
							itemCobertura.setValorSublimiteMoedaEstrangeira(itemCobertura.getValorSublimiteOriginalMoedaEstrangeira());
							itemCobertura.setIdSublimiteInformado(SimNaoEnum.NAO);
						}
					}
					
				} else {
					if(itemCobertura.getValorISMoedaEstrangeira() != null && itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira() != null) {
						if(BigDecimalUtil.menorIgual(itemCobertura.getValorISMoedaEstrangeira(),itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira())) {
							itemCobertura.setValorSublimiteOriginalMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
						} else {
							itemCobertura.setValorSublimiteOriginalMoedaEstrangeira(itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira());
						}
	
						if(itemCobertura.getIdSublimiteInformado() != SimNaoEnum.SIM) {
							itemCobertura.setValorSublimiteMoedaEstrangeira(itemCobertura.getValorSublimiteMoedaEstrangeira());
						} else if(BigDecimalUtil.safeMenorIgual(itemCobertura.getValorSublimiteOriginalMoedaEstrangeira(),itemCobertura.getValorSublimiteMoedaEstrangeira())) {
							if(itemCobertura.getValorSublimiteMoedaEstrangeira() != null) {
								itemCobertura.setValorSublimiteMoedaEstrangeira(itemCobertura.getValorSublimiteOriginalMoedaEstrangeira());
								itemCobertura.setIdSublimiteInformado(SimNaoEnum.NAO);
							}
						}
					}
				}
			}
		}
	}
}
