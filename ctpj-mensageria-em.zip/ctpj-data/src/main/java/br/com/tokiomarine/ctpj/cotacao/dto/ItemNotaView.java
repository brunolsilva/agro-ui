package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ItemNotaView implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3252962299452783918L;
	
	private BigInteger sequencialItemNota;
	private BigInteger codigoSequencia;
	private String descricaoNota;
	private BigInteger sequencialItemCotacao;
	private BigInteger numeroCotacaoProposta;
	private Integer versaoCotacaoProposta;
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm:ss")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy HH:mm:ss")
	private Date dataAtualizacao;
	private Integer codigoGrupo;
	private Long usuarioAtualizacao;
	
	public BigInteger getSequencialItemNota() {
		return sequencialItemNota;
	}
	
	public void setSequencialItemNota(BigInteger sequencialItemNota) {
		this.sequencialItemNota = sequencialItemNota;
	}
	
	public BigInteger getCodigoSequencia() {
		return codigoSequencia;
	}
	
	public void setCodigoSequencia(BigInteger codigoSequencia) {
		this.codigoSequencia = codigoSequencia;
	}
	
	public String getDescricaoNota() {
		return descricaoNota;
	}
	
	public void setDescricaoNota(String descricaoNota) {
		this.descricaoNota = descricaoNota;
	}
	
	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}
	
	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}
	
	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}
	
	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}
	
	public Integer getVersaoCotacaoProposta() {
		return versaoCotacaoProposta;
	}
	
	public void setVersaoCotacaoProposta(Integer versaoCotacaoProposta) {
		this.versaoCotacaoProposta = versaoCotacaoProposta;
	}

	
	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	
	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	
	public Integer getCodigoGrupo() {
		return codigoGrupo;
	}

	
	public void setCodigoGrupo(Integer codigoGrupo) {
		this.codigoGrupo = codigoGrupo;
	}

	
	public Long getUsuarioAtualizacao() {
		return usuarioAtualizacao;
	}

	
	public void setUsuarioAtualizacao(Long usuarioAtualizacao) {
		this.usuarioAtualizacao = usuarioAtualizacao;
	}
	
	

}
