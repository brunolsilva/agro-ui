package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request;

import java.io.Serializable;
import java.math.BigDecimal;

public class ConsultaSaldoRequest implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 995512121024126482L;
	private Long codigoCorretor;
	private String codigoParceiro;
	private String codigoProduto;
	private String cpfUsuarioEmissor;
	private String dataProvisaoSantander;
	private Long nivelHierarquico;
	private Long numeroRamo;
	private BigDecimal percentualComissao;
	private String protocoloProvisao;
    private BigDecimal valorPremioLiquido;

	public Long getCodigoCorretor() {
		return codigoCorretor;
	}

	public void setCodigoCorretor(Long codigoCorretor) {
		this.codigoCorretor = codigoCorretor;
	}

	public String getCodigoParceiro() {
		return codigoParceiro;
	}

	public void setCodigoParceiro(String codigoParceiro) {
		this.codigoParceiro = codigoParceiro;
	}

	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getCpfUsuarioEmissor() {
		return cpfUsuarioEmissor;
	}

	public void setCpfUsuarioEmissor(String cpfUsuarioEmissor) {
		this.cpfUsuarioEmissor = cpfUsuarioEmissor;
	}

	public String getDataProvisaoSantander() {
		return dataProvisaoSantander;
	}

	public void setDataProvisaoSantander(String dataProvisaoSantander) {
		this.dataProvisaoSantander = dataProvisaoSantander;
	}

	public Long getNivelHierarquico() {
		return nivelHierarquico;
	}

	public void setNivelHierarquico(Long nivelHierarquico) {
		this.nivelHierarquico = nivelHierarquico;
	}

	public Long getNumeroRamo() {
		return numeroRamo;
	}

	public void setNumeroRamo(Long numeroRamo) {
		this.numeroRamo = numeroRamo;
	}

	public BigDecimal getPercentualComissao() {
		return percentualComissao;
	}

	public void setPercentualComissao(BigDecimal percentualComissao) {
		this.percentualComissao = percentualComissao;
	}

	public String getProtocoloProvisao() {
		return protocoloProvisao;
	}

	public void setProtocoloProvisao(String protocoloProvisao) {
		this.protocoloProvisao = protocoloProvisao;
	}

	public BigDecimal getValorPremioLiquido() {
		return valorPremioLiquido;
	}

	public void setValorPremioLiquido(BigDecimal valorPremioLiquido) {
		this.valorPremioLiquido = valorPremioLiquido;
	}

	@Override
	public String toString() {
		return "ConsultaSaldoRequest [codigoCorretor=" + codigoCorretor + ", codigoParceiro=" + codigoParceiro
				+ ", codigoProduto=" + codigoProduto + ", cpfUsuarioEmissor=" + cpfUsuarioEmissor
				+ ", dataProvisaoSantander=" + dataProvisaoSantander + ", nivelHierarquico=" + nivelHierarquico
				+ ", numeroRamo=" + numeroRamo + ", percentualComissao=" + percentualComissao + ", protocoloProvisao="
				+ protocoloProvisao + ", valorPremioLiquido=" + valorPremioLiquido + "]";
	}
}
