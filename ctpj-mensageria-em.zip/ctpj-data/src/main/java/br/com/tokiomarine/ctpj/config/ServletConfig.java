package br.com.tokiomarine.ctpj.config;

import java.util.List;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.JdkRegexpMethodPointcut;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.opensymphony.sitemesh.webapp.SiteMeshFilter;

import br.com.tokiomarine.ctpj.aop.LogAOP;
import br.com.tokiomarine.ctpj.aop.PerformanceAroundAdvice;
import br.com.tokiomarine.ctpj.infra.converter.Converters;
import br.com.tokiomarine.ctpj.interceptor.ModelHandlerInterceptor;
import net.bull.javamelody.MonitoringFilter;
import net.bull.javamelody.SessionListener;

@EnableWebMvc
//@EnableCaching
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ComponentScan(basePackages = "br.com.tokiomarine")
public class ServletConfig extends WebMvcConfigurerAdapter implements WebApplicationInitializer {

	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**/*.png").addResourceLocations("/");
        registry.addResourceHandler("/**/*.jpg").addResourceLocations("/");
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
        registry.addResourceHandler("/erros/**").addResourceLocations("/WEB-INF/views/erros/");
    }

	@Bean
	public InternalResourceViewResolver internalResourceViewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}

	@Bean
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource bundle = new ReloadableResourceBundleMessageSource();
		bundle.setBasename("/WEB-INF/classes/messages");
		bundle.setFallbackToSystemLocale(false);
		bundle.setDefaultEncoding("UTF-8");

		return bundle;
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new ModelHandlerInterceptor());
	}

	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
		converters.add(new MappingJackson2HttpMessageConverter(builder.build()));

		super.configureMessageConverters(converters);
	}

	@Bean
	public DefaultPointcutAdvisor advisor(LogAOP logAOP) {
		JdkRegexpMethodPointcut regexpMethodPointcut = new JdkRegexpMethodPointcut();
		regexpMethodPointcut.setPatterns("br.com.tokiomarine.*");
		return new DefaultPointcutAdvisor(regexpMethodPointcut, logAOP);
	}

	@Bean
	public CommonsMultipartResolver multipartResolver() {
	    CommonsMultipartResolver resolver=new CommonsMultipartResolver();
	    resolver.setDefaultEncoding("utf-8");
	    return resolver;
	}

	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		FilterRegistration.Dynamic monitoringFilter = servletContext.addFilter("monitoring", MonitoringFilter.class);
		monitoringFilter.setInitParameter("monitoring-path","/tms/monitoring");
		monitoringFilter.addMappingForUrlPatterns(null,false,"/*");

		servletContext.addListener(SessionListener.class);

		FilterRegistration.Dynamic sitemesh = servletContext.addFilter("sitemesh", SiteMeshFilter.class);
		sitemesh.addMappingForUrlPatterns(null,false,"/*");

		FilterRegistration.Dynamic charsetFilter = servletContext.addFilter("charsetFilter",CharacterEncodingFilter.class);
		charsetFilter.setInitParameter("encoding","UTF-8");
		charsetFilter.setInitParameter("forceEncoding","true");
		charsetFilter.addMappingForUrlPatterns(null,false,"/*");
	}

	@Bean
	public PerformanceAroundAdvice performanceAroundAdvice() {
		return new PerformanceAroundAdvice();
	}

//	@Bean
//	public CacheManager cacheManager() {
//		return new ConcurrentMapCacheManager();
//	}

	@Override
	public void addFormatters(FormatterRegistry registry) {
		registry.addConverter(new Converters.TipoISReadConverter());
		registry.addConverter(new Converters.TipoISWriteConverter());
		registry.addConverter(new Converters.BeneficiarioReadConverter());
		registry.addConverter(new Converters.BeneficiarioWriteConverter());
		registry.addConverter(new Converters.MoedaReadConverter());
		registry.addConverter(new Converters.MoedaWriteConverter());
		registry.addConverter(new Converters.MoedaReadStringConverter());
		registry.addConverter(new Converters.PrazoVigenciaReadConverter());
		registry.addConverter(new Converters.PrazoVigenciaWriteConverter());
		registry.addConverter(new Converters.TipoSeguradoReadConverter());
		registry.addConverter(new Converters.TipoSeguradoWriteConverter());
		registry.addConverter(new Converters.SimNaoReadConverter());
		registry.addConverter(new Converters.SimNaoWriteConverter());
		registry.addConverter(new Converters.AplicacaoPeriodoIndenitarioReadConverter());
		registry.addConverter(new Converters.AplicacaoPeriodoIndenitarioWriteConverter());
		registry.addConverter(new Converters.TipoSeguroReadConverter());
		registry.addConverter(new Converters.TipoSeguroWriteConverter());
		registry.addConverter(new Converters.FinalidadeVencimentoReadConverter());
		registry.addConverter(new Converters.FinalidadeVencimentoWriteConverter());
		registry.addConverter(new Converters.NivelCaracteristicaReadConverter());
		registry.addConverter(new Converters.NivelCaracteristicaWriteConverter());
		registry.addConverter(new Converters.TipoEndossoReadConverter());
		registry.addConverter(new Converters.TipoEndossoWriteConverter());
		registry.addConverter(new Converters.SolicitanteEndossoReadConverter());
		registry.addConverter(new Converters.SolicitanteEndossoWriteConverter());
	}

}