package br.com.tokiomarine.ctpj.cotacao.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculo;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCobertura;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCoberturaLimiteIs;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoJurosParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoUsuario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCorretor;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Repository
public class PerfilCalculoRepository {

	private static Logger logger = LogManager.getLogger(PerfilCalculoRepository.class);
	
	@Autowired
	private MongoTemplate mongoTemplate;

	public PerfilCalculoUsuario findPerfilCalculo(Long usuario, Date dataCotacao) {
		return mongoTemplate.findOne(
				query(
						where("usuario").is(usuario)
						.and("dataInicioVigencia").lte(dataCotacao)
						.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))),
				PerfilCalculoUsuario.class);
	}

	public PerfilCalculo getPerfilCalculo(Long codigo) {
		return mongoTemplate.findOne(query(where("codigo").is(codigo)),	PerfilCalculo.class);
	}

	public PerfilCalculoCondicao findPerfilCalculoCondicao(Long usuario,Integer produto, Date dataCotacao) {
		PerfilCalculoUsuario perfilCalculo = findPerfilCalculo(usuario,dataCotacao);
		if(perfilCalculo != null) {
			return mongoTemplate.findOne(
					query(
							where("perfilCalculo").is(perfilCalculo.getPerfilCalculo())
							.and("produto").is(produto)
							.and("dataInicioVigencia").lte(dataCotacao)
							.orOperator(
									where("dataTerminoVigencia").gte(dataCotacao),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoCondicao.class);
		} else {
			return null;
		}
	}
	
	public PerfilCalculoCondicao getPerfilCalculoCondicaoByCodigoAndProduto(Long codigoPerfil,Integer produto, Date dataCotacao) {

			return mongoTemplate.findOne(
					query(
							where("perfilCalculo").is(codigoPerfil)
							.and("produto").is(produto)
							.and("dataInicioVigencia").lte(dataCotacao)
							.orOperator(
									where("dataTerminoVigencia").gte(dataCotacao),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoCondicao.class);
	}
	
	public PerfilCalculoCondicao getPerfilCalculoCondicaoByCodigoAndProdutoFull(Long codigoPerfil,Integer produto) {

		return mongoTemplate.findOne(
				query(
						where("perfilCalculo").is(codigoPerfil)
						.and("produto").is(produto)),
				PerfilCalculoCondicao.class);
}

	public List<PerfilCalculoJurosParcelamento> findPerfilCalculoJurosParcelamento(Long usuario,Integer produto,Date dataInicioVigencia) {
		PerfilCalculoUsuario perfilCalculo = findPerfilCalculo(usuario,dataInicioVigencia);
		if(perfilCalculo != null) {
			return mongoTemplate.find(
					query(
							where("perfilCalculo").is(perfilCalculo.getPerfilCalculo())
							.and("produto").is(produto)
							.and("dataInicioVigencia").lte(dataInicioVigencia)
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoJurosParcelamento.class);
		} else {
			return Collections.<PerfilCalculoJurosParcelamento>emptyList();
		}
	}
	
	public List<PerfilCalculoJurosParcelamento> findPerfilCalculoJurosParcelamentoByPerfilCalculo(Long perfilCalculo,Integer produto) {
		
		
			return mongoTemplate.find(
					query(
							where("perfilCalculo").is(perfilCalculo)
							.and("produto").is(produto)
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoJurosParcelamento.class);
	}
	
	public PerfilCalculoJurosParcelamento findPerfilCalculoJurosParcelamento(
			Long usuario, 
			Integer produto, 
			Integer codigoFormaPagamento, 
			Integer codigoFormaParcelamento, 
			Date dataInicioVigencia) {
		PerfilCalculoUsuario perfilCalculo = findPerfilCalculo(usuario,dataInicioVigencia);
		if(perfilCalculo != null) {
			return mongoTemplate.findOne(
					query(
							where("perfilCalculo").is(perfilCalculo.getPerfilCalculo())
							.and("produto").is(produto)
							.and("codigoFormaPagamento").is(codigoFormaPagamento)
							.and("codigoFormaParcelamento").is(codigoFormaParcelamento)
							.and("dataInicioVigencia").lte(dataInicioVigencia)
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoJurosParcelamento.class);
		} else {
			return null;
		}
	}
	

	public List<PerfilCalculoCoberturaLimiteIs> findCoberturaLimiteIs(Cotacao cotacao,List<Integer> coberturas) {
		PerfilCalculoUsuario perfilCalculo = findPerfilCalculo(SecurityUtils.getCurrentUser().getCdUsuro().longValue(),cotacao.getDataCotacao());

		if(perfilCalculo != null) {
			return mongoTemplate.find(
					query(
							where("perfilCalculo").is(perfilCalculo.getPerfilCalculo())
							.and("produto").is(cotacao.getCodigoProduto())
							.and("cobertura").in(coberturas)
							//.and("moeda").is(cotacao.getCodigoMoeda())
							.and("dataInicioVigencia").lte(cotacao.getDataCotacao())
							.orOperator(
									where("dataTerminoVigencia").gte(cotacao.getDataCotacao()),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoCoberturaLimiteIs.class);
		}

		return Collections.<PerfilCalculoCoberturaLimiteIs>emptyList();
	}
	
	public List<PerfilCalculoCobertura> findPerfilCalculoCobertura(Long usuario,Integer produto, Date dataCotacao) {
		PerfilCalculoUsuario perfilCalculo = findPerfilCalculo(usuario,dataCotacao);
		if(perfilCalculo != null) {
			return findPerfilCalculoCobertura(produto, perfilCalculo);
		} else {
			return Collections.<PerfilCalculoCobertura>emptyList();
		}
	}

	//@Cacheable("perfilCalculoCobertura")
	public List<PerfilCalculoCobertura> findPerfilCalculoCobertura(Integer produto,
			PerfilCalculoUsuario perfilCalculo) {
		return mongoTemplate.find(
				query(
						where("perfilCalculo").is(perfilCalculo.getPerfilCalculo())
						.and("produto").is(produto)
						.and("inativo").is(false)),
				PerfilCalculoCobertura.class);
	}

	public void save(PerfilCalculoUsuario perfilCalculoUsuario) {
		mongoTemplate.save(perfilCalculoUsuario);
	}
	
	public void save(PerfilComercialCorretor perfilComercialCorretor) {
		mongoTemplate.save(perfilComercialCorretor);
	}
	
	public void insertPerfilCalculoCondicao(PerfilCalculoCondicao perfilCalculoCondicao) {
		mongoTemplate.insert(perfilCalculoCondicao);
	}
	
	public void insertPerfisCalculoJurosParcelamento(List<PerfilCalculoJurosParcelamento> jurosParcelamentos) {
		mongoTemplate.insertAll(jurosParcelamentos);
	}
	
	public void insertPerfisCalculoCoberturaLimiteIs(List<PerfilCalculoCoberturaLimiteIs> coberturasLimitesIs) {
		mongoTemplate.insertAll(coberturasLimitesIs);
	}
	
	public List<PerfilCalculoCoberturaLimiteIs> findCoberturaLimiteIs(Cotacao cotacao,List<Integer> coberturas, User user) {
		PerfilCalculoUsuario perfilCalculo = findPerfilCalculo(user.getCdUsuro().longValue(),cotacao.getDataCotacao());

		if(perfilCalculo != null) {
			return mongoTemplate.find(
					query(
							where("perfilCalculo").is(perfilCalculo.getPerfilCalculo())
							.and("produto").is(cotacao.getCodigoProduto())
							.and("cobertura").in(coberturas)
							//.and("moeda").is(cotacao.getCodigoMoeda())
							.and("dataInicioVigencia").lte(cotacao.getDataCotacao())
							.orOperator(
									where("dataTerminoVigencia").gte(cotacao.getDataCotacao()),
									where("dataTerminoVigencia").is(null))),
					PerfilCalculoCoberturaLimiteIs.class);
		}

		return Collections.<PerfilCalculoCoberturaLimiteIs>emptyList();
	}
	
	public List<PerfilCalculoCoberturaLimiteIs> findCoberturaLimiteIsByPerfilCalculo(Long perfilCalculo, Integer produto) {

			return mongoTemplate.find(
					query(
							where("perfilCalculo").is(perfilCalculo)
							.and("produto").is(produto)),
					PerfilCalculoCoberturaLimiteIs.class);
	}
}