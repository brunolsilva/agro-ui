package br.com.tokiomarine.ctpj.cotacao.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCobertura;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCorretor;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialJurosParcelamento;

@Repository
public class PerfilComercialRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public PerfilComercialCorretor findPerfilComercial(Long corretor, Integer produto, Date dataCotacao) {
		return mongoTemplate.findOne(
				query(
						where("corretor").is(corretor)
						.and("produto").is(produto)
						.and("dataInicioVigencia").lte(dataCotacao)
						.orOperator(
								where("dataTerminoVigencia").gte(dataCotacao),
								where("dataTerminoVigencia").is(null))),
				PerfilComercialCorretor.class);
	}

	public PerfilComercialCondicao findPerfilComercialCondicao(Long corretor, Integer produto, Date dataCotacao) {
		PerfilComercialCorretor perfilComercial = findPerfilComercial(corretor, produto, dataCotacao);
		if(perfilComercial != null) {
			return mongoTemplate.findOne(
					query(
							where("perfilComercial").is(perfilComercial.getPerfilComercial())
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))),
					PerfilComercialCondicao.class);
		} else {
			return null;
		}
	}

	public List<PerfilComercialJurosParcelamento> findPerfilComercialJurosParcelamento(Long corretor, Integer produto,Date dataInicioVigencia) {
		PerfilComercialCorretor perfilComercial = findPerfilComercial(corretor, produto, dataInicioVigencia);
		if(perfilComercial != null) {
			return mongoTemplate.find(
					query(
							where("perfilComercial").is(perfilComercial.getPerfilComercial())),
					PerfilComercialJurosParcelamento.class);
		} else {
			return Collections.<PerfilComercialJurosParcelamento>emptyList();
		}
	}
	
	public List<PerfilComercialCobertura> findPerfilComercialCobertura(Long corretor, Integer produto,Date dataInicioVigencia) {
		PerfilComercialCorretor perfilComercial = findPerfilComercial(corretor, produto, dataInicioVigencia);
		if(perfilComercial != null) {
			return findPerfilComercialCobertura(produto, perfilComercial);
		} else {
			return Collections.<PerfilComercialCobertura>emptyList();
		}
	}

	//@Cacheable("perfilComercialCobertura")
	public List<PerfilComercialCobertura> findPerfilComercialCobertura(Integer produto,
			PerfilComercialCorretor perfilComercial) {
		return mongoTemplate.find(
				query(
						where("perfilComercial").is(perfilComercial.getPerfilComercial())
						.and("produto").is(produto)
						.and("inativo").is(false)
						),
				PerfilComercialCobertura.class);
	}
}