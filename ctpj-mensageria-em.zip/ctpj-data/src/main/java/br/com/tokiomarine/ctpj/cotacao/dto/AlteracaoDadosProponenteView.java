package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

public class AlteracaoDadosProponenteView implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String nomeSegurado;
	private String idCEPSegurado;
	private String enderecoSegurado;
	private Long numeroEnderecoSegurado;
	private String nomeComplementoEnderecoSegurado;
	private String nomeBairroSegurado;
	private String nomeMunicipioSegurado;
	private String idUFSegurado;
	private String idEmailSegurado;

	public String getNomeSegurado() {
		return nomeSegurado;
	}

	public void setNomeSegurado(String nomeSegurado) {
		this.nomeSegurado = nomeSegurado;
	}

	public String getIdCEPSegurado() {
		return idCEPSegurado;
	}

	public void setIdCEPSegurado(String idCEPSegurado) {
		this.idCEPSegurado = idCEPSegurado;
	}

	public String getEnderecoSegurado() {
		return enderecoSegurado;
	}

	public void setEnderecoSegurado(String enderecoSegurado) {
		this.enderecoSegurado = enderecoSegurado;
	}

	public Long getNumeroEnderecoSegurado() {
		return numeroEnderecoSegurado;
	}

	public void setNumeroEnderecoSegurado(Long numeroEnderecoSegurado) {
		this.numeroEnderecoSegurado = numeroEnderecoSegurado;
	}

	public String getNomeComplementoEnderecoSegurado() {
		return nomeComplementoEnderecoSegurado;
	}

	public void setNomeComplementoEnderecoSegurado(String nomeComplementoEnderecoSegurado) {
		this.nomeComplementoEnderecoSegurado = nomeComplementoEnderecoSegurado;
	}

	public String getNomeBairroSegurado() {
		return nomeBairroSegurado;
	}

	public void setNomeBairroSegurado(String nomeBairroSegurado) {
		this.nomeBairroSegurado = nomeBairroSegurado;
	}

	public String getNomeMunicipioSegurado() {
		return nomeMunicipioSegurado;
	}

	public void setNomeMunicipioSegurado(String nomeMunicipioSegurado) {
		this.nomeMunicipioSegurado = nomeMunicipioSegurado;
	}

	public String getIdUFSegurado() {
		return idUFSegurado;
	}

	public void setIdUFSegurado(String idUFSegurado) {
		this.idUFSegurado = idUFSegurado;
	}

	public String getIdEmailSegurado() {
		return idEmailSegurado;
	}

	public void setIdEmailSegurado(String idEmailSegurado) {
		this.idEmailSegurado = idEmailSegurado;
	}

	@Override
	public String toString() {
		return "AlteracaoDadosProponenteView [nomeSegurado=" + nomeSegurado + ", idCEPSegurado=" + idCEPSegurado + ", enderecoSegurado=" + enderecoSegurado + ", numeroEnderecoSegurado=" + numeroEnderecoSegurado + ", nomeComplementoEnderecoSegurado=" + nomeComplementoEnderecoSegurado
				+ ", nomeBairroSegurado=" + nomeBairroSegurado + ", nomeMunicipioSegurado=" + nomeMunicipioSegurado + ", idUFSegurado=" + idUFSegurado + ", idEmailSegurado=" + idEmailSegurado + "]";
	}	

}
