package br.com.tokiomarine.ctpj.endosso.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.cliente.dto.FormaCobrancaCliente;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.integracao.cliente.service.FormaCobrancaClienteService;
import br.com.tokiomarine.ctpj.integracao.dto.ClienteDados;

@Service
public class EndossoAlteracaoCadastralTdoService {
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired
	private FormaCobrancaClienteService formaCobrancaClienteService;
	
	/**
	 * 
	 * @param formaPagamentoAlterada
	 * @param proposta
	 * @param cotacao
	 * @return
	 */
	public Boolean isFormaPagamentoAlterada(PropostaView proposta,//
			Cotacao cotacao) {
		
		
		if(isAlteracaoDadosCadastraisTdo(cotacao)) {
			if(cotacao.getNumeroBancoBoleto() != null) {
				proposta.getCotacao().setFormaPagamentoAlteracao(FormaPagamentoEnum.CARNE.getCodigo());		
				return true;
			}
			else if(cotacao.getNumeroBancoDebito() != null) {
				proposta.getCotacao().setFormaPagamentoAlteracao(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo());
				return true;
			}
			else if(!StringUtils.isBlank(cotacao.getIdToken())) {
				proposta.getCotacao().setFormaPagamentoAlteracao(FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo());
				return true;
			}
		}	
		return false;
	}
	
	public Boolean isAlteracaoDadosCadastraisTdo(Cotacao cotacao) {
		return  isDestinoEmissaoAcsel(cotacao) &&
				cotacao.getCodigoTipoEndossoSCT() != null &&  
				cotacao.getCodigoTipoEndossoSCT().equals(TipoEndossoSctEnum.TDO_ALTERACAO_DADOS_CADASTRAIS);
	}
	
	public Boolean isPagamentoCartao(ClienteDados dados) {
		return  dados != null &&
				dados.getDadosPagamento() != null &&
				SimNaoEnum.SIM == dados.getDadosPagamento().getPagamentoCartaoCredito();
	}
	
	
	
	/**
	 * Carrega as formas de pagamento liberadas (conforme o tipo de pagamento escolhido para a apólice emitida)
	 * @param cotacao
	 * @param model
	 * 
	 * Alterações de pagamento permitidas:
	 * -debito para ficha;
	 * -debito pra debito;
	 * -ficha pra debito;
	 * -cartao pra debito;
	 * -cartao pra ficha;
	 * -cartao pra cartao.
	 * 
	 */
	public List<FormaPagamentoEnum> carregarFormasPagamento(Cotacao cotacao) {
		List<FormaPagamentoEnum> formasPagamento = new ArrayList<>();
		//verifica se a cotação possui id da apolice no mongo
		if(isAlteracaoDadosCadastraisTdo(cotacao) && 
				!StringUtils.isEmpty(cotacao.getIdMongoEndosso())) {
			//valida se a apólice possui os ids do cliente e da forma de cobrança
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			if(apolice != null && apolice.getIdFrmCobPrimeira() != null && !StringUtils.isEmpty(apolice.getIdCliente())) {
				//busca a forma de cobrança da apólice
				FormaCobrancaCliente formaCobrancaCliente = formaCobrancaClienteService.consultarFormaCobrancaCliente(Long.valueOf(apolice.getIdCliente()), BigInteger.valueOf(apolice.getIdFrmCobPrimeira()));
				if(formaCobrancaCliente != null){
					//conforme a forma de cobrança da apólice, libera as formas de pagamento para alteração
					switch (FormaPagamentoEnum.getByTipoDocumentoACT(formaCobrancaCliente.getTpCobrc())) {
					case CARNE:
						formasPagamento.add(FormaPagamentoEnum.DEBITO_EM_CONTA);
						break;
					case CARTAO_DE_CREDITO:
						formasPagamento.add(FormaPagamentoEnum.CARNE);
						formasPagamento.add(FormaPagamentoEnum.CARTAO_DE_CREDITO);
						formasPagamento.add(FormaPagamentoEnum.DEBITO_EM_CONTA);
						break;
					case DEBITO_EM_CONTA:
						formasPagamento.add(FormaPagamentoEnum.CARNE);
						formasPagamento.add(FormaPagamentoEnum.DEBITO_EM_CONTA);
						break;
					}
				}					
			}	
		}
		return formasPagamento;
		
	}
	
	/**
	 * Se for Endosso de Alteração de Dados Cadastrais/TDO e não houver alteração de pagamento, limpa todos os dados de pagamento gravados previamente.
	 * @param proposta
	 * @param cotacao
	 */
	public void validarDadosPagamento(PropostaView proposta, Cotacao cotacao) {
		if(isAlteracaoDadosCadastraisTdo(cotacao) && 
		   proposta.getCotacao().getAlterarFormaPagamento() != null && 
		   proposta.getCotacao().getAlterarFormaPagamento().equals(SimNaoEnum.NAO)) {
			
			proposta.setCodigoFormaPagamento(null);
			proposta.getCotacao().setNumeroBancoDebito(null);
			proposta.getCotacao().setNumeroAgenciaDebito(null);
			proposta.getCotacao().setNumeroContaCorrenteDebito(null);
			proposta.getCotacao().setNumeroDigitoContaCorrenteDebito(null);
			proposta.getCotacao().setIdRelacaoPagadorDebito(null);
			proposta.getCotacao().setNumeroBancoBoleto(null);
			proposta.getCotacao().setNomeAgenciaDebito(null);
			proposta.getCotacao().setNumeroTelefoneAgencia(null);
			proposta.getCotacao().setNomeCidadeAgencia(null);
			proposta.getCotacao().setNomeBairroAgencia(null);
			proposta.getCotacao().setIdCepAgencia(null);
			proposta.getCotacao().setEnderecoAgencia(null);
			
			cotacao.setCodigoFormaPagamentoPrimeiraParcela(null);
			cotacao.setNumeroBancoBoleto(null);
			cotacao.setNumeroBancoDebito(null);
			cotacao.setNumeroAgenciaDebito(null);
			cotacao.setNumeroContaCorrenteDebito(null);
			cotacao.setNumeroDigitoContaCorrenteDebito(null);
			cotacao.setIdRelacaoPagadorDebito(null);
			cotacao.setNomeAgenciaDebito(null);
			cotacao.setNumeroTelefoneAgencia(null);
			cotacao.setNomeCidadeAgencia(null);
			cotacao.setNomeBairroAgencia(null);
			cotacao.setIdCepAgencia(null);
			cotacao.setEnderecoAgencia(null);
		}
	}
	
	/**
	 * Retorna TRUE caso seja uma alteração de segurado, porém na apólice (do segurado anterior) a forma de pagamento for DÉBITO com o proprio TITULAR 
	 * como proprietário da conta corrente
	 * @param cotacao
	 * @return
	 */
	public Boolean hasNecessidadeAlteracaoPagamento(Cotacao cotacao) {
		if(isAlteracaoDadosCadastraisTdo(cotacao)) {
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			if(cotacao.getNumeroBancoBoleto()==null && cotacao.getNumeroBancoDebito()==null && !apolice.getNumeroCNPJCPFSegurado().equals(cotacao.getNumeroCNPJCPFSegurado())) {
				FormaCobrancaCliente formaCobranca = formaCobrancaClienteService.getFormaCobrancaClienteFromApolice(apolice);
				return formaCobrancaClienteService.isDebitoTitularEqualsProprioSegurado(formaCobranca);
			}
		}
		return false;
	}
	
	/**
	 * Retorna TRUE caso seja uma alteração cadastral/TDO com alteração na forma de pagamento 
	 * @param proposta
	 * @param cotacao
	 * @return
	 */
	public Boolean isAlteracaoCadastralComAlteracaoPagamento(PropostaView proposta, Cotacao cotacao) {
		return isAlteracaoDadosCadastraisTdo(cotacao) && 
		   proposta.getCotacao().getAlterarFormaPagamento() != null && 
		   proposta.getCotacao().getAlterarFormaPagamento().equals(SimNaoEnum.SIM);
	}
	
	/**
	 * Retorna TRUE caso seja uma alteração cadastral/TDO com alteração na forma de pagamento 
	 * @param proposta
	 * @param cotacao
	 * @return
	 */
	public Boolean isAlteracaoCadastralComAlteracaoPagamento(Cotacao cotacao, ClienteDados clienteDados) {
		return isAlteracaoDadosCadastraisTdo(cotacao) && (cotacao.getNumeroBancoBoleto() != null || cotacao.getNumeroBancoDebito() != null || isPagamentoCartao(clienteDados));
	}
	
	private Boolean isDestinoEmissaoAcsel(Cotacao cotacao) {
		return cotacao.getIdDestinoEmissao() != null && 
				cotacao.getIdDestinoEmissao().equals(DestinoEmissaoEnum.ACX);
	}
}
