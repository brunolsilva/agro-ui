package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.service.ContaCorrenteService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.DescontoCCGService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.StatusEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request.ProvisaoRequest;
import br.com.tokiomarine.ctpj.integracao.dto.RetornoConsultarSaldo;
import br.com.tokiomarine.ctpj.integracao.dto.RetornoProvisao;
import br.com.tokiomarine.ctpj.integracao.service.ConsultarSaldoService;
import br.com.tokiomarine.ctpj.integracao.service.ProvisaoService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Controller
@RequestMapping(value = "/contacorrente")
public class ContaCorrenteController extends AbstractController {

	private static final Logger logger = LogManager.getLogger(ContaCorrenteController.class);
	
	@Autowired
	CotacaoService cotacaoService;
	
	@Autowired
	ProdutoService produtoService;
	
	@Autowired
	ConsultarSaldoService consultarSaldoService;
	
	@Autowired
	ContaCorrenteService contaCorrenteService;
	
	@Autowired
	DescontoCCGService descontoCCGService;
	
	@Autowired
	ProvisaoService provisaoService;

	@LogPerformance
	@GetMapping(value = "/consultarSaldos/{id}")
	/**
	 * Retorna as verbas disponíveis no Conta Corrente juntamente com o agravo ou desconto(s) aplicado(s) pelo usuário - tabela 101
	 * @param id
	 * @return
	 */
	public @ResponseBody ResultadoREST<RetornoConsultarSaldo> consultarSaldos(@PathVariable BigInteger id) throws ServiceException {
		return consultarSaldoService.loadSaldo(id, super.getUser());
	}
	
	@LogPerformance
	@PostMapping(value = "/validarProvisao")
	/**
	 * Valida a provisão para o agravo ou desconto(s) aplicado(s)
	 * @param provisao
	 * @return
	 */
	public @ResponseBody ResultadoREST<RetornoProvisao> validarProvisao(@RequestBody ProvisaoRequest provisao) {
		ResultadoREST<RetornoProvisao> resultado = new ResultadoREST<>();
		resultado.setSuccess(false);
		try {
			//carrega o user
			User user = SecurityUtils.getCurrentUser();
			
			//carrega a cotação
			//carrega a cotação
			Cotacao cotacao = cotacaoService.findCotacaoContaCorrente(new BigInteger(provisao.getDocumentoSegurado()));
			
			//carrega o produto
			Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
			
			RetornoProvisao retornoProvisao = null;
			
			//valida a provisão
			retornoProvisao = provisaoService.validarProvisao(user,produto,cotacao,provisao);				
			

			if(retornoProvisao == null){
				throw new Exception("Retorno do serviço Validar Provisão nulo");
			} else if(retornoProvisao.getIcProvisionarValor() == StatusEnum.SUCESSO) {
				resultado.setSuccess(true);	
				
				//aplicar total de descontos e agravos
				contaCorrenteService.aplicarAgravoDesconto(cotacao, provisao);
				
				//aplicar total de descontos
				descontoCCGService.aplicarDescontos(cotacao,provisao);
			}
			
			resultado.setRetornoObj(retornoProvisao);

			return resultado;
		} catch (Exception e) {
			logger.error("Erro ao validar provisão para a sequência cotação: "+provisao.getDocumentoSegurado(), e);
			return resultado;
		}
	}
	


}
