package br.com.tokiomarine.ctpj.integracao.backoffice.request;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AproveitamentoCreditoRequest implements Serializable {

	@JsonProperty("p_cd_ramo_produto_tmsr")
	private Integer codigoRamoProdutoTmsr;

	@JsonProperty("p_cd_apolice_tmsr")
	private Long codigoApoliceTmsr;

	@JsonProperty("p_cd_tipo_endosso_tmsr")
	private Integer codigoTipoEndossoTmsr;

	@JsonProperty("p_cd_endosso_tmsr")
	private Long codigoEndossoTmsr;

	@JsonProperty("p_cd_forma_pagamento")
	private Long codigoFormaPagamento;

	@JsonProperty("p_cd_forma_parcelamento")
	private Long codigoFormaParcelamento;

	@JsonProperty("p_dt_vencimento")
	private String dataVencimento;

	@JsonProperty("p_mensagem")
	private String mensagem;

	@JsonProperty("p_mens")
	private String mens;

	@JsonProperty("p_nm_usuario")
	private String usuario;

	@JsonProperty("p_cd_pedido_cotacao")
	private BigInteger numeroCotacaoProposta;

	@JsonProperty("p_id_movimentacao")
	private String idMovimentacao;

	@JsonProperty("p_cd_matricula")
	private String codigoMatricula;

	public Integer getCodigoRamoProdutoTmsr() {
		return codigoRamoProdutoTmsr;
	}

	public void setCodigoRamoProdutoTmsr(Integer codigoRamoProdutoTmsr) {
		this.codigoRamoProdutoTmsr = codigoRamoProdutoTmsr;
	}

	public Long getCodigoApoliceTmsr() {
		return codigoApoliceTmsr;
	}

	public void setCodigoApoliceTmsr(Long codigoApoliceTmsr) {
		this.codigoApoliceTmsr = codigoApoliceTmsr;
	}

	public Integer getCodigoTipoEndossoTmsr() {
		return codigoTipoEndossoTmsr;
	}

	public void setCodigoTipoEndossoTmsr(Integer codigoTipoEndossoTmsr) {
		this.codigoTipoEndossoTmsr = codigoTipoEndossoTmsr;
	}

	public Long getCodigoEndossoTmsr() {
		return codigoEndossoTmsr;
	}

	public void setCodigoEndossoTmsr(Long codigoEndossoTmsr) {
		this.codigoEndossoTmsr = codigoEndossoTmsr;
	}

	public Long getCodigoFormaPagamento() {
		return codigoFormaPagamento;
	}

	public void setCodigoFormaPagamento(Long codigoFormaPagamento) {
		this.codigoFormaPagamento = codigoFormaPagamento;
	}

	public Long getCodigoFormaParcelamento() {
		return codigoFormaParcelamento;
	}

	public void setCodigoFormaParcelamento(Long codigoFormaParcelamento) {
		this.codigoFormaParcelamento = codigoFormaParcelamento;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public String getMens() {
		return mens;
	}

	public void setMens(String mens) {
		this.mens = mens;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public String getIdMovimentacao() {
		return idMovimentacao;
	}

	public void setIdMovimentacao(String idMovimentacao) {
		this.idMovimentacao = idMovimentacao;
	}

	public String getCodigoMatricula() {
		return codigoMatricula;
	}

	public void setCodigoMatricula(String codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	@Override
	public String toString() {
		return "AproveitamentoCreditoRequest [codigoRamoProdutoTmsr=" + codigoRamoProdutoTmsr + ", codigoApoliceTmsr=" + codigoApoliceTmsr + 
				", codigoTipoEndossoTmsr=" + codigoTipoEndossoTmsr + ", codigoEndossoTmsr=" + codigoEndossoTmsr + ", codigoFormaPagamento=" + codigoFormaPagamento + 
				", codigoFormaParcelamento=" + codigoFormaParcelamento + ", dataVencimento=" + dataVencimento + ", mens=" + mens + ", usuario=" + usuario + 
				", numeroCotacaoProposta=" + numeroCotacaoProposta + ", idMovimentacao=" + idMovimentacao + ", codigoMatricula=" + codigoMatricula + "]";
	}

}
