package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.domain.Produto;

@Service
public class EndossoDadosCapaService {
	
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	/**
	 * prc_ctp0100
	 */
	public void validarDadosDaCapa(Produto produto, Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		//Validando o Código Produtor
//		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getCodigoProdutor(), endosso.getCodigoProdutor(), TipoMensagemEndossoEnum.ALT_PRODUTOR, "- Código Produtor ", produto, endosso, alteracoesEndossoList, user);
//		//Validando o Nome Produtor		
//		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNomeProdutor(), endosso.getNomeProdutor(), TipoMensagemEndossoEnum.ALT_PRODUTOR, "- Nome Produtor ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Código da Companhia Seguradora
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getCodigoCompanhiaSeguradora(), endosso.getCodigoCompanhiaSeguradora(), TipoMensagemEndossoEnum.ALT_RENOV_CONGENERE, "- Seguradora ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Código da Apólice Congênere
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNumeroApoliceCongenere(), endosso.getNumeroApoliceCongenere(), TipoMensagemEndossoEnum.ALT_RENOV_CONGENERE, "- Apólice anterior ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Data Fim Vigência
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getDataFimVigencia(), endosso.getDataFimVigencia(), TipoMensagemEndossoEnum.ALT_VIGENCIA, "- Término de vigência ", produto, endosso, alteracoesEndossoList, user);
		//Validando o CPF/CNPJ Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNumeroCNPJCPFSegurado(), endosso.getNumeroCNPJCPFSegurado(), TipoMensagemEndossoEnum.ALT_TDO, "- CPF/CNPJ(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Nome Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNomeSegurado(), endosso.getNomeSegurado(), TipoMensagemEndossoEnum.ALT_NOME_SEGURADO, "- Nome(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Código Atividade Principal
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getCodigoAtividadePrincipal(), endosso.getCodigoAtividadePrincipal(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Atividade Principal ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Cep Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getIdCEPSegurado(), endosso.getIdCEPSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- CEP(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Endereço Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getEnderecoSegurado(), endosso.getEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Endereço(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Bairro Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNomeBairroSegurado(), endosso.getNomeBairroSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Bairro(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Numero Endereço Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNumeroEnderecoSegurado(), endosso.getNumeroEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Nº End(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Complemento Endereço Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNomeComplementoEnderecoSegurado(), endosso.getNomeComplementoEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Compl End(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Município Endereço Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getNomeMunicipioSegurado(), endosso.getNomeMunicipioSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Município(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o UF Endereço Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getIdUFSegurado(), endosso.getIdUFSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- UF(Segurado) ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Numero DDD e Telefone Segurado
		validacaoParametrosEndossoService.compararParametrosTelefone(apolice.getNumeroDDDSegurado(), apolice.getNumeroTelefoneSegurado(), endosso.getNumeroDDDSegurado(), endosso.getNumeroTelefoneSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Telefone ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Numero DDD e Celular Segurado
		validacaoParametrosEndossoService.compararParametrosTelefone(apolice.getNumeroDDDCelularSegurado(), apolice.getNumeroCelularSegurado(), endosso.getNumeroDDDCelularSegurado(), endosso.getNumeroCelularSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Celular ", produto, endosso, alteracoesEndossoList, user);
		//Validando o Email Segurado
		validacaoParametrosEndossoService.compararParametrosEndosso(apolice.getIdEmailSegurado(), endosso.getIdEmailSegurado(), TipoMensagemEndossoEnum.ALT_DADOS_SEGURADO, "- Email ", produto, endosso, alteracoesEndossoList, user);
	}
}
