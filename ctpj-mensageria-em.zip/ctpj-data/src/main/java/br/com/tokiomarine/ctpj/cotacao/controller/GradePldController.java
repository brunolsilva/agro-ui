package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.integracao.grade.request.PropostaSeguradoPldRequest;
import br.com.tokiomarine.ctpj.integracao.grade.response.SeguradoPldResponse;
import br.com.tokiomarine.ctpj.integracao.service.GradePldService;

/**
 * 
 * @author Ricardo Yukio Miwa
 *
 */
@Controller
public class GradePldController {
	
	private static Logger logger = LogManager.getLogger(GradePldController.class);
	
	@Autowired
	private GradePldService gradePldService;
	
	@GetMapping(value = "/rest/grade/pld/{numeroCotacaoProposta}")
	public @ResponseBody ResponseEntity<SeguradoPldResponse>  buscarDadosSeguradoPld(@PathVariable BigInteger numeroCotacaoProposta,HttpServletRequest request,HttpServletResponse response,ModelMap model){
		SeguradoPldResponse resultado = new SeguradoPldResponse();
		
		try {
			logger.info("Carregando /rest/grade/pld/"+numeroCotacaoProposta);
			PropostaSeguradoPldRequest propostaSeguradoPldRequest = new PropostaSeguradoPldRequest(); 
			propostaSeguradoPldRequest.setNumeroPropostaCotacao(numeroCotacaoProposta);
			resultado = gradePldService.buscarDadosSeguradoPLD(propostaSeguradoPldRequest);
			return new ResponseEntity<SeguradoPldResponse>(resultado,HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Erro ao chamar o REST SERVICE no Controller: " + e.getMessage());
			new ResponseEntity<SeguradoPldResponse>(resultado,HttpStatus.BAD_REQUEST);
			return null;
		}
	}

}
