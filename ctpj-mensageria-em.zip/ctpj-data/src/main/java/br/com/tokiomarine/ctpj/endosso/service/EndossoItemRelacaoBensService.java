package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemRelacaoBemApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemRelacaoBensService {

	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0115
	 */
	public void validarItemRelacaoBem(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiItemRelBem = itemEndosso.getListItemRelacaoBem() != null && !itemEndosso.getListItemRelacaoBem().isEmpty();
		boolean itemApolicePossuiItemRelBem = itemApolice.getListItemRelacaoBemApolice() != null && !itemApolice.getListItemRelacaoBemApolice().isEmpty();
		
		//1 - percorre os itens relacao bens do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiItemRelBem){			
			for(ItemRelacaoBem itemEndossoRelacaoBem : itemEndosso.getListItemRelacaoBem()){
				boolean itemRelBemExiste = false;
				if(itemApolicePossuiItemRelBem){
					for(ItemRelacaoBemApolice itemApolRelacaoBem : itemApolice.getListItemRelacaoBemApolice()){
						if(AssertUtils.compareNull(itemEndossoRelacaoBem.getSequencialRelacaoBem(),itemApolRelacaoBem.getSequencialRelacaoBem())){
							//valida descricao bem
							validacaoParametrosEndossoService.compararParametrosItem(itemApolRelacaoBem.getDescricaoBem(), itemEndossoRelacaoBem.getDescricaoBem(), TipoMensagemEndossoEnum.ALT_RELACAO_BEM, "- Descrição: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida valor is
							validacaoParametrosEndossoService.compararParametrosItem(itemApolRelacaoBem.getValorImportanciaSegurada(), itemEndossoRelacaoBem.getValorImportanciaSegurada(), TipoMensagemEndossoEnum.ALT_RELACAO_BEM, "- IS: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida valor is moeda estrangeira
							validacaoParametrosEndossoService.compararParametrosItem(itemApolRelacaoBem.getValorImportanciaSeguradaMoedaEstrangeira(), itemEndossoRelacaoBem.getValorImportanciaSeguradaMoedaEstrangeira(), TipoMensagemEndossoEnum.ALT_RELACAO_BEM, "- IS em dólar: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							itemRelBemExiste = true;
							break;
						}						
					}
				}
				
				//se o item relacao bem não existir
				if(!itemRelBemExiste){ 
					logarInclusaoItem(itemEndossoRelacaoBem,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os itens relacao bens da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiItemRelBem){
			for(ItemRelacaoBemApolice itemApolRelacaoBem : itemApolice.getListItemRelacaoBemApolice()){
				boolean itemDistribExiste = false;
				if(itemEndossoPossuiItemRelBem){
					for(ItemRelacaoBem itemEndossoRelacaoBem : itemEndosso.getListItemRelacaoBem()){
						if(AssertUtils.compareNull(itemEndossoRelacaoBem.getSequencialRelacaoBem(),itemApolRelacaoBem.getSequencialRelacaoBem())){
							itemDistribExiste = true;
							break;
						}
					}
				}
				
				if(!itemDistribExiste){
					logarExclusaoItem(itemApolRelacaoBem,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoItem(ItemRelacaoBem itemEndossoRelacaoBem, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_RELACAO_BEM, itemEndossoRelacaoBem.getSequencialRelacaoBem().toString(), user));
	}
	
		
	private void logarExclusaoItem(ItemRelacaoBemApolice itemApolRelacaoBem, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_RELACAO_BEM, itemApolRelacaoBem.getSequencialRelacaoBem().toString(), user));
	}
}
