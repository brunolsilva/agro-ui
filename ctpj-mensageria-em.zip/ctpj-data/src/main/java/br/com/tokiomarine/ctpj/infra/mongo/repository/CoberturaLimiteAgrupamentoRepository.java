package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoLimiteAgrupamento;

@Repository
public class CoberturaLimiteAgrupamentoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@LogPerformance
	public BigDecimal findByProduto(Integer produto,Cotacao cotacao) {
		return mongoTemplate.findOne(query(
				where("produto").is(produto)
				.and("dataInicioVigencia").lte(cotacao.getDataInicioVigencia())
				.orOperator(
						where("dataTerminoVigencia").gte(cotacao.getDataInicioVigencia()),
						where("dataTerminoVigencia").is(null))),
				ProdutoLimiteAgrupamento.class).getValorLimiteIS();
	}
}
