package br.com.tokiomarine.ctpj.integracao.aceitacao;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NossoNumeroACT implements Serializable {

	private static final long serialVersionUID = 8997949425021260990L;

	@JsonProperty("codigoCorretor")
	private Long codigoCorretor;

	@JsonProperty("formaPagamento")
	private String formaPagamento;

	@JsonProperty("codBancoCobrador")
	private Long codigoBancoCobrador;

	@JsonProperty("user")
	private String user;

	public Long getCodigoCorretor() {
		return codigoCorretor;
	}

	public void setCodigoCorretor(Long codigoCorretor) {
		this.codigoCorretor = codigoCorretor;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public Long getCodigoBancoCobrador() {
		return codigoBancoCobrador;
	}

	public void setCodigoBancoCobrador(Long codigoBancoCobrador) {
		this.codigoBancoCobrador = codigoBancoCobrador;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "NossoNumeroACTRequest [codigoCorretor=" + codigoCorretor + ", formaPagamento=" + formaPagamento
				+ ", codigoBancoCobrador=" + codigoBancoCobrador + ", user=" + user + "]";
	}


}