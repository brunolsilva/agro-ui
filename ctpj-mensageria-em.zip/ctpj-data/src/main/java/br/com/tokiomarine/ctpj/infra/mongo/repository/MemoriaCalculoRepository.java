package br.com.tokiomarine.ctpj.infra.mongo.repository;

import java.math.BigInteger;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.domain.mongo.MemoriaCalculo;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Repository
public interface MemoriaCalculoRepository extends MongoRepository<MemoriaCalculo, BigInteger> {

}
