package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;

@Repository
public class ItemCotacaoRenumeracaoRepository extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(ItemCotacaoRenumeracaoRepository.class);


	public BigInteger maxNumeroItemCotacao(BigInteger sequencialCotacaoProposta) throws HibernateException {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("select Max(i.numeroItem) ");
			sb.append("from   ItemCotacao i ");
			sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
			Query query = getCurrentSession().createQuery(sb.toString());
			query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
			return (BigInteger) query.uniqueResult();
		} catch (Exception e) {
			logger.error("Erro ao buscar Max número Item por sequencialCotacaoProposta: " + sequencialCotacaoProposta,e);
			throw new HibernateException("Erro ao buscar Max número Item por sequencialCotacaoProposta: " + sequencialCotacaoProposta,e);
		}
	}

	@LogPerformance
	public void updateItemCotacao(List<ItemCotacao> listItemCotacao) throws HibernateException {
		try {
			for (ItemCotacao item : listItemCotacao) {
				item.setDataAtualizacao(Calendar.getInstance().getTime());
				super.getCurrentSession().update(item);
			}
		} catch (Exception e) {
			logger.error("Erro ao Gravar ItemCotacao");
			throw new HibernateException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public void deleteItemCotacao(ItemCotacao itemCotacao) throws HibernateException {
		try {
			super.getCurrentSession().delete(itemCotacao);
		} catch (Exception e) {
			logger.error("Erro ao exlcuir ItemCotacao");
			throw new HibernateException(e.getMessage(),e);
		}
	}

}
