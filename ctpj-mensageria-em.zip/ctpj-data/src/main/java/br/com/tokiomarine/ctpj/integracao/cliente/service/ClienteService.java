package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URI;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;

import br.com.tokiomarine.cliente.dto.ClientePessoa;
import br.com.tokiomarine.cliente.dto.ClienteProposta;
import br.com.tokiomarine.cliente.dto.Consulta;
import br.com.tokiomarine.cliente.dto.FormaCobrancaCliente;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteContato;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteEndereco;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteFisica;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteJuridica;
import br.com.tokiomarine.cliente.dto.persistencia.ClientePagamento;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteRequest;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.apolice.service.ParcelamentoApoliceService;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CartaoResponse;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.endosso.service.EndossoAlteracaoCadastralTdoService;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoProcessamentoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SexoEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.infra.type.Usuarios;
import br.com.tokiomarine.ctpj.integracao.dto.ClienteDados;
import br.com.tokiomarine.ctpj.integracao.dto.ClienteDadosPagamento;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.ServicosClienteEnum;
import br.com.tokiomarine.ctpj.type.TipoCobrancaEnum;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.ctpj.util.StringUtil;
import br.com.tokiomarine.ctpj.ws.request.BancoDebitoRequest;

@Service
public class ClienteService extends BaseClienteService {
		
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;
	
	@Autowired
	private ParcelamentoApoliceService parcelamentoApoliceService;
	
	@Autowired
	private EndossoAlteracaoCadastralTdoService endossoAlteracaoCadastralTdoService;
	
	@Autowired
	private FormaCobrancaClienteService formaCobrancaClienteService;
	
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired
	private ParametroGeralService parametroGeralService;//#
	
		
	public Consulta consultaAgenciaBanco(Object[] parametros) {
		Consulta consultaResponse = null;
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(), ServicosClienteEnum.AGENCIA_BANCO
					, parametros);

			consultaResponse = restTemplate.getForObject(uri,Consulta.class);		
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Consultar Banco Agencia Cliente ",e);
		}
		return consultaResponse;
	}
		
	public void salvarCliente(Cotacao cotacao, ClienteDados clienteDados, OpcaoParcelamento parcelamentoSelecionado) throws ServiceException {
		User user = getUser();
		ClientePessoa clientePessoa = this.findCliente(cotacao,user);
		if(clientePessoa != null && clientePessoa.getCdClien() != null) {
			cotacao.setCodigoCliente(clientePessoa.getCdClien());
		}
		//caso não encontre o cliente no serviço, salva o mesmo
		ClienteProposta clienteResponse = null;
		clienteResponse = salvarCliente(cotacao,user,clienteResponse,clienteDados,parcelamentoSelecionado);
		populaDadosCliente(cotacao, clienteResponse,clienteDados);
	}

	private void populaDadosCliente(Cotacao cotacao, ClienteProposta clienteResponse, ClienteDados clienteDados) {
		if(clienteResponse != null) {
			//se o cliente foi salvo com sucesso, grava o código na cotação
			cotacao.setCodigoCliente(clienteResponse.getCdClien());
			if(clienteResponse.getIdTelef() != null) {
				cotacao.setIdTelefone(BigInteger.valueOf(clienteResponse.getIdTelef()));
			}
			if(clienteResponse.getIdNovoEnderClien() != null) {
				cotacao.setIdNovoEnderecoCliente(BigInteger.valueOf(clienteResponse.getIdNovoEnderClien()));
			}
			if(clienteResponse.getIdEmail() != null) {
				cotacao.setIdEmail(BigInteger.valueOf(clienteResponse.getIdEmail()));
			}
			populaFormaCobranca(cotacao, clienteResponse, clienteDados);
		}
	}

	private void populaFormaCobranca(Cotacao cotacao, ClienteProposta clienteResponse, ClienteDados clienteDados) {
		//não salva estas formas de cobrança para devoluções e cotações com prêmio zerado
		if(cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0 || (endossoAlteracaoCadastralTdoService.isAlteracaoCadastralComAlteracaoPagamento(cotacao,clienteDados))) {
			if(clienteResponse.getIdFormaCobrc() != null) {
				cotacao.setIdFormaCobranca(BigInteger.valueOf(clienteResponse.getIdFormaCobrc()));
			}
			if(clienteResponse.getIdFormaCobrcPrmraParcl() != null) {
				cotacao.setIdFormaCobrancaPrimeiraParcela(BigInteger.valueOf(clienteResponse.getIdFormaCobrcPrmraParcl()));
			}	//		
		}
	}

	private User getUser() {
		User user = new User();
		user.setGrupoUsuario(GrupoUsuarioEnum.INTERFACE_RD);
		user.setCdUsuro(Usuarios.USER_INTERFACE.codigo());
		return user;
	}
	
	private ClienteProposta salvarCliente(Cotacao cotacao,User user,ClienteProposta clienteResponse,ClienteDados clienteDados,
			OpcaoParcelamento parcelamentoSelecionado) throws ServiceException {
		CotacaoLog cotacaoLog = new CotacaoLog();
		ClienteRequest request = null;
	
		try{
			request = criarCliente(cotacao,clienteDados,parcelamentoSelecionado);
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.SALVAR);
			cotacaoLog = cotacaoLogService.bindCotacaoLogBasicSucesso(cotacao,user,TipoProcessamentoEnum.SALVAR_CLIENTE);
			cotacaoLog.setRequest(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request));
			
			clienteResponse = chamarServicoSalvarCliente(cotacao, clienteResponse, request, uri); 
			cotacaoLog.setResponse(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(clienteResponse));
			cotacaoLogService.save(cotacaoLog);
			return clienteResponse;
		} catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Salvar Cliente ",e);
			try {
				cotacaoLog = cotacaoLogService.bindCotacaoLogBasicErro(
						cotacao,user,
						TipoProcessamentoEnum.SALVAR_CLIENTE,
						e.getMessage(),
						JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request),
						JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(clienteResponse));
				cotacaoLogService.save(cotacaoLog);
			} catch (Exception e2) {
				logger.error("Erro geral Salvar Cliente Log salvarCliente ",e2);
			}
			throw new ServiceException(e.getMessage() == null ? "Ocorreu um erro ao salvar os dados do cliente" : e.getMessage());
		}
	}

	private ClienteProposta chamarServicoSalvarCliente(Cotacao cotacao, ClienteProposta clienteResponse,
			ClienteRequest request, URI uri) throws ServiceException {
		try {
			logger.info(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request));
			clienteResponse = restTemplate.postForObject(uri,request,ClienteProposta.class);
		}catch(HttpServerErrorException se){
			logger.error("Erro ao chamar serviço Salvar Cliente - HttpServerErrorException ",se);
			tratarHttpServerErrorException(cotacao,se);
			
		} catch (RestClientException re) {
			logger.error("Erro ao chamar serviço Salvar Cliente ",re);
			throw new ServiceException("Ocorreu um erro ao salvar o cliente");
		}
		return clienteResponse;
	}
	
	public ClientePessoa findCliente(Cotacao cotacao, User user) throws ServiceException {
		ClientePessoa clienteResponse = null;
        if(DestinoEmissaoEnum.ACX == cotacao.getIdDestinoEmissao() &&
           TipoPedidoCotacaoEnum.ENDOSSO == cotacao.getIdTipoPedidoCotacao() &&
           TipoEndossoSctEnum.TDO_ALTERACAO_DADOS_CADASTRAIS != cotacao.getCodigoTipoEndossoSCT()) {
           
            clienteResponse = findClienteByCodigo(cotacao, user);
            if(clienteResponse != null) {
                return clienteResponse;
            }
        }
        clienteResponse = findClienteByCpfCnpj(cotacao, user, clienteResponse);
        return clienteResponse;
	}

	private ClientePessoa findClienteByCpfCnpj(Cotacao cotacao, User user, ClientePessoa clienteResponse)
			throws ServiceException {
		CotacaoLog cotacaoLog = null;
		Boolean ehPessoaFisica = cotacao.getIdTipoPessoa().equals(TipoSeguradoEnum.FISICA);
		TipoProcessamentoEnum tipoProcessamento = ehPessoaFisica ? TipoProcessamentoEnum.PESQUISAR_CLIENTE_CPF : TipoProcessamentoEnum.PESQUISAR_CLIENTE_CNPJ;
		ServicosClienteEnum servicosClienteEnum = ehPessoaFisica ? ServicosClienteEnum.PESQUISAR_POR_CPF_ATIVO : ServicosClienteEnum.PESQUISAR_POR_CNPJ_ATIVO;
		String textoTipoPesquisa = ehPessoaFisica ? "(CPF)" : "(CNPJ)";
		
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),servicosClienteEnum
					, new Object[] {cotacao.getNumeroCNPJCPFSegurado()});
			
			cotacaoLog = cotacaoLogService.bindCotacaoLogBasicSucesso(cotacao,user,tipoProcessamento);
			cotacaoLog.setRequest(uri.toString());
			clienteResponse = findClienteRestCall(textoTipoPesquisa, uri);
			cotacaoLog.setResponse(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(clienteResponse));
			cotacaoLogService.save(cotacaoLog);			
		} catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de pesquisar Cliente ",e);
			try {
				cotacaoLog = cotacaoLogService.bindCotacaoLogBasicErro(cotacao,user,tipoProcessamento,e.getMessage(),cotacao.getNumeroCNPJCPFSegurado().toString(),JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(clienteResponse));
				cotacaoLogService.save(cotacaoLog);
			} catch (Exception e2) {
				logger.error("Erro geral Pesquisar Cliente Log pesquisarCliente ",e2);
			}
			throw new ServiceException("Erro geral ao executar findCliente. Erro:",e);
		}
		return clienteResponse;
	}

	private ClientePessoa findClienteByCodigo(Cotacao cotacao, User user) {
		ClientePessoa clienteResponse = null;
		if(!StringUtil.isEmptyOrNull(cotacao.getIdMongoEndosso())) {
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			if(apolice != null && !StringUtil.isEmptyOrNull(apolice.getIdCliente())) {
				CotacaoLog cotacaoLog = null;
				try {
					//PESQUISAR_CLIENTE_POR_CODIGO
					URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_CLIENTE_PESSOA_POR_CODIGO
							, new Object[] {apolice.getIdCliente()});
					
					cotacaoLog = cotacaoLogService.bindCotacaoLogBasicSucesso(cotacao,user,TipoProcessamentoEnum.PESQUISAR_CLIENTE_POR_CODIGO);
					cotacaoLog.setRequest(uri.toString());
					ClientePessoa[] clienteResponseArray = findClienteListRestCall("(Por código)", uri);
					cotacaoLog.setResponse(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(clienteResponseArray));
					cotacaoLogService.save(cotacaoLog);	
					if(clienteResponseArray != null && clienteResponseArray.length > 0) {
						clienteResponse = clienteResponseArray[0];
					}
				}
				catch(Exception e) {
					logger.error("Erro Geral ao chamar o servico de pesquisar Cliente Pessoa por Codigo ",e);
					try {
						cotacaoLog = cotacaoLogService.bindCotacaoLogBasicErro(cotacao,user,TipoProcessamentoEnum.PESQUISAR_CLIENTE_POR_CODIGO,e.getMessage(),apolice.getIdCliente(),JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(clienteResponse));
						cotacaoLogService.save(cotacaoLog);
					} catch (Exception e2) {
						logger.error("Erro geral Pesquisar Cliente Log pesquisarCliente ",e2);
					}
				}
			}
		}
		return clienteResponse;
	}

	private ClientePessoa findClienteRestCall(String textoTipoPesquisa, URI uri)
			throws ServiceException {
		try {
			return restTemplate.getForObject(uri,ClientePessoa.class);
		} catch (RestClientException re) {
			logger.error("Erro ao chamar serviço pesquisar Cliente "+textoTipoPesquisa,re);
			throw new ServiceException("Erro ao chamar serviço pesquisar Cliente "+textoTipoPesquisa,re);
		}
	}
	
	private ClientePessoa[] findClienteListRestCall(String textoTipoPesquisa, URI uri)
			throws ServiceException {
		try {
			return restTemplate.getForObject(uri,ClientePessoa[].class);
		} catch (RestClientException re) {
			logger.error("Erro ao chamar serviço pesquisar Cliente "+textoTipoPesquisa,re);
			throw new ServiceException("Erro ao chamar serviço pesquisar Cliente "+textoTipoPesquisa,re);
		}
	}
	
	public ClientePessoa consultarClientePessoaPorCodigo(Long codigoCliente) {
		ClientePessoa clienteResponse = null;
		
		if(codigoCliente==null) {
			return clienteResponse;
		}
		
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_POR_CODIGO
					, new Object[] {codigoCliente});
			
			clienteResponse = restTemplate.getForObject(uri,ClientePessoa.class);	
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de pesquisar cliente por codigo ",e);
		}
		return clienteResponse;
	}
	
	public ClienteFisica consultarClientePessoaFisicaPorCodigo(Long codigoCliente) {
		ClienteFisica clienteResponse = null;
		
		if(codigoCliente==null) {
			return clienteResponse;
		}
		
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_CPF_POR_CODIGO
					, new Object[] {codigoCliente});
			
			clienteResponse = restTemplate.getForObject(uri,ClienteFisica.class);	
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de pesquisar Cliente por codigo ",e);
		}
		return clienteResponse;
	}
	
	public ClienteJuridica consultarClientePessoaJuridicaPorCodigo(Long codigoCliente) {
		ClienteJuridica clienteResponse = null;
		
		if(codigoCliente==null) {
			return clienteResponse;
		}
		
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_CPNJ_POR_CODIGO
					, new Object[] {codigoCliente});
			
			clienteResponse = restTemplate.getForObject(uri,ClienteJuridica.class);	
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de pesquisar Cliente por codigo ",e);
		}
		return clienteResponse;
	}
	
	private ClienteRequest criarCliente(Cotacao cotacao, ClienteDados dados, OpcaoParcelamento parcelamentoSelecionado) throws ServiceException {
		ClienteRequest request = new ClienteRequest();
		Integer codigoUsuario = SecurityUtils.getCurrentUser() != null ? SecurityUtils.getCurrentUser().getCdUsuro() : Usuarios.USER_INTERFACE.codigo();
		request.setCdUsuroUltmaAlter(StringUtils.leftPad(String.valueOf(codigoUsuario), 6, "0"));
		request.setId(cotacao.getCodigoCliente());
		preencherCelular(cotacao, request);
		preencherEmail(cotacao, request);
		preencherPagamento(cotacao, dados, request, parcelamentoSelecionado);
		preencherEndereco(cotacao, request);
		preencherDadosSegurado(cotacao, dados, request);
		User user = new User();
		user.setGrupoUsuario(GrupoUsuarioEnum.INTERFACE_RD);
		user.setCdUsuro(Usuarios.USER_INTERFACE.codigo());
		request.setNmClien(cotacao.getNomeSegurado());
		preencherTelefone(cotacao, request);
		request.setTpPesoa(cotacao.getIdTipoPessoa().getId());
		request.setTpClien(null);
		request.setClienteAgrupClienteEstrgReprsLegal(null);
		request.setInfoComplementar(null);
		request.setFisicaInfoComplementar(null);
		request.setJuridicaInfoComplementar(null);

		return request;
	}

	private void preencherPagamento(Cotacao cotacao, ClienteDados dados, ClienteRequest request, OpcaoParcelamento parcelamentoSelecionado)
			throws ServiceException {
		//verifica se é tipo endosso TDO/Alteração cadastral
		if(endossoAlteracaoCadastralTdoService.isAlteracaoDadosCadastraisTdo(cotacao)) {
			preencherPagamentoAlteracaoCadastral(cotacao, dados, request);
		} else {
			if(parcelamentoSelecionado != null){
				request.setPrimeiraParcelaDebito(parcelamentoSelecionado.getCodigoFormaPagamento().equals(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo()));
				if(parcelamentoSelecionado.getCodigoFormaPagamento().equals(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo()) && 
						isDadosContaCorrentePreenchidos(cotacao)){
					
					preencherPagamentoDebito(cotacao, dados, request);				
				} else if(parcelamentoSelecionado.getCodigoFormaPagamento().equals(FormaPagamentoEnum.CARNE.getCodigo())){
					preencherPagamentoBoleto(cotacao, request);
				} else if(parcelamentoSelecionado.getCodigoFormaPagamento().equals(FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo())){
					preencherPagamentoCartaoCredito(cotacao, request);
				}

			} else {
				// quando não tem pagamento, manda valor "default"
				ClientePagamento pagamento = new ClientePagamento();			
				pagamento.setTpCobrc(TipoCobrancaEnum.CARNE.getId());
				pagamento.setCdBancoFicha(33l);
				request.setPagamento(pagamento);
			}
		}
	}

	private void preencherPagamentoCartaoCredito(Cotacao cotacao, ClienteRequest request) throws ServiceException {
		ClientePagamento pagamento = new ClientePagamento();
		String url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroPaymentServer()) + "v1/credit-cards/" + cotacao.getIdToken();
		
		String username = "ctpj";
		String senha = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroSenhaPaymentServer());

		String plainCreds = username + ":" + senha;
		String base64Creds = Base64Utils.encodeToString(plainCreds.getBytes());

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);

		ResponseEntity<CartaoResponse> response = restTemplate.exchange(url, HttpMethod.GET,new HttpEntity<>(headers), CartaoResponse.class);
		CartaoResponse cartaoResponse = response.getBody();
		pagamento.setTpCobrc("C");
		pagamento.setDsNumberCrtao(cartaoResponse.getNumero());
		pagamento.setNmBandeira(cartaoResponse.getBandeira().toLowerCase());
		pagamento.setNmTtlarCrtao(cartaoResponse.getCliente().getNome());
		pagamento.setNrMesVldadCrtao(cartaoResponse.getMesExpiracao().longValue());
		pagamento.setNrAnoVldadCrtao(cartaoResponse.getAnoExpiracao().longValue());
		if(cotacao.getDataVencimentoProgramada() != null) {
			LocalDateTime localDateTime = LocalDateTime.ofInstant(cotacao.getDataVencimentoProgramada().toInstant(), ZoneId.systemDefault());
			LocalDate localDate = localDateTime.toLocalDate();
			pagamento.setNrDiaPagtoFtura((long)localDate.getDayOfMonth());
		}
		pagamento.setNrCpfCnpjTtlarCrtao(Long.valueOf(cartaoResponse.getCliente().getDocumento()));
		pagamento.setTpPesoaTtlarCrtao(cotacao.getIdTipoPessoa().getId());
		pagamento.setTpPrntcTtlarCartao("1");
		pagamento.setIdToken(cotacao.getIdToken());
		request.setPagamento(pagamento);
	}

	private void preencherPagamentoAlteracaoCadastral(Cotacao cotacao, ClienteDados dados, ClienteRequest request) throws ServiceException {
		Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
		
		dados = preencherPagamentoDefaultTdoNovoCliente(cotacao, dados,apolice);
		
		Boolean isPagamentoBoleto = cotacao.getNumeroBancoBoleto() != null;
		Boolean isPagamentoDebito = cotacao.getNumeroBancoDebito() != null;
		
		
		//verifica se houve alteração na forma de pagamento
		if(isPagamentoBoleto || isPagamentoDebito || endossoAlteracaoCadastralTdoService.isPagamentoCartao(dados)) {
			if(isPagamentoDebito) {
				if(isDadosContaCorrentePreenchidos(cotacao)) {
					preencherPagamentoDebito(cotacao, dados, request);	
				}
				else {
					throw new ServiceException("Favor preencher corretamente os dados de conta corrente para débito");
				}
				
			} else if(isPagamentoBoleto) {
				preencherPagamentoBoleto(cotacao, request);
			} else{
				preencherPagamentoCartaoCredito(cotacao, request);
			}
		}
		//senão envia a mesma forma de pagamento da apólice
		else {
			
			if(apolice.getIdFrmCobPrimeira() != null) {
				cotacao.setIdFormaCobrancaPrimeiraParcela(BigInteger.valueOf(apolice.getIdFrmCobPrimeira()));	
			}
			
			if(apolice.getIdFrmCobDemais() != null) {
				cotacao.setIdFormaCobranca(BigInteger.valueOf(apolice.getIdFrmCobDemais()));	
			}
			
			request.setPagamento(new ClientePagamento());
			
			
		}
	}



	/**
	 * Caso seja um TDO e a forma de pagamento não tenha sido alterada, repete os dados de pagamento do cliente anterior (porém associados ao novo cliente) 
	 * @param cotacao
	 * @param dados
	 * @param apolice
	 * @return
	 */
	private ClienteDados preencherPagamentoDefaultTdoNovoCliente(Cotacao cotacao, ClienteDados dados, Apolice apolice) {
		
		if(cotacao.getNumeroBancoBoleto()==null && cotacao.getNumeroBancoDebito()==null && !apolice.getNumeroCNPJCPFSegurado().equals(cotacao.getNumeroCNPJCPFSegurado())) {
			FormaCobrancaCliente formaCobranca = formaCobrancaClienteService.getFormaCobrancaClienteFromApolice(apolice);
			if(formaCobranca != null) {
				if(TipoCobrancaEnum.CARNE.getId().equals(formaCobranca.getTpCobrc())) {
					cotacao.setNumeroBancoBoleto(formaCobranca.getCdBancoFicha().intValue());
				}
				//se a forma de cobrança anterior for igual a débito e o titular da conta não for o próprio titular, assume os dados de pagamento da apolice
				else if(formaCobrancaClienteService.isDebitoTitularNotEqualsProprioSegurado(formaCobranca)) {
					cotacao.setNumeroBancoDebito(formaCobranca.getCdBanco().intValue());
					cotacao.setNumeroAgenciaDebito(formaCobranca.getCdAgencDebitConta());
					cotacao.setNumeroContaCorrenteDebito(formaCobranca.getNrCcDebitConta());
					cotacao.setNumeroDigitoContaCorrenteDebito(formaCobranca.getDvCcDebitConta()); 
					cotacao.setIdRelacaoPagadorDebito(Integer.valueOf(formaCobranca.getTpPrntcTtlarCc()));
					
					if(dados == null) {
						dados = new ClienteDados();
					}
					
					ClienteDadosPagamento dadosPagamento = new ClienteDadosPagamento();
					dadosPagamento.setPrimeiraParcelaDebito(apolice.getIdFrmCobPrimeira()==null ? SimNaoEnum.NAO : SimNaoEnum.SIM);
					dadosPagamento.setNometitularContaCorrenteDebito(formaCobranca.getNmTtlarCc());
					dadosPagamento.setNumeroCNPJCPFTitularContaCorrenteDebito(formaCobranca.getNrCpfCnpjTtlarCc());
					dadosPagamento.setTipoPessoaTitularContaCorrenteDebito(TipoSeguradoEnum.getById(formaCobranca.getTpPesoaTtlarCc()));
					
					dados.setDadosPagamento(dadosPagamento);
				}
			}
		}
		return dados;
	}
	
	private Boolean isDadosContaCorrentePreenchidos(Cotacao cotacao) {
		return cotacao.getNumeroAgenciaDebito() != null && 
				cotacao.getNumeroBancoDebito() != null &&
				cotacao.getNumeroContaCorrenteDebito() != null;
	}

	private void preencherPagamentoBoleto(Cotacao cotacao, ClienteRequest request) {
		ClientePagamento pagamento = new ClientePagamento();
		pagamento.setCdBancoFicha(cotacao.getNumeroBancoBoleto().longValue());
		pagamento.setTpCobrc(TipoCobrancaEnum.CARNE.getId());
		request.setPrimeiraParcelaFicha(true);
		request.setPagamento(pagamento);
	}

	private void preencherPagamentoDebito(Cotacao cotacao, ClienteDados dados, ClienteRequest request) {
		ClientePagamento pagamento = new ClientePagamento();
		ClienteDadosPagamento dadosPagamento = dados.getDadosPagamento();
		if(dadosPagamento.getPrimeiraParcelaDebito() != null) {
			Boolean primeiraParcelaDebito = dadosPagamento.getPrimeiraParcelaDebito().equals(SimNaoEnum.SIM);
			request.setPrimeiraParcelaDebito(primeiraParcelaDebito);
		}
		
		pagamento.setTpCobrc(TipoCobrancaEnum.DEBITO_EM_CONTA.getId());
		pagamento.setCdAgencDebitConta(cotacao.getNumeroAgenciaDebito());
		pagamento.setCdBanco(cotacao.getNumeroBancoDebito() != null ? cotacao.getNumeroBancoDebito().longValue() : null);
		pagamento.setCdBancoFicha(null);
		pagamento.setDvCcDebitConta(cotacao.getNumeroDigitoContaCorrenteDebito()  != null ? cotacao.getNumeroDigitoContaCorrenteDebito() : null);
		pagamento.setNmTtlarCc(dadosPagamento.getNometitularContaCorrenteDebito());
		pagamento.setNrCcDebitConta(cotacao.getNumeroContaCorrenteDebito());
		pagamento.setNrCpfCnpjTtlarCc(dadosPagamento.getNumeroCNPJCPFTitularContaCorrenteDebito());
		pagamento.setTpPesoaTtlarCc(dadosPagamento.getTipoPessoaTitularContaCorrenteDebito() != null ? dadosPagamento.getTipoPessoaTitularContaCorrenteDebito().getId() : null);
		pagamento.setTpPrntcTtlarCc(String.valueOf(cotacao.getIdRelacaoPagadorDebito()));
		request.setPagamento(pagamento);
	}

	private void preencherTelefone(Cotacao cotacao, ClienteRequest request) {
		if(cotacao.getNumeroDDDSegurado() != null && cotacao.getNumeroDDDSegurado() > 0 && cotacao.getNumeroTelefoneSegurado() != null && cotacao.getNumeroTelefoneSegurado() > 0){
			ClienteContato telefone = new ClienteContato();
			telefone.setId(null);
			telefone.setContato(br.com.tokiomarine.ctpj.util.StringUtil.formataTelefone(cotacao.getNumeroDDDSegurado().longValue(),cotacao.getNumeroTelefoneSegurado()));
			telefone.setNrRamal(null);
			telefone.setDtUltmaAlter(new Date());
			request.setTelefone(telefone);
		}
	}

	private void preencherDadosSegurado(Cotacao cotacao, ClienteDados dados, ClienteRequest request) {
		if(cotacao.getIdTipoPessoa().equals(TipoSeguradoEnum.FISICA)){
			preencherPessoaFisica(cotacao, dados, request);
		} else {
			preencherPessoaJuridica(cotacao, dados, request);
		}
	}

	private void preencherPessoaJuridica(Cotacao cotacao, ClienteDados dados, ClienteRequest request) {
		ClienteJuridica juridica = new ClienteJuridica();
		juridica.setCdPatrmLiqui(dados.getPatrimonioLiquido());
		juridica.setCdRectaOprnlBrutaAnual(dados.getReceita());
		juridica.setCdRmatv(dados.getRamoAtividade());
		juridica.setNrCnpj(cotacao.getNumeroCNPJCPFSegurado());
		juridica.setExistContrAdmtrProcr(dados.getExisteControlador());
		juridica.setQtContrAdmtrProcr(dados.getQuantidadeControlador());
		juridica.setTpEmpr(dados.getTipoEmpresa());
		request.setJuridica(juridica);
		request.setFisica(null);
	}

	private void preencherPessoaFisica(Cotacao cotacao, ClienteDados dados, ClienteRequest request) {
		ClienteFisica fisica = new ClienteFisica();
		fisica.setCdDoctoIdent(dados.getNumeroRG() == null || dados.getNumeroRG().isEmpty() ? null : dados.getNumeroRG());
		fisica.setDtEmissDocto(dados.getDataExpedicao() == null ? null : new Date(dados.getDataExpedicao().getTime()));
		fisica.setDtNascm(dados.getDataNascimentoCliente() == null ? null : new Date(dados.getDataNascimentoCliente().getTime()));
		fisica.setCdEscol(dados.getEscolaridade());
		fisica.setCdOrgaoEmsorDocto(dados.getOrgaoEmissor());
		fisica.setCdProfs(dados.getProfissao());
		fisica.setFxRendaMensl(dados.getRenda());
		fisica.setNrCpf(cotacao.getNumeroCNPJCPFSegurado());
		fisica.setPep(dados.getIdSeguradoPEP() != null ? dados.getIdSeguradoPEP().getId() : null);
		fisica.setTpEstadCivil(dados.getEstadoCivil());
		fisica.setTpNatrzDocto(dados.getTipoDocumento());
		if(cotacao.getIdTipoSexo() == null) {
			fisica.setTpSexo(null);	
		} else {
			fisica.setTpSexo(cotacao.getIdTipoSexo().equals(SexoEnum.FEMININO) ? "F" : "M");	
		}
		
		fisica.setIcEtrge(dados.getEstrangeiro() != null ? dados.getEstrangeiro().getId() : null);
		fisica.setIcRne(dados.getPossuiRNE() != null ? dados.getPossuiRNE().getId() : null);
		if(dados.getNumeroRNE() == null || dados.getNumeroRNE().isEmpty()){
			fisica.setNrRne(null);
		} else {
			fisica.setNrRne(dados.getNumeroRNE());	
			fisica.setCdDoctoIdent(dados.getNumeroRNE());
		}
		
		fisica.setNrPassp(dados.getNumeroPassaporte() == null || dados.getNumeroPassaporte().isEmpty() ? null : dados.getNumeroPassaporte());
		fisica.setNmPaisEmissPassp(dados.getSiglaPais() == null || dados.getSiglaPais().isEmpty() ? null : dados.getSiglaPais());
		
		request.setFisica(fisica);
		request.setJuridica(null);
	}

	private void preencherEndereco(Cotacao cotacao, ClienteRequest request) {
		if(cotacao.getIdCEPSegurado() != null && cotacao.getIdCEPSegurado() > 0) {
			ClienteEndereco endereco = new ClienteEndereco();
			endereco.setNrCep(cotacao.getIdCEPSegurado());
			endereco.setNmLogra(StringUtils.defaultIfBlank(cotacao.getEnderecoSegurado(),null));
			endereco.setNrLogra(cotacao.getNumeroEnderecoSegurado() != null && cotacao.getNumeroEnderecoSegurado() > 0 ? cotacao.getNumeroEnderecoSegurado().toString() : "0");
			if(cotacao.getNomeComplementoEnderecoSegurado() != null && !cotacao.getNomeComplementoEnderecoSegurado().isEmpty()){
				tratarComplementoLogradouro(cotacao, endereco);
			}
			endereco.setNmBairr(StringUtils.defaultIfBlank(cotacao.getNomeBairroSegurado(),null));
			endereco.setNmCidad(StringUtils.defaultIfBlank(cotacao.getNomeMunicipioSegurado(),null));
			endereco.setSgUniddFedrc(StringUtils.defaultIfBlank(cotacao.getIdUFSegurado(),null));
			request.setEndereco(endereco);
		}
	}
	
	private void tratarComplementoLogradouro(Cotacao cotacao, ClienteEndereco endereco) {
		if(cotacao.getNomeComplementoEnderecoSegurado().length() <= 15){
			endereco.setDsCmploLogra(cotacao.getNomeComplementoEnderecoSegurado());
		} else {
			endereco.setDsCmploLogra(StringUtils.substring(cotacao.getNomeComplementoEnderecoSegurado(), 0, 15));	
		}
	}

	private void preencherEmail(Cotacao cotacao, ClienteRequest request) {
		if(!StringUtils.isBlank(cotacao.getIdEmailSegurado())) {
			ClienteContato email = new ClienteContato();
			email.setDtUltmaAlter(new Date());
			email.setNrRamal(null);
			email.setContato(cotacao.getIdEmailSegurado().toUpperCase());		
			request.setEmail(email);
		}
	}

	private void preencherCelular(Cotacao cotacao, ClienteRequest request) {
		if (cotacao.getNumeroDDDCelularSegurado() != null && cotacao.getNumeroDDDCelularSegurado() > 0 
				&& cotacao.getNumeroCelularSegurado() != null && cotacao.getNumeroCelularSegurado() > 0){
			ClienteContato celular = new ClienteContato();
			celular.setContato(StringUtil.formataTelefone(cotacao.getNumeroDDDCelularSegurado().longValue(),
					cotacao.getNumeroCelularSegurado()));
			celular.setDtUltmaAlter(new Date());
			celular.setNrRamal(null);
			request.setCelular(celular);
		}
	}

	public void populaDadosCliente(PropostaView proposta, Cotacao cotacao, ClienteDados clienteDados) {
		if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			clienteDados.setEscolaridade(proposta.getCotacao().getEscolaridade());
			clienteDados.setEstadoCivil(proposta.getCotacao().getIdEstadoCivil().getId());
			clienteDados.setOrgaoEmissor(proposta.getCotacao().getNomeOrgaoExpedidor());
			clienteDados.setTipoDocumento(proposta.getCotacao().getTipoDocumento());
			clienteDados.setNumeroRG(proposta.getCotacao().getNumeroRG());
			clienteDados.setDataExpedicao(proposta.getCotacao().getDataExpedicao());
			clienteDados.setDataNascimentoCliente(proposta.getCotacao().getDataNascimentoCliente());
			
			clienteDados.setProfissao(proposta.getCotacao().getIdProfissao().longValue());
			clienteDados.setRenda(proposta.getCotacao().getIdRenda().longValue());
			
			clienteDados.setIdSeguradoPEP(proposta.getCotacao().getIdSeguradoPEP());
			clienteDados.setEstrangeiro(proposta.getCotacao().getEstrangeiro());
			clienteDados.setPossuiRNE(proposta.getCotacao().getPossuiRNE());
			clienteDados.setNumeroRNE(proposta.getCotacao().getNumeroRNE());
			clienteDados.setNumeroPassaporte(proposta.getCotacao().getNumeroPassaporte());
			clienteDados.setSiglaPais(proposta.getCotacao().getSiglaPais());
		} else {
			clienteDados.setExisteControlador(proposta.getCotacao().getControlador());
			clienteDados.setQuantidadeControlador(proposta.getCotacao().getQuantidadeControlador());
			clienteDados.setRamoAtividade(proposta.getCotacao().getRamoAtividade());
			clienteDados.setTipoEmpresa(proposta.getCotacao().getTipoEmpresa());
			clienteDados.setPatrimonioLiquido(proposta.getCotacao().getPatrimonioLiquido());
			clienteDados.setReceita(proposta.getCotacao().getReceita());
		}
		
		Boolean isAlteracaoCadastralComAlteracaoPagamento = endossoAlteracaoCadastralTdoService.isAlteracaoCadastralComAlteracaoPagamento(proposta, cotacao);
		Boolean isAlteracaoCadastralPagamentoDebito = isAlteracaoCadastralComAlteracaoPagamento && proposta.getCotacao().getFormaPagamentoAlteracao().equals(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo());
		Boolean isAlteracaoCadastralPagamentoCredito = isAlteracaoCadastralComAlteracaoPagamento && proposta.getCotacao().getFormaPagamentoAlteracao().equals(FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo());
		if(proposta.isDebitoEmConta() || isAlteracaoCadastralPagamentoDebito) {	
			clienteDados.getDadosPagamento().setTipoPessoaTitularContaCorrenteDebito(proposta.getCotacao().getTipoPessoaTitularContaCorrenteDebito());
			clienteDados.getDadosPagamento().setNometitularContaCorrenteDebito(proposta.getCotacao().getNometitularContaCorrenteDebito());
			clienteDados.getDadosPagamento().setNumeroCNPJCPFTitularContaCorrenteDebito(proposta.getCotacao().getNumeroCNPJCPFTitularContaCorrenteDebito());
			//se NÃO for alteração cadastral OU (for alteração cadastral) houver mudança na forma de pagamento, então preenche 
			if(isAlteracaoCadastralPagamentoDebito) {
				clienteDados.getDadosPagamento().setPrimeiraParcelaDebito(parcelamentoApoliceService.isPrimeiraParcelaPendente(cotacao) ? SimNaoEnum.SIM : SimNaoEnum.NAO);
					
			} else { 
				clienteDados.getDadosPagamento().setPrimeiraParcelaDebito(proposta.getCotacao().getPrimeiraParcelaDebito());
			}
						
		} 
		
		if(isAlteracaoCadastralPagamentoCredito) {
			clienteDados.getDadosPagamento().setPagamentoCartaoCredito(SimNaoEnum.SIM);
		}
	}

	public void populaDadosClienteWS(Cotacao cotacao, ClienteDados clienteDados, OpcaoParcelamento opcaoParcelamento, BancoDebitoRequest bancoDebitoRequest) {
		if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			clienteDados.setEstadoCivil(cotacao.getIdEstadoCivil().getId());
			clienteDados.setOrgaoEmissor(cotacao.getNomeOrgaoExpedidor());
			clienteDados.setTipoDocumento("01");
			clienteDados.setNumeroRG(cotacao.getNumeroRG());
			clienteDados.setDataExpedicao(cotacao.getDataExpedicao());
			clienteDados.setDataNascimentoCliente(cotacao.getDataNascimentoCliente());
			
			clienteDados.setProfissao(cotacao.getIdProfissao() != null ? cotacao.getIdProfissao().longValue(): 999999l);
			clienteDados.setRenda(cotacao.getIdRenda().longValue());
			
			clienteDados.setIdSeguradoPEP(cotacao.getIdSeguradoPEP());
			clienteDados.setEstrangeiro(cotacao.getEstrangeiro());
			clienteDados.setPossuiRNE(cotacao.getPossuiRNE());
			clienteDados.setNumeroRNE(cotacao.getNumeroRNE());
			clienteDados.setNumeroPassaporte(cotacao.getNumeroPassaporte());
			clienteDados.setSiglaPais("PT");
		} else {
			clienteDados.setRamoAtividade(96L);
			clienteDados.setPatrimonioLiquido(1L);
			clienteDados.setReceita(1L);
		}

		if(opcaoParcelamento.getCodigoFormaPagamento() == 6) {
			clienteDados.getDadosPagamento().setTipoPessoaTitularContaCorrenteDebito(TipoSeguradoEnum.getById(bancoDebitoRequest.getTipoTitular()));
			clienteDados.getDadosPagamento().setNometitularContaCorrenteDebito(bancoDebitoRequest.getNomeTitular());
			clienteDados.getDadosPagamento().setNumeroCNPJCPFTitularContaCorrenteDebito(bancoDebitoRequest.getCpfCnpjTitular());
			if(bancoDebitoRequest.getParentesco() == 10) {
				clienteDados.getDadosPagamento().setNometitularContaCorrenteDebito(cotacao.getNomeSegurado());
				clienteDados.getDadosPagamento().setNumeroCNPJCPFTitularContaCorrenteDebito(cotacao.getNumeroCNPJCPFSegurado());
				clienteDados.getDadosPagamento().setTipoPessoaTitularContaCorrenteDebito(cotacao.getIdTipoPessoa());
			}
			clienteDados.getDadosPagamento().setPrimeiraParcelaDebito(SimNaoEnum.SIM);
		}

//		if(isAlteracaoCadastralPagamentoCredito) {
//			clienteDados.getDadosPagamento().setPagamentoCartaoCredito(SimNaoEnum.SIM);
//		}
	}

	public void populaDadosClienteWSFinal(Cotacao cotacao, ClienteDados clienteDados, OpcaoParcelamento opcaoParcelamento, BancoDebitoRequest bancoDebitoRequest) {
		if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			clienteDados.setEstadoCivil(cotacao.getIdEstadoCivil().getId());
			clienteDados.setOrgaoEmissor(cotacao.getNomeOrgaoExpedidor());
			clienteDados.setTipoDocumento("01");
			clienteDados.setNumeroRG(cotacao.getNumeroRG());
			clienteDados.setDataExpedicao(cotacao.getDataExpedicao());
			clienteDados.setDataNascimentoCliente(cotacao.getDataNascimentoCliente());
			
			clienteDados.setProfissao(cotacao.getIdProfissao().longValue());
			clienteDados.setRenda(cotacao.getIdRenda().longValue());
			
			clienteDados.setIdSeguradoPEP(cotacao.getIdSeguradoPEP());
			clienteDados.setEstrangeiro(cotacao.getEstrangeiro());
			clienteDados.setPossuiRNE(cotacao.getPossuiRNE());
			clienteDados.setNumeroRNE(cotacao.getNumeroRNE());
			clienteDados.setNumeroPassaporte(cotacao.getNumeroPassaporte());
			clienteDados.setSiglaPais("PT");
		} else {
			clienteDados.setRamoAtividade(96L);
			clienteDados.setPatrimonioLiquido(1L);
			clienteDados.setReceita(1L);
		}

		if(opcaoParcelamento.getCodigoFormaPagamento() == 6) {
			clienteDados.getDadosPagamento().setTipoPessoaTitularContaCorrenteDebito(TipoSeguradoEnum.getById(bancoDebitoRequest.getTipoTitular()));
			clienteDados.getDadosPagamento().setNometitularContaCorrenteDebito(bancoDebitoRequest.getNomeTitular());
			clienteDados.getDadosPagamento().setNumeroCNPJCPFTitularContaCorrenteDebito(bancoDebitoRequest.getCpfCnpjTitular());
			if(bancoDebitoRequest.getParentesco() == 10) {
				clienteDados.getDadosPagamento().setNometitularContaCorrenteDebito(cotacao.getNomeSegurado());
				clienteDados.getDadosPagamento().setNumeroCNPJCPFTitularContaCorrenteDebito(cotacao.getNumeroCNPJCPFSegurado());
				clienteDados.getDadosPagamento().setTipoPessoaTitularContaCorrenteDebito(cotacao.getIdTipoPessoa());
			}
			clienteDados.getDadosPagamento().setPrimeiraParcelaDebito(SimNaoEnum.SIM);
		}

//		if(isAlteracaoCadastralPagamentoCredito) {
//			clienteDados.getDadosPagamento().setPagamentoCartaoCredito(SimNaoEnum.SIM);
//		}
	}
}
