package br.com.tokiomarine.ctpj.infra.repository;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ParametrosGeral;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;

@Repository
public class ParametrosGeralRepository extends BaseDAO{

	private static final Logger logger = LogManager.getLogger(ParametrosGeralRepository.class);

	public ParametrosGeral getParametroGeralByNome(ParametroGeralEnum nomeParametro) throws HibernateException{
		ParametrosGeral parametro = null;
		try {
			Query query = getCurrentSession().createQuery(" SELECT	p FROM ParametrosGeral p "
														+ "	where	p.nomeParametro = :nomeParametro ");
			query.setParameter("nomeParametro",nomeParametro.name());

			parametro = (ParametrosGeral) query.uniqueResult();

		} catch (Exception e) {
			logger.error("Erro ao Buscar Parametro Geral nomeParametro:  "+nomeParametro.name(),e);
			throw new HibernateException("Erro ao Buscar Parametro Geral nomeParametro:  "+nomeParametro.name(),e);
		}
		return parametro;
	}
	
	/**
	 * Recupera os parâmetros da fila2 do ActiveMQ
	 * 
	 * @param activeMQProdutor
	 * @param activeMQUser
	 * @param activeMQPassword
	 * @param activeMQConsumidor1
	 * @param activeMQConsumidor2
	 * @param activeMQConsumidor3
	 * @return uma lista contendo objetos {@link ParametrosGeral} relacionados aos dados da fila JMS do ActiveMQ
	 */
	@SuppressWarnings("unchecked")
	public List<ParametrosGeral> getParametrosActiveMQFila2(String activeMQProdutor, String activeMQUser, String activeMQPassword, String activeMQConsumidor1, String activeMQConsumidor2, String activeMQConsumidor3){
		String hql = new StringBuilder()
		.append("SELECT c FROM ParametrosGeral c ")
		.append("where c.nomeParametro = :produtor ")
		.append("or c.nomeParametro = :user ")
		.append("or c.nomeParametro = :senha ")
		.append("or	c.nomeParametro = :consumidor1 ")
		.append("or	c.nomeParametro = :consumidor2 ")
		.append("or	c.nomeParametro = :consumidor3")
		.toString();
		
		return getCurrentSession().createQuery(hql)
		.setParameter("produtor", activeMQProdutor)
		.setParameter("user", activeMQUser)
		.setParameter("senha", activeMQPassword)
		.setParameter("consumidor1", activeMQConsumidor1)
		.setParameter("consumidor2", activeMQConsumidor2)
		.setParameter("consumidor3", activeMQConsumidor3)
		.list();
	}

}
