package br.com.tokiomarine.ctpj.auth.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.service.EntradaCadastroCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.controller.AbstractController;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.sct.response.EntradaCadastroCotacaoResponse;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Controller
public class EntradaCadastroCotacaoController extends AbstractController {
	
	private static final Logger logger = Logger.getLogger(EntradaCadastroCotacaoController.class);
	
	@Autowired
	private EntradaCadastroCotacaoService entradaCadastroCotacaoService;
	
	/**
	 * - Entrada via SCT para cadastrar uma cotação para o Corretor
	 */
	
	@LogPerformance
	@GetMapping("/rest/tokenCadastroCotacao")
	@ResponseBody
	public ResponseEntity<EntradaCadastroCotacaoResponse> tokenCadastroCotacao(@RequestParam(name="token")String token,@RequestParam(name="cdUsuro")Long cdUsuro,
			@RequestParam(name="cdGrp")Long cdGrp, HttpServletRequest request) {
		
		EntradaCadastroCotacaoResponse response = new EntradaCadastroCotacaoResponse();
		
		try{
			
			logger.info("################# ENTRADA CADASTRO DE COTAÇÃO SCT ###########################");
			logger.info("Token..:	"+ token);
			logger.info("cdGrp..:	"+ cdUsuro);
			logger.info("cdUsuro:	"+ cdGrp);
			
			response = entradaCadastroCotacaoService.processaTokenCadastroCotacao(token,cdUsuro,cdGrp, request);
			
			
			logger.info("Response entrada cadastro cotação");
			logger.info(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
			
		}catch (Exception e) {
			logger.error("Erro na entrada para o SCT cadadstro de cotação",e);
			response.setSucesso(false);
			List<Mensagem> mensagens = super.getMensagemErro(e);
			response.getMensagens().addAll(mensagens);
		}
		
		return new ResponseEntity<EntradaCadastroCotacaoResponse>(response,HttpStatus.OK);
		
	}
}
