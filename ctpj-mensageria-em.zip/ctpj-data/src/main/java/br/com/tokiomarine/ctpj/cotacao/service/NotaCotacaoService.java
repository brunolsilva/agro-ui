package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemNotaView;
import br.com.tokiomarine.ctpj.cotacao.dto.NotaCotacaoEIemForm;
import br.com.tokiomarine.ctpj.cotacao.dto.NotaCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.NotaCotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.ItemNotaViewMapper;
import br.com.tokiomarine.ctpj.mapper.NotaViewMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.StringUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class NotaCotacaoService {

	private static Logger logger = LogManager.getLogger(NotaCotacaoService.class);

	@Autowired
	private NotaCotacaoRepository repository;

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	private static final String ERRO_GERAL_SALVAR_NOTA = "Erro Geral ao Salvar Nota ";

	@LogPerformance
	public List<ItemNotaView> getListItensNotaView(List<ItemCotacao> itensCotacao,BigInteger numeroItem) throws ServiceException {

		List<ItemNotaView> itensNotaView = new ArrayList<>();

		try {
			if (itensCotacao != null && !itensCotacao.isEmpty()) {

				for (Iterator<ItemCotacao> itemCotacaoIterator = itensCotacao.iterator() ; itemCotacaoIterator.hasNext() ;) {
					ItemCotacao itemCotacao = itemCotacaoIterator.next();

					if (itemCotacao.getNumeroItem().equals(numeroItem) && itemCotacao.getListItemNota() != null && !itemCotacao.getListItemNota().isEmpty()) {
							itensNotaView = ItemNotaViewMapper.INSTANCE.toItensNotaView(itemCotacao.getListItemNota());
							break;
						
					}

				}

			}
		} catch (Exception e) {
			logger.error("Erro ao fazer bind para ItemNotaView",e);
			throw new ServiceException(e.getMessage(),e.getCause());
		}
		finally {
			if(itensNotaView != null && !itensNotaView.isEmpty()) {
				itensNotaView.sort(Comparator.comparing(ItemNotaView::getCodigoSequencia));
			}
		}
		
		return itensNotaView;

	}

	@LogPerformance
	public List<NotaCotacaoView> getListNotaCotacaoView(Cotacao cotacao) throws ServiceException {

		List<NotaCotacaoView> notasCotacaoView = new ArrayList<>();

		try {
			if (cotacao.getListNotaCotacao() != null && !cotacao.getListNotaCotacao().isEmpty()) {

				notasCotacaoView = NotaViewMapper.INSTANCE.toNotasCotacaoView(cotacao.getListNotaCotacao());

			}
		} catch (Exception e) {
			logger.error("Erro ao fazer bind para Nota Cotacao view",e);
			throw new ServiceException(e.getMessage(),e.getCause());
		}
		finally {
			if(notasCotacaoView != null && !notasCotacaoView.isEmpty()) {
				notasCotacaoView.sort(Comparator.comparing(NotaCotacaoView::getSequencialNotaControle));
			}
		}

		return notasCotacaoView;

	}

	@LogPerformance
	public List<ItemNotaView> getListItensNotaView(ItemCotacao itemCotacao) throws ServiceException {

		List<ItemNotaView> itensNotaView = new ArrayList<>();

		try {
			if (itemCotacao.getListItemNota() != null && !itemCotacao.getListItemNota().isEmpty()) {
				itensNotaView = ItemNotaViewMapper.INSTANCE.toItensNotaView(itemCotacao.getListItemNota());
			}

		} catch (

		Exception e) {
			logger.error("Erro ao fazer bind para ItemNotaView",e);
			throw new ServiceException(e.getMessage(),e.getCause());
		}
		finally {
			if(itensNotaView != null && !itensNotaView.isEmpty()) {
				itensNotaView.sort(Comparator.comparing(ItemNotaView::getCodigoSequencia));
			}
		}

		return itensNotaView;

	}

	@LogPerformance
	public void deleteNotaCotacao(BigInteger sequencialNotaCotacao,boolean isItem) throws ServiceException {

		try {
			if (isItem) {
				repository.deleteItemNotaCotacao(sequencialNotaCotacao);
			} else {
				repository.deleteNotaCotacao(sequencialNotaCotacao);
			}
		} catch (HibernateException h) {
			logger.error("Erro ao Deletar Nota ",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao Deletar Nota ",e);
			throw new ServiceException("Erro Geral ao Deletar Nota ",e);
		}

	}

	@LogPerformance
	public void saveNota(NotaCotacaoEIemForm form,boolean isItem) throws ServiceException {

		try {

			User user = SecurityUtils.getCurrentUser();

			if (isItem) {
				saveNotaItem(form, user);
			} else {
				saveNotaCotacao(form, user);
			}
		} catch (HibernateException h) {
			logger.error("Erro ao Salvar Nota ",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error(ERRO_GERAL_SALVAR_NOTA,e);
			throw new ServiceException(ERRO_GERAL_SALVAR_NOTA,e);
		}

	}

	private void saveNotaCotacao(NotaCotacaoEIemForm form, User user) {
		Cotacao cotacao = cotacaoRepository.findCotacaoNotas(form.getNota().getNumeroCotacaoProposta(),form.getNota().getVersaoCotacaoProposta());

		NotaCotacao notaCotacao;

		if (cotacao.getListNotaCotacao() != null && !cotacao.getListNotaCotacao().isEmpty()) {

			notaCotacao = NotaViewMapper.INSTANCE.toNotaCotacao(form.getNota());
			notaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			notaCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			notaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			notaCotacao.setNota(StringUtil.replaceAspas(form.getNota().getNota()));
			notaCotacao.setCotacao(cotacao);
			notaCotacao.setSequencialNotaControle(repository.getNrNotaCotacao(notaCotacao.getNumeroCotacaoProposta(),notaCotacao.getVersaoCotacaoProposta()));
			cotacao.getListNotaCotacao().add(notaCotacao);

		} else {

			List<NotaCotacao> listNotaCotacao = new ArrayList<>();

			notaCotacao = NotaViewMapper.INSTANCE.toNotaCotacao(form.getNota());
			notaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			notaCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			notaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			notaCotacao.setNota(StringUtil.replaceAspas(form.getNota().getNota()));
			notaCotacao.setSequencialNotaControle(1);
			notaCotacao.setCotacao(cotacao);
			listNotaCotacao.add(notaCotacao);
			cotacao.setListNotaCotacao(listNotaCotacao);

		}
		cotacaoRepository.save(cotacao);
	}

	private void saveNotaItem(NotaCotacaoEIemForm form, User user) {
		ItemCotacao itemCotacao = cotacaoRepository.findItensCotacaoAndItemNotaBySequencialItemCotacao(form.getItemNota().getSequencialItemCotacao());
		if(itemCotacao.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || Arrays.asList(1,6).contains(itemCotacao.getIdTipoEndosso())) {
			ItemNota itemNota;

			if (itemCotacao.getListItemNota() != null && !itemCotacao.getListItemNota().isEmpty()) {
				itemNota = ItemNotaViewMapper.INSTANCE.toItemNota(form.getItemNota());
				itemNota.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				itemNota.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				itemNota.setDataAtualizacao(Calendar.getInstance().getTime());
				itemNota.setDescricaoNota(StringUtil.replaceAspas(form.getItemNota().getDescricaoNota()));
				itemNota.setItemCotacao(itemCotacao);
				itemNota.setCodigoSequencia(repository.getNrItemNotaCotacao(itemNota.getNumeroCotacaoProposta(),itemNota.getVersaoCotacaoProposta()));
				itemCotacao.getListItemNota().add(itemNota);
			} else {

				List<ItemNota> listItemNota = new ArrayList<>();

				itemNota = ItemNotaViewMapper.INSTANCE.toItemNota(form.getItemNota());
				itemNota.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				itemNota.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				itemNota.setDataAtualizacao(Calendar.getInstance().getTime());
				itemNota.setDescricaoNota(StringUtil.replaceAspas(form.getItemNota().getDescricaoNota()));
				itemNota.setItemCotacao(itemCotacao);
				itemNota.setCodigoSequencia(repository.getNrItemNotaCotacao(itemNota.getNumeroCotacaoProposta(),itemNota.getVersaoCotacaoProposta()));
				listItemNota.add(itemNota);
				itemCotacao.setListItemNota(listItemNota);
			}

			cotacaoRepository.save(itemCotacao);
		}
	}

	@LogPerformance
	public void atualizarNota(NotaCotacaoEIemForm form,boolean isItem) throws ServiceException {

		try {

			User user = SecurityUtils.getCurrentUser();

			if (isItem) {
				ItemNota itemNota = repository.findItemNotaBySequencialItemNota(form.getItemNota().getSequencialItemNota());
				itemNota.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				itemNota.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				itemNota.setDataAtualizacao(Calendar.getInstance().getTime());
				itemNota.setDescricaoNota(StringUtil.replaceAspas(form.getItemNota().getDescricaoNota()));

				repository.atualizaItemNota(itemNota);
			} else {

				NotaCotacao notaCotacao = repository.findNotaCotacaBySequencialNotaCotacao(form.getNota().getSequencialNotaCotacao());

				notaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				notaCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				notaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
				notaCotacao.setNota(form.getNota().getNota());
				repository.atualizaNotaCotacao(notaCotacao);
			}
		} catch (HibernateException h) {
			logger.error("Erro ao Salvar Nota ",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error(ERRO_GERAL_SALVAR_NOTA,e);
			throw new ServiceException(ERRO_GERAL_SALVAR_NOTA,e);
		}

	}

}
