package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.componente.utils.DateUtil;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.TaxaIOF;

@Repository
public class TaxaIOFRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public TaxaIOF findTaxaIOF(Integer codigoGrupoRamo, Integer codigoRamo, Date dataInicioVigencia )  throws RepositoryException {
		TaxaIOF taxaIOF = null;
		try{
			taxaIOF = mongoTemplate.findOne(
					query(
							where("codigoGrupoRamo").is(codigoGrupoRamo)
								.and("codigoRamo").is(codigoRamo)
								.and("dataInicioVigencia").lte(dataInicioVigencia)
								.orOperator(
										where("dataTerminoVigencia").gte(new Date()),
										where("dataTerminoVigencia").is(null))),
					TaxaIOF.class); 
		}catch(Exception e ){
			throw new RepositoryException("Erro ao buscar Taxa IOF grupoRamo "+codigoGrupoRamo+", ramo"+codigoRamo+" e "+DateUtil.formataCompleta(dataInicioVigencia),e);
		}
		return taxaIOF; 
	}

	
}
