package br.com.tokiomarine.ctpj.cotacao.relatorios;

public class RelatorioException extends Exception {
	private static final long serialVersionUID = 1L;

	public RelatorioException() {
		super();		
	}

	public RelatorioException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);		
	}

	public RelatorioException(String message, Throwable cause) {
		super(message, cause);		
	}

	public RelatorioException(String message) {
		super(message);		
	}

	public RelatorioException(Throwable cause) {
		super(cause);		
	}	

}
