package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

public class CartaoView implements Serializable {

	private static final long serialVersionUID = 7977686994072017464L;

	private BigInteger cotacao;
	private String numeroCartao;
	private String tipoTitular;
	private String documento;
	private String nomeTitular;
	private String bandeira;
	private Integer mesValidade;
	private Integer anoValidade;
	private Integer diaFatura;
	private String token;

	public BigInteger getCotacao() {
		return cotacao;
	}

	public void setCotacao(BigInteger cotacao) {
		this.cotacao = cotacao;
	}

	public String getNumeroCartao() {
		return numeroCartao;
	}

	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	public String getTipoTitular() {
		return tipoTitular;
	}

	public void setTipoTitular(String tipoTitular) {
		this.tipoTitular = tipoTitular;
	}

	public String getBandeira() {
		return bandeira;
	}

	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	public Integer getMesValidade() {
		return mesValidade;
	}

	public void setMesValidade(Integer mesValidade) {
		this.mesValidade = mesValidade;
	}

	public Integer getAnoValidade() {
		return anoValidade;
	}

	public void setAnoValidade(Integer anoValidade) {
		this.anoValidade = anoValidade;
	}

	public String getNomeTitular() {
		return nomeTitular;
	}

	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}
	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	public Integer getDiaFatura() {
		return diaFatura;
	}

	public void setDiaFatura(Integer diaFatura) {
		this.diaFatura = diaFatura;
	}

	@Override
	public String toString() {
		return "CartaoView [cotacao=" + cotacao + ", tipoTitular=" + tipoTitular
				+ ", bandeira=" + bandeira + ", mesValidade=" + mesValidade + ", anoValidade=" + anoValidade + "]";
	}
}