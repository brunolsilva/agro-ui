package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

public class CotacaoComProduto implements Serializable {

	private static final long serialVersionUID = 9123534252810573913L;

	private BigInteger numeroCotacao;
	private Integer produto;
	private String corretor;
	private Date dataCotacao;

	public BigInteger getNumeroCotacao() {
		return numeroCotacao;
	}

	public void setNumeroCotacao(BigInteger numeroCotacao) {
		this.numeroCotacao = numeroCotacao;
	}

	public Integer getProduto() {
		return produto;
	}

	public void setProduto(Integer produto) {
		this.produto = produto;
	}

	public String getCorretor() {
		return corretor;
	}

	public void setCorretor(String corretor) {
		this.corretor = corretor;
	}

	public Date getDataCotacao() {
		return dataCotacao;
	}

	public void setDataCotacao(Date dataCotacao) {
		this.dataCotacao = dataCotacao;
	}

	@Override
	public String toString() {
		return "CotacaoComProduto [numeroCotacao=" + numeroCotacao + ", produto=" + produto + ", corretor=" + corretor
				+ "]";
	}
}
