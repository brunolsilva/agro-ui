
package br.com.tokiomarine.ctpj.integracao.dadosconta;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.com.tokiomarine.ctpj.integracao.dadosconta package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _InfoAgencia_QNAME = new QName("http://consulta.feb.seguradora.tokiomarine.com.br/", "infoAgencia");
    private final static QName _InfoAgenciaResponse_QNAME = new QName("http://consulta.feb.seguradora.tokiomarine.com.br/", "infoAgenciaResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.tokiomarine.ctpj.integracao.dadosconta
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InfoAgencia }
     * 
     */
    public InfoAgencia createInfoAgencia() {
        return new InfoAgencia();
    }

    /**
     * Create an instance of {@link InfoAgenciaResponse }
     * 
     */
    public InfoAgenciaResponse createInfoAgenciaResponse() {
        return new InfoAgenciaResponse();
    }

    /**
     * Create an instance of {@link AgenciaVO }
     * 
     */
    public AgenciaVO createConsultaVO() {
        return new AgenciaVO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InfoAgencia }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://consulta.feb.seguradora.tokiomarine.com.br/", name = "infoAgencia")
    public JAXBElement<InfoAgencia> createInfoAgencia(InfoAgencia value) {
        return new JAXBElement<InfoAgencia>(_InfoAgencia_QNAME, InfoAgencia.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InfoAgenciaResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://consulta.feb.seguradora.tokiomarine.com.br/", name = "infoAgenciaResponse")
    public JAXBElement<InfoAgenciaResponse> createInfoAgenciaResponse(InfoAgenciaResponse value) {
        return new JAXBElement<InfoAgenciaResponse>(_InfoAgenciaResponse_QNAME, InfoAgenciaResponse.class, null, value);
    }

}
