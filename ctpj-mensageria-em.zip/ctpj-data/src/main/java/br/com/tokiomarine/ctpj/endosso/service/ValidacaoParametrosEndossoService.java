package br.com.tokiomarine.ctpj.endosso.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.util.AssertUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Service
public class ValidacaoParametrosEndossoService {
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	public final String MENSAGEM_ALTERADO_PARA = " alterado(a) p/ " ;
	
	public void compararParametrosEndosso(Long parametro1, Long parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
	
	public void compararParametrosEndosso(BigDecimal parametro1, BigDecimal parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!BigDecimalUtil.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
	
	public void compararParametrosTelefone(Integer dddTelefone1, Long numeroTelefone1, Integer dddTelefone2, Long numeroTelefone2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(dddTelefone1, dddTelefone2) || !AssertUtils.compareNull(numeroTelefone1, numeroTelefone2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append("("+dddTelefone1+")"+numeroTelefone1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append("("+dddTelefone2+")"+numeroTelefone2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
	
	public void compararParametrosEndosso(String parametro1, String parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	public void compararParametrosEndossoSemDePara(String parametro1, String parametro2, TipoMensagemEndossoEnum tipoMensagem, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, "", user));
		}		
	}
	
	public void compararParametrosEndosso(Integer parametro1, Integer parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}

	public void compararParametrosEndosso(Date parametro1, Date parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	//métodos para itens
	public void compararParametrosItem(Long parametro1, Long parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
	
	public void compararParametrosItem(BigDecimal parametro1, BigDecimal parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!BigDecimalUtil.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
	
	public void compararParametrosItem(BigInteger parametro1, BigInteger parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
	
	
	public void compararParametrosItem(String parametro1, String parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	public void compararParametrosItemSemDePara(String parametro1, String parametro2, TipoMensagemEndossoEnum tipoMensagem, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, "", user));
		}		
	}
	
	public void compararParametrosItem(Integer parametro1, Integer parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}

	public void compararParametrosItem(Date parametro1, Date parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	
	//métodos para coberturas
	public void compararParametrosCobertura(String parametro1, String parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	//métodos para coberturas
	public void compararParametrosCoberturaSemDePara(String parametro1, String parametro2,String descricaoCampo, TipoMensagemEndossoEnum tipoMensagem, Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, tipoMensagem, descricaoCampo, user));
		}		
	}
	
	public void compararParametrosCobertura(Integer parametro1, Integer parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	public void compararParametrosCobertura(Long parametro1, Long parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	public void compararParametrosCobertura(BigDecimal parametro1, BigDecimal parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!BigDecimalUtil.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
	
	public void compararParametrosCobertura(BigInteger parametro1, BigInteger parametro2, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemCobertura,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(MENSAGEM_ALTERADO_PARA);
			descricaoAlteracao.append(parametro2);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
		}		
	}
}
