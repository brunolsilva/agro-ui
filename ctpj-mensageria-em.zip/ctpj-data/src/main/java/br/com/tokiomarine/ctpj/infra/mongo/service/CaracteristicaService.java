package br.com.tokiomarine.ctpj.infra.mongo.service;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.infra.domain.AgrupamentoAtividade;
import br.com.tokiomarine.ctpj.infra.domain.AtividadeSegurado;
import br.com.tokiomarine.ctpj.infra.domain.CaracteristicaValor;
import br.com.tokiomarine.ctpj.infra.domain.CoberturaBemCoberto;
import br.com.tokiomarine.ctpj.infra.domain.CompanhiaSeguradora;
import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristicaValor;
import br.com.tokiomarine.ctpj.infra.domain.UF;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CaracteristicaValorRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CompanhiaSeguradoraRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CorretorRepository;
import br.com.tokiomarine.ctpj.mapper.ProdutoValorCaracteristicaMapper;

@Service
public class CaracteristicaService {

	@Autowired
	private MongoTemplate template;

	@Autowired
	private CaracteristicaValorRepository caracteristicaValorRepository;

	@Autowired
	private CompanhiaSeguradoraRepository companhiaSeguradoraRepository;

	@Autowired
	private CorretorRepository corretorRepository;

	public List<ProdutoValorCarac> getValoresCaracteristica(Integer codigoProduto, Integer caracteristica, Sort sort) {
		List<ProdutoCaracteristicaValor> listaProdutoValor = template.find(
				query(
						where("produto").is(codigoProduto)
							.and("caracteristica").is(caracteristica)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				), ProdutoCaracteristicaValor.class);

		List<Integer> valoresCaracteristica = listaProdutoValor
				.stream()
				.map(ProdutoCaracteristicaValor::getValorCaracteristica)
				.collect(Collectors.toList());

		List<CaracteristicaValor> listaValorCaracteristica =
				caracteristicaValorRepository.findListCaracValorByCaracAndValorCarac(caracteristica,valoresCaracteristica, sort);

		List<ProdutoValorCarac> retorno = new ArrayList<>();

		for(CaracteristicaValor valorCarac: listaValorCaracteristica) {
			retorno.add(ProdutoValorCaracteristicaMapper.INSTANCE.toProdValorCaracDTO(valorCarac, codigoProduto));
		}

		return retorno;
	}
	
	@LogPerformance
	public List<ProdutoValorCarac> findRubricasPorNome(Integer codigoProduto, Integer caracteristica, String q) {
		
		List<ProdutoCaracteristicaValor> listaProdutoValor = template.find(
				query(
						where("produto").is(codigoProduto)
							.and("caracteristica").is(caracteristica)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCaracteristicaValor.class);

		List<Integer> valoresCaracteristica = listaProdutoValor
				.stream()
				.map(ProdutoCaracteristicaValor::getValorCaracteristica)
				.collect(Collectors.toList());

		List<CaracteristicaValor> listaValorCaracteristica =
				caracteristicaValorRepository.findListCaracValorByCaracAndValorCarac(caracteristica,valoresCaracteristica,q);

		List<ProdutoValorCarac> retorno = new ArrayList<>();

		for(CaracteristicaValor valorCarac: listaValorCaracteristica) {
			retorno.add(ProdutoValorCaracteristicaMapper.INSTANCE.toProdValorCaracDTO(valorCarac, codigoProduto));
		}
		
		return retorno;
	}

	@LogPerformance
	public List<ProdutoValorCarac> findRubricas(Integer codigoProduto, Integer caracteristica, Integer nicho, Integer atividadeSegurado) {
		Query query = new Query();
		query.addCriteria(where("produto").is(codigoProduto)
				.and("caracteristica").is(caracteristica)
				.and("dataInicioVigencia").lte(new Date())
				.orOperator(
						where("dataTerminoVigencia").gte(new Date()),
						where("dataTerminoVigencia").is(null)));

		if(nicho != null) {
			query.addCriteria(where("nicho").is(nicho));
		}

		List<ProdutoCaracteristicaValor> listaProdutoValor = template.find(query, ProdutoCaracteristicaValor.class);

		List<Integer> valoresCaracteristica = listaProdutoValor
				.stream()
				.map(ProdutoCaracteristicaValor::getValorCaracteristica)
				.collect(Collectors.toList());

		List<CaracteristicaValor> listaValorCaracteristica =
				caracteristicaValorRepository.findListCaracValorByCaracAndValorCarac(caracteristica,valoresCaracteristica, new Sort(Direction.ASC, "descricaoValor"));

		List<ProdutoValorCarac> retorno = new ArrayList<>();

		for(CaracteristicaValor valorCarac: listaValorCaracteristica) {
			retorno.add(ProdutoValorCaracteristicaMapper.INSTANCE.toProdValorCaracDTO(valorCarac, codigoProduto));
		}

		if(atividadeSegurado != null) {
			List<AgrupamentoAtividade> sugestoes = template.find(query(
					where("atividadePrincipal").is(atividadeSegurado)), AgrupamentoAtividade.class);
			List<Long> s = sugestoes.stream().map(AgrupamentoAtividade::getValorCaracteristica).collect(Collectors.toList());
			for(ProdutoValorCarac p: retorno) {
				if(s.contains(p.getValorCaracteristica())) {
					p.setSugestao(true);
				}
			}

			retorno = retorno.stream().sorted(Comparator.comparing(ProdutoValorCarac::isSugestao).reversed()
					.thenComparing(ProdutoValorCarac::getDescricaoValor)).collect(Collectors.toList());
		}

		return retorno;
	}
	
	@LogPerformance
	public ProdutoCaracteristicaValor findRubricaComNicho(Integer codigoProduto, Integer caracteristica, Integer valorCaracteristica) {
		Query query = new Query();
		query.addCriteria(where("produto").is(codigoProduto)
				.and("caracteristica").is(caracteristica)
				.and("valorCaracteristica").is(valorCaracteristica)
				.and("nicho").ne(null)
				.and("dataInicioVigencia").lte(new Date())
				.orOperator(
						where("dataTerminoVigencia").gte(new Date()),
						where("dataTerminoVigencia").is(null)));
		
		return template.findOne(query, ProdutoCaracteristicaValor.class);
	}

	@LogPerformance
	//@Cacheable("atividadesSegurado")
	public List<AtividadeSegurado> findAtividades() {
		return template.find(
				query(where("situacao").is(1))
				.with(new Sort(Direction.ASC, "descricao")) ,AtividadeSegurado.class);
	}

	@LogPerformance
	//@Cacheable("ufs")
	public List<UF> findUFs() {
		return template.find(new Query().with(new Sort(Direction.ASC,"uf")), UF.class);
	}

	@LogPerformance
	//@Cacheable("ciasSeguradora")
	public List<CompanhiaSeguradora> findCiasSeguradora() {
		return companhiaSeguradoraRepository.findCiasSeguradora();
	}

	@LogPerformance
	//@Cacheable("corretores")
	public List<Corretor> findCorretores() {
		return corretorRepository.findCorretores();
	}

	@LogPerformance
	public CompanhiaSeguradora findCiaSeguradora(Integer codigo) {
		return companhiaSeguradoraRepository.findCiaSeguradoraByCodigo(codigo);
	}

	@LogPerformance
	public CaracteristicaValor getValor(Integer caracteristica,Long valorCaracteristica) {
		return caracteristicaValorRepository.findCaracteristicaValorByCaracAndValorCarac(caracteristica,valorCaracteristica);
	}
	
	@LogPerformance
	//@Cacheable("coberturaBemCoberto")
	public List<Integer> findCoberturaBemCoberto(Integer produto, Long bemCoberto) {
		CoberturaBemCoberto coberturaBemCoberto = template.findOne(
				query(
						where("bemCoberto").is(bemCoberto)
						.and("produto").is(produto)
						) ,CoberturaBemCoberto.class);
		return coberturaBemCoberto != null ? coberturaBemCoberto.getCoberturas() : Collections.emptyList();
	}

	public Map<Integer, ProdutoCaracteristica> findCaracteristicaDoProduto(Integer produto, Date dataCotacao) {
		return caracteristicaValorRepository.findCaracteristicaDoProduto(produto, dataCotacao);
	}
	
	@LogPerformance
	public List<ProdutoValorCarac> findRubricasWs(Integer codigoProduto, Integer caracteristica) {
		
		List<ProdutoCaracteristicaValor> listaProdutoValor = template.find(
				query(
						where("produto").is(codigoProduto)
							.and("caracteristica").is(caracteristica)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCaracteristicaValor.class);

		
		
		List<Integer> valoresCaracteristica = listaProdutoValor
				.stream()
				.map(ProdutoCaracteristicaValor::getValorCaracteristica)
				.collect(Collectors.toList());

		List<CaracteristicaValor> listaValorCaracteristica =
				caracteristicaValorRepository.findListCaracValorByCaracAndValorCarac(caracteristica,valoresCaracteristica, new Sort(Direction.ASC, "descricaoValor"));
		
		List<ProdutoValorCarac> retorno = new ArrayList<>();

		for(CaracteristicaValor valorCarac: listaValorCaracteristica) {
			ProdutoCaracteristicaValor pv = listaProdutoValor.stream()
					.filter(p -> valorCarac.getValorCaracteristica().equals(p.getValorCaracteristica().longValue()))
					.findFirst()
					.orElseThrow(() -> new RuntimeException("Caracteristica não encontrada " + valorCarac.getValorCaracteristica()));

			valorCarac.setIdKme(pv.getIdKme());
			retorno.add(ProdutoValorCaracteristicaMapper.INSTANCE.toProdValorCaracDTO(valorCarac, codigoProduto));
		}
		
		return retorno;
	}
	
		@LogPerformance
	public List<ProdutoValorCarac> getValoresCaracteristicaWs(Integer codigoProduto, Integer caracteristica, Sort sort) {
		
		List<ProdutoCaracteristicaValor> listaProdutoValor = template.find(
				query(
						where("produto").is(codigoProduto)
							.and("caracteristica").is(caracteristica)
							.and("dataInicioVigencia").lte(new Date())
							.and("idKme").ne(null)
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCaracteristicaValor.class);
		
		if(listaProdutoValor == null || listaProdutoValor.isEmpty()) {
			return Collections.EMPTY_LIST;
		}
		
		List<Integer> valoresCaracteristica = listaProdutoValor
				.stream()
				.map(ProdutoCaracteristicaValor::getValorCaracteristica)
				.collect(Collectors.toList());

		List<CaracteristicaValor> listaValorCaracteristica =
				caracteristicaValorRepository.findListCaracValorByCaracAndValorCarac(caracteristica,valoresCaracteristica, sort);

		List<ProdutoValorCarac> retorno = new ArrayList<>();

		for(CaracteristicaValor valorCarac: listaValorCaracteristica) {
			ProdutoCaracteristicaValor pv = listaProdutoValor.stream()
															.filter(p -> valorCarac.getValorCaracteristica().equals(p.getValorCaracteristica().longValue()))
															.findFirst()
															.orElseThrow(() -> new RuntimeException("Caracteristica não encontrada " + caracteristica));
			
			valorCarac.setIdKme(pv.getIdKme());
			retorno.add(ProdutoValorCaracteristicaMapper.INSTANCE.toProdValorCaracDTO(valorCarac, codigoProduto));
		}

		return retorno;
	}
}