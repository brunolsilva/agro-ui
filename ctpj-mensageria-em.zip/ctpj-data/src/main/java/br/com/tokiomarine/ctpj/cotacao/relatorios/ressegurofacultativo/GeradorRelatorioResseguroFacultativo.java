package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import br.com.tokiomarine.ctpj.cotacao.dto.DadosCotacaoParaResseguroFacultativo;
import br.com.tokiomarine.ctpj.cotacao.relatorios.RelatorioException;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;

public interface GeradorRelatorioResseguroFacultativo {

	byte[] gera(DadosRelatorioResseguroFacultativo dados) throws RelatorioException;

	byte[] gera(DadosCotacaoParaResseguroFacultativo dadosCotacao, ResseguroFacultativo resseguroFacultativo) throws RelatorioException;
}