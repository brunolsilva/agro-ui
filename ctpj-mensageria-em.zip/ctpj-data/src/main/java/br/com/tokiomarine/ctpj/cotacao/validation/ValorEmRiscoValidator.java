package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.infra.domain.CorretorValorRisco;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristicaValor;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CorretorRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

public class ValorEmRiscoValidator {
	
	@Autowired
	private ProdutoService produtoService;

	@Autowired
	private CorretorRepository corretorRepository;

	@Autowired
	private CaracteristicaService caracteristicaService;
	
	public ValorEmRiscoValidator() {
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}
	
	public List<ValidacaoLote> valida(Cotacao cotacao) {
		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		ProdutoCaracteristicaValor produtoCaracteristicaValor = null;
		
		Optional<ItemCotacao> primeiroItem = cotacao.getListItem()
				.stream()
				.filter(it -> it.getNumeroItem().equals(BigInteger.ONE))
				.findFirst();
		
		BigDecimal valorRiscoBemItem1 = null;
		if(primeiroItem.isPresent() && primeiroItem.get().getCodigoRubrica() != null) {
			valorRiscoBemItem1 = primeiroItem.get().getValorRiscoBem();
			produtoCaracteristicaValor = caracteristicaService.findRubricaComNicho(cotacao.getCodigoProduto(), Caracteristicas.ATIVIDADE.codigo(), primeiroItem.get().getCodigoRubrica().intValue());
		}

		if(cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {

			List<BigDecimal> valoresRiscoBem;

			if(cotacao.getCodigoMoeda() == MoedaEnum.REAL) {
				valorRiscoBemItem1 = primeiroItem.get().getValorRiscoBem();
				valoresRiscoBem = cotacao.getListItem()
						.stream()
						.filter(it -> !it.getNumeroItem().equals(BigInteger.ONE) && it.getValorRiscoBem() != null)
						.map(ItemCotacao::getValorRiscoBem)
						.collect(Collectors.toList());
			} else {
				valorRiscoBemItem1 = primeiroItem.get().getValorRiscoBemMoedaEstrangeira();
				valoresRiscoBem = cotacao.getListItem()
						.stream()
						.filter(it -> !it.getNumeroItem().equals(BigInteger.ONE) && it.getValorRiscoBemMoedaEstrangeira() != null)
						.map(ItemCotacao::getValorRiscoBemMoedaEstrangeira)
						.collect(Collectors.toList());
			}

			for(BigDecimal valor: valoresRiscoBem) {
				if(valorRiscoBemItem1 != null && BigDecimalUtil.menor(valorRiscoBemItem1,valor)) {
					listaValidacao.add(new ValidacaoLote(1, "O valor em risco do item 1 não pode ser menor que o valor em risco dos demais items"));
					break;
				}
			}
		}

		if(SecurityUtils.isCorretor()) {
			CorretorValorRisco corretorValorRisco = corretorRepository.findCorretorVR(cotacao);
			boolean valido = true;
			if(corretorValorRisco != null && valorRiscoBemItem1 != null && corretorValorRisco.getValorRiscoMinimo().compareTo(valorRiscoBemItem1) > 0) {
				listaValidacao.add(new ValidacaoLote(1, "O valor em risco do item 1 não pode ser inferior a R$50.000,00"));
				valido = false;
			}
			
			if(valido && valorRiscoBemItem1 != null && new BigDecimal("50000").compareTo(valorRiscoBemItem1) > 0 && produtoCaracteristicaValor != null) {
				listaValidacao.add(new ValidacaoLote(1, "O valor em risco do item 1 não pode ser inferior a R$50.000,00"));
				valido = false;
			}

			if(cotacao.getIdDestinoEmissao() != DestinoEmissaoEnum.ACX) {
				if(valido && corretorValorRisco == null && valorRiscoBemItem1 != null && new BigDecimal("500000").compareTo(valorRiscoBemItem1) > 0 && produtoCaracteristicaValor == null) {
					listaValidacao.add(new ValidacaoLote(1, "O valor em risco do item 1 não pode ser inferior a R$500.000,00"));
					valido = false;
				}
			}

			if(valido && corretorValorRisco == null && valorRiscoBemItem1 != null && new BigDecimal("50000").compareTo(valorRiscoBemItem1) > 0 && produtoCaracteristicaValor != null) {
				listaValidacao.add(new ValidacaoLote(1, "O valor em risco do item 1 não pode ser inferior a R$50.000,00"));
				valido = false;
			}
		}

		Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
		if(produto.getValorMaximoVR() != null) {
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				if(BigDecimalUtil.safeMenor(produto.getValorMaximoVR(), itemCotacao.getValorRiscoBemCalculado())) {
					DecimalFormat formatter = new DecimalFormat("#,##0.00", new DecimalFormatSymbols(new Locale("pt", "BR")));
					String valorMaximo = "R$ " + formatter.format(produto.getValorMaximoVR());
					listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(),
							String.format("Para Valor em Risco acima de: %s favor solicitar a cotação na opção NOVA COTAÇÃO (Anexar Arquivos) no produto: RISCOS NOMEADOS LMI ÚNICO.", 
									valorMaximo)));
				}
			}
		}

		return listaValidacao;
	}
}