package br.com.tokiomarine.ctpj.controller.rest;

import java.math.BigInteger;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.interfaceCSF.response.ResponseInterfaceCSF;
import br.com.tokiomarine.ctpj.print.service.CotacaoPrintService;
import br.com.tokiomarine.ctpj.print.service.DeclaracaoPrintService;
import br.com.tokiomarine.ctpj.print.service.PropostaPrintService;

@Controller
public class FormalizacaoController {
	
	private static Logger logger = LogManager.getLogger(FormalizacaoController.class);

	@Autowired
	private PropostaPrintService propostaPrintService;
	
	@Autowired
	private DeclaracaoPrintService declaracaoPrintService;
	
	@Autowired
	private CotacaoPrintService cotacaoPrintService;

	@LogPerformance
	@GetMapping(value = "/rest/printProposta/{sequencialCotacaoProposta}/{cdUsuro}/{cdGrp}")
	@ResponseBody
	public ResponseEntity<ResultadoREST<ResponseInterfaceCSF>> gerarImpressaoPropostaFormalizacao(
			@PathVariable BigInteger sequencialCotacaoProposta,
			@PathVariable Integer cdUsuro,
			@PathVariable Integer cdGrp){
		ResultadoREST<ResponseInterfaceCSF> responseImpresao = new ResultadoREST<ResponseInterfaceCSF>();
		try {
			logger.info("FormalizacaoController.gerarImpressaoPropostaFormalizacao.." + sequencialCotacaoProposta);
			responseImpresao = propostaPrintService.gerarImpressaoPropostaFormalizacao(sequencialCotacaoProposta,this.getUserInterface(cdUsuro,cdGrp));
		} catch (final Exception e) {
			logger.error(String.format("Erro gerar impressao da Proposta sequencial da Cotacao: [%s]  ",sequencialCotacaoProposta) + ExceptionUtils.getFullStackTrace(e));
			responseImpresao.setSuccess(false);
			responseImpresao.setThrowable(e);
		}
		return new ResponseEntity<ResultadoREST<ResponseInterfaceCSF>>(responseImpresao,HttpStatus.OK);
	}
	
	

	@LogPerformance
	@GetMapping(value = "/rest/printDeclaracao/{sequencialCotacaoProposta}/{cdUsuro}/{cdGrp}")
	@ResponseBody
	public ResponseEntity<ResultadoREST<ResponseInterfaceCSF>> gerarImpressaoDeclaracaoFormalizacao(
			@PathVariable BigInteger sequencialCotacaoProposta,
			@PathVariable Integer cdUsuro,
			@PathVariable Integer cdGrp){
		
		ResultadoREST<ResponseInterfaceCSF> responseImpresao = new ResultadoREST<ResponseInterfaceCSF>();
		try {
			logger.info("FormalizacaoController.gerarImpressaoDeclaracaoFormalizacao.." + sequencialCotacaoProposta);
			responseImpresao = declaracaoPrintService.gerarImpressaoDeclaracaoFormalizacao(sequencialCotacaoProposta,this.getUserInterface(cdUsuro,cdGrp));
		} catch (final Exception e) {
			logger.error(String.format("Erro gerar impressao da declaracao sequencial da Cotacao: [%s]  ",sequencialCotacaoProposta) + ExceptionUtils.getFullStackTrace(e));
			responseImpresao.setSuccess(false);
			responseImpresao.setThrowable(e);
		}
		return new ResponseEntity<ResultadoREST<ResponseInterfaceCSF>>(responseImpresao,HttpStatus.OK);
	}
	
	@LogPerformance
	@GetMapping(value = "/rest/printCotacao/{sequencialCotacaoProposta}/{cdUsuro}/{cdGrp}")
	@ResponseBody
	public ResponseEntity<ResultadoREST<ResponseInterfaceCSF>> gerarImpressaoCotacaoFormalizacao(
			@PathVariable BigInteger sequencialCotacaoProposta,
			@PathVariable Integer cdUsuro,
			@PathVariable Integer cdGrp){
		
		ResultadoREST<ResponseInterfaceCSF> responseImpresao = new ResultadoREST<ResponseInterfaceCSF>();
		try {
			logger.info("FormalizacaoController.gerarImpressaoCotacaoFormalizacao.." + sequencialCotacaoProposta);
			responseImpresao = cotacaoPrintService.gerarImpressaoCotacaoFormalizacao(sequencialCotacaoProposta,this.getUserInterface(cdUsuro,cdGrp));
		} catch (final Exception e) {
			logger.error(String.format("Erro gerar impressao da Cotacao sequencial da Cotacao: [%s]  ",sequencialCotacaoProposta) + ExceptionUtils.getFullStackTrace(e));
			responseImpresao.setSuccess(false);
			responseImpresao.setThrowable(e);
		}
		return new ResponseEntity<ResultadoREST<ResponseInterfaceCSF>>(responseImpresao,HttpStatus.OK);
		
	}
	
	private User getUserInterface(Integer cdUsuro,Integer cdGrp){
		User user =  new User();
		user.setCdUsuro(cdUsuro);		
		user.setGrupoUsuario(GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(cdGrp));	
		return user;
		
	}

}
