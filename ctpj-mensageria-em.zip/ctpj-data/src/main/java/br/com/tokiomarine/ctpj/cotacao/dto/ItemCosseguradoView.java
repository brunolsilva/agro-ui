package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import br.com.tokiomarine.ctpj.cotacao.validator.constraint.CpfCnpj;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.IncluirParaTodosItemCossegurado;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@IncluirParaTodosItemCossegurado(message = "Item da Cotação é obrigatório")
@CpfCnpj(cnpjKey = "J", cpfKey = "F", keyField = "tipoPessoa", valueField = "numeroCPFCNPJ", message = "CPF/CNPJ inválido")
public class ItemCosseguradoView {
	private BigInteger sequencialItemCossegurado;

	private BigInteger numeroCossegurado;

	@NotBlank(message = "Tipo de Pessoa é obrigatório")
	private String tipoPessoa;

	@NotBlank(message = "CPF/CNPJ é obrigatório")
	private String numeroCPFCNPJ;

	@NotBlank(message = "Nome da Pessoa é obrigatório")
	@Length(max = 300, message = "Nome da Pessoa deve possuir no máximo 300 caracteres")
	private String nomePessoa;

	private BigInteger itemCotacao;
	
	private Boolean incluirParaTodos = false;
	
	private BigInteger sequencialCotacaoProposta;
	
	public ItemCosseguradoView(){
		
	}

	public ItemCosseguradoView(BigInteger sequencialItemCossegurado, BigInteger numeroCossegurado, String tipoPessoa,
			String numeroCPFCNPJ, String nomePessoa, BigInteger itemCotacao, BigInteger sequencialCotacaoProposta) {
		super();
		this.sequencialItemCossegurado = sequencialItemCossegurado;
		this.numeroCossegurado = numeroCossegurado;
		this.tipoPessoa = tipoPessoa;
		this.numeroCPFCNPJ = numeroCPFCNPJ;
		this.nomePessoa = nomePessoa;
		this.itemCotacao = itemCotacao;
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}	
	
	public BigInteger getSequencialItemCossegurado() {
		return sequencialItemCossegurado;
	}

	public void setSequencialItemCossegurado(BigInteger sequencialItemCossegurado) {
		this.sequencialItemCossegurado = sequencialItemCossegurado;
	}

	public BigInteger getNumeroCossegurado() {
		return numeroCossegurado;
	}

	public void setNumeroCossegurado(BigInteger numeroCossegurado) {
		this.numeroCossegurado = numeroCossegurado;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public String getNumeroCPFCNPJ() {
		return numeroCPFCNPJ;
	}

	public void setNumeroCPFCNPJ(String numeroCPFCNPJ) {
		this.numeroCPFCNPJ = numeroCPFCNPJ;
	}

	public String getNomePessoa() {
		return nomePessoa;
	}

	public void setNomePessoa(String nomePessoa) {
		this.nomePessoa = nomePessoa;
	}

	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public Boolean getIncluirParaTodos() {
		return incluirParaTodos;
	}

	public void setIncluirParaTodos(Boolean incluirParaTodos) {
		this.incluirParaTodos = incluirParaTodos;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((incluirParaTodos == null) ? 0 : incluirParaTodos.hashCode());
		result = prime * result + ((itemCotacao == null) ? 0 : itemCotacao.hashCode());
		result = prime * result + ((nomePessoa == null) ? 0 : nomePessoa.hashCode());
		result = prime * result + ((numeroCPFCNPJ == null) ? 0 : numeroCPFCNPJ.hashCode());
		result = prime * result + ((numeroCossegurado == null) ? 0 : numeroCossegurado.hashCode());
		result = prime * result + ((sequencialCotacaoProposta == null) ? 0 : sequencialCotacaoProposta.hashCode());
		result = prime * result + ((sequencialItemCossegurado == null) ? 0 : sequencialItemCossegurado.hashCode());
		result = prime * result + ((tipoPessoa == null) ? 0 : tipoPessoa.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemCosseguradoView other = (ItemCosseguradoView) obj;
		if (incluirParaTodos == null) {
			if (other.incluirParaTodos != null)
				return false;
		} else if (!incluirParaTodos.equals(other.incluirParaTodos))
			return false;
		if (itemCotacao == null) {
			if (other.itemCotacao != null)
				return false;
		} else if (!itemCotacao.equals(other.itemCotacao))
			return false;
		if (nomePessoa == null) {
			if (other.nomePessoa != null)
				return false;
		} else if (!nomePessoa.equals(other.nomePessoa))
			return false;
		if (numeroCPFCNPJ == null) {
			if (other.numeroCPFCNPJ != null)
				return false;
		} else if (!numeroCPFCNPJ.equals(other.numeroCPFCNPJ))
			return false;
		if (numeroCossegurado == null) {
			if (other.numeroCossegurado != null)
				return false;
		} else if (!numeroCossegurado.equals(other.numeroCossegurado))
			return false;
		if (sequencialCotacaoProposta == null) {
			if (other.sequencialCotacaoProposta != null)
				return false;
		} else if (!sequencialCotacaoProposta.equals(other.sequencialCotacaoProposta))
			return false;
		if (sequencialItemCossegurado == null) {
			if (other.sequencialItemCossegurado != null)
				return false;
		} else if (!sequencialItemCossegurado.equals(other.sequencialItemCossegurado))
			return false;
		if (tipoPessoa == null) {
			if (other.tipoPessoa != null)
				return false;
		} else if (!tipoPessoa.equals(other.tipoPessoa))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ItemCosseguradoView [sequencialItemCossegurado=" + sequencialItemCossegurado + ", numeroCossegurado="
				+ numeroCossegurado + ", tipoPessoa=" + tipoPessoa + ", numeroCPFCNPJ=" + numeroCPFCNPJ
				+ ", nomePessoa=" + nomePessoa + ", itemCotacao=" + itemCotacao + ", incluirParaTodos="
				+ incluirParaTodos + ", sequencialCotacaoProposta=" + sequencialCotacaoProposta + "]";
	}	

}
