
package br.com.tokiomarine.ctpj.integracao.crivo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de anonymous complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="executeReturn" type="{http://helper.vo.apps.co.tokiomarine.com.br}ResponseGrandesRiscosHelperVO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "executeReturn"
})
@XmlRootElement(name = "executeResponse", namespace = "http://service.co.tokiomarine.com.br")
public class ExecuteResponse {

    @XmlElement(namespace = "http://service.co.tokiomarine.com.br", required = true)
    protected ResponseGrandesRiscosHelperVO executeReturn;

    /**
     * Obt�m o valor da propriedade executeReturn.
     * 
     * @return
     *     possible object is
     *     {@link ResponseGrandesRiscosHelperVO }
     *     
     */
    public ResponseGrandesRiscosHelperVO getExecuteReturn() {
        return executeReturn;
    }

    /**
     * Define o valor da propriedade executeReturn.
     * 
     * @param value
     *     allowed object is
     *     {@link ResponseGrandesRiscosHelperVO }
     *     
     */
    public void setExecuteReturn(ResponseGrandesRiscosHelperVO value) {
        this.executeReturn = value;
    }

}
