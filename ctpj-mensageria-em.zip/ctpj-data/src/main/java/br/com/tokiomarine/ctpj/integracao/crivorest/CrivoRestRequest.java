package br.com.tokiomarine.ctpj.integracao.crivorest;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "cpfCnpjSegurado", "codigoCorretor", "tipoValidacaoPessoa", "codigoProduto", "nomeSegurado", "cdRamo", "cep",
		"nrCalculoGenerico", "tipoOperacao", "icConsultaFonteExterna" })
public class CrivoRestRequest {

	@JsonProperty("cpfCnpjSegurado")
	private String cpfCnpjSegurado;
	@JsonProperty("codigoCorretor")
	private String codigoCorretor;
	/**
	 * Pessoa Física = P
	 * Pessoa Jurídica = E
	 */
	@JsonProperty("tipoValidacaoPessoa")
	private String tipoValidacaoPessoa;
	@JsonProperty("codigoProduto")
	private String codigoProduto;
	@JsonProperty("nomeSegurado")
	private String nomeSegurado;
	@JsonProperty("cdRamo")
	private Integer cdRamo;
	@JsonProperty("cep")
	private String cep;
	@JsonProperty("nrCalculoGenerico")
	private Integer nrCalculoGenerico;
	@JsonProperty("tipoOperacao")
	private String tipoOperacao;
	@JsonProperty("icConsultaFonteExterna")
	private String icConsultaFonteExterna;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	@JsonProperty("cpfCnpjSegurado")
	public String getCpfCnpjSegurado() {
		return cpfCnpjSegurado;
	}

	@JsonProperty("cpfCnpjSegurado")
	public void setCpfCnpjSegurado(String cpfCnpjSegurado) {
		this.cpfCnpjSegurado = cpfCnpjSegurado;
	}

	@JsonProperty("codigoCorretor")
	public String getCodigoCorretor() {
		return codigoCorretor;
	}

	@JsonProperty("codigoCorretor")
	public void setCodigoCorretor(String codigoCorretor) {
		this.codigoCorretor = codigoCorretor;
	}

	@JsonProperty("tipoValidacaoPessoa")
	public String getTipoValidacaoPessoa() {
		return tipoValidacaoPessoa;
	}

	@JsonProperty("tipoValidacaoPessoa")
	public void setTipoValidacaoPessoa(String tipoValidacaoPessoa) {
		this.tipoValidacaoPessoa = tipoValidacaoPessoa;
	}

	@JsonProperty("codigoProduto")
	public String getCodigoProduto() {
		return codigoProduto;
	}

	@JsonProperty("codigoProduto")
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	@JsonProperty("cdRamo")
	public Integer getCdRamo() {
		return cdRamo;
	}

	@JsonProperty("cdRamo")
	public void setCdRamo(Integer cdRamo) {
		this.cdRamo = cdRamo;
	}

	@JsonProperty("cep")
	public String getCep() {
		return cep;
	}

	@JsonProperty("cep")
	public void setCep(String cep) {
		this.cep = cep;
	}

	@JsonProperty("nrCalculoGenerico")
	public Integer getNrCalculoGenerico() {
		return nrCalculoGenerico;
	}

	@JsonProperty("nrCalculoGenerico")
	public void setNrCalculoGenerico(Integer nrCalculoGenerico) {
		this.nrCalculoGenerico = nrCalculoGenerico;
	}

	@JsonProperty("tipoOperacao")
	public String getTipoOperacao() {
		return tipoOperacao;
	}

	@JsonProperty("tipoOperacao")
	public void setTipoOperacao(String tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

	@JsonProperty("icConsultaFonteExterna")
	public String getIcConsultaFonteExterna() {
		return icConsultaFonteExterna;
	}

	@JsonProperty("icConsultaFonteExterna")
	public void setIcConsultaFonteExterna(String icConsultaFonteExterna) {
		this.icConsultaFonteExterna = icConsultaFonteExterna;
	}
	
	public String getNomeSegurado() {
		return nomeSegurado;
	}

	public void setNomeSegurado(String nomeSegurado) {
		this.nomeSegurado = nomeSegurado;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		return "CrivoRestRequest [cpfCnpjSegurado=" + cpfCnpjSegurado + ", codigoCorretor=" + codigoCorretor
				+ ", tipoValidacaoPessoa=" + tipoValidacaoPessoa + ", codigoProduto=" + codigoProduto
				+ ", nomeSegurado=" + nomeSegurado + ", cdRamo=" + cdRamo + ", cep=" + cep + ", nrCalculoGenerico="
				+ nrCalculoGenerico + ", tipoOperacao=" + tipoOperacao + ", icConsultaFonteExterna="
				+ icConsultaFonteExterna + ", additionalProperties=" + additionalProperties + "]";
	}
}