package br.com.tokiomarine.ctpj.infra.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.ParametrosGeral;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.repository.ParametrosGeralRepository;

@Service
@Transactional
public class ParametroGeralService {

	private static Logger logger = LogManager.getLogger(ParametroGeralService.class);

	@Autowired
	private ParametrosGeralRepository repository;

	@LogPerformance
	public ParametrosGeral getParametroGeralByNome(ParametroGeralEnum nomeParametro) throws ServiceException {
		ParametrosGeral parametro = null;
		try {

			if (nomeParametro == null) { throw new Exception("Nome do Parametro infomado nulo"); }

			parametro = repository.getParametroGeralByNome(nomeParametro);

		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Parametro Geral ",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral Buscar Parametro Geral ",e);
			throw new ServiceException("Erro geral ao Buscar Parametro Geral ",e);
		}
		return parametro;

	}

	@LogPerformance
	public String getUrlByNome(ParametroGeralEnum nomeParametro) throws ServiceException {
		logger.info(nomeParametro);
		String url = null;
		try {

			if (nomeParametro == null) { throw new Exception("Nome do Parametro infomado nulo"); }

			ParametrosGeral parametro = repository.getParametroGeralByNome(nomeParametro);

			url = parametro.getValorCaracter();

			if (StringUtils.isEmpty(url)) { throw new Exception("Parametro "+nomeParametro+" procurado não encontrado!"); }

		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Parametro Geral "+nomeParametro,h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral Buscar Parametro Geral "+nomeParametro,e);
			throw new ServiceException("Erro geral ao Buscar Parametro Geral "+nomeParametro,e);
		}
		return url;
	}
	
	public List<ParametrosGeral> getParametrosActiveMQFila2(String activeMQProdutor, String activeMQUser, String activeMQPassword, String activeMQConsumidor1, String activeMQConsumidor2, String activeMQConsumidor3){
		return repository.getParametrosActiveMQFila2(activeMQProdutor, activeMQUser, activeMQPassword, activeMQConsumidor1, activeMQConsumidor2, activeMQConsumidor3);
	}
	@LogPerformance
	public String getUrl(ParametroGeralEnum nomeParametro){		
		ParametrosGeral parametro = repository.getParametroGeralByNome(nomeParametro);
		return parametro.getValorCaracter();
	}

}
