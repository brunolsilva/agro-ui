package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;

public class ParcelamentoCotacao implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -8678647843703416055L;
	private Integer codigo;
	private Integer formaPagamento;
	private Integer formaParcelamento;
	private String descricaoValor;
	private String valorEntrada;
	private String valorTotal;




	public Integer getCodigo() {
		return codigo;
	}


	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public Integer getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(Integer formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public Integer getFormaParcelamento() {
		return formaParcelamento;
	}

	public void setFormaParcelamento(Integer formaParcelamento) {
		this.formaParcelamento = formaParcelamento;
	}

	public String getDescricaoValor() {
		return descricaoValor;
	}

	public void setDescricaoValor(String descricaoValor) {
		this.descricaoValor = descricaoValor;
	}

	public String getValorEntrada() {
		return valorEntrada;
	}

	public void setValorEntrada(String valorEntrada) {
		this.valorEntrada = valorEntrada;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}


}
