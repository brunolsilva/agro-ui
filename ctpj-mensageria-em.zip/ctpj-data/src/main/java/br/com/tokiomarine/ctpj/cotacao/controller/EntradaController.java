package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaBasicaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaValor;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoPagamentoView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ProcessaLogin;
import br.com.tokiomarine.ctpj.cotacao.service.BloqueioAlcadaService;
import br.com.tokiomarine.ctpj.cotacao.service.ContaCorrenteService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.dto.ProdutoCaracteristicaView;
import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.ClasseBonusEnum;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoValorRiscoDistribuidoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.AtividadeSegurado;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.domain.CompanhiaSeguradora;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoUsuario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialBloqueioAtividade;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.UF;
import br.com.tokiomarine.ctpj.infra.enums.ClassificacaoAtividadeEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.PrazoVigenciaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.AtividadeSeguradoService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CoberturaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.PerfilComercialBloqueioAtividadeService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.integracao.dto.CnaeBu;
import br.com.tokiomarine.ctpj.integracao.dto.RetornoConsultarSaldo;
import br.com.tokiomarine.ctpj.integracao.service.ConsultarSaldoService;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.type.Paginas;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;


@Controller
@RequestMapping(value = "/entrada")
public class EntradaController extends AbstractController {

	private static final String SUCESSO = "sucesso";

	private static final Logger logger = LogManager.getLogger(EntradaController.class);

	@Autowired
	private MailUtilService mailUtilService;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private ProdutoService produtoService;

	@Autowired
	private CoberturaService coberturaService;

	@Autowired
	private AtividadeSeguradoService atividadeSeguradoService;

	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private PerfilComercialService perfilComercialService;

	@Autowired
	private BloqueioAlcadaService bloqueioAlcadaService;

	@Autowired
	private ContaCorrenteService contaCorrenteGlobal;
	
	@Autowired
	private RecebimentoService recebimentoService;
	
	@Autowired
	private PerfilComercialBloqueioAtividadeService perfilComercialBloqueioAtividadeService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;
	
	@Autowired
	private ConsultarSaldoService consultarSaldoService;
	
	private RestTemplate restTemplate = new RestTemplate();

	/*
	 * ENTRADA DO SCT
	 */
	@LogPerformance
	@GetMapping
	public Object entrada(Locale locale,HttpSession session,HttpServletRequest request,Model model,RedirectAttributes redirectAttributes) {

		String returnPage = Paginas.cotacao.value();

		try {
			logger.info("################# Entrada normal SCT ###########################");

			CtpjToken token = (CtpjToken) session.getAttribute(CTP.ctpjToken.value());

			if (logger.isDebugEnabled()) {
				logger.debug("######### CtpjToken #########");
				logger.debug(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(token));
			}

			ProcessaLogin processaLogin = cotacaoService.processaLogin(token, super.getUser());

			if (!processaLogin.isSucesso()) {
				logger.info(processaLogin.getMensagens());
				mailUtilService.sendMailErro(processaLogin.getMensagens());
				if(processaLogin.isPossuiRestricaoCrivo()) {
					model.addAttribute("mensagemRestricaoCrivo", processaLogin.getMensagens().toString().toUpperCase());
					return Paginas.restricaoCrivo.value();
				}
				return Paginas.error_403.value();
			}
			
			Cotacao cotacao = processaLogin.getCotacao();
			
			model.addAttribute("bloqueada", processaLogin.isBloqueada());
			model.addAttribute("exibeImpressos", true);

			if("S".equals(token.getSolicitacaoCotacao().getIcPossuiAnaliseTecnica()) && SecurityUtils.isCorretor()) {
				model.addAttribute("bloqueada", true);
				model.addAttribute("exibeImpressos", false);
			}

			if(cotacao.getIdTipoPedidoCotacao().equals(TipoPedidoCotacaoEnum.APOLICE) ){
				returnPage = this.pageHome(model, token, cotacao);
				contaCorrenteGlobal.bindContaCorrenteGlobalByEntradaSCT(token, cotacao, request);

				
				if(cotacaoService.isRegraNegocioFechado(cotacao, super.getUser())) {
					if(cotacao.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {
						return new RedirectView("/transmissao2/" + cotacao.getSequencialCotacaoProposta(), true , false);
					} else {
						return new RedirectView("/transmissao/" + cotacao.getSequencialCotacaoProposta(), true , false);
					}
				}
			}else{
				redirectAttributes.addFlashAttribute("cotacao", cotacao);
				returnPage = token.getSolicitacaoCotacao().getCdTipoEndosSsc().getPaginaInicialRedirect().concat(cotacao.getSequencialCotacaoProposta().toString());
				contaCorrenteGlobal.bindContaCorrenteGlobalByEntradaSCT(token, cotacao, request);
			}
			
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			mailUtilService.sendMailErro(e);
			returnPage = Paginas.error.value();
		}
		logger.info("Entrada SCT pagina de retorno: "+returnPage);
		return returnPage;
	}	

	@LogPerformance
	@GetMapping(value = "/falhaAutenticacao")
	public String falhaAutenticacao(Locale locale,HttpSession session,HttpServletRequest request,Model model) {
		model.addAttribute("msgAcessoNegado","Token inválido");
		return Paginas.acessoNegado.value();
	}

	@LogPerformance
	@GetMapping(value = "/sessaoExpirada")
	public String sessao() {
		return "erros/sessaoExpirada";
	}

	/*
	 * HOME DO CTPJ
	 */
	@LogPerformance
	@GetMapping(value = {"/home/{sqCotacao}", "/home/{sqCotacao}/{page}"})
	public Object home(
			@PathVariable(value = "sqCotacao") BigInteger sqCotacao,
			@PathVariable(value = "page") Optional<Integer> page,
			Model model,
			HttpServletRequest request,
			HttpSession session,
			RedirectAttributes redirectAttributes) {

		String returnPage = Paginas.cotacao.value();
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));
		model.addAttribute("exibeImpressos",true);

		try {
			Cotacao cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			CotacaoView cotacaoView = bindCotacaoView(cotacao,model,page.orElse(1));
			model.addAttribute(CTP.COTACAO.value(),cotacaoView);

			Map<String, String> coberturasAjustadas = (Map<String, String>) session.getAttribute("coberturasAjustadas");
			if (coberturasAjustadas != null && !coberturasAjustadas.isEmpty()) {
				for (ItemCotacaoView itemCotacao: cotacaoView.getListItem()) {
					for (ItemCoberturaView cobertura: itemCotacao.getListCoberturaAcessoriaDM()) {
						if(coberturasAjustadas.containsKey(cobertura.getDescricaoCobertura())) {
							cobertura.setDescricaoCoberturaAjustada(coberturasAjustadas.get(cobertura.getDescricaoCobertura()));
						}
					}
					
					for (ItemCoberturaView cobertura: itemCotacao.getListCoberturaBasica()) {
						if(coberturasAjustadas.containsKey(cobertura.getDescricaoCobertura())) {
							cobertura.setDescricaoCoberturaAjustada(coberturasAjustadas.get(cobertura.getDescricaoCobertura()));
						}
					}
				}
			}
			limpaMensagens(request);

			if(cotacaoService.isRegraNegocioFechado(cotacao, super.getUser())) {
				if(cotacao.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {
					return new RedirectView("/transmissao2/" + cotacao.getSequencialCotacaoProposta(), true , false);
				} else {
					return new RedirectView("/transmissao/" + cotacao.getSequencialCotacaoProposta(), true , false);
				}
			}
		} catch (final Exception e) {
			model.addAttribute("mensagem",e.getMessage());
			model.addAttribute("stacktrace",ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro",e);
			if (!AmbienteUtil.isServidorLocal()) {
				mailUtilService.sendMailErro(e);
			}

			if (StringUtils.isEmpty(returnPage)) {
				returnPage = Paginas.error.value();
			}
		}

		return returnPage;
	}
	
	private String pageHome(Model model, CtpjToken token, Cotacao cotacao) throws ServiceException, Exception {
		cotacao = cotacaoService.findCotacaoTela(cotacao.getSequencialCotacaoProposta());
		CotacaoView cotacaoView = this.bindCotacaoView(cotacao, model, token,1);
		model.addAttribute(CTP.COTACAO.value(), cotacaoView);
		
		return Paginas.cotacao.value();
	}	
	
	/**
	 * metodo usado pela home
	 */
	private CotacaoView bindCotacaoView(Cotacao cotacao,Model model,int page) throws Exception {
		return this.bindCotacaoView(cotacao,model,null,page);
	}

	private CotacaoView bindCotacaoView(Cotacao cotacao, Model model, CtpjToken ctpjToken, int page) throws Exception {
		
		CotacaoPagamentoView pagamento = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao);
		Recebimento recebimento = recebimentoService.findRecebimentoByNumeroCotacaoProposta(cotacao);
		model.addAttribute("recebimento", recebimento != null);
		model.addAttribute("pagamento", pagamento);
		model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(cotacao.getSequencialCotacaoProposta()));
		model.addAttribute("bloquearAgravo", bloquearAgravo(cotacao));

		TreeMap<Integer,Object> versoes = cotacaoService.findVersoes(cotacao.getNumeroCotacaoProposta());
		model.addAttribute("versoes", versoes);
		if(versoes != null && !versoes.isEmpty()) {
			Integer ultimaVersao = versoes.lastKey();
			if(!cotacao.getVersaoCotacaoProposta().equals(ultimaVersao)) {
				model.addAttribute("restricaoCorretor", true);
			}
		}

		if (SecurityUtils.isCorretor() && cotacao.getCodigoSituacao().equals(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getSituacao().intValue())) {
			model.addAttribute("restricaoCorretor",true);
		}

		if (Arrays.asList(
				CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue(),
				CodigoSituacaoEnum.ERRO_NA_FORMALIZACAO_453.getSituacao().intValue(),
				CodigoSituacaoEnum.LIBERADO_PELA_GRADE_454.getSituacao().intValue(),
				CodigoSituacaoEnum.CANCELADA_320.getSituacao().intValue(),
				CodigoSituacaoEnum.RECUSADA_PELA_TECNICA_308.getSituacao().intValue(),
				CodigoSituacaoEnum.RECUSADA_PELO_COMERCIAL_314.getSituacao().intValue(),
				CodigoSituacaoEnum.EMITIDA_315.getSituacao().intValue()).contains(cotacao.getCodigoSituacao())) {
			model.addAttribute("restricaoCorretor",true);
		}
		
		int firstResult = 1;
		int lastResult = 1000;
		CotacaoView cotacaoView = CotacaoViewMapper.INSTANCE.toCotacaoView(cotacao);
		
		if (page != 0) {
			if(page < 0) {
				page = 1;
			}
			
			int resultadosPorPagina = 20;

			if(cotacaoView.getCodigoProduto().equals(1851)) {
				resultadosPorPagina = 1;
			}

			int total = cotacao.getListItem().size();
			int paginas = (int) Math.ceil(total / (double) resultadosPorPagina);
			
			if(page - paginas > 1) {
				page = paginas;
			}

			firstResult = ((page - 1) * resultadosPorPagina) + 1;
			lastResult = (page) * resultadosPorPagina;

			if(page > paginas) {
				paginas = page;
			}

			model.addAttribute("pagina",page);
			model.addAttribute("total",total);
			model.addAttribute("paginas",paginas);
			model.addAttribute("firstResult",firstResult);
			model.addAttribute("lastResult",lastResult);
		}

		cotacaoView.setListItem(CotacaoViewMapper.INSTANCE.itemCotacaoSetToItemCotacaoViewList(
				cotacao.getListItem(),
				page));

		if (cotacaoView.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_CONGENERE) {
			CompanhiaSeguradora cia = caracteristicaService.findCiaSeguradora(cotacao.getCodigoCompanhiaSeguradora());
			if (cia != null) {
				model.addAttribute("dadosCongenere","Nº APÓLICE: " + cotacao.getNumeroApoliceCongenere() + " - " + cia.getCodigo() + " " + cia.getNome());
			}
		}

		if (cotacaoView.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO) {
			model.addAttribute("dadosRenovacao","Nº APÓLICE: " + cotacao.getCodigoRamoProdutoRenovada() + " " + cotacao.getCodigoApoliceRenovada());
		}

		List<BloqueioAlcada> alcadas = bloqueioAlcadaService.listaMensagensBloqueio(cotacao.getSequencialCotacaoProposta());

		Map<Integer,Object> valoresPerfil = perfilComercialService.valoresPerfil(SecurityUtils.getCurrentUser().getCdUsuro().longValue(),cotacaoView.getCodigoProduto(),cotacao.getDataCotacao());

		boolean calculoVencido = false;
		if(!valoresPerfil.isEmpty()) {
			if (cotacao.getDataCalculo() != null) {
				Integer diasValidadeCotacao = (Integer) valoresPerfil.get(3);
				Date dataMaximaCalculo = DateUtils.addDays(cotacao.getDataCalculo(),diasValidadeCotacao);
				if (DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH).after(dataMaximaCalculo) && cotacao.getDataProposta() == null) {
					calculoVencido = true;
					cotacaoView.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
					model.addAttribute("alertas",Arrays.asList("A validade do cálculo desta cotação expirou! Favor calcular novamente."));
				}
			}
			
			if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
				Optional<ComissaoCotacao> comissaoExistente = cotacao.getListComissaoCotacao().stream().findFirst();
				if(comissaoExistente.isPresent()) {
					cotacaoView.setPercentualComissao(comissaoExistente.get().getPercentualComissao().setScale(2).toString());
				} else {
					cotacaoView.setPercentualComissao(valoresPerfil.getOrDefault(1,BigDecimal.ZERO).toString());
				}
			} else {
				cotacaoView.setPercentualComissao(valoresPerfil.getOrDefault(1,BigDecimal.ZERO).toString());
			}

			boolean habilitaDesconto = (boolean) valoresPerfil.getOrDefault(4,true);
			model.addAttribute("habilitaDesconto", habilitaDesconto);
			if(habilitaDesconto && valoresPerfil.containsKey(5)) {
				List<TipoSeguroEnum> tipos = (List<TipoSeguroEnum>) valoresPerfil.get(5);
				model.addAttribute("habilitaDesconto", tipos.contains(cotacao.getIdTipoSeguro()));
			}

			if (StringUtils.isEmpty(cotacaoView.getPercentualDescontoGeral())) {
				cotacaoView.setPercentualDescontoGeral(valoresPerfil.getOrDefault(2,BigDecimal.ZERO).toString());
			}
		}

		if (SecurityUtils.isCorretor()) {
			List<String> mensagemBloqueio = new ArrayList<>();

			if(!alcadas.isEmpty()) {
				for(BloqueioAlcada alcada: alcadas) {
					if(alcada.getIdApresentaRestricao() == SimNaoEnum.SIM) {
						mensagemBloqueio.add(alcada.getDescricaoRestricaoCorretor());
					}
				}

				if(mensagemBloqueio.isEmpty()) {
					model.addAttribute("bloqueio",Arrays.asList("Clique aqui para enviar a cotação para a Tokio Marine. O retorno de sua solicitação será através do SCT."));
					model.addAttribute("link",true);
				} else {
					model.addAttribute("bloqueio",mensagemBloqueio);
				}
			} else {
				if(cotacao.getIdControleCalculo() != null) {
					Boolean possuiBloqueio = this.possuiBloqueioRubrica(cotacao, cotacaoView,model,mensagemBloqueio,page);
					if(possuiBloqueio) {
						model.addAttribute("bloqueio",Arrays.asList(mensagemBloqueio.get(0)));
						model.addAttribute("link",true);
					} else {
						model.addAttribute("bloqueio",Collections.emptyList());
					}
				}
			}
		} else if (!calculoVencido && alcadas != null && !alcadas.isEmpty()) {
			model.addAttribute("bloqueio",Arrays.asList("Foram encontrados bloqueios para esta cotação. Clique aqui para visualizar."));
		}

		model.addAttribute("desabilitaContratacao", 
				cotacaoView.getIdControleCalculo() == null || cotacaoView.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO 
					|| !alcadas.isEmpty() || calculoVencido || "0.00".equals(cotacaoView.getPercentualComissao()));

		model.addAttribute("desabilitaOpcaoParcelamento", "0.00".equals(cotacaoView.getPercentualComissao()) || !alcadas.isEmpty());

		if (cotacaoView.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			cotacaoView.setCpfSegurado(cotacao.getNumeroCNPJCPFSegurado() != null ? String.valueOf(cotacao.getNumeroCNPJCPFSegurado()) : null);
			cotacaoView.setNomeSeguradoPF(cotacao.getNomeSegurado());
		} else {
			cotacaoView.setCnpjSegurado(cotacao.getNumeroCNPJCPFSegurado() != null ? String.valueOf(cotacao.getNumeroCNPJCPFSegurado()) : null);
			cotacaoView.setNomeSeguradoPJ(cotacao.getNomeSegurado());
		}

		Produto produto = produtoService.findProduto(cotacaoView.getCodigoProduto());
		
		atualizaInicioVigencia(cotacaoView);

		basicModelMap(model,cotacaoView,produto);

		if (cotacaoView.getListItem() == null) {
			cotacaoView.setListItem(new ArrayList<ItemCotacaoView>());
		}

		if (cotacaoView.getListItem().isEmpty()) {
			populaCotacaoSemItems(cotacaoView, ctpjToken, (page == 0 || page == 1) ? BigInteger.ONE: new BigInteger(String.valueOf(firstResult)));
		}

		if(cotacao.getIdLmiUnico() == SimNaoEnum.SIM && (page > 1 && cotacaoView.getListItem().size() == 1)) {
			populaCotacaoSemItems(cotacaoView, ctpjToken, new BigInteger(String.valueOf(firstResult)));
		}
		boolean readOnly = CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly();
		model.addAttribute("readOnly", readOnly);
		validarVerbasContaCorrente(ctpjToken, cotacao, model, readOnly);

		if(model.containsAttribute("bloqueada")) {
			if((boolean)model.asMap().get("bloqueada") == true) {
				model.addAttribute("readOnly",true);
				if(CodigoSituacaoEnum.EMITIDA_315.getSituacao().intValue() == cotacaoView.getCodigoSituacaoReadOnly()
						|| CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue() == cotacaoView.getCodigoSituacaoReadOnly() 
						|| CodigoSituacaoEnum.LIBERADO_PELA_GRADE_454.getSituacao().intValue() == cotacaoView.getCodigoSituacaoReadOnly()) {
					model.addAttribute("exibeImpressos",true);
				} else {
					model.addAttribute("exibeImpressos",false);
				}
			}
		} else {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			if(perfilComercialService.hasPerfilComercial(grupoUsuario)) {
				model.addAttribute("readOnly",true);
				model.addAttribute("bloqueada",true);
				model.addAttribute("exibeImpressos",false);
				if ((cotacao.getIdTipoOrigem() != null && cotacao.getIdTipoOrigem() == TipoOrigemEnum.WS)
						|| cotacao.getCodigoSituacao() == CodigoSituacaoEnum.EMITIDA_315.getSituacao().intValue()) {
					model.addAttribute("comercial", true);
				}
			}
		}

		return cotacaoView;
	}

	/**
	 * valida se as verbas utilizadas na conta corrente ainda estão disponíveis
	 * @param cotacao
	 * @param model
	 * @param isReadOnly
	 * @throws ServiceException
	 */
	private void validarVerbasContaCorrente(CtpjToken ctpjToken, Cotacao cotacao, Model model, Boolean isReadOnly) throws ServiceException {
		
		final Long codigoRobo = 111119l;
		//validação no saldo do conta corrente - início
		if(ctpjToken != null && 
		   !codigoRobo.equals(Long.valueOf(cotacao.getCodigoCorretorACSEL())) && 
		   cotacao.getIdTipoPedidoCotacao() != null && 
		   cotacao.getIdTipoPedidoCotacao().equals(TipoPedidoCotacaoEnum.APOLICE) && 
		   !isReadOnly) {
			
			ResultadoREST<RetornoConsultarSaldo> retConsultaSaldo = consultarSaldoService.loadSaldo(cotacao.getSequencialCotacaoProposta(), super.getUser());
			//verifica se algum saldo utilizado anteriormente ficou indisponível
			if(retConsultaSaldo.getRetornoObj() != null && 
				!StringUtils.isBlank(retConsultaSaldo.getRetornoObj().getDescontoRemovido()) && 
				retConsultaSaldo.getRetornoObj().getDescontoRemovido().equals(SimNaoEnum.SIM.getId())) {
				model.addAttribute("descontoCcgRemovido", SimNaoEnum.SIM.getId());
				//cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
				model.addAttribute("infos",Arrays.asList("<strong>Atenção!</strong> Identificamos que anteriormente foi aplicado um desconto de Conta Corrente para esta cotação, porém a verba utilizada naquele momento está indisponível.<br>Será necessário calcular a cotação novamente."));
			}
		}
		//validação no saldo do conta corrente - fim
	}
	
	private Boolean possuiBloqueioRubrica(Cotacao cotacao, CotacaoView cotacaoView, Model model, List<String> mensagemBloqueio, int page) throws ServiceException{
		//verifica se o usuário é corretor
			Boolean possuiRubricaAmarela = false;
			PerfilCalculoUsuario perfilComercial = perfilComercialService.findPerfilCalculo(
					SecurityUtils.getCurrentUser().getCdUsuro().longValue(),
					cotacao.getDataCotacao());
			//verifica se o corretor possui perfil comercial
			if(perfilComercial != null){
				Boolean possuiRubricaVermelha = false;
				
				for(ItemCotacao itemCotacao : cotacao.getListItem()){
					PerfilComercialBloqueioAtividade perfilComercialBloqueio = perfilComercialBloqueioAtividadeService.findPerfilComercialBloqueio(
							cotacao,
							itemCotacao.getCodigoRubrica(),
							perfilComercial);

					if(perfilComercialBloqueio != null){
						
						//itemCotacaoView.setClassificacaoRubrica(perfilComercialBloqueio.getClassificacao());
						if(!possuiRubricaVermelha){
							if(perfilComercialBloqueio.getClassificacao().getId().equals(ClassificacaoAtividadeEnum.VERMELHA.getId())){
								possuiRubricaVermelha = true;
								model.addAttribute("erro", Arrays.asList("Atividade '"+itemCotacao.getDescricaoRubrica().toUpperCase()+"' declinada"));
								possuiRubricaAmarela = false;//seta para false, pois se há rubrica vermelha não deve mostrar mensagem de bloqueio
							}
							
							if(perfilComercialBloqueio.getClassificacao().getId().equals(ClassificacaoAtividadeEnum.AMARELA.getId())){
								mensagemBloqueio.add("Atividade '"+itemCotacao.getDescricaoRubrica().toUpperCase()+"' sob consulta, clique aqui para enviar a cotação para Tokio Marine");
								possuiRubricaAmarela = true;
							}
						}
					}
				}
				
				for(ItemCotacaoView itemCotacaoView : cotacaoView.getListItem()){
					PerfilComercialBloqueioAtividade perfilComercialBloqueio = perfilComercialBloqueioAtividadeService.findPerfilComercialBloqueio(
							cotacao,
							itemCotacaoView.getCodigoRubrica(),
							perfilComercial);

					if(perfilComercialBloqueio != null){
						
						itemCotacaoView.setClassificacaoRubrica(perfilComercialBloqueio.getClassificacao());
						if(!possuiRubricaVermelha){
							if(perfilComercialBloqueio.getClassificacao().getId().equals(ClassificacaoAtividadeEnum.VERMELHA.getId())){
								possuiRubricaVermelha = true;
								model.addAttribute("erro", Arrays.asList("Atividade '"+itemCotacaoView.getDescricaoRubrica().toUpperCase()+"' declinada"));
								possuiRubricaAmarela = false;//seta para false, pois se há rubrica vermelha não deve mostrar mensagem de bloqueio
							}
							
							if(perfilComercialBloqueio.getClassificacao().getId().equals(ClassificacaoAtividadeEnum.AMARELA.getId())){
								mensagemBloqueio.add("Atividade '"+itemCotacaoView.getDescricaoRubrica().toUpperCase()+"' sob consulta, clique aqui para enviar a cotação para Tokio Marine");
								possuiRubricaAmarela = true;
							}
						}
					}
				}
				model.addAttribute("possuiRubricaVermelha", possuiRubricaVermelha);
				model.addAttribute("possuiRubricaAmarela", possuiRubricaAmarela);

				if(!possuiRubricaVermelha) {
					if(page <= 1 && cotacaoService.isOrcamentoRamoCpfCnpj(cotacao,SecurityUtils.getCurrentUser())){
						possuiRubricaAmarela = true;
						mensagemBloqueio.add("Esse cálculo será analisado pela Matriz, clique aqui para enviar a cotação para a Tokio Marine. O retorno se dará em até 48 horas úteis via SCT.");
						model.addAttribute("possuiRubricaAmarela", possuiRubricaAmarela);
					}
				}
			}
			
			return possuiRubricaAmarela;
	}

	/**
	 * Metódo que adiciona o dados básicos para montagem da tela de Cotação
	 * (listas de valores, coberturas, informações adicionais, etc)
	 * 
	 * @param model o Model (map) com as informações da tela
	 * @param cotacao o DTO da Cotacao
	 * @param produto o documento do Produto
	 * @throws RepositoryException 
	 */
	public void basicModelMap(Model model,CotacaoView cotacao,Produto produto) throws RepositoryException {

		if(SecurityUtils.isCorretor()) {
			model.addAttribute("moeda",Arrays.asList(MoedaEnum.REAL));
		} else {
			model.addAttribute("moeda",MoedaEnum.values());
		}
		model.addAttribute("tiposSeguro",TipoSeguroEnum.valoresCTPJ());
		if(SecurityUtils.isCorretor()) {
			model.addAttribute("prazosVigencia",Arrays.asList(PrazoVigenciaEnum.ANUAL));
		} else {
			model.addAttribute("prazosVigencia",Arrays.asList(PrazoVigenciaEnum.values()).stream().sorted(Comparator.comparing(PrazoVigenciaEnum::getValor)).collect(Collectors.toList()));
		}

		AtividadeSegurado atividadeSegurado = atividadeSeguradoService.getAtividadeSegurado(cotacao.getCodigoAtividadePrincipal());
		if (atividadeSegurado != null) {
			model.addAttribute("codigoAtividadePrincipalOriginal",atividadeSegurado.getAtividadePrincipal());
			model.addAttribute("descricaoAtividadePrincipalOriginal",atividadeSegurado.getDescricao());
		}

		if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.JURIDICA && Boolean.FALSE.equals(cotacao.getIdIsencaoImposto())) {
			try {
				String urlCnae = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroBuConsultaCnae());
				if(cotacao.getCodigoTipoEndossoSCT() == null) {
					CnaeBu[] retornoCnae = restTemplate.getForObject(urlCnae,CnaeBu[].class);
					if(retornoCnae != null && retornoCnae.length > 0) {
						for(CnaeBu cnae: retornoCnae) {
							if(atividadeSegurado.getAtividadePrincipal().equals(cnae.getAtividadePrincipal()) &&
								atividadeSegurado.getDigitoVerificador().equals(cnae.getDigitoVerificador()) &&
								atividadeSegurado.getClasse().equals(cnae.getClasse()) &&
								atividadeSegurado.getSubClasse().equals(cnae.getSubClasse())) {
								if("S".equals(cnae.getIsencaoIof())) {
									cotacao.setIdIsencaoImposto(true);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				logger.error("Erro na consulta da busca do Parametro ou na recuperação dos cnaes " + e.getMessage());
			}
		}

		if (cotacao.getIdPrazoVigencia() == null) {
			cotacao.setIdPrazoVigencia(produto.getPrazoVigencia());
		}

		List<ProdutoValorCarac> bensCobertos = caracteristicaService.getValoresCaracteristica(cotacao.getCodigoProduto(),Caracteristicas.BEM_COBERTO.codigo(),new Sort(Direction.ASC,"descricaoValor"));
		List<ProdutoValorCarac> classesConstrucao = caracteristicaService.getValoresCaracteristica(cotacao.getCodigoProduto(),Caracteristicas.CLASSE_CONSTRUCAO.codigo(),new Sort(Direction.ASC,"descricaoValor"));
		List<ProdutoValorCarac> localizacoes = caracteristicaService.getValoresCaracteristica(cotacao.getCodigoProduto(),Caracteristicas.LOCALIZACAO.codigo(),new Sort(Direction.ASC,"descricaoValor"));

		List<ProdutoValorCarac> classesOcupacao = caracteristicaService.getValoresCaracteristica(cotacao.getCodigoProduto(),Caracteristicas.CLASSE_OCUPACAO.codigo(),new Sort(Direction.ASC,"valorCaracteristica"));
		List<ProdutoValorCarac> classesLocalizacao = caracteristicaService.getValoresCaracteristica(cotacao.getCodigoProduto(),Caracteristicas.CLASSE_LOCALIZACAO.codigo(),new Sort(Direction.ASC,"valorCaracteristica"));

		List<ProdutoValorCarac> protecionais = caracteristicaService.getValoresCaracteristica(cotacao.getCodigoProduto(),Caracteristicas.SISTEMA_PROTECIONAL.codigo(),new Sort(Direction.ASC,"descricaoValor"));

		List<CompanhiaSeguradora> ciasSeguradora = caracteristicaService.findCiasSeguradora();

		List<UF> ufs = caracteristicaService.findUFs();
		Optional<ProdutoCaracteristicaView> produtoCaracteristica = produtoService.findCaracsByProduto(cotacao.getCodigoProduto());

		/**
		 * Recupera as Coberturas Básicas
		 */
		List<Cobertura> coberturasBasicas = coberturaService.findCoberturasBasicas(cotacao);

		/**
		 * Listas com a hierarquia completa das coberturas Danos Materiais e Lucros Cessantes
		 */
		List<CoberturaBasicaHierarquiaView> hierarquiaDM = new ArrayList<>();

		Map<Integer,List<CoberturaHierarquiaView>> todasDM = coberturaService.findCoberturasAdicionaisDMView(cotacao,coberturasBasicas.stream()
				.map(Cobertura::getCodigo)
				.collect(Collectors.toList()));

		todasDM.forEach((k,v) -> {
			CoberturaBasicaHierarquiaView estruturaCobertura = new CoberturaBasicaHierarquiaView();
			estruturaCobertura.setCoberturaBasica(k);
			estruturaCobertura.setFilhas(v);
			hierarquiaDM.add(estruturaCobertura);
		});

		/**
		 * Início da montagem da hierarquia de Danos Materiais
		 */
		montaHierarquiaDM(cotacao,produto,coberturasBasicas,hierarquiaDM);

		/**
		 * Models com as hierarquias completas de coberturas Danos Materiais e Lucros Cessantes
		 */
		model.addAttribute("hierarquiaDM",JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(hierarquiaDM));

		boolean lmiUnico = produto.getLmiUnico() != null ? produto.getLmiUnico().getLogical() : false;
		BigDecimal valorMaximoVR = produto.getValorMaximoVR();
		
		/**
		 * Atributos do Item/Local de Risco (caracteristicas)
		 */
		model.addAttribute("ufs",ufs);
		model.addAttribute("bensCobertos",bensCobertos);
		model.addAttribute("classesConstrucao",classesConstrucao);
		model.addAttribute("classesOcupacao",classesOcupacao);
		model.addAttribute("classesLocalizacao",classesLocalizacao);
		model.addAttribute("localizacoes",localizacoes);
		model.addAttribute("protecionais",protecionais);
		model.addAttribute("idsVRDistribuido",TipoValorRiscoDistribuidoEnum.values());
		model.addAttribute("ciasSeguradora",ciasSeguradora);
		model.addAttribute("coberturasBasicas",coberturasBasicas);
		model.addAttribute("classesBonus",ClasseBonusEnum.values());
		model.addAttribute("lmiUnico",lmiUnico);
		model.addAttribute("valorMaximoVR",valorMaximoVR);
		model.addAttribute("produto",produto);
		model.addAttribute("codigoCorretor",cotacao.getCodigoCorretorACSEL());

		model.addAttribute("prazoVigenciaProduto",produto.getPrazoVigencia());
		model.addAttribute("carateristicas",produtoCaracteristica.orElseThrow(IllegalStateException::new));

		if (lmiUnico) {
			for (ItemCotacaoView item : cotacao.getListItem()) {
				if (!item.getNumeroItem().equals(BigInteger.ONE)) {
					item.getListCoberturaBasica().clear();
					item.getListCoberturaAcessoriaDM().clear();
					item.getListCoberturaAcessoriaLC().clear();
				}
			}
		}
	}

	/**
	 * @param cotacao
	 * @param produto
	 * @param coberturasBasicas
	 * @param hierarquiaDM
	 */
	@LogPerformance
	public void montaHierarquiaDM(CotacaoView cotacao,Produto produto,List<Cobertura> coberturasBasicas,List<CoberturaBasicaHierarquiaView> hierarquiaDM) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		if (cotacao.getListItem() != null && !cotacao.getListItem().isEmpty()) {
			for (ItemCotacaoView itemCotacaoView : cotacao.getListItem()) {
				if (itemCotacaoView.getListCoberturaBasica() != null && !itemCotacaoView.getListCoberturaBasica().isEmpty()) {
					Integer codigoCoberturaBasica = itemCotacaoView.getListCoberturaBasica().get(0).getCodigoCobertura();
					for (int i = 0 ; i < itemCotacaoView.getListCoberturaAcessoriaDM().size() ; i++) {
						ItemCoberturaView coberturaAtual = itemCotacaoView.getListCoberturaAcessoriaDM().get(i);

						List<CoberturaHierarquiaView> coberturasDMItem = new ArrayList<>();

						for (CoberturaBasicaHierarquiaView cbhv : hierarquiaDM) {
							if (cbhv.getCoberturaBasica().equals(codigoCoberturaBasica)) {
								coberturasDMItem.addAll(cbhv.getFilhas());
							}
						}

						for (CoberturaHierarquiaView cv : coberturasDMItem) {
							coberturaAtual.getValoresCobertura().add(new CoberturaValor(cv.getCodigoCobertura(),cv.getDescricao()));
						}

						Map<Integer,Object> infras = coberturaService.getInfrasCobertura(produto.getCodigo(),coberturaAtual.getCodigoCobertura(),cotacao.getDataCotacao(), coberturaAtual.getCoberturaPrincipal());
						if (infras.size() == 5) {
							coberturaAtual.setPeriodosIndenitarios((List<Integer>) infras.get(1));
							coberturaAtual.setExigeValorRisco((boolean) infras.get(2));
							coberturaAtual.setExigeVagasGaragem((boolean) infras.get(3));
							coberturaAtual.setExigeIS((boolean) infras.get(4));
						}

						Map<String,List<BigDecimal>> multiplos = coberturaService.getMultiplosFranquiaPrejuizo(produto.getCodigo(),coberturaAtual.getCodigoCobertura(),cotacao.getDataCotacao());

						if (multiplos.containsKey("multiplosFranquia")) {
							coberturaAtual.setMultiplosFranquia(multiplos.get("multiplosFranquia"));
						}

						if (multiplos.containsKey("multiplosPrejuizo")) {
							coberturaAtual.setMultiplosPrejuizo(multiplos.get("multiplosPrejuizo"));
						}
					}
				}

				List<Integer> todasCoberturasDM = itemCotacaoView.getListCoberturaAcessoriaDM()
						.stream()
						.map(ItemCoberturaView::getCodigoCobertura).collect(Collectors.toList());

				for (int i = 0 ; i < itemCotacaoView.getListCoberturaAcessoriaDM().size() ; i++) {
					ItemCoberturaView coberturaAtual = itemCotacaoView.getListCoberturaAcessoriaDM().get(i);
					coberturaAtual.setValoresCobertura(coberturaAtual.getValoresCobertura().stream()
							.filter(valor -> !todasCoberturasDM.contains(valor.getCodigo()) || valor.getCodigo().equals(coberturaAtual.getCodigoCobertura()))
							.collect(Collectors.toList()));
				}

				if (itemCotacaoView.getListCoberturaAcessoriaDM().size() == 0) {
					ItemCoberturaView linhaCobertura = new ItemCoberturaView();

					List<CoberturaHierarquiaView> coberturasDoItem = new ArrayList<>();

					for (CoberturaBasicaHierarquiaView cbhv : hierarquiaDM) {
						if (cbhv.getCoberturaBasica().equals(coberturasBasicas.get(0).getCodigo())) {
							coberturasDoItem.addAll(cbhv.getFilhas());
						}
					}

					for (CoberturaHierarquiaView cv : coberturasDoItem) {
						linhaCobertura.getValoresCobertura().add(new CoberturaValor(cv.getCodigoCobertura(),cv.getDescricao()));
					}

					ItemCoberturaView linhaCoberturaAvulsa = new ItemCoberturaView();
					linhaCoberturaAvulsa.setIdCoberturaAvulsa(true);

					itemCotacaoView.getListCoberturaAcessoriaDM().add(linhaCobertura);
					itemCotacaoView.getListCoberturaAcessoriaDM().add(linhaCoberturaAvulsa);
				} else {
					if (itemCotacaoView.getListCoberturaAcessoriaDM().stream().filter(ItemCoberturaView::getIdCoberturaAvulsa).count() == 0) {

						ItemCoberturaView linhaCoberturaAvulsa = new ItemCoberturaView();
						linhaCoberturaAvulsa.setIdCoberturaAvulsa(true);
						itemCotacaoView.getListCoberturaAcessoriaDM().add(linhaCoberturaAvulsa);
					} else {
						itemCotacaoView.setCoberturaAvulsaDM(true);
					}
				}
			}
		}
		stopWatch.stop();
		logger.info(cotacao.getSequencialCotacaoProposta() + " executado em " + stopWatch.getTotalTimeSeconds() + "s");
	}

	/**
	 * Atualiza a Data de Início de Vigência para HOJE se CORRETOR e VERSÃO 1
	 * 
	 * @param cotacaoView
	 */
	private void atualizaInicioVigencia(CotacaoView cotacaoView) {
		GrupoUsuarioEnum grupoUsuario = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getGrupoUsuario();
		LocalDate dataInicio = LocalDate.from(cotacaoView.getDataInicioVigencia().toInstant().atZone(ZoneId.systemDefault()));
		if (cotacaoView.getVersaoCotacaoProposta().equals(1) && grupoUsuario == GrupoUsuarioEnum.CORRETOR && dataInicio.isBefore(LocalDate.now())) {
			cotacaoView.setDataInicioVigencia(new Date());
			if (cotacaoView.getIdPrazoVigencia() == PrazoVigenciaEnum.ANUAL) {
				cotacaoView.setDataFimVigencia(DateUtils.addYears(cotacaoView.getDataInicioVigencia(),1));
			}
		}
	}

	private void populaCotacaoSemItems(CotacaoView cotacaoView, CtpjToken ctpjToken, BigInteger numeroItem) {
		ItemCotacaoView item = new ItemCotacaoView();
		item.setNumeroItem(numeroItem);
		
		if (ctpjToken != null) {
			SolicitacaoCotacao solicitacaoCotacao = ctpjToken.getSolicitacaoCotacao();
			if(solicitacaoCotacao.getVlMaiorIsRisco() != null) {
				item.setValorRiscoBemCalculado(solicitacaoCotacao.getVlMaiorIsRisco().toPlainString());
			}
			item.setIdTipoSeguro(TipoSeguroEnum.fromId(solicitacaoCotacao.getIcTipoSegur().getId()));
		}

		ItemCoberturaView coberturaBasica = new ItemCoberturaView();
		coberturaBasica.setIdLMR(true);
		ItemCoberturaView coberturaAdicionalDM = new ItemCoberturaView();
		ItemCoberturaView coberturaAdicionalLC = new ItemCoberturaView();

		ItemCoberturaView coberturaAdicionalDMAvulsa = new ItemCoberturaView();
		coberturaAdicionalDMAvulsa.setIdCoberturaAvulsa(true);
		ItemCoberturaView coberturaAdicionalLCAvulsa = new ItemCoberturaView();
		coberturaAdicionalLCAvulsa.setIdCoberturaAvulsa(true);

		item.getListCoberturaBasica().add(coberturaBasica);
		item.getListCoberturaAcessoriaDM().add(coberturaAdicionalDM);
		item.getListCoberturaAcessoriaLC().add(coberturaAdicionalLC);

		item.getListCoberturaAcessoriaDM().add(coberturaAdicionalDMAvulsa);
		item.getListCoberturaAcessoriaLC().add(coberturaAdicionalLCAvulsa);
		cotacaoView.getListItem().add(item);
	}

	private boolean bloquearAgravo(Cotacao cotacao) {
		return GrupoUsuarioEnum.CORRETOR == SecurityUtils.getCurrentUser().getGrupoUsuario() && TipoOrigemEnum.INTERNO == cotacao.getIdTipoOrigem();
	}

}
