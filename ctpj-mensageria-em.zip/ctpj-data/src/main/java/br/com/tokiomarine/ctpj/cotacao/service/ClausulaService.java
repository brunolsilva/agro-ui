package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.ClausulaCotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaClausulaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemRamoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemRubricaClausulaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemSistemaProtecionalClausulaRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ClausulaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRubricaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecionalClausula;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.CaracteristicaValorClausulaNota;
import br.com.tokiomarine.ctpj.infra.domain.ClausulaNota;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CondicaoContratualRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.mapper.ClausulaMapper;

/**
 * @author Hromenique Cezniowscki Leite Batista
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class ClausulaService {

	private static Logger logger = LogManager.getLogger(ClausulaService.class);

	private static final String SIM = "S";
	private static final String NAO = "N";

	private static final int TIPO_CLAUSULA_COBERTURA = 3;
	private static final int TIPO_CLAUSULA_RUBRICA = 4;
	private static final int TIPO_CLASULA_SISTEMAS_PROTECIONAIS = 5;

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private ItemRamoRepository itemRamoRepository;
	
	@Autowired
	private ProdutoRepository produtoRepository;
	
	@Autowired
	private CondicaoContratualRepository condicaoContratualRepository;
	
	@Autowired
	private ClausulaCotacaoRepository clausulaCotacaoRepository;
	
	@Autowired
	private ItemRubricaClausulaRepository itemRubricaClausulaRepository;
	
	@Autowired
	private ItemSistemaProtecionalClausulaRepository itemSistProtecionalClausulaRepository;
	
	@Autowired
	private ItemCoberturaClausulaRepository itemCoberturaClausulaRepository;
	
	@Autowired
	private ClausulaMapper mapper;

	/**
	 * Lista as cláusulas de capa para uma determinada cotação
	 * 
	 * @param cotacao Cotação para a qual será listada as cláusulas de capa
	 * @param clausulasAutomaticas Define se serão buscadas claúsulas de automáticas ou não automáticas (manuais). Usar true para sim e false para não
	 * @return Uma lista contendo as cláusulas de capa para uma determinada cotação
	 */
	public List<ClausulaNota> listaClausulasCapa(Cotacao cotacao,boolean clausulasAutomaticas) {
		Produto produto = produtoRepository.findByCodigo(cotacao.getCodigoProduto());

		Integer codigoGrupoRamo = produto.getGrupoRamo();
		Integer codigoRamoProduto = produto.getRamoContabil();
		Date dataCalculo = cotacao.getDataCalculo() != null ? cotacao.getDataCalculo() : new Date();
		String clausulasAutomaticasFlag = clausulasAutomaticas ? SIM : NAO;

		List<ClausulaNota> clausulasNotas = condicaoContratualRepository.findClausulaNota(codigoGrupoRamo,codigoRamoProduto,1,clausulasAutomaticasFlag,dataCalculo);
		return clausulasNotas;
	}

	/**
	 * Lista as cláusulas de capa manuais para uma determinada cotação
	 * 
	 * @param cotacao
	 * @return
	 */
	public List<ClausulaNota> listaClausulasCapaManuais(Cotacao cotacao) {
		return listaClausulasCapa(cotacao,false);
	}

	/**
	 * Lista as cláusulas de capa manuais para uma determinada cotação
	 * 
	 * @param seqCotacao
	 * @return
	 */
	public List<ClausulaNota> listaClausulasCapaManuais(BigInteger seqCotacao) {
		Cotacao cotacao = cotacaoRepository.findById(seqCotacao);
		return listaClausulasCapa(cotacao,false);
	}

	/**
	 * Salva as Clausulas de Capa Manuais
	 * 
	 * @param seqCotacao
	 * @param clausulasCotacao Lista contendo as Clausulas da Cotacao
	 */
	public void salvaClausulasCapasManuais(BigInteger seqCotacao,List<ClausulaCotacao> clausulasCotacao) {
		clausulaCotacaoRepository.excluiTodasClausulasManuaisDaCotacao(seqCotacao);

		for (ClausulaCotacao clausulaCotacao : clausulasCotacao)
			clausulaCotacaoRepository.salva(clausulaCotacao);
	}

	/**
	 * Lista as CaracteristicaValorClausulaNota para Rubrica
	 * 
	 * @param itemCotacao Item da Cotacao para o qual os valores serão listado
	 * @param dataCalculoCotacao
	 * @return
	 */
	public List<CaracteristicaValorClausulaNota> listaClausulasRubrica(ItemCotacao itemCotacao,Date dataCalculoCotacao) {
		ItemRamoEmissao itemRamoEmissao = itemRamoRepository.findByItemCotacao(itemCotacao).get(0);
		Integer codigoGrupoRamo = itemRamoEmissao.getCodigoGrupoRamo();
		Integer codigoRamo = itemRamoEmissao.getCodigoRamo();
		Long codigoRubrica = itemCotacao.getCodigoRubrica();

		return condicaoContratualRepository.findCaracteristicaValorClausulaNotas(codigoGrupoRamo,codigoRamo,7,codigoRubrica,TIPO_CLAUSULA_RUBRICA,dataCalculoCotacao);
	}

	/**
	 * Lista as CaracteristicaValorClausulaNota para Rubrica
	 * 
	 * @param seqItemCotacao Identificador do item da cotação para o qual os valores serão listados
	 * @return
	 * @throws ServiceException
	 */
	public List<CaracteristicaValorClausulaNota> listaClausulasRubrica(BigInteger seqItemCotacao) throws ServiceException {
		try {
			ItemCotacao itemCotacao = cotacaoRepository.findItem(seqItemCotacao);
			return listaClausulasRubrica(itemCotacao);
		} catch (RepositoryException e) {
			throw new ServiceException(e);
		}
	}

	public List<CaracteristicaValorClausulaNota> listaClausulasRubrica(ItemCotacao itemCotacao) {
		ItemRamoEmissao itemRamoEmissao = itemRamoRepository.findByItemCotacao(itemCotacao).get(0);
		Integer codigoGrupoRamo = itemRamoEmissao.getCodigoGrupoRamo();
		Integer codigoRamo = itemRamoEmissao.getCodigoRamo();
		Long codigoRubrica = itemCotacao.getCodigoRubrica();
		Date dataCalculoCotacao = itemCotacao.getCotacao().getDataCalculo();
		return condicaoContratualRepository.findCaracteristicaValorClausulaNotas(codigoGrupoRamo,codigoRamo,7,codigoRubrica,TIPO_CLAUSULA_RUBRICA,dataCalculoCotacao);
	}

	/**
	 * Salva (atualiza) os Itens Rubrica Clausula para todos os Itens da Cotação
	 * 
	 * @param seqCotacao Identificador da Cotação
	 * @param itens
	 */
	public void salvaOuAtualizaItensRubricaClausulaParaCotacao(BigInteger seqCotacao,List<ItemRubricaClausula> itens) {
		itemRubricaClausulaRepository.excluiClausulaRubricaManualPorCotacao(seqCotacao);

		for (ItemRubricaClausula item : itens)
			itemRubricaClausulaRepository.salva(item);
	}

	/**
	 * Salva (atualiza) os Itens Rubrica Clausula para um Item da Cotação
	 * 
	 * @param seqItemCotacao identificador do Item da Cotação
	 * @param itens
	 * @throws ServiceException
	 */
	public void salvaOuAtualizaItensRubricaClausulaParaItemCotacao(BigInteger seqItemCotacao,List<ItemRubricaClausula> itens) throws ServiceException {
		itemRubricaClausulaRepository.excluiClausulaRubricaManualPorItemCotacao(seqItemCotacao);

		for (ItemRubricaClausula item : itens)
			itemRubricaClausulaRepository.salva(item);
	}

	/**
	 * Salva (atualiza) os Itens Sistema Protecional Clausula para todos os Itens da Cotação
	 * 
	 * @param seqCotacao identificador da cotação
	 * @param itens
	 */
	public void salvaOuAtualizaItemSistemaProtecionalClausulaParaCotacao(BigInteger seqCotacao,List<ItemSistemaProtecionalClausula> itens) {
		itemSistProtecionalClausulaRepository.exlcluiClausulasManuaisPorCotacao(seqCotacao);

		for (ItemSistemaProtecionalClausula item : itens) {
			itemSistProtecionalClausulaRepository.salva(item);
		}

	}

	/**
	 * Salva (atualiza) os Itens Protecional Clausula para todos um Item da Cotação
	 * 
	 * @param seqItemCotacao Identificador do Item da Cotação
	 * @param itens
	 */
	public void salvaOuAtualizaItemSistemaProtecionalClausulaParaItemCotacao(BigInteger seqItemCotacao,List<ItemSistemaProtecionalClausula> itens) {
		itemSistProtecionalClausulaRepository.excluiClausulasManuaisPorItemCotacao(seqItemCotacao);

		for (ItemSistemaProtecionalClausula item : itens) {
			itemSistProtecionalClausulaRepository.salva(item);
		}
	}

	/**
	 * Lista CaracteristicaValorClausulaNota para o Item Sistema Protecional pertecente a um item cotação
	 * 
	 * @param ic
	 * @param ire
	 * @param isp
	 * @return
	 */
	public List<CaracteristicaValorClausulaNota> listaCaracValorClausulaNotaPorSistemaProtecional(ItemCotacao ic,ItemRamoEmissao ire,ItemSistemaProtecional isp) {
		Integer codigoGrupoRamo = ire.getCodigoGrupoRamo();
		Integer codigoRamo = ire.getCodigoRamo();
		Integer caracteristica = 20;
		Long valorCaracteristica = isp.getCodigoSistemaProtecional();
		Date dataCalculoCotacao = ic.getCotacao().getDataCalculo();
		return condicaoContratualRepository.findCaracteristicaValorClausulaNotas(codigoGrupoRamo,codigoRamo,caracteristica,valorCaracteristica,TIPO_CLASULA_SISTEMAS_PROTECIONAIS,dataCalculoCotacao);
	}

	/**
	 * Lista CaracteristicaValorClausulaNota para o Item Sistema Protecional pertecente a um item cotação
	 * 
	 * @param ic
	 * @param isp
	 * @return
	 */
	public List<CaracteristicaValorClausulaNota> listaCaracValorClausulaNotaPorSistemaProtecional(ItemCotacao ic,ItemSistemaProtecional isp) {
		ItemRamoEmissao ire = itemRamoRepository.findByItemCotacao(ic).get(0);
		return listaCaracValorClausulaNotaPorSistemaProtecional(ic,ire,isp);
	}

	/**
	 * Lista CaracteristicaValorClausulaNota para um Item Cobertura
	 * 
	 * @param itcob
	 * @return
	 */
	public List<CaracteristicaValorClausulaNota> listaCaracValorClausulaNotaCoberturaPorItemCotacao(ItemCobertura itcob) {
		Integer codigoGrupoRamoEmissao = itcob.getCodigoGrupoRamoEmissao();
		Integer codigoRamoCoberturaEmissao = itcob.getCodigoRamoCoberturaEmissao();
		ItemCotacao itemCotacao = itcob.getItemCotacao();
		Long codRubrica = itemCotacao.getCodigoRubrica();
		Date dataCalculoCotacao = itemCotacao.getCotacao().getDataCalculo();
		return condicaoContratualRepository.findCaracteristicaValorClausulaNotas(codigoGrupoRamoEmissao,codigoRamoCoberturaEmissao,7,codRubrica,TIPO_CLAUSULA_COBERTURA,dataCalculoCotacao);
	}

	/**
	 * Salva (atualiza) os ItensClausulaCobertura para todos os Itens da Cotação
	 * 
	 * @param seqCotacao Identificador da cotação
	 * @param itensParaInclusao
	 */
	public void salvaOuAtualizaItensClausualCoberturaParaCotacao(BigInteger seqCotacao,List<ItemCoberturaClausula> itensParaInclusao) {
		itemCoberturaClausulaRepository.excluiClausulasManuaisPorCotacao(seqCotacao);

		for (ItemCoberturaClausula item : itensParaInclusao) {
			itemCoberturaClausulaRepository.salvaItem(item);
		}
	}

	/**
	 * Salva (atualiza) os ItensClausulaCobertura para um Item da Cotação
	 * 
	 * @param seqItemCotacao
	 * @param itensParaInclusao
	 */
	public void salvaOuAtualizaItensClausualCoberturaParaItemCotacao(BigInteger seqItemCotacao,List<ItemCoberturaClausula> itensParaInclusao) {
		itemCoberturaClausulaRepository.excluiClausulasManuaisPorItemCotacao(seqItemCotacao);

		for (ItemCoberturaClausula item : itensParaInclusao) {
			itemCoberturaClausulaRepository.salvaItem(item);
		}
	}

	/**
	 * Salva as Clausulas Automáticas para um determinada Cotação
	 * 
	 * @param cotacao
	 */
	@LogPerformance
	public void salvaOuAtualizaClausulasAutomaticas(Cotacao cotacao,User user) {

		clausulaCotacaoRepository.excluiToddasClausulasAutomaticasDaCotacao(cotacao);
		itemRubricaClausulaRepository.excluiClausualasAutomaticasPorCotacao(cotacao);
		itemSistProtecionalClausulaRepository.exlcluiClausulasManuaisPorCotacao(cotacao);
		itemCoberturaClausulaRepository.excluiClausulasAutomaticasPorCotacao(cotacao);

		salvaClausulasAutomaticasDeCapa(cotacao,user);
		List<ItemCotacao> itensCotacaoSemExcluEndosso = listaItensSemExclusaoEndosso(cotacao);
		salvaClausulasAutomaticasDeRubrica(itensCotacaoSemExcluEndosso,user);
		salvaClausulasAutomaticasDeSistemasProtecionais(itensCotacaoSemExcluEndosso, user);
		salvaClausulasAutomaticasDeCobertura(itensCotacaoSemExcluEndosso, user);
	}

	/**
	 * Lista as Clausulas Nota automáticas para uma determinada Cotação
	 * 
	 * @param cotacao Cotação para a qual serão listadas as Clausulas Nota
	 * @return
	 */
	public List<ClausulaNota> listaClausulasCapaAutomaticas(Cotacao cotacao) {
		return listaClausulasCapa(cotacao,true);
	}

	/**
	 * Lista os Itens Sem Exclusao Endosso
	 * 
	 * @param cotacao
	 * @return
	 */
	private List<ItemCotacao> listaItensSemExclusaoEndosso(Cotacao cotacao) {
		List<ItemCotacao> itensCotacaoSemExcluEndosso = cotacao.getListItem()
				.stream()
				.filter(itemCotacao -> itemCotacao.getIdExclusaoEndosso().equals(SimNaoEnum.NAO))
				.collect(Collectors.toList());

		return itensCotacaoSemExcluEndosso;
	}

	/**
	 * Salva as cláusulas automática para um dada Cotacao
	 * 
	 * @param cotacao
	 */
	private void salvaClausulasAutomaticasDeCapa(Cotacao cotacao,User user) {
		List<ClausulaNota> clausulasNota = listaClausulasCapaAutomaticas(cotacao);
		List<ClausulaCotacao> clausulasCotacaoAutomatica = mapper.toListOfClausulaCotacaoAutomatica(clausulasNota,cotacao,user);

		for (ClausulaCotacao clausulaCotacao : clausulasCotacaoAutomatica) {
			clausulaCotacaoRepository.salva(clausulaCotacao);
		}
	}

	/**
	 * Salva as clausulas automáticas de rubrica para uma lista de ItemCotacao
	 * 
	 * @param itensCotacao
	 */
	private void salvaClausulasAutomaticasDeRubrica(Collection<ItemCotacao> itensCotacao,User user) {
		for (ItemCotacao itemCotacao : itensCotacao) {
			salvaClausulasAutomaticasDeRubrica(itemCotacao,user);
		}
	}

	/**
	 * Salva as cláusulas automáticas de rubrica para um ItemCotacao
	 * 
	 * @param itemCotacao
	 */
	private void salvaClausulasAutomaticasDeRubrica(ItemCotacao itemCotacao,User user) {
		List<ItemRubricaClausula> itensRubricaClausula = mapper.toClausulasAutomaticaDeRubrica(itemCotacao,user);
		for (ItemRubricaClausula item : itensRubricaClausula) {
			itemRubricaClausulaRepository.salva(item);
		}
	}

	/**
	 * Salva as cláusulas automática de sistemas protecionais para uma lista de ItemCotacao
	 * 
	 * @param itensCotacao
	 */
	private void salvaClausulasAutomaticasDeSistemasProtecionais(List<ItemCotacao> itensCotacao, User user) {
		for (ItemCotacao item : itensCotacao) {
			salvaClausulaAutomaticaDeSistemaProtecional(item, user);
		}
	}

	/**
	 * Salva as cláusulas automáticas de sistemas protecionais para um ItemCotacao
	 * 
	 * @param itemCotacao
	 */
	private void salvaClausulaAutomaticaDeSistemaProtecional(ItemCotacao itemCotacao, User user) {
		
		List<ItemSistemaProtecionalClausula> itensSistProtecClausula = mapper.toClausulaAutomaticaDeItemSistemaProtecionais(itemCotacao, user);

		for (ItemSistemaProtecionalClausula item : itensSistProtecClausula) {
			itemSistProtecionalClausulaRepository.salva(item);
		}

	}

	/**
	 * Salva as cláusulas automáticas de item de cobertura para uma lista de ItemCotacao
	 * 
	 * @param itensCotacao
	 */
	private void salvaClausulasAutomaticasDeCobertura(List<ItemCotacao> itensCotacao, User user) {
		for (ItemCotacao itemCotacao : itensCotacao) {
			salvaClausulasAutomaticasDeCobertura(itemCotacao, user);
		}
	}

	/**
	 * Salva as cláusulas automáticas de Item Cobertura para um ItemCotacao
	 * 
	 * @param itemCotacao
	 */
	private void salvaClausulasAutomaticasDeCobertura(ItemCotacao itemCotacao, User user) {
		List<ItemCoberturaClausula> itensCoberturaClausula = mapper.toClausulaAutomaticaDeItemCobertura(itemCotacao, user);

		for (ItemCoberturaClausula item : itensCoberturaClausula) {
			itemCoberturaClausulaRepository.salvaItem(item);
		}
	}

}
