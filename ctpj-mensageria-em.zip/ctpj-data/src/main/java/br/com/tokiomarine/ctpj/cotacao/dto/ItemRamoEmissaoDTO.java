package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemRamoEmissaoDTO implements Serializable {

	private static final long serialVersionUID = -8931836844889386994L;

	private Integer codigoGrupoRamo;
	private Integer codigoRamo;	
	private String processoSusep;
	private String complementoLmr;
	
	public ItemRamoEmissaoDTO() {
		/**
		 * Construtor Vazio
		 */
	}

	public ItemRamoEmissaoDTO(Integer codigoGrupoRamo, Integer codigoRamo, String processoSusep,
			String complementoLmr) {
		this.codigoGrupoRamo = codigoGrupoRamo;
		this.codigoRamo = codigoRamo;
		this.processoSusep = processoSusep;
		this.complementoLmr = complementoLmr;
	}

	public Integer getCodigoGrupoRamo() {
		return codigoGrupoRamo;
	}
	public void setCodigoGrupoRamo(Integer codigoGrupoRamo) {
		this.codigoGrupoRamo = codigoGrupoRamo;
	}
	public Integer getCodigoRamo() {
		return codigoRamo;
	}
	public void setCodigoRamo(Integer codigoRamo) {
		this.codigoRamo = codigoRamo;
	}
	public String getProcessoSusep() {
		return processoSusep;
	}
	public void setProcessoSusep(String processoSusep) {
		this.processoSusep = processoSusep;
	}
	public String getComplementoLmr() {
		return complementoLmr;
	}
	public void setComplementoLmr(String complementoLmr) {
		this.complementoLmr = complementoLmr;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigoGrupoRamo == null) ? 0 : codigoGrupoRamo.hashCode());
		result = prime * result + ((codigoRamo == null) ? 0 : codigoRamo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemRamoEmissaoDTO other = (ItemRamoEmissaoDTO) obj;
		if (codigoGrupoRamo == null) {
			if (other.codigoGrupoRamo != null)
				return false;
		} else if (!codigoGrupoRamo.equals(other.codigoGrupoRamo))
			return false;
		if (codigoRamo == null) {
			if (other.codigoRamo != null)
				return false;
		} else if (!codigoRamo.equals(other.codigoRamo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ItemRamoEmissaoDTO [codigoGrupoRamo=" + codigoGrupoRamo + ", codigoRamo=" + codigoRamo
				+ ", processoSusep=" + processoSusep + ", complementoLmr=" + complementoLmr + "]";
	}
	
	
}