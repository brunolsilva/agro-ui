package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.JurosParcelamentoCotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.FormaParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoJurosParcelamento;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class FormaParcelamentoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static Logger logger = LogManager.getLogger(FormaParcelamentoRepository.class);

	@LogPerformance
	public FormaParcelamento findFormaParcelamentoByCodigo(Integer codigo) throws RepositoryException {
		logger.info("Buscando Forma de parcelamento by codigo: " + codigo);
		try {
			return mongoTemplate.findOne(query(where("codigo").is(codigo)),FormaParcelamento.class);
		} catch (Exception e) {
			logger.error("Erro na busca do forma de parcelamento by codigo, codigo numero: " + codigo,e);
			throw new RepositoryException("Erro na busca do forma de parcelamento by codigo, codigo numero: " + codigo,e);
		}
	}

	@LogPerformance
	public FormaParcelamento findByFormaParcelamento(Integer formaParcelamento) {
		return mongoTemplate.findOne(
				query(
						where("codigo").is(formaParcelamento)),
				FormaParcelamento.class);
	}
	
	@LogPerformance
	public Map<Integer,FormaParcelamento> findFormaParcelamentoByJuros(List<JurosParcelamentoCotacao> juros) {
		List<FormaParcelamento> formas = mongoTemplate.find(
				query(
						where("codigo").in(
								juros.stream().map(JurosParcelamentoCotacao::getCodigoFormaParcelamento).collect(Collectors.toList()))
					),
				FormaParcelamento.class);

		return formas.stream().collect(Collectors.toMap(FormaParcelamento::getCodigo, Function.identity()));
	}
	
	@LogPerformance
	public Map<Integer,FormaParcelamento> findByFormaParcelamento(List<PerfilCalculoJurosParcelamento> formaParcelamento) {
		List<FormaParcelamento> formas = mongoTemplate.find(
				query(
						where("codigo").in(
								formaParcelamento.stream().map(PerfilCalculoJurosParcelamento::getFormaParcelamento).collect(Collectors.toList()))
					),
				FormaParcelamento.class);

		return formas.stream().collect(Collectors.toMap(FormaParcelamento::getCodigo, Function.identity()));
	}

	public Map<Integer, FormaParcelamento> findFormasParcelamentoByCodigo(List<Integer> codigos) {
		List<FormaParcelamento> formas = mongoTemplate.find(
				query(where("codigo").in(codigos)), FormaParcelamento.class);

		return formas.stream().collect(Collectors.toMap(FormaParcelamento::getCodigo, Function.identity()));
	}

	@LogPerformance
	public FormaParcelamento findByQuantidadeParcelas(Integer quantidadeParcelas, SimNaoEnum simNaoEnum) {
		return mongoTemplate.findOne(
				query(
						where("quantidadeParcelas").is(quantidadeParcelas)
						.and("entrada").is(simNaoEnum.getId())),
				FormaParcelamento.class);
	}
}