package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;

/**
 * @author Desconhecido
 */
public class RecebimentoView {

	private BigInteger sequencialRecebimento;
	private String tipoRecebimento;
	private String banco;
	private String agencia;
	private String conta;
	private String numeroFichaDeposito;
	private String dataCobranca;
	private String valorRecebimento;
	private String numeroApolice;
	private String numeroEndosso;
	private BigInteger sequencialCotacaoProposta;
	private Boolean creditoVinculado;

	public RecebimentoView() {

	}

	public RecebimentoView(
			BigInteger sequencialRecebimento,String tipoRecebimento,String banco,String agencia,String conta,
			String numeroFichaDeposito,String dataCobranca,String valorRecebimento,String numeroApolice,
			String numeroEndosso,BigInteger sequencialCotacaoProposta,Boolean creditoVinculado) {
		super();
		this.sequencialRecebimento = sequencialRecebimento;
		this.tipoRecebimento = tipoRecebimento;
		this.banco = banco;
		this.agencia = agencia;
		this.conta = conta;
		this.numeroFichaDeposito = numeroFichaDeposito;
		this.dataCobranca = dataCobranca;
		this.valorRecebimento = valorRecebimento;
		this.numeroApolice = numeroApolice;
		this.numeroEndosso = numeroEndosso;
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
		this.creditoVinculado = creditoVinculado;
	}

	public BigInteger getSequencialRecebimento() {
		return sequencialRecebimento;
	}

	public void setSequencialRecebimento(BigInteger sequencialRecebimento) {
		this.sequencialRecebimento = sequencialRecebimento;
	}

	public String getTipoRecebimento() {
		return tipoRecebimento;
	}

	public void setTipoRecebimento(String tipoRecebimento) {
		this.tipoRecebimento = tipoRecebimento;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getNumeroFichaDeposito() {
		return numeroFichaDeposito;
	}

	public void setNumeroFichaDeposito(String numeroFichaDeposito) {
		this.numeroFichaDeposito = numeroFichaDeposito;
	}

	public String getDataCobranca() {
		return dataCobranca;
	}

	public void setDataCobranca(String dataCobranca) {
		this.dataCobranca = dataCobranca;
	}

	public String getValorRecebimento() {
		return valorRecebimento;
	}

	public void setValorRecebimento(String valorRecebimento) {
		this.valorRecebimento = valorRecebimento;
	}

	public String getNumeroApolice() {
		return numeroApolice;
	}

	public void setNumeroApolice(String numeroApolice) {
		this.numeroApolice = numeroApolice;
	}

	public String getNumeroEndosso() {
		return numeroEndosso;
	}

	public void setNumeroEndosso(String numeroEndosso) {
		this.numeroEndosso = numeroEndosso;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	public Boolean getCreditoVinculado() {
		return creditoVinculado;
	}

	public void setCreditoVinculado(Boolean creditoVinculado) {
		this.creditoVinculado = creditoVinculado;
	}

}
