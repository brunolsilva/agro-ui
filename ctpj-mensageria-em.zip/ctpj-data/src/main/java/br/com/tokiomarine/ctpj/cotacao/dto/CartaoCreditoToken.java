package br.com.tokiomarine.ctpj.cotacao.dto;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class CartaoCreditoToken {

	private String token;
	private String cartaoTruncado;

	public CartaoCreditoToken(String token, String cartaoTruncado) {
		this.token = token;
		this.cartaoTruncado = cartaoTruncado;
	}

	public String getToken() {
		return this.token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getCartaoTruncado() {
		return this.cartaoTruncado;
	}

	public void setCartaoTruncado(String cartaoTruncado) {
		this.cartaoTruncado = cartaoTruncado;
	}

	public String toString() {
		return new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE).append("token", this.token)
				.append("cartaoTruncado", this.cartaoTruncado).append("transacao").build();
	}
}