package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SublimiteView implements Serializable {

	private static final long serialVersionUID = -19538552238412192L;

	private BigInteger numeroItem;
	private Integer codigoCobertura;
	private Integer coberturaPrincipal;
	private BigDecimal valorSublimite;
	private BigInteger sequencialItemCotacao;
	private BigInteger sequencialItemCobertura;
	private BigInteger sequencialCotacaoProposta;
	private String descricaoCobertura;
	private BigDecimal valorRiscoBem;
	private BigDecimal valorImportanciaSegurada;
	private BigDecimal valorSublimiteOriginal;
	private boolean coberturaExcluida = false;
	private Integer idTipoCobertura;
	private List<BigInteger> items;
	private SimNaoEnum idSublimiteInformado;
	private boolean liberaSublimite = true;
	private SimNaoEnum idExclusaEndosso = SimNaoEnum.NAO;

	public SublimiteView() {
		/**
		 * Construtor Vazio
		 */
	}

	public SublimiteView(BigInteger numeroItem, Integer codigoCobertura, BigInteger sequencialItemCotacao) {
		this.numeroItem = numeroItem;
		this.codigoCobertura = codigoCobertura;
		this.sequencialItemCotacao = sequencialItemCotacao;
		this.coberturaExcluida = true;
	}

	public BigInteger getNumeroItem() {
		return numeroItem;
	}

	public void setNumeroItem(BigInteger numeroItem) {
		this.numeroItem = numeroItem;
	}

	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}

	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}

	public Integer getCoberturaPrincipal() {
		return coberturaPrincipal;
	}

	public void setCoberturaPrincipal(Integer coberturaPrincipal) {
		this.coberturaPrincipal = coberturaPrincipal;
	}

	public BigDecimal getValorSublimite() {
		return valorSublimite;
	}

	public void setValorSublimite(BigDecimal valorSublimite) {
		this.valorSublimite = valorSublimite;
	}

	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}

	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}

	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}

	public BigDecimal getValorRiscoBem() {
		return valorRiscoBem;
	}

	public void setValorRiscoBem(BigDecimal valorRiscoBem) {
		this.valorRiscoBem = valorRiscoBem;
	}

	public BigDecimal getValorImportanciaSegurada() {
		return valorImportanciaSegurada;
	}

	public void setValorImportanciaSegurada(BigDecimal valorImportanciaSegurada) {
		this.valorImportanciaSegurada = valorImportanciaSegurada;
	}

	public BigDecimal getValorSublimiteOriginal() {
		return valorSublimiteOriginal;
	}

	public void setValorSublimiteOriginal(BigDecimal valorSublimiteOriginal) {
		this.valorSublimiteOriginal = valorSublimiteOriginal;
	}

	public BigInteger getSequencialItemCobertura() {
		return sequencialItemCobertura;
	}

	public void setSequencialItemCobertura(BigInteger sequencialItemCobertura) {
		this.sequencialItemCobertura = sequencialItemCobertura;
	}

	public boolean isCoberturaExcluida() {
		return coberturaExcluida;
	}

	public void setCoberturaExcluida(boolean coberturaExcluida) {
		this.coberturaExcluida = coberturaExcluida;
	}

	public Integer getIdTipoCobertura() {
		return idTipoCobertura;
	}

	public void setIdTipoCobertura(Integer idTipoCobertura) {
		this.idTipoCobertura = idTipoCobertura;
	}

	public SimNaoEnum getIdSublimiteInformado() {
		return idSublimiteInformado;
	}

	public void setIdSublimiteInformado(SimNaoEnum idSublimiteInformado) {
		this.idSublimiteInformado = idSublimiteInformado;
	}

	public boolean isLiberaSublimite() {
		return liberaSublimite;
	}

	public void setLiberaSublimite(boolean liberaSublimite) {
		this.liberaSublimite = liberaSublimite;
	}

	public SimNaoEnum getIdExclusaEndosso() {
		return idExclusaEndosso;
	}

	public void setIdExclusaEndosso(SimNaoEnum idExclusaEndosso) {
		this.idExclusaEndosso = idExclusaEndosso;
	}

	public List<BigInteger> getItems() {
		return items;
	}

	public void setItems(List<BigInteger> items) {
		this.items = items;
	}
}