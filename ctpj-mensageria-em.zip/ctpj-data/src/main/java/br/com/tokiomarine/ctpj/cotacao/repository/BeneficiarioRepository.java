package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;

/**
 * Repositório para entidade ItemBeneficiario e entidades relacionadas
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Repository
public class BeneficiarioRepository extends BaseDAO{

	private static final String BUSCA_ITENS_BENEFICIARIO_HQL = 
			"select itemBenef " +
			"from ItemBeneficiario itemBenef " + 
				"join itemBenef.itemCotacao itemCot " +	
				"join itemCot.cotacao cot " +
			"where " +
				"cot.sequencialCotacaoProposta = :seqCotacao ";
	
	private static String BUSCA_ITENS_BENEFICIARIO_ASC_HQL =  
			BUSCA_ITENS_BENEFICIARIO_HQL +
			"order by itemBenef.numeroBeneficiario ASC ";
	
	private static final String PROX_NRO_BENEFICIARIO_HQL = 
			BUSCA_ITENS_BENEFICIARIO_HQL + 
			"order by itemBenef.numeroBeneficiario DESC ";
	
	private static final String EXCLUI_ITENS_BENEFICIARIO_POR_COTACAO = 
			"delete from ItemBeneficiario ib " +
			"where ib in (" + BUSCA_ITENS_BENEFICIARIO_HQL + ")";
	
	public BigInteger proximoNroBeneficiario(BigInteger sequencialCotacaoProposta){
		Query query = getCurrentSession().createQuery(PROX_NRO_BENEFICIARIO_HQL);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		query.setMaxResults(1);
		
		ItemBeneficiario result = (ItemBeneficiario) query.uniqueResult();
		
		if(result == null)
			return BigInteger.ONE;
		
		return result.getNumeroBeneficiario().add(BigInteger.ONE);
	}
	
	/**
	 * Salva um novo ItemBeneficiario
	 * 
	 * @param item item a ser salvo
	 * @return item atualizado com a chave primária criada
	 */
	@LogPerformance
	public ItemBeneficiario salvaItemBeneficiario(ItemBeneficiario item){
		getCurrentSession().persist(item);
		
		return item;
	}
	
	@LogPerformance
	public List<ItemBeneficiario> salvaItemBeneficiario(List<ItemBeneficiario> itens){
		itens.forEach(item -> salvaItemBeneficiario(item));
		return itens;
	}
	
	/**
	 * Lista os Itens Beneficiário
	 * 
	 * @param sequencialCotacaoProposta Identificação da cotação para o qual os itens serão listados
	 * @return
	 */
	@LogPerformance
	@SuppressWarnings("unchecked")
	public List<ItemBeneficiario> listaItensBeneficiario(BigInteger seqCotacao){
		List<ItemBeneficiario> itens = getCurrentSession().createQuery(BUSCA_ITENS_BENEFICIARIO_ASC_HQL).setParameter("seqCotacao", seqCotacao).list();
		return itens;
	}

	@LogPerformance
	public void excluiItemBeneficiario(BigInteger sequencialItemBeneficiario) {
		ItemBeneficiario itemParaExclusao = new ItemBeneficiario();
		itemParaExclusao.setSequencialItemBeneficiario(sequencialItemBeneficiario);
		
		getCurrentSession().delete(itemParaExclusao);		
	}	
	
	public int excluiItemBeneficiarioPorCotacao(BigInteger seqCotacao){
		int nroItensExcluidos = getCurrentSession()
		.createQuery(EXCLUI_ITENS_BENEFICIARIO_POR_COTACAO)
		.setParameter("seqCotacao", seqCotacao)
		.executeUpdate();
		
		return nroItensExcluidos;
	}
}
