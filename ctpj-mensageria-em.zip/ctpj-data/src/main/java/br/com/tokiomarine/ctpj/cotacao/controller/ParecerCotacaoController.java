package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.ParecerView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.ParecerCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

@RequestMapping(value = "/parecer")
@Controller
public class ParecerCotacaoController extends AbstractController {
	
	private static Logger logger= LogManager.getLogger(ParecerCotacaoController.class);
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired	
	private ParecerCotacaoService parecerCotacaoService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;
	
	@LogPerformance
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String index(@PathVariable BigInteger sequencialCotacaoProposta, Model model) {
		try {
			logger.info("parecer.....");
			Cotacao cotacao = cotacaoService.findCotacaoPareceres(sequencialCotacaoProposta);
			List<ParecerView> pareceres = parecerCotacaoService.getListParecerView(cotacao);
			model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(cotacao.getSequencialCotacaoProposta()));
			model.addAttribute("cotacao", cotacao);
			model.addAttribute("pareceres", pareceres);
			model.addAttribute("readOnly",isReadOnlyParecer(cotacao));
			logger.info(isReadOnlyParecer(cotacao));
		} catch (Exception e) {
			logger.error("Erro ao recuperar as Pareceres da Cotacao ", e);
			return Paginas.error.value();
		}
		
		return Paginas.parecer.value();
	}
	
	@LogPerformance
	@PostMapping(value = "/salvar")
	public ResponseEntity<ResultadoREST<ParecerView>> salvar(@RequestBody ParecerView parecer) {

		logger.info("Inicio salvar Parecer da Cotação");

		ResultadoREST<ParecerView> resultado = new ResultadoREST<ParecerView>();

		try {
			parecerCotacaoService.saveParecer(parecer);
			resultado.setMensagem("Parecer da Cotação incluido com Sucesso!");
			resultado.setSuccess(true);
			
		} catch(Exception e) {
			logger.error("Erro do incluir Parecer Cotação ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}

		logger.info("Fim do incluir Parecer Cotação");

		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}
	
	@LogPerformance
	@GetMapping(value = "/delete/{sequencialParecerCotacao}")
	public ResponseEntity<ResultadoREST<String>> delete(@PathVariable BigInteger sequencialParecerCotacao) {

		logger.info("Inicio delete Parecer da Cotação");

		ResultadoREST<String> resultado = new ResultadoREST<String>();

		try {
			parecerCotacaoService.deleteParecerCotacao(sequencialParecerCotacao);
			resultado.setMensagem("Parecer da Cotação excluido com Sucesso!");
			resultado.setSuccess(true);
		} catch(Exception e) {
			logger.error("Erro do incluir Parecer Cotação ", e);
			resultado.setSuccess(false);
			return new ResponseEntity<>(resultado, HttpStatus.BAD_REQUEST);
		}

		logger.info("Fim do delete Parecer Cotação");

		return new ResponseEntity<>(resultado, HttpStatus.OK);
	}

	/**
	 * O parecer é liberado se a cotação está em emissão ou num estado onde pode ter alteração
	 * @param cotacao
	 * @return boolean se é somente leitura
	 */
	private boolean isReadOnlyParecer(Cotacao cotacao) {
		GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
		try {
			if(perfilComercialService.hasPerfilComercial(grupoUsuario)) {
				return true;
			}
		} catch (ServiceException e) {
			logger.error("Ocorreu um erro ao verificar se é usuário do comercial:" + e.getMessage());
		}
		
		if(cotacao.getCodigoSituacao().equals(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue())
				|| cotacao.getCodigoSituacao().equals(CodigoSituacaoEnum.ERRO_NA_GRADE_486.getSituacao().intValue())) {
			return false;
		}
		return CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly();
		
	}
}
