package br.com.tokiomarine.ctpj.integracao.cliente.formadevolucao;

import java.util.EnumMap;
import java.util.Optional;

import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;

public class FormaDevolucaoFactory {
	private FormaDevolucaoFactory() {
	}

	static EnumMap<FormaDevolucaoApoliceEnum, CadastroFormaDevolucao> formaDevolucaoMap = new EnumMap<>(
			FormaDevolucaoApoliceEnum.class);
	static {
		formaDevolucaoMap.put(FormaDevolucaoApoliceEnum.CHEQUE, new CadastroFormaDevolucaoCheque());
		formaDevolucaoMap.put(FormaDevolucaoApoliceEnum.CREDITO_CONTA, new CadastroFormaDevolucaoCreditoEmConta());
		formaDevolucaoMap.put(FormaDevolucaoApoliceEnum.RECIBO, new CadastroFormaDevolucaoRecibo());
	}

	public static Optional<CadastroFormaDevolucao> getFormaDevolucao(FormaDevolucaoApoliceEnum formaDevolucao) {
		return Optional.ofNullable(formaDevolucaoMap.get(formaDevolucao));
	}
}
