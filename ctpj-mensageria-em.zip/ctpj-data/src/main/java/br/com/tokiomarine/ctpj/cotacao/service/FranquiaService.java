package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaEFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemEquipamentoFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.FranquiaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Equipamento;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCoberturaEquipamento;
import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.EquipamentoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoCoberturaEquipamentoRepository;
import br.com.tokiomarine.ctpj.mapper.CoberturaEFranquiaViewMapper;
import br.com.tokiomarine.ctpj.mapper.FranquiaMapper;
import br.com.tokiomarine.ctpj.mapper.ItemEquipamentoFranquiaMapper;
import br.com.tokiomarine.ctpj.mapper.NumberMapper;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.ctpj.util.StringUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class FranquiaService {

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private FranquiaRepository franquiaRepository;

	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;

	@Autowired
	private ProdutoCoberturaEquipamentoRepository produtoCoberturaEquipamentoRepository;

	@Autowired
	private EquipamentoRepository equipamentoRepository;

	private static Logger logger = LogManager.getLogger(FranquiaService.class);

	private static final int PRODUTO_RN_1 = 9650;
	private static final int PRODUTO_RN_2 = 9651;
	private static final int PRODUTO_RN_3 = 1860;
	private static final int PRODUTO_RN_4 = 1861;
	private static final int COBERTURA_DANOS_ELETRICOS = 19;
	private static final int COBERTURA_QUEBRA_DE_MAQUINAS = 78;
	private static final int COBERTURA_DANOS_ELETRICOS2 = 538;
	private static final int COBERTURA_QUEBRA_DE_MAQUINAS2 = 605;

	@LogPerformance
	public List<ItemCotacao> getItemsComEndereco(BigInteger sqCotacao) throws ServiceException {
		try {
			List<ItemCotacao> items = cotacaoRepository.getItemsComEndereco(sqCotacao);
			if(items != null && !items.isEmpty()) {
				if(items.get(0).getCotacao().getIdTipoEndosso() != null) {
					return items.stream()
							.filter(it -> Arrays.asList(1,6).contains(it.getIdTipoEndosso()))
							.collect(Collectors.toList());
				}
			}
			return items; 
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public List<ItemCoberturaFranquiaView> findDadosFranquia(BigInteger sqItemCotacao,BigInteger sqCotac,Integer codigoProduto) throws ServiceException {
		List<ItemCoberturaFranquiaView> list = new ArrayList<>();
		try {
			if (sqItemCotacao != null && !sqItemCotacao.equals(BigInteger.valueOf(-1))) {
				list = this.findDadosFranquiaByItem(sqItemCotacao);
			} else if (sqCotac != null) {
				list = this.findDadosFranquiaByCotacao(sqCotac);
				System.out.println("a" + isProdutoPermiteInformarFranquiaEquipamento(codigoProduto));
				if (isProdutoPermiteInformarFranquiaEquipamento(codigoProduto)) {
					this.getEquipamentosByProdutoCobertura(list,codigoProduto);
				}
			}
			return list;
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public List<ItemCoberturaFranquiaView> findDadosFranquiaByCotacao(BigInteger sqCotac) throws ServiceException {
		List<ItemCoberturaFranquiaView> list = new ArrayList<>();
		List<Object[]> coberturas = franquiaRepository.findCoberturasByCotacao(sqCotac);

		for (int i = 0 ; i < coberturas.size() ; i++) {
			ItemCoberturaFranquiaView item = new ItemCoberturaFranquiaView();
			item.setSequencialItemCobertura(BigInteger.valueOf(i));
			item.setCodigoCobertura((Integer) coberturas.get(i)[0]);
			item.setDescricaoCobertura((String) coberturas.get(i)[1]);
			item.setNumeroCotacaoProposta((BigInteger) coberturas.get(i)[2]);
			item.setVersaoCotacaoProposta((Integer) coberturas.get(i)[3]);
			list.add(item);
		}

		return list;
	}

	@LogPerformance
	public List<ItemCoberturaFranquiaView> findDadosFranquiaByItem(BigInteger sqItemCotacao) throws ServiceException {
		List<ItemCoberturaFranquiaView> list = new ArrayList<>();
		try {
			List<ItemCobertura> coberturas = franquiaRepository.findDadosFranquiaByItem(sqItemCotacao);
			list = FranquiaMapper.INSTANCE.toFranquia(coberturas);

			ItemCotacao itemCotacao = cotacaoRepository.findItem(sqItemCotacao);
			if (isProdutoPermiteInformarFranquiaEquipamento(itemCotacao.getCotacao().getCodigoProduto())) {
				list = this.getEquipamentosByItemCobertura(list,itemCotacao);
			}

			return list;
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	public List<CoberturaEFranquiaView> findCoberturasEFranquiasPorCotacao(BigInteger seqCotacao){
		List<ItemCobertura> itens = franquiaRepository.buscaCoberturasPorCotacao(seqCotacao);	
		return CoberturaEFranquiaViewMapper
				.toListOfCoberturaEFranquiaView(itens).stream()
				.distinct()
				.sorted((a, b)-> a.getItemCotacao().compareTo(b.getItemCotacao()))
				.collect(Collectors.toList());
	}
	
	public List<CoberturaEFranquiaView> findCoberturasEFranquiasPorItemCotacao(BigInteger seqItemCotacao) throws ServiceException{
		try {
			List<ItemCobertura> itens = franquiaRepository.findDadosFranquiaByItem(seqItemCotacao);
			return CoberturaEFranquiaViewMapper.toListOfCoberturaEFranquiaView(itens);
		} catch (RepositoryException e) {
			throw new ServiceException(e);
		}
		
	}

	private Boolean isProdutoPermiteInformarFranquiaEquipamento(Integer codigoProduto) throws RepositoryException {
		if (Arrays.asList(
				PRODUTO_RN_1,
				PRODUTO_RN_2,
				PRODUTO_RN_3,
				PRODUTO_RN_4).contains(codigoProduto)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	private Boolean isCoberturaPermiteInformarFranquiaEquipamento(Integer codigoCobertura) throws RepositoryException {
		if (codigoCobertura == COBERTURA_DANOS_ELETRICOS
				|| codigoCobertura == COBERTURA_QUEBRA_DE_MAQUINAS
				|| codigoCobertura == COBERTURA_DANOS_ELETRICOS2
				|| codigoCobertura == COBERTURA_QUEBRA_DE_MAQUINAS2) { 
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	private List<ItemCoberturaFranquiaView> getEquipamentosByItemCobertura(List<ItemCoberturaFranquiaView> coberturas,ItemCotacao itemCotacao) throws RepositoryException {
		for (ItemCoberturaFranquiaView itemCobertura : coberturas) {
			System.out.println("AAA " + isCoberturaPermiteInformarFranquiaEquipamento(itemCobertura.getCodigoCobertura()));
			if (isCoberturaPermiteInformarFranquiaEquipamento(itemCobertura.getCodigoCobertura())) {
				List<ProdutoCoberturaEquipamento> listprodutoCoberturaEquipamento = produtoCoberturaEquipamentoRepository.findEquipamentoByProdutoCobertura(itemCotacao,itemCobertura);
				for (ProdutoCoberturaEquipamento produtoCoberturaEquipamento : listprodutoCoberturaEquipamento) {
					Equipamento equipamento = equipamentoRepository.findByCodigo(produtoCoberturaEquipamento.getEquipamento());
					if (itemCobertura.getListItemEquipamentoFranquia() == null || !itemCobertura.getListItemEquipamentoFranquia().stream().filter(f -> f.getCodigoEquipamento().intValue() == equipamento.getCodigo().intValue()).findFirst().isPresent()) {
						ItemEquipamentoFranquiaView itemEquipamentoFranquia = new ItemEquipamentoFranquiaView();
						itemEquipamentoFranquia.setCodigoEquipamento(BigInteger.valueOf(equipamento.getCodigo().intValue()));
						itemEquipamentoFranquia.setDescricaoEquipamento(equipamento.getDescricao());
						itemEquipamentoFranquia.setSequencialItemCobertura(itemCobertura.getSequencialItemCobertura());
						itemCobertura.getListItemEquipamentoFranquia().add(itemEquipamentoFranquia);
					}
				}
			}
		}
		for (ItemCoberturaFranquiaView itemCobertura : coberturas) {
			if (itemCobertura.getListItemEquipamentoFranquia() != null && !itemCobertura.getListItemEquipamentoFranquia().isEmpty()) {
				itemCobertura.setListItemEquipamentoFranquia(itemCobertura.getListItemEquipamentoFranquia().stream().sorted((e1,e2) -> e1.getDescricaoEquipamento().compareTo(e2.getDescricaoEquipamento())).collect(Collectors.toList()));
			}
		}
		return coberturas;
	}

	private List<ItemCoberturaFranquiaView> getEquipamentosByProdutoCobertura(List<ItemCoberturaFranquiaView> coberturas,Integer codigoProduto) throws RepositoryException {
		for (ItemCoberturaFranquiaView itemCobertura : coberturas) {
			System.out.println("BBB " + isCoberturaPermiteInformarFranquiaEquipamento(itemCobertura.getCodigoCobertura()));
			if (isCoberturaPermiteInformarFranquiaEquipamento(itemCobertura.getCodigoCobertura())) {
				List<Integer> list = produtoCoberturaEquipamentoRepository.findEquipamentoByProdutoCoberturaDistinct(codigoProduto,itemCobertura);
				for (Integer equipamento2 : list) {
					Equipamento equipamento = equipamentoRepository.findByCodigo(equipamento2);
					if (itemCobertura.getListItemEquipamentoFranquia() == null || !itemCobertura.getListItemEquipamentoFranquia().stream().filter(f -> f.getCodigoEquipamento().intValue() == equipamento.getCodigo().intValue()).findFirst().isPresent()) {
						ItemEquipamentoFranquiaView itemEquipamentoFranquia = new ItemEquipamentoFranquiaView();
						itemEquipamentoFranquia.setCodigoEquipamento(BigInteger.valueOf(equipamento.getCodigo().intValue()));
						itemEquipamentoFranquia.setDescricaoEquipamento(equipamento.getDescricao());
						itemEquipamentoFranquia.setSequencialItemCobertura(itemCobertura.getSequencialItemCobertura());
						itemCobertura.getListItemEquipamentoFranquia().add(itemEquipamentoFranquia);
					}
				}

			}
		}

		for (ItemCoberturaFranquiaView itemCobertura : coberturas) {
			if (itemCobertura.getListItemEquipamentoFranquia() != null && !itemCobertura.getListItemEquipamentoFranquia().isEmpty()) {
				itemCobertura.setListItemEquipamentoFranquia(itemCobertura.getListItemEquipamentoFranquia().stream().sorted((e1,e2) -> e1.getDescricaoEquipamento().compareTo(e2.getDescricaoEquipamento())).collect(Collectors.toList()));
			}
		}

		return coberturas;
	}

	/**
	 * TODO AJUSTA PARA TODAS AS COTAÇÔES
	 * 
	 * @param franquias
	 * @param itemAitemOrTodosItens
	 * @param sqCotacao
	 * @return
	 * @throws ServiceException
	 */
	@LogPerformance
	public ResultadoREST<ItemCoberturaFranquiaView> verificaSalvaTodosItensOrItemAItem(List<ItemCoberturaFranquiaView> franquias,Long itemAitemOrTodosItens,BigInteger sqCotacao) throws ServiceException {

		ResultadoREST<ItemCoberturaFranquiaView> resultado = new ResultadoREST<>();

		logger.info("FranquiaService.verificaSalvaTodosItensOrItemAItem ");

		try {

			if (itemAitemOrTodosItens == 1) {

				logger.info("Todos os item");

				resultado = this.validaDadosTodosItens(franquias);

				if (resultado.getListaValidacaoLote().isEmpty()) {

					if(logger.isDebugEnabled()){
						logger.debug("Antes: " + JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(franquias));
					}

					List<ItemCoberturaFranquiaView> listFranquiasAll = populaItemCoberturaFranquiaViewTodosItens(franquias,sqCotacao);
					this.saveDadosFranquiaTodosItens(listFranquiasAll,sqCotacao);
					resultado.setSuccess(true);
				} else {
					resultado.setSuccess(false);
				}

			} else {
				logger.info("item a item");

				resultado = this.validaDados(franquias,itemAitemOrTodosItens);

				if (resultado.getListaValidacaoLote().isEmpty()) {

					this.saveDadosFranquia(franquias,sqCotacao);
					resultado.setSuccess(true);
				} else {
					resultado.setSuccess(false);
				}
			}

		} catch (Exception e) {
			throw new ServiceException(e.getMessage(),e);
		}

		return resultado;
	}

	private List<ItemCoberturaFranquiaView> populaItemCoberturaFranquiaViewTodosItens(List<ItemCoberturaFranquiaView> franquiasTodosItens,BigInteger sqCotacao) throws ServiceException {

		List<ItemCoberturaFranquiaView> franquiasTodosItensNew = new ArrayList<>();
		List<ItemEquipamentoFranquiaView> equipamentosFranquiaView = new ArrayList<>();
		List<ItemEquipamentoFranquiaView> equipamentosFranquiaDeleteView = new ArrayList<>();

		try {

			List<ItemCotacao> listItensCotacao = this.getItemsComEndereco(sqCotacao);

			for (Iterator<ItemCotacao> itemIterator = listItensCotacao.iterator() ; itemIterator.hasNext() ;) {
				ItemCotacao itemCotacao = itemIterator.next();

				for (Iterator<ItemCobertura> itemCoberturaIterator = itemCotacao.getListItemCobertura().iterator() ; itemCoberturaIterator.hasNext() ;) {
					ItemCobertura itemCobertura = itemCoberturaIterator.next();

					for (Iterator<ItemCoberturaFranquiaView> itemCoberturaFranquiaViewIterator = franquiasTodosItens.iterator() ; itemCoberturaFranquiaViewIterator.hasNext() ;) {
						ItemCoberturaFranquiaView franquiaViewOld = itemCoberturaFranquiaViewIterator.next();

						ItemCoberturaFranquiaView franquiaViewNew = FranquiaMapper.INSTANCE.toFranquiaView(franquiaViewOld);

						equipamentosFranquiaView = new ArrayList<>();
						equipamentosFranquiaDeleteView = new ArrayList<>();

						if (itemCobertura.getCodigoCobertura().equals(franquiaViewNew.getCodigoCobertura())) {

							franquiaViewNew.setSequencialItemCotacao(itemCotacao.getSequencialItemCotacao());

							if (franquiaViewNew.getIdFormaFranquia() != null) {
								franquiaViewNew.setSequencialItemCobertura(itemCobertura.getSequencialItemCobertura());
							}

							if (franquiaViewNew.getListItemEquipamentoFranquia() != null && !franquiaViewNew.getListItemEquipamentoFranquia().isEmpty()) {

								for (Iterator<ItemEquipamentoFranquiaView> itemEquipamentoFranquiaViewIterator = franquiaViewOld.getListItemEquipamentoFranquia().iterator() ; itemEquipamentoFranquiaViewIterator.hasNext() ;) {
									ItemEquipamentoFranquiaView equipamentoFranquiaViewOld = itemEquipamentoFranquiaViewIterator.next();

									ItemEquipamentoFranquiaView equipamentoFranquiaViewNew = ItemEquipamentoFranquiaMapper.INSTANCE.toEquipamentoFranquiaView(equipamentoFranquiaViewOld);
									equipamentoFranquiaViewNew.setSequencialItemCobertura(itemCobertura.getSequencialItemCobertura());
									equipamentoFranquiaViewNew.setSequencialItemCotacao(itemCotacao.getSequencialItemCotacao());

									if (equipamentoFranquiaViewNew.getIdFormaFranquia() != null && !equipamentoFranquiaViewNew.isDeleteItem()) {

										if (itemCobertura.getListItemEquipamentoFranquia() != null && !itemCobertura.getListItemEquipamentoFranquia().isEmpty()) {

											for (Iterator<ItemEquipamentoFranquia> itemEquipamentoFranquiaIterator = itemCobertura.getListItemEquipamentoFranquia().iterator() ; itemEquipamentoFranquiaIterator.hasNext() ;) {
												ItemEquipamentoFranquia itemEquipamentoFranquia = itemEquipamentoFranquiaIterator.next();

												if (itemEquipamentoFranquia.getCodigoEquipamento().equals(equipamentoFranquiaViewNew.getCodigoEquipamento())) {
													equipamentoFranquiaViewNew.setSequencialItemEquipamantoFranquia(itemEquipamentoFranquia.getSequencialItemEquipamantoFranquia());
													break;
												}

											}

										}
									}

									if (equipamentoFranquiaViewNew.isDeleteItem()) {
										equipamentosFranquiaDeleteView.add(equipamentoFranquiaViewNew);
									} else {
										equipamentosFranquiaView.add(equipamentoFranquiaViewNew);
									}

								}

								franquiaViewNew.setListItemEquipamentoFranquia(equipamentosFranquiaView);
								franquiaViewNew.setListItemEquipamentoFranquiaDelete(equipamentosFranquiaDeleteView);

								// Filtro de equipamentos
							}

							franquiaViewNew.setListItemEquipamentoFranquia(this.populaItensEquipamentos(franquiaViewNew,itemCotacao));

							franquiasTodosItensNew.add(franquiaViewNew);
						}
					}
				}
			}
			
			if(logger.isDebugEnabled()){
				logger.info("Depois: " + JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(franquiasTodosItensNew));
			}
			

		} catch (Exception e) {
			throw new ServiceException(e.getMessage(),e);
		}

		return franquiasTodosItensNew;
	}

	private List<ItemEquipamentoFranquiaView> populaItensEquipamentos(ItemCoberturaFranquiaView franquia,ItemCotacao itemCotacao) throws ServiceException {
		try {
			List<ProdutoCoberturaEquipamento> listprodutoCoberturaEquipamento = produtoCoberturaEquipamentoRepository.findEquipamentoByProdutoCobertura(itemCotacao,franquia);

			for (Iterator<ItemEquipamentoFranquiaView> equipamentoIterator = franquia.getListItemEquipamentoFranquia().iterator() ; equipamentoIterator.hasNext() ;) {
				ItemEquipamentoFranquiaView itemEquipamentoFranquiaView = (ItemEquipamentoFranquiaView) equipamentoIterator.next();

				Optional<ProdutoCoberturaEquipamento> exist = listprodutoCoberturaEquipamento.stream().filter(e -> e.getEquipamento().equals(itemEquipamentoFranquiaView.getCodigoEquipamento().intValue())).findFirst();
				if (!exist.isPresent()) {
					equipamentoIterator.remove();
					franquia.getListItemEquipamentoFranquia().remove(itemEquipamentoFranquiaView);
				}
			}
		} catch (Exception e) {
			throw new ServiceException(e.getMessage(),e);
		}
		return franquia.getListItemEquipamentoFranquia();
	}

	@LogPerformance
	public void saveDadosFranquia(List<ItemCoberturaFranquiaView> franquias,BigInteger sqCotacao) throws ServiceException {
		try {
			List<BigInteger> idsCobertura = franquias.stream().map(ItemCoberturaFranquiaView::getSequencialItemCobertura).collect(Collectors.toList());

			List<ItemCobertura> coberturas = itemCoberturaRepository.getCoberturasById(idsCobertura);

			for (ItemCobertura cobertura : coberturas) {

				Optional<ItemCoberturaFranquiaView> franquia = franquias.stream().filter(f -> f.getSequencialItemCobertura().equals(cobertura.getSequencialItemCobertura())).findFirst();
				if (franquia.isPresent()) {

					List<BigDecimal> valoresPreFloat = new ArrayList<>();
					List<Integer> valoresPre = new ArrayList<>();
					List<BigDecimal> valoresPosFloat = new ArrayList<>();
					List<Integer> valoresPos = new ArrayList<>();

					valoresPre.add(cobertura.getNumeroHorasFranquia());
					valoresPre.add(cobertura.getNumeroDiasFranquia());

					valoresPreFloat.add(cobertura.getTaxaFranquia());
					valoresPreFloat.add(cobertura.getValorFranquia());
					valoresPreFloat.add(cobertura.getValorFranquiaMinima());
					valoresPreFloat.add(cobertura.getValorFranquiaMaxima());
					valoresPreFloat.add(cobertura.getTaxaImportanciaSegurada());
					valoresPreFloat.add(cobertura.getTaxaImportanciaSeguradaMinima());
					valoresPreFloat.add(cobertura.getTaxaImportanciaSeguradaMaxima());

					FranquiaMapper.INSTANCE.toCobertura(franquia.get(),cobertura);

					valoresPos.add(cobertura.getNumeroHorasFranquia());
					valoresPos.add(cobertura.getNumeroDiasFranquia());

					valoresPosFloat.add(cobertura.getTaxaFranquia());
					valoresPosFloat.add(cobertura.getValorFranquia());
					valoresPosFloat.add(cobertura.getValorFranquiaMinima());
					valoresPosFloat.add(cobertura.getValorFranquiaMaxima());
					valoresPosFloat.add(cobertura.getTaxaImportanciaSegurada());
					valoresPosFloat.add(cobertura.getTaxaImportanciaSeguradaMinima());
					valoresPosFloat.add(cobertura.getTaxaImportanciaSeguradaMaxima());

					for (int i = 0 ; i < valoresPre.size() ; i++) {
						if (valoresPre.get(i) != null && valoresPos.get(i) != null) {
							if (!valoresPre.get(i).equals(valoresPos.get(i))) {
								cobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
							}
						} else if (valoresPre.get(i) == null ^ valoresPos.get(i) == null) {
							cobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
						}
					}

					for (int i = 0 ; i < valoresPreFloat.size() ; i++) {
						if (valoresPreFloat.get(i) != null && valoresPosFloat.get(i) != null) {
							if (valoresPreFloat.get(i).compareTo(valoresPosFloat.get(i)) != 0) {
								cobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
							}
						} else if (valoresPreFloat.get(i) == null ^ valoresPosFloat.get(i) == null) {
							cobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
						}
					}
				}
			}
			franquiaRepository.saveDadosFranquia(coberturas);
			this.deleteItemEquipamentoFranquia(franquias,coberturas);
		} catch (Exception e) {
			logger.error("Erro ao salvar os dados da franquia ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public void saveDadosFranquiaTodosItens(List<ItemCoberturaFranquiaView> franquias,BigInteger sqCotacao) throws ServiceException {
		try {
			NumberMapper numberMapper = new NumberMapper();

			List<ItemCobertura> coberturas = itemCoberturaRepository.getCoberturasBySequencialItemCotacao(sqCotacao);

			for (Iterator<ItemCobertura> iteratorCobertura = coberturas.iterator() ; iteratorCobertura.hasNext() ;) {
				ItemCobertura itemCobertura = (ItemCobertura) iteratorCobertura.next();

				ItemCoberturaFranquiaView franquiaView = this.findItemCoberturaView(itemCobertura,franquias);

				if (franquiaView != null && franquiaView.getIdFormaFranquia() != null) {
					
					List<BigDecimal> valoresPreFloat = new ArrayList<>();
					List<Integer> valoresPre = new ArrayList<>();
					List<BigDecimal> valoresPosFloat = new ArrayList<>();
					List<Integer> valoresPos = new ArrayList<>();

					valoresPre.add(itemCobertura.getNumeroHorasFranquia());
					valoresPre.add(itemCobertura.getNumeroDiasFranquia());

					valoresPreFloat.add(itemCobertura.getTaxaFranquia());
					valoresPreFloat.add(itemCobertura.getValorFranquia());
					valoresPreFloat.add(itemCobertura.getValorFranquiaMinima());
					valoresPreFloat.add(itemCobertura.getValorFranquiaMaxima());
					valoresPreFloat.add(itemCobertura.getTaxaImportanciaSegurada());
					valoresPreFloat.add(itemCobertura.getTaxaImportanciaSeguradaMinima());
					valoresPreFloat.add(itemCobertura.getTaxaImportanciaSeguradaMaxima());

					itemCobertura.setNumeroCotacaoProposta(franquiaView.getNumeroCotacaoProposta());
					itemCobertura.setVersaoCotacaoProposta(franquiaView.getVersaoCotacaoProposta());
					itemCobertura.setDescricaoTextoFranquia(franquiaView.getDescricaoTextoFranquia());
					itemCobertura.setIdFormaFranquia(franquiaView.getIdFormaFranquia());
					itemCobertura.setIdTextoFranquia(franquiaView.getIdTextoFranquia());
					itemCobertura.setNumeroDiasFranquia(franquiaView.getNumeroDiasFranquia());
					itemCobertura.setNumeroHorasFranquia(franquiaView.getNumeroHorasFranquia());
					itemCobertura.setTaxaFranquia(numberMapper.asDecimal(franquiaView.getTaxaFranquia()));
					itemCobertura.setTaxaImportanciaSegurada(numberMapper.asDecimal(franquiaView.getTaxaImportanciaSegurada()));
					itemCobertura.setTaxaImportanciaSeguradaMaxima(numberMapper.asDecimal(franquiaView.getTaxaImportanciaSeguradaMaxima()));
					itemCobertura.setTaxaImportanciaSeguradaMinima(numberMapper.asDecimal(franquiaView.getTaxaImportanciaSeguradaMinima()));
					itemCobertura.setValorFranquia(numberMapper.asDecimal(franquiaView.getValorFranquia()));
					itemCobertura.setValorFranquiaMaxima(numberMapper.asDecimal(franquiaView.getValorFranquiaMaxima()));
					itemCobertura.setValorFranquiaMinima(numberMapper.asDecimal(franquiaView.getValorFranquiaMinima()));
					if(itemCobertura.getItemCotacao().getCotacao().getIdLmiUnico() == SimNaoEnum.NAO) {
						itemCobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
					}
					
					valoresPos.add(itemCobertura.getNumeroHorasFranquia());
					valoresPos.add(itemCobertura.getNumeroDiasFranquia());

					valoresPosFloat.add(itemCobertura.getTaxaFranquia());
					valoresPosFloat.add(itemCobertura.getValorFranquia());
					valoresPosFloat.add(itemCobertura.getValorFranquiaMinima());
					valoresPosFloat.add(itemCobertura.getValorFranquiaMaxima());
					valoresPosFloat.add(itemCobertura.getTaxaImportanciaSegurada());
					valoresPosFloat.add(itemCobertura.getTaxaImportanciaSeguradaMinima());
					valoresPosFloat.add(itemCobertura.getTaxaImportanciaSeguradaMaxima());

					for (int i = 0 ; i < valoresPre.size() ; i++) {
						if (valoresPre.get(i) != null && valoresPos.get(i) != null) {
							if (!valoresPre.get(i).equals(valoresPos.get(i))) {
								itemCobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
							}
						} else if (valoresPre.get(i) == null ^ valoresPos.get(i) == null) {
							itemCobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
						}
					}

					for (int i = 0 ; i < valoresPreFloat.size() ; i++) {
						if (valoresPreFloat.get(i) != null && valoresPosFloat.get(i) != null) {
							if (valoresPreFloat.get(i).compareTo(valoresPosFloat.get(i)) != 0) {
								itemCobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
							}
						} else if (valoresPreFloat.get(i) == null ^ valoresPosFloat.get(i) == null) {
							itemCobertura.setIdFranquiaInformado(SimNaoEnum.SIM);
						}
					}
				}

				if (itemCobertura.getListItemEquipamentoFranquia() != null && !itemCobertura.getListItemEquipamentoFranquia().isEmpty()) {

					for (Iterator<ItemEquipamentoFranquia> iteratorEquipamento = itemCobertura.getListItemEquipamentoFranquia().iterator() ; iteratorEquipamento.hasNext() ;) {
						ItemEquipamentoFranquia itemEquipamentoFranquia = iteratorEquipamento.next();

						if (franquiaView != null && franquiaView.getListItemEquipamentoFranquia() != null && !franquiaView.getListItemEquipamentoFranquia().isEmpty()) {

							for (Iterator<ItemEquipamentoFranquiaView> iteratorEquipamentoView = franquiaView.getListItemEquipamentoFranquia().iterator() ; iteratorEquipamentoView.hasNext() ;) {
								ItemEquipamentoFranquiaView equipamentoFranquiaView = iteratorEquipamentoView.next();

								if (equipamentoFranquiaView.getIdFormaFranquia() != null) {

									if (equipamentoFranquiaView.getSequencialItemEquipamantoFranquia() == null) {

										ItemEquipamentoFranquia itemEquipamentoFranquiaNew = new ItemEquipamentoFranquia();
										itemEquipamentoFranquiaNew.setNumeroCotacaoProposta(equipamentoFranquiaView.getNumeroCotacaoProposta());
										itemEquipamentoFranquiaNew.setVersaoCotacaoProposta(equipamentoFranquiaView.getVersaoCotacaoProposta());
										itemEquipamentoFranquiaNew.setCodigoEquipamento(equipamentoFranquiaView.getCodigoEquipamento());
										itemEquipamentoFranquiaNew.setDescricaoEquipamento(equipamentoFranquiaView.getDescricaoEquipamento());
										itemEquipamentoFranquiaNew.setDescricaoTextoFranquia(equipamentoFranquiaView.getDescricaoTextoFranquia());
										itemEquipamentoFranquiaNew.setIdFormaFranquia(equipamentoFranquiaView.getIdFormaFranquia());
										itemEquipamentoFranquiaNew.setIdTextoFranquia(equipamentoFranquiaView.getIdTextoFranquia());
										itemEquipamentoFranquiaNew.setNumeroDiasFranquia(equipamentoFranquiaView.getNumeroDiasFranquia());
										itemEquipamentoFranquiaNew.setNumeroHorasFranquia(equipamentoFranquiaView.getNumeroHorasFranquia());
										itemEquipamentoFranquiaNew.setSequencialItemEquipamantoFranquia(equipamentoFranquiaView.getSequencialItemEquipamantoFranquia());
										itemEquipamentoFranquiaNew.setTaxaFranquia(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaFranquia()));
										itemEquipamentoFranquiaNew.setTaxaImportanciaSegurada(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSegurada()));
										itemEquipamentoFranquiaNew.setTaxaImportanciaSeguradaMaximo(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSeguradaMaximo()));
										itemEquipamentoFranquiaNew.setTaxaImportanciaSeguradaMinimo(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSeguradaMinimo()));
										itemEquipamentoFranquiaNew.setValorFranquia(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquia()));
										itemEquipamentoFranquiaNew.setValorFranquiaMaximo(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquiaMaximo()));
										itemEquipamentoFranquiaNew.setValorFranquiaMinimo(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquiaMinimo()));

										User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

										itemEquipamentoFranquiaNew.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
										if (user.getCdUsuro() != null) {
											itemEquipamentoFranquiaNew.setUsuarioAtualizacao(user.getCdUsuro().longValue());
										}
										itemEquipamentoFranquiaNew.setDataAtualizacao(new Date());

										itemCobertura.getListItemEquipamentoFranquia().add(itemEquipamentoFranquia);

									} else if (equipamentoFranquiaView.getSequencialItemEquipamantoFranquia().equals(itemEquipamentoFranquia.getSequencialItemEquipamantoFranquia()) && !equipamentoFranquiaView.isDeleteItem()) {

										itemEquipamentoFranquia.setNumeroCotacaoProposta(equipamentoFranquiaView.getNumeroCotacaoProposta());
										itemEquipamentoFranquia.setVersaoCotacaoProposta(equipamentoFranquiaView.getVersaoCotacaoProposta());
										itemEquipamentoFranquia.setCodigoEquipamento(equipamentoFranquiaView.getCodigoEquipamento());
										itemEquipamentoFranquia.setDescricaoEquipamento(equipamentoFranquiaView.getDescricaoEquipamento());
										itemEquipamentoFranquia.setDescricaoTextoFranquia(equipamentoFranquiaView.getDescricaoTextoFranquia());
										itemEquipamentoFranquia.setIdFormaFranquia(equipamentoFranquiaView.getIdFormaFranquia());
										itemEquipamentoFranquia.setIdTextoFranquia(equipamentoFranquiaView.getIdTextoFranquia());
										itemEquipamentoFranquia.setNumeroDiasFranquia(equipamentoFranquiaView.getNumeroDiasFranquia());
										itemEquipamentoFranquia.setNumeroHorasFranquia(equipamentoFranquiaView.getNumeroHorasFranquia());
										itemEquipamentoFranquia.setSequencialItemEquipamantoFranquia(equipamentoFranquiaView.getSequencialItemEquipamantoFranquia());
										itemEquipamentoFranquia.setTaxaFranquia(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaFranquia()));
										itemEquipamentoFranquia.setTaxaImportanciaSegurada(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSegurada()));
										itemEquipamentoFranquia.setTaxaImportanciaSeguradaMaximo(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSeguradaMaximo()));
										itemEquipamentoFranquia.setTaxaImportanciaSeguradaMinimo(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSeguradaMinimo()));
										itemEquipamentoFranquia.setValorFranquia(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquia()));
										itemEquipamentoFranquia.setValorFranquiaMaximo(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquiaMaximo()));
										itemEquipamentoFranquia.setValorFranquiaMinimo(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquiaMinimo()));

									}
								}
							}
						}
					}
				} else {
					List<ItemEquipamentoFranquia> listEquipamentoFranquiaNew = new ArrayList<>();

					if (franquiaView != null && franquiaView.getListItemEquipamentoFranquia() != null && !franquiaView.getListItemEquipamentoFranquia().isEmpty()) {

						for (Iterator<ItemEquipamentoFranquiaView> iteratorEquipamentoView = franquiaView.getListItemEquipamentoFranquia().iterator() ; iteratorEquipamentoView.hasNext() ;) {
							ItemEquipamentoFranquiaView equipamentoFranquiaView = (ItemEquipamentoFranquiaView) iteratorEquipamentoView.next();

							if (equipamentoFranquiaView.getIdFormaFranquia() != null) {
								ItemEquipamentoFranquia itemEquipamentoFranquiaNew = new ItemEquipamentoFranquia();
								itemEquipamentoFranquiaNew.setNumeroCotacaoProposta(equipamentoFranquiaView.getNumeroCotacaoProposta());
								itemEquipamentoFranquiaNew.setVersaoCotacaoProposta(equipamentoFranquiaView.getVersaoCotacaoProposta());
								itemEquipamentoFranquiaNew.setCodigoEquipamento(equipamentoFranquiaView.getCodigoEquipamento());
								itemEquipamentoFranquiaNew.setDescricaoEquipamento(equipamentoFranquiaView.getDescricaoEquipamento());
								itemEquipamentoFranquiaNew.setDescricaoTextoFranquia(equipamentoFranquiaView.getDescricaoTextoFranquia());
								itemEquipamentoFranquiaNew.setIdFormaFranquia(equipamentoFranquiaView.getIdFormaFranquia());
								itemEquipamentoFranquiaNew.setIdTextoFranquia(equipamentoFranquiaView.getIdTextoFranquia());
								itemEquipamentoFranquiaNew.setNumeroDiasFranquia(equipamentoFranquiaView.getNumeroDiasFranquia());
								itemEquipamentoFranquiaNew.setNumeroHorasFranquia(equipamentoFranquiaView.getNumeroHorasFranquia());
								itemEquipamentoFranquiaNew.setSequencialItemEquipamantoFranquia(equipamentoFranquiaView.getSequencialItemEquipamantoFranquia());
								itemEquipamentoFranquiaNew.setTaxaFranquia(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaFranquia()));
								itemEquipamentoFranquiaNew.setTaxaImportanciaSegurada(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSegurada()));
								itemEquipamentoFranquiaNew.setTaxaImportanciaSeguradaMaximo(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSeguradaMaximo()));
								itemEquipamentoFranquiaNew.setTaxaImportanciaSeguradaMinimo(numberMapper.asDecimal(equipamentoFranquiaView.getTaxaImportanciaSeguradaMinimo()));
								itemEquipamentoFranquiaNew.setValorFranquia(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquia()));
								itemEquipamentoFranquiaNew.setValorFranquiaMaximo(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquiaMaximo()));
								itemEquipamentoFranquiaNew.setValorFranquiaMinimo(numberMapper.asDecimal(equipamentoFranquiaView.getValorFranquiaMinimo()));
								itemEquipamentoFranquiaNew.setItemCobertura(itemCobertura);

								User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

								itemEquipamentoFranquiaNew.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
								if (user.getCdUsuro() != null) {
									itemEquipamentoFranquiaNew.setUsuarioAtualizacao(user.getCdUsuro().longValue());
								}
								itemEquipamentoFranquiaNew.setDataAtualizacao(new Date());

								listEquipamentoFranquiaNew.add(itemEquipamentoFranquiaNew);

							}
						}
						itemCobertura.setListItemEquipamentoFranquia(listEquipamentoFranquiaNew);
					}

				}

			}
			franquiaRepository.saveDadosFranquia(coberturas);
			this.deleteItemEquipamentoFranquiaByCobertura(franquias);
		} catch (Exception e) {
			logger.error("Erro ao salvar os dados da franquia todos os Itens ",e);
			throw new ServiceException(e.getMessage(),e);
		}

	}

	private ItemCoberturaFranquiaView findItemCoberturaView(ItemCobertura itemCobertura,List<ItemCoberturaFranquiaView> franquias) throws Exception {

		ItemCoberturaFranquiaView franquia = null;

		for (Iterator<ItemCoberturaFranquiaView> iterator = franquias.iterator() ; iterator.hasNext() ;) {
			ItemCoberturaFranquiaView itemCoberturaFranquiaView = iterator.next();

			if (itemCoberturaFranquiaView.getCodigoCobertura().equals(itemCobertura.getCodigoCobertura()) && itemCoberturaFranquiaView.getSequencialItemCotacao().equals(itemCobertura.getItemCotacao().getSequencialItemCotacao())) {
				franquia = itemCoberturaFranquiaView;
				break;
			}
		}
		return franquia;

	}

	/**
	 * @param franquias
	 * @param coberturas
	 * @throws Exception
	 */
	private void deleteItemEquipamentoFranquia(List<ItemCoberturaFranquiaView> franquias,List<ItemCobertura> coberturas) throws Exception {

		for (ItemCoberturaFranquiaView itemCoberturaFranquiaView : franquias) {

			if (itemCoberturaFranquiaView.getListItemEquipamentoFranquia() != null && !itemCoberturaFranquiaView.getListItemEquipamentoFranquia().isEmpty()) {

				for (ItemEquipamentoFranquiaView itemEquipamentoFranquiaView : itemCoberturaFranquiaView.getListItemEquipamentoFranquia()) {

					if (itemEquipamentoFranquiaView.getSequencialItemEquipamantoFranquia() != null && itemEquipamentoFranquiaView.isDeleteItem()) {

						for (Iterator<ItemCobertura> itc = coberturas.iterator() ; itc.hasNext() ;) {
							ItemCobertura itemCobertura = itc.next();

							if (!itemCobertura.getSequencialItemCobertura().equals(itemEquipamentoFranquiaView.getSequencialItemCobertura())) {
								continue;
							}

							if (itemCobertura.getListItemEquipamentoFranquia() == null || itemCobertura.getListItemEquipamentoFranquia().isEmpty()) {
								continue;
							}

							for (Iterator<ItemEquipamentoFranquia> it = itemCobertura.getListItemEquipamentoFranquia().iterator() ; it.hasNext() ;) {
								ItemEquipamentoFranquia itemEquipamentoFranquia = it.next();
								if (itemEquipamentoFranquiaView.getSequencialItemEquipamantoFranquia().equals(itemEquipamentoFranquia.getSequencialItemEquipamantoFranquia())) {
									it.remove();
									franquiaRepository.deleteEquipamentoFranquia(itemEquipamentoFranquia);
								}
							}
						}
					}
				}
			}
		}
	}

	public boolean limpaFranquiaInformada(BigInteger id) throws ServiceException {
		try {
			ItemCobertura itemCobertura = itemCoberturaRepository.find(id);
			itemCobertura.setIdFranquiaInformado(SimNaoEnum.NAO);
			return franquiaRepository.limpaFranquiaInformada(itemCobertura);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public ResultadoREST<ItemCoberturaFranquiaView> validaDados(List<ItemCoberturaFranquiaView> franquias,Long itemAitemOrTodosItens) throws Exception {
		ResultadoREST<ItemCoberturaFranquiaView> resultado = new ResultadoREST<>();
		resultado.setListaValidacaoLote(this.validaFranquiasView(franquias));
		return resultado;
	}

	private List<ValidacaoLote> validaFranquiasView(List<ItemCoberturaFranquiaView> franquias) throws ServiceException {

		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		for (ItemCoberturaFranquiaView cobertura : franquias) {
			this.validaFranquiasView(listaValidacao,cobertura);
			listaValidacao.addAll(this.validaItemEquipamentoFranquiaView(cobertura));
		}

		return listaValidacao;
	}

	public ResultadoREST<ItemCoberturaFranquiaView> validaDadosTodosItens(List<ItemCoberturaFranquiaView> franquias) throws Exception {

		ResultadoREST<ItemCoberturaFranquiaView> resultado = new ResultadoREST<>();
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		for (ItemCoberturaFranquiaView coberturaView : franquias) {
			if (coberturaView.getIdFormaFranquia() != null) {
				this.validaFranquiasView(listaValidacao,coberturaView);
			}

			if (coberturaView.getListItemEquipamentoFranquia() != null && !coberturaView.getListItemEquipamentoFranquia().isEmpty()) {
				for (ItemEquipamentoFranquiaView equipamentoView : coberturaView.getListItemEquipamentoFranquia()) {
					this.validaItemEquipamentoFranquiaView(listaValidacao,equipamentoView,coberturaView);
				}
			}
		}
		resultado.setListaValidacaoLote(listaValidacao);
		return resultado;
	}

	private List<ValidacaoLote> validaItemEquipamentoFranquiaView(ItemCoberturaFranquiaView cobertura) throws ServiceException {

		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		if (cobertura.getListItemEquipamentoFranquia() != null && !cobertura.getListItemEquipamentoFranquia().isEmpty()) {

			for (ItemEquipamentoFranquiaView itemEquipamento : cobertura.getListItemEquipamentoFranquia()) {

				this.validaItemEquipamentoFranquiaView(listaValidacao,itemEquipamento,cobertura);
			}
		}

		return listaValidacao;
	}

	private void validaFranquiasView(List<ValidacaoLote> listaValidacao,ItemCoberturaFranquiaView itemCoberturaView) throws ServiceException {

		if (itemCoberturaView.getIdFormaFranquia() != null && itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.NAO_HA) {
			//
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.VALOR_FRANQUIA) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento do Valor da Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_SOBRE_PREJUIZO) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_PREJUIZO_C_MINIMO) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_PREJ_C_MIN_MAX) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMaxima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Máxima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.NUMERO_DE_DIAS) {
			if (itemCoberturaView.getNumeroDiasFranquia() == null || itemCoberturaView.getNumeroDiasFranquia().equals(0)) {
				String validacao = String.format("É obrigatório o preenchimento de Dias para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.NUMERO_DE_HORAS) {
			if (itemCoberturaView.getNumeroHorasFranquia() == null || itemCoberturaView.getNumeroHorasFranquia().equals(0)) {
				String validacao = String.format("É obrigatório o preenchimento de Horas para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_SOBRE_I_S) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_I_S_C_MINIMO) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_I_S_C_MIN_MAX) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMaxima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Máxima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_SOBRE_PREJ_LIM_PERC_IS) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_PREJ_LIM_PERC_IS_MI) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_PREJ_LIM_PERC_IS_MI_MA) {
			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getValorFranquiaMaxima())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Máxima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemCoberturaView.getIdFormaFranquia() == FormaFranquiaEnum.PERC_PREJ_LIM_PERC_IS) {
			if (itemCoberturaView.getTaxaFranquia() == null) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSeguradaMinima())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS Mínima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemCoberturaView.getTaxaImportanciaSeguradaMaxima())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS Máxima para a Cobertura %s",itemCoberturaView.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		}
	}

	private void validaItemEquipamentoFranquiaView(List<ValidacaoLote> listaValidacao,ItemEquipamentoFranquiaView itemEquipamento,ItemCoberturaFranquiaView cobertura) throws ServiceException {

		if(itemEquipamento.getIdFormaFranquia() == null && !itemEquipamento.isDeleteItem()){
			
				String validacao = String.format("É obrigatório o preenchimento da Forma de Franquia para o itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			
		}else if (itemEquipamento.getIdFormaFranquia() != null && itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.NAO_HA) {
			//
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.VALOR_FRANQUIA) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento do Valor da Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_SOBRE_PREJUIZO) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_PREJUIZO_C_MINIMO) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_PREJ_C_MIN_MAX) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMaximo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Máxima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.NUMERO_DE_DIAS) {
			if (itemEquipamento.getNumeroDiasFranquia() == null || itemEquipamento.getNumeroDiasFranquia().equals(0)) {
				String validacao = String.format("É obrigatório o preenchimento de Dias para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.NUMERO_DE_HORAS) {
			if (itemEquipamento.getNumeroHorasFranquia() == null || itemEquipamento.getNumeroHorasFranquia().equals(0)) {
				String validacao = String.format("É obrigatório o preenchimento de Horas para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_SOBRE_I_S) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_I_S_C_MINIMO) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_I_S_C_MIN_MAX) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMaximo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Máxima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_SOBRE_PREJ_LIM_PERC_IS) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_S_PREJ_LIM_PERC_IS_MI) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_PREJ_LIM_PERC_IS_MI_MA) {
			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaFranquia())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getValorFranquiaMaximo())) {
				String validacao = String.format("É obrigatório o preenchimento da Franquia Máxima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSegurada())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		} else if (itemEquipamento.getIdFormaFranquia() == FormaFranquiaEnum.PERC_PREJ_LIM_PERC_IS) {
			if (itemEquipamento.getTaxaFranquia() == null) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa Franquia para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSeguradaMinimo())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS Mínima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}

			if (StringUtil.isEmptyOrNull(itemEquipamento.getTaxaImportanciaSeguradaMaximo())) {
				String validacao = String.format("É obrigatório o preenchimento da Taxa IS Máxima para a itemEquipamento %s",cobertura.getDescricaoCobertura());
				listaValidacao.add(new ValidacaoLote(0,validacao));
			}
		}
	}

	@LogPerformance
	public void deleteItemEquipamentoFranquiaByCobertura(List<ItemCoberturaFranquiaView> listFranquiasAll) throws ServiceException {
		try {
			for (Iterator<ItemCoberturaFranquiaView> iterator = listFranquiasAll.iterator() ; iterator.hasNext() ;) {
				ItemCoberturaFranquiaView itemCoberturaFranquiaView = (ItemCoberturaFranquiaView) iterator.next();

				if (itemCoberturaFranquiaView.getListItemEquipamentoFranquiaDelete() != null && !itemCoberturaFranquiaView.getListItemEquipamentoFranquiaDelete().isEmpty()) {

					logger.info("quantidades de equipamentos a exlcuir " + itemCoberturaFranquiaView.getListItemEquipamentoFranquiaDelete().size());
					for (Iterator<ItemEquipamentoFranquiaView> equipamentoFranquiaViewIterator = itemCoberturaFranquiaView.getListItemEquipamentoFranquiaDelete().iterator() ; equipamentoFranquiaViewIterator.hasNext() ;) {
						ItemEquipamentoFranquiaView equipamentoFranquia = (ItemEquipamentoFranquiaView) equipamentoFranquiaViewIterator.next();

						logger.info("Equipamento a exlcuir: ");
						logger.info(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(equipamentoFranquia));
						franquiaRepository.deleteItemEquipamentoFranquiaByCobertura(equipamentoFranquia.getCodigoEquipamento(),equipamentoFranquia.getNumeroCotacaoProposta(),equipamentoFranquia.getVersaoCotacaoProposta(),equipamentoFranquia.getSequencialItemCobertura());

					}
				}
			}
		} catch (Exception e) {
			logger.error("Erro ao salvar os deletar franquia todos os Itens ",e);
			throw new ServiceException(e.getMessage(),e);
		}

	}
}
