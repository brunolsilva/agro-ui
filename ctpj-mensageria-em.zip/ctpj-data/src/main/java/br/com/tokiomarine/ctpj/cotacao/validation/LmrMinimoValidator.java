package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.Date;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Component
public class LmrMinimoValidator {

	@Autowired
	private ProdutoService produtoService;
	
	public String validar(Cotacao cotacao) {

		boolean existeValorMinimoLMR = false;

		if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE){

			ProdutoControle produtoControle = produtoService.findProdutoControleByCodigoAndVigencia(cotacao.getCodigoProduto(),new Date());
			
			if (produtoControle != null && produtoControle.getDataCorteLMR() != null && new Date().after(produtoControle.getDataCorteLMR()) ) {

				for	(ItemCotacao item: cotacao.getListItem()) {
					
					if (item.getListItemRamoEmissao()
							.stream()
							.filter(itr -> BigDecimalUtil.maiorIgual(itr.getValorLMR(),produtoControle.getValorMinimoLMR()))
							.collect(Collectors.toList()).size() > 0) {
							existeValorMinimoLMR = true;
							break;
					}
				}

				if (!existeValorMinimoLMR) {
					return "De acordo com a Circular 565, proposta com itens abaixo de "+BigDecimalUtil.formatBigDecimalMoeda(MoedaEnum.REAL,produtoControle.getValorMinimoLMR()) +" de LMR, não pode ser emitida neste produto.";
				}
				
			}

			
		}	
		return null;
	}
	
}
