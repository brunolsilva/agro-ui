package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.util.List;

public class BaseOpcaoParcelamentoView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -222699536392103974L;

	private int codigoFormaPagamento;

	private String descricaoFormaPagamento;

	private List<OpcaoParcelamentoView> opcoesParcelamento;

	public String getDescricaoFormaPagamento() {
		return descricaoFormaPagamento;
	}

	public void setDescricaoFormaPagamento(String descricaoFormaPagamento) {
		this.descricaoFormaPagamento = descricaoFormaPagamento;
	}

	public List<OpcaoParcelamentoView> getOpcoesParcelamento() {
		return opcoesParcelamento;
	}

	public void setOpcoesParcelamento(List<OpcaoParcelamentoView> opcoesParcelamento) {
		this.opcoesParcelamento = opcoesParcelamento;
	}

	public int getCodigoFormaPagamento() {
		return codigoFormaPagamento;
	}

	public void setCodigoFormaPagamento(int codigoFormaPagamento) {
		this.codigoFormaPagamento = codigoFormaPagamento;
	}
}
