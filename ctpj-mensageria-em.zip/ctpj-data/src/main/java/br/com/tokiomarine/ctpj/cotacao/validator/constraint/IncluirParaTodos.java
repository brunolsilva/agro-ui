package br.com.tokiomarine.ctpj.cotacao.validator.constraint;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators.IncluirParaTodosValidator;

/**
 * Valida se uma dado objeto é válido para a inclusão para todos os item da cotação. Caso não seja para incluir para todos, devemos informar o item da cotação, caso contrário não 
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Documented
@Constraint(validatedBy = IncluirParaTodosValidator.class)
@Target({TYPE, METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RUNTIME)
public @interface IncluirParaTodos {
	String campoItemCotacao() default "";
	String campoIncluirParaTodos() default "";
	
	String message() default "";
	Class<?>[] groups() default { };
	Class<? extends Payload>[] payload() default { };
}
