package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dto.ProdutoCaracteristicaView;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoSusep;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.mapper.ProdutoCaracViewMapper;

@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepository produtoRepository;

	//@Cacheable("produtos")
	@LogPerformance
	public Produto findProduto(Integer codigo) {
		return produtoRepository.findByCodigo(codigo);
	}

	//@Cacheable("produtoCaracteristica")
	@LogPerformance
	public Produto findByCaracBemKme(Long caracBem) {
		return produtoRepository.findByCaracBemKme(caracBem);
	}
	

	//@Cacheable("produtoCaracteristica")
	@LogPerformance
	public Optional<ProdutoCaracteristicaView> findCaracsByProduto(Integer codigoProduto) {
		List<ProdutoCaracteristica> listaProdutoCaracteristica = produtoRepository.findCaracsByProduto(codigoProduto);

		if(listaProdutoCaracteristica == null || listaProdutoCaracteristica.isEmpty()) {
			return Optional.empty();
		}

		Map<Integer, ProdutoCaracteristica> caracMap = listaProdutoCaracteristica
				.stream()
				.collect(Collectors.toMap(ProdutoCaracteristica::getCaracteristica,Function.identity()));

		ProdutoCaracteristicaView pcv = new ProdutoCaracteristicaView();
		carregarCaracteristicas(caracMap, pcv);

		return Optional.of(pcv);
	}

	private void carregarCaracteristicas(Map<Integer, ProdutoCaracteristica> caracMap, ProdutoCaracteristicaView pcv) {
		pcv.setCep(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CEP.codigo())));
		pcv.setLogradouro(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.ENDERECO_LOCAL.codigo())));
		pcv.setNumero(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.NUMERO_LOCAL.codigo())));
		pcv.setComplemento(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.COMPLEMENTO_LOCAL.codigo())));
		pcv.setMunicipio(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.MUNICIPIO_LOCAL.codigo())));
		pcv.setUf(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.UF_LOCAL.codigo())));
		pcv.setAtividade(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.ATIVIDADE.codigo())));
		pcv.setAtividadeAlternativa(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.ATIVIDADE_ALTERNATIVA.codigo())));
		pcv.setValorEmRisco(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.VALOR_EM_RISCO.codigo())));
		pcv.setClasseConstrucao(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSE_CONSTRUCAO.codigo())));
		pcv.setClasseLocalizacao(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSE_LOCALIZACAO.codigo())));
		pcv.setClasseOcupacao(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSE_OCUPACAO.codigo())));
		pcv.setLocalizacao(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.LOCALIZACAO.codigo())));
		pcv.setBemCoberto(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.BEM_COBERTO.codigo())));
		pcv.setPercentISVR(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.PERC_IS_VR.codigo())));
		pcv.setPercentDMPVR(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.PERC_DMP_VR.codigo())));
		pcv.setIdDistribuicaoVR(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.ID_DISTRIBUICAO_VR.codigo())));
		pcv.setSistemaProtecional(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.SISTEMA_PROTECIONAL.codigo())));
		pcv.setAmbitoGeografico(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.AMBITO_GEOGRAFICO.codigo())));
		pcv.setTipoFundacao(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.TIPO_FUNDACAO.codigo())));
		pcv.setSeveridade(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.SEVERIDADE.codigo())));
		pcv.setTipoConstrucao(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.TIPO_CONSTRUCAO.codigo())));
		pcv.setTipoPoco(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.TIPO_POCO.codigo())));
		pcv.setClasseMercadoria(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSE_MERCADORIA.codigo())));
		pcv.setClassificacaoPessoa(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSIFICACAO_PESSOA.codigo())));
		pcv.setClasseResseguro(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSE_RESSEGURO.codigo())));
		pcv.setBairro(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.BAIRRO.codigo())));
		pcv.setGalpaoVinilona(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.GALPAO_VINILONA.codigo())));
		pcv.setClasseBonus(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.CLASSE_BONUS.codigo())));
		pcv.setPercSinistroPremio(ProdutoCaracViewMapper.INSTANCE.toCaracView(caracMap.get(Caracteristicas.PERC_SINISTRO_PREMIO.codigo())));
	}

	@LogPerformance
	public ProdutoSusep findProdutoSusepByProduto(Integer codigoProduto, Integer codigoGrupoRamo, Integer codigoRamo, Date dataInicioVigencia){
		return produtoRepository.findProdutoSusepByProduto(codigoProduto,codigoGrupoRamo,codigoRamo,dataInicioVigencia);
	}
	
	@LogPerformance
	public ProdutoSusep findProduoSusepByProduto(Integer codigoProduto){
		return produtoRepository.findProdutoSusepByProduto(codigoProduto);
	}
	
	//@Cacheable("produtosControle")
	@LogPerformance
	public ProdutoControle findProdutoControleByCodigoAndVigencia(Integer codigoProduto, Date dataInicioVigencia){
		return produtoRepository.findProdutoControleByCodigoAndVigencia(codigoProduto,dataInicioVigencia);
	}

}