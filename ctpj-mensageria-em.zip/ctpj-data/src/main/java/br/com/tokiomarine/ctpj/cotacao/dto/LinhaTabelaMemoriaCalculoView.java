package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * Representação de uma linha da tabela de memória cálculo
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class LinhaTabelaMemoriaCalculoView implements Serializable {
	private static final long serialVersionUID = 1L;

	private Date dataCalculo;
	private BigInteger item;
	private BigInteger codCobertura;
	private String descricaoCobertura;
	private BigDecimal premioLiquido;
	private BigDecimal premioNet;
	private BigDecimal premioVigencia;
	private BigDecimal valorRiscoBem;
	private BigDecimal importanciaSegurada;
	private BigDecimal sublimite;
	private BigDecimal taxaIS;
	private BigDecimal coeficienteBemCoberto; //COEFICIENTE DE BEM COBERTO
	private BigDecimal descontoPorQuantDeCoberturas;// DESCONTO POR QUANTIDADE DE COBERTURAS
	private BigDecimal descontoProtecionalIncendio; // DESCONTO PROTECIONAL DE INCÊNDIO
	private BigDecimal descontoProtecionalRoubo; //DESCONTO PROTECIONAL DE ROUBO
	private BigDecimal agravoDeExperiencia; // AGRAVO DE EXPERIÊNCIA
	private BigDecimal coeficientePeriodoIndenitario;// COEFICIENTE PERÍODO INDENITÁRIO
	private BigDecimal descontoDePeriodoIndenitario; // DESCONTO DE PERÍODO INDENITÁRIO
	private BigDecimal descontoDeFranquia; // DESCONTO DE FRANQUIA
	private BigDecimal descontoAgrupamentoDeCobertura; // DESCONTO DE AGRUPAMENTO DE COBERTURA
	private BigDecimal descontoLMI; // DESCONTO LMI
	private BigDecimal coeficienteDePrazo; // COEFICIENTE DE PRAZO
	private BigDecimal coeficienteDeDMPVR; // COEFICIENTE DE DMP/VR
	private BigDecimal descontoGeral; // DESCONTO GERAL
	private BigDecimal descontoFidelidade; // DESCONTO FIDELIDADE
	private BigDecimal descontoGeralAplicado; // DESCONTO GERAL APLICADO
	private BigDecimal agravoDeComissao; // AGRAVO DE EXPERIÊNCIA
	private BigDecimal descontoDeExperiencia; // DESCONTO DE EXPERIÊNCIA
	private BigDecimal agravoGeralAplicado; //AGRAVO GERAL APLICADO
	private BigDecimal coeficienteVagas; //FATOR DE QTD DE VAGAS
	private BigDecimal descontoLocalizacao; //FATOR DE QTD DE VAGAS

	public LinhaTabelaMemoriaCalculoView() {

	}

	public Date getDataCalculo() {
		return dataCalculo;
	}

	
	
	public BigDecimal getCoeficienteBemCoberto() {
		return coeficienteBemCoberto;
	}

	public void setCoeficienteBemCoberto(BigDecimal coeficienteBemCoberto) {
		this.coeficienteBemCoberto = coeficienteBemCoberto;
	}

	public void setDataCalculo(Date dataCalculo) {
		this.dataCalculo = dataCalculo;
	}

	public BigInteger getItem() {
		return item;
	}

	public void setItem(BigInteger item) {
		this.item = item;
	}

	public BigInteger getCodCobertura() {
		return codCobertura;
	}

	public void setCodCobertura(BigInteger codCobertura) {
		this.codCobertura = codCobertura;
	}

	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}

	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}

	public BigDecimal getPremioLiquido() {
		return premioLiquido;
	}

	public void setPremioLiquido(BigDecimal premioLiquido) {
		this.premioLiquido = premioLiquido;
	}

	public BigDecimal getPremioNet() {
		return premioNet;
	}

	public void setPremioNet(BigDecimal premioNet) {
		this.premioNet = premioNet;
	}

	public BigDecimal getPremioVigencia() {
		return premioVigencia;
	}

	public void setPremioVigencia(BigDecimal premioVigencia) {
		this.premioVigencia = premioVigencia;
	}

	public BigDecimal getValorRiscoBem() {
		return valorRiscoBem;
	}

	public void setValorRiscoBem(BigDecimal valorRiscoBem) {
		this.valorRiscoBem = valorRiscoBem;
	}

	public BigDecimal getImportanciaSegurada() {
		return importanciaSegurada;
	}

	public void setImportanciaSegurada(BigDecimal importanciaSegurada) {
		this.importanciaSegurada = importanciaSegurada;
	}

	public BigDecimal getTaxaIS() {
		return taxaIS;
	}

	public void setTaxaIS(BigDecimal taxaIS) {
		this.taxaIS = taxaIS;
	}

	public BigDecimal getDescontoPorQuantDeCoberturas() {
		return descontoPorQuantDeCoberturas;
	}

	public void setDescontoPorQuantDeCoberturas(BigDecimal descontoPorQuantDeCoberturas) {
		this.descontoPorQuantDeCoberturas = descontoPorQuantDeCoberturas;
	}

	public BigDecimal getDescontoProtecionalIncendio() {
		return descontoProtecionalIncendio;
	}

	public void setDescontoProtecionalIncendio(BigDecimal descontoProtecionalIncendio) {
		this.descontoProtecionalIncendio = descontoProtecionalIncendio;
	}

	public BigDecimal getAgravoDeExperiencia() {
		return agravoDeExperiencia;
	}

	public void setAgravoDeExperiencia(BigDecimal agravoDeExperiencia) {
		this.agravoDeExperiencia = agravoDeExperiencia;
	}

	public BigDecimal getCoeficientePeriodoIndenitario() {
		return coeficientePeriodoIndenitario;
	}

	public void setCoeficientePeriodoIndenitario(BigDecimal coeficientePeriodoIndenitario) {
		this.coeficientePeriodoIndenitario = coeficientePeriodoIndenitario;
	}

	public BigDecimal getDescontoDePeriodoIndenitario() {
		return descontoDePeriodoIndenitario;
	}

	public void setDescontoDePeriodoIndenitario(BigDecimal descontoDePeriodoIndenitario) {
		this.descontoDePeriodoIndenitario = descontoDePeriodoIndenitario;
	}

	public BigDecimal getDescontoDeFranquia() {
		return descontoDeFranquia;
	}

	public void setDescontoDeFranquia(BigDecimal descontoDeFranquia) {
		this.descontoDeFranquia = descontoDeFranquia;
	}

	public BigDecimal getDescontoAgrupamentoDeCobertura() {
		return descontoAgrupamentoDeCobertura;
	}

	public void setDescontoAgrupamentoDeCobertura(BigDecimal descontoAgrupamentoDeCobertura) {
		this.descontoAgrupamentoDeCobertura = descontoAgrupamentoDeCobertura;
	}

	public BigDecimal getDescontoLMI() {
		return descontoLMI;
	}

	public void setDescontoLMI(BigDecimal descontoLMI) {
		this.descontoLMI = descontoLMI;
	}

	public BigDecimal getCoeficienteDePrazo() {
		return coeficienteDePrazo;
	}

	public void setCoeficienteDePrazo(BigDecimal coeficienteDePrazo) {
		this.coeficienteDePrazo = coeficienteDePrazo;
	}

	public BigDecimal getCoeficienteDeDMPVR() {
		return coeficienteDeDMPVR;
	}

	public void setCoeficienteDeDMPVR(BigDecimal coeficienteDeDMPVR) {
		this.coeficienteDeDMPVR = coeficienteDeDMPVR;
	}

	public BigDecimal getDescontoGeral() {
		return descontoGeral;
	}

	public void setDescontoGeral(BigDecimal descontoGeral) {
		this.descontoGeral = descontoGeral;
	}

	public BigDecimal getDescontoFidelidade() {
		return descontoFidelidade;
	}

	public void setDescontoFidelidade(BigDecimal descontoFidelidade) {
		this.descontoFidelidade = descontoFidelidade;
	}

	public BigDecimal getDescontoGeralAplicado() {
		return descontoGeralAplicado;
	}

	public void setDescontoGeralAplicado(BigDecimal descontoGeralAplicado) {
		this.descontoGeralAplicado = descontoGeralAplicado;
	}

	public BigDecimal getAgravoDeComissao() {
		return agravoDeComissao;
	}

	public void setAgravoDeComissao(BigDecimal agravoDeComissao) {
		this.agravoDeComissao = agravoDeComissao;
	}

	public BigDecimal getDescontoDeExperiencia() {
		return descontoDeExperiencia;
	}

	public void setDescontoDeExperiencia(BigDecimal descontoDeExperiencia) {
		this.descontoDeExperiencia = descontoDeExperiencia;
	}
	
	

	public BigDecimal getAgravoGeralAplicado() {
		return agravoGeralAplicado;
	}

	public void setAgravoGeralAplicado(BigDecimal agravoGeralAplicado) {
		this.agravoGeralAplicado = agravoGeralAplicado;
	}	

	public BigDecimal getSublimite() {
		return sublimite;
	}

	public void setSublimite(BigDecimal sublimite) {
		this.sublimite = sublimite;
	}
	
	

	public BigDecimal getDescontoProtecionalRoubo() {
		return descontoProtecionalRoubo;
	}

	public void setDescontoProtecionalRoubo(BigDecimal descontoProtecionalRoubo) {
		this.descontoProtecionalRoubo = descontoProtecionalRoubo;
	}	

	public BigDecimal getCoeficienteVagas() {
		return coeficienteVagas;
	}

	public void setCoeficienteVagas(BigDecimal coeficienteVagas) {
		this.coeficienteVagas = coeficienteVagas;
	}

	public BigDecimal getDescontoLocalizacao() {
		return descontoLocalizacao;
	}

	public void setDescontoLocalizacao(BigDecimal descontoLocalizacao) {
		this.descontoLocalizacao = descontoLocalizacao;
	}

	@Override
	public String toString() {
		return "LinhaTabelaMemoriaCalculoView [dataCalculo=" + dataCalculo + ", item=" + item + ", codCobertura=" + codCobertura + ", descricaoCobertura=" + descricaoCobertura + ", premioLiquido=" + premioLiquido + ", premioNet=" + premioNet + ", premioVigencia=" + premioVigencia
				+ ", valorRiscoBem=" + valorRiscoBem + ", importanciaSegurada=" + importanciaSegurada + ", sublimite=" + sublimite + ", taxaIS=" + taxaIS + ", coeficienteBemCoberto=" + coeficienteBemCoberto + ", descontoPorQuantDeCoberturas=" + descontoPorQuantDeCoberturas
				+ ", descontoProtecionalIncendio=" + descontoProtecionalIncendio + ", descontoProtecionalRoubo=" + descontoProtecionalRoubo + ", agravoDeExperiencia=" + agravoDeExperiencia + ", coeficientePeriodoIndenitario=" + coeficientePeriodoIndenitario + ", descontoDePeriodoIndenitario="
				+ descontoDePeriodoIndenitario + ", descontoDeFranquia=" + descontoDeFranquia + ", descontoAgrupamentoDeCobertura=" + descontoAgrupamentoDeCobertura + ", descontoLMI=" + descontoLMI + ", coeficienteDePrazo=" + coeficienteDePrazo + ", coeficienteDeDMPVR=" + coeficienteDeDMPVR
				+ ", descontoGeral=" + descontoGeral + ", descontoFidelidade=" + descontoFidelidade + ", descontoGeralAplicado=" + descontoGeralAplicado + ", agravoDeComissao=" + agravoDeComissao + ", descontoDeExperiencia=" + descontoDeExperiencia + ", agravoGeralAplicado=" + agravoGeralAplicado
				+ ", coeficienteVagas=" + coeficienteVagas + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agravoDeComissao == null) ? 0 : agravoDeComissao.hashCode());
		result = prime * result + ((agravoDeExperiencia == null) ? 0 : agravoDeExperiencia.hashCode());
		result = prime * result + ((agravoGeralAplicado == null) ? 0 : agravoGeralAplicado.hashCode());
		result = prime * result + ((codCobertura == null) ? 0 : codCobertura.hashCode());
		result = prime * result + ((coeficienteBemCoberto == null) ? 0 : coeficienteBemCoberto.hashCode());
		result = prime * result + ((coeficienteDeDMPVR == null) ? 0 : coeficienteDeDMPVR.hashCode());
		result = prime * result + ((coeficienteDePrazo == null) ? 0 : coeficienteDePrazo.hashCode());
		result = prime * result + ((coeficientePeriodoIndenitario == null) ? 0 : coeficientePeriodoIndenitario.hashCode());
		result = prime * result + ((coeficienteVagas == null) ? 0 : coeficienteVagas.hashCode());
		result = prime * result + ((dataCalculo == null) ? 0 : dataCalculo.hashCode());
		result = prime * result + ((descontoAgrupamentoDeCobertura == null) ? 0 : descontoAgrupamentoDeCobertura.hashCode());
		result = prime * result + ((descontoDeExperiencia == null) ? 0 : descontoDeExperiencia.hashCode());
		result = prime * result + ((descontoDeFranquia == null) ? 0 : descontoDeFranquia.hashCode());
		result = prime * result + ((descontoDePeriodoIndenitario == null) ? 0 : descontoDePeriodoIndenitario.hashCode());
		result = prime * result + ((descontoFidelidade == null) ? 0 : descontoFidelidade.hashCode());
		result = prime * result + ((descontoGeral == null) ? 0 : descontoGeral.hashCode());
		result = prime * result + ((descontoGeralAplicado == null) ? 0 : descontoGeralAplicado.hashCode());
		result = prime * result + ((descontoLMI == null) ? 0 : descontoLMI.hashCode());
		result = prime * result + ((descontoPorQuantDeCoberturas == null) ? 0 : descontoPorQuantDeCoberturas.hashCode());
		result = prime * result + ((descontoProtecionalIncendio == null) ? 0 : descontoProtecionalIncendio.hashCode());
		result = prime * result + ((descontoProtecionalRoubo == null) ? 0 : descontoProtecionalRoubo.hashCode());
		result = prime * result + ((descricaoCobertura == null) ? 0 : descricaoCobertura.hashCode());
		result = prime * result + ((importanciaSegurada == null) ? 0 : importanciaSegurada.hashCode());
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		result = prime * result + ((premioLiquido == null) ? 0 : premioLiquido.hashCode());
		result = prime * result + ((premioNet == null) ? 0 : premioNet.hashCode());
		result = prime * result + ((premioVigencia == null) ? 0 : premioVigencia.hashCode());
		result = prime * result + ((sublimite == null) ? 0 : sublimite.hashCode());
		result = prime * result + ((taxaIS == null) ? 0 : taxaIS.hashCode());
		result = prime * result + ((valorRiscoBem == null) ? 0 : valorRiscoBem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LinhaTabelaMemoriaCalculoView other = (LinhaTabelaMemoriaCalculoView) obj;
		if (agravoDeComissao == null) {
			if (other.agravoDeComissao != null)
				return false;
		} else if (!agravoDeComissao.equals(other.agravoDeComissao))
			return false;
		if (agravoDeExperiencia == null) {
			if (other.agravoDeExperiencia != null)
				return false;
		} else if (!agravoDeExperiencia.equals(other.agravoDeExperiencia))
			return false;
		if (agravoGeralAplicado == null) {
			if (other.agravoGeralAplicado != null)
				return false;
		} else if (!agravoGeralAplicado.equals(other.agravoGeralAplicado))
			return false;
		if (codCobertura == null) {
			if (other.codCobertura != null)
				return false;
		} else if (!codCobertura.equals(other.codCobertura))
			return false;
		if (coeficienteBemCoberto == null) {
			if (other.coeficienteBemCoberto != null)
				return false;
		} else if (!coeficienteBemCoberto.equals(other.coeficienteBemCoberto))
			return false;
		if (coeficienteDeDMPVR == null) {
			if (other.coeficienteDeDMPVR != null)
				return false;
		} else if (!coeficienteDeDMPVR.equals(other.coeficienteDeDMPVR))
			return false;
		if (coeficienteDePrazo == null) {
			if (other.coeficienteDePrazo != null)
				return false;
		} else if (!coeficienteDePrazo.equals(other.coeficienteDePrazo))
			return false;
		if (coeficientePeriodoIndenitario == null) {
			if (other.coeficientePeriodoIndenitario != null)
				return false;
		} else if (!coeficientePeriodoIndenitario.equals(other.coeficientePeriodoIndenitario))
			return false;
		if (coeficienteVagas == null) {
			if (other.coeficienteVagas != null)
				return false;
		} else if (!coeficienteVagas.equals(other.coeficienteVagas))
			return false;
		if (dataCalculo == null) {
			if (other.dataCalculo != null)
				return false;
		} else if (!dataCalculo.equals(other.dataCalculo))
			return false;
		if (descontoAgrupamentoDeCobertura == null) {
			if (other.descontoAgrupamentoDeCobertura != null)
				return false;
		} else if (!descontoAgrupamentoDeCobertura.equals(other.descontoAgrupamentoDeCobertura))
			return false;
		if (descontoDeExperiencia == null) {
			if (other.descontoDeExperiencia != null)
				return false;
		} else if (!descontoDeExperiencia.equals(other.descontoDeExperiencia))
			return false;
		if (descontoDeFranquia == null) {
			if (other.descontoDeFranquia != null)
				return false;
		} else if (!descontoDeFranquia.equals(other.descontoDeFranquia))
			return false;
		if (descontoDePeriodoIndenitario == null) {
			if (other.descontoDePeriodoIndenitario != null)
				return false;
		} else if (!descontoDePeriodoIndenitario.equals(other.descontoDePeriodoIndenitario))
			return false;
		if (descontoFidelidade == null) {
			if (other.descontoFidelidade != null)
				return false;
		} else if (!descontoFidelidade.equals(other.descontoFidelidade))
			return false;
		if (descontoGeral == null) {
			if (other.descontoGeral != null)
				return false;
		} else if (!descontoGeral.equals(other.descontoGeral))
			return false;
		if (descontoGeralAplicado == null) {
			if (other.descontoGeralAplicado != null)
				return false;
		} else if (!descontoGeralAplicado.equals(other.descontoGeralAplicado))
			return false;
		if (descontoLMI == null) {
			if (other.descontoLMI != null)
				return false;
		} else if (!descontoLMI.equals(other.descontoLMI))
			return false;
		if (descontoPorQuantDeCoberturas == null) {
			if (other.descontoPorQuantDeCoberturas != null)
				return false;
		} else if (!descontoPorQuantDeCoberturas.equals(other.descontoPorQuantDeCoberturas))
			return false;
		if (descontoProtecionalIncendio == null) {
			if (other.descontoProtecionalIncendio != null)
				return false;
		} else if (!descontoProtecionalIncendio.equals(other.descontoProtecionalIncendio))
			return false;
		if (descontoProtecionalRoubo == null) {
			if (other.descontoProtecionalRoubo != null)
				return false;
		} else if (!descontoProtecionalRoubo.equals(other.descontoProtecionalRoubo))
			return false;
		if (descricaoCobertura == null) {
			if (other.descricaoCobertura != null)
				return false;
		} else if (!descricaoCobertura.equals(other.descricaoCobertura))
			return false;
		if (importanciaSegurada == null) {
			if (other.importanciaSegurada != null)
				return false;
		} else if (!importanciaSegurada.equals(other.importanciaSegurada))
			return false;
		if (item == null) {
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		if (premioLiquido == null) {
			if (other.premioLiquido != null)
				return false;
		} else if (!premioLiquido.equals(other.premioLiquido))
			return false;
		if (premioNet == null) {
			if (other.premioNet != null)
				return false;
		} else if (!premioNet.equals(other.premioNet))
			return false;
		if (premioVigencia == null) {
			if (other.premioVigencia != null)
				return false;
		} else if (!premioVigencia.equals(other.premioVigencia))
			return false;
		if (sublimite == null) {
			if (other.sublimite != null)
				return false;
		} else if (!sublimite.equals(other.sublimite))
			return false;
		if (taxaIS == null) {
			if (other.taxaIS != null)
				return false;
		} else if (!taxaIS.equals(other.taxaIS))
			return false;
		if (valorRiscoBem == null) {
			if (other.valorRiscoBem != null)
				return false;
		} else if (!valorRiscoBem.equals(other.valorRiscoBem))
			return false;
		return true;
	}

}
