package br.com.tokiomarine.ctpj.apolice.exception;

/**
 * Exceção utilizada quando não é encontrada uma Apólice
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class ApoliceNaoEncotradaException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ApoliceNaoEncotradaException() {
		super("Não foi encontra uma apólice");
	}	

	public ApoliceNaoEncotradaException(String message, Throwable cause) {
		super(message, cause);
	}

	public ApoliceNaoEncotradaException(String message) {
		super(message);
	}	

	public ApoliceNaoEncotradaException(Throwable cause) {
		super(cause);
	}

}
