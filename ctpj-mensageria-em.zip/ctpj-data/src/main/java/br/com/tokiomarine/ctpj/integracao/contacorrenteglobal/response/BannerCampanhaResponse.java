package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response;

import java.io.Serializable;

public class BannerCampanhaResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -2576012650467430773L;
	private String descricao;
	private Long idCampanha;

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Long getIdCampanha() {
		return idCampanha;
	}

	public void setIdCampanha(Long idCampanha) {
		this.idCampanha = idCampanha;
	}


}
