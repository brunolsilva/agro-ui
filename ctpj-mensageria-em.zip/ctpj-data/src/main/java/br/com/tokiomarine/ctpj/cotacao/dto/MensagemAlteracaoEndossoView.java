package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.util.Date;

public class MensagemAlteracaoEndossoView implements Serializable {

	private static final long serialVersionUID = 4808629982372595920L;

	private Date data;
	private String descricao;

	public MensagemAlteracaoEndossoView() {

	}

	public MensagemAlteracaoEndossoView(Date data,String descricao) {
		super();
		this.data = data;
		this.descricao = descricao;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ( (data == null) ? 0 : data.hashCode());
		result = prime * result + ( (descricao == null) ? 0 : descricao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MensagemAlteracaoEndossoView other = (MensagemAlteracaoEndossoView) obj;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		return true;
	}

}
