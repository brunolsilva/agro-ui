package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

public class ValorDescontoRequest implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 631766367004165700L;
	private BigInteger idSaldo;
	private BigDecimal valorDesconto;

	public BigInteger getIdSaldo() {
		return idSaldo;
	}

	public void setIdSaldo(BigInteger idSaldo) {
		this.idSaldo = idSaldo;
	}

	public BigDecimal getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(BigDecimal valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

}
