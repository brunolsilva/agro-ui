package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemDistribuicaoVrApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemDistribuicaoService {

	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0114
	 */
	public void validarItemDistribuicao(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiItemDistribuicao = itemEndosso.getListItemDistribuicao() != null && !itemEndosso.getListItemDistribuicao().isEmpty();
		boolean itemApolicePossuiItemDistribuicao = itemApolice.getListItemDistribuicaoVrApolice() != null && !itemApolice.getListItemDistribuicaoVrApolice().isEmpty();
		
		//1 - percorre os itens de distribuiçao do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiItemDistribuicao){			
			for(ItemDistribuicao itemDistrEndosso : itemEndosso.getListItemDistribuicao()){
				boolean itemDistribExiste = false;
				if(itemApolicePossuiItemDistribuicao){
					for(ItemDistribuicaoVrApolice itemDistrApolice : itemApolice.getListItemDistribuicaoVrApolice()){
						if(AssertUtils.compareNull(itemDistrEndosso.getDescricaoRiscoBem(),itemDistrApolice.getDescricaoRiscoBem())){
							//valida descricao risco bem
							validacaoParametrosEndossoService.compararParametrosItem(itemDistrApolice.getDescricaoRiscoBem(), itemDistrEndosso.getDescricaoRiscoBem(), TipoMensagemEndossoEnum.ALT_DISTR_VR, "- Descrição: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida valor risco bem
							validacaoParametrosEndossoService.compararParametrosItem(itemDistrApolice.getValorRiscoBem(), itemDistrEndosso.getValorRiscoBem(), TipoMensagemEndossoEnum.ALT_DISTR_VR, "- VR: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida valor risco bem moeda estrangeira
							validacaoParametrosEndossoService.compararParametrosItem(itemDistrApolice.getValorRiscoBemMoedaEstrangeira(), itemDistrEndosso.getValorRiscoBemMoedaEstrangeira(), TipoMensagemEndossoEnum.ALT_DISTR_VR, "- VR em dólar: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida tipo valor risco
							validacaoParametrosEndossoService.compararParametrosItem(itemDistrApolice.getIdTipoValorRisco().getId(), itemDistrEndosso.getIdTipoValorRisco().getId(), TipoMensagemEndossoEnum.ALT_DISTR_VR, "- Tipo VR: ", endosso, itemEndosso, alteracoesEndossoList, user);
							itemDistribExiste = true;
							break;
						}						
					}
				}
				
				//se o item distribuição não existir
				if(!itemDistribExiste){ 
					logarInclusaoItem(itemDistrEndosso,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os itens de distribuição da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiItemDistribuicao){
			for(ItemDistribuicaoVrApolice itemDistrApolice : itemApolice.getListItemDistribuicaoVrApolice()){
				boolean itemDistribExiste = false;
				if(itemEndossoPossuiItemDistribuicao){
					for(ItemDistribuicao itemDistrEndosso : itemEndosso.getListItemDistribuicao()){
						if(AssertUtils.compareNull(itemDistrEndosso.getDescricaoRiscoBem(),itemDistrApolice.getDescricaoRiscoBem())){
							itemDistribExiste = true;
							break;
						}
					}
				}
				
				if(!itemDistribExiste){
					logarExclusaoItem(itemDistrApolice,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoItem(ItemDistribuicao itemDistrEndosso, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.ALT_DISTR_VR, itemDistrEndosso.getSequencialDistribuicaoValorRisco().toString(), user));
	}
	
		
	private void logarExclusaoItem(ItemDistribuicaoVrApolice itemDistrApolice, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.ALT_DISTR_VR, itemDistrApolice.getCdSequencia().toString(), user));
	}
}
