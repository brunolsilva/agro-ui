package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class JurosParcelamentoCotacaoView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8931337109148019889L;

	private BigInteger sequencialCotacaoProposta;
	private BigInteger sequencialJurosParcelamentoCotacao;
	private Integer codigoFormaPagamento;
	private String descricaoFormaPagamento;
	private Integer codigoFormaParcelamento;
	private String decricaoFormaParcelamento;
	private String percentualJuros;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy HH:mm:ss",timezone = "America/Sao_Paulo")
	private Date dataAtualizacao;
	private Integer codigoGrupo;
	private Long usuarioAtualizacao;

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	public BigInteger getSequencialJurosParcelamentoCotacao() {
		return sequencialJurosParcelamentoCotacao;
	}

	public void setSequencialJurosParcelamentoCotacao(BigInteger sequencialJurosParcelamentoCotacao) {
		this.sequencialJurosParcelamentoCotacao = sequencialJurosParcelamentoCotacao;
	}

	public Integer getCodigoFormaPagamento() {
		return codigoFormaPagamento;
	}

	public void setCodigoFormaPagamento(Integer codigoFormaPagamento) {
		this.codigoFormaPagamento = codigoFormaPagamento;
	}

	public String getDescricaoFormaPagamento() {
		return descricaoFormaPagamento;
	}

	public void setDescricaoFormaPagamento(String descricaoFormaPagamento) {
		this.descricaoFormaPagamento = descricaoFormaPagamento;
	}

	public Integer getCodigoFormaParcelamento() {
		return codigoFormaParcelamento;
	}

	public void setCodigoFormaParcelamento(Integer codigoFormaParcelamento) {
		this.codigoFormaParcelamento = codigoFormaParcelamento;
	}

	public String getDecricaoFormaParcelamento() {
		return decricaoFormaParcelamento;
	}

	public void setDecricaoFormaParcelamento(String decricaoFormaParcelamento) {
		this.decricaoFormaParcelamento = decricaoFormaParcelamento;
	}

	public String getPercentualJuros() {
		return percentualJuros;
	}

	public void setPercentualJuros(String percentualJuros) {
		this.percentualJuros = percentualJuros;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public Integer getCodigoGrupo() {
		return codigoGrupo;
	}

	public void setCodigoGrupo(Integer codigoGrupo) {
		this.codigoGrupo = codigoGrupo;
	}

	public Long getUsuarioAtualizacao() {
		return usuarioAtualizacao;
	}

	public void setUsuarioAtualizacao(Long usuarioAtualizacao) {
		this.usuarioAtualizacao = usuarioAtualizacao;
	}

}
