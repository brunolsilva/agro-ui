package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.infra.domain.SistemaProtecao;
import br.com.tokiomarine.ctpj.infra.mongo.repository.SistemaProtecaoRepository;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.ws.response.SistemaProtecaoResponse;

@Service
public class SistemaProtecaoService {
	
	@Autowired
	private SistemaProtecaoRepository repository;
	
	@Autowired
	private CaracteristicaService caracteristicaService;
	
	public List<SistemaProtecao> findListIncendio(Integer produto){
		return repository.findListIncendio(produto, new Sort(Direction.ASC, "nome"));
	}
	
	public List<SistemaProtecao> findListRoubo(Integer produto){
		return repository.findListRoubo(produto, new Sort(Direction.ASC, "nome"));
	}
	
	public List<SistemaProtecao> findAll(Integer produto){
		return repository.findAll(produto, new Sort(Direction.ASC, "nome"));
	}
	
	public List<SistemaProtecaoResponse> findListIncendioSemDePara(Integer produto){
		List<ProdutoValorCarac> valoresCaracteristica = caracteristicaService.getValoresCaracteristica(produto,
				Caracteristicas.SISTEMA_PROTECIONAL.codigo(), new Sort(Direction.ASC, "descricaoValor"));
		List<SistemaProtecaoResponse> protecionaisResponse = new ArrayList<>();
		List<Long> protecionaisIncendio = Arrays.asList(12L,19L,24L);
		for(ProdutoValorCarac pvc: valoresCaracteristica) {
			if(protecionaisIncendio.contains(pvc.getValorCaracteristica())) {
				SistemaProtecaoResponse sp = new SistemaProtecaoResponse();
				sp.setCodigoSistemaProtecao(pvc.getValorCaracteristica());
				sp.setDescricao(pvc.getDescricaoValor());
				protecionaisResponse.add(sp);
			}
		}
		return protecionaisResponse;
	}
	
	public List<SistemaProtecaoResponse> findListRouboSemDePara(Integer produto){
		List<ProdutoValorCarac> valoresCaracteristica = caracteristicaService.getValoresCaracteristica(produto,
				Caracteristicas.SISTEMA_PROTECIONAL.codigo(), new Sort(Direction.ASC, "descricaoValor"));
		List<SistemaProtecaoResponse> protecionaisResponse = new ArrayList<>();
		List<Long> protecionaisIncendio = Arrays.asList(12L,19L,24L);
		for(ProdutoValorCarac pvc: valoresCaracteristica) {
			if(!protecionaisIncendio.contains(pvc.getValorCaracteristica())) {
				SistemaProtecaoResponse sp = new SistemaProtecaoResponse();
				sp.setCodigoSistemaProtecao(pvc.getValorCaracteristica());
				sp.setDescricao(pvc.getDescricaoValor());
				protecionaisResponse.add(sp);
			}
		}
		return protecionaisResponse;
	}
	
	public List<SistemaProtecaoResponse> findAllSemDePara(Integer produto){
		List<ProdutoValorCarac> valoresCaracteristica = caracteristicaService.getValoresCaracteristica(produto,
				Caracteristicas.SISTEMA_PROTECIONAL.codigo(), new Sort(Direction.ASC, "descricaoValor"));
		List<SistemaProtecaoResponse> protecionaisResponse = new ArrayList<>();
		for(ProdutoValorCarac pvc: valoresCaracteristica) {
			SistemaProtecaoResponse sp = new SistemaProtecaoResponse();
			sp.setCodigoSistemaProtecao(pvc.getValorCaracteristica());
			sp.setDescricao(pvc.getDescricaoValor());
			protecionaisResponse.add(sp);
		}
		return protecionaisResponse;
	}
}
