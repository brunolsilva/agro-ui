package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.lang.reflect.Field;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ValidationException;

import br.com.tokiomarine.ctpj.cotacao.validator.constraint.IncluirParaTodos;

/**
 * 
 * @author Hroemnique Cezniowscki Leite Batista
 *
 */
public class IncluirParaTodosValidator implements ConstraintValidator<IncluirParaTodos, Object> {

	private String incluirParaTodosFieldName;
	private String itemCotacaoFieldName;

	@Override
	public void initialize(IncluirParaTodos annotation) {
		incluirParaTodosFieldName = annotation.campoIncluirParaTodos();
		itemCotacaoFieldName = annotation.campoItemCotacao();
	}

	@Override
	public boolean isValid(Object obj, ConstraintValidatorContext context) {
		try {
			Boolean incluirParaTodos = (Boolean) getFieldValue(obj, incluirParaTodosFieldName);
			Object itemCotacao = getFieldValue(obj, itemCotacaoFieldName);

			if(incluirParaTodos == null) //não possuo a informação se é ou não para incluir para todos, logo não valido
				return true;
			
			if (!incluirParaTodos) {
				return itemCotacao != null ? true : false;
			}

			return true;
		} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			throw new ValidationException("Ocorreu um erro durante a validação do IncluirParaTodos", e);
		}

	}
	
	private Object getFieldValue(Object obj, String fieldName) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
		Class<? extends Object> clazz = obj.getClass();
		Field field = clazz.getDeclaredField(fieldName);
		field.setAccessible(true);
		return field.get(obj);
	}

}
