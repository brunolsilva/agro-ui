package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ClausulaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;


/**
 * Repositório para entidade ClausulaCotacao
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Repository
public class ClausulaCotacaoRepository extends BaseDAO{
	
	private static final String EXCLUI_TODAS_CLAUSULAS_POR_COTACAO_HQL = 
			"delete from ClausulaCotacao cc where cc.cotacao.sequencialCotacaoProposta = :seqCotacao and cc.idClausulaAutomatica = :clausulaAutomatica";
	
	private static final String LISTA_COD_CLAUSULAS_EXISTENTES_POR_COTACAO_HQL = 
			"select cc.codigoClausula " + 
			"from ClausulaCotacao cc " +
			"where cc.cotacao.sequencialCotacaoProposta = :seqCotacao";

	private static final String LISTA_CLAUSULAS_POR_COTACAO_HQL = 
			"select cc " +
			"from ClausulaCotacao cc " +
			"where cc.cotacao.sequencialCotacaoProposta = :seqCotacao and cc.idClausulaAutomatica = :clausulaAutomatica";
	
	public ClausulaCotacao salva(ClausulaCotacao clausula){
		getCurrentSession().save(clausula);
		return clausula;
	}
	
	public void excluiTodasClausulasManuaisDaCotacao(BigInteger seqCotacao){
		getCurrentSession()
		.createQuery(EXCLUI_TODAS_CLAUSULAS_POR_COTACAO_HQL)
		.setParameter("seqCotacao", seqCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	@LogPerformance
	public void excluiToddasClausulasAutomaticasDaCotacao(Cotacao cotacao){
		getCurrentSession()
		.createQuery(EXCLUI_TODAS_CLAUSULAS_POR_COTACAO_HQL)
		.setParameter("seqCotacao", cotacao.getSequencialCotacaoProposta())
		.setParameter("clausulaAutomatica", SimNaoEnum.SIM)
		.executeUpdate();
	}
	
	@SuppressWarnings("unchecked")
	public List<ClausulaCotacao> listaClausulasManuaisPorCotacao(BigInteger seqCotacao){
		List<ClausulaCotacao> clausulas = getCurrentSession()
		.createQuery(LISTA_CLAUSULAS_POR_COTACAO_HQL)
		.setParameter("seqCotacao", seqCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.list();
		
		return clausulas;
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> listaCodClausulaExistentesPorCotacao(BigInteger seqCotacao) {
		Query query = getCurrentSession().createQuery(LISTA_COD_CLAUSULAS_EXISTENTES_POR_COTACAO_HQL);
		query.setParameter("seqCotacao", seqCotacao);
		return query.list();
	}
}
