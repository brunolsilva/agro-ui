package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemInspecaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.InspecaoInteligenteService;
import br.com.tokiomarine.ctpj.cotacao.service.InspecaoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ControllerInternalErrorException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.mapper.ItemInspecaoMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Controller
@RequestMapping("/inspecao")
public class InspecaoController extends AbstractController {

	private static Logger logger = LogManager.getLogger(InspecaoController.class);

	@Autowired
	private InspecaoService inspecaoService;
	
	@Autowired
	private ItemInspecaoMapper mapper;
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private InspecaoInteligenteService inspecaoInteligenteService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;
	
	@GetMapping("/{idCotacao}")
	public String home(@PathVariable("idCotacao") BigInteger idCotacao,
						@RequestHeader(value = "referer", required = false) String origem,
						Model model){
		List<ItemCotacao> itensCotacao;

		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(idCotacao);
			inspecaoService.findCotacaoItemInspecaoCompletaBySeqCotacao(idCotacao);
			itensCotacao = cotacaoService.getItemsSemInspecao(idCotacao);
			model.addAttribute("isCorretor", SecurityUtils.isCorretor());
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			model.addAttribute("origem", origem(origem));
			model.addAttribute("emailCorretorInspecao",cotacaoView.getEmailCorretorInspecao());
			model.addAttribute("urlInspecaoInteligente",parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroInspecaoInteligenteConsulta(parametroGeralService.getUrlByNome(ParametroGeralEnum.INSPECAO_INTELIGENTE_TOMCAT))));
			model.addAttribute("readOnly",isReadOnly(cotacaoView));
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}

		model.addAttribute("idCotacao", idCotacao);
		model.addAttribute("itensCotacao", itensCotacao);

		return Paginas.inspecao.value();
	}
	
	private boolean isReadOnly(CotacaoView cotacaoView) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario) && !cotacaoView.getCodigoSituacaoReadOnly().equals(CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao().intValue());
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se � usu�rio do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}

	@GetMapping("/{idCotacao}/itens")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<ItemInspecaoView> listaItensInspecao(@PathVariable("idCotacao") BigInteger idCotacao){
		List<ItemInspecao> itens = inspecaoService.listaItensInspecaoPorCotacao(idCotacao);
		return mapper.toListOfInspecaoView(itens);
	}
	
	@PostMapping("/{idCotacao}/itens")
	public ResponseEntity<?> salvaItemInspecao(@RequestBody @Valid ItemInspecaoView itemView, @PathVariable("idCotacao") BigInteger idCotacao){
		ItemInspecao itemInspecao = mapper.toItemInspecao(itemView);
		ItemInspecao itemIncluido = new ItemInspecao(); 
		
		try {
			logger.info(itemInspecao.getEmailCorretorInspecao());
			inspecaoService.atualizaEmailCorretorInspecao(idCotacao,itemInspecao.getEmailCorretorInspecao());
			
			if(itemView.getIncluirParaTodos()){
				List<ItemInspecao> itensIncluidos = inspecaoService.incluiItemInspecaoParaTodosItensDaCotacao(itemInspecao, idCotacao);
				return ResponseEntity.ok(mapper.toListOfInspecaoView(itensIncluidos));
			} 
			itemIncluido = inspecaoService.incluiItemInspecao(itemInspecao);

		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}

		return ResponseEntity.ok(mapper.toItemInspecaoView(itemIncluido));
		
	}	

	@DeleteMapping("/{idCotacao}/itens/{idItemInspecao}")
	@ResponseStatus(HttpStatus.OK)
	public void excluiItemInspecao(@PathVariable("idItemInspecao") BigInteger idItemInspecao){
		inspecaoService.excluiItemInspecao(idItemInspecao);
	}
	
	@GetMapping("/solicita/{sequencialItemInspecao}")
	public ResponseEntity<?> solicitaInspecao(@PathVariable("sequencialItemInspecao") BigInteger sequencialItemInspecao, Model model){
		
		ResultadoREST<Object> resultado = null;
		try {
			resultado = inspecaoInteligenteService.solicitaInspecaoInteligente(sequencialItemInspecao,super.getUser());
			
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}
		return ResponseEntity.ok(resultado);
	}	

	@GetMapping("/solicita/cancelamento/{sequencialItemInspecao}")
	public ResponseEntity<?> solicitaCancelamentoInspecaoInteligente(@PathVariable("sequencialItemInspecao") BigInteger sequencialItemInspecao, Model model){
		Integer retorno = 1;
		try {
			retorno = inspecaoInteligenteService.solicitaCancelamentoInspecaoInteligente(sequencialItemInspecao,super.getUser());
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}
		return ResponseEntity.ok(retorno);
	}

	private String origem(String origem) {
		
		if(StringUtils.contains(origem, "transmissao2")) {
			return "transmissao2";
		}
		
		if(StringUtils.contains(origem, "transmissao")) {
			return "transmissao";
		}
		
		if(StringUtils.contains(origem, "alteracao")) {
			return "entrada/endosso/alteracaoInclusaoExclusao";
		}
		
		return "entrada/home";
	}
		
}
