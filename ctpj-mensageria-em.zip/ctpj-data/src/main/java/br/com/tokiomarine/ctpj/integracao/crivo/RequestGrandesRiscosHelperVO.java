
package br.com.tokiomarine.ctpj.integracao.crivo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de RequestGrandesRiscosHelperVO complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="RequestGrandesRiscosHelperVO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cdCorret" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cdSegmento" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cdSisOrigem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="chToken" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="idLogin" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="noCNPJ" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="policy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="validationInstruction" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestGrandesRiscosHelperVO", propOrder = {
    "cdCorret",
    "cdSegmento",
    "cdSisOrigem",
    "chToken",
    "idLogin",
    "noCNPJ",
    "policy",
    "validationInstruction"
})
public class RequestGrandesRiscosHelperVO {

    @XmlElement(required = true, nillable = true)
    protected String cdCorret;
    @XmlElement(required = true, nillable = true)
    protected String cdSegmento;
    @XmlElement(required = true, nillable = true)
    protected String cdSisOrigem;
    @XmlElement(required = true, nillable = true)
    protected String chToken;
    @XmlElement(required = true, nillable = true)
    protected String idLogin;
    @XmlElement(required = true, nillable = true)
    protected String noCNPJ;
    @XmlElement(required = true, nillable = true)
    protected String policy;
    @XmlElement(required = true, nillable = true)
    protected String validationInstruction;

    /**
     * Obt�m o valor da propriedade cdCorret.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCdCorret() {
        return cdCorret;
    }

    /**
     * Define o valor da propriedade cdCorret.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCdCorret(String value) {
        this.cdCorret = value;
    }

    /**
     * Obt�m o valor da propriedade cdSegmento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCdSegmento() {
        return cdSegmento;
    }

    /**
     * Define o valor da propriedade cdSegmento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCdSegmento(String value) {
        this.cdSegmento = value;
    }

    /**
     * Obt�m o valor da propriedade cdSisOrigem.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCdSisOrigem() {
        return cdSisOrigem;
    }

    /**
     * Define o valor da propriedade cdSisOrigem.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCdSisOrigem(String value) {
        this.cdSisOrigem = value;
    }

    /**
     * Obt�m o valor da propriedade chToken.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChToken() {
        return chToken;
    }

    /**
     * Define o valor da propriedade chToken.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChToken(String value) {
        this.chToken = value;
    }

    /**
     * Obt�m o valor da propriedade idLogin.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdLogin() {
        return idLogin;
    }

    /**
     * Define o valor da propriedade idLogin.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdLogin(String value) {
        this.idLogin = value;
    }

    /**
     * Obt�m o valor da propriedade noCNPJ.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoCNPJ() {
        return noCNPJ;
    }

    /**
     * Define o valor da propriedade noCNPJ.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoCNPJ(String value) {
        this.noCNPJ = value;
    }

    /**
     * Obt�m o valor da propriedade policy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicy() {
        return policy;
    }

    /**
     * Define o valor da propriedade policy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicy(String value) {
        this.policy = value;
    }

    /**
     * Obt�m o valor da propriedade validationInstruction.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationInstruction() {
        return validationInstruction;
    }

    /**
     * Define o valor da propriedade validationInstruction.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationInstruction(String value) {
        this.validationInstruction = value;
    }

}
