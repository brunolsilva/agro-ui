package br.com.tokiomarine.ctpj.auth.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.ProcessaLogin;
import br.com.tokiomarine.ctpj.cotacao.service.ContaCorrenteService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.sct.response.EntradaCadastroCotacaoResponse;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Service
@Transactional(rollbackFor = ServiceException.class)
public class EntradaCadastroCotacaoService {

	private static final Logger logger = LogManager.getLogger(EntradaCadastroCotacaoService.class);

	@Autowired
	private MailUtilService mailUtilService;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private ContaCorrenteService contaCorrenteService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ParametroGeralService parametroGeralService;

	public EntradaCadastroCotacaoResponse processaTokenCadastroCotacao(String token,Long cdUsuro,Long cdGrp, HttpServletRequest request){

		EntradaCadastroCotacaoResponse response = new EntradaCadastroCotacaoResponse();
		response.setSucesso(true);
		List<Mensagem> mensagens = new ArrayList<Mensagem>();
		response.setMensagens(mensagens);
		Integer codigoErro = 0;
		try {

			this.validaParametros(response,token,cdUsuro,cdGrp);

			if (!response.isSucesso()) {
				logger.error("processaTokenCadastroCotacao parâmetros inválidos");
				StringBuilder sb = new StringBuilder(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
				mailUtilService.sendMailErro(sb);

			} else {

				logger.error("parâmetros validados");

				CtpjToken ctpjToken = new CtpjToken();
				ctpjToken.setToken(token);
				ctpjToken.setCdGrpEnum(GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(cdGrp.intValue()));
				ctpjToken.setCdUsuro(cdUsuro.intValue());

				User user = new User();
				user.setGrupoUsuario(ctpjToken.getCdGrpEnum());
				user.setCdUsuro(ctpjToken.getCdUsuro());

				SolicitacaoCotacao solicitacaoCotacao = this.processaToken(ctpjToken);
			
				ProcessaLogin processaLogin = null;

				if (solicitacaoCotacao == null || solicitacaoCotacao.getNrSolctCotac() == null) {
					logger.error("Token inválido");
					Mensagem mensagem = new Mensagem();
					mensagem.setDescricao("Token informado inválido, token: " + token + " cdUsuro: " + cdUsuro + " cdGrp: " + cdGrp);
					mensagem.setCodigo(codigoErro);
					response.getMensagens().add(mensagem);
					response.setSucesso(false);
					codigoErro++;
				} else {
					
					ctpjToken.setSolicitacaoCotacao(solicitacaoCotacao);

					processaLogin = cotacaoService.processaLogin(ctpjToken,user);

					if (processaLogin != null && processaLogin.isSucesso()) {
						Cotacao cotacao = processaLogin.getCotacao();
						contaCorrenteService.bindContaCorrenteGlobalByEntradaSCT(ctpjToken,cotacao, request);
						logger.error("Cotação não existe...");
						Mensagem mensagem = new Mensagem();
						mensagem.setDescricao("Cotação criada com sucesso cotação: " + cotacao.getNumeroCotacaoProposta() + " versão: " + cotacao.getVersaoCotacaoProposta());
						mensagem.setCodigo(0);
						response.getMensagens().add(mensagem);
					} else {
						Mensagem mensagem = new Mensagem();
						if(processaLogin != null) {
							mensagem.setDescricao(processaLogin.getMensagens().toString());
						}
						mensagem.setCodigo(codigoErro);
						response.getMensagens().add(mensagem);
						response.setSucesso(false);
						codigoErro++;
					}

				}

			}

		} catch (Exception e) {
			logger.error("Erro ao processaTokenCadastroCotacao: ",e);
			Mensagem msg = new Mensagem();
			msg.setCodigo(codigoErro);
			msg.setDescricao("Erro geral ao processar processa token cadastro cotação, parâmetros informados token: " + token + " cdUsuro: " + cdUsuro + " cdGrp: " + cdGrp);
			mensagens.add(msg);
			response.getMensagens().add(msg);
			response.setSucesso(false);
			StringBuilder sb = new StringBuilder(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
			mailUtilService.sendMailErro(e,sb);
		}

		return response;

	}

	private void validaParametros(EntradaCadastroCotacaoResponse response,String token,Long cdUsuro,Long cdGrp) {

		response.setSucesso(true);
		List<Mensagem> mensagens = new ArrayList<Mensagem>();
		Integer codigoErro = 0;

		try {

			if (token == null || token.isEmpty()) {
				Mensagem msg = new Mensagem();
				msg.setCodigo(codigoErro);
				msg.setDescricao("Parâmetro token não informado");
				mensagens.add(msg);
				response.setSucesso(false);
				codigoErro++;
			}

			if (cdUsuro == null) {
				Mensagem msg = new Mensagem();
				msg.setCodigo(codigoErro);
				msg.setDescricao("Parâmetro código do Usuário não informado");
				mensagens.add(msg);
				response.setSucesso(false);
				codigoErro++;
			}

			if (cdGrp == null) {

				Mensagem msg = new Mensagem();
				msg.setCodigo(codigoErro);
				msg.setDescricao("Parâmetro código do grupo do Usuário não informado");
				mensagens.add(msg);
				response.setSucesso(false);
				codigoErro++;

			} else {

				GrupoUsuarioEnum cdGrpEnum = GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(cdGrp.intValue());

				if (!cdGrpEnum.getCdGrp().equals(GrupoUsuarioEnum.CORRETOR.getCdGrp())) {
					Mensagem msg = new Mensagem();
					msg.setCodigo(codigoErro);
					msg.setDescricao("Parâmetro código do grupo do Usuário informado inválido, entrada somente permida para perfil Corretor, o informado foi: " + cdGrpEnum.getCdGrp());
					mensagens.add(msg);
					response.setSucesso(false);
					codigoErro++;
				}
			}

			if (!response.isSucesso()) {
				logger.error("Erro ao validar parâmetros");
				StringBuilder sb = new StringBuilder();
				sb.append("Erro ao processaTokenCadastroCotacao parametros inválidos").append(CTP.quebraDeLinha.caracter());
				sb.append("token...:	" + token).append(CTP.quebraDeLinha.caracter());
				sb.append("cdUsuro.:	" + cdUsuro).append(CTP.quebraDeLinha.caracter());
				sb.append("cdGrp...:	" + cdGrp).append(CTP.quebraDeLinha.caracter());
				sb.append("response:	" + JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
				mailUtilService.sendMailErro(sb);
			}

		} catch (Exception e) {
			logger.error("Erro ao processaTokenCadastroCotacao: ",e);
			Mensagem msg = new Mensagem();
			msg.setCodigo(codigoErro);
			msg.setDescricao("Erro geral ao processar processa token cadastro cotação, parâmetros informados token: " + token + " cdUsuro: " + cdUsuro + " cdGrp: " + cdGrp);
			mensagens.add(msg);
			response.setSucesso(false);
		}

	}

	private SolicitacaoCotacao processaToken(CtpjToken ctpjToken) throws Exception {

		SolicitacaoCotacao solicitacao = new SolicitacaoCotacao();
		StringBuilder msgInfo = new StringBuilder();

		ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroSCTValidaToken();

		if (urlEnum == null) {
			logger.error("Erro ao na busca da url, urlEnum nula: " + urlEnum);
			throw new Exception("Erro ao na busca da url, urlEnum nula ");
		}

		String url = null;

		try {
			url = parametroGeralService.getUrlByNome(urlEnum);
		} catch (Exception e) {
			logger.error("Erro ao na consulta na busca do Paramentro: " + e.getMessage());
			throw new Exception("Erro ao na consulta na busca do Paramentro: ",e);
		}

		if (StringUtils.isEmpty(url)) {
			logger.error("URL de acesso ao gerar nosso numero nula ou vazia ");
			throw new ServiceException("URL de acesso ao gerar nosso numero nula ou vazia ");
		}

		url = url.concat("?cdUsuro={cdUsuro}&token={token}");

		msgInfo.append("Token a ser validado: " + ctpjToken.getToken()).append(CTP.quebraDeLinha.caracter());
		msgInfo.append("Ambiente detectado: " + AmbienteUtil.getAmbienteDetectado()).append(CTP.quebraDeLinha.caracter());
		msgInfo.append("Url de acesso: " + url).append(CTP.quebraDeLinha.caracter());
		Map<String,String> parametros = new HashMap<>(2);
		parametros.put("cdUsuro",String.valueOf(ctpjToken.getCdUsuro()));
		parametros.put("token",ctpjToken.getToken());
		solicitacao = restTemplate.getForObject(url,SolicitacaoCotacao.class,parametros);
		msgInfo.append("Response SCT: " + JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(solicitacao)).append(CTP.quebraDeLinha.caracter());
		logger.info(msgInfo.toString());

		return solicitacao;
	}

}
