package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import br.com.tokiomarine.ctpj.cotacao.validator.constraint.IncluirParaTodos;

/**
 * Classe que transporta os dados do formulário de inclusão de novos itens de relação de bens
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@IncluirParaTodos(campoIncluirParaTodos="incluirParaTodos", campoItemCotacao="itemCotacao", message="Item Cotação é obrigatório")
public class ItemRelacaoBemView {	
	
	private BigInteger sequencialItemRelacaoBem;
	
	private BigInteger itemCotacao;
	
	private BigInteger numeroItemCotacao;
	
	@NotBlank(message = "Descrição do Bem não pode ser nulo")
	@Length(max = 100,message = "Descrição do Bem  deve possuir no máximo 20 caracteres")
	private String descricaoBem;
	
	@NotNull(message = "Valor do Risco Declarado é obrigatório")
	private BigDecimal valorRiscoDeclarado;
	
	private boolean incluirParaTodos = false;

	public ItemRelacaoBemView(){
		this.valorRiscoDeclarado = BigDecimal.ZERO;
	}
	
	public ItemRelacaoBemView(BigInteger itemCotacao, String descricaoBem, BigDecimal valorRiscoDeclarado) {
		super();
		this.itemCotacao = itemCotacao;
		this.descricaoBem = descricaoBem;
		this.valorRiscoDeclarado = valorRiscoDeclarado;
	}

	public ItemRelacaoBemView(BigInteger sequencialItemRelacaoBem, BigInteger itemCotacao, BigInteger numeroItemCotacao, String descricaoBem, BigDecimal valorRiscoDeclarado) {
		super();
		this.sequencialItemRelacaoBem = sequencialItemRelacaoBem;
		this.itemCotacao = itemCotacao;
		this.numeroItemCotacao = numeroItemCotacao;
		this.descricaoBem = descricaoBem;
		this.valorRiscoDeclarado = valorRiscoDeclarado;
	}

	public BigInteger getSequencialItemRelacaoBem() {
		return sequencialItemRelacaoBem;
	}

	public void setSequencialItemRelacaoBem(BigInteger sequencialItemRelacaoBem) {
		this.sequencialItemRelacaoBem = sequencialItemRelacaoBem;
	}

	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public String getDescricaoBem() {
		return descricaoBem;
	}

	public void setDescricaoBem(String descricaoBem) {
		this.descricaoBem = descricaoBem;
	}

	public BigDecimal getValorRiscoDeclarado() {
		return valorRiscoDeclarado;
	}

	public void setValorRiscoDeclarado(BigDecimal valorRiscoDeclarado) {
		this.valorRiscoDeclarado = valorRiscoDeclarado;
	}

	public BigInteger getNumeroItemCotacao() {
		return numeroItemCotacao;
	}

	public void setNumeroItemCotacao(BigInteger numeroItemCotacao) {
		this.numeroItemCotacao = numeroItemCotacao;
	}

	public boolean isIncluirParaTodos() {
		return incluirParaTodos;
	}

	public void setIncluirParaTodos(boolean incluirParaTodos) {
		this.incluirParaTodos = incluirParaTodos;
	}

	@Override
	public String toString() {
		return "ItemRelacaoBemView [sequencialItemRelacaoBem=" + sequencialItemRelacaoBem + ", itemCotacao=" + itemCotacao + ", numeroItemCotacao=" + numeroItemCotacao + 
				", descricaoBem=" + descricaoBem + ", valorRiscoDeclarado=" + valorRiscoDeclarado + ", incluirParaTodos=" + incluirParaTodos
				+ "]";
	}
	
}
