package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;

public class CoberturaEFranquiaView {

	private BigInteger itemCotacao;
	private String cobertura;
	private String franquia;

	public CoberturaEFranquiaView() {
		super();
	}
	
	public CoberturaEFranquiaView(BigInteger itemCotacao, String cobertura, String franquia) {
		super();
		this.itemCotacao = itemCotacao;
		this.cobertura = cobertura;
		this.franquia = franquia;
	}
	
	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public String getCobertura() {
		return cobertura;
	}

	public void setCobertura(String cobertura) {
		this.cobertura = cobertura;
	}

	public String getFranquia() {
		return franquia;
	}

	public void setFranquia(String franquia) {
		this.franquia = franquia;
	}	

	@Override
	public String toString() {
		return "CoberturaEFranquiaView [itemCotacao=" + itemCotacao + ", cobertura=" + cobertura + ", franquia=" + franquia + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cobertura == null) ? 0 : cobertura.hashCode());
		result = prime * result + ((franquia == null) ? 0 : franquia.hashCode());
		result = prime * result + ((itemCotacao == null) ? 0 : itemCotacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CoberturaEFranquiaView other = (CoberturaEFranquiaView) obj;
		if (cobertura == null) {
			if (other.cobertura != null)
				return false;
		} else if (!cobertura.equals(other.cobertura))
			return false;
		if (franquia == null) {
			if (other.franquia != null)
				return false;
		} else if (!franquia.equals(other.franquia))
			return false;
		if (itemCotacao == null) {
			if (other.itemCotacao != null)
				return false;
		} else if (!itemCotacao.equals(other.itemCotacao))
			return false;
		return true;
	}

}
