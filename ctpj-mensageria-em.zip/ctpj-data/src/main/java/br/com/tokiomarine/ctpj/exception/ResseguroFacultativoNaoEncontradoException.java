package br.com.tokiomarine.ctpj.exception;

import java.math.BigInteger;

public class ResseguroFacultativoNaoEncontradoException extends Exception {
	private static final long serialVersionUID = 1L;

	public ResseguroFacultativoNaoEncontradoException(BigInteger seqCotacao){
		super("Não foi encontrado resseguro facultativo para a cotação " + seqCotacao);
	}
	
	public ResseguroFacultativoNaoEncontradoException(String message) {
		super(message);
	}


}
