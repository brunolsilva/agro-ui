package br.com.tokiomarine.ctpj.aop;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.aop.ThrowsAdvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.domain.cotacao.ParametrosGeral;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.util.MailUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Component
public class LogAOP implements ThrowsAdvice {

	private static Logger logger = LogManager.getLogger(LogAOP.class);

	@Autowired
	private ParametroGeralService controleParametroService;

	public void afterThrowing(Exception e) {
		System.out.println(">>>>> " + e.getMessage());
		if (!AmbienteUtil.isServidorLocal()) {
			try {
				ParametrosGeral parametro = controleParametroService.getParametroGeralByNome(ParametroGeralEnum.LOGAOP_CTPJ);
				List<String> emails = Arrays.asList(parametro.getValorCaracter().split(";"));
				MailUtil.getInstance().sendMails(ExceptionUtils.getFullStackTrace(e),"ERRO EM: " + AmbienteUtil.getAmbienteDetectado() + " - " + CTP.nome.value(),emails);
			} catch (ServiceException e1) {
				logger.error("Erro ao tentar obter lista de emails, email de erro não enviado.",e1);
			}
		}
	}
}
