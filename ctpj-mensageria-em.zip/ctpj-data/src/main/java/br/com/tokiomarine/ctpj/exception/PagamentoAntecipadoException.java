package br.com.tokiomarine.ctpj.exception;


public class PagamentoAntecipadoException extends Exception{

	private static final long serialVersionUID = -3346313279043958074L;

	public PagamentoAntecipadoException(String message) {
		super(message);
	}

	public PagamentoAntecipadoException(String message,Throwable cause) {
		super(message,cause);
	}
}
