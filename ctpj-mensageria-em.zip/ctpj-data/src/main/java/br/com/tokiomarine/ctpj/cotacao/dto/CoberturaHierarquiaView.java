package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoberturaHierarquiaView implements Serializable {

	private static final long serialVersionUID = 3061613921039040836L;

	private Integer codigoCobertura;
	private Integer tipo;
	private List<Integer> coberturaPai;
	private String descricao;
	private boolean exigeVagasGaragem;
	private List<Long> rubricasLiberadas;

	public CoberturaHierarquiaView() {
		/**
		 * Construtor Padrão
		 */
	}

	public CoberturaHierarquiaView(Integer codigoCobertura, List<Integer> coberturaPai, String descricao, boolean exigeVagasGaragem, Integer tipo) {
		this.codigoCobertura = codigoCobertura;
		this.coberturaPai = coberturaPai;
		this.descricao = descricao;
		this.tipo = tipo;
		this.setExigeVagasGaragem(exigeVagasGaragem);
	}

	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}

	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}

	public List<Integer> getCoberturaPai() {
		return coberturaPai;
	}

	public void setCoberturaPai(List<Integer> coberturaPai) {
		this.coberturaPai = coberturaPai;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public boolean isExigeVagasGaragem() {
		return exigeVagasGaragem;
	}

	public void setExigeVagasGaragem(boolean exigeVagasGaragem) {
		this.exigeVagasGaragem = exigeVagasGaragem;
	}

	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}

	public List<Long> getRubricasLiberadas() {
		return rubricasLiberadas;
	}

	public void setRubricasLiberadas(List<Long> rubricasLiberadas) {
		this.rubricasLiberadas = rubricasLiberadas;
	}
	
	
}