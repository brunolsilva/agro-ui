package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.FormaPagamentoBanco;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilComercialRepository;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.Banco;
import br.com.tokiomarine.ctpj.infra.domain.BancoCorretorIndisponivel;
import br.com.tokiomarine.ctpj.infra.domain.BancoFinalidade;
import br.com.tokiomarine.ctpj.infra.domain.FinalidadeBancoEnum;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCorretor;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Repository
public class BancoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private ProdutoBancoRepository produtoBancoRepository;

	@Autowired
	private BancoRepository bancoRepository;

	@Autowired
	private PerfilComercialRepository perfilComercialRepository;

	private static Logger logger = LogManager.getLogger(BancoRepository.class);

	public List<Banco> findAll() throws RepositoryException{
		return mongoTemplate.findAll(Banco.class);
	}
	
	public Banco findBancoByCodigo(Long banco){
		return mongoTemplate.findOne(
				query(where("banco").is(banco)
						), Banco.class);
	}

	public List<FormaPagamentoBanco> findAll(CotacaoView cotacao) throws RepositoryException {
		try {
			User user = SecurityUtils.getCurrentUser();
			List<FormaPagamentoBanco> formasPagamentoBanco;
			Integer destinoEmissao = cotacao.getIdDestinoEmissao() != null ? cotacao.getIdDestinoEmissao().getId(): DestinoEmissaoEnum.PLT.getId();
			Long corretor = Long.valueOf(cotacao.getCodigoCorretorACSEL());
			if(user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR) {
				PerfilComercialCorretor perfilComercialCorretor = perfilComercialRepository.findPerfilComercial(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCalculo());
				if(perfilComercialCorretor != null) {
					formasPagamentoBanco = produtoBancoRepository.findProdutoBanco(
							perfilComercialCorretor.getPerfilComercial(),
							corretor,
							cotacao.getCodigoProduto(),
							cotacao.getDataCalculo(),
							destinoEmissao);
				} else {
					formasPagamentoBanco = produtoBancoRepository.findProdutoBanco(
							corretor,
							cotacao.getCodigoProduto(),
							cotacao.getDataCalculo(),
							destinoEmissao);
				}
			} else {
				formasPagamentoBanco = produtoBancoRepository.findProdutoBanco(
						corretor,
						cotacao.getCodigoProduto(),
						cotacao.getDataCalculo(), 
						destinoEmissao);
			}

			return formasPagamentoBanco;
		} catch (Exception e) {
			logger.error("Erro na Busca do Banco ", e);
			throw new RepositoryException("Erro na Busca do Banco", e);
		}
	}
	
	public List<FormaPagamentoBanco> findAllByCorretorAndProduto(Long codigoCorretor, Integer codigoProduto) throws RepositoryException {
		try {
			List<FormaPagamentoBanco> formasPagamentoBanco;
			Date dataCalculo = new Date();
			PerfilComercialCorretor perfilComercialCorretor = perfilComercialRepository.findPerfilComercial(
					codigoCorretor,
					codigoProduto,
					dataCalculo);
			if(perfilComercialCorretor != null) {
				formasPagamentoBanco = produtoBancoRepository.findProdutoBanco(perfilComercialCorretor.getPerfilComercial(),codigoCorretor,codigoProduto,dataCalculo,1);
			} else {
				formasPagamentoBanco = produtoBancoRepository.findProdutoBanco(codigoCorretor,codigoProduto,dataCalculo,1);
			}
			
			List<FormaPagamentoBanco> listaIndisponivel = new ArrayList<>();
			List<BancoCorretorIndisponivel> indisponiveis = bancosIndisponiveis(codigoProduto, String.valueOf(codigoCorretor));
			for(BancoCorretorIndisponivel indisponivel: indisponiveis) {
				listaIndisponivel.add(new FormaPagamentoBanco(indisponivel.getBanco(), null, indisponivel.getFormaPagamento()));
			}
			if(!indisponiveis.isEmpty()) {
				formasPagamentoBanco.removeAll(listaIndisponivel);
				return formasPagamentoBanco;
			} else {
				return formasPagamentoBanco;
			}
		} catch (Exception e) {
			logger.error("Erro na Busca do Banco Corretor/Produto ", e);
			throw new RepositoryException("Erro na Busca do Banco Corretor/Produto", e);
		}
	}
	
	public List<BancoFinalidade> findBancoFinalidadeDevolucao() throws RepositoryException {
		try{
			return mongoTemplate.find(
					query(where("finalidade").is(FinalidadeBancoEnum.DEVOLUCAO.toString())
							).with(new Sort(Sort.Direction.ASC, "descricao")), BancoFinalidade.class);
		} catch (Exception e) {
			logger.error("Erro na Busca do Banco ", e);
			throw new RepositoryException("Erro na Busca do Banco", e);
		}
	}
	
	public List<BancoCorretorIndisponivel> bancosIndisponiveis(CotacaoView cotacao) {
		return mongoTemplate.find(
				query(where("produto").is(cotacao.getCodigoProduto())
						.and("corretor").is(cotacao.getCodigoCorretorACSEL())
						), BancoCorretorIndisponivel.class);
	}

	public List<BancoCorretorIndisponivel> bancosIndisponiveis(Integer produto, String corretor) {
		return mongoTemplate.find(
				query(where("produto").is(produto)
						.and("corretor").is(corretor)
						), BancoCorretorIndisponivel.class);
	}

	public List<Banco> findAllAtivos() throws RepositoryException{
		return mongoTemplate.find(query(where("ativo").is("S")),Banco.class);
	}
	
	public Banco findBancoPrimeiraParcela() {
		return mongoTemplate.findOne(
				query(where("ativo").is(SimNaoEnum.SIM)
						.and("bancoPrimeiraParcela").is(SimNaoEnum.SIM)
						), Banco.class);
	}

	
}