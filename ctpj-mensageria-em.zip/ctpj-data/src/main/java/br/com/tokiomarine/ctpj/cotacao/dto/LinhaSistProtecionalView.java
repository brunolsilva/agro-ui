package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;
import java.util.List;

/**
 * Objeto da camada de View que representa uma linha na tabela de sistemas protecionais
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class LinhaSistProtecionalView {

	private BigInteger itemCotacao;
	private BigInteger seqItemSistemaProtecional;
	private List<ClausulaItemSistemaProtecionalView> clausulas;
	
	public BigInteger getSeqItemSistemaProtecional() {
		return seqItemSistemaProtecional;
	}

	public void setSeqItemSistemaProtecional(BigInteger seqItemSistemaProtecional) {
		this.seqItemSistemaProtecional = seqItemSistemaProtecional;
	}

	private Long codItemSistProtecional;
	private String descricaoSistProtecional;
	
	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}	
	

	public String getDescricaoSistProtecional() {
		return descricaoSistProtecional;
	}

	public void setDescricaoSistProtecional(String descricaoSistProtecional) {
		this.descricaoSistProtecional = descricaoSistProtecional;
	}	

	public Long getCodItemSistProtecional() {
		return codItemSistProtecional;
	}

	public void setCodItemSistProtecional(Long codItemSistProtecional) {
		this.codItemSistProtecional = codItemSistProtecional;
	}

	public List<ClausulaItemSistemaProtecionalView> getClausulas() {
		return clausulas;
	}

	public void setClausulas(List<ClausulaItemSistemaProtecionalView> clausulas) {
		this.clausulas = clausulas;
	}
}
