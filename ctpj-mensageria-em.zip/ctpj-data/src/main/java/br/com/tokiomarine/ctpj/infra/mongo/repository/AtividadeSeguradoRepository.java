package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.MongoRegexCreator;
import org.springframework.data.repository.query.parser.Part;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.AtividadeSegurado;

@Repository
public class AtividadeSeguradoRepository {

	private static Logger logger = LogManager.getLogger(AtividadeSeguradoRepository.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	@LogPerformance
	public AtividadeSegurado getAtividadeSegurado(Integer classe,Integer digitoVerificador,Integer subClasse) throws RepositoryException {

		try {
			return mongoTemplate.findOne(query(where("classe").is(classe)
					.and("digitoVerificador").is(digitoVerificador)
					.and("subClasse").is(subClasse)),
					AtividadeSegurado.class);
		} catch (Exception e) {
			logger.error("Erro ao Buscar Atividade Segurado");
			throw new RepositoryException(e.getMessage(),e);
		}

	}

	@LogPerformance
	public AtividadeSegurado getAtividadeSegurado(Integer atividadePrincipal) {
		return mongoTemplate.findOne(
					query(where("atividadePrincipal").is(atividadePrincipal)),AtividadeSegurado.class);
	}

	@LogPerformance
	public AtividadeSegurado getAtividadeSeguradoAtivo(Integer atividadePrincipal) {
		return mongoTemplate.findOne(
					query(where("atividadePrincipal").is(atividadePrincipal)
							.and("inativo").is(false)),AtividadeSegurado.class);
	}

	@LogPerformance
	public List<AtividadeSegurado> findAllByNome(String q) throws RepositoryException {
		try {
			return mongoTemplate.find(
					query(where("situacao").is(1)
							.and("descricao").regex(MongoRegexCreator.INSTANCE.toRegularExpression(q, Part.Type.EXISTS), "i"))
					.with(new Sort(Direction.ASC, "descricao")) ,AtividadeSegurado.class);
		} catch (Exception e) {
			throw new RepositoryException(e.getMessage(), e);
		}
	}
	
	@LogPerformance
	public List<AtividadeSegurado> findAll() throws RepositoryException {
		try {
			return mongoTemplate.find(
					query(where("situacao").is(1))
					.with(new Sort(Direction.ASC, "descricao")) ,AtividadeSegurado.class);
		} catch (Exception e) {
			throw new RepositoryException(e.getMessage(), e);
		}
	}

}
