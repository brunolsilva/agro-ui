package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;

@Repository
public class ResseguroFacultativoRepository extends BaseDAO{
	
	public BigInteger save(ResseguroFacultativo resseguroFacultativo){
		return (BigInteger) getCurrentSession().save(resseguroFacultativo);
	}
	
	public Optional<ResseguroFacultativo> findById(BigInteger seqResseguroFacultativo){
		ResseguroFacultativo rf = getCurrentSession().get(ResseguroFacultativo.class, seqResseguroFacultativo);
		return Optional.ofNullable(rf);
	}
	
	public Optional<ResseguroFacultativo> findByCotacao(BigInteger seqCotacao){
		String hql = new StringBuilder()
				.append("select ressegFacul ")
				.append("from ResseguroFacultativo ressegFacul ")
				.append("join ressegFacul.cotacao cotacao ")
				.append("where cotacao.sequencialCotacaoProposta = :seqCotacao")
				.toString();
		
		ResseguroFacultativo resultado = (ResseguroFacultativo) getCurrentSession()
				.createQuery(hql)
				.setParameter("seqCotacao", seqCotacao)
				.setMaxResults(1)
				.uniqueResult();
		
		return Optional.ofNullable(resultado);
	}	
	
	public void deleteByCotacao(BigInteger seqCotacao){
		findByCotacao(seqCotacao)
		.ifPresent(resseguroFacultativo -> getCurrentSession().delete(resseguroFacultativo));
	}

}
