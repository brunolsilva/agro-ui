package br.com.tokiomarine.ctpj.cotacao.controller;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.tokiomarine.componente.utils.CelularUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaAdicionar;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaExclusao;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CalculoCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.DuplicarCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.exception.CalculoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.AtividadeSegurado;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoUsuario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialBloqueioAtividade;
import br.com.tokiomarine.ctpj.infra.enums.ClassificacaoAtividadeEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.AtividadeSeguradoService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CoberturaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.PerfilComercialBloqueioAtividadeService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.integracao.service.CotacaoDolarService;
import br.com.tokiomarine.ctpj.interfaceCSF.response.ResponseInterfaceCSF;
import br.com.tokiomarine.ctpj.jms.response.CotacaoDolarResponse;
import br.com.tokiomarine.ctpj.plataforma.request.ApoliceItemRequest;
import br.com.tokiomarine.ctpj.print.service.CotacaoPrintService;
import br.com.tokiomarine.ctpj.print.service.PropostaPrintService;
import br.com.tokiomarine.ctpj.sct.form.EmailContatoSCT;
import br.com.tokiomarine.ctpj.sct.form.EnviarArquivoSCT;
import br.com.tokiomarine.ctpj.sct.service.SCTService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Controller
@RequestMapping(value = "/cotacao")
public class CotacaoController extends AbstractController {

	private static final Logger logger = LogManager.getLogger(CotacaoController.class);

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private CoberturaService coberturaService;
	
	@Autowired
	private AtividadeSeguradoService atividadeSeguradoService;
	
	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private CalculoCotacaoService calculoCotacaoService;
	
	@Autowired
	private CotacaoDolarService cotacaoDolarService;

	@Autowired
	private SCTService sctService;
	
	@Autowired
	private CotacaoPrintService cotacaoPrintService;

	@Autowired
	private PropostaPrintService propostaPrintService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;
	
	@Autowired
	private PerfilComercialBloqueioAtividadeService perfilComercialBloqueioAtividadeService;

	@Autowired
	private DuplicarCotacaoService duplicarCotacaoService;

	@Autowired
	private ParametroGeralService parametroGeralService;

	@LogPerformance
	@PostMapping(value = "/salvar")
	public @ResponseBody ResultadoREST<String> salvar(
			@Valid @RequestBody CotacaoView cotacao,
			BindingResult result,
			HttpSession session,
			RedirectAttributes redirectAttributes,
			HttpServletResponse response) throws IOException {

		ResultadoREST<String> resultado = new ResultadoREST<>();

		try {
			
			boolean calculaLmi = validacaoCalculoLmi(cotacao);
			if(!calculaLmi) {
				List<ValidacaoLote> listaValidacao = Arrays.asList(new ValidacaoLote(0, "Nos casos de produtos com LMI único devem ser cadastrados pelo menos 2 locais de risco."));
				resultado.setListaValidacaoLote(listaValidacao);
				resultado.setSuccess(false);
			} else {
				List<ValidacaoLote> listaValidacao = cotacaoService.save(cotacao);
				resultado.setListaValidacaoLote(listaValidacao);
				HashMap<String, String> coberturasAjustadas = new HashMap<>();

				for (ValidacaoLote validacaoLote: listaValidacao) {
					if(!StringUtils.isBlank(validacaoLote.getCoberturaAjustada())) {
						coberturasAjustadas.put(validacaoLote.getCoberturaAjustada(),validacaoLote.getDescricao());
					}
				}

				session.setAttribute("coberturasAjustadas",coberturasAjustadas);

				for (Iterator<ValidacaoLote> iterator = listaValidacao.iterator(); iterator.hasNext();) {
					ValidacaoLote validacaoLote = iterator.next();
				    if (validacaoLote.getCoberturaAjustada() != null) {
				    	iterator.remove();
				    }
				}

				if(resultado.getListaValidacaoLote().isEmpty()) {
					resultado.setSuccess(true);
					if(cotacao.isCalculo()) {
						trataRetornoCalculo(cotacao, session);
					} else {
						session.setAttribute(SUCESSO, Arrays.asList("Dados Atualizados com Sucesso!"));
					}
				} else {
					resultado.setSuccess(false);
				}
			}
			
		} catch (Exception e) {
			logger.error("Erro ao salvar a cotação ", e);
			resultado.setSuccess(false);
		}

		return resultado;
	}

	private void trataRetornoCalculo(CotacaoView cotacao, HttpSession session) {
		boolean calculaLmi = validacaoCalculoLmi(cotacao);
		if(!calculaLmi) {
			session.setAttribute(ERRO,Arrays.asList("Nos casos de produtos com LMI único devem ser cadastrados pelo menos 2 locais de risco."));
		} else {
			try {
				ResultadoREST<List<String>> resultadoBlaze = calculoCotacaoService.calcularCotacao(cotacao.getSequencialCotacaoProposta(), getUser());
				if(resultadoBlaze.isSuccess()) {
					session.setAttribute(SUCESSO,  Arrays.asList("Cotação calculada com sucesso!"));
				} else if(resultadoBlaze.getRetornoObj() != null && !resultadoBlaze.getRetornoObj().isEmpty()){
					session.setAttribute(ERRO, resultadoBlaze.getRetornoObj());
				} else {
					session.setAttribute(ERRO,Arrays.asList(resultadoBlaze.getMensagem()));
				}
			} catch (CalculoException e) {
				ResultadoREST<List<String>> resultadoBlaze = e.getResultado();
				if(resultadoBlaze.isSuccess()) {
					session.setAttribute(SUCESSO,  Arrays.asList("Cotação calculada com sucesso!"));
				} else if(resultadoBlaze.getRetornoObj() != null && !resultadoBlaze.getRetornoObj().isEmpty()){
					session.setAttribute(ERRO, resultadoBlaze.getRetornoObj());
				} else {
					session.setAttribute(ERRO,Arrays.asList(resultadoBlaze.getMensagem()));
				}
			}
		}
	}
	
	@LogPerformance
	@GetMapping(value = "/infoPrimeiroItem/{sqCotacao}")
	public @ResponseBody ResultadoREST<?> getInfosPrimeiroItem(@PathVariable BigInteger sqCotacao) {
		ResultadoREST<Map<String,Object>> resultado = new ResultadoREST<>();

		try {
			Cotacao cotacao = cotacaoService.findComPrimeiroItem(sqCotacao);
			Map<String, Object> retorno = new HashMap<>();
			if(cotacao != null && cotacao.getListItem() != null && !cotacao.getListItem().isEmpty()){
				retorno.put("rubrica", cotacao.getListItem().iterator().next().getCodigoRubrica());
				retorno.put("bemCoberto", cotacao.getListItem().iterator().next().getCodigoBemCoberto());
				resultado.setRetornoObj(retorno);
			} else {
				retorno.put("rubrica", 0);
				retorno.put("bemCoberto", 0);
				resultado.setRetornoObj(retorno);
			}
			resultado.setSuccess(true);
		} catch (Exception e) {
			logger.info("Erro ao obter infos do primeiro item da cotação  ", e);
			resultado.setSuccess(false);
			resultado.setThrowable(e);
		}

		return resultado;
	}
	
	@LogPerformance
	@GetMapping(value = "/restricaoAtividade/{sqCotacao}/{codigoCategoria}")
	public @ResponseBody ResultadoREST<Long> getRestricaoAtividade(@PathVariable BigInteger sqCotacao,@PathVariable Long codigoCategoria) {
		ResultadoREST<Long> resultado = new ResultadoREST<>();
		resultado.setCodigo(0);
		//verifica se o usuário é corretor
		if(SecurityUtils.isCorretor()){			
			try {
				Cotacao cotacao = cotacaoService.findById(sqCotacao);
				PerfilCalculoUsuario perfilCalculo = perfilComercialService.findPerfilCalculo(SecurityUtils.getCurrentUser().getCdUsuro().longValue()
						, cotacao.getDataCotacao());
				if(perfilCalculo != null){
					PerfilComercialBloqueioAtividade perfilComercialBloqueio = perfilComercialBloqueioAtividadeService.findPerfilComercialBloqueio(
							cotacao, codigoCategoria, perfilCalculo);
					if(perfilComercialBloqueio != null){
						resultado.setCodigo(perfilComercialBloqueio.getClassificacao().getId());
						resultado.setMensagem(perfilComercialBloqueio.getClassificacao().getMensagem()); 
					}	
				}

				if(resultado.getCodigo() == 0) {
					//verifica se há restrição orçamento ramo/cpfcnpj
					if(cotacaoService.isOrcamentoRamoCpfCnpj(cotacao, SecurityUtils.getCurrentUser())) {
						resultado.setCodigo(ClassificacaoAtividadeEnum.AMARELA.getId());
						resultado.setMensagem("Esse cálculo será analisado pela Matriz. Favor preencher todos os campos e clicar no botão Enviar. O retorno se dará em até 48 horas úteis via SCT.");					
					}
				}

				resultado.setSuccess(true);
			} catch (Exception e) {
				logger.info("Erro ao obter restricao atividade da cotação  ", e);
				resultado.setSuccess(false);
				resultado.setThrowable(e);
			}
		}


		return resultado;
	}
	
	@LogPerformance
	@GetMapping(value = "/carrega")
	public @ResponseBody ResultadoREST<String> carrega() {
		ResultadoREST<String> resultado = new ResultadoREST<>();

		try {
			resultado.setSuccess(true);
		} catch (Exception e) {
			logger.info("Erro ao salvar a cotação  ", e);
			resultado.setSuccess(false);
			resultado.setThrowable(e);
		}

		return resultado;
	}

	@PostMapping(value = "/getPeriodosIndenitarios")
	public @ResponseBody Map<Integer, Object> getPeriodosIndenitarios(
			@RequestBody Map<String,String> params) {
		try {
			Date data = DateUtils.parseDate((String)params.get("dataCotacao"),"dd/MM/yyyy");
			Integer produto = Integer.valueOf(params.get("produto"));
			Integer cobertura = Integer.valueOf(params.get("cobertura"));
			Integer coberturaPrincipal = Integer.valueOf(params.get("coberturaPrincipal"));
			if(coberturaPrincipal.equals(0)) {
				coberturaPrincipal = null;
			}
			return coberturaService.getInfrasCobertura(produto,cobertura,data,coberturaPrincipal);
		} catch (ParseException e) {
			logger.error("Erro ao converter a data " + params.get("dataCotacao"), e);
		}

		return Collections.<Integer,Object>emptyMap();
	}

	@PostMapping(value = "/getMultiplos"/*/{produto}/{cobertura}/{dataCotacao}"*/)
	public @ResponseBody Map<String, List<BigDecimal>> getMultiplos(
			@RequestBody Map<String,String> params
			/*@PathVariable Integer produto,
			@PathVariable Integer cobertura,
			@PathVariable String dataCotacao*/) {
		try {
			Date data = DateUtils.parseDate((String)params.get("dataCotacao"),"dd/MM/yyyy");
			Integer produto = Integer.valueOf(params.get("produto"));
			Integer cobertura = Integer.valueOf(params.get("cobertura"));
			return coberturaService.getMultiplosFranquiaPrejuizo(produto,cobertura, data);

		} catch (ParseException e) {
			logger.error("Erro ao converter a data " + params.get("dataCotacao"), e);
		}

		return Collections.singletonMap(null,null);
	}

	@LogPerformance
	@GetMapping(value = "/excluiItem/{item}")
	public ResponseEntity<ResultadoREST<String>> excluirItem(@PathVariable BigInteger item) {
		ResultadoREST<String> resultadoREST = new ResultadoREST<>();
		try {
			cotacaoService.excluiItem(item);
			resultadoREST.setSuccess(true);
			return new ResponseEntity<>(resultadoREST, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Erro ao excluir o item: ", e);
			resultadoREST.setSuccess(false);
			resultadoREST.setThrowable(e);
			return new ResponseEntity<>(resultadoREST, HttpStatus.OK);
		}
	}

	@LogPerformance
	@PostMapping(value = "/excluiCobertura")
	public ResponseEntity<ResultadoREST<CoberturaAdicionar>> excluiCobertura(@RequestBody List<CoberturaExclusao> coberturas) {
		try {
			ResultadoREST<CoberturaAdicionar> resultadoREST = cotacaoService.excluiItemCobertura(coberturas);
			return new ResponseEntity<>(resultadoREST, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Erro ao excluir o item: ", e);
			ResultadoREST<CoberturaAdicionar> resultadoREST = new ResultadoREST<>(); 
			resultadoREST.setSuccess(false);
			resultadoREST.setThrowable(e);
			return new ResponseEntity<>(resultadoREST, HttpStatus.OK);
		}
	}

	@LogPerformance
	@GetMapping(value = "/atividadePrincipal")
	public @ResponseBody List<AtividadeSegurado> atividadePrincipal(@RequestParam String q) throws ServiceException {
		return atividadeSeguradoService.findAllByNome(q);
	}

	@LogPerformance
	@GetMapping(value = "/rubrica")
	public @ResponseBody List<ProdutoValorCarac> rubrica(
			@RequestParam Integer produto,
			@RequestParam(required = false) Integer nicho,
			@RequestParam(required = false) Integer atividadeSegurado) throws ServiceException {
		return caracteristicaService.findRubricas(produto, Caracteristicas.ATIVIDADE.codigo(), nicho, atividadeSegurado);
		//return caracteristicaService.findRubricas(produto, Caracteristicas.ATIVIDADE.codigo());
	}
	
	@LogPerformance
	@GetMapping(value = "/novaVersao/{sqCotacaoEscolhidaParaNovaVersao}")
	public ResponseEntity<ResultadoREST<BigInteger>> geraNovaVersaoCotacao(@PathVariable BigInteger sqCotacaoEscolhidaParaNovaVersao) {
		ResultadoREST<BigInteger> resultadoREST = new ResultadoREST<>();
		
		try {			
			BigInteger nrSqNovaVersaoCotacao = cotacaoService.geraNovaVersao(sqCotacaoEscolhidaParaNovaVersao,super.getUser(),false);
			resultadoREST.setRetornoObj(nrSqNovaVersaoCotacao);
			//Seta o retorno com sucesso
			resultadoREST.setSuccess(true);
			//Devolve o objeto JSON para o método
			return new ResponseEntity<>(resultadoREST, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Erro ao solicitar nova versão", e);
			resultadoREST.setSuccess(false);
			resultadoREST.setThrowable(e);
			return new ResponseEntity<>(resultadoREST, HttpStatus.OK);
		}
	}
		
	@LogPerformance
	@GetMapping(value = "/getCoeficienteConversaoMoeda/{dataPesquisa}")
	public ResponseEntity<ResultadoREST<CotacaoDolarResponse>> getCoeficienteConersaoMoeda(@PathVariable String dataPesquisa) {
		ResultadoREST<CotacaoDolarResponse> resultadoREST = new ResultadoREST<>();
		try {
			return new ResponseEntity<ResultadoREST<CotacaoDolarResponse>>(cotacaoDolarService.getCoeficienteConversaoMoeda(dataPesquisa) , HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar coeficiente de conversão de moeda: ", e);
			resultadoREST.setSuccess(false);
			resultadoREST.setThrowable(e);
			return new ResponseEntity<ResultadoREST<CotacaoDolarResponse>>(resultadoREST, HttpStatus.OK);
		}
	}

	@LogPerformance
	@PostMapping(value = "/enviaCotacaoParaAnaliseTecnica/{sqCotacao}")
	public @ResponseBody ResultadoREST<Object> enviaCotacaoParaAnaliseTecnica(@PathVariable BigInteger sqCotacao, @RequestBody EmailContatoSCT emailContatoSCT) {
		ResultadoREST<Object> resultado = new ResultadoREST<>();
		try {
			if("C".equalsIgnoreCase(emailContatoSCT.getIcTipoContt()) && emailContatoSCT.getNrDddContt() != null && emailContatoSCT.getNrTelefCelulContt() != null) {
				if(!CelularUtil.valida(emailContatoSCT.getNrDddContt(), emailContatoSCT.getNrTelefCelulContt().intValue())) {
					resultado.setMensagem("Celular informado inválido!");
					resultado.setSuccess(true);
					return resultado;
				}
			}
			cotacaoService.enviaCotacaoParaAnaliseTecnica(sqCotacao, emailContatoSCT);
			resultado.setSuccess(true);
			return resultado;
		} catch (Exception e) {
			logger.error("Erro ao enviar a cotacao com restricao para analise tecnica: " + sqCotacao, e);
			resultado.setSuccess(false);
			return resultado;
		}
	}

	@LogPerformance
	@GetMapping(value = "/corretor/emails")
	public ResponseEntity<?> recuperaEmailsCorretor() {
		try {
			return ResponseEntity.ok(sctService.emailsCorretorSCT());
		} catch (Exception e) {
			logger.error("Erro buscar os e-mails do corretor: ", e);
			return ResponseEntity.noContent().build();
		}
	}

	@LogPerformance
	@GetMapping(value = "/coberturasliberadas/{produto}/{rubrica}/{bemCoberto}")
	public ResponseEntity<?> coberturasLiberadas(
			@PathVariable Integer produto,
			@PathVariable Long rubrica,
			@PathVariable Long bemCoberto) {
		try {
			return ResponseEntity.ok(coberturaService.findCoberturasLiberadas(produto, rubrica, bemCoberto));
		} catch (Exception e) {
			logger.error("Erro ao enviar a cotacao com restricao para analise tecnica: " + produto, e);
			return ResponseEntity.badRequest().build();
		}
	}

	@LogPerformance
	@PostMapping(value = "/enviaArquivoSCT")
	public ResponseEntity<?> enviaArquivoSCT(@RequestBody EnviarArquivoSCT enviarArquivoSCT) {
		try {
			User user = SecurityUtils.getCurrentUser();
			Cotacao cotacao = cotacaoService.findById(enviarArquivoSCT.getCotacao());
			List<String> idsDocstore = new ArrayList<>();
			if(enviarArquivoSCT.isEnviaCotacao()) {
				ResultadoREST<ResponseInterfaceCSF> arquivoCotacao = cotacaoPrintService.gerarImpressaoCotacao(cotacao.getSequencialCotacaoProposta(),"S",user);
				if(arquivoCotacao.isSuccess() && arquivoCotacao.getRetornoObj() != null) {
					idsDocstore.add(arquivoCotacao.getRetornoObj().getIdArquivoDoc());
				}
			}

			if(enviarArquivoSCT.isEnviaProposta()) {
				ResultadoREST<ResponseInterfaceCSF> arquivoProposta = propostaPrintService.gerarImpressaoProposta(cotacao.getSequencialCotacaoProposta(),"S",user);
				if(arquivoProposta.isSuccess() && arquivoProposta.getRetornoObj() != null) {
					idsDocstore.add(arquivoProposta.getRetornoObj().getIdArquivoDoc());
				}
			}

			sctService.enviaArquivoSCT(cotacao,user,idsDocstore);
			return ResponseEntity.ok("Sucesso");
		} catch (Exception e) {
			logger.error("Erro ao enviar a cotacao arquivo para o SCT: " + enviarArquivoSCT.getCotacao(), e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao enviar a cotacao arquivo para o SCT");
		}
	}
	
	@LogPerformance
	@PostMapping(value = "/validaNumeroApoliceItemPlataforma")
	public ResponseEntity<?> validaNumeroApoliceItemPlataforma(@RequestBody ApoliceItemRequest apoliceItemRequest) {
		try {
			
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroConsultaItemRenovacao();
			if (urlEnum == null) {
				throw new ServiceException("Erro ao buscar URL referente ao Blaze de cálculo.");
			}

			String url = parametroGeralService.getUrlByNome(urlEnum);

			url = String.format(url, apoliceItemRequest.getCodigoRamo(), apoliceItemRequest.getCodigoApolice(), apoliceItemRequest.getCodigoItemApolice());
			ResponseEntity<ApoliceItemPlataformaResponse> resp = new RestTemplate().getForEntity(
					url, ApoliceItemPlataformaResponse.class);
			if(resp.getBody().getCodigo() == 0) {
				return ResponseEntity.ok(resp.getBody());
			}
		} catch(Exception e) {
			logger.error("Erro ao validar ramo/apólice/item " + apoliceItemRequest, e);
			return ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok().build();
	}

	@LogPerformance
	@GetMapping(value = "/duplica/{destino}/{numeroCotacaoProposta}/{versao}")
	public ResponseEntity<?> duplica(
			@PathVariable BigInteger destino,
			@PathVariable BigInteger numeroCotacaoProposta,
			@PathVariable Integer versao) {
		try {
			List<Validacao> validacoes = duplicarCotacaoService.copiarConteudoParaCotacao(destino, numeroCotacaoProposta, versao);
			if(!validacoes.isEmpty()) {
				return ResponseEntity.badRequest().body(validacoes);
			}
		} catch(Exception e) {
			logger.error("Erro ao duplicar a cotação ", e);
			return ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok("ok");
	}
	
	@LogPerformance
	@GetMapping(value = "/duplica/item/{item}/{quantidade}/{ultimoItem}")
	public ResponseEntity<?> duplicarItem(
			@PathVariable BigInteger item,
			@PathVariable Integer quantidade,
			@PathVariable int ultimoItem) {
		try {
			if(quantidade > 10) {
				quantidade = 10;
			}
			duplicarCotacaoService.duplicarItem(item, quantidade, ultimoItem);
		} catch(Exception e) {
			logger.error("Erro ao duplicar a cotação ", e);
			return ResponseEntity.badRequest().build();
		}

		return ResponseEntity.ok("ok");
	}
	
	private boolean validacaoCalculoLmi(CotacaoView cotacao) {
		boolean produtoLmi = Arrays.asList(1850,9651,1852).contains(cotacao.getCodigoProduto());
		if(produtoLmi && cotacao.getListItem().size() > 1) {
			return true;
		}

		if(!produtoLmi) {
			return true;
		}

		return false;
	}

	static class ApoliceItemPlataformaResponse implements Serializable {

		private static final long serialVersionUID = 6230188134993857477L;

		private long codigo;
		private String descricao;
		private String idMsg;

		public long getCodigo() {
			return codigo;
		}

		public void setCodigo(long codigo) {
			this.codigo = codigo;
		}

		public String getDescricao() {
			return descricao;
		}

		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}

		public String getIdMsg() {
			return idMsg;
		}

		public void setIdMsg(String idMsg) {
			this.idMsg = idMsg;
		}
	}
}
