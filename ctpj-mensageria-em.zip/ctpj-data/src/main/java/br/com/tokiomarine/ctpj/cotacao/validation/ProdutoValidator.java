package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.List;
import java.util.Map;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;

public interface ProdutoValidator {

	List<ValidacaoLote> valida(Cotacao cotacao, Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto);

}
