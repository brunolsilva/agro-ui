package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.tokiomarine.cliente.util.DateUtil;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CorretagemView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.repository.CorretagemRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CorretorFranqueadorView;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Transactional(rollbackFor = {ServiceException.class})
@Service
public class CorretagemService {

	private static final Logger logger = LogManager.getLogger(CosseguroService.class);

	@Autowired
	private CorretagemRepository corretagemRepository;

	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private RestTemplate restTemplate = new RestTemplate();
	public List<CorretagemCotacao> findCorretagensByCotacao(BigInteger cotacao) throws ServiceException {
		try {
			return corretagemRepository.findCorretagensByCotacao(cotacao);
		} catch (RepositoryException e) {
			logger.error("Erro ao buscar listagem de corretagem ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	public void salvar(List<CorretagemView> corretagens) throws ServiceException {
		try {
			CotacaoView cotacaoVersao = cotacaoService.findCotacaoCabecalho(corretagens.get(0).getSequencialCotacaoProposta());
			List<CorretagemCotacao> corretagensSalvar = new ArrayList<>();

			/**
			 * Remove os corretagens e insere novamente
			 */
			corretagemRepository.deleteCorretagem(corretagens.get(0).getSequencialCotacaoProposta());
			
			if(corretagens.size() > 1) {
				for(CorretagemView corretagem: corretagens) {
					CorretagemCotacao corretagemCotacao = new CorretagemCotacao();
					CotacaoViewMapper.INSTANCE.toCorretagemCotacao(corretagem, corretagemCotacao);
					corretagemCotacao.setNumeroCotacaoProposta(cotacaoVersao.getNumeroCotacaoProposta());
					corretagemCotacao.setVersaoCotacaoProposta(cotacaoVersao.getVersaoCotacaoProposta());
					corretagemCotacao.setIdCorretorLider(corretagem.getCodigoCorretorAcsel().equals(cotacaoVersao.getCodigoCorretorACSEL()) ? SimNaoEnum.SIM : SimNaoEnum.NAO);
					Cotacao cotacao = new Cotacao();
					cotacao.setSequencialCotacaoProposta(cotacaoVersao.getSequencialCotacaoProposta());
					corretagemCotacao.setCotacao(cotacao);
					User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
					corretagemCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
					corretagemCotacao.setDataAtualizacao(new Date());
					corretagemCotacao.setUsuarioAtualizacao(user.getCdUsuro() != null ? Long.valueOf(user.getCdUsuro()) : null);
					corretagensSalvar.add(corretagemCotacao);
				}

				corretagemRepository.salvar(corretagensSalvar);
			}

		} catch (RepositoryException e) {
			logger.error("Erro ao salvar corretagens ", e);
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Erro ao salvar corretagens ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
	
	public BigInteger getSequencialItemSinistroCobertura() {
		return corretagemRepository.getSequencialItemSinistroCobertura();
	}

	public void salvarCorretagemDaCotacao(BigInteger sequencialCotacaoProposta, List<CorretagemCotacao> corretagens) throws ServiceException {
		try {
			corretagemRepository.deleteCorretagem(sequencialCotacaoProposta);
			if(!corretagens.isEmpty()) {
				corretagemRepository.salvar(corretagens);
			}
		} catch (RepositoryException e) {
			logger.error("Erro ao salvar corretagens ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
	
	public CorretorFranqueadorView getCorretorFranqueador(Integer codModProduto, Cotacao cotacao, Date dataReferencia) {
		CorretorFranqueadorView response = null;
		
		try {
			String url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroCorretorFranqueado());
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
					.queryParam("codModProduto", codModProduto)
					.queryParam("codCorretor", StringUtils.leftPad(cotacao.getCodigoCorretorACSEL(),6,"0"))
					.queryParam("dataReferencia", URLDecoder.decode(DateUtil.formataSemHora(dataReferencia), "UTF-8"));
			
			response = restTemplate.getForObject(builder.toUriString(), CorretorFranqueadorView.class);
			
			if (response != null) {
				if (houveAlteracaoDadosCorretagemCotacao(cotacao, response)) {
					corretagemRepository.deleteCorretagem(cotacao.getSequencialCotacaoProposta());
					List<CorretagemCotacao> listCorretagemCotacao = geraListaCorretagemCotacao(cotacao, response);
					corretagemRepository.salvar(listCorretagemCotacao);
				}
			}
			
			return response;
		} catch (HttpClientErrorException e) {
			if (e.getStatusCode() == HttpStatus.UNPROCESSABLE_ENTITY) {
				return null;
			} else {
				throw new RuntimeException("Erro ao buscar corretor franqueador");
			}

		} catch (Exception e) {
			logger.error("Erro ao buscar corretor franqueador", e);
			return null;
		}
		
	}

	/**
	 * Retorna TRUE se os dados cadastrados de CorretagemCotacao na Cotacao forem diferentes ao CorretorFranqueadorView passado, senao retorna FALSE
	 * @param cotacao
	 * @param corretorFranqueadorView
	 * @return
	 * @throws ServiceException 
	 */
	private boolean houveAlteracaoDadosCorretagemCotacao(Cotacao cotacao, CorretorFranqueadorView corretorFranqueadorView) throws ServiceException {
		List<CorretagemCotacao> listCorretagemCotacao = findCorretagensByCotacao(cotacao.getSequencialCotacaoProposta());
		
		if (listCorretagemCotacao != null && !listCorretagemCotacao.isEmpty()) {
			CorretorFranqueadorView old = new CorretorFranqueadorView();
			// itera pela lista e adiciona os valores antigos
			for (CorretagemCotacao corretagemCotacao : listCorretagemCotacao) {
				if (corretagemCotacao.getIdCorretorLider() == SimNaoEnum.NAO) {
					old.setCodCorretorFranqueador(corretagemCotacao.getCodigoCorretorAcsel());
					old.setNomCorretorFranqueador(corretagemCotacao.getNomeCorretorAcsel());
					old.setPercFranqueador(corretagemCotacao.getPercentualCorretagem());
				} else {
					old.setPercFranqueado(corretagemCotacao.getPercentualCorretagem());
				}
			}
			
			if (old.equals(corretorFranqueadorView)) {
				return Boolean.FALSE;
			}
		} 
		return Boolean.TRUE;
	}

	private List<CorretagemCotacao> geraListaCorretagemCotacao(Cotacao cotacao, CorretorFranqueadorView corretorFranqueadorView) {
		List<CorretagemCotacao> listCorretagemCotacao = new ArrayList<>();
		CorretagemCotacao corretor = new CorretagemCotacao();
		corretor.setCotacao(cotacao);
		corretor.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		corretor.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		corretor.setCodigoCorretorAcsel(cotacao.getCodigoCorretorACSEL());
		corretor.setNomeCorretorAcsel(cotacao.getNomeCorretor());
		corretor.setPercentualCorretagem(corretorFranqueadorView.getPercFranqueado());
		corretor.setIdCorretorLider(SimNaoEnum.SIM);
		corretor.setDataAtualizacao(new Date());
		corretor.setCodigoGrupo(SecurityUtils.getCurrentUser().getGrupoUsuario().getId());
		corretor.setUsuarioAtualizacao(SecurityUtils.getCurrentUser().getCdUsuro().longValue());
		listCorretagemCotacao.add(corretor);
		
		CorretagemCotacao franqueador = new CorretagemCotacao();
		franqueador.setCotacao(cotacao);
		franqueador.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		franqueador.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		franqueador.setCodigoCorretorAcsel(corretorFranqueadorView.getCodCorretorFranqueador());
		franqueador.setNomeCorretorAcsel(corretorFranqueadorView.getNomCorretorFranqueador());
		franqueador.setPercentualCorretagem(corretorFranqueadorView.getPercFranqueador());
		franqueador.setIdCorretorLider(SimNaoEnum.NAO);
		franqueador.setUsuarioAtualizacao(SecurityUtils.getCurrentUser().getCdUsuro().longValue());
		franqueador.setCodigoGrupo(SecurityUtils.getCurrentUser().getGrupoUsuario().getId());
		franqueador.setDataAtualizacao(new Date());
		listCorretagemCotacao.add(franqueador);
		return listCorretagemCotacao;
	}


}
