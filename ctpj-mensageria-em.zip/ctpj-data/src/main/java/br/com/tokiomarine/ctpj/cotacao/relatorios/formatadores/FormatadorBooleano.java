package br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores;

/**
 * Formatador para valores booleanos presentes nos Relatórios
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class FormatadorBooleano {
	
	private String trueAsString;
	private String falseAsString;
	
	/**
	 * Construtor default. O valor utilizado para true é SIM e o valor utilizado para false é NÃO
	 */
	public FormatadorBooleano(){
		this("SIM", "NÃO");
	}
	
	/**
	 * Construtor
	 * 
	 * @param trueAsString Valor utilizado para os casos onde o valor do boolean é true
	 * @param falseAsString Valor utilizado para os casos onde o valor do boolean é false
	 */
	public FormatadorBooleano(String trueAsString, String falseAsString){
		this.trueAsString = trueAsString;
		this.falseAsString = falseAsString;
	}
	
	/**
	 * Formata o valor como String
	 * 
	 * @param value Valor a ser formatado
	 * @return O valor formatado como String. Nos casos do valor ser igual a null, será utilizado o mesmo valor definido para false
	 */
	public String asString(Boolean value){
		return asString(value, falseAsString);
	}
	
	/**
	 * Formata o valor como String
	 * 
	 * @param value Valor a ser formatado
	 * @param replace Utilizado para os casos onde o valor é null
	 * @return O valor formatado como String. Nos casos do valor ser igual a null, será utilizado o valor definido no parâmetro replace
	 */
	public String asString(Boolean value, String replace){
		if(value == null)
			return replace;
		
		return value ? trueAsString : falseAsString;
	}

}
