package br.com.tokiomarine.ctpj.endosso.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCoberturaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCoberturaEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Service
public class EndossoItemCoberturaService {
	
	private static Logger logger = LogManager.getLogger(EndossoItemCoberturaService.class.getName());
		
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	@Autowired
	private EndossoItemCoberturaClausulaService endossoItemCoberturaClausulaService;
	
	@Autowired
	private EndossoItemCoberturaEquipamentoFranquiaService endossoItemCoberturaEquipamentoFranquiaService;
	
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	private final String MENSAGEM_DA_COBERTURA = " da cobertura ";
	/**
	 * prc_ctp0130
	 */
	public void validarItensCoberturas(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		boolean itemEndossoPossuiCoberturas = itemEndosso.getListItemCobertura() != null && !itemEndosso.getListItemCobertura().isEmpty();
		boolean itemApolicePossuiCoberturas = itemApolice.getListItemCoberturaApolice() != null && !itemApolice.getListItemCoberturaApolice().isEmpty();
		
		//1 - percorre as coberturas do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiCoberturas){			
			for(ItemCobertura itemEndossoCobertura : itemEndosso.getListItemCobertura()){
				boolean coberturaExiste = false;
				if(itemApolicePossuiCoberturas){
					for(ItemCoberturaApolice itemApolCobertura : itemApolice.getListItemCoberturaApolice()){
						if(AssertUtils.compareNull(itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura.getCodigoCobertura())){
							
							if(AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(),TipoEndossoEnum.REDUCAO_IS_SINISTRO.getId())){
								if(BigDecimalUtil.safeMenor(itemEndossoCobertura.getValorImportanciaSegurada(), itemApolCobertura.getValorIs())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorIs(), itemEndossoCobertura.getValorImportanciaSegurada(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- IS: ", getTipoReducaoIsPorSinistroTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), endosso, itemEndosso, alteracoesEndossoList, user);
								}
							} else if(AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(),TipoEndossoEnum.REINTEGRA_IS_SINISTRO.getId())){
								if(BigDecimalUtil.safeMenor(itemApolCobertura.getValorIs(), itemEndossoCobertura.getValorImportanciaSegurada())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorIs(), 
											itemEndossoCobertura.getValorImportanciaSegurada(), 
											itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, 
											"-IS: ", 
											getTipoReintegracaoIsPorTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), 
											endosso, 
											itemEndosso, 
											alteracoesEndossoList, 
											user);
								}
							} else {
								Optional<ItemCoberturaApolice> optItemCoberturaApolice = itemApolice
										.getListItemCoberturaApolice().stream().filter(c -> c.getCodigoCobertura()
												.equals(itemEndossoCobertura.getCodigoCobertura()))
										.findFirst();
								if (optItemCoberturaApolice.isPresent()) {
									ItemCoberturaApolice itemCoberturaApolice = optItemCoberturaApolice.get();
									if ((itemCoberturaApolice.getIdExclusaoEndosso() == null
											|| itemCoberturaApolice.getIdExclusaoEndosso().equals(SimNaoEnum.NAO))
											&& itemEndossoCobertura.getIdExclusaEndosso() == SimNaoEnum.SIM) {
										this.logarExclusaoCobertura(itemEndossoCobertura.getValorPremio(),
												itemApolCobertura.getCodigoCobertura(), itemEndossoCobertura,
												"Cobertura ",
												getTipoExclusaoPorTipoCobertura(
														itemEndossoCobertura.getIdTipoCobertura()),
												endosso, itemEndosso, alteracoesEndossoList, user);
									}
								}

								if(itemEndossoCobertura.getValorImportanciaSegurada() != null) {
									if(BigDecimalUtil.safeMenor(itemApolCobertura.getValorIs(),itemEndossoCobertura.getValorImportanciaSegurada())){
										this.logarAlteracaoCobertura(itemApolCobertura.getValorIs(), itemEndossoCobertura.getValorImportanciaSegurada(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- IS: ", getTipoAumentoIsPorTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), endosso, itemEndosso, alteracoesEndossoList, user);	
									}
	
									if(BigDecimalUtil.safeMaior(itemApolCobertura.getValorIs(),itemEndossoCobertura.getValorImportanciaSegurada())){
										this.logarAlteracaoCobertura(itemApolCobertura.getValorIs(), itemEndossoCobertura.getValorImportanciaSegurada(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- IS: ", getTipoReducaoIsPorTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), endosso, itemEndosso, alteracoesEndossoList, user);	
									}
								}

								//valida o valor risco bem
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getValorRiscoBem(), itemEndossoCobertura.getValorRiscoBem())){
									//inseri esta condição, pois na proc só loga para tipos diferentes de básica, inclusive não há "tipo mensagem" de alteração de vr para a basica
									if(!isBasica(itemEndossoCobertura.getIdTipoCobertura())){
										this.logarAlteracaoCobertura(itemApolCobertura.getValorRiscoBem(), itemEndossoCobertura.getValorRiscoBem(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- VR: ", getTipoAlteracaoVrPorTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), endosso, itemEndosso, alteracoesEndossoList, user);	
									}
									
								}
								
								//valida o periodo indenitario
								if(!AssertUtils.compareNull(itemApolCobertura.getCodigoPeriodoIndenitario(), itemEndossoCobertura.getCodigoPeriodoIndenitario())){
									this.logarAlteracaoCobertura(itemApolCobertura.getCodigoPeriodoIndenitario(), itemEndossoCobertura.getCodigoPeriodoIndenitario(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Período indenitário:", TipoMensagemEndossoEnum.ALT_PERIODO_INDENITARIO, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida o valor sublimite
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getValorSubLimite(),itemEndossoCobertura.getValorSublimite()) && !BigDecimalUtil.compareNull(itemEndossoCobertura.getValorSublimiteOriginal(), itemEndossoCobertura.getValorSublimite())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorSubLimite(), itemEndossoCobertura.getValorSublimite(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Sub limite:", TipoMensagemEndossoEnum.ALT_SUBLIMITE, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida numero vagas garagem
								if(!AssertUtils.compareNull(itemApolCobertura.getNumeroVagas(),itemEndossoCobertura.getNumeroVagasGaragem())){

									this.logarAlteracaoCobertura(itemApolCobertura.getNumeroVagas(), itemEndossoCobertura.getNumeroVagasGaragem(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Nº vagas garagem: ", TipoMensagemEndossoEnum.ALT_VAGAS_GARAGEM, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida complemento cobertura
								if(!AssertUtils.compareNull(itemApolCobertura.getDescricaoComplementoCobertura(),itemEndossoCobertura.getDescricaoComplementoCobertura())) {
									this.logarAlteracaoCobertura(itemApolCobertura.getDescricaoComplementoCobertura(), itemEndossoCobertura.getDescricaoComplementoCobertura(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Complemento: ", getTipoAlteracaoComplementoPorTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida id forma franquia
								if(itemApolCobertura.getIdFormaFranquia() != itemEndossoCobertura.getIdFormaFranquia()){
									this.logarAlteracaoCobertura(itemApolCobertura.getIdFormaFranquia().getId(), itemEndossoCobertura.getIdFormaFranquia().getId(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Forma franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}			
								
								//valida nr horas franquia
								if(!AssertUtils.compareNull(itemApolCobertura.getNumeroHorasFranquia(),itemEndossoCobertura.getNumeroHorasFranquia())) {
									this.logarAlteracaoCobertura(itemApolCobertura.getNumeroHorasFranquia(), itemEndossoCobertura.getNumeroHorasFranquia(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Nº horas: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}			

								//valida nr dias franquia
								if(!AssertUtils.compareNull(itemApolCobertura.getNumeroDiasFranquia(), itemEndossoCobertura.getNumeroDiasFranquia())){
									this.logarAlteracaoCobertura(itemApolCobertura.getNumeroDiasFranquia(), itemEndossoCobertura.getNumeroDiasFranquia(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Nº dias: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}	
								
								//valida taxa franquia
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getTaxaFranquia(),itemEndossoCobertura.getTaxaFranquia())){
									this.logarAlteracaoCobertura(itemApolCobertura.getTaxaFranquia(), itemEndossoCobertura.getTaxaFranquia(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Tx franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida valor franquia
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getValorFranquia(),itemEndossoCobertura.getValorFranquia())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorFranquia(), itemEndossoCobertura.getValorFranquia(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Valor franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida valor franquia minimo
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getValorFranquiaMinima(),itemEndossoCobertura.getValorFranquiaMinima())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorFranquiaMinima(), itemEndossoCobertura.getValorFranquiaMinima(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Valor mínimo franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}								
								
								//valida valor franquia maximo
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getValorFranquiaMaxima(),itemEndossoCobertura.getValorFranquiaMaxima())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorFranquiaMaxima(), itemEndossoCobertura.getValorFranquiaMaxima(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Valor máximo franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida taxa is
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getTaxaImportanciaSegurada(),itemEndossoCobertura.getTaxaImportanciaSegurada())){
									this.logarAlteracaoCobertura(itemApolCobertura.getTaxaImportanciaSegurada(), itemEndossoCobertura.getTaxaImportanciaSegurada(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Taxa IS: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida taxa is minimo
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getTaxaImportanciaSeguradaMinima(),itemEndossoCobertura.getTaxaImportanciaSeguradaMinima())){
									this.logarAlteracaoCobertura(itemApolCobertura.getTaxaImportanciaSeguradaMinima(), itemEndossoCobertura.getTaxaImportanciaSeguradaMinima(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Taxa mínima IS: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida taxa is maximo
								if(!BigDecimalUtil.compareNull(itemApolCobertura.getTaxaImportanciaSeguradaMaxima(),itemEndossoCobertura.getTaxaImportanciaSeguradaMaxima())){
									this.logarAlteracaoCobertura(itemApolCobertura.getTaxaImportanciaSeguradaMaxima(), itemEndossoCobertura.getTaxaImportanciaSeguradaMaxima(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- Taxa máxima IS: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, alteracoesEndossoList, user);
								}
								
								//valida texto franquia
								// obs: Apolice descricaoTextoFranquia = itemCobertura descricaoFranquia
								validacaoParametrosEndossoService.compararParametrosCoberturaSemDePara(itemApolCobertura.getDescricaoTextoFranquia(), itemEndossoCobertura.getDescricaoFranquia(),"- Descrição franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);
								
								//valida texto franquia
								// obs: Apolice complemento = itemCobertura descricaoTextoFranquia
								validacaoParametrosEndossoService.compararParametrosCoberturaSemDePara(itemApolCobertura.getDescricaoComplementoFranquia(), itemEndossoCobertura.getDescricaoTextoFranquia(),"- Complemento descrição franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);
							}
							
							logger.info("Validando cobertura clausula do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" ,item endosso de numero "+itemEndosso.getNumeroItem()+" e cobertura tipo "+itemEndossoCobertura.getIdTipoCobertura()+" e código "+itemEndossoCobertura.getCodigoCobertura());
							endossoItemCoberturaClausulaService.validarItemCoberturaClausula(endosso, itemEndosso, itemEndossoCobertura, itemApolCobertura, alteracoesEndossoList, user);
							logger.info("Validando equipamento franquia do sequencial Cotacao :"+endosso.getSequencialCotacaoProposta()+" ,item endosso de numero "+itemEndosso.getNumeroItem()+" e cobertura tipo "+itemEndossoCobertura.getIdTipoCobertura()+" e código "+itemEndossoCobertura.getCodigoCobertura());
							endossoItemCoberturaEquipamentoFranquiaService.validarEquipamentoFranquia(endosso, itemEndosso, itemEndossoCobertura, itemApolCobertura, alteracoesEndossoList, user);
							coberturaExiste = true;
							break;
						}						
					}
				}
				
				//se a cobertura não existir
				if(!coberturaExiste){ 
					logarInclusaoCobertura(itemEndossoCobertura,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
	}//
	
	public void validarItensCoberturasReintegracao(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		boolean itemEndossoPossuiCoberturas = itemEndosso.getListItemCobertura() != null && !itemEndosso.getListItemCobertura().isEmpty();
		boolean itemApolicePossuiCoberturas = itemApolice.getListItemCoberturaApolice() != null && !itemApolice.getListItemCoberturaApolice().isEmpty();
		
		//1 - percorre as coberturas do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiCoberturas){			
			for(ItemCobertura itemEndossoCobertura : itemEndosso.getListItemCobertura()){
				boolean coberturaExiste = false;
				if(itemApolicePossuiCoberturas){
					for(ItemCoberturaApolice itemApolCobertura : itemApolice.getListItemCoberturaApolice()){
						if(AssertUtils.compareNull(itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura.getCodigoCobertura())){
							
							if(AssertUtils.compareNull(itemEndosso.getIdTipoEndosso(),TipoEndossoEnum.REINTEGRA_IS_SINISTRO.getId())){
								if(BigDecimalUtil.safeMenor(itemApolCobertura.getValorIs(), itemEndossoCobertura.getValorImportanciaSegurada())){
									this.logarAlteracaoCobertura(itemApolCobertura.getValorIs(), 
											itemEndossoCobertura.getValorImportanciaSegurada(), 
											itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, 
											"- IS: ", 
											getTipoReintegracaoIsPorTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), 
											endosso, 
											itemEndosso, 
											alteracoesEndossoList, 
											user);
								}
							}
							coberturaExiste = true;
							break;
						}						
					}
				}			
			}
		}		
		//1 - fim
		
	}//
	
	public void validarItensCoberturasReducaoIsPorSinistro(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		boolean itemEndossoPossuiCoberturas = itemEndosso.getListItemCobertura() != null && !itemEndosso.getListItemCobertura().isEmpty();
		boolean itemApolicePossuiCoberturas = itemApolice.getListItemCoberturaApolice() != null && !itemApolice.getListItemCoberturaApolice().isEmpty();
		
		//1 - percorre as coberturas do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiCoberturas){			
			for(ItemCobertura itemEndossoCobertura : itemEndosso.getListItemCobertura()){
				boolean coberturaExiste = false;
				if(itemApolicePossuiCoberturas){
					for(ItemCoberturaApolice itemApolCobertura : itemApolice.getListItemCoberturaApolice()){
						if(AssertUtils.compareNull(itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura.getCodigoCobertura())){
							
							if(BigDecimalUtil.safeMenor(itemEndossoCobertura.getValorImportanciaSegurada(),itemApolCobertura.getValorIs())){
								this.logarAlteracaoCobertura(itemApolCobertura.getValorIs(), itemEndossoCobertura.getValorImportanciaSegurada(), itemApolCobertura.getCodigoCobertura(),itemEndossoCobertura, "- IS: ", getTipoReducaoIsPorSinistroTipoCobertura(itemEndossoCobertura.getIdTipoCobertura()), endosso, itemEndosso, alteracoesEndossoList, user);
							}
							coberturaExiste = true;
							break;
						}						
					}
				}			
			}
		}		
		//1 - fim
		
	}//
	
	private TipoMensagemEndossoEnum getTipoAlteracaoComplementoPorTipoCobertura(Integer tipoCobertura){
		if(isBasica(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_COMPL_BASICA;
		} else if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_COMPL_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_COMPL_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_COMPL_EESPECIAL;
		}
		
		return null;
	}
	
	private TipoMensagemEndossoEnum getTipoExclusaoPorTipoCobertura(Integer tipoCobertura){
		if(isBasica(tipoCobertura)){
			return TipoMensagemEndossoEnum.EXCLUSAO_BASICA;
		} else if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.EXCLUSAO_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.EXCLUSAO_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.EXCLUSAO_EESPECIAL;
		}
		
		return null;
	}
	
	private TipoMensagemEndossoEnum getTipoReducaoIsPorSinistroTipoCobertura(Integer tipoCobertura){
		if(isBasica(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_SIN_BASICA;
		} else if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_SIN_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_SIN_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_SIN_EESPECIAL;
		}
		
		return null;
	}
	
	private TipoMensagemEndossoEnum getTipoReducaoIsPorTipoCobertura(Integer tipoCobertura){
		if(isBasica(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_IS_BASICA;
		} else if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_IS_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_IS_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.REDUCAO_IS_EESPECIAL;
		}
		
		return null;
	}

	private TipoMensagemEndossoEnum getTipoReintegracaoIsPorTipoCobertura(Integer tipoCobertura){
		if(isBasica(tipoCobertura)){
			return TipoMensagemEndossoEnum.REINTEGRACAO_IS_BASICA;
		} else if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.REINTEGRACAO_IS_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.REINTEGRACAO_IS_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.REINTEGRACAO_IS_EESPECIAL;
		}
		
		return null;
	}	
	
	private TipoMensagemEndossoEnum getTipoAumentoIsPorTipoCobertura(Integer tipoCobertura){
		if(isBasica(tipoCobertura)){
			return TipoMensagemEndossoEnum.AUMENTO_IS_BASICA;
		} else if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.AUMENTO_IS_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.AUMENTO_IS_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.AUMENTO_IS_EESPECIAL;
		}
		
		return null;
	}
	
	private TipoMensagemEndossoEnum getTipoAlteracaoVrPorTipoCobertura(Integer tipoCobertura){
		if(isAdicional(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_VR_ADICIONAL;
		} else if(isEspecial(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_VR_ESPECIAL;
		} else if(isEspecial2(tipoCobertura)){
			return TipoMensagemEndossoEnum.ALT_VR_EESPECIAL;
		}
		
		return null;
	}
	
	
	
	private boolean isBasica(Integer tipoCobertura){
		return tipoCobertura.equals(TipoCoberturaEnum.BASICA.getId());
	}
	
	private boolean isAdicional(Integer tipoCobertura){
		return tipoCobertura.equals(TipoCoberturaEnum.ADICIONAL.getId());
	}
	
	private boolean isEspecial(Integer tipoCobertura){
		return tipoCobertura.equals(TipoCoberturaEnum.ESPECIAL.getId());
	}
	
	private boolean isEspecial2(Integer tipoCobertura){
		return tipoCobertura.equals(TipoCoberturaEnum.ESPECIAL2.getId());
	}
	
	private void logarInclusaoCobertura(ItemCobertura itemEndossoCobertura, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		String descricao = " - ";
		TipoMensagemEndossoEnum tipoMensagem = TipoMensagemEndossoEnum.INC_BASICA_POSITIVA;
		
		if(isBasica(itemEndossoCobertura.getIdTipoCobertura())){
				
			tipoMensagem = TipoMensagemEndossoEnum.INC_BASICA_POSITIVA;
		} else if(isAdicional(itemEndossoCobertura.getIdTipoCobertura())){
			
			tipoMensagem = TipoMensagemEndossoEnum.INC_ADICIONAL_POSITIVA;
		} else if(isEspecial(itemEndossoCobertura.getIdTipoCobertura())){
			
			tipoMensagem = TipoMensagemEndossoEnum.INC_ESPECIAL_POSITIVA;
		} else if(isEspecial2(itemEndossoCobertura.getIdTipoCobertura())){
			
			tipoMensagem = TipoMensagemEndossoEnum.INC_EESPECIAL_POSITIVA;
		}
		
		
		descricao += itemEndossoCobertura.getCodigoCobertura()+" com prêmio "+itemEndossoCobertura.getValorPremio();
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, itemEndossoCobertura, tipoMensagem, descricao, user));
	}

	private void logarAlteracaoCobertura(BigDecimal parametro1, BigDecimal parametro2, Integer codigoCobertura, ItemCobertura itemCobertura, String descricaoCampo, TipoMensagemEndossoEnum tipoMensagem,Cotacao endosso,ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(descricaoCampo);
		descricaoAlteracao.append(parametro1);
		descricaoAlteracao.append(validacaoParametrosEndossoService.MENSAGEM_ALTERADO_PARA);
		descricaoAlteracao.append(parametro2);
		descricaoAlteracao.append(MENSAGEM_DA_COBERTURA);
		descricaoAlteracao.append(codigoCobertura);
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso,itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
	}

	private void logarAlteracaoCobertura(String parametro1, String parametro2, Integer codigoCobertura, ItemCobertura itemCobertura, String descricaoCampo, TipoMensagemEndossoEnum tipoMensagem,Cotacao endosso,ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(descricaoCampo);
		descricaoAlteracao.append(parametro1);
		descricaoAlteracao.append(validacaoParametrosEndossoService.MENSAGEM_ALTERADO_PARA);
		descricaoAlteracao.append(parametro2);
		descricaoAlteracao.append(MENSAGEM_DA_COBERTURA);
		descricaoAlteracao.append(codigoCobertura);
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso,itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
	}
	
	private void logarAlteracaoCobertura(Integer parametro1, Integer parametro2, Integer codigoCobertura, ItemCobertura itemCobertura, String descricaoCampo, TipoMensagemEndossoEnum tipoMensagem,Cotacao endosso,ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(descricaoCampo);
		descricaoAlteracao.append(parametro1);
		descricaoAlteracao.append(validacaoParametrosEndossoService.MENSAGEM_ALTERADO_PARA);
		descricaoAlteracao.append(parametro2);
		descricaoAlteracao.append(MENSAGEM_DA_COBERTURA);
		descricaoAlteracao.append(codigoCobertura);
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso,itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
	}
	
	private void logarExclusaoCobertura(BigDecimal valorPremio, Integer codigoCobertura, ItemCobertura itemCobertura, String descricaoCampo, TipoMensagemEndossoEnum tipoMensagem,Cotacao endosso,ItemCotacao itemEndosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append("Cobertura ");
		descricaoAlteracao.append(codigoCobertura);
		descricaoAlteracao.append(" excluída - restituição de  ");
		descricaoAlteracao.append(valorPremio);
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso,itemEndosso,itemCobertura, tipoMensagem, descricaoAlteracao.toString(), user));
	}
}
