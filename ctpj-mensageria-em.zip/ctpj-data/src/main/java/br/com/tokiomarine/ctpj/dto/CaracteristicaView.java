package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;

public class CaracteristicaView implements Serializable {

	private static final long serialVersionUID = 5203488311676411063L;

	private Integer produto;
	private Integer caracteristica;
	private String descricaoLabelTela;
	private boolean preenchimentoObrigatorio;
	private String valorDefault;
	private boolean displayTela;

	public CaracteristicaView() { }

	public Integer getProduto() {
		return produto;
	}

	public void setProduto(Integer produto) {
		this.produto = produto;
	}

	public Integer getCaracteristica() {
		return caracteristica;
	}

	public void setCaracteristica(Integer caracteristica) {
		this.caracteristica = caracteristica;
	}

	public String getDescricaoLabelTela() {
		return descricaoLabelTela;
	}

	public void setDescricaoLabelTela(String descricaoLabelTela) {
		this.descricaoLabelTela = descricaoLabelTela;
	}

	public String getValorDefault() {
		return valorDefault;
	}

	public void setValorDefault(String valorDefault) {
		this.valorDefault = valorDefault;
	}

	public boolean isDisplayTela() {
		return displayTela;
	}

	public void setDisplayTela(boolean displayTela) {
		this.displayTela = displayTela;
	}


	public boolean isPreenchimentoObrigatorio() {
		return preenchimentoObrigatorio;
	}


	public void setPreenchimentoObrigatorio(boolean preenchimentoObrigatorio) {
		this.preenchimentoObrigatorio = preenchimentoObrigatorio;
	}
}