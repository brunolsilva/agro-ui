package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.blaze.dto.CotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ErroBlaze;
import br.com.tokiomarine.ctpj.blaze.mapper.BlazeParaCotacaoMapper;
import br.com.tokiomarine.ctpj.blaze.mapper.CotacaoParaBlazeMapper;
import br.com.tokiomarine.ctpj.cotacao.dto.BloqueioAlcadaView;
import br.com.tokiomarine.ctpj.cotacao.repository.BloqueioAlcadaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.mapper.BloqueioAlcadaMapper;

@Service
@Transactional(rollbackFor = {Exception.class,ServiceException.class})
public class AceitacaoCotacaoService {

	@Autowired
	protected RestTemplate restTemplate;

	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private BloqueioAlcadaRepository bloqueioAlcadaRepository;
	

	private static Logger logger = LogManager.getLogger(AceitacaoCotacaoService.class);

	public ResultadoREST<List<String>> gerarAceitacaoRestricaoCotacao(BigInteger sequencialCotacaoProposta,User user) {
		ResultadoREST<List<String>> resultado = new ResultadoREST<>();
		try {
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroBlazeAceitacao();
			if (urlEnum == null) {
				throw new ServiceException("Erro ao buscar URL referente ao Blaze de aceitação.");
			}

			String url = parametroGeralService.getUrlByNome(urlEnum);
			if (StringUtils.isEmpty(url)) {
				throw new ServiceException("URL de acesso ao blaze de aceitação nula ou vazia.");
			}

			Cotacao cotacao = cotacaoRepository.findCompleta(sequencialCotacaoProposta);

			CotacaoParaBlazeMapper cotacaoToBlazeMapper = new CotacaoParaBlazeMapper();
			BlazeParaCotacaoMapper blazeToCotacaoMapper = new BlazeParaCotacaoMapper();

			CotacaoBlaze cotacaoBlaze = cotacaoToBlazeMapper.createCotacaoBlaze(cotacao,null,new ArrayList<>(),user);

			ResponseEntity<CotacaoBlaze> response = 
					restTemplate.postForEntity(url,cotacaoBlaze,CotacaoBlaze.class);


			CotacaoBlaze cotacaoBlazeResponse = response.getBody();

			if(user.getGrupoUsuario() !=  GrupoUsuarioEnum.CORRETOR) {
				resultado.setRetornoObj(cotacaoBlaze.getListErro()
						.stream()
						.map(ErroBlaze::getDescricaoErro)
						.collect(Collectors.toList()));
			}

			if(cotacaoBlaze.getListErro() != null && !cotacaoBlaze.getListErro().isEmpty()) {
				resultado.setMensagem("Erro na aceitação cotação/proposta! Entre em Contato com a Seguradora informando este problema!");
				resultado.setSuccess(false);
				return resultado;
			}

			List<BloqueioAlcadaView> listBloqueioAlcadaAutorizado = new ArrayList<>();
			for(BloqueioAlcada bloqueio: cotacao.getListBloqueioAlcada()) {
				listBloqueioAlcadaAutorizado.add(new BloqueioAlcadaView(
						bloqueio.getDescricaoRestricao(),
						bloqueio.getCodigoNivelAutorizacao(),
						bloqueio.getIdAutorizacao(),
						bloqueio.getDataAutorizacao(),
						bloqueio.getCodigoFuncionarioAutorizacao()));
			}

			bloqueioAlcadaRepository.delete(cotacao.getSequencialCotacaoProposta());
			blazeToCotacaoMapper.convertBlazeToCotacaoAceitacao(cotacao,cotacaoBlazeResponse,listBloqueioAlcadaAutorizado,user);
			cotacaoRepository.update(cotacao);

			resultado.setMensagem("Sucesso");
			resultado.setSuccess(true);

		} catch (RestClientException e) {
			logger.error("Erro ao fazer a conexão com o Blaze",e);
			resultado.setThrowable(e);
			resultado.setMensagem("Erro na aceitação cotação/proposta!");
			resultado.setSuccess(false);
		} catch (Exception e) {
			logger.error("Erro na aceitação cotação/proposta ",e);
			resultado.setThrowable(e);
			resultado.setMensagem("Erro na aceitação cotação/proposta!");
			resultado.setSuccess(false);
		}
		logger.error("Fim Aceitação");
		return resultado;
	}
	
	
	public List<BloqueioAlcadaView> listaBloqueioAlcadaPorCotacao(BigInteger sequencialCotacaoProposta) throws ServiceException {
		List<BloqueioAlcada> bloqueios = bloqueioAlcadaRepository.list(sequencialCotacaoProposta);
		return BloqueioAlcadaMapper.INSTANCE.toView(bloqueios);
	}


	public void atualizar(List<BloqueioAlcadaView> aprovacoes, User user) {
		bloqueioAlcadaRepository.atualiza(aprovacoes, user);
	}

}
