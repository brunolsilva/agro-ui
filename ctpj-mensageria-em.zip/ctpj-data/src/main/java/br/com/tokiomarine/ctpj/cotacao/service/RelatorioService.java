package br.com.tokiomarine.ctpj.cotacao.service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.enums.StatusEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.util.DateUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class RelatorioService {

	private static Logger logger = LogManager.getLogger(RelatorioService.class);

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private CotacaoLogService cotacaoLogService;

	public byte[] exportXLS(BigInteger numeroCotacaoProposta,ServletContext context) throws ServiceException {
		try {

			Cotacao cotacao = cotacaoService.findByNumeroCotacaoProposta(numeroCotacaoProposta);

			List<CotacaoLog> logs = cotacaoLogService.getCotacoesLogBySequencialCotacaoPropostaErro(cotacao.getSequencialCotacaoProposta());

			return this.criarPlanilha(context,cotacao,logs);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar informações para gerar XLS de inconsistências: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro ao exportXLS: ", e);
			throw new ServiceException(e.getMessage(),e.getCause());
		}
	}

	private byte[] criarPlanilha(ServletContext context,Cotacao cotacao,List<CotacaoLog> logs) throws Exception {

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

		logger.info("criarPlanilha.....");
		SXSSFWorkbook workbook = new SXSSFWorkbook();
		Sheet sheet = workbook.createSheet("Inconsistência Cotação");
		Row row = sheet.createRow(5);

		this.montaCabecalho(workbook,sheet,context,cotacao,logs);
		this.montaTabelaEstatica(workbook,sheet,row);
		this.montaTabelaDinamica(workbook,sheet,logs);

		workbook.write(byteArrayOutputStream);

		logger.info("montagem do relatorio finalizado...");

		return byteArrayOutputStream.toByteArray();

	}

	private void montaCabecalho(SXSSFWorkbook workbook,Sheet sheet,ServletContext context,Cotacao cotacao,List<CotacaoLog> logs) throws Exception {

		logger.info("montaCabecalho.....");

		CellStyle estilo = workbook.createCellStyle();
		org.apache.poi.ss.usermodel.Font fonte = workbook.createFont();
		fonte.setFontHeightInPoints((short) 18);
		fonte.setFontName("Arial");
		fonte.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		estilo.setFont(fonte);
		estilo.setAlignment(XSSFCellStyle.ALIGN_CENTER);

		Row row = sheet.createRow(0);
		Cell cell = row.createCell(0);
		cell.setCellValue("Inconsistências da Cotação/Proposta: " + cotacao.getNumeroCotacaoProposta() + " Versão: " + cotacao.getVersaoCotacaoProposta());
		cell.setCellStyle(estilo);
		sheet.addMergedRegion(new CellRangeAddress(0,0,0,5));

		row = sheet.createRow(1);
		cell = row.createCell(0);
		cell.setCellValue("Data do Relatório: " + DateUtil.formataCompleta(Calendar.getInstance().getTime()));
		cell.setCellStyle(createCellStyle(workbook,false,false,HSSFColor.GREY_25_PERCENT.index));
		sheet.addMergedRegion(new CellRangeAddress(1,1,0,5));

		InputStream myBannerImage = new FileInputStream(context.getRealPath("resources") + "/imagens/logo.BMP");
		byte[] bytes = IOUtils.toByteArray(myBannerImage);
		int myPictureId = workbook.addPicture(bytes,Workbook.PICTURE_TYPE_JPEG);
		myBannerImage.close();
		Drawing drawing = sheet.createDrawingPatriarch();

		XSSFClientAnchor myAnchor = new XSSFClientAnchor();
		myAnchor.setCol1(8);
		myAnchor.setRow1(0);

		Picture myPicture = drawing.createPicture(myAnchor,myPictureId);
		myPicture.resize();
	}
	
	
	private void montaTabelaEstatica(SXSSFWorkbook workbook,Sheet sheet,Row row) throws Exception {
		int i = 0;
		
		createCell(workbook,sheet,row,i++, "Sequencial");
		createCell(workbook,sheet,row,i++, "Pedido	");
		createCell(workbook,sheet,row,i++, "Versão");
		createCell(workbook,sheet,row,i++, "Sequencial Item");
		createCell(workbook,sheet,row,i++, "Item");
		createCell(workbook,sheet,row,i++, "Cobertura");
		createCell(workbook,sheet,row,i++, "Observação");
		createCell(workbook,sheet,row,i++, "Status");
	}
	
	private void montaTabelaDinamica(SXSSFWorkbook workbook,Sheet sheet, List<CotacaoLog> logs) throws Exception {
		int i = 0;
		for (i = 0; i < logs.size() ; i++) {
			CotacaoLog log = logs.get(i);
			int column = 0;
			tabelaInconsistenciaCotacao(sheet,i,log,column);
		}
	}
	
	private void tabelaInconsistenciaCotacao(Sheet sheet,int i,CotacaoLog log,int column) {
		Row row;
		Cell cell;
		row = sheet.createRow(6 + i);

		cell = row.createCell(column);
		if(log.getCotacao().getSequencialCotacaoProposta() !=  null) {
			cell.setCellValue(log.getCotacao().getSequencialCotacaoProposta().doubleValue());
		} else {
			cell.setCellValue("");
		}
		
		cell = row.createCell(++column);
		if(log.getCotacao().getNumeroCotacaoProposta() !=  null) {
			cell.setCellValue(log.getCotacao().getNumeroCotacaoProposta().longValue());
		} else {
			cell.setCellValue("");
		}
						
		cell = row.createCell(++column);
		if(log.getCotacao().getVersaoCotacaoProposta() !=  null) {
			cell.setCellValue(log.getCotacao().getVersaoCotacaoProposta());
		} else {
			cell.setCellValue("");
		}
		
		cell = row.createCell(++column);
		if(log.getSequencialItemCotacao()	 !=  null) {
			cell.setCellValue(log.getSequencialItemCotacao().doubleValue());
		} else {
			cell.setCellValue("");
		}
		
		cell = row.createCell(++column);
		if(log.getNumeroItem() !=  null) {
			cell.setCellValue(log.getNumeroItem().doubleValue());
		} else {
			cell.setCellValue("");
		}
		
		cell = row.createCell(++column);
		if(log.getCodigoCobertura() !=  null) {
			cell.setCellValue(log.getCodigoCobertura().doubleValue());
		} else {
			cell.setCellValue("");
		}
		
		cell = row.createCell(++column);
		if(log.getObservacao() !=  null) {
			cell.setCellValue(log.getObservacao());
		} else {
			cell.setCellValue("");
		}
		
		cell = row.createCell(++column);
		if(log.getStatusLog() !=  null) {
			
			String status = StatusEnum.getById(log.getStatusLog()).name();
			
			cell.setCellValue(status);
		} else {
			cell.setCellValue("");
		}

		
	}
	
	private void createCell(SXSSFWorkbook workbook,Sheet sheet,Row row,int i, String name) throws Exception {
		short bgColor = HSSFColor.GREY_40_PERCENT.index;
		Cell cell;
		cell = row.createCell(i);
		cell.setCellValue(name);
		cell.setCellStyle(createCellStyle(workbook,true,true,bgColor));
		sheet.autoSizeColumn(cell.getColumnIndex());
	}
	
	private CellStyle createCellStyle(SXSSFWorkbook workbook,boolean bg,boolean border,short bgColor) throws Exception {
		XSSFCellStyle style = (XSSFCellStyle) workbook.createCellStyle();
		org.apache.poi.ss.usermodel.Font fonte = workbook.createFont();
		fonte.setFontHeightInPoints((short) 9);
		fonte.setFontName("Arial");
		fonte.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(fonte);
		style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		if (bg) {
			if (bgColor == HSSFColor.GREY_80_PERCENT.index) {
				style.setFillForegroundColor(new XSSFColor(new Color(217,217,217)));
			} else {
				style.setFillForegroundColor(bgColor);
			}
			style.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		}

		if (border) {
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			style.setRightBorderColor(HSSFColor.BLACK.index);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBottomBorderColor(HSSFColor.BLACK.index);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setLeftBorderColor(HSSFColor.BLACK.index);
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setTopBorderColor(HSSFColor.BLACK.index);
		}
		return style;
	}

}
