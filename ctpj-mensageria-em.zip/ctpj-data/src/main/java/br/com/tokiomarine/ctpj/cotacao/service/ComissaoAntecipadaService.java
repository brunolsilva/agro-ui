package br.com.tokiomarine.ctpj.cotacao.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoPagamentoView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.OpcaoParcelamentoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.EntradaParcelamentoEnum;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.ModuloProdutoEnum;
import br.com.tokiomarine.ctpj.enums.OrigemContratacaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.util.DateUtil;

@Service
@Transactional(rollbackFor = Exception.class)
public class ComissaoAntecipadaService {

	
	private static final String SIM = "S";

	private static Logger logger = LogManager.getLogger(ComissaoAntecipadaService.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private OpcaoParcelamentoRepository opcaoPactoPagtoCotacaoRepository;

	@LogPerformance
	public void atualizarComissaoAntecipada(List<CotacaoPagamentoView> pagamento,User user) {
		
		UriComponentsBuilder uri = null;
		ResponseEntity<String> responseEntity = null;
		try {
			Cotacao cotacao = cotacaoRepository.findById(pagamento.get(0).getCotacao());
			OpcaoParcelamento opcaoParcelamento = opcaoPactoPagtoCotacaoRepository.findOpcaoParcelamentoById(pagamento.get(0).getOpcaoSelecionada());

			String comissaoAntecipadaAcsel = parametroGeralService.getUrlByNome(ParametroGeralEnum.COMISSAO_ANTECIPADA_ACSEL);
			
			if ( comissaoAntecipadaAcsel != null && comissaoAntecipadaAcsel.equals(SIM) && cotacao.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {
				
				OrigemContratacaoEnum idOrigemContratacao;
				if (cotacao.getIdOrigemContratacao() != null) {
					idOrigemContratacao = cotacao.getIdOrigemContratacao();
				}else{
					idOrigemContratacao = user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR ? OrigemContratacaoEnum.ORIGEM_CORRETOR : OrigemContratacaoEnum.ORIGEM_SUBSCRITOR;
				}
				uri = UriComponentsBuilder
						.fromHttpUrl(parametroGeralService.getUrl(ParametroGeralEnum.getParametroServicoComissaoAntecipadaAcsel()) + "/" + cotacao.getCodigoCorretorACSEL())
							.queryParam("codigoModuloProduto",ModuloProdutoEnum.getByProdutoAndOrigem(cotacao.getCodigoProduto(),idOrigemContratacao.getId()).getCodigoModuloProduto())
							.queryParam("dataVigencia", DateUtil.formataSemHora(cotacao.getDataInicioVigencia()))
							.queryParam("tipoDocumentoCobranca", FormaPagamentoEnum.getByCodigo(opcaoParcelamento.getCodigoFormaPagamento()).getTipoDocumentoCobrancaAcsel())
							.queryParam("quantidadeParcelas",opcaoParcelamento.getQuantidadeParcelas())
							.queryParam("tipoComissao","ANT")
							.queryParam("tpPrimeiraParcela",EntradaParcelamentoEnum.getById(opcaoParcelamento.getIdEntrada().getId()).getIdAcsel());
				responseEntity = restTemplate.getForEntity(uri.build().toUri(), String.class);
				
				String retorno = responseEntity.getBody();
				if (retorno != null) {
					retorno = retorno.replaceAll("\"","");
				}
				SimNaoEnum idComissaoAntecipada = SimNaoEnum.fromValor(retorno);
				if (idComissaoAntecipada == null){
					throw new ServiceException("Retorno do serviço de comissão antecipada Ascel inválido "+uri.build().toUri());
				}
				cotacao.setIcComissaoAntecipada(idComissaoAntecipada);
			} else {
				uri = UriComponentsBuilder
						.fromHttpUrl(parametroGeralService.getUrl(ParametroGeralEnum.getParametroComissaoAntecipada()))
							.queryParam("cdProduto", cotacao.getCodigoProduto())
							.queryParam("cdCorretorAcx", cotacao.getCodigoCorretorACSEL())
							.queryParam("cdFormaPagamento", opcaoParcelamento.getCodigoFormaPagamento())
							.queryParam("cdFormaParcelamento", opcaoParcelamento.getCodigoFormaParcelamento());
				responseEntity = restTemplate.getForEntity(uri.build().toUri(), String.class);
				cotacao.setIcComissaoAntecipada(SimNaoEnum.fromValor(responseEntity.getBody()));

			}
			cotacaoRepository.save(cotacao);
		} catch (Exception e) {
			logger.error("Erro geral ao chamar serviço comissão antecipada");
//			throw new ServiceException(e.getMessage(),e);
		}
		 
	}
	
}
