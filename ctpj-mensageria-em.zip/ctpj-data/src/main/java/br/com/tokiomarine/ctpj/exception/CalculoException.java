package br.com.tokiomarine.ctpj.exception;

import java.util.List;

import br.com.tokiomarine.ctpj.dto.ResultadoREST;

public class CalculoException extends RuntimeException {

	private static final long serialVersionUID = 7663361063928391958L;
	private ResultadoREST<List<String>> resultado;

	public CalculoException(String message) {
		super(message);
	}

	public CalculoException(String message,Throwable cause) {
		super(message,cause);
	}

	public CalculoException(Throwable cause) {
		super(cause);
	}
	
	public CalculoException(String message,Throwable cause,ResultadoREST<List<String>> resultado) {
		super(message,cause);
		setResultado(resultado);
	}

	public ResultadoREST<List<String>> getResultado() {
		return resultado;
	}

	public void setResultado(ResultadoREST<List<String>> resultado) {
		this.resultado = resultado;
	}
}
