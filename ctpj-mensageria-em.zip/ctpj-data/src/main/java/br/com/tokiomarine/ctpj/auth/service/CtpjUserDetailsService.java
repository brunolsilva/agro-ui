package br.com.tokiomarine.ctpj.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.Authority;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.dto.CtpjToken;

@Service
public class CtpjUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return null;
	}

	public UserDetails loadUserBySolicitacao(CtpjToken ctpjToken) throws UsernameNotFoundException {

		User user = new User();
		List<Authority> authorities = new ArrayList<Authority>();
		Authority authority = new Authority();

		user.setCdUsuro(ctpjToken.getCdUsuro());
		user.setCdNivelAutz(ctpjToken.getSolicitacaoCotacao().getCdNivelAutz());
		user.setNmUsuro(ctpjToken.getSolicitacaoCotacao().getNmUsuro());
		
		authority.setAuthority(ctpjToken.getCdGrpEnum().getAuthority());
		authority.setCdGrp(ctpjToken.getCdGrpEnum().getCdGrp());
		
		authorities.add(authority);

		user.setAuthorities(authorities);

		return user;
	}
}