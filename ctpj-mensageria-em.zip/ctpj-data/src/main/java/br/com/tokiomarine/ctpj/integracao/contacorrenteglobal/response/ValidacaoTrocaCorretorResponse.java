package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response;

import java.io.Serializable;

public class ValidacaoTrocaCorretorResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -1793017314696247851L;
	private Long stRetorno;
	private String msgRetorno;
	private String sql_type;

	public Long getStRetorno() {
		return stRetorno;
	}

	public void setStRetorno(Long stRetorno) {
		this.stRetorno = stRetorno;
	}

	public String getMsgRetorno() {
		return msgRetorno;
	}

	public void setMsgRetorno(String msgRetorno) {
		this.msgRetorno = msgRetorno;
	}

	public String getSql_type() {
		return sql_type;
	}

	public void setSql_type(String sql_type) {
		this.sql_type = sql_type;
	}

}
