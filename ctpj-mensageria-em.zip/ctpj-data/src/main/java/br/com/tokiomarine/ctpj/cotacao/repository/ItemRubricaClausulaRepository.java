package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRubricaClausula;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class ItemRubricaClausulaRepository extends BaseDAO{	
	
	private static final String EXCLUI_ITEM_RUBRICA_CLAUSULA_POR_COTACAO = 
			"delete from ItemRubricaClausula ircl " +
			"where ircl in ("+
		    	"select ir " +
		    	"from ItemRubricaClausula ir " +
		    	"where ir.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao and ir.idClausulaAutomatica = :clausulaAutomatica) ";
	
	private static final String EXCLUI_ITEM_RUBRICA_CLAUSULA_POR_ITEM_COTACAO =
			"delete from ItemRubricaClausula ircl " +
			"where ircl in ("+
		    	"select ir " +
		    	"from ItemRubricaClausula ir " +
		    	"where ir.itemCotacao.sequencialItemCotacao = :seqItemCotacao and ir.idClausulaAutomatica = :clausulaAutomatica) ";
	
	private static final String BUSCA_ITEM_POR_COTACAO_AND_CLAUSULA = 
			"select irc " +
			"from ItemRubricaClausula irc " +
			"where irc.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao  and irc.codigoClausula =:codClausula and irc.idClausulaAutomatica = :clausulaAutomatica ";
	
	private static final String BUSCA_ITEM_POR_COTACAO_AND_RUBRICA = 
			"select irc " +
			"from ItemRubricaClausula irc " +
			"where irc.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao and irc.codRubrica = :codRubrica and irc.idClausulaAutomatica = :clausulaAutomatica ";
	
	private static final String BUSCA_ITEM_POR_ITEM_COTACAO_AND_CLAUSULA = 
			"select irc " +
			"from ItemRubricaClausula irc " +
			"where irc.itemCotacao.sequencialItemCotacao = :seqItemCotacao and irc.codigoClausula =:codClausula and irc.idClausulaAutomatica = :clausulaAutomatica ";
	
	public ItemRubricaClausula salva(ItemRubricaClausula item){
		getCurrentSession().save(item);
		return item;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemRubricaClausula> buscaClausulasManuaisPorCotacaoEClausula(BigInteger seqCotacao, Integer codClausula){
		List<ItemRubricaClausula> itens = getCurrentSession()
		.createQuery(BUSCA_ITEM_POR_COTACAO_AND_CLAUSULA)
		.setParameter("seqCotacao", seqCotacao)
		.setParameter("codClausula", codClausula)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.list();
		
		return itens;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemRubricaClausula> buscaClausulasManuasiPorCotacaoECodRubrica(BigInteger seqCotacao, Long codRubrica){
		List<ItemRubricaClausula> itens = getCurrentSession()
				.createQuery(BUSCA_ITEM_POR_COTACAO_AND_RUBRICA)
				.setParameter("seqCotacao", seqCotacao)
				.setParameter("codRubrica", codRubrica)
				.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
				.list();
		
		return itens;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemRubricaClausula> buscaClausulaManualPorItemCotacaoEClausula(BigInteger seqItemCotacao, Integer codClausula){
		List<ItemRubricaClausula> itens = getCurrentSession()
		.createQuery(BUSCA_ITEM_POR_ITEM_COTACAO_AND_CLAUSULA)
		.setParameter("seqItemCotacao", seqItemCotacao)
		.setParameter("codClausula", codClausula)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.list();
				
		return itens;
	}
	
	public void exclui(ItemRubricaClausula item){
		getCurrentSession().delete(item);
	}	
	
	public void excluiClausulaRubricaManualPorCotacao(BigInteger seqCotacao){
		getCurrentSession()
		.createQuery(EXCLUI_ITEM_RUBRICA_CLAUSULA_POR_COTACAO)
		.setParameter("seqCotacao", seqCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	@LogPerformance
	public void excluiClausualasAutomaticasPorCotacao(Cotacao cotacao){
		getCurrentSession()
		.createQuery(EXCLUI_ITEM_RUBRICA_CLAUSULA_POR_COTACAO)
		.setParameter("seqCotacao", cotacao.getSequencialCotacaoProposta())
		.setParameter("clausulaAutomatica", SimNaoEnum.SIM)
		.executeUpdate();
	}
	
	public void excluiClausulaRubricaManualPorItemCotacao(BigInteger seqItemCotacao){
		getCurrentSession()
		.createQuery(EXCLUI_ITEM_RUBRICA_CLAUSULA_POR_ITEM_COTACAO)
		.setParameter("seqItemCotacao", seqItemCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	public boolean existeClausulaPorCotacaoECodClausula(BigInteger seqCotacao, Integer codClausula){
		return !buscaClausulasManuaisPorCotacaoEClausula(seqCotacao, codClausula).isEmpty();
	}
	
	public boolean existeClausulaPorItemCotacaoECodClausula(BigInteger seqItemCotacao, Integer codClausula){
		return !buscaClausulaManualPorItemCotacaoEClausula(seqItemCotacao, codClausula).isEmpty();
	}

}
