package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.validation.constraints.NotNull;

public class ResseguroFacultativoFaixaForm implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer numeroItemFaixa;
	@NotNull(message = "Código SUSEP é obrigatório")
	private BigInteger codigoRessegurador;
	@NotNull(message = "Prêmio de resseguro é obrigatório")
	private BigDecimal valorPremioRessegurador;
	@NotNull(message = "Porcentagam de participação é obrigatório")
	private BigDecimal percentualParticipacao;
	@NotNull(message = "Porcentagam de comissão de resseguro é obrigatório")
	private BigDecimal percentualComissaoRessegurador;

	public Integer getNumeroItemFaixa() {
		return numeroItemFaixa;
	}

	public void setNumeroItemFaixa(Integer numeroItemFaixa) {
		this.numeroItemFaixa = numeroItemFaixa;
	}

	public BigInteger getCodigoRessegurador() {
		return codigoRessegurador;
	}

	public void setCodigoRessegurador(BigInteger codigoRessegurador) {
		this.codigoRessegurador = codigoRessegurador;
	}

	public BigDecimal getValorPremioRessegurador() {
		return valorPremioRessegurador;
	}

	public void setValorPremioRessegurador(BigDecimal valorPremioRessegurador) {
		this.valorPremioRessegurador = valorPremioRessegurador;
	}

	public BigDecimal getPercentualParticipacao() {
		return percentualParticipacao;
	}

	public void setPercentualParticipacao(BigDecimal percentualParticipacao) {
		this.percentualParticipacao = percentualParticipacao;
	}

	public BigDecimal getPercentualComissaoRessegurador() {
		return percentualComissaoRessegurador;
	}

	public void setPercentualComissaoRessegurador(BigDecimal percentualComissaoRessegurador) {
		this.percentualComissaoRessegurador = percentualComissaoRessegurador;
	}

	@Override
	public String toString() {
		return "ResseguroFacultativoFaixaForm [numeroItemFaixa=" + numeroItemFaixa + ", codigoRessegurador=" + codigoRessegurador + ", valorPremioRessegurador=" + valorPremioRessegurador + ", percentualParticipacao=" + percentualParticipacao + ", percentualComissaoRessegurador="
				+ percentualComissaoRessegurador + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigoRessegurador == null) ? 0 : codigoRessegurador.hashCode());
		result = prime * result + ((numeroItemFaixa == null) ? 0 : numeroItemFaixa.hashCode());
		result = prime * result + ((percentualComissaoRessegurador == null) ? 0 : percentualComissaoRessegurador.hashCode());
		result = prime * result + ((percentualParticipacao == null) ? 0 : percentualParticipacao.hashCode());
		result = prime * result + ((valorPremioRessegurador == null) ? 0 : valorPremioRessegurador.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResseguroFacultativoFaixaForm other = (ResseguroFacultativoFaixaForm) obj;
		if (codigoRessegurador == null) {
			if (other.codigoRessegurador != null)
				return false;
		} else if (!codigoRessegurador.equals(other.codigoRessegurador))
			return false;
		if (numeroItemFaixa == null) {
			if (other.numeroItemFaixa != null)
				return false;
		} else if (!numeroItemFaixa.equals(other.numeroItemFaixa))
			return false;
		if (percentualComissaoRessegurador == null) {
			if (other.percentualComissaoRessegurador != null)
				return false;
		} else if (!percentualComissaoRessegurador.equals(other.percentualComissaoRessegurador))
			return false;
		if (percentualParticipacao == null) {
			if (other.percentualParticipacao != null)
				return false;
		} else if (!percentualParticipacao.equals(other.percentualParticipacao))
			return false;
		if (valorPremioRessegurador == null) {
			if (other.valorPremioRessegurador != null)
				return false;
		} else if (!valorPremioRessegurador.equals(other.valorPremioRessegurador))
			return false;
		return true;
	}

}
