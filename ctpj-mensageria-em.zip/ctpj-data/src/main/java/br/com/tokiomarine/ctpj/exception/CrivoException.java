package br.com.tokiomarine.ctpj.exception;


public class CrivoException  extends Exception{
	
	private static final long serialVersionUID = -3346313279043958074L;

	public CrivoException(String message) {
		super(message);
	}

	public CrivoException(String message,Throwable cause) {
		super(message,cause);
	}

}
