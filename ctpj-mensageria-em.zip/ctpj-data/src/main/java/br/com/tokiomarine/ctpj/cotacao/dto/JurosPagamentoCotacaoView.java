package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class JurosPagamentoCotacaoView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8931337109148019889L;

	private Integer codigoFormaPagamento;
	private String descricaoFormaPagamento;
	private List<JurosParcelamentoCotacaoView> listaJurosParcelamentoCotacao;

	public Integer getCodigoFormaPagamento() {
		return codigoFormaPagamento;
	}

	public void setCodigoFormaPagamento(Integer codigoFormaPagamento) {
		this.codigoFormaPagamento = codigoFormaPagamento;
	}

	public String getDescricaoFormaPagamento() {
		return descricaoFormaPagamento;
	}

	public void setDescricaoFormaPagamento(String descricaoFormaPagamento) {
		this.descricaoFormaPagamento = descricaoFormaPagamento;
	}

	public List<JurosParcelamentoCotacaoView> getListaJurosParcelamentoCotacao() {
		return listaJurosParcelamentoCotacao;
	}

	public void setListaJurosParcelamentoCotacao(List<JurosParcelamentoCotacaoView> listaJurosParcelamentoCotacaoView) {
		this.listaJurosParcelamentoCotacao = listaJurosParcelamentoCotacaoView;
	}

}
