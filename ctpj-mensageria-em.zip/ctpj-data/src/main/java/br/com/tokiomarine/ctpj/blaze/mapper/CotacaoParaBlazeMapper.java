package br.com.tokiomarine.ctpj.blaze.mapper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.blaze.dto.AlteracaoEndossoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ApoliceBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ComissaoCotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.CotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.DescontoAgravacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemApoliceBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCoberturaApoliceBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCoberturaBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemDadosObraBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemDistribuicaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemEmbarcacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemEmbarqueBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemQbrBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemSistemaProtecionalBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ParcelamentoApoliceBlaze;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ComissaoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCobDescAgravApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCoberturaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemDadosObraApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemDistribuicaoVrApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemEmbarcacaoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemEmbarqueApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemQbrApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemSistemaProtecionalApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ParcelamentoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ContaCorrenteGlobal;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCrivo;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDadosObra;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarcacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarque;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemQBR;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

public class CotacaoParaBlazeMapper {

	public CotacaoBlaze createCotacaoBlaze(Cotacao cotacao,Apolice apolice, List<ItemApolice> itens,User user) {
		CotacaoBlaze cotacaoBlaze = new CotacaoBlaze();
		cotacaoBlaze.setSequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta() != null ? cotacao.getSequencialCotacaoProposta().longValue() : null);
		cotacaoBlaze.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta() != null ? cotacao.getNumeroCotacaoProposta().longValue() : null);
		cotacaoBlaze.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		cotacaoBlaze.setDataCotacao(cotacao.getDataCotacao());
		cotacaoBlaze.setNumeroCNPJCPFSegurado(cotacao.getNumeroCNPJCPFSegurado());
		cotacaoBlaze.setCodigoAtividadePrincipal(cotacao.getCodigoAtividadePrincipal() != null ? cotacao.getCodigoAtividadePrincipal().longValue() : null);
		cotacaoBlaze.setIdCEPSegurado(cotacao.getIdCEPSegurado());
		cotacaoBlaze.setIdTipoSeguro(cotacao.getIdTipoSeguro() != null ? cotacao.getIdTipoSeguro().getId() : null);
		cotacaoBlaze.setCodigoLocal(cotacao.getCodigoLocal());
		cotacaoBlaze.setCodigoSubLocal(cotacao.getCodigoSubLocal());
		cotacaoBlaze.setCodigoProdutor(cotacao.getCodigoProdutor());
		cotacaoBlaze.setCodigoCorretorACSEL(cotacao.getCodigoCorretorACSEL());
		cotacaoBlaze.setCodigoProduto(cotacao.getCodigoProduto());
		cotacaoBlaze.setDataInicioVigencia(cotacao.getDataInicioVigencia());
		cotacaoBlaze.setDataFimVigencia(cotacao.getDataFimVigencia());
		cotacaoBlaze.setDataAlteracao(cotacao.getDataAlteracao());
		cotacaoBlaze.setIdPrazoVigencia(cotacao.getIdPrazoVigencia() != null ? cotacao.getIdPrazoVigencia().getId() : null);
		cotacaoBlaze.setIdTipoEndosso(cotacao.getIdTipoEndosso() != null ? cotacao.getIdTipoEndosso().getId() : null);
		cotacaoBlaze.setIdSolicitante(cotacao.getIdSolicitanteEndosso() != null ? cotacao.getIdSolicitanteEndosso().getId() : null);
		cotacaoBlaze.setValorPremioParteAjustavel(cotacao.getValorPremioParteAjustavel() != null ? cotacao.getValorPremioParteAjustavel().doubleValue() : null);
		cotacaoBlaze.setPercentualPremioDepositoMinimo(cotacao.getPercentualPremioDepositoMinimo() != null ? cotacao.getPercentualPremioDepositoMinimo().doubleValue() : null);
		cotacaoBlaze.setIdTipoPedidoCotacao(cotacao.getIdTipoPedidoCotacao() != null ? cotacao.getIdTipoPedidoCotacao().getId() : null);
		cotacaoBlaze.setDataProposta(cotacao.getDataProposta());
		cotacaoBlaze.setPercentualDescontoAcordoIRB(cotacao.getPercentualDescontoAcordoIRB() != null ? cotacao.getPercentualDescontoAcordoIRB().doubleValue() : null);
		cotacaoBlaze.setCodigoMoeda(cotacao.getCodigoMoeda() != null ? cotacao.getCodigoMoeda().getId() : null);
		cotacaoBlaze.setPercentualDescontoGeral(cotacao.getPercentualDescontoGeral() != null ? cotacao.getPercentualDescontoGeral().doubleValue() : null);
		cotacaoBlaze.setPercentualAgravoGeral(cotacao.getPercentualAgravoGeral() != null ? cotacao.getPercentualAgravoGeral().doubleValue() : null);
		cotacaoBlaze.setNumeroQuantidadeItens(cotacao.getListItem().size());
		cotacaoBlaze.setIdLmiUnico(cotacao.getIdLmiUnico() != null ? cotacao.getIdLmiUnico().getId() : null);
		cotacaoBlaze.setCodigoUsuario(user.getCdUsuro() != null ? user.getCdUsuro().longValue() : null);
		cotacaoBlaze.setNomeUsuario(user.getNmUsuro());
		cotacaoBlaze.setGrupoUsuario(user.getGrupoUsuario() != null ? user.getGrupoUsuario().getCdGrp().longValue() : null);
		cotacaoBlaze.setValorPremioInformado(cotacao.getValorPremioInformado() != null ? cotacao.getValorPremioInformado().doubleValue() : null);
		List<ItemApolice> listItemApolice = new ArrayList<>(); 
		if (apolice != null){
			cotacaoBlaze.setApolice(this.getApolice(apolice,cotacao));
			cotacaoBlaze.setListComissaoApolice(createListComissaoApoliceMapper(apolice.getListComissaoApolice()));
			listItemApolice = apolice.getListItemApolice();
		}
		cotacaoBlaze.setListComissaoCotacao(createListComissaoCotacaoMapper(cotacao.getListComissaoCotacao()));
		cotacaoBlaze.setListItem(createListItemBlazeMapper(cotacao.getIdLmiUnico(),cotacao.getListComissaoCotacao(),cotacaoBlaze.getListComissaoApolice(),cotacao.getListItem(),listItemApolice,itens));
		cotacaoBlaze.setListAlteracaoEndosso(createListAlteracaoEndosso(cotacao.getListAlteracaoEndosso()));
		for (ContaCorrenteGlobal contaCorrenteGlobal: cotacao.getListContaCorrenteGlobal()){
			cotacaoBlaze.setValorDescontoContaCorrente(contaCorrenteGlobal.getValorDescontoCCG() != null ? contaCorrenteGlobal.getValorDescontoCCG().doubleValue() : null);
			cotacaoBlaze.setValorAgravacaoContaCorrente(contaCorrenteGlobal.getValorAgravoCCG() != null ? contaCorrenteGlobal.getValorAgravoCCG().doubleValue() : null);
		}
		cotacaoBlaze.setPercentualPremioAjustavel(cotacao.getPercentualPremioParteAjustavel() != null ? cotacao.getPercentualPremioParteAjustavel().doubleValue() : null);
		cotacaoBlaze.setPercentualPremioFixo(cotacao.getPercentualPremioParteFixa() != null ? cotacao.getPercentualPremioParteFixa().doubleValue() : null);
		return cotacaoBlaze;
	}

	public List<AlteracaoEndossoBlaze> createListAlteracaoEndosso(List<AlteracaoEndosso> listAlteracaoEndosso) {
		List<AlteracaoEndossoBlaze> listAlteracaoEndossoBlaze = new ArrayList<>();
		for	(AlteracaoEndosso alteracaoEndosso : listAlteracaoEndosso){
			AlteracaoEndossoBlaze alteracaoEndossoBlaze = new AlteracaoEndossoBlaze();
			alteracaoEndossoBlaze.setNumeroItem(alteracaoEndosso.getItemCotacao() != null ? alteracaoEndosso.getItemCotacao().getNumeroItem().longValue() : null);
			alteracaoEndossoBlaze.setCodigoCobertura(alteracaoEndosso.getItemCobertura() != null ? alteracaoEndosso.getItemCobertura().getCodigoCobertura() : null);
			alteracaoEndossoBlaze.setCodigoTipoAlteracao(alteracaoEndosso.getCodigoTipoAlteracao());
			listAlteracaoEndossoBlaze.add(alteracaoEndossoBlaze);
		}
		return listAlteracaoEndossoBlaze;
	}

	private ApoliceBlaze getApolice(Apolice apolice,Cotacao cotacao) {
		ApoliceBlaze apoliceBlaze = new ApoliceBlaze();
		apoliceBlaze.setSequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta() != null ? cotacao.getSequencialCotacaoProposta().longValue() : null);
		apoliceBlaze.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta() != null ? cotacao.getNumeroCotacaoProposta().longValue() : null);
		apoliceBlaze.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		apoliceBlaze.setNumeroCNPJCPFSegurado(apolice.getNumeroCNPJCPFSegurado());
		apoliceBlaze.setCodigoAtividadePrincipal(apolice.getCodigoAtividadePrincipal() != null ? apolice.getCodigoAtividadePrincipal().longValue() : null);
		apoliceBlaze.setIdCEPSegurado(apolice.getIdCEPSegurado());
		apoliceBlaze.setCodigoLocal(apolice.getCodigoLocal());
		apoliceBlaze.setCodigoSubLocal(apolice.getCodigoSubLocal());
		apoliceBlaze.setCodigoProdutor(apolice.getCodigoProdutor());
		apoliceBlaze.setCodigoCorretorACSEL(apolice.getCodigoCorretorACSEL());
		apoliceBlaze.setCodigoProduto(apolice.getCodigoProduto());
		apoliceBlaze.setDataInicioVigencia(apolice.getDataInicioVigencia());
		apoliceBlaze.setDataFimVigencia(apolice.getDataFimVigencia());
		apoliceBlaze.setIdPrazoVigencia(apolice.getIdPrazoVigencia() != null ? apolice.getIdPrazoVigencia().getId() : null);
		apoliceBlaze.setPercentualDescontoAcordoIRB(apolice.getPercentualDescontoAcordoIRB() != null ? apolice.getPercentualDescontoAcordoIRB().doubleValue() : null);
		apoliceBlaze.setCodigoMoeda(apolice.getCodigoMoeda() != null ? apolice.getCodigoMoeda().getId() : null);
		apoliceBlaze.setPercentualDescontoGeral(apolice.getPercentualDescontoGeral() != null ? apolice.getPercentualDescontoGeral().doubleValue() : null);
		apoliceBlaze.setListParcelamentoApolice((apolice.getListParcelamentoApolice() != null && !apolice.getListParcelamentoApolice().isEmpty()) ? getParcelamentoApolice(apolice.getListParcelamentoApolice()) : null);
		apoliceBlaze.setIdOrigemApolice(apolice.getCodSistemaOrigem());
		return apoliceBlaze;
	}

	private List<ParcelamentoApoliceBlaze> getParcelamentoApolice(List<ParcelamentoApolice> listParcelamentoApolice) {
		List<ParcelamentoApoliceBlaze> listApoliceParcelamentoBlaze = new ArrayList<>();
		for (ParcelamentoApolice parcelamentoApolice : listParcelamentoApolice) {
			ParcelamentoApoliceBlaze parcelamentoApoliceBlaze = new ParcelamentoApoliceBlaze();
			parcelamentoApoliceBlaze.setCodigoRamoProduto(parcelamentoApolice.getCodigoRamoProduto());
			parcelamentoApoliceBlaze.setCodigoApolice(parcelamentoApolice.getCodigoApolice());
			parcelamentoApoliceBlaze.setCodigoTipoEndosso(parcelamentoApolice.getCodigoTipoEndosso());
			parcelamentoApoliceBlaze.setCodigoEndosso(parcelamentoApolice.getCodigoEndosso());
			parcelamentoApoliceBlaze.setNumeroParcela(parcelamentoApolice.getNumeroParcela());
			parcelamentoApoliceBlaze.setIdentificadorSituacao(parcelamentoApolice.getIdSituacaoParcelamento() != null ? parcelamentoApolice.getIdSituacaoParcelamento().getId() :null);
			parcelamentoApoliceBlaze.setDataVencimento(parcelamentoApolice.getDataVencimento());
			parcelamentoApoliceBlaze.setValorParcela(parcelamentoApolice.getValorParcela() != null ? parcelamentoApolice.getValorParcela().doubleValue() : null);
			parcelamentoApoliceBlaze.setValorJuros(parcelamentoApolice.getValorJuros() != null ? parcelamentoApolice.getValorJuros().doubleValue() : null);
			parcelamentoApoliceBlaze.setValorCustoApolice(parcelamentoApolice.getValorCustoApolice() != null ? parcelamentoApolice.getValorCustoApolice().doubleValue() : null);
			parcelamentoApoliceBlaze.setValorIof(parcelamentoApolice.getValorIof() != null ? parcelamentoApolice.getValorIof().doubleValue() : null);
			parcelamentoApoliceBlaze.setDataRecebimento(parcelamentoApolice.getDataRecebimento());
			parcelamentoApoliceBlaze.setValorRecebido(parcelamentoApolice.getValorRecebido() != null ? parcelamentoApolice.getValorRecebido().doubleValue() : null);
			parcelamentoApoliceBlaze.setValorJurosRecebido(parcelamentoApolice.getValorJurosRecebido() != null ? parcelamentoApolice.getValorJurosRecebido().doubleValue() : null);
			parcelamentoApoliceBlaze.setValorIofRecebido(parcelamentoApolice.getValorIofRecebido() != null ? parcelamentoApolice.getValorIofRecebido().doubleValue() : null);
			listApoliceParcelamentoBlaze.add(parcelamentoApoliceBlaze);
		}
		return listApoliceParcelamentoBlaze;
	}

	public List<ItemCotacaoBlaze> createListItemBlazeMapper(
			SimNaoEnum idLmiUnico,
			Set<ComissaoCotacao> listComissaoCotacao,
			List<ComissaoCotacaoBlaze> listComissaoApolice,
			Set<ItemCotacao> listItem,
			List<ItemApolice> listItemApolice,
			List<ItemApolice> listItemApoliceDiferenteCapa) {
		List<ItemCotacaoBlaze> listItemCotacaoBlaze = new ArrayList<>(); 
		for (ItemCotacao item : listItem) {
			if(item.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (idLmiUnico == SimNaoEnum.SIM || item.getIdTipoEndosso() != null)) {
				ItemCotacaoBlaze itemCotacaoBlaze = new ItemCotacaoBlaze();
				itemCotacaoBlaze.setSequencialItemCotacao(item.getSequencialItemCotacao() != null ? item.getSequencialItemCotacao().longValue() : null);
				itemCotacaoBlaze.setNumeroItem(item.getNumeroItem() != null ? item.getNumeroItem().longValue() : null);
				itemCotacaoBlaze.setNumeroCNPJCPFSegurado(item.getNumeroCNPJCPFSegurado());
				itemCotacaoBlaze.setCodigoAtividadePrincipal(item.getCodigoAtividadePrincipal());
				itemCotacaoBlaze.setIdCEPSegurado(item.getIdCEPSegurado());
				itemCotacaoBlaze.setDataInicioVigencia(item.getDataInicioVigencia());
				itemCotacaoBlaze.setDataFimVigencia(item.getDataFimVigencia());
				itemCotacaoBlaze.setIdResseguroFacultativo(item.getIdResseguroFacultativo() != null ? item.getIdResseguroFacultativo().getId() : null);
				itemCotacaoBlaze.setNumeroItemEndossado(item.getCodigoItemApoliceEndossada() != null ? item.getCodigoItemApoliceEndossada().longValue() : null);
				itemCotacaoBlaze.setNumeroItemRenovado(item.getNumeroItemApoliceCongenere());
				itemCotacaoBlaze.setIdTipoEndosso(item.getIdTipoEndosso() != null ? item.getIdTipoEndosso() : null);
				itemCotacaoBlaze.setDataAlteracao(item.getDataAlteracao());
				itemCotacaoBlaze.setIdExclusaoEndosso(item.getIdExclusaoEndosso() != null ? item.getIdExclusaoEndosso().getId() : null);
				itemCotacaoBlaze.setIdTipoSeguro(item.getIdTipoSeguro() != null ? item.getIdTipoSeguro().getId() : null );
				itemCotacaoBlaze.setCodigoClasseBonus(item.getCodigoClasseBonus() != null ? item.getCodigoClasseBonus().getId() : null);
				itemCotacaoBlaze.setIdCEPLocalRisco(item.getIdCEPLocalRisco());
				itemCotacaoBlaze.setCodigoMunicipioLocalRisco(item.getCodigoMunicipioLocalRisco());
				itemCotacaoBlaze.setCodigoRubrica(item.getCodigoRubrica());
				itemCotacaoBlaze.setDescricaoRubrica(item.getDescricaoRubrica());
				itemCotacaoBlaze.setCodigoRegiaoTarifaria(item.getCodigoRegiaoTarifaria());
				itemCotacaoBlaze.setDataConversaoValorRisco(item.getDataConversaoValorRisco());
				itemCotacaoBlaze.setCoeficienteConversaoMoeda(item.getCoeficienteConversaoMoeda() != null ? item.getCoeficienteConversaoMoeda().doubleValue() : null);
				itemCotacaoBlaze.setCodigoClasseLocalizacao(item.getCodigoClasseLocalizacao());
				itemCotacaoBlaze.setCodigoClasseConstrucao(item.getCodigoClasseConstrucao());
				itemCotacaoBlaze.setCodigoBemCoberto(item.getCodigoBemCoberto());
				itemCotacaoBlaze.setCodigoLocalizacao(item.getCodigoLocalizacao());
				itemCotacaoBlaze.setCodigoAmbitoGeografico(item.getCodigoAmbitoGeografico());
				itemCotacaoBlaze.setQuantidadeSinistros(item.getQuantidadeSinistros());
				itemCotacaoBlaze.setValorSinistroPago(item.getValorSinistroPago() != null ? item.getValorSinistroPago().doubleValue() : null);
				itemCotacaoBlaze.setPercentualRelacaoImportanciaSeguradaValorRisco(item.getPercentualRelacaoImportanciaSeguradaValorRisco() != null ? item.getPercentualRelacaoImportanciaSeguradaValorRisco().doubleValue() : null);
				itemCotacaoBlaze.setPercentualRelacaoDMPValorRisco(item.getPercentualRelacaoDMPValorRisco() != null ? item.getPercentualRelacaoDMPValorRisco().doubleValue() : null);
				itemCotacaoBlaze.setValorRiscoBem(item.getValorRiscoBem() != null ? item.getValorRiscoBem().doubleValue() : null);
				itemCotacaoBlaze.setValorRiscoBemCalculado(item.getValorRiscoBemCalculado() != null ? item.getValorRiscoBemCalculado().doubleValue() : null);
				itemCotacaoBlaze.setValorMaiorRiscoIsolado(item.getValorMaiorRiscoIsolado() != null ? item.getValorMaiorRiscoIsolado().doubleValue() : null);
				itemCotacaoBlaze.setValorRiscoBemMoedaEstrangeira(item.getValorRiscoBemMoedaEstrangeira() != null ? item.getValorRiscoBemMoedaEstrangeira().doubleValue() : null);
				itemCotacaoBlaze.setValorCalculadoMoedaEstrangeira(item.getValorCalculadoMoedaEstrangeira() != null ? item.getValorCalculadoMoedaEstrangeira().doubleValue() : null);
				itemCotacaoBlaze.setValorIsoladoMoedaEstrangeira(item.getValorIsoladoMoedaEstrangeira() != null ? item.getValorIsoladoMoedaEstrangeira().doubleValue() : null);
				itemCotacaoBlaze.setQuantidadeDiasProRata(item.getQuantidadeDiasProRata());
				itemCotacaoBlaze.setPercentualPrazoCurto(item.getPercentualPrazoCurto() != null ? item.getPercentualPrazoCurto().doubleValue() : null);
				itemCotacaoBlaze.setIdVinilona(item.getIdVinilona() != null ? item.getIdVinilona().getId() : null);
				itemCotacaoBlaze.setPercentualDescontoItem(item.getPercentualDescontoItem() != null ? item.getPercentualDescontoItem().doubleValue() : null);
				itemCotacaoBlaze.setPercentualAgravacaoItem(item.getPercentualAgravacaoItem() != null ? item.getPercentualAgravacaoItem().doubleValue() : null);
				itemCotacaoBlaze.setPercentualSinistralidade(item.getPercentualSinistralidade() != null ? item.getPercentualSinistralidade().doubleValue() : 0.0);
				
				if(!SecurityUtils.isCorretor()) {
					for	(ItemCrivo itemCrivo : item.getListItemCrivo()){
						if(itemCrivo.getIdResultadoCrivo() != null && !itemCrivo.getIdResultadoCrivo().equals("0")) {
							itemCotacaoBlaze.setIdResultadoCrivo(itemCrivo.getIdResultadoCrivo() != null ? itemCrivo.getIdResultadoCrivo() : null);
						}
					}
				}

				itemCotacaoBlaze.setListItemDadosObra(item.getListItemDadosObra() != null ? createListItemDadosObra(item.getListItemDadosObra()) : null);
				itemCotacaoBlaze.setListItemDistribuicao(item.getListItemDistribuicao() != null ? createListItemDistribuicao(item.getListItemDistribuicao()) : null);
				itemCotacaoBlaze.setListItemEmbarcacao(item.getListItemEmbarcacao() != null ? createListItemEmbarcacao(item.getListItemEmbarcacao()) : null);
				itemCotacaoBlaze.setListItemEmbarque(item.getListItemEmbarque() != null ? createListItemEmbarque(item.getListItemEmbarque()) : null);
				itemCotacaoBlaze.setListItemQBR(item.getListItemQBR() != null ? createListItemQBR(item.getListItemQBR()) : null);
				itemCotacaoBlaze.setListItemSistemaProtecional(item.getListItemSistemaProtecional() != null ? createListItemSistemaProtecional(item.getListItemSistemaProtecional()) : null);

				ItemApolice itemApolice = new ItemApolice(); 
				Optional<ItemApolice> oia = listItemApolice.stream()
						.filter(it -> item.getNumeroItemEndos() != null && it.getCodigoItemApolice().equals(item.getNumeroItemEndos().intValue()))
						.findFirst();
				
				if(item.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
					oia = listItemApolice.stream()
							.filter(it -> item.getCodigoItemRenovada() != null && it.getCodigoItemApolice().equals(item.getCodigoItemRenovada().intValue()))
							.findFirst();
				}

				if (oia.isPresent()) {
					itemApolice = oia.get();
					itemCotacaoBlaze.setItemApolice(this.getItemApolice(itemApolice));
					if(itemApolice.getListItemDadosObraApolice() != null) {
						itemCotacaoBlaze.setListItemDadosObraApolice(this.getListItemDadosObraApolice(itemApolice.getListItemDadosObraApolice()));
					}
					if(itemApolice.getListItemDistribuicaoVrApolice() != null) {
						itemCotacaoBlaze.setListItemDistribuicaoApolice(this.getListItemDistribuicaoApolice(itemApolice.getListItemDistribuicaoVrApolice()));
					}
					if(itemApolice.getListItemEmbarcacaoApolice() != null) {
						itemCotacaoBlaze.setListItemEmbarcacaoApolice(this.getListItemEmbarcacaoApolice(itemApolice.getListItemEmbarcacaoApolice()));
					}
					if(itemApolice.getListItemEmbarqueApolice() != null) {
						itemCotacaoBlaze.setListItemEmbarqueApolice(this.getListItemEmbarqueApolice(itemApolice.getListItemEmbarqueApolice()));
					}
					if(itemApolice.getListItemQbrApolice() != null) {
						itemCotacaoBlaze.setListItemQBRApolice(this.getListItemQBRApolice(itemApolice.getListItemQbrApolice()));
					}
					if(itemApolice.getListItemSistemaProtecionalApolice() != null) {
						itemCotacaoBlaze.setListItemSistemaProtecionalApolice(this.getListItemSistemaProtecionalApolice(itemApolice.getListItemSistemaProtecionalApolice()));
					}
				} else {
					Optional<ItemApolice> itemApoliceEncontrado = listItemApoliceDiferenteCapa.stream()
						.filter(it -> it.getCodigoApolice().equals(item.getCodigoApolice()) 
								&& item.getCodigoItemRenovada().equals(it.getCodigoItemApolice().longValue()))
						.findFirst();
					if(itemApoliceEncontrado.isPresent()) {
						itemApolice = itemApoliceEncontrado.get();
						itemCotacaoBlaze.setItemApolice(this.getItemApolice(itemApolice));
						if(itemApolice.getListItemDadosObraApolice() != null) {
							itemCotacaoBlaze.setListItemDadosObraApolice(this.getListItemDadosObraApolice(itemApolice.getListItemDadosObraApolice()));
						}
						if(itemApolice.getListItemDistribuicaoVrApolice() != null) {
							itemCotacaoBlaze.setListItemDistribuicaoApolice(this.getListItemDistribuicaoApolice(itemApolice.getListItemDistribuicaoVrApolice()));
						}
						if(itemApolice.getListItemEmbarcacaoApolice() != null) {
							itemCotacaoBlaze.setListItemEmbarcacaoApolice(this.getListItemEmbarcacaoApolice(itemApolice.getListItemEmbarcacaoApolice()));
						}
						if(itemApolice.getListItemEmbarqueApolice() != null) {
							itemCotacaoBlaze.setListItemEmbarqueApolice(this.getListItemEmbarqueApolice(itemApolice.getListItemEmbarqueApolice()));
						}
						if(itemApolice.getListItemQbrApolice() != null) {
							itemCotacaoBlaze.setListItemQBRApolice(this.getListItemQBRApolice(itemApolice.getListItemQbrApolice()));
						}
						if(itemApolice.getListItemSistemaProtecionalApolice() != null) {
							itemCotacaoBlaze.setListItemSistemaProtecionalApolice(this.getListItemSistemaProtecionalApolice(itemApolice.getListItemSistemaProtecionalApolice()));
						}
					}
				}

				if (item.getListItemCobertura() != null) {
					List<ItemCoberturaApolice> listItemCoberturaApolice = new ArrayList<>();
					if (itemApolice.getListItemCoberturaApolice() != null){
						listItemCoberturaApolice = itemApolice.getListItemCoberturaApolice();
					}
					itemCotacaoBlaze.setListItemCobertura(createListItemCoberturaMapper(idLmiUnico,listComissaoCotacao,listComissaoApolice,item.getListItemCobertura(),listItemCoberturaApolice, item.getCotacao().getIdTipoEndosso()));
				}

				listItemCotacaoBlaze.add(itemCotacaoBlaze);
			}
		}
		return listItemCotacaoBlaze;
	}

	public List<ItemSistemaProtecionalBlaze> getListItemSistemaProtecionalApolice(List<ItemSistemaProtecionalApolice> listItemSistemaProtecionalApolice) {
		List<ItemSistemaProtecionalBlaze> listItemSistemaProtecionalBlaze = new ArrayList<>();
		for (ItemSistemaProtecionalApolice itemSistemaProtecionalApolice : listItemSistemaProtecionalApolice) {
			ItemSistemaProtecionalBlaze itemSistemaProtecionalBlaze = new ItemSistemaProtecionalBlaze();
			itemSistemaProtecionalBlaze.setCodigoSistemaProtecional(itemSistemaProtecionalApolice.getCodigoSistemaProtecional() != null ? itemSistemaProtecionalApolice.getCodigoSistemaProtecional().intValue() : null);
			itemSistemaProtecionalBlaze.setPercentualDesconto(itemSistemaProtecionalApolice.getPercentualDesconto() != null ? itemSistemaProtecionalApolice.getPercentualDesconto().doubleValue() : null);
			listItemSistemaProtecionalBlaze.add(itemSistemaProtecionalBlaze);
		}
		return listItemSistemaProtecionalBlaze;
	}

	public List<ItemQbrBlaze> getListItemQBRApolice(List<ItemQbrApolice> listItemQbrApolice) {
		List<ItemQbrBlaze> listItemQbrBlaze = new ArrayList<>();
		for (ItemQbrApolice itemQbrApolice : listItemQbrApolice) {
			ItemQbrBlaze itemQbrBlaze = new ItemQbrBlaze();
			itemQbrBlaze.setIdPergunta(itemQbrApolice.getIdPergunta());
			itemQbrBlaze.setIdResposta(itemQbrApolice.getIdResposta());
			listItemQbrBlaze.add(itemQbrBlaze);
		}
		return listItemQbrBlaze;
	}

	public List<ItemEmbarqueBlaze> getListItemEmbarqueApolice(List<ItemEmbarqueApolice> listItemEmbarqueApolice) {
		List<ItemEmbarqueBlaze> listItemEmbarqueBlaze = new ArrayList<>();
		for (ItemEmbarqueApolice itemEmbarqueApolice : listItemEmbarqueApolice){
			ItemEmbarqueBlaze itemEmbarqueBlaze = new ItemEmbarqueBlaze();
			itemEmbarqueBlaze.setNumeroEmbarquePerigosos(itemEmbarqueApolice.getNumeroEmbarquePerigosos() != null ? itemEmbarqueApolice.getNumeroEmbarquePerigosos().longValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarquePerigosos(itemEmbarqueApolice.getValorTotalEmbarquePerigosos() != null ? itemEmbarqueApolice.getValorTotalEmbarquePerigosos().doubleValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarquePerigosoMoedaEstrangeira(itemEmbarqueApolice.getValorTotalEmbarquePerigosoMoedaEstrangeira() != null ? itemEmbarqueApolice.getValorTotalEmbarquePerigosoMoedaEstrangeira().doubleValue() : null);
			itemEmbarqueBlaze.setNumeroEmbarqueComum(itemEmbarqueApolice.getNumeroEmbarqueComum() != null ? itemEmbarqueApolice.getNumeroEmbarqueComum().longValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarqueComum(itemEmbarqueApolice.getValorTotalEmbarqueComum() != null ? itemEmbarqueApolice.getValorTotalEmbarqueComum().doubleValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarqueComumMoedaEstrangeira(itemEmbarqueApolice.getValorTotalEmbarqueComumMoedaEstrangeira() != null ? itemEmbarqueApolice.getValorTotalEmbarqueComumMoedaEstrangeira().doubleValue() : null);
			itemEmbarqueBlaze.setPercentualEmbarqueMercosul(itemEmbarqueApolice.getPercentualEmbarqueMercosul() != null ? itemEmbarqueApolice.getPercentualEmbarqueMercosul().doubleValue() : null);
			itemEmbarqueBlaze.setPercentualDescontoMercosul(itemEmbarqueApolice.getPercentualDescontoMercosul() != null ? itemEmbarqueApolice.getPercentualDescontoMercosul().doubleValue() : null);
			itemEmbarqueBlaze.setDescricaoEmpresaGerenciamentoRisco(itemEmbarqueApolice.getDescricaoEmpresaGerenciamentoRisco());			
			listItemEmbarqueBlaze.add(itemEmbarqueBlaze);	
		}
		return listItemEmbarqueBlaze;
	}

	public List<ItemEmbarcacaoBlaze> getListItemEmbarcacaoApolice(List<ItemEmbarcacaoApolice> listItemEmbarcacaoApolice) {
		List<ItemEmbarcacaoBlaze> listItemEmbarcacaoBlaze = new ArrayList<>();
		for (ItemEmbarcacaoApolice itemEmbarcacaoApolice : listItemEmbarcacaoApolice) {
			ItemEmbarcacaoBlaze itemEmbarcacaoBlaze = new ItemEmbarcacaoBlaze();
			itemEmbarcacaoBlaze.setNomeEmbarcacao(itemEmbarcacaoApolice.getNomeEmbarcacao());
			itemEmbarcacaoBlaze.setNomeEstaleiroFabricacao(itemEmbarcacaoApolice.getNomeEstaleiroFabricacao());
			itemEmbarcacaoBlaze.setNomeModelo(itemEmbarcacaoApolice.getNomeModelo());
			itemEmbarcacaoBlaze.setIdAssociadoClube(itemEmbarcacaoApolice.getIdAssociadoClube() != null ? itemEmbarcacaoApolice.getIdAssociadoClube().longValue() : null);
			itemEmbarcacaoBlaze.setIdPropulsaoMotor(itemEmbarcacaoApolice.getIdPropulsaoMotor() != null ? itemEmbarcacaoApolice.getIdPropulsaoMotor().longValue() : null);
			itemEmbarcacaoBlaze.setIdClasseEmbarcacao(itemEmbarcacaoApolice.getIdClasseEmbarcacao() != null ? itemEmbarcacaoApolice.getIdClasseEmbarcacao().longValue() : null);
			itemEmbarcacaoBlaze.setIdPortoInscricao(itemEmbarcacaoApolice.getIdPortoInscricao() != null ? itemEmbarcacaoApolice.getIdPortoInscricao().longValue() : null);
			itemEmbarcacaoBlaze.setNomeFabricanteMotor(itemEmbarcacaoApolice.getNomeFabricanteMotor());
			itemEmbarcacaoBlaze.setNumeroSerieMotor(itemEmbarcacaoApolice.getNumeroSerieMotor());
			itemEmbarcacaoBlaze.setTipoModeloMotor(itemEmbarcacaoApolice.getTipoModeloMotor());
			itemEmbarcacaoBlaze.setNumeroInscricao(itemEmbarcacaoApolice.getNumeroInscricao());
			itemEmbarcacaoBlaze.setNomeRazaoSocialLocalGuarda(itemEmbarcacaoApolice.getNomeRazaoSocialLocalGuarda());
			itemEmbarcacaoBlaze.setNomeRazaoSocialClubeEntidadeDesportiva(itemEmbarcacaoApolice.getNomeRazaoSocialClubeEntidadeDesportiva());
			itemEmbarcacaoBlaze.setIdEmpresaVistoriaServicos(itemEmbarcacaoApolice.getIdEmpresaVistoriaServicos() != null ? itemEmbarcacaoApolice.getIdEmpresaVistoriaServicos().longValue() : null);
			itemEmbarcacaoBlaze.setDataRealizacaoVistoria(itemEmbarcacaoApolice.getDataRealizacaoVistoria());
			itemEmbarcacaoBlaze.setNumeroLaudoVistoria(itemEmbarcacaoApolice.getNumeroLaudoVistoria());
			itemEmbarcacaoBlaze.setValorCascoEmbarcacao(itemEmbarcacaoApolice.getValorCascoEmbarcacao() != null ? itemEmbarcacaoApolice.getValorCascoEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorMotorEmbarcacao(itemEmbarcacaoApolice.getValorMotorEmbarcacao() != null ? itemEmbarcacaoApolice.getValorMotorEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorEquipamentoAcessorioEmbarcacao(itemEmbarcacaoApolice.getValorEquipamentoAcessorioEmbarcacao() != null ? itemEmbarcacaoApolice.getValorEquipamentoAcessorioEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorVelaMastroEmbarcacao(itemEmbarcacaoApolice.getValorVelaMastroEmbarcacao() != null ? itemEmbarcacaoApolice.getValorVelaMastroEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorCascoEmbarcacaoMoedaEstrangeira(itemEmbarcacaoApolice.getValorCascoEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacaoApolice.getValorCascoEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorMotorEmbarcacaoMoedaEstrangeira(itemEmbarcacaoApolice.getValorMotorEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacaoApolice.getValorMotorEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorEquipamentoEmbarcacaoMoedaEstrangeira(itemEmbarcacaoApolice.getValorEquipamentoEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacaoApolice.getValorEquipamentoEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorVelaEmbarcacaoMoedaEstrangeira(itemEmbarcacaoApolice.getValorVelaEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacaoApolice.getValorVelaEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			listItemEmbarcacaoBlaze.add(itemEmbarcacaoBlaze);
		}
		return listItemEmbarcacaoBlaze;
	}

	public List<ItemDistribuicaoBlaze> getListItemDistribuicaoApolice(List<ItemDistribuicaoVrApolice> listItemDistribuicaoVrApolice) {
		List<ItemDistribuicaoBlaze> listItemDistribuicaoBlaze = new ArrayList<>();
		for (ItemDistribuicaoVrApolice itemDistribuicaoVrApolice : listItemDistribuicaoVrApolice) {
			ItemDistribuicaoBlaze itemDistribuicaoBlaze = new ItemDistribuicaoBlaze();
			itemDistribuicaoBlaze.setIdTipoValorRisco(itemDistribuicaoVrApolice.getIdTipoValorRisco() != null ? itemDistribuicaoVrApolice.getIdTipoValorRisco().getId() : null);
			itemDistribuicaoBlaze.setValorRiscoBem(itemDistribuicaoVrApolice.getValorRiscoBem() != null ? itemDistribuicaoVrApolice.getValorRiscoBem().doubleValue() : null);
			itemDistribuicaoBlaze.setValorRiscoBemMoedaEstrangeira(itemDistribuicaoVrApolice.getValorRiscoBemMoedaEstrangeira() != null ? itemDistribuicaoVrApolice.getValorRiscoBemMoedaEstrangeira().doubleValue() : null);
			listItemDistribuicaoBlaze.add(itemDistribuicaoBlaze);
		}
		return listItemDistribuicaoBlaze;
	}

	public List<ItemDadosObraBlaze> getListItemDadosObraApolice(List<ItemDadosObraApolice> listItemDadosObraApolice) {
		List<ItemDadosObraBlaze> listItemDadosObraBlaze = new ArrayList<>();
		for (ItemDadosObraApolice itemDadosObraApolice : listItemDadosObraApolice){
			ItemDadosObraBlaze itemDadosObraBlaze = new ItemDadosObraBlaze();
			itemDadosObraBlaze.setDataInicioObra(itemDadosObraApolice.getDataInicioObra());
			itemDadosObraBlaze.setDataFimObra(itemDadosObraApolice.getDataFimObra());
			itemDadosObraBlaze.setIdFundacao(itemDadosObraApolice.getIdFundacao() != null ? itemDadosObraApolice.getIdFundacao().getId() : null);
			itemDadosObraBlaze.setNumeroSubSolo(itemDadosObraApolice.getNumeroSubSolo());
			itemDadosObraBlaze.setCodigoTipoFundacao(itemDadosObraApolice.getCodigoTipoFundacao());
			itemDadosObraBlaze.setCodigoSeveridade(itemDadosObraApolice.getCodigoSeveridade());
			itemDadosObraBlaze.setIdEscavacaoSubSolo(itemDadosObraApolice.getIdEscavacaoSubSolo() != null ? itemDadosObraApolice.getIdEscavacaoSubSolo().getId() : null);
			itemDadosObraBlaze.setIdRebaixamentoLencol(itemDadosObraApolice.getIdRebaixamentoLencol() != null ? itemDadosObraApolice.getIdRebaixamentoLencol().getId() : null);
			itemDadosObraBlaze.setIdSFH(itemDadosObraApolice.getIdSFH() != null ? itemDadosObraApolice.getIdSFH().getId() : null);
			itemDadosObraBlaze.setCodigoTipoConstrucao(itemDadosObraApolice.getCodigoTipoConstrucao());
			itemDadosObraBlaze.setValorTotalObra(itemDadosObraApolice.getValorTotalObra() != null ? itemDadosObraApolice.getValorTotalObra().doubleValue() : null);
			itemDadosObraBlaze.setValorTotalObraMoedaEstrangeira(itemDadosObraApolice.getValorTotalObraMoedaEstrangeira() != null ? itemDadosObraApolice.getValorTotalObraMoedaEstrangeira().doubleValue() : null);			
			listItemDadosObraBlaze.add(itemDadosObraBlaze);
		}
		return listItemDadosObraBlaze;
	}

	private ItemApoliceBlaze getItemApolice(ItemApolice itemApolice) {
		ItemApoliceBlaze itemApoliceBlaze = new ItemApoliceBlaze();
		itemApoliceBlaze.setNumeroCNPJCPFSegurado(itemApolice.getNumeroCNPJCPFSegurado());
		itemApoliceBlaze.setCodigoAtividadePrincipal(itemApolice.getCodigoAtividadePrincipal());
		itemApoliceBlaze.setIdCEPSegurado(itemApolice.getIdCEPSegurado());
		itemApoliceBlaze.setDataInicioVigencia(itemApolice.getDataInicioVigencia());
		itemApoliceBlaze.setDataFimVigencia(itemApolice.getDataFimVigencia());
		itemApoliceBlaze.setNumeroItemEndossado(itemApolice.getCodigoItemApolice() != null ? itemApolice.getCodigoItemApolice().longValue() : null);
		itemApoliceBlaze.setNumeroItemRenovado(itemApolice.getCodigoItemApoliceRenovada());
		itemApoliceBlaze.setIdTipoEndosso(itemApolice.getIdTipoEndosso() != null ? itemApolice.getIdTipoEndosso().getId(): null);
		itemApoliceBlaze.setDataAlteracao(itemApolice.getDataAlteracao());
		itemApoliceBlaze.setCodigoClasseBonus(itemApolice.getCodigoClasseBonus() != null ? itemApolice.getCodigoClasseBonus().getId() : null);
		itemApoliceBlaze.setIdCEPLocalRisco(itemApolice.getIdCEPLocalRisco());
		itemApoliceBlaze.setCodigoMunicipioLocalRisco(itemApolice.getCodigoMunicipioLocalRisco());
		itemApoliceBlaze.setCodigoRubrica(itemApolice.getCodigoRubrica());
		itemApoliceBlaze.setCodigoRegiaoTarifaria(itemApolice.getCodigoRegiaoTarifaria());
		itemApoliceBlaze.setDataConversaoValorRisco(itemApolice.getDataConversaoValorRisco());
		itemApoliceBlaze.setCoeficienteConversaoMoeda(itemApolice.getCoeficienteConversaoMoeda() != null ? itemApolice.getCoeficienteConversaoMoeda().doubleValue() : null);
		itemApoliceBlaze.setCodigoClasseLocalizacao(itemApolice.getCodigoClasseLocalizacao());
		itemApoliceBlaze.setCodigoClasseOcupacao(itemApolice.getCodigoClasseOcupacao());
		itemApoliceBlaze.setCodigoClasseConstrucao(itemApolice.getCodigoClasseConstrucao());
		itemApoliceBlaze.setCodigoBemCoberto(itemApolice.getCodigoBemCoberto());
		itemApoliceBlaze.setCodigoLocalizacao(itemApolice.getCodigoLocalizacao());
		itemApoliceBlaze.setCodigoAmbitoGeografico(itemApolice.getCodigoAmbitoGeografico());
		itemApoliceBlaze.setPercentualRelacaoImportanciaSeguradaValorRisco(itemApolice.getPercentualRelacaoIsVr() != null ? itemApolice.getPercentualRelacaoIsVr().doubleValue() : null);
		itemApoliceBlaze.setPercentualRelacaoDMPValorRisco(itemApolice.getPercentualRelacaoDmpVr() != null ? itemApolice.getPercentualRelacaoDmpVr().doubleValue() : null);
		itemApoliceBlaze.setValorRiscoBem(itemApolice.getValorRiscoBem() != null ? itemApolice.getValorRiscoBem().doubleValue() : null);
		itemApoliceBlaze.setValorRiscoBemCalculado(itemApolice.getValorRiscoBemCalculado() != null ? itemApolice.getValorRiscoBemCalculado().doubleValue() : null);
		itemApoliceBlaze.setValorMaiorRiscoIsolado(itemApolice.getValorMaiorRiscoIsolado() != null ? itemApolice.getValorMaiorRiscoIsolado().doubleValue() : null);
		itemApoliceBlaze.setValorRiscoBemMoedaEstrangeira(itemApolice.getValorRiscoBemMoedaEstrangeira() != null ? itemApolice.getValorRiscoBemMoedaEstrangeira().doubleValue() : null);
		itemApoliceBlaze.setValorCalculadoMoedaEstrangeira(itemApolice.getValorRiscoBemCalculadoMoedaEstrangeira() != null ? itemApolice.getValorRiscoBemCalculadoMoedaEstrangeira().doubleValue() : null);
		itemApoliceBlaze.setValorIsoladoMoedaEstrangeira(itemApolice.getValorMaiorRiscoIsoladoMoedaEstrangeira() != null ? itemApolice.getValorMaiorRiscoIsoladoMoedaEstrangeira().doubleValue() : null);
		itemApoliceBlaze.setQuantidadeDiasProRata(itemApolice.getQuantidadeDiasProRata());
		itemApoliceBlaze.setPercentualPrazoCurto(itemApolice.getPercentualPrazoCurto() != null ? itemApolice.getPercentualPrazoCurto().doubleValue() : null);
		itemApoliceBlaze.setIdVinilona(itemApolice.getIdGalpaoVinilona() != null ? itemApolice.getIdGalpaoVinilona().getId() : null);
		itemApoliceBlaze.setPercentualDescontoItem(itemApolice.getPercentualDescontoItem() != null ? itemApolice.getPercentualDescontoItem().doubleValue() : null);
		itemApoliceBlaze.setPercentualAgravacaoItem(itemApolice.getPercentualAgravacaoItem() != null ? itemApolice.getPercentualAgravacaoItem().doubleValue() : null);
		itemApoliceBlaze.setPercentualSinistralidade(itemApolice.getPercentualSinistralidade() != null ? itemApolice.getPercentualSinistralidade().doubleValue() : null);
		return itemApoliceBlaze;
	}

	public List<ItemQbrBlaze> createListItemQBR(List<ItemQBR> listItemQBR) {
		List<ItemQbrBlaze> listItemQbrBlaze = new ArrayList<>();
		for (ItemQBR itemQBR : listItemQBR) {
			ItemQbrBlaze itemQbrBlaze = new ItemQbrBlaze();
			itemQbrBlaze.setSequencialItemQBR(itemQBR.getSequencialItemQBR() != null ? itemQBR.getSequencialItemQBR().longValue() : null);
			itemQbrBlaze.setIdPergunta(itemQBR.getIdPergunta());
			itemQbrBlaze.setIdResposta(itemQBR.getIdResposta());
			listItemQbrBlaze.add(itemQbrBlaze);
		}
		return listItemQbrBlaze;
	}

	public List<ItemEmbarqueBlaze> createListItemEmbarque(List<ItemEmbarque> listItemEmbarque) {
		List<ItemEmbarqueBlaze> listItemEmbarqueBlaze = new ArrayList<>();
		for (ItemEmbarque itemEmbarque : listItemEmbarque) {
			ItemEmbarqueBlaze itemEmbarqueBlaze = new ItemEmbarqueBlaze();
			itemEmbarqueBlaze.setSequencialItemEmbarque(itemEmbarque.getSequencialItemEmbarque() != null ? itemEmbarque.getSequencialItemEmbarque().longValue() : null);
			itemEmbarqueBlaze.setNumeroEmbarquePerigosos(itemEmbarque.getNumeroEmbarquePerigosos() != null ? itemEmbarque.getNumeroEmbarquePerigosos().longValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarquePerigosos(itemEmbarque.getValorTotalEmbarquePerigosos() != null ? itemEmbarque.getValorTotalEmbarquePerigosos().doubleValue() : null);
			itemEmbarqueBlaze.setNumeroEmbarqueComum(itemEmbarque.getNumeroEmbarqueComum() != null ? itemEmbarque.getNumeroEmbarqueComum().longValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarqueComum(itemEmbarque.getValorTotalEmbarqueComum() != null ? itemEmbarque.getValorTotalEmbarqueComum().doubleValue() : null);
			itemEmbarqueBlaze.setPercentualEmbarqueMercosul(itemEmbarque.getPercentualEmbarqueMercosul() != null ? itemEmbarque.getPercentualEmbarqueMercosul().doubleValue() : null);
			itemEmbarqueBlaze.setPercentualDescontoMercosul(itemEmbarque.getPercentualDescontoMercosul() != null ? itemEmbarque.getPercentualDescontoMercosul().doubleValue() : null);
			itemEmbarqueBlaze.setDescricaoEmpresaGerenciamentoRisco(itemEmbarque.getDescricaoEmpresaGerenciamentoRisco());
			itemEmbarqueBlaze.setValorTotalEmbarquePerigosoMoedaEstrangeira(itemEmbarque.getValorTotalEmbarquePerigosoMoedaEstrangeira() != null ? itemEmbarque.getValorTotalEmbarquePerigosoMoedaEstrangeira().doubleValue() : null);
			itemEmbarqueBlaze.setValorTotalEmbarqueComumMoedaEstrangeira(itemEmbarque.getValorTotalEmbarqueComumMoedaEstrangeira() != null ? itemEmbarque.getValorTotalEmbarqueComumMoedaEstrangeira().doubleValue() : null);
			listItemEmbarqueBlaze.add(itemEmbarqueBlaze);
		}
		return listItemEmbarqueBlaze;
	}

	public List<ItemEmbarcacaoBlaze> createListItemEmbarcacao(List<ItemEmbarcacao> listItemEmbarcacao) {
		List<ItemEmbarcacaoBlaze> listItemEmbarcacaoBlaze = new ArrayList<>();
		for (ItemEmbarcacao itemEmbarcacao : listItemEmbarcacao) {
			ItemEmbarcacaoBlaze itemEmbarcacaoBlaze = new ItemEmbarcacaoBlaze();
			itemEmbarcacaoBlaze.setSequencialItemEmbarcacao(itemEmbarcacao.getSequencialItemEmbarcacao() != null ? itemEmbarcacao.getSequencialItemEmbarcacao().longValue() : null);
			itemEmbarcacaoBlaze.setNomeEmbarcacao(itemEmbarcacao.getNomeEmbarcacao());
			itemEmbarcacaoBlaze.setNomeEstaleiroFabricacao(itemEmbarcacao.getNomeEstaleiroFabricacao());
			itemEmbarcacaoBlaze.setNomeModelo(itemEmbarcacao.getNomeModelo());
			itemEmbarcacaoBlaze.setIdAssociadoClube(itemEmbarcacao.getIdAssociadoClube() != null ? itemEmbarcacao.getIdAssociadoClube().longValue() : null);
			itemEmbarcacaoBlaze.setIdPropulsaoMotor(itemEmbarcacao.getIdPropulsaoMotor() != null ? itemEmbarcacao.getIdPropulsaoMotor().longValue() : null);
			itemEmbarcacaoBlaze.setIdClasseEmbarcacao(itemEmbarcacao.getIdClasseEmbarcacao() != null ? itemEmbarcacao.getIdClasseEmbarcacao().longValue() : null);
			itemEmbarcacaoBlaze.setIdPortoInscricao(itemEmbarcacao.getIdPortoInscricao() != null ? itemEmbarcacao.getIdPortoInscricao().longValue() : null);
			itemEmbarcacaoBlaze.setNomeFabricanteMotor(itemEmbarcacao.getNomeFabricanteMotor());
			itemEmbarcacaoBlaze.setNumeroSerieMotor(itemEmbarcacao.getNumeroSerieMotor());
			itemEmbarcacaoBlaze.setTipoModeloMotor(itemEmbarcacao.getTipoModeloMotor());
			itemEmbarcacaoBlaze.setNumeroInscricao(itemEmbarcacao.getNumeroInscricao());
			itemEmbarcacaoBlaze.setNomeRazaoSocialLocalGuarda(itemEmbarcacao.getNomeRazaoSocialLocalGuarda());
			itemEmbarcacaoBlaze.setNomeRazaoSocialClubeEntidadeDesportiva(itemEmbarcacao.getNomeRazaoSocialClubeEntidadeDesportiva());
			itemEmbarcacaoBlaze.setIdEmpresaVistoriaServicos(itemEmbarcacao.getIdEmpresaVistoriaServicos() != null ? itemEmbarcacao.getIdEmpresaVistoriaServicos().longValue() : null);
			itemEmbarcacaoBlaze.setDataRealizacaoVistoria(itemEmbarcacao.getDataRealizacaoVistoria());
			itemEmbarcacaoBlaze.setNumeroLaudoVistoria(itemEmbarcacao.getNumeroLaudoVistoria());
			itemEmbarcacaoBlaze.setValorCascoEmbarcacao(itemEmbarcacao.getValorCascoEmbarcacao() != null ? itemEmbarcacao.getValorCascoEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorMotorEmbarcacao(itemEmbarcacao.getValorMotorEmbarcacao() != null ? itemEmbarcacao.getValorMotorEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorEquipamentoAcessorioEmbarcacao(itemEmbarcacao.getValorEquipamentoAcessorioEmbarcacao() != null ? itemEmbarcacao.getValorEquipamentoAcessorioEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorVelaMastroEmbarcacao(itemEmbarcacao.getValorVelaMastroEmbarcacao() != null ? itemEmbarcacao.getValorVelaMastroEmbarcacao().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorCascoEmbarcacaoMoedaEstrangeira(itemEmbarcacao.getValorCascoEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacao.getValorCascoEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorMotorEmbarcacaoMoedaEstrangeira(itemEmbarcacao.getValorMotorEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacao.getValorMotorEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorEquipamentoEmbarcacaoMoedaEstrangeira(itemEmbarcacao.getValorEquipamentoEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacao.getValorEquipamentoEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			itemEmbarcacaoBlaze.setValorVelaEmbarcacaoMoedaEstrangeira(itemEmbarcacao.getValorVelaEmbarcacaoMoedaEstrangeira() != null ? itemEmbarcacao.getValorVelaEmbarcacaoMoedaEstrangeira().doubleValue() : null);
			listItemEmbarcacaoBlaze.add(itemEmbarcacaoBlaze);
		}
		return listItemEmbarcacaoBlaze;
	}

	public List<ItemDistribuicaoBlaze> createListItemDistribuicao(Set<ItemDistribuicao> listItemDistribuicao) {
		List<ItemDistribuicaoBlaze> listItemDistribuicaoBlaze = new ArrayList<>();
		for (ItemDistribuicao itemDistribuicao : listItemDistribuicao) {
			ItemDistribuicaoBlaze itemDistribuicaoBlaze = new ItemDistribuicaoBlaze();
			itemDistribuicaoBlaze.setSequencialItemDistribuicao(itemDistribuicao.getSequencialItemDistribuicao() != null ? itemDistribuicao.getSequencialItemDistribuicao().longValue() : null);
			itemDistribuicaoBlaze.setSequencialDistribuicaoValorRisco(itemDistribuicao.getSequencialDistribuicaoValorRisco() != null ? itemDistribuicao.getSequencialDistribuicaoValorRisco().longValue() : null);
			itemDistribuicaoBlaze.setIdTipoValorRisco(itemDistribuicao.getIdTipoValorRisco() != null ? itemDistribuicao.getIdTipoValorRisco().getId() : null);
			itemDistribuicaoBlaze.setValorRiscoBem(itemDistribuicao.getValorRiscoBem() != null ? itemDistribuicao.getValorRiscoBem().doubleValue() : null);
			itemDistribuicaoBlaze.setValorRiscoBemMoedaEstrangeira(itemDistribuicao.getValorRiscoBemMoedaEstrangeira() != null ? itemDistribuicao.getValorRiscoBemMoedaEstrangeira().doubleValue() : null);
			listItemDistribuicaoBlaze.add(itemDistribuicaoBlaze);
		}
		return listItemDistribuicaoBlaze;
	}

	public List<ItemDadosObraBlaze> createListItemDadosObra(List<ItemDadosObra> listItemDadosObra) {
		List<ItemDadosObraBlaze> listItemDadosObraBlaze = new ArrayList<>();
		for (ItemDadosObra itemDadosObra : listItemDadosObra) {
			ItemDadosObraBlaze itemDadosObraBlaze = new ItemDadosObraBlaze();
			itemDadosObraBlaze.setSequencialItemDadosObra(itemDadosObra.getSequencialItemDadosObra() != null ? itemDadosObra.getSequencialItemDadosObra().longValue() : null);
			itemDadosObraBlaze.setDataInicioObra(itemDadosObra.getDataInicioObra());
			itemDadosObraBlaze.setDataFimObra(itemDadosObra.getDataFimObra());
			itemDadosObraBlaze.setIdFundacao(itemDadosObra.getIdFundacao() != null ? itemDadosObra.getIdFundacao().getId() : null);
			itemDadosObraBlaze.setNumeroSubSolo(itemDadosObra.getNumeroSubSolo());
			itemDadosObraBlaze.setCodigoTipoFundacao(itemDadosObra.getCodigoTipoFundacao());
			itemDadosObraBlaze.setCodigoSeveridade(itemDadosObra.getCodigoSeveridade());
			itemDadosObraBlaze.setIdEscavacaoSubSolo(itemDadosObra.getIdEscavacaoSubSolo() != null ? itemDadosObra.getIdEscavacaoSubSolo().getId() : null);
			itemDadosObraBlaze.setIdRebaixamentoLencol(itemDadosObra.getIdRebaixamentoLencol() != null ? itemDadosObra.getIdRebaixamentoLencol().getId() : null);
			itemDadosObraBlaze.setIdSFH( itemDadosObra.getIdSFH() != null ? itemDadosObra.getIdSFH().getId() : null);
			itemDadosObraBlaze.setCodigoTipoConstrucao(itemDadosObra.getCodigoTipoConstrucao());
			itemDadosObraBlaze.setValorTotalObra(itemDadosObra.getValorTotalObra() != null ? itemDadosObra.getValorTotalObra().doubleValue() : null);
			itemDadosObraBlaze.setValorTotalObraMoedaEstrangeira(itemDadosObra.getValorTotalObraMoedaEstrangeira() != null ? itemDadosObra.getValorTotalObraMoedaEstrangeira().doubleValue() : null);
			listItemDadosObraBlaze.add(itemDadosObraBlaze);
		}
		return listItemDadosObraBlaze;
	}

	public List<ItemSistemaProtecionalBlaze> createListItemSistemaProtecional(Set<ItemSistemaProtecional> listItemSistemaProtecional) {
		List<ItemSistemaProtecionalBlaze> listItemSistemaProtecionalBlaze = new ArrayList<>();
		for (ItemSistemaProtecional itemSistemaProtecional : listItemSistemaProtecional) {
			ItemSistemaProtecionalBlaze itemSistemaProtecionalBlaze = new ItemSistemaProtecionalBlaze();
			itemSistemaProtecionalBlaze.setSequencialItemSistemaProtecional(itemSistemaProtecional.getSequencialItemSistemaProtecional() != null ? itemSistemaProtecional.getSequencialItemSistemaProtecional().longValue() : null);
			itemSistemaProtecionalBlaze.setCodigoSistemaProtecional(itemSistemaProtecional.getCodigoSistemaProtecional() != null ? itemSistemaProtecional.getCodigoSistemaProtecional().intValue() : null);
			itemSistemaProtecionalBlaze.setPercentualDesconto(itemSistemaProtecional.getPercentualDesconto() != null ? itemSistemaProtecional.getPercentualDesconto().doubleValue() : null);
			listItemSistemaProtecionalBlaze.add(itemSistemaProtecionalBlaze);
		}
		return listItemSistemaProtecionalBlaze;
	}

	public List<ItemCoberturaBlaze> createListItemCoberturaMapper(
			SimNaoEnum idLmiUnico,
			Set<ComissaoCotacao> listComissaoCotacao,
			List<ComissaoCotacaoBlaze> listComissaoApolice,
			Set<ItemCobertura> listItemCobertura,
			List<ItemCoberturaApolice> listItemCoberturaApolice,
			TipoEndossoEnum idTipoEndosso) {
		List<ItemCoberturaBlaze> listItemCoberturaBlaze = new ArrayList<>();
		for (ItemCobertura itemCobertura : listItemCobertura) {
			ItemCoberturaBlaze itemCoberturaBlaze = new ItemCoberturaBlaze();
			itemCoberturaBlaze.setIdExclusaoEndosso(itemCobertura.getIdExclusaEndosso() != null ? itemCobertura.getIdExclusaEndosso().getId(): "N");
			itemCoberturaBlaze.setSequencialItemCobertura(itemCobertura.getSequencialItemCobertura() != null ? itemCobertura.getSequencialItemCobertura().longValue() : null);
			itemCoberturaBlaze.setCodigoCobertura(itemCobertura.getCodigoCobertura());
			itemCoberturaBlaze.setDescricaoCobertura(itemCobertura.getDescricaoCobertura());
			itemCoberturaBlaze.setIdCoberturaAvulsa(itemCobertura.getIdCoberturaAvulsa() != null ? itemCobertura.getIdCoberturaAvulsa().getId() : null);
			itemCoberturaBlaze.setCodigoGrupoRamo(itemCobertura.getCodigoGrupoRamoEmissao());
			itemCoberturaBlaze.setCodigoRamoCobertura(itemCobertura.getCodigoRamoCoberturaEmissao());
			itemCoberturaBlaze.setValorImportanciaSegurada(itemCobertura.getValorImportanciaSegurada() != null ? itemCobertura.getValorImportanciaSegurada().doubleValue() : null);
			itemCoberturaBlaze.setIdControleReintegracao("N");
			TipoEndossoSctEnum tipoEndosso = itemCobertura.getItemCotacao().getCotacao().getCodigoTipoEndossoSCT();
			if(TipoEndossoSctEnum.REINTEGRACAO_IS == tipoEndosso) {
				if(itemCobertura.getItemCotacao().getListItemSinistro() != null) {
					for(ItemSinistro itemSinistro: itemCobertura.getItemCotacao().getListItemSinistro()) {
						if(itemSinistro.getListItemCoberturaSinistro() != null) {
							for(ItemCoberturaSinistro itemCoberturaSinistro: itemSinistro.getListItemCoberturaSinistro()) {
								if(itemCoberturaSinistro.getCodigoCobertura().equals(itemCoberturaBlaze.getCodigoCobertura())) {
									itemCoberturaBlaze.setIdControleReintegracao("S");
								}
							}
						}
					}
				}
			}

			if (itemCobertura.getValorSublimite() != null) {
				if (idLmiUnico == SimNaoEnum.SIM){
					itemCoberturaBlaze.setValorSublimite(itemCobertura.getValorSublimite().doubleValue());
				} else {
					itemCoberturaBlaze.setValorSublimite(itemCobertura.getValorImportanciaSegurada() != null ? itemCobertura.getValorImportanciaSegurada().doubleValue() : null);
				}
			}else{
				//De acordo com o Bruno Speria mesmo não sendo LMI devemos passar o valor do SubLimite, por este motivo foi 
				//passado o valor da Importância Segurada
				if (idLmiUnico.equals(SimNaoEnum.NAO)){
					itemCoberturaBlaze.setValorSublimite(itemCobertura.getValorImportanciaSegurada() != null ? itemCobertura.getValorImportanciaSegurada().doubleValue() : null);
				} else {
					itemCoberturaBlaze.setValorSublimite(0.0);
				}
			}
			itemCoberturaBlaze.setValorSublimiteOriginal(itemCobertura.getValorSublimiteOriginal() != null ? itemCobertura.getValorSublimiteOriginal().doubleValue() : null);
			itemCoberturaBlaze.setNumeroMultiploFranquia(itemCobertura.getNumeroMultiploFranquia() != null ? itemCobertura.getNumeroMultiploFranquia().doubleValue() : null);
			itemCoberturaBlaze.setNumeroMultiploPrejuizo(itemCobertura.getNumeroMultiploPrejuizo() != null ? itemCobertura.getNumeroMultiploPrejuizo().doubleValue() : null);
			if ((itemCobertura.getIdFranquiaInformado() == SimNaoEnum.SIM) 
					|| Arrays.asList(
							TipoEndossoEnum.CANCELAMENTO_APOLICE,
							TipoEndossoEnum.CANCELAMENTO_ENDOSSO,
							TipoEndossoEnum.REDUCAO_IS_SINISTRO,
							TipoEndossoEnum.ALTERACAO_DADOS_CADASTRAIS,
							TipoEndossoEnum.ALTERACAO_SEGURADO_TDO,
							TipoEndossoEnum.ALTERACAO_CONDICAO_COMERCIAL_DOCUMENTO,
							TipoEndossoEnum.PRORROGACAO_VIGENCIA).contains(idTipoEndosso)) {
				itemCoberturaBlaze.setIdFormaFranquia(itemCobertura.getIdFormaFranquia() != null ? itemCobertura.getIdFormaFranquia().getId() : null); // TODO - NAO ESQUECE DE CONFIRMAR
				itemCoberturaBlaze.setNumeroHorasFranquia(itemCobertura.getNumeroHorasFranquia());
				itemCoberturaBlaze.setNumeroDiasFranquia(itemCobertura.getNumeroDiasFranquia());
				itemCoberturaBlaze.setTaxaFranquia(itemCobertura.getTaxaFranquia() != null ? itemCobertura.getTaxaFranquia().doubleValue() : null);
				itemCoberturaBlaze.setValorFranquia(itemCobertura.getValorFranquia() != null ? itemCobertura.getValorFranquia().doubleValue() : null);
				itemCoberturaBlaze.setValorFranquiaMinima(itemCobertura.getValorFranquiaMinima() != null ? itemCobertura.getValorFranquiaMinima().doubleValue() : null);
				itemCoberturaBlaze.setValorFranquiaMaxima(itemCobertura.getValorFranquiaMaxima() != null ? itemCobertura.getValorFranquiaMaxima().doubleValue() : null);
				itemCoberturaBlaze.setTaxaImportanciaSegurada(itemCobertura.getTaxaImportanciaSegurada() != null ? itemCobertura.getTaxaImportanciaSegurada().doubleValue() : null);
				itemCoberturaBlaze.setTaxaImportanciaSeguradaMinima(itemCobertura.getTaxaImportanciaSeguradaMinima() != null ? itemCobertura.getTaxaImportanciaSeguradaMinima().doubleValue() : null);
				itemCoberturaBlaze.setTaxaImportanciaSeguradaMaxima(itemCobertura.getTaxaImportanciaSeguradaMaxima() != null ? itemCobertura.getTaxaImportanciaSeguradaMaxima().doubleValue() : null);
			}
			itemCoberturaBlaze.setIdTextoFranquia(itemCobertura.getIdTextoFranquia());
			itemCoberturaBlaze.setCodigoPeriodoIndenitario(itemCobertura.getCodigoPeriodoIndenitario());
			itemCoberturaBlaze.setIdLMR(itemCobertura.getIdLMR() != null ? itemCobertura.getIdLMR().getId() : null );
			if (itemCobertura.getValorPremio() != null) {
				itemCoberturaBlaze.setValorPremio(itemCobertura.getValorPremio() != null ? itemCobertura.getValorPremio().doubleValue() : null);
			}
			if (itemCobertura.getValorPremioVigencia() != null) {
				itemCoberturaBlaze.setValorPremioVigencia(itemCobertura.getValorPremioVigencia() != null ? itemCobertura.getValorPremioVigencia().doubleValue() : null);
			}
//			if (itemCobertura.getValorPremioNET() != null) {
//				itemCoberturaBlaze.setValorPremioNET(itemCobertura.getValorPremioNET().doubleValue() : null);
//			}
			if (itemCobertura.getValorPremioReferencial() != null) {
				itemCoberturaBlaze.setValorPremioReferencial(itemCobertura.getValorPremioReferencial() != null ? itemCobertura.getValorPremioReferencial().doubleValue() : null);
			}
			itemCoberturaBlaze.setPercentualPremioDepositoMinimo(itemCobertura.getPercentualPremioDepositoMinimo() != null ? itemCobertura.getPercentualPremioDepositoMinimo().doubleValue() : null);
			itemCoberturaBlaze.setValorISMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira() != null ? itemCobertura.getValorISMoedaEstrangeira().doubleValue() : null);
			itemCoberturaBlaze.setValorPremioMoedaEstrangeira(itemCobertura.getValorPremioMoedaEstrangeira() != null ? itemCobertura.getValorPremioMoedaEstrangeira().doubleValue() : null);
			if (itemCobertura.getPercentualTaxaCalculoPremio() != null && itemCobertura.getIdCoberturaAvulsa() == SimNaoEnum.SIM) {
				if(!listComissaoCotacao.isEmpty()) {
					itemCoberturaBlaze.setPercentualComissao(new ArrayList<>(listComissaoCotacao).get(0).getPercentualComissao().doubleValue());
				}
				itemCoberturaBlaze.setPercentualTaxaCalculoPremio(itemCobertura.getPercentualTaxaCalculoPremio() != null ? itemCobertura.getPercentualTaxaCalculoPremio().doubleValue() : null);
			}
			itemCoberturaBlaze.setValorSublimiteMoedaEstrangeira(itemCobertura.getValorSublimiteMoedaEstrangeira() != null ? itemCobertura.getValorSublimiteMoedaEstrangeira().doubleValue() : null);
			itemCoberturaBlaze.setValorSublimiteOriginalMoedaEstrangeira(itemCobertura.getValorSublimiteOriginalMoedaEstrangeira() != null ? itemCobertura.getValorSublimiteOriginalMoedaEstrangeira().doubleValue() : null);
			itemCoberturaBlaze.setIdDanosMateriais(itemCobertura.getIdDanosMateriais() != null ? itemCobertura.getIdDanosMateriais().getId() : null);
			itemCoberturaBlaze.setIdLucrosCessantes(itemCobertura.getIdLucrosCessantes() != null ? itemCobertura.getIdLucrosCessantes().getId() : null);
			itemCoberturaBlaze.setIdTipoCobertura(itemCobertura.getIdTipoCobertura());
			itemCoberturaBlaze.setIdExigeOficio(itemCobertura.getIdExigeOficio() != null ? itemCobertura.getIdExigeOficio().getId() : null);
			itemCoberturaBlaze.setCodigoRessegurador(itemCobertura.getCodigoRessegurador());
			itemCoberturaBlaze.setIdOficioRessegurador(itemCobertura.getIdOficioRessegurador());
			itemCoberturaBlaze.setDataEmissaoOficio(itemCobertura.getDataEmissaoOficio());
			itemCoberturaBlaze.setValorRiscoBem(itemCobertura.getValorRiscoBem() != null ? itemCobertura.getValorRiscoBem().doubleValue() : null);
			itemCoberturaBlaze.setValorRiscoBemMoedaEstrangeira(itemCobertura.getValorRiscoBemMoedaEstrangeira() != null ? itemCobertura.getValorRiscoBemMoedaEstrangeira().doubleValue() : null);

			Optional<ComissaoCotacao> optionalComissaoCotacao = 
					listComissaoCotacao.stream()
					.filter(comissao -> comissao.getCodigoGrupoRamo().equals(itemCobertura.getCodigoGrupoRamoEmissao()) && comissao.getCodigoRamo().equals(itemCobertura.getCodigoRamoCoberturaEmissao()))
					.findFirst();
			if(itemCobertura.getIdCoberturaAvulsa() !=  SimNaoEnum.SIM) {
				itemCoberturaBlaze.setPercentualComissao(optionalComissaoCotacao.isPresent() ? optionalComissaoCotacao.get().getPercentualComissao().doubleValue() : null);
			}
			itemCoberturaBlaze.setNumeroVagas(itemCobertura.getNumeroVagasGaragem());

			Optional<ItemCoberturaApolice> oica = listItemCoberturaApolice.stream().filter(cb->cb.getCodigoCobertura().equals(itemCobertura.getCodigoCobertura())).findFirst();
			ItemCoberturaApolice itemCoberturaApolice = oica.orElse(null);
			if(itemCoberturaApolice != null) {
				itemCoberturaBlaze.setItemCoberturaApolice(getItemCoberturaApolice(itemCoberturaApolice));
				if (itemCoberturaApolice.getListItemCobDescAgravApolice() != null){
					itemCoberturaBlaze.setListDescontoAgravacaoApolice(getItemDescontoAgravacaoApolice(itemCoberturaApolice.getListItemCobDescAgravApolice()));
				}
			} else {
				if(TipoSeguroEnum.RENOVACAO_TOKIO == itemCobertura.getItemCotacao().getIdTipoSeguro()) {
					itemCoberturaBlaze.setItemCoberturaApolice(getItemCoberturaApoliceZerada());
				} else {
					itemCoberturaBlaze.setItemCoberturaApolice(null);
				}
			}
			if(itemCoberturaBlaze.getItemCoberturaApolice() != null) {
				Optional<ComissaoCotacaoBlaze> optionalComissaoCotacaoApolice = listComissaoApolice.stream()
						.filter(comissao -> comissao.getCodigoGrupoRamo().equals(itemCobertura.getCodigoGrupoRamoEmissao()) && comissao.getCodigoRamo().equals(itemCobertura.getCodigoRamoCoberturaEmissao()))
						.findFirst();
				itemCoberturaBlaze.getItemCoberturaApolice().setPercentualComissao(optionalComissaoCotacaoApolice.isPresent() ? optionalComissaoCotacaoApolice.get().getPercentualComissao().doubleValue() : null);
			}
			
			listItemCoberturaBlaze.add(itemCoberturaBlaze);
		}
		return listItemCoberturaBlaze;
	}

	private ItemCoberturaApoliceBlaze getItemCoberturaApolice(ItemCoberturaApolice itemCoberturaApolice) {
		ItemCoberturaApoliceBlaze itemCoberturaApoliceBlaze = new ItemCoberturaApoliceBlaze();
		itemCoberturaApoliceBlaze.setCodigoCobertura(itemCoberturaApolice.getCodigoCobertura());
		itemCoberturaApoliceBlaze.setIdCoberturaAvulsa(itemCoberturaApolice.getIdCoberturaAvulsa() != null ? itemCoberturaApolice.getIdCoberturaAvulsa().getId() : null);
		itemCoberturaApoliceBlaze.setCodigoGrupoRamo(itemCoberturaApolice.getCodigoGrupoRamoEmissao());
		itemCoberturaApoliceBlaze.setCodigoRamoCobertura(itemCoberturaApolice.getCodigoRamoCoberturaEmissao());
		itemCoberturaApoliceBlaze.setValorImportanciaSegurada(itemCoberturaApolice.getValorIs() != null ? itemCoberturaApolice.getValorIs().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorSublimite(itemCoberturaApolice.getValorSubLimite() != null ? 
				itemCoberturaApolice.getValorSubLimite().doubleValue() : (itemCoberturaApolice.getValorIs() != null ? itemCoberturaApolice.getValorIs().doubleValue() : 0.0));
		itemCoberturaApoliceBlaze.setValorSublimiteOriginal(itemCoberturaApolice.getValorSubLimiteOriginal() != null ? itemCoberturaApolice.getValorSubLimiteOriginal().doubleValue() : null);
		itemCoberturaApoliceBlaze.setNumeroMultiploFranquia(itemCoberturaApolice.getNumeroMultiploFranquia() != null ? itemCoberturaApolice.getNumeroMultiploFranquia().doubleValue() : null);
		itemCoberturaApoliceBlaze.setNumeroMultiploPrejuizo(itemCoberturaApolice.getNumeroMultiploPrejuizo() != null ? itemCoberturaApolice.getNumeroMultiploPrejuizo().doubleValue() : null);
		itemCoberturaApoliceBlaze.setIdFormaFranquia(itemCoberturaApolice.getIdFormaFranquia() != null ? itemCoberturaApolice.getIdFormaFranquia().getId() : null);
		itemCoberturaApoliceBlaze.setNumeroHorasFranquia(itemCoberturaApolice.getNumeroHorasFranquia());
		itemCoberturaApoliceBlaze.setNumeroDiasFranquia(itemCoberturaApolice.getNumeroDiasFranquia());
		itemCoberturaApoliceBlaze.setTaxaFranquia(itemCoberturaApolice.getTaxaFranquia() != null ? itemCoberturaApolice.getTaxaFranquia().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorFranquia(itemCoberturaApolice.getValorFranquia() != null ? itemCoberturaApolice.getValorFranquia().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorFranquiaMinima(itemCoberturaApolice.getValorFranquiaMinima() != null ? itemCoberturaApolice.getValorFranquiaMinima().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorFranquiaMaxima(itemCoberturaApolice.getValorFranquiaMaxima() != null ? itemCoberturaApolice.getValorFranquiaMaxima().doubleValue() : null);
		itemCoberturaApoliceBlaze.setTaxaImportanciaSegurada(itemCoberturaApolice.getTaxaImportanciaSegurada() != null ? itemCoberturaApolice.getTaxaImportanciaSegurada().doubleValue() : null);
		itemCoberturaApoliceBlaze.setTaxaImportanciaSeguradaMinima(itemCoberturaApolice.getTaxaImportanciaSeguradaMinima() != null ? itemCoberturaApolice.getTaxaImportanciaSeguradaMinima().doubleValue() : null);
		itemCoberturaApoliceBlaze.setTaxaImportanciaSeguradaMaxima(itemCoberturaApolice.getTaxaImportanciaSeguradaMaxima() != null ? itemCoberturaApolice.getTaxaImportanciaSeguradaMaxima().doubleValue() : null);
		itemCoberturaApoliceBlaze.setIdTextoFranquia(itemCoberturaApolice.getIdTextoFranquia());
		itemCoberturaApoliceBlaze.setCodigoPeriodoIndenitario(itemCoberturaApolice.getCodigoPeriodoIndenitario());
		itemCoberturaApoliceBlaze.setIdLMR(itemCoberturaApolice.getIdLMR() != null ? itemCoberturaApolice.getIdLMR().getId() : null);
		itemCoberturaApoliceBlaze.setValorPremio(itemCoberturaApolice.getValorPremio() != null ? itemCoberturaApolice.getValorPremio().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorPremioVigencia(itemCoberturaApolice.getValorPremioVigencia() != null ? itemCoberturaApolice.getValorPremioVigencia().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorPremioNET(itemCoberturaApolice.getValorPremioNET() != null ? itemCoberturaApolice.getValorPremioNET().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorPremioReferencial(itemCoberturaApolice.getValorPremioReferencial() != null ? itemCoberturaApolice.getValorPremioReferencial().doubleValue() : null);
		//itemCoberturaApoliceBlaze.setValorPremioReferencial(itemCoberturaApolice.getValorPremioReferencial() != null ? itemCoberturaApolice.getValorPremioReferencial().doubleValue() : null);
		itemCoberturaApoliceBlaze.setPercentualPremioDepositoMinimo(itemCoberturaApolice.getPercentualPremioDepositoMinimo() != null ? itemCoberturaApolice.getPercentualPremioDepositoMinimo().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorISMoedaEstrangeira(itemCoberturaApolice.getValorIsMoedaEstrangeira() != null ? itemCoberturaApolice.getValorIsMoedaEstrangeira().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorPremioMoedaEstrangeira(itemCoberturaApolice.getValorPremioMoedaEstrangeira() != null ?itemCoberturaApolice.getValorPremioMoedaEstrangeira().doubleValue() : null);
		itemCoberturaApoliceBlaze.setPercentualTaxaCalculoPremio(itemCoberturaApolice.getPercentualTaxaCalculoPremio() != null ? itemCoberturaApolice.getPercentualTaxaCalculoPremio().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorSubLimiteMoedaEstrangeira(itemCoberturaApolice.getValorSubLimiteMoedaEstrangeira() != null ? itemCoberturaApolice.getValorSubLimiteMoedaEstrangeira().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorSubLimiteOriginalMoedaEstrangeira(itemCoberturaApolice.getValorSubLimiteOriginalMoedaEstrangeira() != null ? itemCoberturaApolice.getValorSubLimiteOriginalMoedaEstrangeira().doubleValue() : null);
		itemCoberturaApoliceBlaze.setIdDanosMateriais(itemCoberturaApolice.getIdDanosMateriais() != null ? itemCoberturaApolice.getIdDanosMateriais().getId() : null);
		itemCoberturaApoliceBlaze.setIdTipoCobertura(itemCoberturaApolice.getIdTipoCobertura());
		itemCoberturaApoliceBlaze.setIdExigeOficio(itemCoberturaApolice.getIdExigeOficio() != null ? itemCoberturaApolice.getIdExigeOficio().getId() : null);
		itemCoberturaApoliceBlaze.setCodigoRessegurador(itemCoberturaApolice.getCodigoRessegurador());
		itemCoberturaApoliceBlaze.setIdOficioRessegurador(itemCoberturaApolice.getIdOficioRessegurador());
		itemCoberturaApoliceBlaze.setDataEmissaoOficio(itemCoberturaApolice.getDataEmissaoOficio());
		itemCoberturaApoliceBlaze.setValorRiscoBem(itemCoberturaApolice.getValorRiscoBem() != null ? itemCoberturaApolice.getValorRiscoBem().doubleValue() : null);
		itemCoberturaApoliceBlaze.setValorRiscoBemMoedaEstrangeira(itemCoberturaApolice.getValorRiscoBemMoedaEstrangeira() != null ? itemCoberturaApolice.getValorRiscoBemMoedaEstrangeira().doubleValue() : null);
		return itemCoberturaApoliceBlaze;
	}
	
	private ItemCoberturaApoliceBlaze getItemCoberturaApoliceZerada() {
		ItemCoberturaApoliceBlaze itemCoberturaApoliceBlaze = new ItemCoberturaApoliceBlaze();
		itemCoberturaApoliceBlaze.setCodigoCobertura(0);
		itemCoberturaApoliceBlaze.setValorImportanciaSegurada(0.0);
		itemCoberturaApoliceBlaze.setValorSublimite(0.0);
		itemCoberturaApoliceBlaze.setValorSublimiteOriginal(0.0);
		itemCoberturaApoliceBlaze.setNumeroMultiploFranquia(0.0);
		itemCoberturaApoliceBlaze.setNumeroMultiploPrejuizo(0.0);
		itemCoberturaApoliceBlaze.setIdFormaFranquia(null);
		itemCoberturaApoliceBlaze.setNumeroHorasFranquia(null);
		itemCoberturaApoliceBlaze.setNumeroDiasFranquia(null);
		itemCoberturaApoliceBlaze.setTaxaFranquia(null);
		itemCoberturaApoliceBlaze.setValorFranquia(null);
		itemCoberturaApoliceBlaze.setValorFranquiaMinima(null);
		itemCoberturaApoliceBlaze.setValorFranquiaMaxima(null);
		itemCoberturaApoliceBlaze.setTaxaImportanciaSegurada(null);
		itemCoberturaApoliceBlaze.setTaxaImportanciaSeguradaMinima(null);
		itemCoberturaApoliceBlaze.setTaxaImportanciaSeguradaMaxima(null);
		itemCoberturaApoliceBlaze.setIdTextoFranquia(null);
		itemCoberturaApoliceBlaze.setCodigoPeriodoIndenitario(null);
		itemCoberturaApoliceBlaze.setIdLMR( null);
		itemCoberturaApoliceBlaze.setValorPremio(0.0);
		itemCoberturaApoliceBlaze.setValorPremioVigencia(0.0);
		itemCoberturaApoliceBlaze.setValorPremioNET(0.0);
		itemCoberturaApoliceBlaze.setValorPremioReferencial(0.0);
		//itemCoberturaApoliceBlaze.setValorPremioReferencial(itemCoberturaApolice.getValorPremioReferencial() != null ? itemCoberturaApolice.getValorPremioReferencial().doubleValue() : null);
		itemCoberturaApoliceBlaze.setPercentualPremioDepositoMinimo(0.0);
		itemCoberturaApoliceBlaze.setValorISMoedaEstrangeira(0.0);
		itemCoberturaApoliceBlaze.setValorPremioMoedaEstrangeira(0.0);
		itemCoberturaApoliceBlaze.setPercentualTaxaCalculoPremio(null);
		itemCoberturaApoliceBlaze.setValorSubLimiteMoedaEstrangeira(0.0);
		itemCoberturaApoliceBlaze.setValorSubLimiteOriginalMoedaEstrangeira(0.0);
		itemCoberturaApoliceBlaze.setIdDanosMateriais(null);
		itemCoberturaApoliceBlaze.setIdTipoCobertura(null);
		itemCoberturaApoliceBlaze.setIdExigeOficio(null);
		itemCoberturaApoliceBlaze.setCodigoRessegurador(null);
		itemCoberturaApoliceBlaze.setIdOficioRessegurador(null);
		itemCoberturaApoliceBlaze.setDataEmissaoOficio(null);
		itemCoberturaApoliceBlaze.setValorRiscoBem(0.0);
		itemCoberturaApoliceBlaze.setValorRiscoBemMoedaEstrangeira(0.0);
		return itemCoberturaApoliceBlaze;
	}
	
	public List<DescontoAgravacaoBlaze> getItemDescontoAgravacaoApolice(List<ItemCobDescAgravApolice> listItemCobDescAgravApolice) {
		List<DescontoAgravacaoBlaze> listItemCobDescAgravApoliceBlaze = new ArrayList<>(); 
		for (ItemCobDescAgravApolice itemCobDescAgravApolice :listItemCobDescAgravApolice){
			DescontoAgravacaoBlaze itemCobDescAgravBlaze = new DescontoAgravacaoBlaze();
			itemCobDescAgravBlaze.setCodigoCobertura(itemCobDescAgravApolice.getCodigoCobertura());
			itemCobDescAgravBlaze.setDescricaoDescontoAgravacao(itemCobDescAgravApolice.getDescricaoDescontoAgravacao());
			itemCobDescAgravBlaze.setPercentualDescontoAgravacao(itemCobDescAgravApolice.getPercentualDescontoAgravacao() != null ? itemCobDescAgravApolice.getPercentualDescontoAgravacao().doubleValue() : null);
			listItemCobDescAgravApoliceBlaze.add(itemCobDescAgravBlaze);
		}
		return listItemCobDescAgravApoliceBlaze;
	}

	public List<ComissaoCotacaoBlaze> createListComissaoCotacaoMapper(Set<ComissaoCotacao> listComissaoCotacao) {
		List<ComissaoCotacaoBlaze> listComissaoCotacaoBlaze = new ArrayList<>();
		for (ComissaoCotacao comissaoCotacao : listComissaoCotacao) {
			ComissaoCotacaoBlaze comissaoCotacaoBlaze = new ComissaoCotacaoBlaze();
			comissaoCotacaoBlaze.setSequencialComissaoCotacao(comissaoCotacao.getSequencialComissaoCotacao() != null ? comissaoCotacao.getSequencialComissaoCotacao().longValue() : null);
			comissaoCotacaoBlaze.setCodigoGrupoRamo(comissaoCotacao.getCodigoGrupoRamo());
			comissaoCotacaoBlaze.setCodigoRamo(comissaoCotacao.getCodigoRamo());
			comissaoCotacaoBlaze.setPercentualComissao(comissaoCotacao.getPercentualComissao() != null ? comissaoCotacao.getPercentualComissao().doubleValue() : null);
			listComissaoCotacaoBlaze.add(comissaoCotacaoBlaze);
		}
		return listComissaoCotacaoBlaze;
	}
	
	public List<ComissaoCotacaoBlaze> createListComissaoApoliceMapper(List<ComissaoApolice> listComissaoApolice) {
		List<ComissaoCotacaoBlaze> listComissaoCotacaoBlaze = new ArrayList<>();
		for (ComissaoApolice comissaoApolice : listComissaoApolice) {
			ComissaoCotacaoBlaze comissaoCotacaoBlaze = new ComissaoCotacaoBlaze();
			comissaoCotacaoBlaze.setCodigoGrupoRamo(comissaoApolice.getCodigoGrupoRamoEmissao());
			comissaoCotacaoBlaze.setCodigoRamo(comissaoApolice.getCodigoRamoEmissao());
			comissaoCotacaoBlaze.setPercentualComissao(comissaoApolice.getPercentualComissao() != null ? comissaoApolice.getPercentualComissao().doubleValue() : null);
			listComissaoCotacaoBlaze.add(comissaoCotacaoBlaze);
		}
		return listComissaoCotacaoBlaze;
	}	

}
