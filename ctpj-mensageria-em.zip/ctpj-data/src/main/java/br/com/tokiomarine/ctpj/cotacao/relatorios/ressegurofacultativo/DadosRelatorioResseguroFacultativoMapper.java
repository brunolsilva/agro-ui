package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.tokiomarine.ctpj.cotacao.dto.DadosCotacaoParaResseguroFacultativo;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativoCessao;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativoFaixa;
import br.com.tokiomarine.ctpj.infra.mongo.repository.BrokerRepository;

@Mapper(componentModel = "spring")
public abstract class DadosRelatorioResseguroFacultativoMapper {
	
	@Autowired
	private BrokerRepository brokerRepository;
	
	@Mapping(source = "dadosCotacao.apolice", target="apolice")
	@Mapping(source = "ressegFacul.descricaoBrokerAdicional", target="brokerAdicional")
	@Mapping(target="broker", ignore = true)
	@Mapping(source = "dadosCotacao.tipoCosseguro", target="cosseguro")
	@Mapping(source = "ressegFacul.dataPreenchimento", target="data")
	@Mapping(source = "dadosCotacao.fimVigencia", target="fimVigencia")
	@Mapping(source = "dadosCotacao.inicioVigencia", target="inicioVigencia")
	@Mapping(source = "dadosCotacao.moeda", target="moeda")
	@Mapping(source = "ressegFacul.numeroParcelasResseguro", target="nroParcelasResseguro")
	@Mapping(source = "ressegFacul.numeroParcelasSeguro", target="nroParcelasSeguro")
	@Mapping(source = "dadosCotacao.percentualCosseguro", target="porcentagemCosseguro")
	@Mapping(source = "ressegFacul.percentualUtilizacaoContratoAutomatico", target="porcentagemUtilizacaoContratoAutomatico")
	@Mapping(source = "ressegFacul.percentualUtilizadoLimiteTecnico", target="porcentagemUtilizadoLimiteTecnico")
	@Mapping(source = "dadosCotacao.premioSeguro", target="premioSeguro")
	@Mapping(source = "dadosCotacao.ramo", target="ramo")
	@Mapping(source = "ressegFacul.reintegracaoAutomatica.logical", target="reintegracaoAutomaticaNaAP")
	@Mapping(source = "dadosCotacao.segurado", target="segurado")
	@Mapping(source = "ressegFacul.cotacao.sequencialCotacaoProposta", target="seqCotacao")
	@Mapping(source = "dadosCotacao.subscritor", target="subscritor")
	@Mapping(source = "ressegFacul.idCessao", target="idCessao") 
	@Mapping(source = "dadosCotacao.valorLmrLmg", target="valorLmrLmg")
	@Mapping(target = "cessoes", ignore = true)
	@Mapping(target = "resseguradoresOuLloyds", ignore = true)
	@Mapping(source="ressegFacul.descricaoSecurity", target="security")
	public abstract DadosRelatorioResseguroFacultativo toDadosRelatorio(ResseguroFacultativo ressegFacul, DadosCotacaoParaResseguroFacultativo dadosCotacao); 
	
	@AfterMapping
	protected void setBroker(@MappingTarget DadosRelatorioResseguroFacultativo dadosRelatorio, ResseguroFacultativo ressegFacul){
		brokerRepository.findByCodigo(ressegFacul.getCodigoBroker().longValue()).ifPresent(broker -> {
			dadosRelatorio.setBroker(broker.getNome());
			dadosRelatorio.setSecurity(broker.getSecurity());
			}
		);			
		
	}
	
	@AfterMapping
	public void setFaixas(@MappingTarget DadosRelatorioResseguroFacultativo dadosRelatorio, ResseguroFacultativo ressegFacul){
		dadosRelatorio.setCessoes(new ArrayList<DadosRelatorioCessao>());
		
		List<DadosRelatorioCessao> cessoes = ressegFacul
		.getRessegurosFacultativosCessao()
		.stream()
		.map(cessao -> toDadosRelatorioCessao(cessao))
		.collect(Collectors.toList());
		
		dadosRelatorio.setCessoes(cessoes);
	}
	
	@AfterMapping
	public void setDistribuicoes(@MappingTarget DadosRelatorioResseguroFacultativo dadosRelatorio, ResseguroFacultativo ressegFacul){
		List<DadosDistribRessegLloyds> dados = ressegFacul.getRessegurosFacultativosCessao()
		.stream()
		.map(cessao -> {
				return cessao
						.getFaixas()
						.stream()
						.map(faixa -> toDadosDistribRessegLloyds(faixa, cessao.getNumeroItemFaixa()))
						.collect(Collectors.toList());
			}
		)
		.reduce(new ArrayList<DadosDistribRessegLloyds>(), 
					(a, b) -> {
						a.addAll(b); 
						return a;
					}
				);
		
		
		dadosRelatorio.setResseguradoresOuLloyds(dados);
	}

	private DadosRelatorioCessao toDadosRelatorioCessao(ResseguroFacultativoCessao rfc){
		DadosRelatorioCessao dados = new DadosRelatorioCessao();
		dados.setFaixa(rfc.getNumeroItemFaixa());
		dados.setValorInicial(rfc.getValorInicial());
		dados.setValorFinal(rfc.getValorFinal());
		dados.setPercentualCedidoEmResseguro(rfc.getPercentualCedido());
		dados.setPercentualRetidoEmResseguro(rfc.getPercentualRetido());
		
		return dados;
	}
	
	private DadosDistribRessegLloyds toDadosDistribRessegLloyds(ResseguroFacultativoFaixa rff, Integer cessao){
		DadosDistribRessegLloyds dados = new DadosDistribRessegLloyds();
		dados.setFaixa(cessao);
		dados.setCodigoSusep(BigInteger.valueOf(rff.getCodigoRessegurador()));
		dados.setNome(rff.getDescricaoRessegurador());
		dados.setPremioDeResseguro(rff.getValorPremioRessegurador());
		dados.setPorcentagemDeParticipacao(rff.getPercentualParticipacao());
		dados.setPorcentagemComissaoResseguro(rff.getPercentualComissaoRessegurador());			
		dados.setPremioPorRessegurador(rff.getPremioPorRessegurador());
		dados.setPremioLiquidoPorRessegurador(rff.getPremioLiquidoPorRessegurador());
		
		
		return dados;
	}

}
