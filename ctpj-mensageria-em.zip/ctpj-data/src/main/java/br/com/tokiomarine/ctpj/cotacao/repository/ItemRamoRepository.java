package br.com.tokiomarine.ctpj.cotacao.repository;

import static org.hibernate.criterion.Restrictions.eq;
import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamo;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class ItemRamoRepository extends BaseDAO {

	private static final String FIND_ITEM_RAMO_EMISSAO_BY_ITEM_COTACAO_HQL = 
			"select ir " +
			"from ItemCotacao ic " +
			"join ic.listItemRamoEmissao ir " +
			"where ic.sequencialItemCotacao = :sequencialItemCotacao";	
	
	@SuppressWarnings("unchecked")
	public List<Object[]> findGrupoRamoRamoEmissao(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select distinct ir.codigoGrupoRamo, ir.codigoRamo ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemRamoEmissao ir ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemRamoEmissao> findByItemCotacao(BigInteger seqItemCotacao){
		Query query = getCurrentSession().createQuery(FIND_ITEM_RAMO_EMISSAO_BY_ITEM_COTACAO_HQL);
		query.setParameter("sequencialItemCotacao", seqItemCotacao);
		
		return (List<ItemRamoEmissao>)query.list();
	}	
	
	public List<ItemRamoEmissao> findByItemCotacao(ItemCotacao itemCotacao){
		return findByItemCotacao(itemCotacao.getSequencialItemCotacao());
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemRamo> findNaoExcluidoDoEndossoByCotacao(BigInteger numeroCotacaoProposta, Integer versaoCotacaoProposta){
		List<ItemRamo> itens = getCurrentSession()
		.createCriteria(ItemRamo.class)
		.add(eq("numeroCotacaoProposta", numeroCotacaoProposta))
		.add(eq("versaoCotacaoProposta", versaoCotacaoProposta))
		.add(eq("idExclusaoEndosso", SimNaoEnum.NAO))
		.list();
		
		return itens;
	}

	public void saveListItemRamoContabil(List<ItemRamo> listItemRamoContabil) {
		for (ItemRamo itemRamo : listItemRamoContabil) {
			getCurrentSession().save(itemRamo);
		}
	}

	public void saveListItemRamoEmissao(List<ItemRamoEmissao> listaItemRamoEmissao) {
		for (ItemRamoEmissao itemRamoEmissao : listaItemRamoEmissao) {
			getCurrentSession().save(itemRamoEmissao);
		}
	}

	public void deleteItemsRamoEmissao(ItemCotacao itemCotacao) {
		for (ItemRamoEmissao itemRamoEmissao : itemCotacao.getListItemRamoEmissao()) {
			getCurrentSession().delete(itemRamoEmissao);
		}

		itemCotacao.getListItemRamoEmissao().clear();
		getCurrentSession().flush();
	}

	public void deleteItemsRamo(ItemCotacao itemCotacao) {
		for (ItemRamo itemRamo : itemCotacao.getListItemRamo()) {
			getCurrentSession().delete(itemRamo);
		}

		itemCotacao.getListItemRamo().clear();
		getCurrentSession().flush();
	}
}