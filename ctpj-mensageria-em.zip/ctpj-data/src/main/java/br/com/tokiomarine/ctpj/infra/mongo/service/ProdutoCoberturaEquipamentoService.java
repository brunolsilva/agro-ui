package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaFranquiaView;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCoberturaEquipamento;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoCoberturaEquipamentoRepository;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class ProdutoCoberturaEquipamentoService {
		
	private static Logger logger = LogManager.getLogger(ResseguradorService.class);

	
	@Autowired
	private ProdutoCoberturaEquipamentoRepository repository;
	

	public List<ProdutoCoberturaEquipamento> findCoberturasPermiteFranquiaEquipamento(ItemCotacao itemCotacao, ItemCoberturaFranquiaView itemCobertura) throws ServiceException {
		try {
			return repository.findEquipamentoByProdutoCobertura(itemCotacao, itemCobertura);
		} catch (RepositoryException e) {
			logger.error("Erro na Busca do ProdutoCoberturaEquipamento",e);
			throw new ServiceException("Erro na Busca do ProdutoCoberturaEquipamento",e);
		}
	}

}
