package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.JurosParcelamentoCotacao;

@Repository
public class JurosParcelamentoCotacaoRepository extends BaseDAO {

	@SuppressWarnings("unchecked")
	@LogPerformance
	public JurosParcelamentoCotacao findBySequencialCotacaoProdutoParcelamento(BigInteger sequencialCotacaoProposta,Integer codigoFormaParcelamento) {

		Query query = getCurrentSession().createQuery(
				"select j from JurosParcelamentoCotacao j "
						+ "where j.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta "
						+ "and j.codigoFormaParcelamento = :codigoFormaParcelamento "
						);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		query.setParameter("codigoFormaParcelamento", codigoFormaParcelamento);
		return (JurosParcelamentoCotacao) query.uniqueResult();
	}


	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<JurosParcelamentoCotacao> findBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {

		Query query = getCurrentSession().createQuery(
				"select a from JurosParcelamentoCotacao a "
				+"where a.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);

		return (List<JurosParcelamentoCotacao>) query.list();
	}

	@LogPerformance
	public void saveList(List<JurosParcelamentoCotacao> lista) {
		for (JurosParcelamentoCotacao jurosParcelamentoCotacao : lista) {
			getCurrentSession().persist(jurosParcelamentoCotacao);
		}
	}

	@LogPerformance
	public void delete(BigInteger sequencialCotacaoProposta) {
		List<JurosParcelamentoCotacao> listJurosParcelamentoCotacao = list(sequencialCotacaoProposta);
		List<BigInteger> ids = listJurosParcelamentoCotacao.stream().map(JurosParcelamentoCotacao::getSequencialJurosParcelamentoCotacao).collect(Collectors.toList());
		if(ids != null && !ids.isEmpty()) {
			Query query = getCurrentSession().createQuery("delete from JurosParcelamentoCotacao op where op.sequencialJurosParcelamentoCotacao in (:ids)");
			query.setParameterList("ids",ids);
			query.executeUpdate();
		}

//		for(JurosParcelamentoCotacao jpc: listJurosParcelamentoCotacao) {
//			getCurrentSession().delete(jpc);
//		}
//
//		getCurrentSession().flush();
	}
	
	@LogPerformance
	public void delete(List<BigInteger> ids) {
		List<JurosParcelamentoCotacao> listJurosParcelamentoCotacao = new ArrayList<>();
		if(ids != null && !ids.isEmpty()) {
			listJurosParcelamentoCotacao = listJuros(ids);
		}

		for(JurosParcelamentoCotacao jpc: listJurosParcelamentoCotacao) {
			getCurrentSession().delete(jpc);
		}

		getCurrentSession().flush();
	}
	
	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<JurosParcelamentoCotacao> list(BigInteger sequencialCotacaoProposta) {
		return (List<JurosParcelamentoCotacao>) getCurrentSession()
				.createQuery("select jpc from JurosParcelamentoCotacao jpc where jpc.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta")
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.list();
	}
	
	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<JurosParcelamentoCotacao> listJuros(List<BigInteger> ids) {
		return (List<JurosParcelamentoCotacao>) getCurrentSession()
				.createQuery("select jpc from JurosParcelamentoCotacao jpc where jpc.sequencialJurosParcelamentoCotacao in (:ids)")
				.setParameterList("ids", ids)
				.list();
	}
	
	@LogPerformance
	public JurosParcelamentoCotacao findBySequencialJurosParcelamentoCotacao(BigInteger sequencialJurosParcelamentoCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append("select jpc from JurosParcelamentoCotacao jpc");
		hql.append(" where jpc.sequencialJurosParcelamentoCotacao = :sequencialJurosParcelamentoCotacao");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialJurosParcelamentoCotacao",sequencialJurosParcelamentoCotacao);

		return (JurosParcelamentoCotacao) query.uniqueResult();
	}

	public void update(JurosParcelamentoCotacao jurosParcelamentoCotacao) {
		super.getCurrentSession().update(jurosParcelamentoCotacao);
	}

}
