package br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Responsável por formatar valores Monetários (BigDecimal)
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class FormatadorMonetarioRelatorio {
	
	private static final NumberFormat MONEY_FORMATTER = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));//new DecimalFormat("#,###,##0.00");
	
	/**
	 * Formata um valor como monetário
	 * 
	 * @param value Valor a ser formatado
	 * @param replace Será utilizado para os casos do valor ser igual a null
	 * @return Valor formatado como monetário
	 */
	public String asMoney(BigDecimal value, String replace){
		return value == null ? replace : MONEY_FORMATTER.format(value);
	}
	
	/**
	 * Formata um valor como monetário
	 * 
	 * @param value Valor a ser formatado
	 * @return O valor formatado como monetário ou uma String vazia ("") para os casos do valor ser Null
	 */
	public String asMoney(BigDecimal value){
		return asMoney(value, "");
	}
	
	
}
