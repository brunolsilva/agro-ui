package br.com.tokiomarine.ctpj.config;

import javax.servlet.ServletContext;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;

/**
 * Classe que possui conhecimento dos contextos da Aplicação Web
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Component
public class WebApplicationAware implements ServletContextAware, ApplicationContextAware {

	private ServletContext servletContext;
	private ApplicationContext applicationContext;
	
	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
		
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

}
