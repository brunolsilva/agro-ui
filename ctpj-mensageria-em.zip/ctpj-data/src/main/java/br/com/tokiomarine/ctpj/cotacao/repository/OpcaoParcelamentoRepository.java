package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoPagamentoView;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Repository
public class OpcaoParcelamentoRepository extends BaseDAO {

	@LogPerformance
	public Date findDtMaxAlteracaoItem(BigInteger sequencialCotacaoProposta) {

		Query query = getCurrentSession().createSQLQuery("select max(dt_alter) " + "from ctp0111_item_cotac " + "where sq_cotac_ppota = :sequencialCotacaoProposta " );
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (Date) query.uniqueResult();
	}

	@LogPerformance
	public Date findDtAlteracaoInicioVigenciaPedido(BigInteger sequencialCotacaoProposta) {

		Query query = getCurrentSession().createSQLQuery("select nvl(dt_alter,dt_inico_vigen) " + "from ctp0100_cotac_ppota " + "where sq_cotac_ppota = :sequencialCotacaoProposta");
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (Date) query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<Object[]> findGrupoRamoRamo(BigInteger sequencialCotacaoProposta) {

		StringBuilder hql = new StringBuilder();
		hql.append(" select distinct cobertura.codigoGrupoRamoEmissao, cobertura.codigoRamoCoberturaEmissao ");
		hql.append(" from  	Cotacao cotacao ");
		hql.append("	    inner join cotacao.listItem item ");
		hql.append("     	inner join item.listItemCobertura cobertura ");
		hql.append(" where cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		hql.append(" and   cotacao.sequencialCotacaoProposta = item.cotacao.sequencialCotacaoProposta ");
		hql.append(" and   cobertura.itemCotacao.sequencialItemCotacao  = item.sequencialItemCotacao");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (List<Object[]>) query.list();
	}

	@LogPerformance
	public void saveList(List<OpcaoParcelamento> listaOpcaoParcelamentoPagamentoCotacao) {
		for (OpcaoParcelamento opcaoParcelamento : listaOpcaoParcelamentoPagamentoCotacao) {
			getCurrentSession().save(opcaoParcelamento);
		}
		getCurrentSession().flush();
	}
	
	@LogPerformance
	public void update(OpcaoParcelamento opcaoParcelamento) {
		getCurrentSession().update(opcaoParcelamento);
	}

	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<OpcaoParcelamento> list(BigInteger codigoCotacao) {
		Criteria criteria = getCurrentSession().createCriteria(OpcaoParcelamento.class);
		if(SecurityUtils.isCorretor()) {
			criteria.add(Restrictions.eq("idImpressao", SimNaoEnum.SIM));
		}
		criteria.add(Restrictions.eq("cotacao.sequencialCotacaoProposta", codigoCotacao));
		criteria.addOrder(Order.asc("quantidadeParcelas"));

		return (List<OpcaoParcelamento>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<Object[]> findFormasPagamento(BigInteger sequencialCotacaoProposta) {
		return (List<Object[]>) getCurrentSession()
				.createQuery("select distinct op.codigoFormaPagamento,op.descricaoFormaPagamento from OpcaoParcelamento op where op.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta")
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.list();
	}

	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<OpcaoParcelamento> findFormasParcelamento(BigInteger sequencialCotacaoProposta,int codigoFormaPagamento) {
		return (List<OpcaoParcelamento>) getCurrentSession().createQuery(
				"select op from OpcaoParcelamento op " + 
				" where op.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta and op.codigoFormaPagamento = :codigoFormaPagamento order by op.codigoFormaParcelamento")
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.setParameter("codigoFormaPagamento",codigoFormaPagamento)
				.list();
	}

	@LogPerformance
	public Date findMinDataTermino(BigInteger sequencialCotacaoProposta) {
		Query query = getCurrentSession().createSQLQuery("select min(dt_fim_vigen) " + "from ctp0111_item_cotac " + "where sq_cotac_ppota = :sequencialCotacaoProposta ");
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (Date) query.uniqueResult();

	}

	@LogPerformance
	public OpcaoParcelamento findOpcaoParcelamentoPagamentoEscolhida(BigInteger sequencialCotacaoProposta) {
		StringBuilder query = new StringBuilder();
		query.append("select op from OpcaoParcelamento op ");
		query.append("where op.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		query.append("and op.idParcelamentoEscolhido = :idParcelamentoEscolhida");
		return (OpcaoParcelamento) getCurrentSession()
				.createQuery(query.toString())
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.setParameter("idParcelamentoEscolhida",SimNaoEnum.SIM).uniqueResult();
	}

	@LogPerformance
	public OpcaoParcelamento getOpcaoParcelamentoEntradaBoleto(BigInteger sequencialCotacaoProposta) throws HibernateException {		
		StringBuilder hql = new StringBuilder();
		hql.append(" select	o ");
		hql.append(" from	OpcaoParcelamento o  ");
		hql.append(" where	o.idParcelamentoEscolhido = :idParcelamentoEscolhido ");
		hql.append(" and	o.codigoFormaPagamento = :codigoFormaPagamento ");
		hql.append(" and	o.idEntrada = :idEntrada ");
		hql.append(" and	o.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");

		Query query = this.getCurrentSession().createQuery(hql.toString()).setParameter("idParcelamentoEscolhido",SimNaoEnum.SIM)
																		  .setParameter("codigoFormaPagamento",FormaPagamentoEnum.CARNE.getCodigo())
																		  .setParameter("idEntrada",SimNaoEnum.SIM)
																		  .setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		//query.setParameter("parcelamentoEscolhido", SimNaoEnum.SIM);
		return (OpcaoParcelamento) query.uniqueResult();

	}

	@LogPerformance
	public void delete(BigInteger cotacao) {
		List<OpcaoParcelamento> opcoesParcelamento = list(cotacao);
//		for(OpcaoParcelamento op: opcoesParcelamento) {
//			getCurrentSession().delete(op);
//		}
		List<BigInteger> ids = opcoesParcelamento.stream().map(OpcaoParcelamento::getSequencialOpcaoParcelamento).collect(Collectors.toList());

		if(ids != null && !ids.isEmpty()) {
			Query query = getCurrentSession().createQuery("delete from OpcaoParcelamento op where op.sequencialOpcaoParcelamento in (:ids)");
			query.setParameterList("ids",ids);
			query.executeUpdate();
		}
		//getCurrentSession().flush();
	}
	
	@LogPerformance
	public void delete(OpcaoParcelamento op) {
		int index = -1;
		for(int i = 0; i < op.getCotacao().getListOpcaoParcelamento().size(); i++) {
			if(op.getSequencialOpcaoParcelamento().equals(op.getCotacao().getListOpcaoParcelamento().get(i).getSequencialOpcaoParcelamento())) {
				index = i;
				break;
			}
		}
		if(index != -1) {
			op.getCotacao().getListOpcaoParcelamento().remove(index);
		}

		getCurrentSession().delete(op);
		getCurrentSession().flush();
	}

	@LogPerformance
	public CotacaoPagamentoView findOpcaoParcelamentoSelecionada(Cotacao cotacao) {
		StringBuilder hql = new StringBuilder();
		
		hql.append("	select	 ");
		hql.append(" 		o.descricaoFormaPagamento as formaPagamento, ");
		hql.append(" 		o.valorPrimeiraParcela as entrada, ");
		hql.append(" 		o.valorDemaisParcela as demais, ");
		hql.append(" 		o.valorPremioTotal as total, ");
		hql.append(" 		o.descricaoFormaParcelamento as plano ");
		hql.append("	from	OpcaoParcelamento o  ");
		hql.append("	where	o.idParcelamentoEscolhido = :parcelamentoEscolhido");
		hql.append("	and		o.cotacao.sequencialCotacaoProposta = :cotacao");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao", cotacao.getSequencialCotacaoProposta());
		query.setParameter("parcelamentoEscolhido", SimNaoEnum.SIM);
		query.setResultTransformer(Transformers.aliasToBean(CotacaoPagamentoView.class));

		return (CotacaoPagamentoView) query.uniqueResult();
	}

	@LogPerformance
	public OpcaoParcelamento findOpcaoParcelamentoSelecionada(BigInteger cotacao) {
		StringBuilder hql = new StringBuilder();

		hql.append("	select	 o");
		hql.append("	from	OpcaoParcelamento o  ");
		hql.append("	where	o.idParcelamentoEscolhido = :parcelamentoEscolhido");
		hql.append("	and		o.cotacao.sequencialCotacaoProposta = :cotacao");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao", cotacao);
		query.setParameter("parcelamentoEscolhido", SimNaoEnum.SIM);

		return (OpcaoParcelamento) query.uniqueResult();
	}
	
	@LogPerformance
	public OpcaoParcelamento findOpcaoParcelamentoById(BigInteger sequencialOpcaoParcelamento)
	{
		StringBuilder hql = new StringBuilder();
		hql.append(" select o from OpcaoParcelamento o ");
		hql.append(" where  o.sequencialOpcaoParcelamento = :opcao ");
		
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("opcao", sequencialOpcaoParcelamento);
		
		return (OpcaoParcelamento) query.uniqueResult();
	}

	@LogPerformance
	public List<Validacao> salvar(List<CotacaoPagamentoView> pagamento, OpcaoParcelamento opcaoParcelamento, Recebimento recebimento) throws RepositoryException {
		
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		StringBuilder hql = new StringBuilder();
		hql.append(" select o from OpcaoParcelamento o ");
		hql.append(" where  o.cotacao.sequencialCotacaoProposta = :cotacao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao", pagamento.get(0).getCotacao());
		List<OpcaoParcelamento> opcoes = (List<OpcaoParcelamento>) query.list();

		for (OpcaoParcelamento op : opcoes) {
			op.setIdParcelamentoEscolhido(SimNaoEnum.NAO);
			if(!SecurityUtils.isCorretor()) {
				for(CotacaoPagamentoView cpv: pagamento) {
					if(op.getSequencialOpcaoParcelamento().equals(cpv.getSqOpcao())) {
						op.setIdImpressao(SimNaoEnum.getById(cpv.getIdImpressao()) != null ? SimNaoEnum.getById(cpv.getIdImpressao()): SimNaoEnum.NAO);
						op.setIdParcelamentoEscolhido(opcaoParcelamento != null && cpv.getSqOpcao().equals(opcaoParcelamento.getSequencialOpcaoParcelamento()) ? SimNaoEnum.SIM : SimNaoEnum.NAO);
						if (opcaoParcelamento != null && cpv.getSqOpcao().equals(opcaoParcelamento.getSequencialOpcaoParcelamento()) && recebimento != null && recebimento.getDataProcessoCobranca() != null) {
							op.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
						} else {
							op.setDataVencimentoParcela(null);
						}
					}
				}
			} else {
				for(CotacaoPagamentoView cpv: pagamento) {
					if(op.getSequencialOpcaoParcelamento().equals(cpv.getSqOpcao())) {
						op.setIdParcelamentoEscolhido(opcaoParcelamento != null && cpv.getSqOpcao().equals(opcaoParcelamento.getSequencialOpcaoParcelamento()) ? SimNaoEnum.SIM : SimNaoEnum.NAO);
					}
				}
			}
			//op.setIdParcelamentoEscolhido(SimNaoEnum.NAO);
			op.setDataAtualizacao(new Date());
			op.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			op.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			getCurrentSession().save(op);
		}

		return Collections.emptyList();
	}
	
	@SuppressWarnings("unchecked")
	@LogPerformance
	public List<OpcaoParcelamento> findOpcoesParcelamento(BigInteger sequencialCotacaoProposta) {
		StringBuilder query = new StringBuilder();
		query.append("select op from OpcaoParcelamento op ");
		query.append("where op.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		return (List<OpcaoParcelamento>) getCurrentSession()
				.createQuery(query.toString())
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta).list();
	}
	
	
	@LogPerformance
	public OpcaoParcelamento findOpcaoParcelamentoByTipoPagtoAndTipoParcl(BigInteger cotacao, Integer codigoFormaPagamento, Integer codigoFormaParcelamento) {
		StringBuilder hql = new StringBuilder();

		hql.append("	select	 o");
		hql.append("	from	OpcaoParcelamento o  ");
		hql.append("	where	o.cotacao.sequencialCotacaoProposta = :cotacao");
		hql.append("	and		o.codigoFormaPagamento 		= :codigoFormaPagamento");
		hql.append("	and		o.codigoFormaParcelamento 	= :codigoFormaParcelamento");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao", cotacao);
		query.setParameter("codigoFormaPagamento", codigoFormaPagamento);
		query.setParameter("codigoFormaParcelamento", codigoFormaParcelamento);

		return (OpcaoParcelamento) query.uniqueResult();
	}

	@LogPerformance
	public void salvar(BigInteger sequencialCotacaoPropota, OpcaoParcelamento opcaoParcelamento) throws RepositoryException {
		
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if(opcaoParcelamento != null) {
			
			StringBuilder hql = new StringBuilder();
			hql.append(" select o from OpcaoParcelamento o ");
			hql.append(" where  o.cotacao.sequencialCotacaoProposta = :cotacao ");
			hql.append(" and 	o.idParcelamentoEscolhido = :sim ");

			Query query = getCurrentSession().createQuery(hql.toString());
			query.setParameter("cotacao", sequencialCotacaoPropota);
			query.setParameter("sim", SimNaoEnum.SIM);
			List<OpcaoParcelamento> opcoes = (List<OpcaoParcelamento>) query.list();

			for (OpcaoParcelamento op : opcoes) {
				op.setIdParcelamentoEscolhido(SimNaoEnum.NAO);
				op.setDataAtualizacao(new Date());
				op.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				op.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				getCurrentSession().save(op);
			}
			
			opcaoParcelamento.setIdParcelamentoEscolhido(SimNaoEnum.SIM);
			opcaoParcelamento.setDataAtualizacao(new Date());
			opcaoParcelamento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			opcaoParcelamento.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			getCurrentSession().save(opcaoParcelamento);
		}
	}
}