package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.infra.domain.CoberturaAtividadeComplemento;

@Repository
public class CoberturaAtividadeComplementoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@LogPerformance
	public String findByProdutoAndCoberturaAndAtividade(Integer produto, Integer cobertura, Long atividade) {
		CoberturaAtividadeComplemento coberturaAtividadeComplemento = mongoTemplate.findOne(query(
				where("produto").is(produto)
				.and("cobertura").is(cobertura)
				.and("atividade").is(atividade)), CoberturaAtividadeComplemento.class);
		if (coberturaAtividadeComplemento == null)
			return "";
		return coberturaAtividadeComplemento.getTextoComplemento();
	}
}
