package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ParcelamentoJanelado;

@Repository
public class ParcelamentoJaneladoRepository extends BaseDAO {

	@LogPerformance
	public List<ParcelamentoJanelado> listar(BigInteger numeroCotacao, Integer versaoCotacao) {

		StringBuilder hql = new StringBuilder();
		hql.append(" from  	ParcelamentoJanelado janelado ");
		hql.append(" where janelado.numeroCotacaoProposta = :numeroCotacao ");
		hql.append(" and 	janelado.versaoCotacaoProposta = :versaoCotacao");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacao", numeroCotacao);
		query.setParameter("versaoCotacao", versaoCotacao);

		return (List<ParcelamentoJanelado>) query.list();
	}
	
	@LogPerformance
	public List<ParcelamentoJanelado> saveAll(List<ParcelamentoJanelado> parcelamentos) {
		StringBuilder sb = new StringBuilder();
		sb.append("delete from ParcelamentoJanelado p ");
		sb.append(" where 	p.numeroCotacaoProposta = :numeroCotacaoProposta");
		sb.append(" and 	p.versaoCotacaoProposta = :versaoCotacaoProposta");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("numeroCotacaoProposta", parcelamentos.get(0).getNumeroCotacaoProposta());
		query.setParameter("versaoCotacaoProposta", parcelamentos.get(0).getVersaoCotacaoProposta());
		query.executeUpdate();
		
		getCurrentSession().flush();

		for(ParcelamentoJanelado parcelamento: parcelamentos) {
			getCurrentSession().save(parcelamento);
		}
		return parcelamentos;
	}
}