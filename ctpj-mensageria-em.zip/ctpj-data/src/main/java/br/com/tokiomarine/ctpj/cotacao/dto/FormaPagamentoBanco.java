package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FormaPagamentoBanco implements Serializable {

	private static final long serialVersionUID = -8701776910833926894L;

	private Long banco;
	private String descricaoBanco;
	private Integer formaPagamento;

	public FormaPagamentoBanco(Long banco, String descricaoBanco, Integer formaPagamento) {
		this.banco = banco;
		this.descricaoBanco = descricaoBanco;
		this.formaPagamento = formaPagamento;
	}

	public Long getBanco() {
		return banco;
	}

	public void setBanco(Long banco) {
		this.banco = banco;
	}

	public String getDescricaoBanco() {
		return descricaoBanco;
	}

	public void setDescricaoBanco(String descricaoBanco) {
		this.descricaoBanco = descricaoBanco;
	}

	public Integer getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(Integer formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((formaPagamento == null) ? 0 : formaPagamento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FormaPagamentoBanco other = (FormaPagamentoBanco) obj;
		if (banco == null) {
			if (other.banco != null)
				return false;
		} else if (!banco.equals(other.banco))
			return false;
		if (formaPagamento == null) {
			if (other.formaPagamento != null)
				return false;
		} else if (!formaPagamento.equals(other.formaPagamento))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FormaPagamentoBanco [banco=" + banco + ", descricaoBanco=" + descricaoBanco + ", formaPagamento="
				+ formaPagamento + "]";
	}
}