package br.com.tokiomarine.ctpj.integracao.backoffice.response;

import java.io.Serializable;

import java.math.BigDecimal;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AproveitamentoCreditoResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4341536590704735616L;

	@JsonProperty("p_cd_banco")
	private Integer codigoBanco;

	@JsonProperty("p_nm_banco")
	private String nomeBanco;

	@JsonProperty("p_cd_agencia")
	private Long codigoAgencia;

	@JsonProperty("p_vl_credito_dolar")
	private BigDecimal valorCreditoDolar;

	@JsonProperty("p_vl_credito_real")
	private BigDecimal valorCredito;

	@JsonProperty("p_id_credito_disponivel")
	@Type(type = "br.com.tokiomarine.ctpj.config.StringIdEnumType")
	private SimNaoEnum idCreditoDisponivel;

	@JsonProperty("p_id_tipo_recebimento")
	private String idTipoRecebimento;

	@JsonProperty("p_mensagem")
	private String mensagem;

	@JsonProperty("p_mens")
	private String mensagemErro;

	@JsonProperty("codigoRetorno")
	private String codigoRetorno;

	@JsonProperty("descricaoCodigoRetorno")
	private String descricaoCodigoRetorno;

	public Integer getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(Integer codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public Long getCodigoAgencia() {
		return codigoAgencia;
	}

	public void setCodigoAgencia(Long codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	public BigDecimal getValorCreditoDolar() {
		return valorCreditoDolar;
	}

	public void setValorCreditoDolar(BigDecimal valorCreditoDolar) {
		this.valorCreditoDolar = valorCreditoDolar;
	}

	public BigDecimal getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(BigDecimal valorCredito) {
		this.valorCredito = valorCredito;
	}

	public SimNaoEnum getIdCreditoDisponivel() {
		return idCreditoDisponivel;
	}

	public void setIdCreditoDisponivel(SimNaoEnum idCreditoDisponivel) {
		this.idCreditoDisponivel = idCreditoDisponivel;
	}

	public String getIdTipoRecebimento() {
		return idTipoRecebimento;
	}

	public void setIdTipoRecebimento(String idTipoRecebimento) {
		this.idTipoRecebimento = idTipoRecebimento;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getMensagemErro() {
		return mensagemErro;
	}

	public void setMensagemErro(String mensagemErro) {
		this.mensagemErro = mensagemErro;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	@Override
	public String toString() {
		return "AproveitamentoCreditoResponse [codigoBanco=" + codigoBanco + ", nomeBanco=" + nomeBanco + ", codigoAgencia=" + codigoAgencia + ", valorCreditoDolar=" + valorCreditoDolar + ", valorCredito=" + valorCredito + ", idCreditoDisponivel=" + idCreditoDisponivel + ", idTipoRecebimento=" + idTipoRecebimento + ", mensagem=" + mensagem + ", mensagemErro=" + mensagemErro + ", codigoRetorno=" + codigoRetorno + ", descricaoCodigoRetorno=" + descricaoCodigoRetorno + "]";
	}

}
