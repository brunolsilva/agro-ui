package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoberturaAdicionar implements Serializable {

	private static final long serialVersionUID = -6400592575762352625L;

	private BigInteger cotacao;
	private BigInteger sequencialItemCotacao;
	private Integer codigoCobertura;
	
	public CoberturaAdicionar() {
		/**
		 * Construtor Vazio
		 */
	}
	
	public CoberturaAdicionar(BigInteger sequencialItemCotacao, Integer codigoCobertura) {
		this.sequencialItemCotacao = sequencialItemCotacao;
		this.codigoCobertura = codigoCobertura;
	}
	
	public BigInteger getCotacao() {
		return cotacao;
	}
	public void setCotacao(BigInteger cotacao) {
		this.cotacao = cotacao;
	}
	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}
	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}
	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}
	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}
	
	@Override
	public String toString() {
		return "CoberturaAdicionar [cotacao=" + cotacao + ", sequencialItemCotacao=" + sequencialItemCotacao
				+ ", codigoCobertura=" + codigoCobertura + "]";
	}
}