package br.com.tokiomarine.ctpj.controller;

import java.math.BigInteger;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import br.com.tokiomarine.cliente.dto.persistencia.EnderecoCliente;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.controller.AbstractController;
import br.com.tokiomarine.ctpj.cotacao.service.CalculoCotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.CondicaoContratualService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.integracao.cliente.service.EnderecoClienteService;
import br.com.tokiomarine.ctpj.integracao.service.FichaRegistradaService;
import br.com.tokiomarine.ctpj.print.service.CotacaoPrintService;
import br.com.tokiomarine.ctpj.print.service.DeclaracaoPrintService;
import br.com.tokiomarine.ctpj.print.service.PropostaPrintService;

@Controller
public class HomeController extends AbstractController {

	private static Logger logger = LogManager.getLogger(br.com.tokiomarine.ctpj.controller.HomeController.class);

	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private CondicaoContratualService condicaoContratualService;

	@Autowired
	private CalculoCotacaoService calculoCotacaoService;

	@Autowired
	private CotacaoService cotacao;

	@Autowired
	private DeclaracaoPrintService declaracaoPrintService;

	@Autowired
	private CotacaoPrintService cotacaoPrintService;

	@Autowired
	private PropostaPrintService propostaPrintService;
	
	@Autowired
	private FichaRegistradaService fichaRegistradaService;
	
	@Autowired
	private EnderecoClienteService clienteService;
	
	/*@LogPerformance
	@GetMapping(value = "/home")
	public String home(HttpSession session,HttpServletRequest request,ModelMap model) {
		try {
			logger.info("Carregando Produtos...");
			model.put("produtos",Collections.emptyList());

		} catch (final Exception e) {
			model.put("mensagem",e.getMessage());
			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro",e);
			return Paginas.error.value();
		}
		return Paginas.home.value();
	}*/

	@GetMapping(value = "/login")
	public String login(HttpServletRequest request,HttpServletResponse response) {

		return null;
	}

//	@GetMapping(value = "/rest/parcelamento")
//	public List<OpcaoParcelamento> parcelamento(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
//		return opcaoParcelamentoService.gerarOpcaoParcelamento(cotacao.findCompleta(BigInteger.ONE));
//	}
//
//	@GetMapping(value = "/rest/parcelamentoView/{idCotacao}")
//	public String opcaoParcelamento(@PathVariable BigInteger idCotacao,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
//		try {
//			logger.info("Carregando opções de pagamento...");
//			List<BaseOpcaoParcelamentoView> opcoesParcelamento = opcaoParcelamentoService.consultarOpcaoParcelamento(cotacao.findCompleta(idCotacao));
//			for (BaseOpcaoParcelamentoView baseOpcaoParcelamentoView : opcoesParcelamento) {
//				System.out.println(baseOpcaoParcelamentoView.getOpcoesParcelamento().get(0).getDescricaoFormaPagamento());
//			}
//			model.put("parcelamentos",opcoesParcelamento);
//		} catch (final Exception e) {
//			model.put("mensagem",e.getMessage());
//			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
//			logger.error("Erro",e);
//			return Paginas.error.value();
//		}
//		return Paginas.parcelamento.value();
//	}
//
//	@LogPerformance
//	@GetMapping(value = "/rest/declaracao/{sequencialCotacaoProposta}")
//	public String gerarImpressaoDeclaracao(@PathVariable BigInteger sequencialCotacaoProposta,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
//		try {
//			logger.info("Carregando impressão Declaração...");
//			ResultadoREST<Boolean> resultado = declaracaoPrintService.gerarImpressaoDeclaracao(sequencialCotacaoProposta);
//			return "redirect:" + resultado.getMensagem();
//		} catch (final Exception e) {
//			model.put("mensagem",e.getMessage());
//			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
//			logger.error("Erro",e);
//			return Paginas.error.value();
//		}
//	}
//
//	@LogPerformance
//	@GetMapping(value = "/rest/cotacao/{sequencialCotacaoProposta}")
//	public String gerarImpressaoCotacao(@PathVariable BigInteger sequencialCotacaoProposta,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
//		try {
//			logger.info("Carregando impressão proposta...");
//			ResultadoREST<Boolean> resultado = cotacaoPrintService.gerarImpressaoCotacao(sequencialCotacaoProposta);
//			return "redirect:" + resultado.getMensagem();
//		} catch (final Exception e) {
//			model.put("mensagem",e.getMessage());
//			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
//			logger.error("Erro",e);
//			return Paginas.error.value();
//		}
//	}
//
//	@GetMapping(value = "/rest/proposta/{sequencialCotacaoProposta}")
//	public String gerarImpressaoProposta(@PathVariable BigInteger sequencialCotacaoProposta,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
//		try {
//			logger.info("Carregando impressão proposta...");
//			ResultadoREST<Boolean> resultado = propostaPrintService.gerarImpressaoProposta(sequencialCotacaoProposta);
//			return "redirect:" + resultado.getMensagem();
//		} catch (final Exception e) {
//			model.put("mensagem",e.getMessage());
//			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
//			logger.error("Erro",e);
//			return Paginas.error.value();
//		}
//	}
//
//	@GetMapping(value = "/rest/calcular/{sequencialCotacaoProposta}")
//	public @ResponseBody ResultadoREST<List<String>> gerarCalculo(@PathVariable BigInteger sequencialCotacaoProposta,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
//		try {
//			logger.info("Inicializando cálculo da Cotacao...");
//			User user = new User();
//			user.setCdUsuro(107092);
//			user.setGrupoUsuario(GrupoUsuarioEnum.CORRETOR);
//			user.setNmUsuro("Ricardo Yukio Miwa");
//			//TODO
//			// retirar a criação do user
//			//User user = super.getUser();
//			ResultadoREST<List<String>> resultado = calculoCotacaoService.calcularCotacao(sequencialCotacaoProposta,user);
//			System.out.println(resultado.getMensagem());
//			return resultado;
//		} catch (final Exception e) {
//			logger.error("Erro",e);
//			return new ResultadoREST<>();
//		}
//	}
/*	@GetMapping(value = "/rest/declaracaoApolice")
	public String declaracao(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = declaracaoPrintService.gerarDeclaracaoApolice();
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/declaracaoApoliceLMI")
	public String declaracaoLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = declaracaoPrintService.gerarDeclaracaoApoliceLmi();
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/declaracaoEndossoAlteracao")
	public String declaracaoEndossoAlteracao(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = declaracaoPrintService.gerarDeclaracaoEndossoAlteracao();
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/declaracaoEndossoAlteracaoLMI")
	public String declaracaoEndossoAlteracaoLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = declaracaoPrintService.gerarDeclaracaoEndossoAlteracaoLmi();
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/cotacaoApolice")
	public String cotacao(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = cotacaoPrintService.gerarCotacaoApolice();
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/cotacaoApoliceLMI")
	public String cotacaoLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = cotacaoPrintService.gerarCotacaoApoliceLmi();
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaApolice")
	public String proposta(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaApolice("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaApoliceLMI")
	public String propostaLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaApoliceLMI("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaCancelamentoApolice")
	public String propostaCancelamentoApolice(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaCancelamentoApolice("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaCancelamentoApoliceLMI")
	public String propostaCancelamentoApoliceLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaCancelamentoApoliceLmi("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaCancelamentoEndosso")
	public String propostaCancelamentoEndosso(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaCancelamentoEndosso("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaCancelamentoEndossoLMI")
	public String propostaCancelamentoEndossoLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaCancelamentoEndossoLmi("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaProrrogacaoVigencia")
	public String propostaProrrogacaoVigencia(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaProrrogacaoVigencia("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaProrrogacaoVigenciaLMI")
	public String propostaProrrogacaoVigenciaLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaProrrogacaoVigenciaLmi("Corretor");
		return "redirect:" + resultado.getMensagem();
	}
	
	@GetMapping(value = "/rest/propostaEndossoAlteracao")
	public String propostaEndossoAlteracao(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaEndossoAlteracao("Corretor");
		return "redirect:" + resultado.getMensagem();
	}
	
	@GetMapping(value = "/rest/propostaEndossoAlteracaoLMI")
	public String propostaEndossoAlteracaoLMI(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaEndossoAlteracaoLmi("Corretor");
		return "redirect:" + resultado.getMensagem();
	}

	@GetMapping(value = "/rest/propostaEndossoAjustamentoPremio")
	public String propostaEndossoAjustamentoPremio(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaEndossoAjustamentoPremio("Corretor");
		return "redirect:" + resultado.getMensagem();
	}
	
	@GetMapping(value = "/rest/propostaEndossoAjustamentoPremioLMI")
	public String propostaEndossoAjustamentoPremioLmi(HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		ResultadoREST<Boolean> resultado = propostaPrintService.gerarPropostaEndossoAjustamentoPremioLmi("Corretor");
		return "redirect:" + resultado.getMensagem();
	}
	*/
	
	@GetMapping(value = "/rest/clienteService")
	public List<EnderecoCliente> clienteServiceTeste() throws ServiceException {
		
		Cotacao cotacao = new Cotacao();
		cotacao.setCodigoCliente(7870911l);
		cotacao.setIdFormaCobrancaPrimeiraParcela(BigInteger.valueOf(7447907l));
		cotacao.setIdTipoPessoa(TipoSeguradoEnum.FISICA);
		cotacao.setNumeroCNPJCPFSegurado(1234567890l);
		User user = new User();
		user.setGrupoUsuario(GrupoUsuarioEnum.CORRETOR);
		user.setCdUsuro(40);
		List<EnderecoCliente> consulta = clienteService.consultarEnderecosCliente(new Object[] {cotacao.getCodigoCliente()});
		return consulta;
	}
}
