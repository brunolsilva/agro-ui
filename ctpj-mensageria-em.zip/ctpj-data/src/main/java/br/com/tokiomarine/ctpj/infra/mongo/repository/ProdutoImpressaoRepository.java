package br.com.tokiomarine.ctpj.infra.mongo.repository;


public class ProdutoImpressaoRepository {

}
