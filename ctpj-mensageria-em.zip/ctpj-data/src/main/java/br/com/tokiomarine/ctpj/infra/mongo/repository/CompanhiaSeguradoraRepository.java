package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.CompanhiaSeguradora;
@Repository
public class CompanhiaSeguradoraRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public List<CompanhiaSeguradora> findCiasSeguradora() {
		return mongoTemplate.find(
				query(
						where("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))

				).with(new Sort(Direction.ASC, "nome")) , CompanhiaSeguradora.class);
	}

	public CompanhiaSeguradora findCiaSeguradoraByCodigo(Integer codigo) {
		return mongoTemplate.findOne(
				query(
						where("codigo").is(codigo)), CompanhiaSeguradora.class);
	}
}
