package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CoberturaLimiteAgrupamentoRepository;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Component
public class ResseguroFacultativoLimiteService {
	
	@Autowired
	private CoberturaLimiteAgrupamentoRepository coberturaLimiteAgrupamentoRepository;
	
	/**
	 * Se a soma das coberturas LMR = 'S' for maior que o limite do produto,
	 * marca o item e a cotação como resseguro facultativo
	 * 
	 * @param cotacao
	 * @param produto
	 */
	public void marcaResseguroFacultativo(Cotacao cotacao,Produto produto) {
		BigDecimal limiteProduto = coberturaLimiteAgrupamentoRepository.findByProduto(produto.getCodigo(),cotacao);
		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			BigDecimal somaIS = itemCotacao.getListItemCobertura().stream()
				.filter(cobertura -> cobertura.getIdLMR() == SimNaoEnum.SIM &&
						cobertura.getValorImportanciaSegurada() != null)
				.map(ItemCobertura::getValorImportanciaSegurada)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
			if(BigDecimalUtil.maior(somaIS,limiteProduto)) {
				cotacao.setIdResseguroFacultativo(SimNaoEnum.SIM);
				itemCotacao.setIdResseguroFacultativo(SimNaoEnum.SIM);
			}
		}
	}
}