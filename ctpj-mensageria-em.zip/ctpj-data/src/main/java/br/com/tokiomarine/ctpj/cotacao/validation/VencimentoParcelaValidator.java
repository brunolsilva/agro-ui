package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.DataMinimaVencimentoView;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilCalculoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilComercialRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.FormaParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCondicao;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.ReferenciaDataVencimentoEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaParcelamentoRepository;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.DateUtil;

@Component
public class VencimentoParcelaValidator {

	private static Logger logger = LogManager.getLogger(VencimentoParcelaValidator.class);

	@Autowired
	private PerfilComercialRepository perfilComercialRepository;

	@Autowired
	private PerfilCalculoRepository perfilCalculoRepository;
	
	private RestTemplate restTemplate = new RestTemplate();
	
	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private FormaParcelamentoRepository formaParcelamentoRepository;

	public List<Validacao> validaDataPrimeiraParcela(Cotacao cotacao,Date dataVencimentoParcela,Integer formaPagamento,Integer parcelamentoSelecionado) throws ServiceException {
		User user = SecurityUtils.getCurrentUser();
		List<Validacao> listaValidacao = new ArrayList<>();
		FormaParcelamento formaParcelamento = formaParcelamentoRepository.findByFormaParcelamento(parcelamentoSelecionado);
		if(formaParcelamento.getEntrada() == SimNaoEnum.SIM) {
			if(dataVencimentoParcela == null) {
				listaValidacao.add(new Validacao("Favor informar a data de Vencimento da 1ª Parcela"));
				return listaValidacao;
			}
		}

		if(formaPagamento.equals(FormaPagamentoEnum.CARNE.getCodigo())) {
			listaValidacao = validaBoleto(cotacao,dataVencimentoParcela,formaParcelamento,user);
		} else {
			listaValidacao = validaDebito(cotacao,dataVencimentoParcela,formaParcelamento,user);
		}

		return listaValidacao;
	}

	private List<Validacao> validaBoleto(Cotacao cotacao,Date dataVencimentoParcela,FormaParcelamento formaParcelamento,User user) {
		List<Validacao> listaValidacao = new ArrayList<>();
		Date dataInicio = cotacao.getDataInicioVigencia();
		Date dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(), 7);

		if(formaParcelamento.getEntrada() == SimNaoEnum.SIM) {
			PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(
					user.getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			if(perfilComercialCondicao != null) {
				if(perfilComercialCondicao.getReferenciaDataVencimentoBoleto() == ReferenciaDataVencimentoEnum.DATA_TRANSMISSAO_EMISSAO) {
					dataInicio = DateUtils.addDays(new Date(),1);
					dataFim = DateUtils.addDays(new Date(),perfilComercialCondicao.getNumeroDiasVencimentoBoleto());
				} else {
					if(user.getGrupoUsuario() != GrupoUsuarioEnum.CORRETOR) {
						dataInicio = DateUtils.addDays(new Date(),1);
					} else {
						dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(),perfilComercialCondicao.getNumeroDiasVencimentoBoleto());
					}
				}
			} else {
				PerfilCalculoCondicao condicao = perfilCalculoRepository.findPerfilCalculoCondicao(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCotacao());
				if(condicao != null) {
					if(condicao.getReferenciaDataVencimentoBoleto() == ReferenciaDataVencimentoEnum.DATA_TRANSMISSAO_EMISSAO) {
						dataInicio = DateUtils.addDays(new Date(),1);
						dataFim = DateUtils.addDays(new Date(),condicao.getNumeroDiasVencimentoBoleto());
					} else {
						dataInicio = DateUtils.addDays(new Date(),1);
						if(user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR) {
							dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(),condicao.getNumeroDiasVencimentoBoleto());
						} else {
							dataFim = DateUtils.addDays(new Date(),condicao.getNumeroDiasVencimentoBoleto());
						}
					}
				}
			}

			dataInicio = DateUtils.truncate(dataInicio, Calendar.DAY_OF_MONTH);
			dataFim = DateUtils.addMilliseconds(DateUtils.ceiling(dataFim, Calendar.DATE), -1);

			boolean dataValida = DateUtils.truncatedCompareTo(dataVencimentoParcela,dataInicio,Calendar.MINUTE) >= 0 && DateUtils.truncatedCompareTo(dataVencimentoParcela,dataFim,Calendar.MINUTE) <= 0;
			if(!dataValida) {
				listaValidacao.add(new Validacao(String.format("Vencimento da 1ª parcela deve ser entre %s e %s!", DateUtil.formataSemHora(dataInicio), DateUtil.formataSemHora(dataFim))));
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaDebito(Cotacao cotacao,Date dataVencimentoParcela,FormaParcelamento formaParcelamento,User user) throws ServiceException {
		List<Validacao> listaValidacao = new ArrayList<>();

		Date dataInicio = null;
		Date dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(), 7);

		if(formaParcelamento.getEntrada() == SimNaoEnum.SIM) {
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroDataVencimentoDebito();
			if (urlEnum == null) {
				logger.error("Erro ao na busca da url, urlEnum nula: " + urlEnum);
				throw new ServiceException("Erro ao na busca da url, urlEnum nula ");
			}			
			
			String url = null;
			
			try {
				url = parametroGeralService.getUrlByNome(urlEnum);
			} catch (Exception e) {
				logger.error("Erro ao na consulta na busca do Parametro: " + e.getMessage());
				throw new ServiceException("Erro ao na consulta na busca do Parametro: ",e);
			}
			
			Map<String, Object> dadosBanco = new HashMap<>();
			dadosBanco.put("p_cd_banco",cotacao.getNumeroBancoDebito());
			dadosBanco.put("p_id_pa","S");
			dadosBanco.put("p_dt_ref",DateUtil.formataAnoMesDiaComHifen(new Date()));

			logger.info(String.format("Chamando Serviço de Validação de Data Mínima: [%s] [%s] [cotacao = %s]",url,dadosBanco,cotacao.getSequencialCotacaoProposta()));

			DataMinimaVencimentoView dataMinimaVencimentoView = restTemplate.postForObject(url,dadosBanco,DataMinimaVencimentoView.class);
			logger.info(String.format("Retorno Serviço de Validação de Data Mínima: [%s] [%s] [cotacao = %s]",url,dataMinimaVencimentoView,cotacao.getSequencialCotacaoProposta()));
			Date dataMinimaVencimento = null;
			if(dataMinimaVencimentoView != null) {
				dataMinimaVencimento = DateUtil.parseAnoMesDiaComHifen(dataMinimaVencimentoView.getP_dt_min());
			}
			if(dataMinimaVencimentoView != null && dataMinimaVencimento != null) {
				dataInicio = DateUtils.addDays(dataMinimaVencimento, 1);
			} else {
				listaValidacao.add(new Validacao("Não foi possível recuperar a data mínima do vencimento da primeira parcela!"));
				return listaValidacao;
			}

			PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(
					user.getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			if(perfilComercialCondicao != null) {
				if(perfilComercialCondicao.getReferenciaDataVencimentoBoleto() == ReferenciaDataVencimentoEnum.DATA_TRANSMISSAO_EMISSAO) {
					dataFim = DateUtils.addDays(new Date(),perfilComercialCondicao.getNumeroDiasVencimentoBoleto());
				} else {
					dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(),perfilComercialCondicao.getNumeroDiasVencimentoBoleto());
				}
			} else {
				PerfilCalculoCondicao condicao = perfilCalculoRepository.findPerfilCalculoCondicao(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCotacao());
				if(condicao != null) {
					if(condicao.getReferenciaDataVencimentoBoleto() == ReferenciaDataVencimentoEnum.DATA_TRANSMISSAO_EMISSAO) {
						dataFim = DateUtils.addDays(new Date(),condicao.getNumeroDiasVencimentoBoleto());
					} else {
						dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(),condicao.getNumeroDiasVencimentoBoleto());
					}
				}
			}

			if(dataInicio.compareTo(dataFim) >= 0) {
				boolean dataValida = DateUtils.isSameDay(dataInicio, dataVencimentoParcela);
				if(!dataValida) {
					listaValidacao.add(new Validacao("Vencimento da 1ª parcela deve ser igual a " + DateUtil.formataSemHora(dataInicio)));
				}
			} else {
				boolean dataValida = dataVencimentoParcela.compareTo(dataInicio) >= 0 && dataVencimentoParcela.compareTo(dataFim) <= 0;
				if(!dataValida) {
					listaValidacao.add(new Validacao("Vencimento da 1ª parcela deve ser entre " + DateUtil.formataSemHora(dataInicio) + " e " + DateUtil.formataSemHora(dataFim)));
				}
			}
		}

		return listaValidacao;
	}
}