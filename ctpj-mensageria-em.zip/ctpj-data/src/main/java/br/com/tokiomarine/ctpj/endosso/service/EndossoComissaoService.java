package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ComissaoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.domain.Produto;

@Service
public class EndossoComissaoService {
	
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	/**
	 * prc_ctp0102
	 */
	public void validarComissao(Produto produto, Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		//verifica se a apolice possui lista de comissão
		if(apolice.getListComissaoApolice() != null && !apolice.getListComissaoApolice().isEmpty()){
			//verifica 
			if(endosso.getListComissaoCotacao() != null && !endosso.getListComissaoCotacao().isEmpty()){
				for(ComissaoCotacao comissaoCotacao : endosso.getListComissaoCotacao()){
					for(ComissaoApolice comissaoApolice : apolice.getListComissaoApolice()){
						if(comissaoApolice.getCodigoGrupoRamoEmissao().equals(comissaoCotacao.getCodigoGrupoRamo()) &&
							comissaoApolice.getCodigoRamoEmissao().equals(comissaoCotacao.getCodigoRamo())){
							validacaoParametrosEndossoService.compararParametrosEndosso(comissaoApolice.getPercentualComissao(), comissaoCotacao.getPercentualComissao(), TipoMensagemEndossoEnum.ALT_COMISSAO,"-%Comissão ", produto, endosso, alteracoesEndossoList, user);
						}						
					}
				}				
			}
		}
	}
}
