package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DistribuicaoView implements Serializable {

	private static final long serialVersionUID = -19538552238412192L;

	private BigInteger sequencialItemDistribuicao;
	private String descricao;
	
	public BigInteger getSequencialItemDistribuicao() {
		return sequencialItemDistribuicao;
	}
	
	public void setSequencialItemDistribuicao(BigInteger sequencialItemDistribuicao) {
		this.sequencialItemDistribuicao = sequencialItemDistribuicao;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
}