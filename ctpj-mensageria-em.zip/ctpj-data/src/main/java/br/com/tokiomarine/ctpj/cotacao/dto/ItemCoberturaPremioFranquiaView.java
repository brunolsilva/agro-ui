package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemCoberturaPremioFranquiaView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4114785179603445839L;
	private BigInteger sequencialItemCobertura;
	private Integer codigoCobertura;
	private String descricaoCobertura;
	private String valorImportanciaSegurada;
	private String valorPremio;
	private String descricaoFranquia;
	private String franquia;
	
	public BigInteger getSequencialItemCobertura() {
		return sequencialItemCobertura;
	}
	
	public void setSequencialItemCobertura(BigInteger sequencialItemCobertura) {
		this.sequencialItemCobertura = sequencialItemCobertura;
	}
	
	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}
	
	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}
	
	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}
	
	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}
	
	public String getValorImportanciaSegurada() {
		return this.valorImportanciaSegurada;
	}
	
	public void setValorImportanciaSegurada(String valorImportanciaSegurada) {
		this.valorImportanciaSegurada = valorImportanciaSegurada;
	}
	
	public String getValorPremio() {
		return this.valorPremio;
	}
	
	public void setValorPremio(String valorPremio) {
		this.valorPremio = valorPremio;
	}

	public String getDescricaoFranquia() {
		return descricaoFranquia;
	}
	
	public void setDescricaoFranquia(String descricaoFranquia) {
		this.descricaoFranquia = descricaoFranquia;
	}
	
	public String getFranquia() {
		return franquia.toUpperCase();
	}
	
	public void setFranquia(String franquia) {
		this.franquia = franquia;
	}
	
}
