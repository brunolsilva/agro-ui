package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoJurosParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.TabelaJurosParcelamento;

@Repository
public class ProdutoJurosRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	@LogPerformance
	public List<Integer> listarPorSegurado(Long segurado,Integer produto) {
		List<ProdutoJurosParcelamento> produtoJurosParcelamento = mongoTemplate.find(
				query(
						where("segurado").is(segurado)
						.and("produto").is(produto)
						.and("dataInicioVigencia").lte(new Date())
						.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))
						), ProdutoJurosParcelamento.class);

		return produtoJurosParcelamento.stream()
				.map(ProdutoJurosParcelamento::getIdJuros)
				.collect(Collectors.toList());
	}
	
	@LogPerformance
	public List<Integer> listarPorCorretor(Long corretor,Integer produto) {
		List<ProdutoJurosParcelamento> produtoJurosParcelamento = mongoTemplate.find(
				query(
						where("corretor").is(corretor)
						.and("produto").is(produto)
						.and("dataInicioVigencia").lte(new Date())
						.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))
						), ProdutoJurosParcelamento.class);

		return produtoJurosParcelamento.stream()
				.map(ProdutoJurosParcelamento::getIdJuros)
				.collect(Collectors.toList());
	}
	
	@LogPerformance
	public List<Integer> listarDefault(Integer produto) {
		List<ProdutoJurosParcelamento> produtoJurosParcelamento = mongoTemplate.find(
				query(
						where("produto").is(produto)
						.and("dataInicioVigencia").lte(new Date())
						.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))
						), ProdutoJurosParcelamento.class);

		return produtoJurosParcelamento.stream()
				.map(ProdutoJurosParcelamento::getIdJuros)
				.collect(Collectors.toList());
	}

	@LogPerformance
	public List<TabelaJurosParcelamento> listarJuros(List<Integer> idJuros) {
		return mongoTemplate.find(
				query(
						where("idJuros").in(idJuros)
						), TabelaJurosParcelamento.class);
	}
}