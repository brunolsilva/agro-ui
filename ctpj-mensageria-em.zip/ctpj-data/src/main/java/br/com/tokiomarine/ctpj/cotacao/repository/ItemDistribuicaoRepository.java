package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.cotacao.dto.DistribuicaoView;
import br.com.tokiomarine.ctpj.dao.BaseDAO;

@Repository
public class ItemDistribuicaoRepository extends BaseDAO {

	@SuppressWarnings("unchecked")
	public List<Object[]> findValorRiscoDistribuidoBySeq(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select i.numeroItem, ir.descricaoRiscoBem, ir.valorRiscoBem, ir.valorRiscoBemMoedaEstrangeira ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemDistribuicao ir ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		sb.append("order by i.numeroItem ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> findValorRiscoDistribuidoBySeqItem(BigInteger sequencialItemCotacao) {
		StringBuilder sb = new StringBuilder();
		sb.append("select i.numeroItem, ir.descricaoRiscoBem, ir.valorRiscoBem, ir.valorRiscoBemMoedaEstrangeira ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemDistribuicao ir ");
		sb.append("where  i.cotacao.sequencialItemCotacao = :sequencialItemCotacao ");
		sb.append("order by i.numeroItem ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialItemCotacao",sequencialItemCotacao);
		return (List<Object[]>) query.list();
	}

	@SuppressWarnings("unchecked")
	public List<DistribuicaoView> findDescricaoValorRiscoDistribuidoBySeq(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select ir.sequencialItemDistribuicao as sequencialItemDistribuicao, ir.descricaoRiscoBem as descricao ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemDistribuicao ir ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		sb.append("order by ir.sequencialItemDistribuicao ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		query.setResultTransformer(Transformers.aliasToBean(DistribuicaoView.class));
		return (List<DistribuicaoView>) query.list();
	}

	public Object[] findValorRiscoDistribuidoBySeqItemAndDescRiscoBem(BigInteger sequencialItemCotacao,String descricaoRiscoBem) {
		StringBuilder sb = new StringBuilder();
		sb.append("select ir.valorRiscoBem, ir.valorRiscoBemMoedaEstrangeira ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemDistribuicao ir ");
		sb.append("where  i.sequencialItemCotacao = :sequencialItemCotacao ");
		sb.append("and    ir.descricaoRiscoBem    = :descricaoRiscoBem");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialItemCotacao",sequencialItemCotacao);
		query.setParameter("descricaoRiscoBem",descricaoRiscoBem);

		return (Object[]) query.uniqueResult();
	}

	public List<Object[]> findDanosMateriasBySeqCotac(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();

		sb.append("select distinct i.numeroItem, ir.descricaoRiscoBem, ir.valorRiscoBem, ir.valorRiscoBemMoedaEstrangeira ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemDistribuicao ir ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		sb.append("and    ir.idTipoValorRisco = 1 ");
		sb.append("order by i.numeroItem ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}

	public List<Object[]> findLucrosCessantesBySeqCotac(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select 	distinct ir.descricaoRiscoBem, ir.valorRiscoBem, ir.valorRiscoBemMoedaEstrangeira ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemDistribuicao ir ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		sb.append("and    ir.idTipoValorRisco = 2 ");
		sb.append("order by ir.descricaoRiscoBem ");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}

}
