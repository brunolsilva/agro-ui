package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.DescontoCCGRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ContaCorrenteGlobal;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoCCG;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request.ProvisaoRequest;
import br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request.ValorDescontoRequest;
import br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response.SaldoResponse;
import br.com.tokiomarine.ctpj.integracao.dto.RetornoConsultarSaldo;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class DescontoCCGService {
	private static Logger logger = LogManager.getLogger(DescontoCCGService.class);
	
	@Autowired
	DescontoCCGRepository repository;
	
	@Autowired
	CotacaoRepository cotacaoRepository;
	
	@Autowired
	ContaCorrenteService contaCorrenteService;
	
	/**
	 * atualiza as verbas na base de dados - tabela CTP0101_CONSU_CC_GLOBA (deve ser chamado logo após consulta de verbas)
	 * @param cotacao
	 * @param retServico
	 * @param user
	 * @return
	 * @throws ServiceException
	 */
	public RetornoConsultarSaldo atualizarVerbas(Cotacao cotacao, RetornoConsultarSaldo retServico,User user) throws ServiceException{
		if(!CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly()) {
			List<DescontoCCG> descontos = inserirVerbasRetornadasCcg(cotacao, retServico, user);			
			this.deleteVerbasAntigas(cotacao);
			atualizarAgravoCcg(cotacao, retServico);
			//altera o status para não calculado 
			cotacao.setListDescontoCCG(descontos);
			if(cotacao.getIdTipoOrigem() != null && cotacao.getIdTipoOrigem() != TipoOrigemEnum.WS) {
				cotacaoRepository.update(cotacao);
			}
		}
		return retServico;
	}

	private void atualizarAgravoCcg(Cotacao cotacao, RetornoConsultarSaldo retServico) {
		//atualiza o agravo
		Optional<ContaCorrenteGlobal> optCcg = cotacao.getListContaCorrenteGlobal().stream().findFirst();
		if(optCcg.isPresent()) {
			ContaCorrenteGlobal ccg = optCcg.get();
			if(ccg.getValorAgravoCCG() != null && ccg.getValorAgravoCCG().compareTo(BigDecimal.ZERO) > 0){
				retServico.getResponse().setValorAgravo(ccg.getValorAgravoCCG());
			}
		}
	}

	private List<DescontoCCG> inserirVerbasRetornadasCcg(Cotacao cotacao, RetornoConsultarSaldo retServico, User user) throws ServiceException {

		List<DescontoCCG> descontos = new ArrayList<>();

		//caso o serviço não tenha retorno, devolve uma lista vazia
		if(retServico.getResponse() == null)
		{
			return descontos;
		}
		//verifica se há registro na tabela 105
		Optional<ContaCorrenteGlobal> optCcg = cotacao.getListContaCorrenteGlobal().stream().findFirst();
		
		//caso o serviço tenha devolvido um response sem saldo, retorna lista vazia
		if(retServico.getResponse().getListaSaldo() == null || retServico.getResponse().getListaSaldo().isEmpty()){
			removerDescontoCcg(cotacao, retServico, optCcg);
			return descontos;
		}

		//armazenará a somatoria dos descontos
		BigDecimal valorDesconto = BigDecimal.ZERO;
		//se retornou verbas, salva/atualiza as verbas		
		for(SaldoResponse saldoResponse : retServico.getResponse().getListaSaldo()){
			//verifica se há verbas de conta corrente na tabela 101
			if(cotacao.getListDescontoCCG() != null && !cotacao.getListDescontoCCG().isEmpty()) {
				//compara as verbas retornadas com as existentes na base de dados, em caso de "match" atualiza o valor de desconto utilizado
				Optional<DescontoCCG> optDesconto = cotacao.getListDescontoCCG().stream().filter(v -> v.getIdSaldo().compareTo(saldoResponse.getIdSaldo())==0).findFirst();
				if(optDesconto.isPresent()) {
					//soma o valor do desconto
					valorDesconto = valorDesconto.add(optDesconto.get().getValorDesconto() == null ? BigDecimal.ZERO : optDesconto.get().getValorDesconto());
					saldoResponse.setValorProvisionado(optDesconto.get().getValorDesconto());
				} else {
					//caso não tenha encontrado, significa que a verba nao existe mais, portanto é removida
					removerDescontoCcg(cotacao, retServico, optCcg);
				}
			}
			descontos.add(this.save(this.bindToDomain(cotacao,saldoResponse,user)));
		}
		atualizarContaCorrenteGlobal(optCcg, valorDesconto);

		return descontos;
	}

	/**
	 * ajusta o valor do desconto na 105
	 * @param optCcg
	 * @param valorDesconto
	 */
	private void atualizarContaCorrenteGlobal(Optional<ContaCorrenteGlobal> optCcg, BigDecimal valorDesconto) {
		if(optCcg.isPresent()) {
			optCcg.get().setValorDescontoCCG(valorDesconto == null || valorDesconto.compareTo(BigDecimal.ZERO)==0 ? null : valorDesconto);	
		}
	}
	
	private void removerDescontoCcg(Cotacao cotacao, RetornoConsultarSaldo retServico,
			Optional<ContaCorrenteGlobal> optCcg) {
		if(optCcg.isPresent()) {
			ContaCorrenteGlobal ccg = optCcg.get();
			if(contaCorrenteService.hasDescontoAplicado(ccg)) {
				retServico.setDescontoRemovido(SimNaoEnum.SIM.getId());
				cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
				ccg.setValorDescontoCCG(null);				
			}
		}
	}
	
	/**
	 * aplica, na respectiva verba, o desconto utilizado pelo corretor - tabela CTP0101_CONSU_CC_GLOBA
	 * @param cotacao
	 * @throws ServiceException 
	 */
	public void aplicarDescontos(Cotacao cotacao, ProvisaoRequest provisao) throws ServiceException{

		Boolean haDescontoParaAplicar = haDescontoParaAplicar(provisao);
		
		if(haDescontoNaBase(cotacao)) {
			for(DescontoCCG descontoBaseDados : cotacao.getListDescontoCCG()){
				descontoBaseDados.setValorDesconto(null);
				if(haDescontoParaAplicar) {
					for(ValorDescontoRequest descontoParaAplicar:provisao.getListaValorDesconto()) {
						if(descontoBaseDados.getIdSaldo().compareTo(descontoParaAplicar.getIdSaldo())==0) {
							descontoBaseDados.setValorDesconto(descontoParaAplicar.getValorDesconto() == null || descontoParaAplicar.getValorDesconto().compareTo(BigDecimal.ZERO) == 0 ? null : descontoParaAplicar.getValorDesconto());
							break;
						}
					}
				}
				this.update(descontoBaseDados);	
			}
		}
	}

	private boolean haDescontoNaBase(Cotacao cotacao) {
		return cotacao.getListDescontoCCG() != null && !cotacao.getListDescontoCCG().isEmpty();
	}

	private boolean haDescontoParaAplicar(ProvisaoRequest provisao) {
		return provisao != null && provisao.getListaValorDesconto() != null && !provisao.getListaValorDesconto().isEmpty();
	}
	
	/**
	 * deleta as verbas que não foram retornadas pelo serviço de Consulta Saldo da Conta Corrente
	 * @param verbasBase
	 * @param verbasServico
	 * @throws ServiceException
	 */
	private void deleteVerbasAntigas(Cotacao cotacao) throws ServiceException{
		if(cotacao.getListDescontoCCG() != null && !cotacao.getListDescontoCCG().isEmpty()) {
			logger.info(String.format("Deletando verbas para nr_cotac_ppota %s versao %s, verbas: %s", cotacao.getNumeroCotacaoProposta(), cotacao.getVersaoCotacaoProposta(), cotacao.getListDescontoCCG()));
			for (Iterator<DescontoCCG> iterator = cotacao.getListDescontoCCG().iterator() ; iterator.hasNext() ;) {
				DescontoCCG ccg = iterator.next();
				this.delete(ccg);
				iterator.remove();
			}
		}

	}
		
	/**
	 * bind da verba para que seja gravada na base
	 * @param cotacao
	 * @param descontoBd
	 * @param s
	 * @param user
	 * @return
	 */
	private DescontoCCG bindToDomain(Cotacao cotacao,SaldoResponse s,User user){
		DescontoCCG d = new DescontoCCG();
		d.setCotacao(cotacao);
		d.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		d.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		//seta os dados da verba (retornados pelo serviço)
		d.setDataConsulta(new Date());
		d.setDataValidadeVerba(s.getDataValidade());
		d.setIdSaldo(s.getIdSaldo());
		d.setNomeVerba(s.getNomeVerba());
		d.setTipoVerba(s.getTipoVerba());
		d.setValorSaldo(s.getValorSaldo());
		d.setDataAtualizacao(new Date());
		d.setCodigoGrupo(cotacao.getCodigoGrupo());
		d.setUsuarioAtualizacao(user.getCdUsuro().longValue());
		d.setValorDesconto(s.getValorProvisionado());
		return d;
	}
		
	@LogPerformance
	/**
	 * retorna as verbas gravadas na base
	 * @param sequencialCotacaoProposta
	 * @return
	 * @throws ServiceException
	 */
	public List<DescontoCCG> findVerbas(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findContaCorrenteGlobal(sequencialCotacaoProposta);
		} catch (HibernateException re) {
			logger.error("Erro ao buscar dados das verbas da conta corrente global para a sq cotação: " + sequencialCotacaoProposta,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro ao buscar dados das verbas da conta corrente global para a sq cotação: " + sequencialCotacaoProposta,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	/**
	 * deleta verba
	 * @param ccg
	 * @return
	 * @throws ServiceException
	 */
	private DescontoCCG delete(DescontoCCG ccg) throws ServiceException {
		try {
			return repository.delete(ccg);
		} catch (HibernateException h) {
			logger.error("Erro ao excluir dados das verbas da conta corrente global");
			throw new ServiceException(h.getMessage(), h);
		} catch (Exception e) {
			logger.error("Erro geral ao excluir das verbas dados da conta corrente global");
			throw new ServiceException(e.getMessage(), e);
		}
	}
	
	/**
	 * atualiza verba
	 * @param ccg
	 * @return
	 * @throws ServiceException
	 */
	private DescontoCCG update(DescontoCCG ccg) throws ServiceException {
		try {
			return repository.update(ccg);
			
		} catch (HibernateException h) {
			logger.error("Erro ao atualizar dados das verbas da conta corrente global");
			throw new ServiceException(h.getMessage(), h);
		} catch (Exception e) {
			logger.error("Erro geral ao atualizar das verbas dados da conta corrente global");
			throw new ServiceException(e.getMessage(), e);
		}
	}
	
	/**
	 * insere verba
	 * @param ccg
	 * @return
	 * @throws ServiceException
	 */
	private DescontoCCG save(DescontoCCG ccg) throws ServiceException {
		try {
			return repository.save(ccg);
		} catch (HibernateException h) {
			logger.error("Erro ao salvar dados das verbas da conta corrente global");
			throw new ServiceException(h.getMessage(), h);
		} catch (Exception e) {
			logger.error("Erro geral ao salvar dados das verbas da conta corrente global");
			throw new ServiceException(e.getMessage(), e);
		}
	}
}
