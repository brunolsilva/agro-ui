package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCobEquipFranquiaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCoberturaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemCoberturaEquipamentoFranquiaService {
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0141
	 */
	public void validarEquipamentoFranquia(Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemEndossoCobertura, ItemCoberturaApolice itemApoliceCobertura, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean endossoPossuiEquipamentoFranquia = itemEndossoCobertura.getListItemEquipamentoFranquia() != null && !itemEndossoCobertura.getListItemEquipamentoFranquia().isEmpty();
		boolean apolicePossuiEquipamentoFranquia = itemApoliceCobertura.getListItemCobEquipFranquiaApolice() != null && !itemApoliceCobertura.getListItemCobEquipFranquiaApolice().isEmpty();
		
		//1 - percorre as franquias de equipamento do itemEndossoCobertura e compara com as do itemApoliceCobertura
		if(endossoPossuiEquipamentoFranquia){			
			for(ItemEquipamentoFranquia itemEquipamentoFranquia : itemEndossoCobertura.getListItemEquipamentoFranquia()){
				boolean equipamentoFranquiaExiste = false;
				if(apolicePossuiEquipamentoFranquia){
					for(ItemCobEquipFranquiaApolice itemApolEquipFranq : itemApoliceCobertura.getListItemCobEquipFranquiaApolice()){
						if(AssertUtils.compareNull(itemEquipamentoFranquia.getCodigoEquipamento(),itemApolEquipFranq.getCodigoEquipamento())){
							//valida forma franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getIdFormaFranquia().getId(), itemApolEquipFranq.getIdFormaFranquia(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Forma Franquia: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida numero horas franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getNumeroHorasFranquia(), itemApolEquipFranq.getNumeroHorasFranquia(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Nº Horas: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida numero dias franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getNumeroDiasFranquia(), itemApolEquipFranq.getNumeroDiasFranquia(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Nº Dias: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida taxa franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getTaxaFranquia(), itemApolEquipFranq.getTaxaFranquia(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Taxa: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida valor franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getValorFranquia(), itemApolEquipFranq.getValorFranquia(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Valor de franquia: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida valor minimo franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getValorFranquiaMinimo(), itemApolEquipFranq.getValorFranquiaMinimo(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Valor mínimo de franquia: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida valor máximo de franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getValorFranquiaMinimo(), itemApolEquipFranq.getValorFranquiaMinimo(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Valor máximo de franquia: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida taxa is
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getTaxaImportanciaSegurada(), itemApolEquipFranq.getTaxaImportanciaSegurada(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Taxa de IS: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);
							
							//valida taxa is minimo
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getTaxaImportanciaSeguradaMinimo(), itemApolEquipFranq.getTaxaImportanciaSeguradaMinimo(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Taxa Mínima de IS: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida taxa is maximo
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getTaxaImportanciaSeguradaMaximo(), itemApolEquipFranq.getTaxaImportanciaSeguradaMaximo(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Taxa Máxima de IS: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);

							//valida id texto franquia
							validacaoParametrosEndossoService.compararParametrosCobertura(itemEquipamentoFranquia.getIdTextoFranquia(), itemApolEquipFranq.getIdTextoFranquia(), TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, "- Id Texto: ", endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);
							
							//valida texto franquia
							// obs: itemApolEquipFranq descricaoFranquia = itemEquipamentoFranquia descricaoTextoFranquia 
							validacaoParametrosEndossoService.compararParametrosCoberturaSemDePara(itemEquipamentoFranquia.getDescricaoFranquia(),itemApolEquipFranq.getDescricaoTextoFranquia(),"- Descrição franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);
							
							//valida texto franquia
							// obs: itemEquipamentoFranquia descricaoTextoFranquia = itemApolEquipFranq complemento 
							validacaoParametrosEndossoService.compararParametrosCoberturaSemDePara(itemEquipamentoFranquia.getDescricaoTextoFranquia(),itemApolEquipFranq.getDescricaoComplementoFranquia(),"- Complemento descrição franquia: ", TipoMensagemEndossoEnum.ALT_FRANQUIA, endosso, itemEndosso, itemEndossoCobertura, alteracoesEndossoList, user);
							
							
							
							
							equipamentoFranquiaExiste = true;
							break;
						}						
					}
				}
				
				//se a franquias de equipamento não existir
				if(!equipamentoFranquiaExiste){ 
					logarInclusaoFranquiaEquipamento(itemEquipamentoFranquia,itemEndosso,itemEndossoCobertura,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as franquias de equipamento da itemApoliceCobertura e compara com as do itemEndossoCobertura
		if(apolicePossuiEquipamentoFranquia){
			for(ItemCobEquipFranquiaApolice itemApolEquipFranq : itemApoliceCobertura.getListItemCobEquipFranquiaApolice()){
				boolean equipamentoFranquiaExiste = false;
				if(endossoPossuiEquipamentoFranquia){
					for(ItemEquipamentoFranquia itemEndossoCobtuClaus : itemEndossoCobertura.getListItemEquipamentoFranquia()){
						if(AssertUtils.compareNull(itemEndossoCobtuClaus.getCodigoEquipamento(),itemApolEquipFranq.getCodigoEquipamento())){
							equipamentoFranquiaExiste = true;
							break;
						}
					}
				}
				
				if(!equipamentoFranquiaExiste){
					logarExclusaoClausula(itemApolEquipFranq,itemEndosso,itemEndossoCobertura,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoFranquiaEquipamento(ItemEquipamentoFranquia itemEndossoCobtuClaus, ItemCotacao itemEndosso,ItemCobertura itemCobertura,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, itemCobertura, TipoMensagemEndossoEnum.ALT_FRANQ_EQUIP, itemEndossoCobtuClaus.getCodigoEquipamento().toString(), user));
	}
	
		
	private void logarExclusaoClausula(ItemCobEquipFranquiaApolice itemApolEquipFranq, ItemCotacao itemEndosso, ItemCobertura itemCobertura,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, itemCobertura, TipoMensagemEndossoEnum.EXC_CLAUSULA, itemApolEquipFranq.getCodigoEquipamento().toString(), user));
	}


}
