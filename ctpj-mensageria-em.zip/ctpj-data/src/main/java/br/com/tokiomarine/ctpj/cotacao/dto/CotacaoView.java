package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.cliente.dto.FormaDevolucaoCliente;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.SolicitanteEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.enums.EstadoCivilEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.PrazoVigenciaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SexoEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.util.CnpjCpfUtil;
import br.com.tokiomarine.ctpj.util.DateUtil;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CotacaoView implements Serializable {

	private static final long serialVersionUID = -1668072913850689342L;

	private BigInteger sequencialCotacaoProposta;
	private BigInteger numeroCotacaoProposta;
	private Integer versaoCotacaoProposta;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	private Date dataCotacao;
	private Long numeroCNPJCPFSegurado;
	private TipoSeguradoEnum idTipoPessoa = TipoSeguradoEnum.JURIDICA;
	private String nomeSegurado;
	private Long codigoCliente;
	private Integer codigoAtividadePrincipal;
	private String descricaoAtividadePrincipal;
	private String idCEPSegurado;
	private String enderecoSegurado;
	private String nomeBairroSegurado;
	private Long numeroEnderecoSegurado;
	private String nomeComplementoEnderecoSegurado;
	private String nomeMunicipioSegurado;
	private String idUFSegurado;
	private String idEmailSegurado;
	private Integer numeroDDDSegurado;
	private Long numeroTelefoneSegurado;
	private Integer numeroDDDCelularSegurado;
	private Long numeroCelularSegurado;
	private TipoSeguroEnum idTipoSeguro;
	private Integer codigoCompanhiaSeguradora;
	private String numeroApoliceCongenere;
	private Integer codigoLocal;
	private Integer codigoSubLocal;
	private String nomeSubLocal;
	private String codigoCorretorACSEL;
	private Long numeroCNPJCPFCorretor;
	private String nomeCorretor;
	private Integer codigoProduto;
	private String nomeProduto;
	private String numeroProcessoSUSEP;
	private Integer codigoNicho;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	private Date dataInicioVigencia;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	private Date dataFimVigencia;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	private Date dataAlteracao;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	private Date dataCalculo;

	private PrazoVigenciaEnum idPrazoVigencia;
	private String descricaoObservacao;

	private String valorPremioLiquido;
	private MoedaEnum codigoMoeda;
	private Boolean idResseguroFacultativo;
	private Boolean idIsencaoImposto;

	private String cpfSegurado;
	private String cnpjSegurado;
	private String nomeSeguradoPF;
	private String nomeSeguradoPJ;

	private String telefoneSegurado;
	private String celularSegurado;

	private String numeroRG;
	private String nomeOrgaoExpedidor;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dataExpedicao;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dataNascimentoCliente;

	private String percentualComissao;
	private String percentualDescontoGeral;
	private String percentualAgravoGeral;

	private boolean calculo;
	private ControleCalculoEnum idControleCalculo;

	private Integer numeroBancoDebito;
	private Long numeroAgenciaDebito;
	private String tipoContaCorrenteDebito;
	private Integer numeroDigitoAgenciaDebito;
	private Long numeroContaCorrenteDebito;
	private String numeroDigitoContaCorrenteDebito;
	private TipoSeguradoEnum tipoPessoaTitularContaCorrenteDebito;
	private TipoSeguradoEnum tipoPessoaTitularContaCorrenteDevolucao;
	private Long numeroCNPJCPFTitularContaCorrenteDebito;
	private String cnpjCpfTitularContaCorrenteDebito;
	private Long numeroCNPJCPFTitularContaCorrenteDevolucao;
	private String cnpjCpfTitularContaCorrenteDevolucao;
	private String nometitularContaCorrenteDebito;
	private String nometitularContaCorrenteDevolucao;
	private SimNaoEnum primeiraParcelaDebito;
	private String primeiraParclDebit;

	private String nomeAgenciaDebito;
	private String numeroTelefoneAgencia;
	private String nomeCidadeAgencia;
	private String nomeBairroAgencia;
	private String idCepAgencia;
	private String enderecoAgencia;

	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dataVencimentoProgramada;
	private Integer numeroBancoBoleto;

	private SimNaoEnum estrangeiro;
	private SimNaoEnum possuiRNE;
	private String numeroRNE;
	private String numeroPassaporte;
	private BigInteger idPais;
	private String siglaPais;
	private BigInteger idProfissao;
	private BigInteger idCapitalSocial;
	private BigInteger idFaturamentoPresumido;
	private BigInteger idPatrimonio;
	private BigInteger idRenda;
	private SimNaoEnum idSeguradoPEP;
	private String numeroPropostaCorretor;
	
	private String tipoDocumento;
	private String orgaoEmissorSSV;
	private String escolaridade;
	private Long controlador;
	private Long quantidadeControlador;
	private Long ramoAtividade;
	private Long tipoEmpresa;
	private Long patrimonioLiquido;
	private Long receita;
	
	private Integer idRelacaoPagadorDebito;

	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy",timezone = "America/Sao_Paulo")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dataConversaoValorRisco;

	private BigDecimal coeficienteConversaoMoeda;

	private TipoEndossoEnum idTipoEndosso;
	private Long cdEndosEndso;
	private Long cdTipoEndosEndso;
	private SolicitanteEndossoEnum idSolicitanteEndosso;
	private Integer codigoRamoProdutoEndossada;
	private Long codigoApoliceEndossada;

	private SexoEnum idTipoSexo;
	private EstadoCivilEnum idEstadoCivil;
	private FormaDevolucaoApoliceEnum codigoFormaDevolucao;
	private Integer idFormaDevolucao;
	private Integer numeroBancoDevolucao;
	private Long numeroAgenciaDevolucao;
	private Integer numeroDigitoAgenciaDevolucao;
	private Long numeroContaCorrenteDevolucao;
	private String numeroDigitoContaCorrenteDevolucao;

	private TipoPedidoCotacaoEnum idTipoPedidoCotacao;
	private TipoEndossoSctEnum codigoTipoEndossoSCT;
	private TipoEndossoSctEnum endossoSCT;
	private Integer codigoSituacaoReadOnly;
	private String emailCorretorInspecao;

	private SimNaoEnum liberaLMR;
	private String valorPremioInformado;

	List<FormaDevolucaoApoliceEnum> formasDevolucaoLiberadas  = new ArrayList<>();
	
	List<FormaDevolucaoCliente> formasDevolucaoClienteLiberadas  = new ArrayList<>();

	private List<ItemCotacaoView> listItem = new ArrayList<>();

	private List<ItemCotacaoPremioFranquiaView> listItemPremioFranquia = new ArrayList<>();
	
	private boolean salvarCotacao;
	
	private SimNaoEnum comissaoAntecipada;
	
	private DestinoEmissaoEnum idDestinoEmissao;
	
	private SimNaoEnum alterarFormaPagamento;
	
	private Integer formaPagamentoAlteracao;
	
	private String numeroAgenciaVendedora;

	private String numeroContaCorrenteVendedora;

	private String numeroMatriculaVendedor;

	public List<FormaDevolucaoApoliceEnum> getFormasDevolucaoLiberadas() {
		return formasDevolucaoLiberadas;
	}

	public void setFormasDevolucaoLiberadas(List<FormaDevolucaoApoliceEnum> formasDevolucaoLiberadas) {
		this.formasDevolucaoLiberadas = formasDevolucaoLiberadas;
	}
	
	

	public List<FormaDevolucaoCliente> getFormasDevolucaoClienteLiberadas() {
		return formasDevolucaoClienteLiberadas;
	}

	public void setFormasDevolucaoClienteLiberadas(List<FormaDevolucaoCliente> formasDevolucaoClienteLiberadas) {
		this.formasDevolucaoClienteLiberadas = formasDevolucaoClienteLiberadas;
	}

	public String getIdCEPSegurado() {
		if (idCEPSegurado != null && !idCEPSegurado.isEmpty()) {
			try {
				idCEPSegurado = StringUtils.leftPad(idCEPSegurado.replaceAll("-",""),8,"0");
			} catch (Exception e) {
				idCEPSegurado = null;
			}
		} else {
			idCEPSegurado = null;
		}
		return idCEPSegurado;
	}

	public void setIdCEPSegurado(String idCEPSegurado) {
		this.idCEPSegurado = idCEPSegurado;
	}

	public Long getIdCEPSeguradoNumero() {
		if (getIdCEPSegurado() != null && !getIdCEPSegurado().isEmpty()) {
			return Long.valueOf(idCEPSegurado);
		} else {
			return null;
		}
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	public Date getDataCotacao() {
		return dataCotacao;
	}

	public void setDataCotacao(Date dataCotacao) {
		this.dataCotacao = dataCotacao;
	}

	public Long getNumeroCNPJCPFSegurado() {
		if (idTipoPessoa == TipoSeguradoEnum.FISICA && !StringUtils.isEmpty(cpfSegurado)) {
			numeroCNPJCPFSegurado = Long.valueOf(CnpjCpfUtil.getInstance().cleanCpf(cpfSegurado));
			return numeroCNPJCPFSegurado;
		} else if (idTipoPessoa == TipoSeguradoEnum.JURIDICA && !StringUtils.isEmpty(cnpjSegurado)) {
			numeroCNPJCPFSegurado = Long.valueOf(CnpjCpfUtil.getInstance().cleanCNPJ(cnpjSegurado));
			return numeroCNPJCPFSegurado;
		}

		return null;
	}

	public void setNumeroCNPJCPFSegurado(Long numeroCNPJCPFSegurado) {
		this.numeroCNPJCPFSegurado = numeroCNPJCPFSegurado;
	}

	public TipoSeguradoEnum getIdTipoPessoa() {
		return idTipoPessoa;
	}

	public void setIdTipoPessoa(TipoSeguradoEnum idTipoPessoa) {
		this.idTipoPessoa = idTipoPessoa;
	}

	public String getNomeSegurado() {
		if (idTipoPessoa == TipoSeguradoEnum.FISICA) {
			setNomeSegurado(nomeSeguradoPF);
		} else {
			setNomeSegurado(nomeSeguradoPJ);
		}
		return nomeSegurado;
	}

	public void setNomeSegurado(String nomeSegurado) {
		this.nomeSegurado = nomeSegurado;
	}

	public Integer getCodigoAtividadePrincipal() {
		return codigoAtividadePrincipal;
	}

	public void setCodigoAtividadePrincipal(Integer codigoAtividadePrincipal) {
		this.codigoAtividadePrincipal = codigoAtividadePrincipal;
	}

	public String getDescricaoAtividadePrincipal() {
		return descricaoAtividadePrincipal;
	}

	public void setDescricaoAtividadePrincipal(String descricaoAtividadePrincipal) {
		this.descricaoAtividadePrincipal = descricaoAtividadePrincipal;
	}

	public String getEnderecoSegurado() {
		return enderecoSegurado;
	}

	public void setEnderecoSegurado(String enderecoSegurado) {
		this.enderecoSegurado = enderecoSegurado;
	}

	public String getNomeBairroSegurado() {
		return nomeBairroSegurado;
	}

	public void setNomeBairroSegurado(String nomeBairroSegurado) {
		this.nomeBairroSegurado = nomeBairroSegurado;
	}

	public Long getNumeroEnderecoSegurado() {
		return numeroEnderecoSegurado;
	}

	public void setNumeroEnderecoSegurado(Long numeroEnderecoSegurado) {
		this.numeroEnderecoSegurado = numeroEnderecoSegurado;
	}

	public String getNomeComplementoEnderecoSegurado() {
		return nomeComplementoEnderecoSegurado;
	}

	public void setNomeComplementoEnderecoSegurado(String nomeComplementoEnderecoSegurado) {
		this.nomeComplementoEnderecoSegurado = nomeComplementoEnderecoSegurado;
	}

	public String getNomeMunicipioSegurado() {
		return nomeMunicipioSegurado;
	}

	public void setNomeMunicipioSegurado(String nomeMunicipioSegurado) {
		this.nomeMunicipioSegurado = nomeMunicipioSegurado;
	}

	public String getIdUFSegurado() {
		return idUFSegurado;
	}

	public void setIdUFSegurado(String idUFSegurado) {
		this.idUFSegurado = idUFSegurado;
	}

	public String getIdEmailSegurado() {
		return idEmailSegurado;
	}

	public void setIdEmailSegurado(String idEmailSegurado) {
		this.idEmailSegurado = idEmailSegurado;
	}

	public Integer getNumeroDDDSegurado() {
		if (!StringUtils.isEmpty(telefoneSegurado)) { return Integer.valueOf(telefoneSegurado.replace(")","").replace("-","").replace("(","").replace(" ","").substring(0,2)); }
		return numeroDDDSegurado;
	}

	public void setNumeroDDDSegurado(Integer numeroDDDSegurado) {
		this.numeroDDDSegurado = numeroDDDSegurado;
	}

	public Long getNumeroTelefoneSegurado() {
		if (!StringUtils.isEmpty(telefoneSegurado)) {
			String telefoneCompleto = telefoneSegurado.replace(")","").replace("-","").replace("(","").replace(" ","");
			return Long.valueOf(telefoneCompleto.substring(2,telefoneCompleto.length()));
		}
		return numeroTelefoneSegurado;
	}

	public void setNumeroTelefoneSegurado(Long numeroTelefoneSegurado) {
		this.numeroTelefoneSegurado = numeroTelefoneSegurado;
	}

	public Integer getNumeroDDDCelularSegurado() {
		if (!StringUtils.isEmpty(celularSegurado)) { return Integer.valueOf(celularSegurado.replace(")","").replace("-","").replace("(","").replace(" ","").substring(0,2)); }
		return numeroDDDCelularSegurado;
	}

	public void setNumeroDDDCelularSegurado(Integer numeroDDDCelularSegurado) {
		this.numeroDDDCelularSegurado = numeroDDDCelularSegurado;
	}

	public Long getNumeroCelularSegurado() {
		if (!StringUtils.isEmpty(celularSegurado)) {
			String celularCompleto = celularSegurado.replace(")","").replace("-","").replace("(","").replace(" ","");
			return Long.valueOf(celularCompleto.substring(2,celularCompleto.length()));
		}
		return numeroCelularSegurado;
	}

	public void setNumeroCelularSegurado(Long numeroCelularSegurado) {
		this.numeroCelularSegurado = numeroCelularSegurado;
	}

	public TipoSeguroEnum getIdTipoSeguro() {
		return idTipoSeguro;
	}

	public void setIdTipoSeguro(TipoSeguroEnum idTipoSeguro) {
		this.idTipoSeguro = idTipoSeguro;
	}

	public Integer getCodigoCompanhiaSeguradora() {
		return codigoCompanhiaSeguradora;
	}

	public void setCodigoCompanhiaSeguradora(Integer codigoCompanhiaSeguradora) {
		this.codigoCompanhiaSeguradora = codigoCompanhiaSeguradora;
	}

	public String getNumeroApoliceCongenere() {
		return numeroApoliceCongenere;
	}

	public void setNumeroApoliceCongenere(String numeroApoliceCongenere) {
		this.numeroApoliceCongenere = numeroApoliceCongenere;
	}

	public Integer getCodigoLocal() {
		return codigoLocal;
	}

	public void setCodigoLocal(Integer codigoLocal) {
		this.codigoLocal = codigoLocal;
	}

	public Integer getCodigoSubLocal() {
		return codigoSubLocal;
	}

	public void setCodigoSubLocal(Integer codigoSubLocal) {
		this.codigoSubLocal = codigoSubLocal;
	}

	public String getNomeSubLocal() {
		return nomeSubLocal;
	}

	public void setNomeSubLocal(String nomeSubLocal) {
		this.nomeSubLocal = nomeSubLocal;
	}

	public String getCodigoCorretorACSEL() {
		return codigoCorretorACSEL;
	}

	public void setCodigoCorretorACSEL(String codigoCorretorACSEL) {
		this.codigoCorretorACSEL = codigoCorretorACSEL;
	}

	public Long getNumeroCNPJCPFCorretor() {
		return numeroCNPJCPFCorretor;
	}

	public void setNumeroCNPJCPFCorretor(Long numeroCNPJCPFCorretor) {
		this.numeroCNPJCPFCorretor = numeroCNPJCPFCorretor;
	}

	public String getNomeCorretor() {
		return nomeCorretor;
	}

	public void setNomeCorretor(String nomeCorretor) {
		this.nomeCorretor = nomeCorretor;
	}

	public Integer getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(Integer codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getNumeroProcessoSUSEP() {
		return numeroProcessoSUSEP;
	}

	public void setNumeroProcessoSUSEP(String numeroProcessoSUSEP) {
		this.numeroProcessoSUSEP = numeroProcessoSUSEP;
	}

	public Date getDataInicioVigencia() {
		return dataInicioVigencia;
	}

	public void setDataInicioVigencia(Date dataInicioVigencia) {
		this.dataInicioVigencia = dataInicioVigencia;
	}

	public String getValorDataInicioVigencia() {
		if (dataInicioVigencia != null) { return DateUtil.formataSemHora(dataInicioVigencia); }
		return StringUtils.EMPTY;
	}

	public Date getDataFimVigencia() {
		return dataFimVigencia;
	}

	public void setDataFimVigencia(Date dataFimVigencia) {
		this.dataFimVigencia = dataFimVigencia;
	}

	public String getValorDataFimVigencia() {
		if (dataFimVigencia != null) { return DateUtil.formataSemHora(dataFimVigencia); }
		return StringUtils.EMPTY;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public PrazoVigenciaEnum getIdPrazoVigencia() {
		return idPrazoVigencia;
	}

	public void setIdPrazoVigencia(PrazoVigenciaEnum idPrazoVigencia) {
		this.idPrazoVigencia = idPrazoVigencia;
	}

	public Boolean getIdResseguroFacultativo() {
		return idResseguroFacultativo;
	}

	public void setIdResseguroFacultativo(Boolean idResseguroFacultativo) {
		this.idResseguroFacultativo = idResseguroFacultativo;
	}

	public String getValorPremioLiquido() {
		return valorPremioLiquido;
	}

	public void setValorPremioLiquido(String valorPremioLiquido) {
		this.valorPremioLiquido = valorPremioLiquido;
	}

	public MoedaEnum getCodigoMoeda() {
		return codigoMoeda;
	}

	public void setCodigoMoeda(MoedaEnum codigoMoeda) {
		this.codigoMoeda = codigoMoeda;
	}

	public String getTelefoneSegurado() {
		return telefoneSegurado;
	}

	public void setTelefoneSegurado(String telefoneSegurado) {
		this.telefoneSegurado = telefoneSegurado;
	}

	public String getCelularSegurado() {
		return celularSegurado;
	}

	public void setCelularSegurado(String celularSegurado) {
		this.celularSegurado = celularSegurado;
	}

	public String getCpfSegurado() {
		return StringUtils.leftPad(cpfSegurado,11,"0");
	}

	public void setCpfSegurado(String cpfSegurado) {
		this.cpfSegurado = cpfSegurado;
	}

	public String getCnpjSegurado() {
		return StringUtils.leftPad(cnpjSegurado,14,"0");
	}

	public void setCnpjSegurado(String cnpjSegurado) {
		this.cnpjSegurado = cnpjSegurado;
	}

	public String getNomeSeguradoPF() {
		return nomeSeguradoPF;
	}

	public void setNomeSeguradoPF(String nomeSeguradoPF) {
		this.nomeSeguradoPF = nomeSeguradoPF;
	}

	public String getNomeSeguradoPJ() {
		return nomeSeguradoPJ;
	}

	public void setNomeSeguradoPJ(String nomeSeguradoPJ) {
		this.nomeSeguradoPJ = nomeSeguradoPJ;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public Integer getVersaoCotacaoProposta() {
		return versaoCotacaoProposta;
	}

	public void setVersaoCotacaoProposta(Integer versaoCotacaoProposta) {
		this.versaoCotacaoProposta = versaoCotacaoProposta;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public String getPercentualComissao() {
		return percentualComissao;
	}

	public String getNumeroRG() {
		return numeroRG;
	}

	public void setNumeroRG(String numeroRG) {
		this.numeroRG = numeroRG;
	}

	public String getNomeOrgaoExpedidor() {
		return nomeOrgaoExpedidor;
	}

	public void setNomeOrgaoExpedidor(String nomeOrgaoExpedidor) {
		this.nomeOrgaoExpedidor = nomeOrgaoExpedidor;
	}

	public Date getDataExpedicao() {
		if (dataExpedicao != null) { return new Date(dataExpedicao.getTime()); }
		return null;
	}

	public void setDataExpedicao(Date dataExpedicao) {
		this.dataExpedicao = dataExpedicao;
	}

	public String getValorDataExpedicao() {
		if (dataExpedicao != null) { return DateUtil.formataSemHora(dataExpedicao); }
		return StringUtils.EMPTY;
	}

	public Date getDataNascimentoCliente() {
		if (dataNascimentoCliente != null) { return new Date(dataNascimentoCliente.getTime()); }
		return null;
	}

	public void setDataNascimentoCliente(Date dataNascimentoCliente) {
		this.dataNascimentoCliente = dataNascimentoCliente;
	}

	public String getValorDataNascimentoCliente() {
		if (dataNascimentoCliente != null) { return DateUtil.formataSemHora(dataNascimentoCliente); }
		return StringUtils.EMPTY;
	}

	public Integer getNumeroBancoDebito() {
		return numeroBancoDebito;
	}

	public void setNumeroBancoDebito(Integer numeroBancoDebito) {
		this.numeroBancoDebito = numeroBancoDebito;
	}

	public Long getNumeroAgenciaDebito() {
		return numeroAgenciaDebito;
	}

	public void setNumeroAgenciaDebito(Long numeroAgenciaDebito) {
		this.numeroAgenciaDebito = numeroAgenciaDebito;
	}

	public String getTipoContaCorrenteDebito() {
		return tipoContaCorrenteDebito;
	}

	public void setTipoContaCorrenteDebito(String tipoContaCorrenteDebito) {
		this.tipoContaCorrenteDebito = tipoContaCorrenteDebito;
	}

	public Integer getNumeroDigitoAgenciaDebito() {
		return numeroDigitoAgenciaDebito;
	}

	public void setNumeroDigitoAgenciaDebito(Integer numeroDigitoAgenciaDebito) {
		this.numeroDigitoAgenciaDebito = numeroDigitoAgenciaDebito;
	}

	public Long getNumeroContaCorrenteDebito() {
		return numeroContaCorrenteDebito;
	}

	public void setNumeroContaCorrenteDebito(Long numeroContaCorrenteDebito) {
		this.numeroContaCorrenteDebito = numeroContaCorrenteDebito;
	}

	public String getNumeroDigitoContaCorrenteDebito() {
		return numeroDigitoContaCorrenteDebito;
	}

	public void setNumeroDigitoContaCorrenteDebito(String numeroDigitoContaCorrenteDebito) {
		this.numeroDigitoContaCorrenteDebito = numeroDigitoContaCorrenteDebito;
	}

	public Integer getNumeroBancoBoleto() {
		return numeroBancoBoleto;
	}

	public void setNumeroBancoBoleto(Integer numeroBancoBoleto) {
		this.numeroBancoBoleto = numeroBancoBoleto;
	}

	public Date getDataVencimentoProgramada() {
		return dataVencimentoProgramada;
	}

	public void setDataVencimentoProgramada(Date dataVencimentoProgramada) {
		this.dataVencimentoProgramada = dataVencimentoProgramada;
	}

	public void setPercentualComissao(String percentualComissao) {
		this.percentualComissao = percentualComissao;
	}

	public String getPercentualDescontoGeral() {
		return percentualDescontoGeral;
	}

	public void setPercentualDescontoGeral(String percentualDescontoGeral) {
		this.percentualDescontoGeral = percentualDescontoGeral;
	}

	public String getPercentualAgravoGeral() {
		return percentualAgravoGeral;
	}

	public void setPercentualAgravoGeral(String percentualAgravoGeral) {
		this.percentualAgravoGeral = percentualAgravoGeral;
	}

	public boolean isCalculo() {
		return calculo;
	}

	public void setCalculo(boolean calculo) {
		this.calculo = calculo;
	}

	public ControleCalculoEnum getIdControleCalculo() {
		return idControleCalculo;
	}

	public void setIdControleCalculo(ControleCalculoEnum idControleCalculo) {
		this.idControleCalculo = idControleCalculo;
	}

	public SimNaoEnum getEstrangeiro() {
		return estrangeiro;
	}

	public void setEstrangeiro(SimNaoEnum estrangeiro) {
		this.estrangeiro = estrangeiro;
	}

	public SimNaoEnum getPossuiRNE() {
		return possuiRNE;
	}

	public void setPossuiRNE(SimNaoEnum possuiRNE) {
		this.possuiRNE = possuiRNE;
	}

	public String getNumeroRNE() {
		return numeroRNE;
	}

	public void setNumeroRNE(String numeroRNE) {
		this.numeroRNE = numeroRNE;
	}

	public String getNumeroPassaporte() {
		return numeroPassaporte;
	}

	public void setNumeroPassaporte(String numeroPassaporte) {
		this.numeroPassaporte = numeroPassaporte;
	}

	public BigInteger getIdPais() {
		return idPais;
	}

	public void setIdPais(BigInteger idPais) {
		this.idPais = idPais;
	}

	public BigInteger getIdProfissao() {
		return idProfissao;
	}

	public void setIdProfissao(BigInteger idProfissao) {
		this.idProfissao = idProfissao;
	}

	public BigInteger getIdCapitalSocial() {
		return idCapitalSocial;
	}

	public void setIdCapitalSocial(BigInteger idCapitalSocial) {
		this.idCapitalSocial = idCapitalSocial;
	}

	public BigInteger getIdFaturamentoPresumido() {
		return idFaturamentoPresumido;
	}

	public void setIdFaturamentoPresumido(BigInteger idFaturamentoPresumido) {
		this.idFaturamentoPresumido = idFaturamentoPresumido;
	}

	public BigInteger getIdPatrimonio() {
		return idPatrimonio;
	}

	public void setIdPatrimonio(BigInteger idPatrimonio) {
		this.idPatrimonio = idPatrimonio;
	}

	public BigInteger getIdRenda() {
		return idRenda;
	}

	public void setIdRenda(BigInteger idRenda) {
		this.idRenda = idRenda;
	}

	public SimNaoEnum getIdSeguradoPEP() {
		return idSeguradoPEP;
	}

	public void setIdSeguradoPEP(SimNaoEnum idSeguradoPEP) {
		this.idSeguradoPEP = idSeguradoPEP;
	}

	public String getNumeroPropostaCorretor() {
		return numeroPropostaCorretor;
	}

	public void setNumeroPropostaCorretor(String numeroPropostaCorretor) {
		this.numeroPropostaCorretor = numeroPropostaCorretor;
	}

	public String getNomeAgenciaDebito() {
		return nomeAgenciaDebito;
	}

	public void setNomeAgenciaDebito(String nomeAgenciaDebito) {
		this.nomeAgenciaDebito = nomeAgenciaDebito;
	}

	public String getNumeroTelefoneAgencia() {
		return numeroTelefoneAgencia;
	}

	public void setNumeroTelefoneAgencia(String numeroTelefoneAgencia) {
		this.numeroTelefoneAgencia = numeroTelefoneAgencia;
	}

	public String getNomeCidadeAgencia() {
		return nomeCidadeAgencia;
	}

	public void setNomeCidadeAgencia(String nomeCidadeAgencia) {
		this.nomeCidadeAgencia = nomeCidadeAgencia;
	}

	public String getNomeBairroAgencia() {
		return nomeBairroAgencia;
	}

	public void setNomeBairroAgencia(String nomeBairroAgencia) {
		this.nomeBairroAgencia = nomeBairroAgencia;
	}

	public String getIdCepAgencia() {
		return idCepAgencia;
	}

	public void setIdCepAgencia(String idCepAgencia) {
		this.idCepAgencia = idCepAgencia;
	}

	public String getEnderecoAgencia() {
		return enderecoAgencia;
	}

	public void setEnderecoAgencia(String enderecoAgencia) {
		this.enderecoAgencia = enderecoAgencia;
	}

	public Date getDataConversaoValorRisco() {
		return dataConversaoValorRisco;
	}

	public void setDataConversaoValorRisco(Date dataConversaoValorRisco) {
		this.dataConversaoValorRisco = dataConversaoValorRisco;
	}

	public BigDecimal getCoeficienteConversaoMoeda() {
		return coeficienteConversaoMoeda;
	}

	public void setCoeficienteConversaoMoeda(BigDecimal coeficienteConversaoMoeda) {
		this.coeficienteConversaoMoeda = coeficienteConversaoMoeda;
	}

	public Date getDataCalculo() {
		return dataCalculo;
	}

	public void setDataCalculo(Date dataCalculo) {
		this.dataCalculo = dataCalculo;
	}

	public List<ItemCotacaoView> getListItem() {
		return listItem;
	}

	public void setListItem(List<ItemCotacaoView> listItem) {
		this.listItem = listItem;
	}

	public Long getCdEndosEndso() {
		return cdEndosEndso;
	}

	public void setCdEndosEndso(Long cdEndosEndso) {
		this.cdEndosEndso = cdEndosEndso;
	}

	public Long getCdTipoEndosEndso() {
		return cdTipoEndosEndso;
	}

	public void setCdTipoEndosEndso(Long cdTipoEndosEndso) {
		this.cdTipoEndosEndso = cdTipoEndosEndso;
	}

	public TipoEndossoEnum getIdTipoEndosso() {
		return idTipoEndosso;
	}

	public void setIdTipoEndosso(TipoEndossoEnum idTipoEndosso) {
		this.idTipoEndosso = idTipoEndosso;
	}

	public Integer getCodigoRamoProdutoEndossada() {
		return codigoRamoProdutoEndossada;
	}

	public void setCodigoRamoProdutoEndossada(Integer codigoRamoProdutoEndossada) {
		this.codigoRamoProdutoEndossada = codigoRamoProdutoEndossada;
	}

	public Long getCodigoApoliceEndossada() {
		return codigoApoliceEndossada;
	}

	public void setCodigoApoliceEndossada(Long codigoApoliceEndossada) {
		this.codigoApoliceEndossada = codigoApoliceEndossada;
	}

	public SolicitanteEndossoEnum getIdSolicitanteEndosso() {
		return idSolicitanteEndosso;
	}

	public void setIdSolicitanteEndosso(SolicitanteEndossoEnum idSolicitanteEndosso) {
		this.idSolicitanteEndosso = idSolicitanteEndosso;
	}

	public SexoEnum getIdTipoSexo() {
		return idTipoSexo;
	}

	public void setIdTipoSexo(SexoEnum idTipoSexo) {
		this.idTipoSexo = idTipoSexo;
	}
	
	public String getTipoSexo() {
		
		if(idTipoSexo == null) {
			return null;
		}
		
		return idTipoSexo.equals(SexoEnum.FEMININO) ? "F" : "M";
	}
	
	public void setTipoSexo(String tipoSexo) {
		if(tipoSexo == null || tipoSexo.equals("")) {
			this.idTipoSexo = null;
		} else {
			this.idTipoSexo = tipoSexo.equals("F") ? SexoEnum.FEMININO : SexoEnum.MASCULINO;	
		}
	}
	
	public String getEstadoCivil() {
		if(idEstadoCivil == null) {
			return null;
		}
		
		return idEstadoCivil.getId();
	}
	
	public void setEstadoCivil(String estadoCivil) {
		this.idEstadoCivil = EstadoCivilEnum.getById(estadoCivil);
	}

	public EstadoCivilEnum getIdEstadoCivil() {
		return idEstadoCivil;
	}

	public void setIdEstadoCivil(EstadoCivilEnum idEstadoCivil) {
		this.idEstadoCivil = idEstadoCivil;
	}

	public FormaDevolucaoApoliceEnum getCodigoFormaDevolucao() {
		return codigoFormaDevolucao;
	}

	public void setCodigoFormaDevolucao(FormaDevolucaoApoliceEnum codigoFormaDevolucao) {
		this.codigoFormaDevolucao = codigoFormaDevolucao;
	}
	
	

	public Integer getIdFormaDevolucao() {
		return idFormaDevolucao;
	}

	public void setIdFormaDevolucao(Integer idFormaDevolucao) {
		this.idFormaDevolucao = idFormaDevolucao;
		this.codigoFormaDevolucao = FormaDevolucaoApoliceEnum.getById(idFormaDevolucao);
	}

	public Integer getNumeroBancoDevolucao() {
		return numeroBancoDevolucao;
	}

	public void setNumeroBancoDevolucao(Integer numeroBancoDevolucao) {
		this.numeroBancoDevolucao = numeroBancoDevolucao;
	}

	public Long getNumeroAgenciaDevolucao() {
		return numeroAgenciaDevolucao;
	}

	public void setNumeroAgenciaDevolucao(Long numeroAgenciaDevolucao) {
		this.numeroAgenciaDevolucao = numeroAgenciaDevolucao;
	}

	public Integer getNumeroDigitoAgenciaDevolucao() {
		return numeroDigitoAgenciaDevolucao;
	}

	public void setNumeroDigitoAgenciaDevolucao(Integer numeroDigitoAgenciaDevolucao) {
		this.numeroDigitoAgenciaDevolucao = numeroDigitoAgenciaDevolucao;
	}

	public Long getNumeroContaCorrenteDevolucao() {
		return numeroContaCorrenteDevolucao;
	}

	public void setNumeroContaCorrenteDevolucao(Long numeroContaCorrenteDevolucao) {
		this.numeroContaCorrenteDevolucao = numeroContaCorrenteDevolucao;
	}

	public String getNumeroDigitoContaCorrenteDevolucao() {
		return numeroDigitoContaCorrenteDevolucao;
	}

	public void setNumeroDigitoContaCorrenteDevolucao(String numeroDigitoContaCorrenteDevolucao) {
		this.numeroDigitoContaCorrenteDevolucao = numeroDigitoContaCorrenteDevolucao;
	}

	public TipoPedidoCotacaoEnum getIdTipoPedidoCotacao() {
		return idTipoPedidoCotacao;
	}

	public void setIdTipoPedidoCotacao(TipoPedidoCotacaoEnum idTipoPedidoCotacao) {
		this.idTipoPedidoCotacao = idTipoPedidoCotacao;
	}

	public TipoEndossoSctEnum getCodigoTipoEndossoSCT() {
		return codigoTipoEndossoSCT;
	}

	public void setCodigoTipoEndossoSCT(TipoEndossoSctEnum codigoTipoEndossoSCT) {
		this.codigoTipoEndossoSCT = codigoTipoEndossoSCT;
	}

	public TipoEndossoSctEnum getEndossoSCT() {
		return endossoSCT;
	}

	public void setEndossoSCT(TipoEndossoSctEnum endossoSCT) {
		this.endossoSCT = endossoSCT;
	}

	public Boolean getIdIsencaoImposto() {
		return idIsencaoImposto;
	}

	public void setIdIsencaoImposto(Boolean idIsencaoImposto) {
		this.idIsencaoImposto = idIsencaoImposto;
	}

	public Integer getCodigoSituacaoReadOnly() {
		return codigoSituacaoReadOnly;
	}

	public void setCodigoSituacaoReadOnly(Integer codigoSituacaoReadOnly) {
		this.codigoSituacaoReadOnly = codigoSituacaoReadOnly;
	}

	public String getEmailCorretorInspecao() {
		return emailCorretorInspecao;
	}

	public void setEmailCorretorInspecao(String emailCorretorInspecao) {
		this.emailCorretorInspecao = emailCorretorInspecao;
	}

	public List<ItemCotacaoPremioFranquiaView> getListItemPremioFranquia() {
		return listItemPremioFranquia;
	}

	public void setListItemPremioFranquia(List<ItemCotacaoPremioFranquiaView> listItemPremioFranquia) {
		this.listItemPremioFranquia = listItemPremioFranquia;
	}

	public SimNaoEnum getLiberaLMR() {
		return liberaLMR;
	}

	public void setLiberaLMR(SimNaoEnum liberaLMR) {
		this.liberaLMR = liberaLMR;
	}

	public boolean isSalvarCotacao() {
		return salvarCotacao;
	}

	public void setSalvarCotacao(boolean salvarCotacao) {
		this.salvarCotacao = salvarCotacao;
	}
	public Integer getCodigoNicho() {
		return codigoNicho;
	}
	public void setCodigoNicho(Integer codigoNicho) {
		this.codigoNicho = codigoNicho;
	}
	
	public SimNaoEnum getComissaoAntecipada() {
		return comissaoAntecipada;
	}
	
	public void setComissaoAntecipada(SimNaoEnum propostaAntecipada) {
		this.comissaoAntecipada = propostaAntecipada;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getOrgaoEmissorSSV() {
		return orgaoEmissorSSV;
	}

	public void setOrgaoEmissorSSV(String orgaoEmissorSSV) {
		this.orgaoEmissorSSV = orgaoEmissorSSV;
	}

	public String getEscolaridade() {
		return escolaridade;
	}

	public void setEscolaridade(String escolaridade) {
		this.escolaridade = escolaridade;
	}

	public Long getControlador() {
		return controlador;
	}

	public void setControlador(Long controlador) {
		this.controlador = controlador;
	}

	public Long getQuantidadeControlador() {
		return quantidadeControlador;
	}

	public void setQuantidadeControlador(Long quantidadeControlador) {
		this.quantidadeControlador = quantidadeControlador;
	}

	public Long getRamoAtividade() {
		return ramoAtividade;
	}

	public void setRamoAtividade(Long ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}

	public Long getTipoEmpresa() {
		return tipoEmpresa;
	}

	public void setTipoEmpresa(Long tipoEmpresa) {
		this.tipoEmpresa = tipoEmpresa;
	}

	public Long getPatrimonioLiquido() {
		return patrimonioLiquido;
	}

	public void setPatrimonioLiquido(Long patrimonioLiquido) {
		this.patrimonioLiquido = patrimonioLiquido;
	}

	public Long getReceita() {
		return receita;
	}

	public void setReceita(Long receita) {
		this.receita = receita;
	}
	
	public DestinoEmissaoEnum getIdDestinoEmissao() {
		return idDestinoEmissao;
	}

	public void setIdDestinoEmissao(DestinoEmissaoEnum idDestinoEmissao) {
		this.idDestinoEmissao = idDestinoEmissao;
	}

	public Integer getIdRelacaoPagadorDebito() {
		return idRelacaoPagadorDebito;
	}

	public void setIdRelacaoPagadorDebito(Integer idRelacaoPagadorDebito) {
		this.idRelacaoPagadorDebito = idRelacaoPagadorDebito;
	}

	
	
	public TipoSeguradoEnum getTipoPessoaTitularContaCorrenteDebito() {
		return tipoPessoaTitularContaCorrenteDebito;
	}

	public void setTipoPessoaTitularContaCorrenteDebito(String tipoPessoaTitularContaCorrenteDebito) {
		this.tipoPessoaTitularContaCorrenteDebito = TipoSeguradoEnum.getById(tipoPessoaTitularContaCorrenteDebito);
	}
	
	public TipoSeguradoEnum getTipoPessoaTitularContaCorrenteDevolucao() {
		return tipoPessoaTitularContaCorrenteDevolucao;
	}

	public void setTipoPessoaTitularContaCorrenteDevolucao(String tipoPessoaTitularContaCorrenteDevolucao) {
		this.tipoPessoaTitularContaCorrenteDevolucao = TipoSeguradoEnum.getById(tipoPessoaTitularContaCorrenteDevolucao);
	}
	
	

	public SimNaoEnum getPrimeiraParcelaDebito() {
		return primeiraParcelaDebito;
	}

	public String getPrimeiraParclDebit() {
		return primeiraParclDebit;
	}

	public void setPrimeiraParclDebit(String primeiraParclDebit) {
		this.primeiraParclDebit = primeiraParclDebit;
		this.primeiraParcelaDebito = SimNaoEnum.getById(primeiraParclDebit);
	}

	public Long getNumeroCNPJCPFTitularContaCorrenteDebito() {		
		if(cnpjCpfTitularContaCorrenteDebito == null) {
			return null;
		}
		
		if(tipoPessoaTitularContaCorrenteDebito == TipoSeguradoEnum.FISICA) {
			numeroCNPJCPFTitularContaCorrenteDebito = Long.valueOf(CnpjCpfUtil.getInstance().cleanCpf(cnpjCpfTitularContaCorrenteDebito));
			return numeroCNPJCPFTitularContaCorrenteDebito;
		}
		
		numeroCNPJCPFTitularContaCorrenteDebito = Long.valueOf(CnpjCpfUtil.getInstance().cleanCNPJ(cnpjCpfTitularContaCorrenteDebito));
		return numeroCNPJCPFTitularContaCorrenteDebito;
	}

	public void setNumeroCNPJCPFTitularContaCorrenteDebito(Long numeroCNPJCPFTitularContaCorrenteDebito) {
		this.numeroCNPJCPFTitularContaCorrenteDebito = numeroCNPJCPFTitularContaCorrenteDebito;
	}
	
	public Long getNumeroCNPJCPFTitularContaCorrenteDevolucao() {		
		if(cnpjCpfTitularContaCorrenteDevolucao == null) {
			return null;
		}
		
		if(tipoPessoaTitularContaCorrenteDevolucao == TipoSeguradoEnum.FISICA) {
			numeroCNPJCPFTitularContaCorrenteDevolucao = Long.valueOf(CnpjCpfUtil.getInstance().cleanCpf(cnpjCpfTitularContaCorrenteDevolucao));
			return numeroCNPJCPFTitularContaCorrenteDevolucao;
		}
		
		numeroCNPJCPFTitularContaCorrenteDevolucao = Long.valueOf(CnpjCpfUtil.getInstance().cleanCNPJ(cnpjCpfTitularContaCorrenteDevolucao));
		return numeroCNPJCPFTitularContaCorrenteDevolucao;
	}

	public void setNumeroCNPJCPFTitularContaCorrenteDevolucao(Long numeroCNPJCPFTitularContaCorrenteDevolucao) {
		this.numeroCNPJCPFTitularContaCorrenteDevolucao = numeroCNPJCPFTitularContaCorrenteDevolucao;
		if(numeroCNPJCPFTitularContaCorrenteDevolucao != null) {
			this.cnpjCpfTitularContaCorrenteDevolucao = numeroCNPJCPFTitularContaCorrenteDevolucao.toString();
		}
		
	}
	
	public String getNometitularContaCorrenteDebito() {
		return nometitularContaCorrenteDebito;
	}

	public void setNometitularContaCorrenteDebito(String nometitularContaCorrenteDebito) {
		this.nometitularContaCorrenteDebito = nometitularContaCorrenteDebito;
	}
	
	

	public String getNometitularContaCorrenteDevolucao() {
		return nometitularContaCorrenteDevolucao;
	}

	public void setNometitularContaCorrenteDevolucao(String nometitularContaCorrenteDevolucao) {
		this.nometitularContaCorrenteDevolucao = nometitularContaCorrenteDevolucao;
	}

	public void setTipoPessoaTitularContaCorrenteDevolucao(TipoSeguradoEnum tipoPessoaTitularContaCorrenteDevolucao) {
		this.tipoPessoaTitularContaCorrenteDevolucao = tipoPessoaTitularContaCorrenteDevolucao;
	}

	public String getCnpjCpfTitularContaCorrenteDebito() {
		if(cnpjCpfTitularContaCorrenteDebito == null) {
			return null;
		}
		
		if(tipoPessoaTitularContaCorrenteDebito == TipoSeguradoEnum.FISICA) {
			return CnpjCpfUtil.getInstance().formataCPFString(StringUtils.leftPad(cnpjCpfTitularContaCorrenteDebito,11,"0"));
		}
		return CnpjCpfUtil.getInstance().formataCNPJString(StringUtils.leftPad(cnpjCpfTitularContaCorrenteDebito,14,"0"));
	}

	public void setCnpjCpfTitularContaCorrenteDebito(String cnpjCpfTitularContaCorrenteDebito) {
		this.cnpjCpfTitularContaCorrenteDebito = cnpjCpfTitularContaCorrenteDebito;
	}
	
	public String getCnpjCpfTitularContaCorrenteDevolucao() {
		if(cnpjCpfTitularContaCorrenteDevolucao == null) {
			return null;
		}
		
		if(tipoPessoaTitularContaCorrenteDevolucao == TipoSeguradoEnum.FISICA) {
			return CnpjCpfUtil.getInstance().formataCPFString(StringUtils.leftPad(cnpjCpfTitularContaCorrenteDevolucao,11,"0"));
		}
		return CnpjCpfUtil.getInstance().formataCNPJString(StringUtils.leftPad(cnpjCpfTitularContaCorrenteDevolucao,14,"0"));
	}

	public void setCnpjCpfTitularContaCorrenteDevolucao(String cnpjCpfTitularContaCorrenteDevolucao) {
		this.cnpjCpfTitularContaCorrenteDevolucao = cnpjCpfTitularContaCorrenteDevolucao;
	}

	public Long getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(Long codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getSiglaPais() {
		return siglaPais;
	}

	public void setSiglaPais(String siglaPais) {
		this.siglaPais = siglaPais;
	}

	public String getValorPremioInformado() {
		return valorPremioInformado;
	}

	public void setValorPremioInformado(String valorPremioInformado) {
		this.valorPremioInformado = valorPremioInformado;
	}

	public SimNaoEnum getAlterarFormaPagamento() {
		return alterarFormaPagamento;
	}

	public void setAlterarFormaPagamento(SimNaoEnum alterarFormaPagamento) {
		this.alterarFormaPagamento = alterarFormaPagamento;
	}

	public Integer getFormaPagamentoAlteracao() {
		return formaPagamentoAlteracao;
	}

	public void setFormaPagamentoAlteracao(Integer formaPagamentoAlteracao) {
		this.formaPagamentoAlteracao = formaPagamentoAlteracao;
	}

	public String getNumeroAgenciaVendedora() {
		return numeroAgenciaVendedora;
	}

	public void setNumeroAgenciaVendedora(String numeroAgenciaVendedora) {
		this.numeroAgenciaVendedora = numeroAgenciaVendedora;
	}

	public String getNumeroContaCorrenteVendedora() {
		return numeroContaCorrenteVendedora;
	}

	public void setNumeroContaCorrenteVendedora(String numeroContaCorrenteVendedora) {
		this.numeroContaCorrenteVendedora = numeroContaCorrenteVendedora;
	}

	public String getNumeroMatriculaVendedor() {
		return numeroMatriculaVendedor;
	}

	public void setNumeroMatriculaVendedor(String numeroMatriculaVendedor) {
		this.numeroMatriculaVendedor = numeroMatriculaVendedor;
	}
}