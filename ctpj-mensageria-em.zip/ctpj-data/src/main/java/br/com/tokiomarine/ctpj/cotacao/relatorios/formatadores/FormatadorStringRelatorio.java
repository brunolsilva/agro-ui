package br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores;

/**
 * Responsável por formatar Strings para a exibição em relatórios
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class FormatadorStringRelatorio {	
	
	/**
	 * Retorna String representando o valor passado como parâmetro
	 * 
	 * @param value
	 * @return Uma String representando o objeto passado como parâmetro ou uma String vazia ("") para os casos de null
	 */
	public String asString(Object value){
		return value == null ? "" : value.toString();
	}

}
