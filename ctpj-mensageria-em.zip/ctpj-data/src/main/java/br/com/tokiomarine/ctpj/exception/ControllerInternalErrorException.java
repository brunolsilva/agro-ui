package br.com.tokiomarine.ctpj.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exceção da camada de Controller que representa o erro interno de http status code 500
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
public class ControllerInternalErrorException extends RuntimeException {

	private static final long serialVersionUID = 6756183795065428289L;

	public ControllerInternalErrorException(String message) {
		super(message);
	}

	public ControllerInternalErrorException(String message,Throwable cause) {
		super(message,cause);
	}

	public ControllerInternalErrorException(Throwable cause) {
		super(cause);
	}	
	
}
