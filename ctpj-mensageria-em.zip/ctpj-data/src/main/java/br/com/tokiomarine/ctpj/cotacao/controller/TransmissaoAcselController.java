package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.apolice.service.ParcelamentoApoliceService;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CartaoResponse;
import br.com.tokiomarine.ctpj.cotacao.dto.CartaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.FormaPagamentoBanco;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.DevolucaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.ParcelamentoJaneladoService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.cotacao.service.TransmissaoAcselService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.ParcelamentoJanelado;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.endosso.service.EndossoAlteracaoCadastralTdoService;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.FormaEnvioDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.OpcaoParcelamentoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.BancoService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ResseguradorService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.backoffice.request.ConsultaDataCancelamentoRequest;
import br.com.tokiomarine.ctpj.integracao.backoffice.response.ConsultaDataCancelamentoResponse;
import br.com.tokiomarine.ctpj.integracao.dto.CodigoStringDescricao;
import br.com.tokiomarine.ctpj.integracao.service.SSVService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.ctpj.util.DateUtil;
import br.com.tokiomarine.ctpj.util.RestTemplateUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Controller
@RequestMapping(value = "/transmissao2")
public class TransmissaoAcselController extends AbstractController {

	private static Logger logger = LogManager.getLogger(TransmissaoAcselController.class);	

	@Autowired
	private MailUtilService mailUtilService;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private TransmissaoAcselService transmissaoService;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private BancoService bancoService;
	
	@Autowired
	private RecebimentoService recebimentoService;

	@Autowired
	private ResseguradorService resseguradorService;

	@Autowired
	private OpcaoParcelamentoService parcelamentoService;
	
	@Autowired
	private SSVService ssvService;
	
	@Autowired
	private DevolucaoService devolucaoService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private EndossoAlteracaoCadastralTdoService endossoAlteracaoCadastralTdoService;
	
	@Autowired
	private ParcelamentoApoliceService parcelamentoApoliceService;

	@Autowired
	private ParcelamentoJaneladoService parcelamentoJaneladoService;
	
	private RestTemplate restTemplate = RestTemplateUtil.restTemplate();
	
	private static final String DESTINO_CORRESPONDENCIA = "Esta opção estará disponível somente se selecionada a opção “Correio”<br>"+ 
													"1. Segurado: Será enviada uma via para o segurado<br>"+
													"2. Corretor: Será enviada uma via ao corretor<br>"+
													"3. Ambos: Serão enviadas 2 vias. Uma para o segurado e uma para o corretor.";

	private static final String FORMA_ENVIO = "1. Correio (100% dos documentos impressos)<br>"+
											  "2. E-mail (100% dos documentos digitais)";
	
	private static final String AUTORIZACAO_DEBITO = "<div id='divAutorizacaoDebito'>Para pagamento em débito em conta do <strong>Banco do Brasil</strong> ou <strong>Itaú</strong> é necessário realizar autorização do débito, <b>no próximo dia útil</b><br><br>" + 
													"Verifique os procedimentos para esta operação com o banco.<br><br>" + 
													"<b>Importante: informe o celular do segurado para envio de SMS em caso de não autorização</b></div>";

	@GetMapping("/{id}")
	@LogPerformance
	public String index(@PathVariable BigInteger id, Model model) {
		logger.info("Inicio index contratação cotação: " + id);

		Boolean exibeFormaPagamento = false;
		Boolean exibeBotoes = true;
		Boolean exibeEstadoCivil = false;
		try {			
			CotacaoView cabecalhoCotacao = cotacaoService.findCotacaoCabecalho(id);
			if(cabecalhoCotacao.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO) {
				return "/erros/404";
			}
			PropostaView proposta = transmissaoService.carregaDadosProposta(id);
			Cotacao cotacao = cotacaoService.findById(id);
			Recebimento recebimento = recebimentoService.findRecebimentoByNumeroCotacaoProposta(cotacao);
			
			if (cotacao.getValorPremioLiquido() != null) {
				//Verifica se exibe dados do pagamento para endosso
				if ((cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) || ((cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) && (cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0 ))) {
					exibeFormaPagamento = true;
					
				}
			}
			
			if(endossoAlteracaoCadastralTdoService.isAlteracaoDadosCadastraisTdo(cotacao)) {
				parcelamentoApoliceService.atualizarParcelamentoApolice(cotacao);
				model.addAttribute("formasPagamento",endossoAlteracaoCadastralTdoService.carregarFormasPagamento(cotacao)) ;
			}
			
			//Verifica se exibe botões de cobertura, resseguro, ...
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				exibeBotoes = false;				
			}
			//Solicitado pelo Weliton Santana
			if (!SecurityUtils.isCorretor()){
				if (proposta.getCotacao().getIdFaturamentoPresumido() == null){
					proposta.getCotacao().setIdFaturamentoPresumido(new BigInteger("1"));
				}
				if (proposta.getCotacao().getIdCapitalSocial() == null){
					proposta.getCotacao().setIdCapitalSocial(new BigInteger("1"));
				}
			}
			List<CodigoStringDescricao> parentesco = ssvService.getColunaTipo("TP_PRNTC_TTLAR_CC");
			if(TipoSeguradoEnum.FISICA == cotacao.getIdTipoPessoa()) {
				model.addAttribute("parentesco",parentesco);
			} else {
				List<CodigoStringDescricao> retorno = new ArrayList<>();
			    for (CodigoStringDescricao par : parentesco) {
			    	if ((par.getCodigo().equals("70")) || (par.getCodigo().equals("80")) || (par.getCodigo().equals("10")) || (par.getCodigo().equals("99"))) {
			    		retorno.add(par);
			    	}
			    }
			    model.addAttribute("parentesco",retorno);
			}

			if(TipoSeguradoEnum.JURIDICA == cotacao.getIdTipoPessoa()) {
				model.addAttribute("listaCapitalSocial",ssvService.getColunaTipo("VL_PATRI_LIQ"));
				model.addAttribute("listaFaturamentoPresumido",ssvService.getColunaTipo("VL_RECT_OPR_BRUT_ANUAL"));

				model.addAttribute("existeControlador",ssvService.getColunaTipo("EXIST_CONTR_ADM_PROC"));
				model.addAttribute("quantidadeControlador",ssvService.getColunaTipo("QTD_CONTR_ADM_PROC"));
				model.addAttribute("ramoAtividade",ssvService.getColunaTipo("CD_RMATV"));
				model.addAttribute("tipoEmpresa",ssvService.getColunaTipo("TP_EMPR"));
			} else {
				model.addAttribute("listaProfissao",ssvService.getColunaTipo("CD_PROFS"));
				model.addAttribute("listaRenda",ssvService.getColunaTipo("VL_RENDA_MENS"));
				model.addAttribute("tipoDocumento",ssvService.getColunaTipo("TP_NATRZ_DOCTO"));
				model.addAttribute("orgaoEmissor",ssvService.getColunaTipo("CD_ORGAO_EMSOR_DOCTO"));
				model.addAttribute("escolaridade",ssvService.getColunaTipo("CD_ESCOL"));
				model.addAttribute("estadoCivil",ssvService.getColunaTipo("TP_ESTAD_CIVIL"));
				model.addAttribute("listaPais",ssvService.getColunaTipo("PAIS"));
				model.addAttribute("listaSexo",ssvService.getColunaTipo("TP_SEXO"));
			}
			
			model.addAttribute("bandeiras",ssvService.getColunaTipo("NM_BNDRA"));
			List<FormaPagamentoBanco> bancos = bancoService.findAll(cabecalhoCotacao);
			if(proposta.isEntrada()) {
				model.addAttribute("bancos", bancos.stream().filter(it -> !Long.valueOf(104L).equals(it.getBanco()))
						.collect(Collectors.toList()));
			} else {
				model.addAttribute("bancos", bancos);
			}
			
//			List<CodigoStringDescricao> bancosSSV = ssvService.getColunaTipo("CD_BANCO");
			model.addAttribute("ufs",caracteristicaService.findUFs());
			cabecalhoCotacao.setComissaoAntecipada(cotacao.getIcComissaoAntecipada());
			model.addAttribute("cabecalhoCotacao",cabecalhoCotacao);
			model.addAttribute("proposta",proposta);
			Boolean exibeAlteracaoPagamento = endossoAlteracaoCadastralTdoService.isAlteracaoDadosCadastraisTdo(cotacao) && parcelamentoApoliceService.isPagamentoPendente(cotacao);
			model.addAttribute("exibeFormaPagamento", exibeFormaPagamento || exibeAlteracaoPagamento);
			model.addAttribute("exibeAlteracaoPagamento",exibeAlteracaoPagamento);
			model.addAttribute("formaPagamentoAlterada",endossoAlteracaoCadastralTdoService.isFormaPagamentoAlterada(proposta, cotacao));//
			model.addAttribute("exibeBotoes", exibeBotoes);
			model.addAttribute("exibeVinculoRecebimento", proposta.getCodigoFormaParcelamento() != null && proposta.isEntrada() || recebimento != null && recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO));//

			model.addAttribute("destinos",DestinoDocumentoDigitalEnum.values());
			model.addAttribute("formasEnvio",FormaEnvioDocumentoDigitalEnum.values());
			model.addAttribute("resseguradores",resseguradorService.findAll());
			model.addAttribute("exigeOficio", transmissaoService.exigeOficio(proposta));
			
			model.addAttribute("destinoCorrespondencia",DESTINO_CORRESPONDENCIA);
			model.addAttribute("formaEnvio",FORMA_ENVIO);
			model.addAttribute("autorizacaoDebito", AUTORIZACAO_DEBITO);
			
			model.addAttribute("isEstrangeiro", proposta.getCotacao().getEstrangeiro() != null && proposta.getCotacao().getEstrangeiro().equals(SimNaoEnum.SIM));
			model.addAttribute("possuiRne", proposta.getCotacao().getPossuiRNE() != null && proposta.getCotacao().getPossuiRNE().equals(SimNaoEnum.SIM));
			
			if(!StringUtils.isBlank(proposta.getUrlBoleto())) {
				model.addAttribute("docstoreBoleto",proposta.getUrlBoleto().substring(proposta.getUrlBoleto().lastIndexOf("/") + 1));
			}
			
			model.addAttribute("emailsArquivos", transmissaoService.listarEmails(proposta));
			
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE 
					|| Arrays.asList(TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO,TipoEndossoSctEnum.REINTEGRACAO_IS).contains(cotacao.getCodigoTipoEndossoSCT())
					|| Arrays.asList(TipoEndossoEnum.ALTERACAO_DADOS_CADASTRAIS,TipoEndossoEnum.ALTERACAO_SEGURADO_TDO).contains(cotacao.getIdTipoEndosso())) {
				exibeEstadoCivil = true;
				model.addAttribute("listaEstadoCivil",ssvService.getColunaTipo("TP_ESTAD_CIVIL"));
			}
			
			model.addAttribute("exibeEstadoCivil",exibeEstadoCivil);
			if(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue() == proposta.getCodigoSituacao()) {
				model.addAttribute("sucesso","Proposta enviada com sucesso!");
				model.addAttribute("printProposta", true);
			}
			model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cabecalhoCotacao.getCodigoSituacaoReadOnly()).isReadOnly());
			
			//carrega os atributos abaixo em caso de cancelamento de apólice
			if(devolucaoService.ehDevolucao(cotacao)){
				model.addAttribute("formasDevolucao",proposta.getCotacao().getFormasDevolucaoLiberadas());
				model.addAttribute("bancosFinalidadeDevolucao",bancoService.findBancoFinalidadeDevolucao());
				model.addAttribute("exibeDadosDevolucao", true);
			} else {
				model.addAttribute("exibeDadosDevolucao", false);
			}
			List<OpcaoParcelamento> opcaoParcelamento = parcelamentoService.listar(cotacao.getSequencialCotacaoProposta(), cotacao.getNumeroCotacaoProposta());
			model.addAttribute("opcaoParcelamento", opcaoParcelamento);
			model.addAttribute("grupoUsuario", this.getUser().getGrupoUsuario());
			model.addAttribute("tiposConta", tiposContaCaixaEconomica());
			model.addAttribute("regraNegocioFechado", cotacaoService.isRegraNegocioFechado(cotacao, this.getUser()));

			if(((proposta.getCodigoFormaPagamento() != null && proposta.getCodigoFormaPagamento() == 8) || exibeAlteracaoPagamento) && 
				!StringUtils.isBlank(cotacao.getIdToken())) {
				String url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroPaymentServer()) + "v1/credit-cards/" + cotacao.getIdToken();
				String username = "ctpj";
				String senha = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroSenhaPaymentServer());

				String plainCreds = username + ":" + senha;
				String base64Creds = Base64Utils.encodeToString(plainCreds.getBytes());

				HttpHeaders headers = new HttpHeaders();
				headers.add("Authorization", "Basic " + base64Creds);

				ResponseEntity<CartaoResponse> response = restTemplate.exchange(url, HttpMethod.GET,new HttpEntity<>(headers), CartaoResponse.class);
				CartaoResponse cartaoResponse = response.getBody();
				CartaoView cartao = new CartaoView();
				cartao.setBandeira(cartaoResponse.getBandeira());
				cartao.setAnoValidade(cartaoResponse.getAnoExpiracao());
				cartao.setMesValidade(cartaoResponse.getMesExpiracao());
				cartao.setNumeroCartao(cartaoResponse.getNumero());
				cartao.setNomeTitular(cartaoResponse.getCliente().getNome());
				cartao.setDocumento(cartaoResponse.getCliente().getDocumento());
				cartao.setToken(cartaoResponse.getId());
				if(cotacao.getDataVencimentoProgramada() != null) {
					LocalDateTime localDateTime = LocalDateTime.ofInstant(cotacao.getDataVencimentoProgramada().toInstant(), ZoneId.systemDefault());
					LocalDate localDate = localDateTime.toLocalDate();
					cartao.setDiaFatura(localDate.getDayOfMonth());
				}
				proposta.setCartao(cartao);
			}
//			OpcaoParcelamento op = opcaoParcelamento.stream().filter(it -> it.getIdParcelamentoEscolhido() == SimNaoEnum.SIM).findAny().get();
//
//			if(cotacao.getDataVencimentoProgramada() != null || op.getDataVencimentoParcela() != null) {
//				ConsultaDataCancelamentoRequest request = new ConsultaDataCancelamentoRequest();
//				request.setDiaFechamento(cotacao.getDataFimVigencia());
//				request.setCodPais("BR");
//				request.setCodEstado("SP");
//				request.setCodCidade(1);
//				request.setTipoCalc(-1);
//				request.setQtdDias(18);
//				request.setTipoDias("U");
//				request.setRetDiaUtil("S");
//				ConsultaDataCancelamentoResponse retorno = restTemplate.postForObject(
//						"http://servicos-aceiteint3.tokiomarine.com.br/gestaoapolice/emissao/services/rest/controledata/calculoData",
//						request, ConsultaDataCancelamentoResponse.class);
//
//				System.out.println("mesmo mes " + retorno.getDataCalculada());
//
//
//				List<ParcelamentoJanelado> parcelas = parcelamentoJaneladoService.calcularQuantidadeMaximaParcelas(cotacao, op);
//				
//				System.out.println("-------------");
//				for(ParcelamentoJanelado p: parcelas) {
//					System.out.println(p.getDataVencimentoParcela());
//				}
//				if (parcelas.stream().filter(it -> DateUtils.truncatedCompareTo(it.getDataVencimentoParcela(),
//						retorno.getDataCalculada(), Calendar.MINUTE) >= 0).count() > 0) {
//					System.out.println("estourou");
//				}
//			}

		} catch (ServiceException e) {
			logger.error(String.format("Erro ao carregar a tela de transmissao [cotacao=%s]", id), e);
			if (!AmbienteUtil.isServidorLocal()) {
				mailUtilService.sendMailErro(e);
			}
		}

		logger.info("Fim index contratação cotação: " + id);
		return "/cotacao/propostaAcsel";
	}
	
	private Map<String,String> tiposContaCaixaEconomica(){
		Map<String,String> tiposConta = new LinkedHashMap<String, String>();
		tiposConta.put("001", "001"); 
		tiposConta.put("003", "003"); 
		tiposConta.put("013", "013"); 
		tiposConta.put("023", "023");
		
		return tiposConta;

	}

	@PostMapping(value = "/salvar")
	@LogPerformance
	public ResponseEntity<ResultadoREST<Object>> salvar(@RequestBody PropostaView proposta) throws ServiceException {
		logger.info("Inicio do Salvar da cotação " + proposta.getSequencialCotacaoProposta());

		ResultadoREST<Object> resultado = new ResultadoREST<>();

		try {
			User user = SecurityUtils.getCurrentUser();
			transmissaoService.salvar(proposta,user);
			resultado.setSuccess(true);

			logger.info("Fim do Salvar da cotação " + proposta.getSequencialCotacaoProposta());

			return ResponseEntity.ok(resultado);
		} catch(OpcaoParcelamentoException o){
			resultado.setSuccess(false);
			resultado.getListaValidacao().add(new Validacao("Favor selecionar uma opção de parcelamento"));
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao Salvar os Dados da Proposta ", e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}

	@PostMapping(value = "/enviar")
	@LogPerformance
	public ResponseEntity<ResultadoREST<Object>> enviar(@RequestBody PropostaView proposta, RedirectAttributes redirect) throws ServiceException {
		logger.info("Inicio da Contratação da cotação " + proposta.getSequencialCotacaoProposta());
		
		ResultadoREST<Object> resultado = new ResultadoREST<>();

		try {			
			User user = SecurityUtils.getCurrentUser();
			List<Validacao> validacao = transmissaoService.enviar(proposta,user);
			resultado.setSuccess(true);
			if(validacao != null && !validacao.isEmpty()) {
				resultado.setListaValidacao(validacao);
				resultado.setSuccess(false);
			}

			if(validacao == null || validacao.isEmpty()) {
				transmissaoService.enviaContratacao(proposta.getSequencialCotacaoProposta(),user);
			}

			logger.info("Fim da Contratação da cotação " + proposta.getSequencialCotacaoProposta());

			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao Salvar os Dados da Proposta ", e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}
	
	@PostMapping(value = "/salvarRessegurador")
	@LogPerformance
	public ResponseEntity<ResultadoREST<Object>> salvarRessegurador(@RequestBody PropostaView proposta) throws ServiceException {
		ResultadoREST<Object> resultado = new ResultadoREST<>();

		try {
			resseguradorService.salvarRessegurador(proposta);
			resultado.setSuccess(true);
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error(String.format("Erro ao Salvar os Dados do Ressegurador [numero=%s versao=%s]",
					proposta.getCotacao().getNumeroCotacaoProposta(),
					proposta.getCotacao().getVersaoCotacaoProposta()), e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}

	@PostMapping(value = "/cartao")
	@LogPerformance
	public ResponseEntity<?> enviar(@RequestBody CartaoView cartao) throws ServiceException {
		logger.info("Inicio validação cartão " + cartao);
		try {
			
			List<String> mensagens = new ArrayList<>();
			
			if(StringUtils.isBlank(cartao.getBandeira())) {
				mensagens.add("Favor informar a bandeira do cartão");
			}
			
			if(cartao.getDiaFatura() ==  null) {
				mensagens.add("Favor informar o dia da fatura");
			}
			
			if(StringUtils.isBlank(cartao.getNumeroCartao())) {
				mensagens.add("Favor informar o número do cartão");
			}
			
			if(StringUtils.isBlank(cartao.getDocumento())) {
				mensagens.add("Favor informar o CPF/CNPJ");
			}
			
			if(StringUtils.isBlank(cartao.getNomeTitular())) {
				mensagens.add("Favor informar o nome do titular");
			}
			
			if(StringUtils.isBlank(cartao.getTipoTitular())) {
				mensagens.add("Favor informar a titularidade");
			}
			
			if(cartao.getAnoValidade() == null || cartao.getMesValidade() == null) {
				mensagens.add("Data de validade inválida");
			}

			if(!mensagens.isEmpty()) {
				return ResponseEntity.badRequest().body(mensagens);
			}

			CartaoView cartaoValido = transmissaoService.validarCartao(cartao);
			logger.info("Fim da validação cartão " + cartaoValido);
			return ResponseEntity.ok(cartaoValido);
		} catch (Exception e) {
			logger.error("Erro ao Salvar os Dados da Proposta ", e);
			return ResponseEntity.badRequest().body(Arrays.asList("Cartão inválido"));
		}
	}

	private static class Vencimento {
		
		private Map<String, Date> datasVencimento;

		public Map<String, Date> getDatasVencimento() {
			return datasVencimento;
		}

		public void setDatasVencimento(Map<String, Date> datasVencimento) {
			this.datasVencimento = datasVencimento;
		}

		@Override
		public String toString() {
			return "Vencimento [datasVencimento=" + datasVencimento + "]";
		}
	}
}
