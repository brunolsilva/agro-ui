package br.com.tokiomarine.ctpj.aop;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.util.StopWatch;

@Aspect
public class PerformanceAroundAdvice {

	private final Logger logger = LogManager.getLogger(PerformanceAroundAdvice.class);

	@Around(value = "execution(@br.com.tokiomarine.ctpj.aop.LogPerformance * *.*(..))")
	public Object logPerformance(ProceedingJoinPoint joinPoint) throws Throwable {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Object retVal = joinPoint.proceed();

		stopWatch.stop();

		final String metodo = joinPoint.getTarget().getClass().getName() + "." + joinPoint.getSignature().getName();

		logger.info(metodo + " executado em " + stopWatch.getTotalTimeSeconds() + "s");

		return retVal;
	}
}