package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoUsuario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialBloqueioAtividade;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCorretor;
import br.com.tokiomarine.ctpj.infra.mongo.repository.PerfilComercialBloqueioAtividadeRepository;

@Service
public class PerfilComercialBloqueioAtividadeService {

	@Autowired
	private PerfilComercialBloqueioAtividadeRepository repository;
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	public List<PerfilComercialBloqueioAtividade> listarPerfilComercialBloqueio(BigInteger sequencialCotacaoProposta, PerfilComercialCorretor perfilComercialCorretor){
		Cotacao cotacao = cotacaoRepository.findCompleta(sequencialCotacaoProposta);
		List<Long> categoriasContratadas = new ArrayList<>();
		if(cotacao.getListItem() != null && !cotacao.getListItem().isEmpty()){
			for(ItemCotacao itemCotacao : cotacao.getListItem()){
				categoriasContratadas.add(itemCotacao.getCodigoRubrica());
			}
		}
		
		return repository.listarPerfilComercialBloqueio(perfilComercialCorretor.getPerfilComercial()
																			, categoriasContratadas, cotacao.getCodigoLocal(), cotacao.getCodigoSubLocal());	
		
		
	}
	
	public PerfilComercialBloqueioAtividade findPerfilComercialBloqueio(Cotacao cotacao, Long codigoCategoria, PerfilCalculoUsuario perfilCalculoUsuario){
		
		List<PerfilComercialBloqueioAtividade> perfilComercialBloqueioList = repository.findPerfilComercialBloqueio(
				perfilCalculoUsuario.getPerfilCalculo(),
				codigoCategoria,
				null,
				null);
		
		if(perfilComercialBloqueioList != null && !perfilComercialBloqueioList.isEmpty()){
			return perfilComercialBloqueioList.get(0);
		}
		
		return null;
		
		
	}
}
