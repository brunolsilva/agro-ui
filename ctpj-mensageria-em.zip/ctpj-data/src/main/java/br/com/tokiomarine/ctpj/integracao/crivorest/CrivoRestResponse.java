package br.com.tokiomarine.ctpj.integracao.crivorest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "codEvento", "msgEvent", "idCache", "codRetorno", "codOperacao", "dsVariaveisRelevantePolitica",
		"icFonteExterna", "cnae", "cdNaturezaJuridica", "dsNaturezaJuridica", "nmSegurado", "cepFonteExterna" })
public class CrivoRestResponse {

	@JsonProperty("codEvento")
	private Integer codEvento;
	@JsonProperty("msgEvent")
	private String msgEvent;
	@JsonProperty("idCache")
	private String idCache;
	@JsonProperty("codRetorno")
	private Integer codRetorno;
	@JsonProperty("codOperacao")
	private String codOperacao;
	@JsonProperty("dsVariaveisRelevantePolitica")
	private String dsVariaveisRelevantePolitica;
	@JsonProperty("icFonteExterna")
	private String icFonteExterna;
	@JsonProperty("cnae")
	private String cnae;
	@JsonProperty("cdNaturezaJuridica")
	private String cdNaturezaJuridica;
	@JsonProperty("dsNaturezaJuridica")
	private String dsNaturezaJuridica;
	@JsonProperty("nmSegurado")
	private String nmSegurado;
	@JsonProperty("cepFonteExterna")
	private String cepFonteExterna;
	@JsonProperty("tpSinistro")
	private String tpSinistro;
	@JsonProperty("codCnaeCompleto")
	private String codCnaeCompleto;
	@JsonProperty("codCnae")
	private String codCnae;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	@JsonProperty("codEvento")
	public Integer getCodEvento() {
		return codEvento;
	}

	@JsonProperty("codEvento")
	public void setCodEvento(Integer codEvento) {
		this.codEvento = codEvento;
	}

	@JsonProperty("msgEvent")
	public String getMsgEvent() {
		return msgEvent;
	}

	@JsonProperty("msgEvent")
	public void setMsgEvent(String msgEvent) {
		this.msgEvent = msgEvent;
	}

	@JsonProperty("idCache")
	public String getIdCache() {
		return idCache;
	}

	@JsonProperty("idCache")
	public void setIdCache(String idCache) {
		this.idCache = idCache;
	}

	@JsonProperty("codRetorno")
	public Integer getCodRetorno() {
		return codRetorno;
	}

	@JsonProperty("codRetorno")
	public void setCodRetorno(Integer codRetorno) {
		this.codRetorno = codRetorno;
	}

	@JsonProperty("codOperacao")
	public String getCodOperacao() {
		return codOperacao;
	}

	@JsonProperty("codOperacao")
	public void setCodOperacao(String codOperacao) {
		this.codOperacao = codOperacao;
	}

	@JsonProperty("dsVariaveisRelevantePolitica")
	public String getDsVariaveisRelevantePolitica() {
		return dsVariaveisRelevantePolitica;
	}

	@JsonProperty("dsVariaveisRelevantePolitica")
	public void setDsVariaveisRelevantePolitica(String dsVariaveisRelevantePolitica) {
		this.dsVariaveisRelevantePolitica = dsVariaveisRelevantePolitica;
	}

	@JsonProperty("icFonteExterna")
	public String getIcFonteExterna() {
		return icFonteExterna;
	}

	@JsonProperty("icFonteExterna")
	public void setIcFonteExterna(String icFonteExterna) {
		this.icFonteExterna = icFonteExterna;
	}

	@JsonProperty("cnae")
	public String getCnae() {
		return cnae;
	}

	@JsonProperty("cnae")
	public void setCnae(String cnae) {
		this.cnae = cnae;
	}

	@JsonProperty("cdNaturezaJuridica")
	public String getCdNaturezaJuridica() {
		return cdNaturezaJuridica;
	}

	@JsonProperty("cdNaturezaJuridica")
	public void setCdNaturezaJuridica(String cdNaturezaJuridica) {
		this.cdNaturezaJuridica = cdNaturezaJuridica;
	}

	@JsonProperty("dsNaturezaJuridica")
	public String getDsNaturezaJuridica() {
		return dsNaturezaJuridica;
	}

	@JsonProperty("dsNaturezaJuridica")
	public void setDsNaturezaJuridica(String dsNaturezaJuridica) {
		this.dsNaturezaJuridica = dsNaturezaJuridica;
	}

	@JsonProperty("nmSegurado")
	public String getNmSegurado() {
		return nmSegurado;
	}

	@JsonProperty("nmSegurado")
	public void setNmSegurado(String nmSegurado) {
		this.nmSegurado = nmSegurado;
	}

	@JsonProperty("cepFonteExterna")
	public String getCepFonteExterna() {
		return cepFonteExterna;
	}

	@JsonProperty("cepFonteExterna")
	public void setCepFonteExterna(String cepFonteExterna) {
		this.cepFonteExterna = cepFonteExterna;
	}
	
	

	public String getTpSinistro() {
		return tpSinistro;
	}

	public void setTpSinistro(String tpSinistro) {
		this.tpSinistro = tpSinistro;
	}
	
	public String getCodCnaeCompleto() {
		return codCnaeCompleto;
	}

	public void setCodCnaeCompleto(String codCnaeCompleto) {
		this.codCnaeCompleto = codCnaeCompleto;
	}

	public String getCodCnae() {
		return codCnae;
	}

	public void setCodCnae(String codCnae) {
		this.codCnae = codCnae;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}