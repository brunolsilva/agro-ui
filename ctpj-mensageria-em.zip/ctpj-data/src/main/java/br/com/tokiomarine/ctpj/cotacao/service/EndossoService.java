package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.apolice.exception.ApoliceNaoEncotradaException;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.validation.CotacaoValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.ValidationRegistry;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ParcelamentoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ParametrosGeral;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.dto.ValidationMessage;
import br.com.tokiomarine.ctpj.dto.ValidationMessageList;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.NegocioException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.FormaParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCoberturaLimiteIs;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCancelamentoFaltaPagamento;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.SituacaoParcelamentoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaParcelamentoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.backoffice.request.ConsultaDataCancelamentoRequest;
import br.com.tokiomarine.ctpj.integracao.gestaoapolice.service.GestaoApoliceService;
import br.com.tokiomarine.ctpj.integracao.service.ConsultaDataCancelamentoService;
import br.com.tokiomarine.ctpj.integracao.service.ConsultaSinistroService;
import br.com.tokiomarine.ctpj.integracao.service.CotacaoDolarService;
import br.com.tokiomarine.ctpj.integracao.sinistro.response.ConsultaSinistroResponse;
import br.com.tokiomarine.ctpj.jms.request.DataAlteracaoRequest;
import br.com.tokiomarine.ctpj.jms.response.DataAlteracaoResponse;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.mapper.EndossoMapper;
import br.com.tokiomarine.ctpj.mapper.NumberMapper;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.util.CollectionUtil;
import br.com.tokiomarine.ctpj.util.DateUtil;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.ctpj.validation.ValidationComponent;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class EndossoService {
	
	private static Logger logger = LogManager.getLogger(EndossoService.class);
	
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private ProdutoService produtoService;

	@Autowired
	private CotacaoDolarService cotacaoDolarService;

	@Autowired
	private PerfilComercialService perfilComercialService;

	@Autowired
	private BaseService baseService;
	
	@Autowired
	private ProdutoRepository produtoRepository;
	
	@Autowired
	private FormaParcelamentoRepository formaParcelamentoRepository;
	
	@Autowired
	private ParametroGeralService parametroGeralService;
	
	@Autowired
	private ConsultaSinistroService consultaSinistroService;
	
	@Autowired
	private ConsultaDataCancelamentoService consultaDataCancelamentoService;
	
	@Autowired
	private ValidationComponent validationComponent;
	
	@Autowired
	private CaracteristicaService caracteristicaService;
	
	@Autowired
	private GestaoApoliceService gestaoApoliceService;
	
	private static final Integer VS_COTAC_FIRST = 1;
	
	private static final String ERRO_ULTIMO_ENDOSSO_APOLICE = "O cancelamento de endosso só pode ser feito se este endosso for o último endosso realizado na apólice.";
	
	@LogPerformance
	public Cotacao consultaOuGeraEndosso(SolicitacaoCotacao solicitacaoCotacao) throws NegocioException{		
				
		Cotacao cotacao = cotacaoRepository.findCotacaoDeApoliceEndossada(solicitacaoCotacao.getNrSolctCotac(), solicitacaoCotacao.getCdRamoPrdutApoliTmsrEndso(), solicitacaoCotacao.getCdApoliTmsrEndso());

		if(cotacao == null){
			if(logger.isDebugEnabled()) {
				logger.debug("Salvando Endosso para Apólice");
				logger.debug("nrSolctCotac......................: " + solicitacaoCotacao.getNrSolctCotac());
				logger.debug("cdRamoPrdutApoliTmsrEndso ........: " + solicitacaoCotacao.getCdRamoPrdutApoliTmsrEndso());
				logger.debug("cdApoliTmsrEndsoe ................: " + solicitacaoCotacao.getCdApoliTmsrEndso());
				logger.debug("tipoEndossoCTPJ ..................: " + solicitacaoCotacao.getCdTipoEndosSsc().getTipoEndossoCTPJ());
				logger.debug("solicitanteEndosso ...............: " + solicitacaoCotacao.getCdTipoEndosSsc().getSolicitanteEndosso());
			}

			Apolice apolice = apoliceRepository.findById(solicitacaoCotacao.getIdMongodb());
			
			if(apolice == null)
				throw new ApoliceNaoEncotradaException("Não foi encontrada uma apólice para o id " + solicitacaoCotacao.getIdMongodb());
			
			cotacao = EndossoMapper.INSTANCE.fromApoliceToCotacao(apolice, solicitacaoCotacao, VS_COTAC_FIRST);
			cotacaoRepository.save(cotacao);
		}
		
		return cotacao;
		
	}
	
	/**
	 * Realiza o processo de atualização dos dados da Cotação
	 * Uma lista vazia representa que não há inconsistências na cotação
	 * @return uma lista (Item + Descrição) com as inconsistências geradas pelo processo de validação
	 * @param cotacaoView Classe de tela
	 */
	@LogPerformance
	public List<ValidacaoLote> salvar(CotacaoView cotacaoView) throws ServiceException {

		BigDecimal coeficienteConversaoMoeda = null;

		try {

			Cotacao cotacao = cotacaoRepository.findCotacaoTela(cotacaoView.getSequencialCotacaoProposta());
			cotacaoView.setLiberaLMR(produtoService.findProduto(cotacao.getCodigoProduto()).getLiberaLMR());

			if (cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.TDO_ALTERACAO_DADOS_CADASTRAIS) {

				validarDadosSeguradoPlataforma(cotacaoView, cotacao);
				validarDadosSeguradoAcsel(cotacaoView, cotacao);
				cotacao.getListItem().stream()
						.forEach(item -> item.setIdTipoEndosso(cotacao.getIdTipoEndosso().getId()));

			} else if (cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.PRORROGACAO_VIGENCIA) {
				Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
				cotacaoView.setDataAlteracao(apolice.getDataFimVigencia());
			}
			
			List<ValidacaoLote> listaValidacao =  new ArrayList<>();
			
			validarDataAlteracaoEndossoCancelamentoEndossoAcsel(cotacaoView, cotacao,listaValidacao);
			
			validarDataAlteracaoInicioVigenciaItem(cotacaoView, cotacao, listaValidacao);
			
			if (listaValidacao != null && !listaValidacao.isEmpty()) {
				cotacaoRepository.evict(cotacao);
				return listaValidacao;
			}
			
			

			/**
			 * Busca o coeficiente de Conversão de Moeda
			 * e já atualiza o coeficienteConversaoMoeda para os itens
			 * da cotação se a moeda for Dolar
			 */
//			if (cotacaoView.getCodigoMoeda().getId().equals(MoedaEnum.DOLAR_VENDA.getId())) {
//				coeficienteConversaoMoeda = cotacaoView.getCoeficienteConversaoMoeda();
//			}
			cotacaoView.setCodigoMoeda(cotacao.getCodigoMoeda());

			cotacaoRepository.deleteItemDistribuicao(cotacao);

			if(cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO) {
				for (ItemCotacao itemCotacao : cotacao.getListItem()) {
					for (ItemCotacaoView itemCotacaoView : cotacaoView.getListItem()) {
						if (itemCotacao.getNumeroItem().equals(itemCotacaoView.getNumeroItem())) {
							if (itemCotacaoView.getProtecionais() != null && !itemCotacaoView.getProtecionais().isEmpty()) {
								cotacaoRepository.deleteProtecionais(itemCotacao,itemCotacaoView.getProtecionais());
							}
						}
					}
				}
			}

			if(cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO) {
				CotacaoViewMapper.INSTANCE.toCotacaoEndossoAlteracao(cotacaoView, cotacao);
			} else if(cotacao.getCodigoTipoEndossoSCT() != TipoEndossoSctEnum.REINTEGRACAO_IS){
				CotacaoViewMapper.INSTANCE.toCotacao(cotacaoView,cotacao);
			}

			if(cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.REINTEGRACAO_IS) {
				if(!StringUtils.isBlank(cotacaoView.getPercentualDescontoGeral())) {
					cotacao.setPercentualDescontoGeral( new NumberMapper().asDecimal( cotacaoView.getPercentualDescontoGeral() ) );				
				}

				if(!StringUtils.isBlank(cotacaoView.getPercentualAgravoGeral())) {
					cotacao.setPercentualAgravoGeral( new NumberMapper().asDecimal( cotacaoView.getPercentualAgravoGeral() ) );
				}

				if(!StringUtils.isBlank(cotacaoView.getValorPremioInformado())) {
					cotacao.setValorPremioInformado( new NumberMapper().asDecimal( cotacaoView.getValorPremioInformado() ) );
				}

				if(!StringUtils.isBlank(cotacaoView.getNumeroAgenciaVendedora())) {
					cotacao.setNumeroAgenciaVendedora(cotacaoView.getNumeroAgenciaVendedora());
				}

				if(!StringUtils.isBlank(cotacaoView.getNumeroContaCorrenteVendedora())) {
					cotacao.setNumeroContaCorrenteVendedora(cotacaoView.getNumeroContaCorrenteVendedora());
				}

				if(!StringUtils.isBlank(cotacaoView.getNumeroAgenciaVendedora())) {
					cotacao.setNumeroMatriculaVendedor(cotacaoView.getNumeroAgenciaVendedora());
				}
			}

			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			cotacao.setDataAtualizacao(new Date());
			cotacao.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));

			/**
			 * Popula os dados do item/local de risco e suas dependências (coberturas, protecionais, distribuicaoVR, etc)
			 */
			int sequencialItemDistribuicao = 1;
			
			baseService.populaItem(cotacaoView,cotacao,sequencialItemDistribuicao,coeficienteConversaoMoeda);
			
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO
					&& (cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO)) {
				if (cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
					for(ItemCotacao itemCotacao: cotacao.getListItem()) {
						if (itemCotacao.getIdTipoEndosso() == null) {
							itemCotacao.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO.getId());
						}
						definirDataAlteracaoItem(cotacao, itemCotacao);
					}
				} else {
					for(ItemCotacao itemCotacao: cotacao.getListItem()) {
						if (itemCotacao.getIdTipoEndosso() != null) {
							definirDataAlteracaoItem(cotacao, itemCotacao);
							
						}
					}
				}
			}

			List<Integer> coberturas = cotacao.getListItem().stream()
					.flatMap(it -> it.getListItemCobertura().stream())
					.map(ItemCobertura::getCodigoCobertura)
					.distinct().collect(Collectors.toList());
			
			baseService.populaComissao(cotacaoView,cotacao);

			List<PerfilCalculoCoberturaLimiteIs> perfisCoberturaLimiteIs = perfilComercialService.findCoberturaLimiteIs(cotacao,coberturas);

			List<ItemCobertura> cobs = cotacao.getListItem().stream()
					.flatMap(it -> it.getListItemCobertura()
					.stream())
					.collect(Collectors.toList());

			for (ItemCobertura cob : cobs) {
				for (PerfilCalculoCoberturaLimiteIs p : perfisCoberturaLimiteIs) {
					if (cob.getCodigoCobertura() != null && p != null && cob.getCodigoCobertura().equals(p.getCobertura())) {
						cob.setPerfilCalculoCoberturaLimiteIs(p);
					}
				}
			}
			
			Set<ItemCotacao> listItemCotacaoBkp = cotacao.getListItem();
			if (cotacaoView.isSalvarCotacao()) {
				Set<ItemCotacao> itensCotacao = new HashSet<>();
				Map<BigInteger,ItemCotacao> itemCotacaoMapa = new HashMap<>();
				for(ItemCotacao itemCotacao: cotacao.getListItem()) {
					itemCotacaoMapa.put(itemCotacao.getNumeroItem(),itemCotacao);
				}
				cotacaoView.getListItem().forEach(itemView -> {
					itensCotacao.add(itemCotacaoMapa.get(itemView.getNumeroItem()));
				});
				cotacao.setListItem(itensCotacao);
			} else {
				for (ItemCobertura cob : cobs) {
					if(cob.getTipoIS() == null) {
						baseService.populaDadosProdutoCobertura(cob);
					}
				}
			}

			/**
			 * valida os dados da cotacao
			 */
			Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto = caracteristicaService.findCaracteristicaDoProduto(cotacao.getCodigoProduto(), cotacao.getDataCotacao());
			CotacaoValidator cotacaoValidator = new CotacaoValidator(
					ValidationRegistry.getValidators().get(cotacao.getCodigoProduto()),
					perfilComercialService,
					caracteristicasDoProduto);
			listaValidacao = cotacaoValidator.validaEndosso(cotacao);
			
			/**
			 * Após a validação a cotação assume sua lista se veio do botão salvar
			 */
			if (cotacaoView.isSalvarCotacao()) {
				cotacao.setListItem(listItemCotacaoBkp);
			}

			cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);

			/**
			 * Se a moeda da cotação for Dolar
			 * verifica os valores após a conversão
			 */
			if (cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA) {
				cotacaoDolarService.validaValoresAntesCalculoBlaze(cotacao,coeficienteConversaoMoeda);
			}			
			
			if (listaValidacao != null && listaValidacao.isEmpty()) {
				cotacaoRepository.update(cotacao);
			} else {
				cotacaoRepository.evict(cotacao);
			}
			
			return listaValidacao;
		} catch (Exception e) {
			logger.error(String.format("Erro ao salvar a Cotação [%s]: ",cotacaoView.getSequencialCotacaoProposta()),e);
			throw new ServiceException(e.getMessage() + String.format("Cotacao [%s]",cotacaoView.getSequencialCotacaoProposta()),e);
		}
	}

	/**
	 * verifica se a data de alteração é anterior ao início de vigência de algum item
	 * @param cotacaoView
	 * @param cotacao
	 * @param listaValidacao
	 */
	private void validarDataAlteracaoInicioVigenciaItem(CotacaoView cotacaoView, Cotacao cotacao,
            List<ValidacaoLote> listaValidacao) {
        if(DestinoEmissaoEnum.ACX != cotacao.getIdDestinoEmissao() && TipoPedidoCotacaoEnum.ENDOSSO == cotacao.getIdTipoPedidoCotacao()) {
            for (ItemCotacao itemCotacao : cotacao.getListItem()) {
                if(!isInclusaoItem(itemCotacao) && cotacaoView.getDataAlteracao().before(itemCotacao.getDataInicioVigencia())) {
                    Mensagem mensagem = new Mensagem(itemCotacao.getNumeroItem().intValue(), "Data de Alteração do endosso não pode ser anterior ao início de vigência do item: "+DateUtil.formataSemHora(itemCotacao.getDataInicioVigencia()));
                    listaValidacao.add(new ValidacaoLote(mensagem));
                }
            }
        }
    }
	
	/**
	 * verifica se a data de alteração é anterior ao início de vigência de algum item
	 * @param cotacaoView
	 * @param cotacao
	 * @param listaValidacao
	 */
	public void validarDataAlteracaoInicioVigenciaItemTransmissao(Cotacao cotacao,List<Validacao> listaValidacao) {
        if(DestinoEmissaoEnum.ACX != cotacao.getIdDestinoEmissao() && TipoPedidoCotacaoEnum.ENDOSSO == cotacao.getIdTipoPedidoCotacao()) {
            for (ItemCotacao itemCotacao : cotacao.getListItem()) {
                if(!isInclusaoItem(itemCotacao) && cotacao.getDataAlteracao().before(itemCotacao.getDataInicioVigencia())) {
                    listaValidacao.add(new Validacao(String.format("Item %s - Data de Alteração do endosso não pode ser anterior ao início de vigência do item: %s", itemCotacao.getNumeroItem(), DateUtil.formataSemHora(itemCotacao.getDataInicioVigencia()))) );
                }
            }
        }
    }

	private void definirDataAlteracaoItem(Cotacao cotacao, ItemCotacao itemCotacao) {
		if(cotacao.getDataAlteracao().before(itemCotacao.getDataInicioVigencia())) {
			itemCotacao.setDataAlteracao(itemCotacao.getDataInicioVigencia());
		} else {
			itemCotacao.setDataAlteracao(cotacao.getDataAlteracao());	
		}
	}

	private void validarDadosSeguradoPlataforma(CotacaoView cotacaoView, Cotacao cotacao) {
		if (cotacao.getIdDestinoEmissao() == DestinoEmissaoEnum.PLT) {
			if (!cotacao.getNumeroCNPJCPFSegurado().equals(cotacaoView.getNumeroCNPJCPFSegurado())) {
				cotacao.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO_SEGURADO_TDO);
			} else {
				
				cotacao.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO_DADOS_CADASTRAIS);
			}
		}
	}

	private void validarDataAlteracaoEndossoCancelamentoEndossoAcsel(CotacaoView cotacaoView, Cotacao cotacao, List<ValidacaoLote> listaValidacao) throws ServiceException {
		if(DestinoEmissaoEnum.ACX == cotacao.getIdDestinoEmissao() && TipoEndossoSctEnum.CANCELAMENTO_ENDOSSO_POR_MOTIVO_INTERNO == cotacao.getCodigoTipoEndossoSCT()) {
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			Date dataMenor = null;
			Date dataMaior = null;
			if(cotacao.getDataFimVigencia().compareTo(apolice.getDataAlteracao()) > 0) {
				dataMaior = cotacao.getDataFimVigencia();
				dataMenor = apolice.getDataAlteracao();
			} else {
				dataMaior = apolice.getDataAlteracao();
				dataMenor = cotacao.getDataFimVigencia();					
			}
			
			//se a data não estiver no range, retorna mensagem de erro
			if(!isDataAlteracaoValidaEndossoCancelamentoEndossoAcsel(cotacaoView,cotacao,apolice)) {
				Mensagem mensagem = new Mensagem();
				mensagem.setDescricao(String.format("A Data de Alteração deve estar entre %s e %s", DateUtil.formataSemHora(dataMenor),DateUtil.formataSemHora(dataMaior)));
				listaValidacao.add(new ValidacaoLote(mensagem));
			}
		}
	}

	public Boolean isDataAlteracaoValidaEndossoCancelamentoEndossoAcsel(CotacaoView cotacaoView, Cotacao cotacao, Apolice apolice) {
		if(DestinoEmissaoEnum.ACX == cotacao.getIdDestinoEmissao() && TipoEndossoSctEnum.CANCELAMENTO_ENDOSSO_POR_MOTIVO_INTERNO == cotacao.getCodigoTipoEndossoSCT()) {
			Date dataMenor = null;
			Date dataMaior = null;
			if(cotacao.getDataFimVigencia().compareTo(apolice.getDataAlteracao()) > 0) {
				dataMaior = cotacao.getDataFimVigencia();
				dataMenor = apolice.getDataAlteracao();
			} else {
				dataMaior = apolice.getDataAlteracao();
				dataMenor = cotacao.getDataFimVigencia();					
			}
			
			return cotacaoView.getDataAlteracao().compareTo(dataMenor) >= 0 && cotacaoView.getDataAlteracao().compareTo(dataMaior) <= 0;
		}
		return true;
	}

	private void validarDadosSeguradoAcsel(CotacaoView cotacaoView, Cotacao cotacao) {
		if (cotacao.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {

			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			
			if (!apolice.getNumeroCNPJCPFSegurado().equals(cotacaoView.getNumeroCNPJCPFSegurado())) {
				cotacao.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO_SEGURADO_TDO);
			} else {
				
				cotacao.setIdTipoEndosso(TipoEndossoEnum.ALTERACAO_DADOS_CADASTRAIS);
			}
		}
	}

	public ValidationMessageList validaProrrogracaoVigencia(Cotacao cotacao) {
		ValidationMessageList mensagens = new ValidationMessageList();
		
		Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
		
		if(!produto.getProrrogacaoVigencia().getLogical()){
			mensagens.add("Produto não permite Prorrogação de Vigência", ValidationMessage.Type.ERROR);
		}
		
		return mensagens;
	}
	
	public ValidationMessageList validaCancelamentoDeApolicePorSinistro(String idApolice) throws ServiceException {		
		ValidationMessageList mensagens = new ValidationMessageList();		
		Boolean existeSinistro = false;
		Apolice apolice = apoliceRepository.findById(idApolice);
		String idQuebraCobertura = "S";
	
		try {
			for (ItemApolice itemApolice : apolice.getListItemApolice()) {
				
				List<ConsultaSinistroResponse> sinistros = consultaSinistroService.consultarSinistro(apolice.getCodigoRamoProdutoApolice(), apolice.getCodigoApolice(), itemApolice.getCodigoItemApolice(), null, new Long(0), idQuebraCobertura);
				for (ConsultaSinistroResponse sinistro : sinistros) {
					if (sinistro.getDataOcorrencia().before(apolice.getDataFimVigencia()) || sinistro.getDataOcorrencia().equals(apolice.getDataFimVigencia())) {
						existeSinistro = true;
					}
				}
			}
			if(!existeSinistro) {
				mensagens.add("Não há sinistros para realizar o cancelamento da apólice!", ValidationMessage.Type.ERROR);
			}			
			return mensagens;
		
		} catch (Exception e) {
			logger.error(String.format("Erro ao consultar os sinistro para a apólice [%s]: ", apolice.getCodigoRamoProdutoApolice()+apolice.getCodigoApolice()),e);
			throw new ServiceException(e.getMessage() + String.format("Apólice [%s]",apolice.getCodigoRamoProdutoApolice()+apolice.getCodigoApolice()),e);
		}
	}
	
	public ValidationMessageList validaCancelamentoDeApolicePorFaltaPagamento(String idApolice) throws ServiceException {	
		Apolice apolice = apoliceRepository.findById(idApolice);
		ValidationMessageList mensagens = new ValidationMessageList();		
		Integer numeroParcelaPendente = null;
		SimNaoEnum idEntrada = null;
		Date dataVencimentoParcela = null;
		Date dataCorrente = new Date();
		Date dataMinimaCancelamento = null;
		ParametrosGeral qtDiasPrimeiraParcela = null;
		ParametrosGeral qtDiasDemaisParcelas = null;
		List<ParcelamentoApolice> parcelamentoApolice = apolice.getListParcelamentoApolice();
		
		if (!existeParcelaPendenteMaiorQueZero(apolice)) {
			mensagens.add("Apólice não pode ser cancelada por falta de pagamento, pois não há parcela pendente passível de cancelamento.", ValidationMessage.Type.ERROR);
		} 
		ProdutoControle produtoControle = produtoRepository.findProdutoControleByCodigoAndVigencia(apolice.getCodigoProduto(), apolice.getDataInicioVigencia());
		SimNaoEnum idFormalizaSemRetorno = produtoControle.getFormalizaSemRetorno();
		
		//Ordenar lista por data de vencimento para pegar primeira parcela pendente
		parcelamentoApolice.sort(Comparator.comparing(ParcelamentoApolice::getDataVencimento));
		
		// Varre lista de parcelamento para pegar a primeira parcela pendente
		for (ParcelamentoApolice parcelamento : parcelamentoApolice) {
			if(parcelamento.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE)) {
				FormaParcelamento formaParcelamento = formaParcelamentoRepository.findByFormaParcelamento(parcelamento.getCodigoFormaParcelamento());
				//caso não tenha o codigo forma parcelamento, tenta ajustar através do cdFormaPagto retornado pelo serviço gestaoapolice
				if(formaParcelamento == null && !StringUtils.isEmpty(parcelamento.getCdFormaPagto())) {
					formaParcelamento = new FormaParcelamento();
					formaParcelamento.setEntrada(parcelamento.getCdFormaPagto().equals("V") ? SimNaoEnum.SIM : SimNaoEnum.NAO);
				}
				
				idEntrada = formaParcelamento == null ? null : formaParcelamento.getEntrada();
				numeroParcelaPendente = parcelamento.getNumeroParcela();
				dataVencimentoParcela = parcelamento.getDataVencimento();	
				break;
			}
		}	
				
		/** Validação de data mínima para cancelamento **/
		// Se formalizaSemRetorno = S e entrada = S e for numeroParcela = 1
		if (idFormalizaSemRetorno.getId().equals(SimNaoEnum.SIM.getId()) && idEntrada != null && idEntrada.getId().equals(SimNaoEnum.SIM.getId()) && numeroParcelaPendente == 1) {			
			qtDiasPrimeiraParcela = parametroGeralService.getParametroGeralByNome(ParametroGeralEnum.NR_DIAS_PRIMEIRA_PARCELA_CANCEL_FALTA_PAGTO);
			dataMinimaCancelamento = this.consultaDataCancelamento(dataVencimentoParcela != null ? dataVencimentoParcela: new Date(), qtDiasPrimeiraParcela.getValorNumerico().intValue());
		}				
		
		// Se formalizaSemRetorno = N ou entrada = N oi for numeroParcela != 1
		if (idFormalizaSemRetorno.getId().equals(SimNaoEnum.NAO.getId()) || ( idEntrada != null && idEntrada.getId().equals(SimNaoEnum.NAO.getId())) || numeroParcelaPendente != 1){			
			qtDiasDemaisParcelas = parametroGeralService.getParametroGeralByNome(ParametroGeralEnum.NR_DIAS_DEMAIS_PARCELAS_CANCEL_FALTA_PAGTO);
			dataMinimaCancelamento = this.consultaDataCancelamento(dataVencimentoParcela != null ? dataVencimentoParcela: new Date(), qtDiasDemaisParcelas.getValorNumerico().intValue());
		}
		//Valida a data mínima para cancelamento em relação a data corrente
		if (dataMinimaCancelamento != null && dataMinimaCancelamento.after(dataCorrente)) {
			mensagens.add("Apólice não pode ser cancelada por falta de pagamento, pois a data mínima para realizar o cancelamento é <b>" + DateUtil.formataSemHora(dataMinimaCancelamento) + "</b>", ValidationMessage.Type.ERROR);
		}
		
		/** Validações que exibirão alertas e apresentarão a possibilidade de emissão do endosso**/
		// Valida se a apólice posssui endossos com parcelamento
		if (existeEndossosComParcelamento(parcelamentoApolice)) {
			mensagens.add("Apólice com endosso(s)", ValidationMessage.Type.WARNING);
		}				
		//Valida se a apólice (endosso nulo) possui comissão antecipada				
		
		Comparator<ParcelamentoApolice> cmpNrParcela = (parcApolice1, parcApolice2) -> Integer.compare(parcApolice1.getNumeroParcela(), parcApolice2.getNumeroParcela());				
		List<ParcelamentoApolice> parcelamentoEndossoNulo = parcelamentoApolice.stream().filter(parcelamento -> parcelamento.getCodigoEndosso() == 0).collect(Collectors.toList());				
		ParcelamentoApolice maiorParcelaRegistro = parcelamentoEndossoNulo.stream().max(cmpNrParcela).orElse(new ParcelamentoApolice());
		Integer nrMaiorParcela = maiorParcelaRegistro.getNumeroParcela();
										
		if (apolice.getNumeroParcelasComissaoApolice() != null && apolice.getNumeroParcelasComissaoApolice() < nrMaiorParcela) {
			mensagens.add("Apólice com comissão antecipada", ValidationMessage.Type.WARNING);
		}
		
		return mensagens;
	}
	
	public DataAlteracaoResponse calculaDataAlteracaoBatch(DataAlteracaoRequest request) {
		
		DataAlteracaoResponse response = new DataAlteracaoResponse();
		
		try {
			
			List<Mensagem> mensagens = validationComponent.validatorSemAtributosIgnore(request);
			
			if(mensagens != null) {
				
				response.setMensagens(mensagens);
				response.setSucesso(false);
				
			}else {
			
				Date dataAlteracao = this.calculaDataAlteracao(request.getIdApolice(),request.getTipoEndossoEnum());
				response.setSucesso(true);
				response.setDataAltercao(dataAlteracao);
			}
			
		}catch (NegocioException e) {
			logger.error("Erro ao calcular data de Alteração "+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request),e);
			List<Mensagem> mensagens =  new ArrayList<Mensagem>();
			Mensagem mensagem = new Mensagem();
			mensagem.setCodigo(1);
			mensagem.setDescricao(e.getMessage());
			mensagens.add(mensagem);
			response.setMensagens(mensagens);
			response.setSucesso(false);
		}
		return response;
	}
	
	/** 
	 * Calcula data de alteração - retroação de vigência 
	 *
	 *@param apolice 
	 */
	public Date calculaDataAlteracao(String idApolice, TipoEndossoEnum idTipoEndosso) throws NegocioException {
		
		Apolice apolice = apoliceRepository.findById(idApolice);
				
		List<ParcelamentoApolice> parcelamentoApolice = apolice.getListParcelamentoApolice();
		BigDecimal vlPremioTotalPago = null;
		BigDecimal vlPremioTotal = new BigDecimal(0L);
		LocalDate dtAlteracao = null;
		BigDecimal deducoesDaParcela;
		BigDecimal percentualAplicacaoPrazo = BigDecimal.ZERO;
		
		for (ParcelamentoApolice parcelamento : parcelamentoApolice) {
			deducoesDaParcela = parcelamento.getValorCustoApolice().add(parcelamento.getValorIof().add(parcelamento.getValorJuros()));
			if (parcelamento.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.RECEBIDO)){
				if (vlPremioTotalPago == null) {
					vlPremioTotalPago = BigDecimal.ZERO;
				}
				vlPremioTotalPago = vlPremioTotalPago.add( parcelamento.getValorParcela().subtract(deducoesDaParcela) ); 				
			}
			vlPremioTotal = vlPremioTotal.add(parcelamento.getValorParcela().subtract(deducoesDaParcela));
		}

		//Convertendo as datas de início e fim de vigência bem como a de alteração (se diferente de nulo) para calcular os dias entre as datas
		Instant instantFimVigencia = Instant.ofEpochMilli(apolice.getDataFimVigencia().getTime());
		LocalDate dtFimVigencia = LocalDateTime.ofInstant(instantFimVigencia, ZoneId.systemDefault()).toLocalDate();
		
		Instant instantInicioVigencia = Instant.ofEpochMilli(apolice.getDataInicioVigencia().getTime());
		LocalDate dtInicioVigencia = LocalDateTime.ofInstant(instantInicioVigencia, ZoneId.systemDefault()).toLocalDate();
		
		if (apolice.getDataAlteracao() != null) {
			Instant instantAlteracao = Instant.ofEpochMilli(apolice.getDataAlteracao().getTime());
			dtAlteracao = LocalDateTime.ofInstant(instantAlteracao, ZoneId.systemDefault()).toLocalDate();
		}

		Integer qtDiasVigencia = idTipoEndosso == TipoEndossoEnum.CANCELAMENTO_APOLICE ?
				(int) ChronoUnit.DAYS.between(dtInicioVigencia,dtFimVigencia) :
					(int) ChronoUnit.DAYS.between((dtAlteracao == null ? dtInicioVigencia : dtAlteracao),dtFimVigencia);

		if (vlPremioTotalPago != null) {

			BigDecimal relacaoPagoTotal = (vlPremioTotalPago.divide(vlPremioTotal,MathContext.DECIMAL128)).multiply(new BigDecimal(100),MathContext.DECIMAL128).setScale(2, RoundingMode.HALF_EVEN);
			
			ProdutoCancelamentoFaltaPagamento produtoCancelamentoFaltaPagamento = produtoRepository.findProdutoCancelamentoFaltaPagamentobyProduto(
					apolice.getCodigoProduto(), 
					relacaoPagoTotal);
			
			percentualAplicacaoPrazo = produtoCancelamentoFaltaPagamento.getPercentualAplicacaoPrazo();
		}
		
		Integer qtDiasRetroacao = Math.floorDiv(qtDiasVigencia * percentualAplicacaoPrazo.intValue(),100);
		
		LocalDate dtAlteracaoRetroLocal = null;
		
		if (idTipoEndosso == TipoEndossoEnum.CANCELAMENTO_APOLICE) {
		// Para cancelamento de apólice (4A), adicionar os dias na data de início de vigência
			 dtAlteracaoRetroLocal = dtInicioVigencia.plusDays(qtDiasRetroacao);
		} else {
		// Para cancelamento de endosso (16A), adicionar os dias na data de alteração
			dtAlteracaoRetroLocal = dtAlteracao != null ? dtAlteracao.plusDays(qtDiasRetroacao): dtInicioVigencia.plusDays(qtDiasRetroacao);
		}
		
		return	Date.from(dtAlteracaoRetroLocal.atStartOfDay(ZoneId.systemDefault()).toInstant());
		
	}	
	
	public ValidationMessageList validaCancelamentoDeApolicePorMotivoInterno(String idApolice, Cotacao cotacao){		
		Apolice apolice = apoliceRepository.findById(idApolice);
		ValidationMessageList mensagens = new ValidationMessageList();		
		
		if(cotacao.getIdDestinoEmissao() != DestinoEmissaoEnum.ACX) {
			if(existeParticipacaoDeCosseguro(apolice))
				mensagens.add("Cancelamento por motivo interno não poderá ser realizado, "
						+ "pois existe participação de cosseguro para esta apólice. "
						+ "Utilizar cancelamento solicitado pela companhia (4C) para geração de devolução de prêmio e posterior aproveitamento deste crédito devidamente acordado com a área de cobrança", ValidationMessage.Type.ERROR);
		}
		
		if(!existeParcelaPaga(apolice))
			mensagens.add("Cancelamento por motivo interno não poderá ser realizado, pois não há parcela paga", ValidationMessage.Type.ERROR);	
		
		return mensagens;
	}

	public ValidationMessageList validaCancelamentoDeEndossoPorMotivoInterno(String idApolice, CotacaoView cotacaoView) throws ServiceException {		
		Apolice apolice = apoliceRepository.findById(idApolice);
		ValidationMessageList mensagens = new ValidationMessageList();		
		
		Integer nrMaxVersaoCotacao = cotacaoRepository.getNrMaxVersaoCotacaoByNrCotacao(cotacaoView.getNumeroCotacaoProposta());

		if(cotacaoView.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {
			if(!cotacaoView.getVersaoCotacaoProposta().equals(nrMaxVersaoCotacao) || !gestaoApoliceService.isUltimoEndosso(cotacaoView, apolice)){
				mensagens.add(ERRO_ULTIMO_ENDOSSO_APOLICE, ValidationMessage.Type.ERROR);
			}
		}
		
		if(cotacaoView.getIdDestinoEmissao() != DestinoEmissaoEnum.ACX) {
			switch (apolice.getIdTipoEndosso()) {
				case ALTERACAO_CONDICAO_COMERCIAL_DOCUMENTO:
					mensagens.add("Cancelamento de endosso por motivo interno não pode ser realizado para endosso de alteração de condição comercial.", ValidationMessage.Type.ERROR);
					break;
				case CANCELAMENTO_ENDOSSO:
					mensagens.add("O cancelamento de endosso por motivo interno não pode ser realizado, pois o endosso selecionado é um cancelamento de endosso.", ValidationMessage.Type.ERROR);
					break;
				case CANCELAMENTO_INCLUSAO:
					mensagens.add("O cancelamento de endosso por motivo interno não pode ser realizado, pois o endosso selecionado é um cancelamento do endosso de inclusão de itens.", ValidationMessage.Type.ERROR);
					break;
				default:
					break;
			}
		}

		if(apolice.getListParcelamentoApolice() != null){
			List<ParcelamentoApolice> parcelasPendentes = apolice.getListParcelamentoApolice().stream().filter(parcela -> parcela.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE)).collect(Collectors.toList());
			
			if(!parcelasPendentes.isEmpty()){
				
				Integer nrDiasPgtAtraso = parametroGeralService.getParametroGeralByNome(ParametroGeralEnum.NR_DIAS_PAGTO_ATRASO).getValorNumerico().intValue();
				
				StringBuilder parcelasPendentesMessage = new StringBuilder();
				for (ParcelamentoApolice parcela : parcelasPendentes) {
					
					// Soma na data de vencimento da parcela o parâmetro NR_DIAS_PAGTO_ATRASO
					Instant instantVencimentoParcela = Instant.ofEpochMilli(parcela.getDataVencimento().getTime());
					LocalDate dtVencimentoParcela = LocalDateTime.ofInstant(instantVencimentoParcela, ZoneId.systemDefault()).toLocalDate();
					LocalDate dtVencParcelaLocalDate = dtVencimentoParcela.plusDays(nrDiasPgtAtraso);
					Date dtVencParcelaDate = Date.from(dtVencParcelaLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
															
					if(parcela.getDataVencimento().after(dtVencParcelaDate)) {
						parcelasPendentesMessage.append("Nº Parcela: ").append(parcela.getNumeroParcela()).append(" Valor: ").append(parcela.getValorParcela()).append(" Vencimento: ").append(DateUtil.formataSemHora(parcela.getDataVencimento())).append("<br />");
						mensagens.addParcelaPendente(parcela);
					}
				}
				
				if(parcelasPendentesMessage.length() > 0){ 
					StringBuilder parcelasMessage = new StringBuilder("Apólice ou endosso com parcela vencida, enviar documento para a técnica." + "<br />" + "<br />");
					parcelasMessage.append(parcelasPendentesMessage);
					mensagens.add(parcelasMessage.toString(), ValidationMessage.Type.WARNING); 
				}
			}
		
		}
		
		return mensagens;
	}
	
	public ValidationMessageList validaCancelamentoDeEndossoPorFaltaDePagamento(String idApolice, CotacaoView cotacaoView) throws ServiceException {

		Apolice apolice = apoliceRepository.findById(idApolice);
		ValidationMessageList mensagens = new ValidationMessageList();		
		
		Integer nrMaxVersaoCotacao = cotacaoRepository.getNrMaxVersaoCotacaoByNrCotacao(cotacaoView.getNumeroCotacaoProposta());

		if(cotacaoView.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {
			if(!cotacaoView.getVersaoCotacaoProposta().equals(nrMaxVersaoCotacao) || !gestaoApoliceService.isUltimoEndosso(cotacaoView, apolice)){
				mensagens.add(ERRO_ULTIMO_ENDOSSO_APOLICE, ValidationMessage.Type.ERROR);
			}
		}

		if(cotacaoView.getDataFimVigencia().after(new Date())){
			
			if(!existeParcelaPendenteMaiorQueZero(apolice)) {
				mensagens.add("Endosso não pode ser cancelada por falta de pagamento, pois não há parcela pendente passível de cancelamento.", ValidationMessage.Type.ERROR);
			}
			
			SimNaoEnum idFormalizaSemRetorno = produtoRepository.findProdutoControleByCodigoAndVigencia(apolice.getCodigoProduto(), apolice.getDataInicioVigencia()).getFormalizaSemRetorno();
			
			List<ParcelamentoApolice> parcelamentosApolice = apolice.getListParcelamentoApolice();
			parcelamentosApolice.sort(Comparator.comparing(ParcelamentoApolice::getNumeroParcela));
			
			Optional<ParcelamentoApolice> optionalPrimeiraParcelaPendente = parcelamentosApolice.stream()
					.filter(parcela -> parcela.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE))
					.findFirst();
			
			if(optionalPrimeiraParcelaPendente.isPresent()){
				ParcelamentoApolice primeiraParcelaPendente = optionalPrimeiraParcelaPendente.get();
				SimNaoEnum idEntrada= getIdEntrada(cotacaoView, primeiraParcelaPendente);
				Date dataMinimaCancelamento = null;
				
				if (idFormalizaSemRetorno.equals(SimNaoEnum.SIM) && idEntrada.equals(SimNaoEnum.SIM) && primeiraParcelaPendente.getNumeroParcela() == 1) {			
					
					Integer qtDiasPrimeiraParcela = parametroGeralService.getParametroGeralByNome(ParametroGeralEnum.NR_DIAS_PRIMEIRA_PARCELA_CANCEL_FALTA_PAGTO).getValorNumerico().intValue();
					dataMinimaCancelamento   = this.consultaDataCancelamento(primeiraParcelaPendente.getDataVencimento(), qtDiasPrimeiraParcela);	
					
				} else if (idFormalizaSemRetorno.equals(SimNaoEnum.NAO) || idEntrada.equals(SimNaoEnum.NAO) || primeiraParcelaPendente.getNumeroParcela() != 1) {

					Integer qtDiasDemaisParcelas = parametroGeralService.getParametroGeralByNome(ParametroGeralEnum.NR_DIAS_DEMAIS_PARCELAS_CANCEL_FALTA_PAGTO).getValorNumerico().intValue();
					dataMinimaCancelamento = this.consultaDataCancelamento(primeiraParcelaPendente.getDataVencimento(), qtDiasDemaisParcelas);
					
				}
				Date dataCorrente = new Date();
				
				if(dataMinimaCancelamento != null && (dataMinimaCancelamento.after(dataCorrente) || DateUtil.retornaDias(dataMinimaCancelamento, dataCorrente ) == 0L )){
					mensagens.add("Endosso não pode ser cancelado por falta de pagamento, pois a data mínima para realizar o cancelamento é " + DateUtil.formataSemHora(dataMinimaCancelamento), ValidationMessage.Type.ERROR);
				}
				
			} else {
				mensagens.add("Endosso não pode ser cancelado por falta de pagamento, pois não há parcela pendente passível de cancelamento.", ValidationMessage.Type.ERROR);
			}
			
		}
		
		return mensagens;
		
	}

	private SimNaoEnum getIdEntrada(CotacaoView cotacaoView, ParcelamentoApolice primeiraParcelaPendente) {
		FormaParcelamento formaParcelamento = formaParcelamentoRepository.findByFormaParcelamento(primeiraParcelaPendente.getCodigoFormaParcelamento());
		//caso não tenha o codigo forma parcelamento, tenta ajustar através do cdFormaPagto retornathando pelo serviço gestaoapolice
		if(DestinoEmissaoEnum.ACX == cotacaoView.getIdDestinoEmissao() && formaParcelamento == null) {
			formaParcelamento = new FormaParcelamento();
			formaParcelamento.setEntrada(primeiraParcelaPendente.getCdFormaPagto().equals("V") ? SimNaoEnum.SIM : SimNaoEnum.NAO);
		}
		
		return formaParcelamento.getEntrada();	
		
	}

	private Date consultaDataCancelamento(Date dataVencimentoParcela, Integer qtDias) throws ServiceException {
		try {
			ConsultaDataCancelamentoRequest request = new ConsultaDataCancelamentoRequest();		
			request.setDiaFechamento(dataVencimentoParcela);
			request.setCodPais("BR");
			request.setCodEstado("SP");
			request.setCodCidade(1);
			request.setTipoCalc(1);
			request.setQtdDias(qtDias);
			request.setTipoDias("U");
			request.setRetDiaUtil("S");	
					
			return consultaDataCancelamentoService.consultarDataCancelamento(request);
		} catch (Exception e) {
			logger.error(String.format("Erro ao recuperar data mínima para cancelamento (data vencimento / qt dias): %s ", dataVencimentoParcela.toString() +" / "+ qtDias.toString()), e);
			throw new ServiceException(e.getMessage() + String.format("Data mínima para cancelamento %s ", dataVencimentoParcela.toString() +" / "+ qtDias.toString()), e);
		} 
	}
	
	private boolean existeParcelaPaga(Apolice apolice) throws NegocioException {
		boolean existeParcelaPaga = true;
		if(CollectionUtil.isNotNullOrEmpty(apolice.getListParcelamentoApolice())){
			existeParcelaPaga =  apolice.getListParcelamentoApolice().stream().anyMatch(parcelamento -> parcelamento.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.RECEBIDO));
		}

		return existeParcelaPaga;

	}	

	private boolean existeParcelaPendenteMaiorQueZero(Apolice apolice) throws NegocioException {
		for (ParcelamentoApolice parcelamento : apolice.getListParcelamentoApolice()) {
			if (parcelamento.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE) && (parcelamento.getValorParcela().signum() == 1)) {
				return true;
			}
		}
		return false;
		
	}

	private boolean existeParticipacaoDeCosseguro(Apolice apolice) throws NegocioException {
		return CollectionUtil.isNotNullOrEmpty(apolice.getListCosseguroApolice());
	}
	
	private boolean existeEndossosComParcelamento(List<ParcelamentoApolice> parcelamentoApolice) throws NegocioException {
		boolean existeEndossosComParcelamento = false;
		
		if(CollectionUtil.isNotNullOrEmpty(parcelamentoApolice)){
			existeEndossosComParcelamento =  parcelamentoApolice.stream().anyMatch(parcelamento -> parcelamento.getCodigoEndosso() != 0);
		}
		return existeEndossosComParcelamento;
	}
	
	public void marcaReintegracao(Cotacao cotacao, CotacaoView cotacaoView) {
		List<ItemSinistro> sinistros = cotacaoRepository.findItemSinistro(cotacao.getListItem());

		for(ItemSinistro itemSinistro: sinistros) {
			for(ItemCotacaoView icv: cotacaoView.getListItem()) {
				if(icv.getSequencialItemCotacao().equals(itemSinistro.getItemCotacao().getSequencialItemCotacao())) {
					icv.setReintegracao(true);
				}
			}
		}
	}

	private boolean isInclusaoItem(ItemCotacao itemCotacao) {
        return itemCotacao.getCodigoTipoEndosso() != null && TipoEndossoEnum.INCLUSAO_ITEM.getId().equals(itemCotacao.getCodigoTipoEndosso());
    }
}
