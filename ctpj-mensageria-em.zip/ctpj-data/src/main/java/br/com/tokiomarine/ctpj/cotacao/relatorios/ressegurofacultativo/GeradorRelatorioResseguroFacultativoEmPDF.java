package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import br.com.tokiomarine.ctpj.config.WebApplicationAware;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosCotacaoParaResseguroFacultativo;
import br.com.tokiomarine.ctpj.cotacao.relatorios.RelatorioException;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;
import br.com.tokiomarine.ctpj.enums.IdCessaoEnum;

@Component
public class GeradorRelatorioResseguroFacultativoEmPDF implements GeradorRelatorioResseguroFacultativo {
	
	private static final int MARGIN = 20;
	private static final Rectangle pageSize = PageSize.A4;
	private static final float LARGURA_BORDA_TITULO = 2f;
	
	@Autowired
	private WebApplicationAware contextAware;	
	
	@Autowired
	private DadosRelatorioResseguroFacultativoMapper mapper;
	
	@Override
	public byte[] gera(DadosCotacaoParaResseguroFacultativo dadosCotacao, ResseguroFacultativo resseguroFacultativo) throws RelatorioException {
		DadosRelatorioResseguroFacultativo dadosRelatorio = mapper.toDadosRelatorio(resseguroFacultativo, dadosCotacao);
		return gera(dadosRelatorio);
	}
	
	@Override
	public byte[] gera(DadosRelatorioResseguroFacultativo dados) throws RelatorioException {
		Document document = new Document(pageSize, MARGIN, MARGIN, MARGIN, MARGIN);
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try{
		
			PdfWriter.getInstance(document, baos);
			
			document.open();
			
			criaCabecalho(document);
			addEmptyLine(document, 1);
			criaSecaoDadosCotacao(document, dados);
			addEmptyLine(document, 1);
			criaSecaoDadosDoRisco(document, dados);
			criaSecaoBroken(document, dados);
			addEmptyLine(document, 1);
			criaSecaoDistribuicoes(document, dados);
			addEmptyLine(document, 1);
			criaSecaoDemaisDados(document, dados);
			addEmptyLine(document, 1);
			criaSecaoResseguradoresELloyds(document, dados);
			addEmptyLine(document, 1);
			criaSecaoObservacoes(document, dados);
			
			document.close();		
			
			return baos.toByteArray();
		}catch(Exception e){
			throw new RelatorioException("Ocorreu um erro na geração do relatório de Resseguro Facultativo", e);
		}
	}

	private void criaCabecalho(Document document) throws DocumentException, MalformedURLException, IOException {	
		Image logo = criaLogoTokioMarine();
		
		Font fontTitulo = new Font();
		fontTitulo.setSize(10f);
		fontTitulo.setStyle(Font.BOLD);		
		
		PdfPTable tituloTable = new PdfPTable(2);
		tituloTable.setWidths(new float[]{5.5f, 2});
		tituloTable.setWidthPercentage(100f);	
		
		Paragraph titulo = createParagraph("Formulário de Resseguro - Facultativo", fontTitulo); 
		PdfPCell tituloCell = new PdfPCell(titulo);	
		tituloCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		tituloCell.setBorderWidth(LARGURA_BORDA_TITULO);
		tituloCell.setPaddingTop(1f);	
		
		PdfPCell emptyCell = createEmptyCell();
		
		tituloTable.addCell(tituloCell);
		tituloTable.addCell(emptyCell);
		
		document.add(tituloTable);
		document.add(logo);
	}

	private Image criaLogoTokioMarine() throws MalformedURLException, BadElementException, IOException {
		URL urlLogo = contextAware.getServletContext().getResource("/resources/imagens/logo2.png");
		Image logo = Image.getInstance(urlLogo);
		logo.scalePercent(40f);
		
		float y = pageSize.getHeight() - (logo.getHeight()/2);
		float x = pageSize.getWidth() - (logo.getWidth()/2);
		logo.setAbsolutePosition(x, y);
		
		return logo;
	}
	
	private void criaSecaoDadosCotacao(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable tableDados = new PdfPTable(4);		
		tableDados.setWidthPercentage(100);
		
		PdfPCell subscritor = createCellFieldAndValue("Subscritor", dados.getFormatedSubscritor());
		PdfPCell ramo = createCellFieldAndValue("Ramo", dados.getFormatedRamo());
		PdfPCell moeda = createCellFieldAndValue("Moeda", dados.getFormatedMoeda());
		PdfPCell data = createCellFieldAndValue("Data", dados.getFormatedData());
		
		tableDados.addCell(subscritor);
		tableDados.addCell(ramo);
		tableDados.addCell(moeda);
		tableDados.addCell(data);		
				
		document.add(tableDados);
	}
	
	private void criaSecaoDadosDoRisco(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException{
		criaTituloSecaoDadosDoRisco(document);
		addEmptyLine(document, 1);
		criaCorpoSecaoDadosDoRisco(document, dados);		
	}

	private void criaSecaoBroken(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable linha1 = new PdfPTable(1);
		linha1.setWidthPercentage(100);	
		PdfPCell broken = createCellFieldAndValue("Broken", dados.getFormatedBroker());
		addCellsToTable(linha1, broken);		
		document.add(linha1);
		
		PdfPTable linha2 = new PdfPTable(1);
		linha2.setWidthPercentage(100f);
		addCellsToTable(linha2, createCellFieldAndValue("Security", dados.getFormatedSecurity()) );
		document.add(linha2);
		
		PdfPTable linha3 = new PdfPTable(1);
		linha3.setWidthPercentage(100f);
		addCellsToTable(linha3, createCellFieldAndValue("Há mais de um broken no risco", dados.getFormatedMaisDeUmBroken()) );
		document.add(linha3);
		
		if(dados.maisDeUmBroker()){
			PdfPTable linha4 = new PdfPTable(1);
			linha4.setWidthPercentage(100f);
			addCellsToTable(linha4, createCellFieldAndValue("Qual", dados.getFormatedBrokenAdicional()) );
			document.add(linha4);
		}		
	}

	private void criaTituloSecaoDadosDoRisco(Document document) throws DocumentException {
		Font fontTitulo = new Font();
		fontTitulo.setSize(9f);
		fontTitulo.setStyle(Font.BOLD);
		
		
		PdfPTable dadosRiscoTable = new PdfPTable(1);
		dadosRiscoTable.setWidthPercentage(100);	
		
		Paragraph titulo = createParagraph("Dados do Risco", fontTitulo); 
		PdfPCell tituloCell = new PdfPCell(titulo);	
		tituloCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		tituloCell.setPaddingTop(1f);		
		
		dadosRiscoTable.addCell(tituloCell);
		
		document.add(dadosRiscoTable);
	}
	
	private void criaCorpoSecaoDadosDoRisco(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException{
		document.add(criaLinha1CorpoSecaoDadosRisco(dados));
		document.add(criaLinha2CorpoSecaoDadosRisco(dados));
		document.add(criaLinha3CorpoSecaoDadosRisco(dados));
	}

	private PdfPTable criaLinha1CorpoSecaoDadosRisco(DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable linha = new PdfPTable(3);
		linha.setWidths(new float[] {6f, 3f, 3f});
		linha.setWidthPercentage(100);		
		
		PdfPCell segurado = createCellFieldAndValue("Segurado", dados.getFormatedSegurado());
		PdfPCell apolice = createCellFieldAndValue("N° Apólice", dados.getFormatedApolice());
		PdfPCell emptyCell = createEmptyCell();		
		
		linha.addCell(segurado);
		linha.addCell(apolice);
		linha.addCell(emptyCell);
		
		return linha;
	}
	
	private PdfPTable criaLinha2CorpoSecaoDadosRisco(DadosRelatorioResseguroFacultativo dados) {
		PdfPTable linha = new PdfPTable(4);
		linha.setWidthPercentage(100);	
		
		PdfPCell vigenciaDe = createCellFieldAndValue("Vigência de", dados.getFormatedInicioVigencia());
		PdfPCell ate = createCellFieldAndValue("até", dados.getFormatedFimVigencia());
		PdfPCell lmrLmg = createCellFieldAndValue("LMR/LMG", dados.getFormatedValorLmrLmg());
		PdfPCell premioSeg = createCellFieldAndValue("Prêmio de Seg", dados.getFormatedPremioSeguro());
		
		linha.addCell(vigenciaDe);
		linha.addCell(ate);
		linha.addCell(lmrLmg);
		linha.addCell(premioSeg);		
		
		return linha;
	}
	
	private PdfPTable criaLinha3CorpoSecaoDadosRisco(DadosRelatorioResseguroFacultativo dados) {
		PdfPTable linha = new PdfPTable(4);
		linha.setWidthPercentage(100);	
		
		PdfPCell cosseguro = createCellFieldAndValue("Cosseguro", dados.getFormatedCosseguro());
		PdfPCell porcentagemCosseguro = createCellFieldAndValue("% Cosseguro", dados.getFormatedPorcentagemCosseguro());
		
		linha.addCell(cosseguro);
		linha.addCell(porcentagemCosseguro);
		linha.addCell(createEmptyCell());
		linha.addCell(createEmptyCell());
		
		return linha;
	}
	
	private void criaSecaoDistribuicoes(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		if(dados.getIdCessao().equals(IdCessaoEnum.CESSAO_UNICA)){
			criaDistribuicoesCessaoUnica(document, dados);
		}else{
			criaDistribuicoesPorFaixas(document, dados);
		}
		
	}

	private void criaDistribuicoesCessaoUnica(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable table = new PdfPTable(5);
		table.setWidthPercentage(100);
		
		PdfPCell headerCell1 = createTableHeaderCell("");
		PdfPCell headerCell2 = createTableHeaderCell("% - Cedido em Resseguro");
		PdfPCell headerCell3 = createTableHeaderCell("% - Retido em Resseguro");
		headerCell1.setColspan(3);
		
		table.addCell(headerCell1);
		table.addCell(headerCell2);
		table.addCell(headerCell3);
		table.setHeaderRows(1);
		
		DadosRelatorioCessao cessao = dados.getCessoes().stream().findFirst().orElse(new DadosRelatorioCessao(null, null, null, null));
		
		PdfPCell isLmg = createTableHeaderCell("IS/LMG - Cessão Única");		
		PdfPCell ate = createTableCellWithHorizontalCenterAlign("até");		
		
		PdfPCell valorFinal = createTableCellWithHorizontalRightAlign(cessao.getFormatedValorFinal());
		PdfPCell percentualCedidoResseg = createTableCellWithHorizontalRightAlign(cessao.getFormatedPercentualCedidoEmResseguro());
		PdfPCell percentualRetidoResseg = createTableCellWithHorizontalRightAlign(cessao.getFormatedPercentulRetidoEmResseguro());
		
		addCellsToTable(table, isLmg, ate, valorFinal, percentualCedidoResseg, percentualRetidoResseg);
		document.add(table);
	}
	
	private void criaDistribuicoesPorFaixas(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable table = new PdfPTable(5);
		table.setWidthPercentage(100);
		
		PdfPCell headerCell1 = createTableHeaderCell("");
		PdfPCell headerCell2 = createTableHeaderCell("% - Cedido em Resseguro");
		headerCell1.setColspan(4);
		
		table.addCell(headerCell1);
		table.addCell(headerCell2);
		table.setHeaderRows(1);
		
		dados.getCessoes().forEach(item -> {
			PdfPCell faixa = createTableHeaderCell("IS/LMG - " + item.getFormatedFaixa() + "º Faixa");
			PdfPCell valorInicial = createTableCellWithHorizontalRightAlign(item.getValorInicial());
			PdfPCell ate = createTableCellWithHorizontalCenterAlign("até");			
			PdfPCell valorFinal = createTableCellWithHorizontalRightAlign(item.getFormatedValorFinal());
			PdfPCell porcentualCedidoResseg = createTableCellWithHorizontalRightAlign(item.getFormatedPercentualCedidoEmResseguro());
			addCellsToTable(table, faixa, valorInicial, ate, valorFinal, porcentualCedidoResseg);
		});		
		
		document.add(table);
	}

	private void criaSecaoDemaisDados(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		criaLinha1SecaoDemaisDados(document, dados);
		//criaLinha2SecaoDemaisDados(document, dados);
		criaLinha3SecaoDemaisDados(document, dados);
		criaLinha4SecaoDemaisDados(document, dados);
	}

	private void criaLinha1SecaoDemaisDados(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable linha = new PdfPTable(3);
		linha.setWidthPercentage(100f);
		
		PdfPCell tipoResseguro = createCellFieldAndValue("Tipo de Resseguro", dados.getFormatedTipoResseguro());
		PdfPCell nroParcelasSeg = createCellFieldAndValue("Nº parcelas de Seg.", dados.getFormatedNroParcelasSeguro());
		PdfPCell nroParcelasResseg = createCellFieldAndValue("Nº parcelas de Resseg.", dados.getFormatedNroParcelasResseguro());
		
		addCellsToTable(linha, tipoResseguro, nroParcelasSeg, nroParcelasResseg);
		document.add(linha);
	}

	private void criaLinha3SecaoDemaisDados(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable linha = new PdfPTable(3);
		linha.setWidthPercentage(100f);		
		
		PdfPCell porcentagemUtiloContratoAutomatico = createCellFieldAndValue("% cedido com intragrupo", dados.getFormatedPercentualCedidoIntragrupo());
		PdfPCell porcentagemLimiteTecnico = createCellFieldAndValue("% cessão local", dados.getFormatedPercentualCessaoLocal());
		PdfPCell haReintegracaoAutomatica = createCellFieldAndValue("Reintegração automática na AP(E.D.)?", dados.getFormatedReintegracaoAutomaticaNaAP());
		
		addCellsToTable(linha, porcentagemUtiloContratoAutomatico, porcentagemLimiteTecnico, haReintegracaoAutomatica);
		document.add(linha);
	}

	private void criaLinha4SecaoDemaisDados(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException{
		PdfPTable linha = new PdfPTable(2);
		linha.setWidthPercentage(100f);
		
		PdfPCell porcentagemUtiloContratoAutomatico = createCellFieldAndValue("% de utilização do Contrato Automático", dados.getFormatedPorcentagemUtilizacaoContratoAutomatico());
		PdfPCell porcentagemLimiteTecnico = createCellFieldAndValue("% utilizado em Limite Técnico (LT)/Retenção (Sem Contrato)", dados.getFormatedPorcentagemUtilizadoLimiteTecnico());
		
		addCellsToTable(linha, porcentagemUtiloContratoAutomatico, porcentagemLimiteTecnico);
		
		document.add(linha);
	}
	
	private void criaSecaoResseguradoresELloyds(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable table = new PdfPTable(8);
		table.setWidthPercentage(100);
		if(dados.getIdCessao().equals(IdCessaoEnum.CESSAO_UNICA))
			table.setWidths(new float[]{0, 1, 6, 2, 2, 2, 2 ,2});
		else		
			table.setWidths(new float[]{1, 1, 6, 2, 2, 2, 2 ,2});
		
		//header
		PdfPCell faixaHeader = createTableHeaderCell("Faixa");
		PdfPCell susepHeader = createTableHeaderCell("Cód. Susep");
		PdfPCell resseguradoresHeader = createTableHeaderCell("Resseguradores ou Lloyds");
		PdfPCell premioResseguroHeader = createTableHeaderCell("Prêmio de Resseguro");
		PdfPCell porcentagemParticipacaoHeader = createTableHeaderCell("% de participação");
		PdfPCell premioPorResseguradorHeader = createTableHeaderCell("Prêmio por Ressegurador");
		PdfPCell porcentatemComissaoRessegHeader = createTableHeaderCell("% Comissão Resseguro");
		PdfPCell premioLiqHeader = createTableHeaderCell("Prêmio Liquido por ressegurador");
		
		addCellsToTable(table, faixaHeader, susepHeader, resseguradoresHeader, premioResseguroHeader, porcentagemParticipacaoHeader, premioPorResseguradorHeader,  porcentatemComissaoRessegHeader, premioLiqHeader);
		table.setHeaderRows(2);
		
		//footer
		PdfPCell totalCell = createTableFooterCellWithRightAlign("Total");
		totalCell.setColspan(4);
		PdfPCell somaPorcentagemParticipcao = createTableFooterCellWithRightAlign(dados.getFormatedSomaPercentuaisParticpacao());
		PdfPCell emptyCell = createEmptyCell();
		emptyCell.setColspan(2);
		PdfPCell somaPremioLiqResseguradores = createTableFooterCellWithRightAlign(dados.getFormatedSomaPremioLiquidoPorRessegurador());
		addCellsToTable(table, totalCell, somaPorcentagemParticipcao, emptyCell, somaPremioLiqResseguradores);
		
		table.setFooterRows(1);
		
		//body
		dados.getResseguradoresOuLloyds().forEach(resseg -> {
			PdfPCell faixa = createTableCellWithHorizontalCenterAlign(resseg.getFormatedFaixa());
			PdfPCell susep = createTableCellWithHorizontalRightAlign(resseg.getFormatedCodigoSusep());
			PdfPCell resseguradores = createTableCellWithHorizontalCenterAlign(resseg.getFormatedNome());
			PdfPCell premioResseguro = createTableCellWithHorizontalRightAlign(resseg.getFormatedPremioDeResseguro());
			PdfPCell participacao = createTableCellWithHorizontalRightAlign(resseg.getFormatedPorcentagemDeParticipacao());
			PdfPCell premioPorRessegurador = createTableCellWithHorizontalRightAlign(resseg.getFormatedPremioPorRessegurador());
			PdfPCell comissaoResseguro = createTableCellWithHorizontalRightAlign(resseg.getFormatedPorcentagemComissaoResseguro());
			PdfPCell premioLiqRessegurador = createTableCellWithHorizontalRightAlign(resseg.getFormatedPremioLiquidoPorRessegurador());
			
			addCellsToTable(table, faixa, susep, resseguradores, premioResseguro, participacao, premioPorRessegurador, comissaoResseguro, premioLiqRessegurador);
		});
		
		document.add(table);
	}

	private void criaSecaoObservacoes(Document document, DadosRelatorioResseguroFacultativo dados) throws DocumentException {
		PdfPTable table = new PdfPTable(1);
		table.setWidthPercentage(100f);
		
		PdfPCell observacoesField = createCellFieldAndValue("Observações", "");			
		PdfPCell observacoesValue = createTableCellWithHorizontalLeftAlign(dados.getFormatedObservacoes());		
		observacoesValue.setBorderWidth(0);
		
		addCellsToTable(table, observacoesField, observacoesValue);
		document.add(table);
	}

	private PdfPCell createEmptyCell(){
		PdfPCell cell = new PdfPCell();
		cell.setBorderWidth(0f);
		
		return cell;
	}
	
	private PdfPCell createCellFieldAndValue(String textField, String textValue){
		Paragraph paragraph = createFieldAndValue(textField, textValue);
		
		PdfPCell cell = new PdfPCell(paragraph);
		cell.setBorderWidth(0f);
		
		return cell;
	}

	private Paragraph createFieldAndValue(String textField, String textValue) {
		Font fieldFont = new Font();
		fieldFont.setSize(8f);
		fieldFont.setStyle(Font.BOLD);
		
		Font valueFont = new Font();
		valueFont.setSize(8f);
		
		Chunk field = createChunk(textField, fieldFont);
		Chunk separator = createChunk(": ", fieldFont);
		Chunk value = createChunk(textValue, valueFont);
		
		Paragraph paragraph = createParagraph(field, separator, value);
		return paragraph;
	}	
	
	private PdfPCell createTableHeaderCell(String text){
		return createBoldTableCell(text);
	}
	
	private PdfPCell createTableFooterCellWithRightAlign(String text){
		PdfPCell footerCell = createBoldTableCell(text);
		footerCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		
		return footerCell;
	}

	private PdfPCell createBoldTableCell(String text) {
		Font font = new Font();
		font.setSize(8f);
		font.setStyle(Font.BOLD);
		
		Paragraph paragraph = createParagraph(text, font);
		
		PdfPCell cell = new PdfPCell(paragraph);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);

		return cell;
	}
	
	private PdfPCell createTableCell(String text, Font font){
		Paragraph paragraph = createParagraph(text, font);
		PdfPCell tableCell = new PdfPCell(paragraph);
		//tableCell.setBorderWidth(1f);
		
		return tableCell;
	}
	
	private PdfPCell createTableCell(String text){
		Font font = new Font();
		font.setSize(8f);
		
		return createTableCell(text, font);
	}
	
	private PdfPCell createTableCell(String text, int horizontalAlign){
		PdfPCell cell = createTableCell(text);
		cell.setHorizontalAlignment(horizontalAlign);
		
		return cell;
	}
	
	private PdfPCell createTableCellWithHorizontalCenterAlign(String text){
		return createTableCell(text, Element.ALIGN_CENTER);
	}
	
	private PdfPCell createTableCellWithHorizontalLeftAlign(String text){
		return createTableCell(text, Element.ALIGN_LEFT);
	}
	
	private PdfPCell createTableCellWithHorizontalRightAlign(String text){
		return createTableCell(text, Element.ALIGN_RIGHT);
	}
	
	
	
	private void addEmptyLine(Document document, int numeroLinhas) throws DocumentException{
		for (int i = 0; i < numeroLinhas; i++) {
			document.add(new Paragraph(" "));
		}
	}	
	
	
	private void addCellsToTable(PdfPTable table, PdfPCell... cells) {
		
		for (PdfPCell cell : cells) {
			table.addCell(cell);
		}
		
	}

	private Paragraph createParagraph(String text, Font font) {
		Chunk chunk = new Chunk(text, font);
		
		Paragraph paragraph = new Paragraph(40);
		paragraph.setSpacingAfter(20);
		paragraph.setSpacingBefore(20);
		paragraph.add(chunk);
		return paragraph;
	}
	
	private Paragraph createParagraph(Chunk... chunks){
		return createParagraph(20f, 20f, chunks);
	}
	
	
	private Paragraph createParagraph(float spacingAfter, float spacingBefore, Chunk... chunks){
		Paragraph paragraph = new Paragraph(40);
		paragraph.setSpacingAfter(spacingAfter);
		paragraph.setSpacingBefore(spacingBefore);
		
		for (Chunk chunk : chunks) {
			paragraph.add(chunk);
		}
		
		return paragraph;
	}
	
	private Chunk createChunk(String text, Font font){
		return new Chunk(text, font);
	}

}
