package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.AtividadeSegurado;
import br.com.tokiomarine.ctpj.infra.mongo.repository.AtividadeSeguradoRepository;

@Service
public class AtividadeSeguradoService {

	private static Logger logger = LogManager.getLogger(AtividadeSeguradoService.class);

	@Autowired
	private AtividadeSeguradoRepository atividadeSeguradoRepository;

	@LogPerformance
	public AtividadeSegurado getAtividadeSegurado(Integer classe,Integer digitoVerificador,Integer subClasse) throws ServiceException {
		try {
			return atividadeSeguradoRepository.getAtividadeSegurado(classe,digitoVerificador,subClasse);
		} catch (RepositoryException e) {
			logger.error("Erro ao Buscar Atividade do Segurado",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public List<AtividadeSegurado> findAllByNome(String q) throws ServiceException {
		try {
			return atividadeSeguradoRepository.findAllByNome(q);
		} catch (RepositoryException e) {
			logger.error("Erro ao Buscar Atividade do Segurado",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public List<AtividadeSegurado> findAll() throws ServiceException {
		try {
			return atividadeSeguradoRepository.findAll();
		} catch (RepositoryException e) {
			logger.error("Erro ao Buscar Lista de Atividades do Segurado",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public AtividadeSegurado getAtividadeSegurado(Integer atividadePrincipal) {
		return atividadeSeguradoRepository.getAtividadeSegurado(atividadePrincipal);
	}

	@LogPerformance
	public AtividadeSegurado getAtividadeSeguradoAtivo(Integer atividadePrincipal) {
		return atividadeSeguradoRepository.getAtividadeSeguradoAtivo(atividadePrincipal);
	}
}
