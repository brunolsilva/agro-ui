package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativoCessao;

@Repository
public class ResseguroFacultativoCessaoRepository extends BaseDAO{
	
	public BigInteger save(ResseguroFacultativoCessao rfc){
		return (BigInteger) getCurrentSession().save(rfc);
	}

}
