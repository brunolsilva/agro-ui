package br.com.tokiomarine.ctpj.cotacao.dto;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class LinhaClausulaNotaView {

	private boolean selecionado = false;
	private Integer codigoClausulaNota;
	private String descricaoClausulaNota;
	private String descricaoClausulaNotaOriginal;
	private boolean imprime;
	
	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public Integer getCodigoClausulaNota() {
		return codigoClausulaNota;
	}

	public void setCodigoClausulaNota(Integer codigoClausulaNota) {
		this.codigoClausulaNota = codigoClausulaNota;
	}

	public String getDescricaoClausulaNota() {
		return descricaoClausulaNota;
	}

	public void setDescricaoClausulaNota(String descricaoClausulaNota) {
		this.descricaoClausulaNota = descricaoClausulaNota;
	}

	public String getDescricaoClausulaNotaOriginal() {
		return descricaoClausulaNotaOriginal;
	}

	public void setDescricaoClausulaNotaOriginal(String descricaoClausulaNotaOriginal) {
		this.descricaoClausulaNotaOriginal = descricaoClausulaNotaOriginal;
	}

	public boolean isImprime() {
		return imprime;
	}

	public void setImprime(boolean imprime) {
		this.imprime = imprime;
	}

}
