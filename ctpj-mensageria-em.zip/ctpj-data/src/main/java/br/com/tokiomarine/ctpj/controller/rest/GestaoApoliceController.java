package br.com.tokiomarine.ctpj.controller.rest;

import java.math.BigInteger;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.gestaoapolice.request.EmissaoEmprRequest;
import br.com.tokiomarine.ctpj.integracao.gestaoapolice.request.GerarCotacaoRequest;
import br.com.tokiomarine.ctpj.integracao.gestaoapolice.service.GestaoApoliceService;


@Controller
public class GestaoApoliceController {
	
	@Autowired
	private GestaoApoliceService gestaoApoliceService;
	
	
	@Autowired
	private ApoliceRepository apoliceRepository;
		
	private static Logger logger = LogManager.getLogger(GestaoApoliceController.class);
	
	/**
	 * Importa os dados de uma apólice para o mongodb
	 * @param request
	 * @return
	 * @throws RepositoryException
	 */
	@PostMapping(value = "/rest/gestaoApolice/importar")
	@ResponseBody
	public ResponseEntity<?> importar(@RequestBody EmissaoEmprRequest request){
		String mensagemErro = null;
		try {
			Apolice apolice = gestaoApoliceService.buscar(request);
			
			if(apolice == null || apolice.getCodigoApolice() == null) {				
				mensagemErro = "Apólice retornada nula";
				logger.info(mensagemErro);
				return new ResponseEntity<String>(mensagemErro,HttpStatus.INTERNAL_SERVER_ERROR);				
			}
			apolice.setCodigoApolice(request.getNumeroApolice());
			apoliceRepository.save(apolice);
			return new ResponseEntity<String>(apolice.getId(),HttpStatus.CREATED);
		}
		catch(ServiceException se) {
			mensagemErro = "Erro ao buscar apólice no gestaoApolice "; 
			logger.error(mensagemErro, se);
			return new ResponseEntity<String>(mensagemErro,HttpStatus.BAD_REQUEST);
		}
		catch(Exception e) {
			mensagemErro ="Erro ao salvar apólice no mongoDB "; 
			logger.error(mensagemErro, e);
			return new ResponseEntity<String>(mensagemErro,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(value = "/rest/gestaoApolice/gerarCotacaoPorApolice")
	@ResponseBody
	public ResponseEntity<String> gerarCotacaoPorApoliceId(@RequestBody GerarCotacaoRequest request) throws ServiceException {
		try{
			if(StringUtils.isEmpty(request.getIdMongo())) {
				return new ResponseEntity<>("O parâmetro idMongo é de preenchimento obrigatório",HttpStatus.BAD_REQUEST);
			}	
			Apolice apolice = apoliceRepository.findById(request.getIdMongo());
			if(apolice==null) {
				return new ResponseEntity<>("Nenhuma apólice encontrada para o idMongo informado",HttpStatus.BAD_REQUEST);
			}	
			
			if(gestaoApoliceService.cotacaoExiste(BigInteger.valueOf(apolice.getCodigoApolice()))) {
				return new ResponseEntity<>("Número Cotação "+apolice.getCodigoApolice()+" já existente na base de dados",HttpStatus.CONFLICT);
			}
			Cotacao cotacao = gestaoApoliceService.gerarCotacaoPorApolice(apolice);
			return new ResponseEntity<>("sqCotacPpota gerado: "+cotacao.getSequencialCotacaoProposta().toString(),HttpStatus.CREATED);
		}
		catch(Exception e) {
			logger.error("Erro ao gerar cotação por apólice (gestaoApolice) ", e);
			return new ResponseEntity<>("Ocorreu um erro ao gerar a cotação", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
