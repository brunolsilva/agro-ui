package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorBooleano;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorDateRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorMonetarioRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorPercentualRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorStringRelatorio;
import br.com.tokiomarine.ctpj.enums.IdCessaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoResseguroEnum;

/**
 * Dados a serem exibidos no relatório de resseguro facultativo
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class DadosRelatorioResseguroFacultativo {
	
	private static final FormatadorStringRelatorio FORMATADOR_STRING = new FormatadorStringRelatorio();
	private static final FormatadorDateRelatorio FORMATADOR_DATA = new FormatadorDateRelatorio();
	private static final FormatadorMonetarioRelatorio FORMATADOR_MONETARIO = new FormatadorMonetarioRelatorio();
	private static final FormatadorPercentualRelatorio FORMATADOR_PERCENTUAL = new FormatadorPercentualRelatorio();
	private static final FormatadorBooleano FORMATADOR_BOOLEANO = new FormatadorBooleano();
	
	private BigInteger seqCotacao;
	private String subscritor;
	private Integer ramo;
	private String apolice;
	private MoedaEnum moeda;
	private Date data;
	private String segurado;
	private Date inicioVigencia;
	private Date fimVigencia;
	private BigDecimal premioSeguro;
	private BigDecimal valorLmrLmg;
	private String cosseguro;
	private BigDecimal porcentagemCosseguro;
	private String broker;
	private String security;
	private IdCessaoEnum idCessao;
	private List<DadosRelatorioCessao> cessoes;
	private TipoResseguroEnum tipoResseguro;
	private Integer nroParcelasSeguro;
	private Integer nroParcelasResseguro;
	private String brokerAdicional;
	private Boolean reintegracaoAutomaticaNaAP;
	private BigDecimal porcentagemUtilizacaoContratoAutomatico;
	private BigDecimal porcentagemUtilizadoLimiteTecnico;
	private BigDecimal percentualCedidoIntraGrupo;
	private BigDecimal percentualCessaoLocal;
	private List<DadosDistribRessegLloyds> resseguradoresOuLloyds;
	private String observacoes;

	public boolean maisDeUmBroker(){
		return brokerAdicional != null && !brokerAdicional.isEmpty() ? true : false;
	}
	
	public String getFormatedSeqCotacao() {		
		return FORMATADOR_STRING.asString(seqCotacao);
	}

	public String getFormatedSubscritor() {
		return FORMATADOR_STRING.asString(subscritor);
	}

	public String getFormatedRamo() {
		return FORMATADOR_STRING.asString(ramo);
	}

	public String getFormatedApolice() {
		return FORMATADOR_STRING.asString(apolice);
	}

	public String getFormatedMoeda() {
		return moeda == null ? "" : moeda.getValor();
	}

	public String getFormatedData() {
		return FORMATADOR_DATA.asFormatedDate(data);
	}

	public String getFormatedSegurado() {
		return FORMATADOR_STRING.asString(segurado);
	}

	public String getFormatedInicioVigencia() {
		return FORMATADOR_DATA.asFormatedDate(inicioVigencia);
	}

	public String getFormatedFimVigencia() {
		return FORMATADOR_DATA.asFormatedDate(fimVigencia);
	}

	public String getFormatedPremioSeguro() {
		return FORMATADOR_MONETARIO.asMoney(premioSeguro);
	}

	public String getFormatedValorLmrLmg() {
		return FORMATADOR_MONETARIO.asMoney(valorLmrLmg);
	}

	public String getFormatedCosseguro() {
		return FORMATADOR_STRING.asString(cosseguro);
	}

	public String getFormatedPorcentagemCosseguro(){
		return FORMATADOR_PERCENTUAL.asPercent(porcentagemCosseguro);
	}	

	public String getFormatedBroker() {
		return FORMATADOR_STRING.asString(broker);
	}

	public String getFormatedIdCessao() {
		if(idCessao == null)
			return "";		
		
		return idCessao.getDescricao();
	}

	public List<DadosRelatorioCessao> getCessoes() {
		return cessoes;
	}

	public String getFormatedTipoResseguro() {
		if(tipoResseguro == null)
			return "";
		
		return tipoResseguro.getDescricao();
	}

	public String getFormatedNroParcelasSeguro() {
		return  FORMATADOR_STRING.asString(nroParcelasSeguro);
	}

	public String getFormatedNroParcelasResseguro() {
		return FORMATADOR_STRING.asString(nroParcelasResseguro);
	}
	
	public String getFormatedMaisDeUmBroken(){
		return FORMATADOR_BOOLEANO.asString(maisDeUmBroker());
	}

	public String getFormatedBrokenAdicional() {
		return FORMATADOR_STRING.asString(brokerAdicional);
	}

	public String getFormatedReintegracaoAutomaticaNaAP() {
		return FORMATADOR_BOOLEANO.asString(reintegracaoAutomaticaNaAP);
	}

	public String getFormatedPorcentagemUtilizacaoContratoAutomatico() {
		return FORMATADOR_PERCENTUAL.asPercent(porcentagemUtilizacaoContratoAutomatico);
	}
	
	public String getFormatedPorcentagemUtilizadoLimiteTecnico(){
		return FORMATADOR_PERCENTUAL.asPercent(porcentagemUtilizadoLimiteTecnico);
	}
	
	public String getFormatedSecurity(){
		return FORMATADOR_STRING.asString(security);
	}

	public List<DadosDistribRessegLloyds> getResseguradoresOuLloyds() {
		return resseguradoresOuLloyds;
	}

	public String getFormatedObservacoes() {
		return FORMATADOR_STRING.asString(observacoes);
	}
	
	public String getFormatedSomaPercentuaisParticpacao(){
		BigDecimal soma = resseguradoresOuLloyds.stream().map(DadosDistribRessegLloyds::getPorcentagemDeParticipacao).reduce(BigDecimal.ZERO, (a, b) -> a.add(b));
		return FORMATADOR_PERCENTUAL.asPercent(soma);
	}
	
	public String getFormatedSomaPremioLiquidoPorRessegurador(){
		BigDecimal soma = resseguradoresOuLloyds.stream().map(DadosDistribRessegLloyds::getPremioLiquidoPorRessegurador).reduce(BigDecimal.ZERO, (a, b) -> a.add(b));		
		return FORMATADOR_MONETARIO.asMoney(soma);
	}

	public void setSeqCotacao(BigInteger seqCotacao) {
		this.seqCotacao = seqCotacao;
	}

	public void setSubscritor(String subscritor) {
		this.subscritor = subscritor;
	}

	public void setRamo(Integer ramo) {
		this.ramo = ramo;
	}

	public void setApolice(String apolice) {
		this.apolice = apolice;
	}

	public void setMoeda(MoedaEnum moeda) {
		this.moeda = moeda;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public void setSegurado(String segurado) {
		this.segurado = segurado;
	}

	public void setInicioVigencia(Date inicioVigencia) {
		this.inicioVigencia = inicioVigencia;
	}

	public void setFimVigencia(Date fimVigencia) {
		this.fimVigencia = fimVigencia;
	}

	public void setPremioSeguro(BigDecimal premioSeguro) {
		this.premioSeguro = premioSeguro;
	}

	public void setValorLmrLmg(BigDecimal valorLmrLmg) {
		this.valorLmrLmg = valorLmrLmg;
	}

	public void setCosseguro(String cosseguro) {
		this.cosseguro = cosseguro;
	}
	
	public void setPorcentagemCosseguro(BigDecimal porcentagemCosseguro){
		this.porcentagemCosseguro = porcentagemCosseguro;
	}

	public void setBroker(String broker) {
		this.broker = broker;
	}
	
	public void setIdCessao(IdCessaoEnum idCessao) {
		this.idCessao = idCessao;
	}

	public void setCessoes(List<DadosRelatorioCessao> cessoes) {
		this.cessoes = cessoes;
	}

	public void setTipoResseguro(TipoResseguroEnum tipoResseguro) {
		this.tipoResseguro = tipoResseguro;
	}

	public void setNroParcelasSeguro(Integer nroParcelasSeguro) {
		this.nroParcelasSeguro = nroParcelasSeguro;
	}

	public void setNroParcelasResseguro(Integer nroParcelasResseguro) {
		this.nroParcelasResseguro = nroParcelasResseguro;
	}

	public void setBrokerAdicional(String brokenAdicional) {
		this.brokerAdicional = brokenAdicional;
	}

	public void setReintegracaoAutomaticaNaAP(Boolean reintegracaoAutomaticaNaAP) {
		this.reintegracaoAutomaticaNaAP = reintegracaoAutomaticaNaAP;
	}

	public void setPorcentagemUtilizacaoContratoAutomatico(BigDecimal porcentagemUtilizacaoContratoAutomatico) {
		this.porcentagemUtilizacaoContratoAutomatico = porcentagemUtilizacaoContratoAutomatico;
	}
	
	public void setPorcentagemUtilizadoLimiteTecnico(BigDecimal porcentagemUtilizadoLimiteTecnico){
		this.porcentagemUtilizadoLimiteTecnico = porcentagemUtilizadoLimiteTecnico;
	}


	public void setResseguradoresOuLloyds(List<DadosDistribRessegLloyds> resseguradoresOuLloyds) {
		this.resseguradoresOuLloyds = resseguradoresOuLloyds;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}	
	
	public String getFormatedPercentualCedidoIntragrupo() {
		return FORMATADOR_PERCENTUAL.asPercent(percentualCedidoIntraGrupo);
	}

	public String getFormatedPercentualCessaoLocal() {
		return FORMATADOR_PERCENTUAL.asPercent(percentualCessaoLocal);
	}	

	public BigInteger getSeqCotacao() {
		return seqCotacao;
	}

	public String getSubscritor() {
		return subscritor;
	}

	public Integer getRamo() {
		return ramo;
	}

	public String getApolice() {
		return apolice;
	}

	public MoedaEnum getMoeda() {
		return moeda;
	}

	public Date getData() {
		return data;
	}

	public String getSegurado() {
		return segurado;
	}

	public Date getInicioVigencia() {
		return inicioVigencia;
	}

	public Date getFimVigencia() {
		return fimVigencia;
	}

	public BigDecimal getPremioSeguro() {
		return premioSeguro;
	}

	public BigDecimal getValorLmrLmg() {
		return valorLmrLmg;
	}

	public String getCosseguro() {
		return cosseguro;
	}

	public BigDecimal getPorcentagemCosseguro() {
		return porcentagemCosseguro;
	}	

	public String getBroker() {
		return broker;
	}

	public IdCessaoEnum getIdCessao() {
		return idCessao;
	}

	public TipoResseguroEnum getTipoResseguro() {
		return tipoResseguro;
	}

	public Integer getNroParcelasSeguro() {
		return nroParcelasSeguro;
	}

	public Integer getNroParcelasResseguro() {
		return nroParcelasResseguro;
	}	

	public String getBrokerAdicional() {
		return brokerAdicional;
	}

	public boolean isReintegracaoAutomaticaNaAP() {
		return reintegracaoAutomaticaNaAP;
	}

	public BigDecimal getPorcentagemUtilizacaoContratoAutomatico() {
		return porcentagemUtilizacaoContratoAutomatico;
	}

	public BigDecimal getPorcentagemUtilizadoLimiteTecnico() {
		return porcentagemUtilizadoLimiteTecnico;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}	

	public Boolean getReintegracaoAutomaticaNaAP() {
		return reintegracaoAutomaticaNaAP;
	}

	public BigDecimal getPercentualCedidoIntraGrupo() {
		return percentualCedidoIntraGrupo;
	}

	public void setPercentualCedidoIntraGrupo(BigDecimal percentualCedidoIntragrupo) {
		this.percentualCedidoIntraGrupo = percentualCedidoIntragrupo;
	}

	public BigDecimal getPercentualCessaoLocal() {
		return percentualCessaoLocal;
	}

	public void setPercentualCessaoLocal(BigDecimal percentualCessaoLocal) {
		this.percentualCessaoLocal = percentualCessaoLocal;
	}	
	

}
