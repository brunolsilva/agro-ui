package br.com.tokiomarine.ctpj.cotacao.service;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.ProcessaLogin;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.EndossoMapper;
import br.com.tokiomarine.ctpj.mapper.RenovacaoMapper;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class RenovacaoService {
	
	private static Logger logger = LogManager.getLogger(RenovacaoService.class);
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	private static final Integer VS_COTAC_FIRST = 1;
	
	@LogPerformance
	public Cotacao processaSeguroRenovacaoTokio(CtpjToken token,User user,ProcessaLogin processaLogin) throws Exception {
		
		SolicitacaoCotacao solicitacaoCotacao = token.getSolicitacaoCotacao();
		
		Cotacao cotacao = cotacaoRepository.findCotacaoTelaByNumeroCotacao(solicitacaoCotacao.getNrSolctCotac());

		if(cotacao == null){
			logger.info("Salvando Renovacao para Apólice");
			logger.info("Renovacao........: " + solicitacaoCotacao.getIcTipoSegur().getDescricao());
			logger.info("nrSolctCotac.....: " + solicitacaoCotacao.getNrSolctCotac());
			logger.info("cdRamoPrdutRenov : " + solicitacaoCotacao.getCdRamoPrdutRenov());
			logger.info("cdApoliRenov ....: " + solicitacaoCotacao.getCdApoliRenov());

			Apolice apolice = apoliceRepository.findById(solicitacaoCotacao.getIdMongodb());
			
			if(apolice == null){
				throw new Exception("Não foi encontrada uma apólice da solicitação "+solicitacaoCotacao.getNrSolctCotac()+" para o id " + solicitacaoCotacao.getIdMongodb());
			}	
			
			cotacao = RenovacaoMapper.INSTANCE.fromApoliceToCotacao(apolice, solicitacaoCotacao, VS_COTAC_FIRST);
			cotacaoRepository.save(cotacao);
		}
		
		return cotacao;
		
	}

}
