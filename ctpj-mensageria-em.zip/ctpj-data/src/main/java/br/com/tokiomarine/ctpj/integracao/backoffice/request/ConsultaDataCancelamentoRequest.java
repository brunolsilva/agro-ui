package br.com.tokiomarine.ctpj.integracao.backoffice.request;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsultaDataCancelamentoRequest implements Serializable{

	private static final long serialVersionUID = 6612123223826100824L;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "America/Sao_Paulo")
	private Date diaFechamento;

	@JsonProperty("codPais")
	private String codPais;

	@JsonProperty("codEstado")
	private String codEstado;
	
	@JsonProperty("codCidade")
	private Integer codCidade;

	@JsonProperty("tipoCalc")
	private Integer tipoCalc;

	@JsonProperty("tipoDias")
	private String tipoDias;
	
	@JsonProperty("qtdDias")
	private Integer qtdDias;
	
	@JsonProperty("retDiaUtil")
	private String retDiaUtil;

	public Date getDiaFechamento() {
		return diaFechamento;
	}

	public void setDiaFechamento(Date disFechamento) {
		this.diaFechamento = disFechamento;
	}

	public String getCodPais() {
		return codPais;
	}

	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}

	public String getCodEstado() {
		return codEstado;
	}
	
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public Integer getCodCidade() {
		return codCidade;
	}

	public void setCodCidade(Integer codCidade) {
		this.codCidade = codCidade;
	}
	
	public Integer getTipoCalc() {
		return tipoCalc;
	}

	public void setTipoCalc(Integer tipoCalc) {
		this.tipoCalc = tipoCalc;
	}

	public String getTipoDias() {
		return tipoDias;
	}

	public void setTipoDias(String tipoDias) {
		this.tipoDias = tipoDias;
	}

	public Integer getQtdDias() {
		return qtdDias;
	}

	public void setQtdDias(Integer qtdDias) {
		this.qtdDias = qtdDias;
	}

	public String getRetDiaUtil() {
		return retDiaUtil;
	}

	public void setRetDiaUtil(String retDiaUtil) {
		this.retDiaUtil = retDiaUtil;
	}
	
	@Override
	public String toString() {
		return "ConsultaDataCancelamentoResponse [diaFechamento=" + diaFechamento + ", codPais=" + codPais + 
				", codEstado=" + codEstado + ", codCidade=" + codCidade + 
				", tipoCalc=" + tipoCalc + ", tipoDias=" + tipoDias + ", qtdDias=" + qtdDias + ", retDiaUtil=" + retDiaUtil + "]";
	}
}
