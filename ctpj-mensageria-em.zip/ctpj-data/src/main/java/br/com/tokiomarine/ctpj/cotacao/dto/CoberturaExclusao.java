package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoberturaExclusao implements Serializable {

	private static final long serialVersionUID = -2261387828420320422L;

	private BigInteger sqCobertura;
	private BigInteger sqCotacao;
	private String origem;
	private SimNaoEnum idControleExclusaoEndosso;

	public BigInteger getSqCobertura() {
		return sqCobertura;
	}

	public void setSqCobertura(BigInteger sqCobertura) {
		this.sqCobertura = sqCobertura;
	}

	public BigInteger getSqCotacao() {
		return sqCotacao;
	}

	public void setSqCotacao(BigInteger sqCotacao) {
		this.sqCotacao = sqCotacao;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public SimNaoEnum getIdControleExclusaoEndosso() {
		return idControleExclusaoEndosso;
	}

	public void setIdControleExclusaoEndosso(SimNaoEnum idControleExclusaoEndosso) {
		this.idControleExclusaoEndosso = idControleExclusaoEndosso;
	}

	@Override
	public String toString() {
		return "CoberturaExclusao [sqCobertura=" + sqCobertura + ", sqCotacao=" + sqCotacao + ", origem=" + origem
				+ ", idControleExclusaoEndosso=" + idControleExclusaoEndosso + "]";
	}
}