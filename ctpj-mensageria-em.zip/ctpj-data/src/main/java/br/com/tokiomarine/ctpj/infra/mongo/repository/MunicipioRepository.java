package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dto.SeguradoEndereco;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.FaixaCep;
import br.com.tokiomarine.ctpj.infra.domain.Municipio;

@Repository
public class MunicipioRepository {

	private static Logger logger = LogManager.getLogger(MunicipioRepository.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	/**
	 * Busca realizada ao preencher o cep, recupera a faixa desse cep e seu município
	 *
	 * @param seguradoEndereco obj que será populado com município
	 * @throws RepositoryException
	 */
	public void getMunicipioByCep(SeguradoEndereco seguradoEndereco) throws RepositoryException {
		Integer cep = Integer.valueOf(seguradoEndereco.getCep());

		logger.info("Buscando o municipio do CEP " + cep);

		FaixaCep faixaCep = mongoTemplate.findOne(
				query(where("faixaCepInicial").lte(cep)
						.and("faixaCepFinal").gte(cep)),FaixaCep.class);

		if(faixaCep != null) {
			logger.info(String.format("Faixa CEP encontrada: [%s %s %s]", faixaCep.getCidade(), faixaCep.getFaixaCepInicial(), faixaCep.getFaixaCepFinal()));

			Municipio municipio = mongoTemplate.findOne(
					query(where("codigo").is(faixaCep.getCidade()))
					,Municipio.class);
			if(municipio != null) {
				logger.info("Municipio encontrado: " + municipio.getCodigo() + " " + municipio.getNome());
				seguradoEndereco.setCodigoMunicipio(String.valueOf(municipio.getCodigo()));
				seguradoEndereco.setNomeMunicipio(municipio.getNome());

			} else {
				logger.info("Municipio não encontrado: " + faixaCep.getCidade());
			}
		} else {
			logger.info("Faixa Cep não encontrada: " + cep);
		}
	}

	public List<Municipio> findMunicipios(String uf) throws RepositoryException {
		return mongoTemplate.find(query(where("uf").is(uf)).with(new Sort(Direction.ASC, "nome")), Municipio.class);
	}
}