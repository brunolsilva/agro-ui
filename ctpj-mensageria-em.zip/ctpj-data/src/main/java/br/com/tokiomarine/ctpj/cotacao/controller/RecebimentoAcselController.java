package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.cotacao.dto.AproveitamentoCreditoAcselView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.RecebimentoView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoRecebimentoEnum;
import br.com.tokiomarine.ctpj.exception.ControllerInternalErrorException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.mongo.service.BancoService;
import br.com.tokiomarine.ctpj.integracao.acsel.request.SaldoFupRequest;
import br.com.tokiomarine.ctpj.integracao.acsel.response.SaldoFupResponse;
import br.com.tokiomarine.ctpj.integracao.acsel.service.SaldoFupService;
import br.com.tokiomarine.ctpj.integracao.service.RecebimentoIntegracaoAcselService;
import br.com.tokiomarine.ctpj.mapper.RecebimentoMapper;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping("/recebimentoAcsel")
public class RecebimentoAcselController extends AbstractController{
	private static Logger logger = LogManager.getLogger(RecebimentoAcselController.class);
	
	@Autowired
	private RecebimentoService recebimentoService;

	@Autowired
	private RecebimentoIntegracaoAcselService recebimentoIntegracaoAcselService;
	
	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private BancoService bancoService;
	
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;
	
	@Autowired
	private SaldoFupService saldoFupService;

	@Autowired
	private RecebimentoMapper mapper;
	
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String home(@PathVariable BigInteger sequencialCotacaoProposta, Model model){		
		Set<Recebimento> recebimentos;
		Cotacao cotacao;
		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(sequencialCotacaoProposta);
			cotacao = cotacaoService.findCompleta(sequencialCotacaoProposta);
			recebimentos = cotacao.getListRecebimento();
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			model.addAttribute("bancos",bancoService.findAll());
			model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly());
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}
		model.addAttribute("tiposRecebimentos",TipoRecebimentoEnum.valoresTipoRecebimentoCreditoPA());
		model.addAttribute("sequencialCotacaoProposta", sequencialCotacaoProposta);
		model.addAttribute("recebimentosCotacao", recebimentos);
		model.addAttribute("numeroCotacaoProposta", cotacao.getNumeroCotacaoProposta());
		
		return Paginas.recebimentoAcsel.value();
	}
	
	@GetMapping("/{sequencialCotacaoProposta}/recebimentos")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<RecebimentoView> findRecebimentoBySeqCotacProp(@PathVariable("sequencialCotacaoProposta") BigInteger sequencialCotacaoProposta) throws ServiceException{
		List<Recebimento> listRecebimento = recebimentoService.findRecebimentoBySequencialCotacaoProposta(sequencialCotacaoProposta).stream().collect(Collectors.toList());
		return mapper.toListOfRecebimentoView(listRecebimento);
	}	

	@GetMapping("/listaAproveitamentoCredito")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultadoREST<AproveitamentoCreditoAcselView>> findAproveitamentoCredito(
			@RequestParam("numeroRamoProduto") Integer numeroRamoProduto,
			@RequestParam("numeroApolice") Integer numeroApolice,
			/*@RequestParam("tipoEndosso") Integer tipoEndosso,*/
			@RequestParam("numeroEndosso") Integer numeroEndosso ) throws ServiceException{
		ResultadoREST<AproveitamentoCreditoAcselView> resultado = new ResultadoREST<>();
		try{
			SaldoFupRequest request = new SaldoFupRequest(numeroRamoProduto.toString(), numeroApolice, numeroEndosso);
			SaldoFupResponse response = saldoFupService.find(new SaldoFupRequest(numeroRamoProduto.toString(), numeroApolice, numeroEndosso));
			if(response == null || !Integer.valueOf(response.getRetCode()).equals(0)) {
				resultado.setSuccess(false);					
				List<Validacao> listValidacao = new ArrayList<>();
				listValidacao.add(new Validacao(saldoFupService.tratarMensagem(response)));
				resultado.setListaValidacao(listValidacao);
			}
			else {
				resultado.setSuccess(true);
				resultado.setRetornoObj(new AproveitamentoCreditoAcselView(request.getRamo(), 
						   request.getApolice().toString(), 
						   request.getEndosso().toString(), 
						   response.getValorCreditos().toString()));
			}
			
			///
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Falha na listagem do aproveitamento de crédito.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}

	@GetMapping("/incluiAproveitamentoCredito")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultadoREST<AproveitamentoCreditoAcselView>> incluiAproveitamentoCredito(
			@RequestParam("sequencialCotacaoProposta") BigInteger sequencialCotacaoPropota,
			@RequestParam("numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam("ramo") String ramo,
			@RequestParam("apolice") String apolice,
			@RequestParam("endosso") String endosso) throws ServiceException{
		ResultadoREST<AproveitamentoCreditoAcselView> resultado;
		try{
			
			
			OpcaoParcelamento opcaoParcelamentoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(sequencialCotacaoPropota);
			resultado = recebimentoIntegracaoAcselService.incluirAproveitamentoCredito(sequencialCotacaoPropota,Integer.valueOf(ramo), Long.valueOf(apolice), Long.valueOf(endosso),super.getUser());
			resultado.setSuccess(false);
			if(!resultado.getListaValidacao().isEmpty()) {
				return ResponseEntity.ok(resultado);	
			}
			//faz o calculo das parcelas efetivas
			resultado.getListaValidacao().addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(sequencialCotacaoPropota));
			//caso seja um pagamento a vista, desmarca a opção selecionada
			opcaoParcelamentoService.desmarcarOpcaoParcelamentoSelecionada(opcaoParcelamentoSelecionada);
			if(resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(true);
			}

			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar inclui aproveitamento credito.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}
	
	
	@GetMapping("/excluiRecebimento")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<ResultadoREST<Object>> excluiRecebimento(
			@RequestParam("sequencialCotacaoProposta") BigInteger sequencialCotacaoPropota,
			@RequestParam("numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam("sequencialRecebimento") BigInteger sequencialRecebimento) throws ServiceException{
		ResultadoREST<Object> resultado=null;
		try{
			//guarda o parcelamento selecionado
			OpcaoParcelamento opcaoParcelamentoSelecionado = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(sequencialCotacaoPropota);
			
			
			//exclui o recebimento
			resultado = recebimentoIntegracaoAcselService.excluirRecebimento(sequencialCotacaoPropota,numeroCotacaoProposta,sequencialRecebimento,super.getUser());
			if (resultado.isSuccess()){
				resultado.setSuccess(false);
				//grava a opção de parcelamento selecionada anteriormente pelo usuario
				if(opcaoParcelamentoSelecionado != null){
					resultado.setListaValidacao(opcaoParcelamentoService.salvar(sequencialCotacaoPropota, opcaoParcelamentoSelecionado.getCodigoFormaPagamento(), opcaoParcelamentoSelecionado.getCodigoFormaParcelamento()));
				}
				
				//faz o calculo das parcelas efetivas
				resultado.getListaValidacao().addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(sequencialCotacaoPropota));
	
				if(resultado.getListaValidacao().isEmpty()) {
					resultado.setSuccess(true);
				}
			}
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar exclui recebimento.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}
}
