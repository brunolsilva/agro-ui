package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class FranquiaRepository extends BaseDAO {

	private static Logger logger = LogManager.getLogger(FranquiaRepository.class);

	@LogPerformance
	public List<ItemCobertura> findDadosFranquiaByItem(BigInteger sqItemCotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select cob ");
		hql.append(" from	ItemCobertura cob ");
		hql.append(" where	cob.itemCotacao.sequencialItemCotacao = :sqItemCotacao ");
		hql.append(" and	idExclusaEndosso = :nao");
		hql.append(" order by cob.idTipoCobertura, cob.descricaoCobertura ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqItemCotacao",sqItemCotacao);
		query.setParameter("nao",SimNaoEnum.NAO);

		return (List<ItemCobertura>) query.list();
	}

	@LogPerformance
	public List<Object[]> findCoberturasByCotacao(BigInteger sqCotac) {
		StringBuilder hql = new StringBuilder();
		hql.append("select 	distinct ic.codigoCobertura, ic.descricaoCobertura, ic.numeroCotacaoProposta, ic.versaoCotacaoProposta, ic.idTipoCobertura "); //
		hql.append("from   ItemCotacao i ");
		hql.append("join   i.listItemCobertura ic ");
		hql.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		hql.append("order by ic.idTipoCobertura, ic.descricaoCobertura ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sqCotac);

		return (List<Object[]>) query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemCobertura> buscaCoberturasPorCotacao(BigInteger seqCotacao){
		String query = new StringBuilder()
		.append("select cobtu ")
		.append("from ItemCobertura cobtu ")
		.append("join cobtu.itemCotacao item ")
		.append("where item.cotacao.sequencialCotacaoProposta = :seqCotacao ")
		.append("order by cobtu.idTipoCobertura, cobtu.descricaoCobertura")
		.toString();		
		
		return getCurrentSession().createQuery(query).setParameter("seqCotacao", seqCotacao).list();
	}

	@LogPerformance
	public void deleteItensEquipamentoFranquiaByCotacao(Cotacao cotacao) throws HibernateException,RepositoryException {
		Query query = getCurrentSession().createQuery("delete ItemEquipamentoFranquia i where i.numeroCotacaoProposta = :numeroCotacaoProposta and i.versaoCotacaoProposta = :versaoCotacaoProposta");
		query.setParameter("numeroCotacaoProposta",cotacao.getNumeroCotacaoProposta());
		query.setParameter("versaoCotacaoProposta",cotacao.getVersaoCotacaoProposta());
		query.executeUpdate();
	}

	@LogPerformance
	public void deleteItensEquipamentoFranquiaByCobertura(BigInteger sqItemCobertura) throws HibernateException,RepositoryException {
		Query query = getCurrentSession().createQuery("delete ItemEquipamentoFranquia i where i.itemCobertura.sequencialItemCobertura = :sequencialItemCobertura");
		query.setParameter("sequencialItemCobertura",sqItemCobertura);
		query.executeUpdate();
	}

	@LogPerformance
	public void saveDadosFranquia(List<ItemCobertura> coberturas) throws RepositoryException {
		try {
			if (coberturas != null && !coberturas.isEmpty()) {
				Cotacao cotacao = coberturas.get(0).getItemCotacao().getCotacao();
				cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
				getCurrentSession().save(cotacao);
			}

			if (coberturas != null) {
				for (ItemCobertura itemCobertura : coberturas) {
					getCurrentSession().save(itemCobertura);
				}
			}
		} catch (Exception e) {
			logger.error("Erro ao salvar os dados da franquia ",e);
			throw new RepositoryException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public boolean limpaFranquiaInformada(ItemCobertura itemCobertura) throws RepositoryException {
		try {
			Cotacao cotacao = itemCobertura.getItemCotacao().getCotacao();
			cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
			getCurrentSession().save(cotacao);
			getCurrentSession().save(itemCobertura);
		} catch (Exception e) {
			throw new RepositoryException(e.getMessage(),e);
		}
		return true;
	}

	@LogPerformance
	public List<ItemEquipamentoFranquia> listItensEquipamentoFranquia(BigInteger sequencialItemCobertura) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		hql.append(" select item ");
		hql.append(" from ItemEquipamentoFranquia item ");
		hql.append(" where item.itemCobertura.sequencialItemCobertura = :sequencialItemCobertura ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialItemCobertura",sequencialItemCobertura);

		return (List<ItemEquipamentoFranquia>) query.list();
	}

	@LogPerformance
	public void deleteEquipamentoFranquia(ItemEquipamentoFranquia itemEquipamentoFranquia) {
		super.getCurrentSession().delete(itemEquipamentoFranquia);

	}

	@LogPerformance
	public void deleteItemEquipamentoFranquiaByCobertura(BigInteger codigoEquipamento,BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta,BigInteger sequencialItemCobertura) throws RepositoryException {

		try {

			StringBuilder hql = new StringBuilder();
			hql.append("	delete	ItemEquipamentoFranquia i ");
			hql.append("	where	i.itemCobertura.sequencialItemCobertura = :sequencialItemCobertura	");
			hql.append("	and		i.codigoEquipamento						= :codigoEquipamento ");
			hql.append("	and		i.numeroCotacaoProposta					= :numeroCotacaoProposta ");
			hql.append("	and		i.versaoCotacaoProposta					= :versaoCotacaoProposta ");
			Query query = getCurrentSession().createQuery(hql.toString());
			query.setParameter("sequencialItemCobertura",sequencialItemCobertura);
			query.setParameter("codigoEquipamento",codigoEquipamento);
			query.setParameter("numeroCotacaoProposta",numeroCotacaoProposta);
			query.setParameter("versaoCotacaoProposta",versaoCotacaoProposta);
			query.executeUpdate();
		} catch (Exception e) {
			throw new RepositoryException(e.getMessage(),e);
		}
	}
}
