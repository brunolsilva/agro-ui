package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.NotaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoNotaApoliceService {
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	public void validarNotaApolice(Produto produto, Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		boolean endossoPossuiNotaCotacao = endosso.getListNotaCotacao() != null && !endosso.getListNotaCotacao().isEmpty();
		boolean apolicePossuiNotaApolice = apolice.getListNotaApolice() != null && !apolice.getListNotaApolice().isEmpty();
		
		//1 - percorre as notas cotação do endosso e compara com as da apólice
		//no caso de a apólice possui mesma nota que o endosso, porém a descrição for diferente, loga que houve alteração
		//no caso de a apólice não possuir uma nota que o endosso possua, loga que houve inclusão
		if(endossoPossuiNotaCotacao){			
			for(NotaCotacao notaCotacao : endosso.getListNotaCotacao()){
				boolean notaExiste = false;
				if(apolicePossuiNotaApolice){
					for(NotaApolice notaApolice : apolice.getListNotaApolice()){
						if(AssertUtils.compareNull(notaApolice.getSequenciaNotaCotrole(),notaCotacao.getSequencialNotaControle().longValue())){
							validacaoParametrosEndossoService.compararParametrosEndossoSemDePara(notaApolice.getDescricaoNota(), notaCotacao.getNota(), TipoMensagemEndossoEnum.ALT_NOTA, produto, endosso, alteracoesEndossoList, user);
							notaExiste = true;
							break;
						}						
					}
				}
				
				//se a nota não existe
				if(!notaExiste){
					logarInclusaoNotaApolice(notaCotacao.getSequencialNotaControle(), produto, endosso, alteracoesEndossoList, user); 
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as notas da apólice e compara com as do endosso
		// no caso de o endosso não possuir alguma nota que está na apólice, loga que a mesma foi excluída 
		if(apolicePossuiNotaApolice){
			for(NotaApolice notaApolice : apolice.getListNotaApolice()){
				boolean condicaoExiste = false;
				if(endossoPossuiNotaCotacao){
					for(NotaCotacao notaCotacao : endosso.getListNotaCotacao()){
						if(AssertUtils.compareNull(notaApolice.getSequenciaNotaCotrole(),notaCotacao.getSequencialNotaControle().longValue())){
							condicaoExiste = true;
							break;
						}
					}
				}
				
				if(!condicaoExiste){
					logarExclusaoNotaApolice(notaApolice.getSequenciaNotaCotrole(), produto, endosso, alteracoesEndossoList, user);
				}
			}
		}
		//2 - fim
	}
	
	private void logarInclusaoNotaApolice(Integer sequencialNota, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(sequencialNota);
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, TipoMensagemEndossoEnum.INC_NOTA, descricaoAlteracao.toString(), user));
	}
	
	private void logarExclusaoNotaApolice(Long sequencialNota, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		StringBuilder descricaoAlteracao = new StringBuilder();
		descricaoAlteracao.append(sequencialNota);
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, TipoMensagemEndossoEnum.EXC_NOTA, descricaoAlteracao.toString(), user));
	}
}
