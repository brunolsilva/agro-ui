package br.com.tokiomarine.ctpj.cotacao.dto;

public class AproveitamentoCreditoAcselView extends AproveitamentoCreditoView {
	
	public AproveitamentoCreditoAcselView() {}

	public AproveitamentoCreditoAcselView(String ramo, String apolice, String endosso, String valorCredito) {
		super();
		this.ramo = ramo;
		this.apolice = apolice;
		this.endosso = endosso;
		this.valorCredito = valorCredito;
	}
	
	private String ramo;
	private String apolice;
	private String endosso;
	public String getRamo() {
		return ramo;
	}
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}
	public String getApolice() {
		return apolice;
	}
	public void setApolice(String apolice) {
		this.apolice = apolice;
	}
	public String getEndosso() {
		return endosso;
	}
	public void setEndosso(String endosso) {
		this.endosso = endosso;
	}
}
