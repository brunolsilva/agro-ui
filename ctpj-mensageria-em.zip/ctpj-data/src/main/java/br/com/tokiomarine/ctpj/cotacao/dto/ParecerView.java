package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ParecerView implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7512983387225474254L;
	private BigInteger sequencialCotacaoProposta;
	private BigInteger numeroCotacaoProposta;
	private Integer versaoCotacaoProposta;
	private BigInteger sequencialParecerCotacao;
	private String descricaoParecer;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss", timezone="America/Sao_Paulo")
	private Date dataParecer;
	private BigInteger numeroParecer;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss", timezone="America/Sao_Paulo")
	private Date dataAtualizacao;
	private Integer codigoGrupo;
	private Long usuarioAtualizacao;

	
	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	
	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	
	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	
	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	
	public Integer getVersaoCotacaoProposta() {
		return versaoCotacaoProposta;
	}

	
	public void setVersaoCotacaoProposta(Integer versaoCotacaoProposta) {
		this.versaoCotacaoProposta = versaoCotacaoProposta;
	}

	public BigInteger getSequencialParecerCotacao() {
		return sequencialParecerCotacao;
	}
	
	public void setSequencialParecerCotacao(BigInteger sequencialParecerCotacao) {
		this.sequencialParecerCotacao = sequencialParecerCotacao;
	}
	
	public String getDescricaoParecer() {
		return descricaoParecer;
	}
	
	public void setDescricaoParecer(String descricaoParecer) {
		this.descricaoParecer = descricaoParecer;
	}
	
	public Date getDataParecer() {
		return dataParecer;
	}
	
	public void setDataParecer(Date dataParecer) {
		this.dataParecer = dataParecer;
	}
	
	public BigInteger getNumeroParecer() {
		return numeroParecer;
	}
	
	public void setNumeroParecer(BigInteger numeroParecer) {
		this.numeroParecer = numeroParecer;
	}


	
	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}


	
	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}


	
	public Integer getCodigoGrupo() {
		return codigoGrupo;
	}


	
	public void setCodigoGrupo(Integer codigoGrupo) {
		this.codigoGrupo = codigoGrupo;
	}


	
	public Long getUsuarioAtualizacao() {
		return usuarioAtualizacao;
	}


	
	public void setUsuarioAtualizacao(Long usuarioAtualizacao) {
		this.usuarioAtualizacao = usuarioAtualizacao;
	}
	
	
	
	
	

}
