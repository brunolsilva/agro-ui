package br.com.tokiomarine.ctpj.infra.mongo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoValoresResseguro;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoValoresResseguroRepository;

@Service
public class ProdutoValoresResseguroService {

	@Autowired
	private ProdutoValoresResseguroRepository produtoValoresResseguroRepository;

	public ProdutoValoresResseguro findByProduto(Cotacao cotacao) {
		return produtoValoresResseguroRepository.findByProduto(cotacao);
	}
}