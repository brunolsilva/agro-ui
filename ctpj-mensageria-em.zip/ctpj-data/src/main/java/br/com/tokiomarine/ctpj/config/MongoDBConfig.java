package br.com.tokiomarine.ctpj.config;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.CustomConversions;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

import br.com.tokiomarine.ctpj.infra.converter.Converters;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.util.EnvironmentUtil;

@Configuration
@EnableTransactionManagement
@EnableMongoRepositories(basePackages = "br.com.tokiomarine")
public class MongoDBConfig {
	
	private static Logger logger = LogManager.getLogger(MongoDBConfig.class);
	
	@Bean
	public MongoDbFactory mongoDbFactory() throws UnknownHostException {
		
		String environmentWildFly = System.getenv(CTP.MONGO_URL.value());
		String strPassword = System.getenv(CTP.CTPJ_PASSWORD.value());		
		String userName = CTP.MONGO_CTPJ_USER.value();
		String database = CTP.MONGO_CTPJ_DB.value();
		
		logger.info("environmentWildFly: "+environmentWildFly);
		logger.info("userName..........: "+userName);
		logger.info("database..........: "+database);
		
		List<ServerAddress> serverAddress = EnvironmentUtil.getInstance().getListServerAddressMongo(environmentWildFly);
		
		List<MongoCredential> credentialsList = new ArrayList<MongoCredential>();
		MongoCredential credential = MongoCredential.createCredential(userName, database, strPassword.toCharArray());
		MongoClientOptions options = MongoClientOptions.builder()
				.connectionsPerHost(30)
				.threadsAllowedToBlockForConnectionMultiplier(4)
				.maxConnectionIdleTime(1000 * 60 * 30)
				.maxWaitTime(15000)
				.connectTimeout(1000 * 15)
				.socketKeepAlive(true)
				.socketTimeout(15000)
				.build();
		credentialsList.add(credential);
		MongoClient mongoClient = new MongoClient(serverAddress,credentialsList,options);
		
		return new SimpleMongoDbFactory(mongoClient,database);
	}
	
	@Bean
	@Qualifier("ctpjBackOffice")
	public MongoDbFactory ctpjBackOfficeMongoDbFactory() throws UnknownHostException{
		String servers = System.getenv(CTP.MONGO_URL.value());
		String password = System.getenv(CTP.CTPJ_BACKOFFICE_PASSWORD.value());		
		String user = CTP.MONGO_CTPJ_BACKOFFICE_USER.value();
		String database = CTP.MONGO_CTPJ_BACKOFFICE_DB.value();
		
		List<ServerAddress> serverAddress = EnvironmentUtil.getInstance().getListServerAddressMongo(servers);

		List<MongoCredential> credentialsList = new ArrayList<MongoCredential>();
		MongoCredential credential = MongoCredential.createCredential(user, database, password.toCharArray());
		
		MongoClientOptions options = MongoClientOptions.builder()
				.connectionsPerHost(30)
				.threadsAllowedToBlockForConnectionMultiplier(4)
				.maxConnectionIdleTime(1000 * 60 * 30)
				.maxWaitTime(15000)
				.connectTimeout(1000 * 15)
				.socketKeepAlive(true)
				.socketTimeout(15000)
				.build();
		credentialsList.add(credential);
		MongoClient mongoClient = new MongoClient(serverAddress,credentialsList,options);
		
		return new SimpleMongoDbFactory(mongoClient,database);
	}

	@Bean
	@Primary
	public MongoTemplate mongoTemplate() throws UnknownHostException {
		MongoTemplate template = new MongoTemplate(mongoDbFactory());
		MappingMongoConverter mmc = (MappingMongoConverter) template.getConverter();
		mmc.setCustomConversions(customConversions());
		mmc.afterPropertiesSet();
		return template;
	}
	
	@Bean
	@Qualifier("ctpjBackOffice")
	public MongoTemplate ctpjBackOfficeMongoTemplate() throws UnknownHostException{
		MongoTemplate template = new MongoTemplate(ctpjBackOfficeMongoDbFactory());
		MappingMongoConverter mmc = (MappingMongoConverter) template.getConverter();
		mmc.setCustomConversions(customConversions());
		mmc.afterPropertiesSet();
		
		return template;
	}

	@Bean
	public CustomConversions customConversions() {
		List<Converter<?, ?>> converterList = new ArrayList<Converter<?, ?>>();
		converterList.addAll(Arrays.asList(
				new Converters.TipoISReadConverter(),
				new Converters.TipoISWriteConverter(),
				new Converters.BeneficiarioReadConverter(),
				new Converters.BeneficiarioWriteConverter(),
				new Converters.MoedaReadConverter(),
				new Converters.MoedaWriteConverter(),
				new Converters.PrazoVigenciaReadConverter(),
				new Converters.PrazoVigenciaWriteConverter(),
				new Converters.TipoSeguradoReadConverter(),
				new Converters.TipoSeguradoWriteConverter(),
				new Converters.SimNaoReadConverter(),
				new Converters.SimNaoWriteConverter(),
				new Converters.AplicacaoPeriodoIndenitarioReadConverter(),
				new Converters.AplicacaoPeriodoIndenitarioWriteConverter(),
				new Converters.TipoSeguroReadConverter(),
				new Converters.TipoSeguroWriteConverter(),
				new Converters.FinalidadeVencimentoReadConverter(),
				new Converters.FinalidadeVencimentoWriteConverter(),
				new Converters.NivelCaracteristicaReadConverter(),
				new Converters.NivelCaracteristicaWriteConverter(),
				new Converters.TipoClausulaReadConverter(),
				new Converters.TipoClausulaWriteConverter(),
				new Converters.ReferenciaDataVencimentoReadConverter(),
				new Converters.ReferenciaDataVencimentoWriteConverter(),
				new Converters.GrupoUsuarioReadConverter(),
				new Converters.GrupoUsuarioWriteConverter(),
				new Converters.FinalidadeBancoReadConverter(),
				new Converters.FinalidadeBancoWriteConverter(),
				new Converters.ClasseBonusReadConverter(),
				new Converters.ClasseBonusWriteConverter(),
				new Converters.TipoEndossoReadConverter(),
				new Converters.TipoEndossoWriteConverter(),
				new Converters.SexoReadConverter(),
				new Converters.SexoWriteConverter(),
				new Converters.EstadoCivilReadConverter(),
				new Converters.EstadoCivilWriteConverter(),
				new Converters.SolicitanteEndossoReadConverter(),
				new Converters.SolicitanteEndossoWriteConverter(),
				new Converters.TipoApoliceEnumReadConverter(),
				new Converters.TipoApoliceEnumWriteConverter(),
				new Converters.TipoCoberturaReadConverter(),
				new Converters.TipoCoberturaWriteConverter(),
				new Converters.FormaDevolucaoCancelamentoApoliceEnumReadConverter(),
				new Converters.FormaDevolucaoCancelamentoApoliceWriteConverter(),
				new Converters.TipoValorRiscoDistribuidoEnumReadConverter(),
				new Converters.TipoValorRiscoDistribuidoEnumWriteConverter(),
				new Converters.ClassificacaoAtividadeEnumReadConverter(),
				new Converters.ClassificacaoAtividadeEnumWriteConverter(),
				new Converters.TipoCoberturaReadConverter(),
				new Converters.TipoCoberturaWriteConverter()
				));

		return new CustomConversions(converterList);
	}
}