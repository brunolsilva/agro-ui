package br.com.tokiomarine.ctpj.cotacao.relatorios.memoriacalculo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import br.com.tokiomarine.ctpj.cotacao.dto.LinhaTabelaMemoriaCalculoView;
import br.com.tokiomarine.ctpj.cotacao.relatorios.RelatorioException;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaCalculo;
import br.com.tokiomarine.ctpj.mapper.TabelaMemoriaCalculoViewMapper;

public abstract class GeradorRelatorioMemoriaCalculoPlanilha implements GeradorRelatorioMemoriaCalculo {	

	/**
	 * Retorna algum objeto que implementa a interface {@link Workbook}, a qual representa uma planilha (.odt, xls, xlsx) na API do Apache POI. Este objeto será usado para cria uma planilha em algum formato válido
	 * 
	 * @return
	 */
	protected abstract Workbook getWorkbook();
	
	@Override
	public byte[] gera(MemoriaCalculo memoriaCalculo) throws RelatorioException{
		OutputStream os = geraOutputStream(memoriaCalculo);
		return ((ByteArrayOutputStream)os).toByteArray();
	}	

	@Override
	public OutputStream geraOutputStream(MemoriaCalculo memoriaCalculo) throws RelatorioException{
		Workbook workbook = getWorkbook();
		Sheet sheet = workbook.createSheet("Memória Cálculo");		
		
		criaLinhaTitulo(workbook, sheet);
		criaLinhaDadosCotacao(workbook, sheet, memoriaCalculo);
		criaLinhasVazias(sheet, 1);
		criaTabelaMemorias(workbook, sheet, TabelaMemoriaCalculoViewMapper.getInstance().fromMemoriaCalculoToListOfLinhaTabelaCalculoview(memoriaCalculo));		
		criaLinhasVazias(sheet, 3);
		criaLegenda(workbook, sheet);
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			workbook.write(baos);
			return baos;
		} catch (IOException e) {
			throw new RelatorioException(e);
		}
	}

	private void criaLinhasVazias(Sheet sheet, int quantidade) {
		for (int i = 0; i < quantidade; i++) 
			sheet.createRow(getNextRowNum(sheet));
	}

	private void criaLinhaTitulo(Workbook workbook, Sheet sheet) {
		Row row = sheet.createRow(0);
		Cell cell = row.createCell(0);
		cell.setCellValue("Memória Cálculo");
		
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 21));
		
		Font font = workbook.createFont();
		font.setFontHeightInPoints((short) 20);
		font.setBold(true);
		CellStyle style =  workbook.createCellStyle();
		style.setFont(font);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		cell.setCellStyle(style);
	}

	private void criaLinhaDadosCotacao(Workbook workbook, Sheet sheet, MemoriaCalculo memoriaCalculo) {
		Row rowNroCotacao = sheet.createRow(getNextRowNum(sheet));
		criaCelula(rowNroCotacao, 0, "Nro Cotacao:").setCellStyle(negrito(workbook));
		criaCelula(rowNroCotacao, 1, memoriaCalculo.getNumeroCotacaoProposta());
		
		Row rowVersaoCotacao = sheet.createRow(getNextRowNum(sheet));
		criaCelula(rowVersaoCotacao, 0, "Versão Cotação:").setCellStyle(negrito(workbook));
		criaCelula(rowVersaoCotacao, 1, memoriaCalculo.getVersaoCotacaoProposta());
		
		Row rowVersaoDataCotacao = sheet.createRow(getNextRowNum(sheet));
		criaCelula(rowVersaoDataCotacao, 0, "Data Cotação:").setCellStyle(negrito(workbook));
		criaCelulaDataCalculo(workbook, rowVersaoDataCotacao, 1,  memoriaCalculo.getDataCotacao());
		
		Row rowPercentualComissao = sheet.createRow(getNextRowNum(sheet));
		criaCelula(rowPercentualComissao, 0, "Comissão:").setCellStyle(negrito(workbook));
		criaCelula(rowPercentualComissao, 1, memoriaCalculo.getPercentualComissao());	
	}
	
	private void criaTabelaMemorias(Workbook workbook, Sheet sheet, List<LinhaTabelaMemoriaCalculoView> linhasTabela) {
		criaCabecalhoTabela(workbook, sheet);
		criaCorpoTabela(workbook, sheet, linhasTabela);	
	}

	private void criaCabecalhoTabela(Workbook workbook, Sheet sheet) {
		Row row = sheet.createRow(getNextRowNum(sheet));		
		
		criaCelula(row, 0, "Data Cálculo");
		criaCelula(row, row.getLastCellNum(), "Item");
		criaCelula(row, row.getLastCellNum(), "Cobertura");
		criaCelula(row, row.getLastCellNum(), "Prêmio Líquido");
		criaCelula(row, row.getLastCellNum(), "Prêmio Net");
		criaCelula(row, row.getLastCellNum(), "Prêmio Vigência");
		criaCelula(row, row.getLastCellNum(), "Valor em Risco");
		criaCelula(row, row.getLastCellNum(), "Importância Segurada");
		criaCelula(row, row.getLastCellNum(), "Sublimite");		
		criaCelula(row, row.getLastCellNum(), "Taxa IS");
		criaCelula(row, row.getLastCellNum(), "coefBemCoberto");
		criaCelula(row, row.getLastCellNum(), "Agravo Experiência");
		criaCelula(row, row.getLastCellNum(), "Desc. Experiência");		
		criaCelula(row, row.getLastCellNum(), "Desc. Qtde Coberturas");
		criaCelula(row, row.getLastCellNum(), "Desc. Franquia");		
		criaCelula(row, row.getLastCellNum(), "Desc. Protecional Incendio");
		criaCelula(row, row.getLastCellNum(), "Desc. Protecional Roubo");		
		criaCelula(row, row.getLastCellNum(), "Coef. PI");		
		criaCelula(row, row.getLastCellNum(), "Coef. Vagas");
		criaCelula(row, row.getLastCellNum(), "Agravo Comissão");
		criaCelula(row, row.getLastCellNum(), "Coef. Prazo");
		criaCelula(row, row.getLastCellNum(), "Coef. DMP/VR");
		criaCelula(row, row.getLastCellNum(), "Desc. Geral");
		criaCelula(row, row.getLastCellNum(), "Agravo Geral");
		criaCelula(row, row.getLastCellNum(), "Desc. LMI");
		criaCelula(row, row.getLastCellNum(), "Desc. Local.");
		
		IntStream
		.range(0, row.getLastCellNum())
		.forEach(i -> row.getCell(i).setCellStyle(estiloCabecalho(workbook)));
	}

	private void criaCorpoTabela(Workbook workbook, Sheet sheet, List<LinhaTabelaMemoriaCalculoView> linhasTabela) {
		IntStream
		.range(0, linhasTabela.size())
		.forEach(i -> criaLinhaTabela(workbook, sheet, linhasTabela.get(i), getNextRowNum(sheet))); 
	}

	private void criaLinhaTabela(Workbook workbook, Sheet sheet, LinhaTabelaMemoriaCalculoView linha, int posicao) {
		Row row = sheet.createRow(posicao);
		
		criaCelulaDataCalculo(workbook, row, 0, linha.getDataCalculo());
		criaCelula(row, row.getLastCellNum(), linha.getItem()); 
		criaCelula(row, row.getLastCellNum(), linha.getCodCobertura() + " - " + linha.getDescricaoCobertura()); 
		criaCelula(row, row.getLastCellNum(), linha.getPremioLiquido()); 
		criaCelula(row, row.getLastCellNum(), linha.getPremioNet());
		criaCelula(row, row.getLastCellNum(), linha.getPremioVigencia()); 
		criaCelula(row, row.getLastCellNum(), linha.getValorRiscoBem()); 
		criaCelula(row, row.getLastCellNum(), linha.getImportanciaSegurada()); 		
		criaCelula(row, row.getLastCellNum(), linha.getSublimite()); 		
		criaCelula(row, row.getLastCellNum(), linha.getTaxaIS()); 
		criaCelula(row, row.getLastCellNum(), linha.getCoeficienteBemCoberto()); 
		criaCelula(row, row.getLastCellNum(), linha.getAgravoDeExperiencia());
		criaCelula(row, row.getLastCellNum(), linha.getDescontoDeExperiencia());		
		criaCelula(row, row.getLastCellNum(), linha.getDescontoPorQuantDeCoberturas()); 
		criaCelula(row, row.getLastCellNum(), linha.getDescontoDeFranquia()); 		
		criaCelula(row, row.getLastCellNum(), linha.getDescontoProtecionalIncendio());
		criaCelula(row, row.getLastCellNum(), linha.getDescontoProtecionalRoubo());		
		criaCelula(row, row.getLastCellNum(), linha.getCoeficientePeriodoIndenitario()); 		
		criaCelula(row, row.getLastCellNum(), linha.getCoeficienteVagas()); 
		criaCelula(row, row.getLastCellNum(), linha.getAgravoDeComissao());
		criaCelula(row, row.getLastCellNum(), linha.getCoeficienteDePrazo());
		criaCelula(row, row.getLastCellNum(), linha.getCoeficienteDeDMPVR());
		criaCelula(row, row.getLastCellNum(), linha.getDescontoGeralAplicado());	  
		criaCelula(row, row.getLastCellNum(), linha.getAgravoGeralAplicado());
		criaCelula(row, row.getLastCellNum(), linha.getDescontoLMI());
		criaCelula(row, row.getLastCellNum(), linha.getDescontoLocalizacao());
	}
	
	private void criaLegenda(Workbook workbook, Sheet sheet) {
		criaCabecalhoLegenda(workbook,sheet);
		criaCorpoTabelaLegenda(sheet);
	}
	
	private void criaCabecalhoLegenda(Workbook workbook, Sheet sheet) {
		Row row = sheet.createRow(getNextRowNum(sheet));
		criaCelula(row, 0, "Coluna").setCellStyle(estiloCabecalho(workbook));
		criaCelula(row, 1, "Descritivo do Blaze").setCellStyle(estiloCabecalho(workbook));		
	}
	
	private void criaCorpoTabelaLegenda(Sheet sheet) {
		criaLinhaTabelaLegenda(sheet, "coefBemCoberto", "COEFICIENTE DE BEM COBERTO");
		criaLinhaTabelaLegenda(sheet, "Agravo Experiência", "AGRAVO DE EXPERIÊNCIA");
		criaLinhaTabelaLegenda(sheet, "Desc. Experiência", "DESCONTO DE EXPERIÊNCIA");
		criaLinhaTabelaLegenda(sheet, "Desc. Qtde Coberturas", "DESCONTO POR QUANTIDADE DE COBERTURAS");
		criaLinhaTabelaLegenda(sheet, "Desc. Franquia", "DESCONTO DE FRANQUIA");
		criaLinhaTabelaLegenda(sheet, "Desc. Protecional Incendio", "DESCONTO PROTECIONAL DE INCÊNDIO");
		criaLinhaTabelaLegenda(sheet, "Desc. Protecional Roubo", "DESCONTO PROTECIONAL DE ROUBO");
		criaLinhaTabelaLegenda(sheet, "Coef. PI", "COEFICIENTE PERÍODO INDENITÁRIO");
		criaLinhaTabelaLegenda(sheet, "Coef. Vagas", "FATOR DE QTD DE VAGAS");
		criaLinhaTabelaLegenda(sheet, "Desc. Geral", "DESCONTO GERAL APLICADO");
		criaLinhaTabelaLegenda(sheet, "Agravo Geral", "AGRAVO GERAL APLICADO");
		criaLinhaTabelaLegenda(sheet, "Agravo Comissão", "AGRAVO DE COMISSAO");
		criaLinhaTabelaLegenda(sheet, "Coef. Prazo", "COEFICIENTE DE PRAZO");
		criaLinhaTabelaLegenda(sheet, "Coef. DMP/VR", "COEFICIENTE DE DMP/VR");
		criaLinhaTabelaLegenda(sheet, "Desc. LMI", "DESCONTO LMI");	
	}

	private void criaLinhaTabelaLegenda(Sheet sheet, String nomeColuna, String descritivoBlaze){
		Row row = sheet.createRow(getNextRowNum(sheet));
		criaCelula(row, 0, nomeColuna); 
		criaCelula(row, 1, descritivoBlaze);
	}

	/**
	 * Retorna o próximo número para uma nova linha (row) ainda não existente
	 * 
	 * @param sheet
	 * @return próximo número de linha
	 */
	private int getNextRowNum(Sheet sheet) {
		return sheet.getLastRowNum() + 1;
	}
	
	private Cell criaCelula(Row row, int posicao, Integer valor) {
		Cell cell = row.createCell(posicao);
		Optional.ofNullable(valor).ifPresent(v -> cell.setCellValue(v.intValue()));		
		return cell;
	}	
	
	private Cell criaCelula(Row row, int posicao, BigInteger valor) {
		Cell cell = row.createCell(posicao);
		Optional.ofNullable(valor).ifPresent(v -> cell.setCellValue(v.intValue()));
		return cell;
	}	
	
	private Cell criaCelula(Row row, int posicao, String valor) {
		Cell cell = row.createCell(posicao);
		Optional.ofNullable(valor).ifPresent(v -> cell.setCellValue(v));
		return cell;
	}
	
	@SuppressWarnings("unused")
	private Cell criaCelula(Row row, int posicao, Date valor) {
		Cell cell = row.createCell(posicao);
		Optional.ofNullable(valor).ifPresent(v -> cell.setCellValue(v));
		return cell;
	}
	
	private Cell criaCelulaDataCalculo(Workbook workbook, Row row, int posicao, Date valor) {
		Cell cell = row.createCell(posicao);
		Optional.ofNullable(valor).ifPresent(v -> cell.setCellValue(v));
		
		CellStyle style = workbook.createCellStyle();
		short dateFormat = workbook.createDataFormat().getFormat("dd/MM/yyyy");
		style.setDataFormat(dateFormat);
		cell.setCellStyle(style);
		
		return cell;
	}
	
	private Cell criaCelula(Row row, int posicao, BigDecimal valor) {
		Cell cell = row.createCell(posicao);
		Optional.ofNullable(valor).ifPresent(v -> cell.setCellValue(v.doubleValue()));
		return cell;
	}
	
	@SuppressWarnings("unused")
	private Cell criaCelula(Row row, int posicao){
		return row.createCell(posicao);
	}

	private CellStyle estiloCabecalho(Workbook workbook){
		Font font = workbook.createFont();
		font.setBold(true);
		
		CellStyle style =  workbook.createCellStyle();
		style.setFont(font);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.index);
		style.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.index);		
		
		return style;
	}
	
	private CellStyle negrito(Workbook workbook){
		Font font = workbook.createFont();
		font.setBold(true);		
		CellStyle style =  workbook.createCellStyle();
		style.setFont(font);
		return style;
	}
}
