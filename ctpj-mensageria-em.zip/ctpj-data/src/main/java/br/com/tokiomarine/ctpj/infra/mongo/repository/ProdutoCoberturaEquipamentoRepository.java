package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaFranquiaView;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCoberturaEquipamento;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;

@Repository
public class ProdutoCoberturaEquipamentoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static Logger logger = LogManager.getLogger(ProdutoCoberturaEquipamentoRepository.class);

	@LogPerformance
	public List<ProdutoCoberturaEquipamento> findEquipamentoByProdutoCobertura(ItemCotacao itemCotacao, ItemCoberturaFranquiaView itemCobertura) throws RepositoryException {
		try {
			
			return mongoTemplate.find(query(where("produto").is(itemCotacao.getCotacao().getCodigoProduto())
						.and("cobertura").is(itemCobertura.getCodigoCobertura())
						.and("caracteristica").is(Caracteristicas.ATIVIDADE.codigo())
						.and("valorCaracteristica").is(itemCotacao.getCodigoRubrica())
					), ProdutoCoberturaEquipamento.class);
		}catch (Exception e) {
			logger.error("Erro na Busca do ProdutoCoberturaEquipamento ", e);
			throw new RepositoryException("Erro na Busca do ProdutoCoberturaEquipamento", e);
		}
	}
	
	public List<Integer> findEquipamentoByProdutoCoberturaDistinct(Integer codigoProduto, ItemCoberturaFranquiaView itemCobertura) throws RepositoryException {
		List<Integer> equipamentos = new ArrayList<>();
		try {
			equipamentos = mongoTemplate.getCollection("produtoCoberturaEquipamento").distinct("equipamento",query(where("produto").is(codigoProduto)
					.and("cobertura").is(itemCobertura.getCodigoCobertura())
					.and("caracteristica").is(Caracteristicas.ATIVIDADE.codigo())
				).getQueryObject());
			return equipamentos;
		}catch (Exception e) {
			logger.error("Erro na Busca do ProdutoCoberturaEquipamento distinct ", e);
			throw new RepositoryException("Erro na Busca do ProdutoCoberturaEquipamento distinct", e);
		}
	}
}
