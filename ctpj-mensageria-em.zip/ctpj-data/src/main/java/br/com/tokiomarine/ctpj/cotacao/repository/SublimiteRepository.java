package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemSublimiteView;
import br.com.tokiomarine.ctpj.cotacao.dto.SublimiteView;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.mapper.NumberMapper;

@Repository
public class SublimiteRepository extends BaseDAO {
	
	private static Logger logger = LogManager.getLogger(SublimiteRepository.class);
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	public List<SublimiteView> getSublimites(BigInteger sqCotacao) {
		logger.info("Inicio getSublimites " + sqCotacao);

		Cotacao cotacao = cotacaoRepository.findById(sqCotacao);
		MoedaEnum moeda = cotacao.getCodigoMoeda();
		StringBuilder hql = new StringBuilder();

		if (moeda == MoedaEnum.REAL) {
			hql.append(" select i.numeroItem as numeroItem, ");
			hql.append(" 		c.codigoCobertura as codigoCobertura, ");
			hql.append(" 		c.coberturaPrincipal as coberturaPrincipal, ");
			hql.append(" 		c.valorSublimite as valorSublimite, ");
			hql.append(" 		c.sequencialItemCobertura as sequencialItemCobertura, ");
			hql.append(" 		i.sequencialItemCotacao as sequencialItemCotacao, ");
			hql.append(" 		i.cotacao.sequencialCotacaoProposta as sequencialCotacaoProposta, ");
			hql.append(" 		c.descricaoCobertura as descricaoCobertura, ");
			hql.append(" 		coalesce(c.valorRiscoBem, i.valorRiscoBemCalculado) as valorRiscoBem, ");
			hql.append(" 		c.valorImportanciaSegurada as valorImportanciaSegurada, ");
			hql.append(" 		c.valorSublimiteOriginal as valorSublimiteOriginal, ");
			hql.append(" 		c.idTipoCobertura as idTipoCobertura, ");
			hql.append(" 		c.idExclusaEndosso  as idExclusaEndosso,");
			hql.append(" 		c.idSublimiteInformado as idSublimiteInformado ");
			hql.append(" from 			ItemCotacao 	i");
			hql.append(" inner join 	i.listItemCobertura c");
			hql.append(" where 	i.cotacao.sequencialCotacaoProposta = :sqCotacao");
			hql.append(" order 	by	c.idTipoCobertura, c.descricaoCobertura ");
		} else if (moeda == MoedaEnum.DOLAR_VENDA) {
			hql.append(" select i.numeroItem as numeroItem, ");
			hql.append(" 		c.codigoCobertura as codigoCobertura, ");
			hql.append(" 		c.coberturaPrincipal as coberturaPrincipal, ");
			hql.append(" 		c.valorSublimiteMoedaEstrangeira as valorSublimite, ");
			hql.append(" 		c.sequencialItemCobertura as sequencialItemCobertura, ");
			hql.append(" 		i.sequencialItemCotacao as sequencialItemCotacao, ");
			hql.append(" 		i.cotacao.sequencialCotacaoProposta as sequencialCotacaoProposta, ");
			hql.append(" 		c.descricaoCobertura as descricaoCobertura, ");
			hql.append(" 		coalesce(c.valorRiscoBemMoedaEstrangeira, i.valorCalculadoMoedaEstrangeira) as valorRiscoBem, ");
			hql.append(" 		c.valorISMoedaEstrangeira as valorImportanciaSegurada, ");
			hql.append(" 		c.valorSublimiteOriginalMoedaEstrangeira as valorSublimiteOriginal, ");
			hql.append(" 		c.idTipoCobertura as idTipoCobertura, ");
			hql.append(" 		c.idExclusaEndosso  as idExclusaEndosso,");
			hql.append(" 		c.idSublimiteInformado as idSublimiteInformado ");
			hql.append(" from 			ItemCotacao 	i");
			hql.append(" inner join 	i.listItemCobertura c");
			hql.append(" where 	i.cotacao.sequencialCotacaoProposta = :sqCotacao");
			hql.append(" order 	by	c.idTipoCobertura, c.descricaoCobertura ");
		}

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqCotacao", sqCotacao);
		query.setResultTransformer(Transformers.aliasToBean(SublimiteView.class));

		List<SublimiteView> listaSublimite = (List<SublimiteView>) query.list();

		logger.info("Fim getSublimites " + sqCotacao);

		return listaSublimite;
	}

	public void saveSublimite(List<ItemSublimiteView> sublimites, BigInteger sqCotacao) throws RepositoryException {

		logger.info("Inicio saveSublimite " + sqCotacao);

		Object[] cotacaoVersao = cotacaoRepository.getCotacaoVersaoMoeda(sqCotacao);

		BigInteger numeroCotacaoProposta = (BigInteger) cotacaoVersao[0];
		Integer versao = (Integer) cotacaoVersao[1];
		MoedaEnum moeda = (MoedaEnum) cotacaoVersao[2];
		StringBuilder hql = new StringBuilder();

		hql.append(" select cob ");
		hql.append("	from ItemCobertura cob ");
		hql.append(" where cob.numeroCotacaoProposta = :numeroCotacaoProposta ");
		hql.append(" and   cob.versaoCotacaoProposta = :versao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		query.setParameter("versao", versao);

		List<ItemCobertura> coberturas = (List<ItemCobertura>) query.list();
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		for (ItemCobertura itemCobertura : coberturas) {
			for(ItemSublimiteView sublimite: sublimites) {
				if(sublimite.getSequencialItemCobertura().equals(itemCobertura.getSequencialItemCobertura())) {
					BigDecimal valorSublimite = new NumberMapper().asDecimal(sublimite.getValorSublimite());
					marcaSublimiteInformado(itemCobertura, valorSublimite, moeda);
					if (moeda == MoedaEnum.REAL) {		
						itemCobertura.setValorSublimite(valorSublimite);
					} else if (moeda == MoedaEnum.DOLAR_VENDA) {
						itemCobertura.setValorSublimiteMoedaEstrangeira(valorSublimite);
					}

					itemCobertura.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
					itemCobertura.setDataAtualizacao(new Date());
					itemCobertura.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));

					Cotacao cotacao = itemCobertura.getItemCotacao().getCotacao();
					cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);

					getCurrentSession().save(cotacao);
					getCurrentSession().save(itemCobertura);
				}
			}
		}

		logger.info("Fim saveSublimite " + sqCotacao);
	}

	private void marcaSublimiteInformado(ItemCobertura itemCobertura, BigDecimal valorSublimite, MoedaEnum moeda) {
		if((valorSublimite == null && (moeda == MoedaEnum.REAL && itemCobertura.getValorSublimite() != null)) 
				|| (valorSublimite == null && (moeda == MoedaEnum.DOLAR_VENDA && itemCobertura.getValorSublimiteMoedaEstrangeira() != null))) {
			itemCobertura.setIdSublimiteInformado(SimNaoEnum.SIM);
		}

		if(valorSublimite != null) {
			if ( (moeda == MoedaEnum.REAL && itemCobertura.getValorSublimite() != null && valorSublimite.compareTo(itemCobertura.getValorSublimite()) != 0) 
					  || (moeda == MoedaEnum.DOLAR_VENDA && itemCobertura.getValorSublimiteMoedaEstrangeira() != null && valorSublimite.compareTo(itemCobertura.getValorSublimiteMoedaEstrangeira()) != 0) ) {
				itemCobertura.setIdSublimiteInformado(SimNaoEnum.SIM);
			}
		}
	}
}