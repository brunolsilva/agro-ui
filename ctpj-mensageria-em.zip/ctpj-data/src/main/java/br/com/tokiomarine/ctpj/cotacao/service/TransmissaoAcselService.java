package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.componente.utils.CelularUtil;
import br.com.tokiomarine.componente.utils.EmailUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CartaoResponse;
import br.com.tokiomarine.ctpj.cotacao.dto.CartaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ClienteCartao;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.DocumentoDigitalView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.repository.ContaCorrenteRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.OpcaoParcelamentoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.RecebimentoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.TransmissaoRepository;
import br.com.tokiomarine.ctpj.cotacao.validation.LmrMinimoValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.VencimentoParcelaValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.VencimentoProgramadoValidator;
import br.com.tokiomarine.ctpj.domain.cotacao.ContaCorrenteGlobal;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DocumentoDigital;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.ParcelamentoJanelado;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.CorretorApoliceDigital;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.endosso.service.EndossoAlteracaoCadastralTdoService;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaEnvioDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.ModuloProdutoEnum;
import br.com.tokiomarine.ctpj.enums.OrigemContratacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.OpcaoParcelamentoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.EstadoCivilEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.backoffice.request.ConsultaDataCancelamentoRequest;
import br.com.tokiomarine.ctpj.integracao.backoffice.response.ConsultaDataCancelamentoResponse;
import br.com.tokiomarine.ctpj.integracao.cliente.service.ClienteService;
import br.com.tokiomarine.ctpj.integracao.cliente.service.FormaDevolucaoClienteService;
import br.com.tokiomarine.ctpj.integracao.dto.ClienteDados;
import br.com.tokiomarine.ctpj.integracao.service.ConsultaDataCancelamentoService;
import br.com.tokiomarine.ctpj.integracao.service.MensageriaService;
import br.com.tokiomarine.ctpj.integracao.service.PagamentoAntecipadoService;
import br.com.tokiomarine.ctpj.integracao.service.ProvisaoService;
import br.com.tokiomarine.ctpj.interfaceCSF.response.ResponseInterfaceCSF;
import br.com.tokiomarine.ctpj.print.service.CotacaoPrintService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.ctpj.type.BancosEnum;
import br.com.tokiomarine.ctpj.type.FormaEnvioApoliceDigitalEnum;
import br.com.tokiomarine.ctpj.util.InspecaoUtil;
import br.com.tokiomarine.ctpj.util.RestTemplateUtil;

@EnableAsync
@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class TransmissaoAcselService {

	private static Logger logger = LogManager.getLogger(TransmissaoService.class);

	@Autowired
	private TransmissaoRepository transmissaoRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private LmrMinimoValidator lmrMinimoValidator;

	@Autowired
	private VencimentoParcelaValidator vencimentoParcelaValidator;

	@Autowired
	private VencimentoProgramadoValidator vencimentoProgramadoValidator;
	
	@Autowired
	private OpcaoParcelamentoRepository opcaoParcelamentoRepository;
	
	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;
	
	@Autowired
	private MensageriaService mensageriaService;
	
	@Autowired
	private PagamentoAntecipadoService pagamentoAntecipadoService;
	
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;
	
	@Autowired
	private CotacaoPrintService cotacaoPrintService;

	@Autowired
	private InspecaoService inspecaoService;
	
	@Autowired
	private RecebimentoRepository recebimentoRepository;

	@Autowired
	private MailUtilService mailUtilService;
	
	@Autowired
	private ClienteService clienteService;

	@Autowired
	private ProvisaoService provisaoService;
	
	@Autowired
	private DevolucaoService devolucaoService;
	
	@Autowired
	private CorretagemService corretagemService;
	
	@Autowired
	private FormaDevolucaoClienteService formaDevolucaoClienteService;
	
	@Autowired
	private ContaCorrenteRepository contaCorrenteRepository;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private ParcelamentoJaneladoService parcelamentoJaneladoService;

	@Autowired
	private ConsultaDataCancelamentoService consultaDataCancelamentoService;

	private RestTemplate restTemplate = RestTemplateUtil.restTemplate(10000);
	
	@Autowired
	private EndossoAlteracaoCadastralTdoService endossoAlteracaoCadastralTdoService;

	public PropostaView carregaDadosProposta(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			PropostaView proposta = transmissaoRepository.carregaDadosProposta(sequencialCotacaoProposta);
			String url = null;
			try {
				if (proposta.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE
						&& !CodigoSituacaoEnum
								.getCodigoSituacaoEnumByCdSituc(proposta.getCotacao().getCodigoSituacaoReadOnly()).isReadOnly()) {
					corretagemService.getCorretorFranqueador(
							ModuloProdutoEnum.getByProdutoAndOrigem(proposta.getCotacao().getCodigoProduto(), getOrigemContratacao()).getCodigoModuloProduto(),
							cotacaoRepository.findById(sequencialCotacaoProposta), new Date());
				}
				url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroConsultaApoliceDigital());
				if(proposta.getCotacao().getCodigoTipoEndossoSCT() != null || (proposta.getDocumentoDigital() != null && StringUtils.isBlank(proposta.getDocumentoDigital().getEmailCorretor()))) {
					CorretorApoliceDigital[] retornoApoliceDigital = restTemplate.getForObject(
							String.format(url, proposta.getCotacao().getCodigoCorretorACSEL(), proposta.getCotacao().getCodigoProduto()),
							CorretorApoliceDigital[].class);

					if(retornoApoliceDigital != null && retornoApoliceDigital.length > 0) {
						FormaEnvioApoliceDigitalEnum formaEnvio = FormaEnvioApoliceDigitalEnum.getById(retornoApoliceDigital[0].getIdApoliceDigital());
						if(formaEnvio != null) {
							proposta.setDocumentoDigital(formaEnvio.adicionaEmails(retornoApoliceDigital));
						}
					}
				}
			} catch (Exception e) {
				logger.error("Erro na consulta da busca do Parametro ou na recuperação dos e-mails: " + e.getMessage());
			}

			return proposta;
		} catch (Exception e) {
			logger.error("Erro ao carregar os dados da Proposta", e);
			throw new ServiceException(e.getMessage() + " cotacao  " + sequencialCotacaoProposta, e);
		}
	}

	private Integer getOrigemContratacao() {
		Integer origemContratacao = OrigemContratacaoEnum.ORIGEM_CORRETOR.getId();
//		if(!SecurityUtils.isCorretor()) {
//			origemContratacao = OrigemContratacaoEnum.ORIGEM_SUBSCRITOR.getId();
//		}
		return origemContratacao;
	}

	public void salvar(PropostaView proposta,User user) throws OpcaoParcelamentoException, ServiceException {
		Cotacao cotacao = cotacaoRepository.findCompleta(proposta.getSequencialCotacaoProposta());
		CotacaoView cotacaoView = proposta.getCotacao();
		cotacaoView.setIdTipoPessoa(cotacao.getIdTipoPessoa());
		Recebimento recebimento = recebimentoRepository.findRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());

		if (cotacao.getValorPremioLiquido() != null) {
			if (cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0) {	
				OpcaoParcelamento opcaoParcelamento = opcaoParcelamentoRepository.findOpcaoParcelamentoSelecionada(cotacao.getSequencialCotacaoProposta());
				if(opcaoParcelamento != null){
					if(!FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
						cotacao.setDataVencimentoProgramada(proposta.getCotacao().getDataVencimentoProgramada() != null ? proposta.getCotacao().getDataVencimentoProgramada() : null);
					}
					if (recebimento == null) {
						opcaoParcelamento.setDataVencimentoParcela(proposta.getDataVencimentoParcela());
						populaDadosCC(proposta, cotacao);
					}
				}			
			}
		}
		populaDadosSegurado(cotacaoView, cotacao);
		populaEndereco(cotacaoView, cotacao);
		populaDadosDevolucao(cotacaoView, cotacao);
		populaDadosDocumentoDigital(proposta.getDocumentoDigital(), cotacao, user);
		//cadastra a forma de devolução
		formaDevolucaoClienteService.cadastrarFormaDevolucaoSemException(cotacao,proposta,user);
		
		if (!EmailUtil.valida(cotacao.getIdEmailSegurado())) {
			cotacao.setIdEmailSegurado(null);
		}
		
		transmissaoRepository.salvar(cotacao);
	}

	public List<Validacao> enviar(PropostaView proposta,User user) throws ServiceException {
		Boolean efetuaValidacao = null;
		Boolean isProvisionado = false;
		
		Cotacao cotacao = cotacaoRepository.findCotacaoItemInspecaoCompletaBySeqCotacao(proposta.getSequencialCotacaoProposta());
		
		opcaoParcelamentoService.excluirOpcaoParcelamentoDevolucao(cotacao);

		List<Validacao> listaValidacao = new ArrayList<>();
		String msgLmrMinimoValidator = lmrMinimoValidator.validar(cotacao);
		if(msgLmrMinimoValidator != null) {
			listaValidacao.add(new Validacao(msgLmrMinimoValidator));
			return listaValidacao;
		}
		endossoAlteracaoCadastralTdoService.validarDadosPagamento(proposta, cotacao);
		Recebimento recebimento = recebimentoRepository.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		if(recebimento != null && recebimento.getValorRecebimento() != null && recebimento.getValorRecebimento().compareTo(BigDecimal.ZERO) > 0){
			proposta.setPossuiRecebimento(true);
		}
		
		CotacaoView cotacaoView = proposta.getCotacao();
		cotacaoView.setIdTipoPessoa(cotacao.getIdTipoPessoa());
		Map<BigInteger, List<ItemInspecao>> duplicidadeInspecaoPorItem = new LinkedHashMap<>();
		Map<BigInteger, Date> ultimaInspecaoPorCotacao = new LinkedHashMap<>();

		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			duplicidadeInspecaoPorItem.put(itemCotacao.getNumeroItem(), inspecaoService.buscarDuplicidadeItemInspecao(itemCotacao));
			if(itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO || itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR) {
				ultimaInspecaoPorCotacao.put(itemCotacao.getNumeroItem(), inspecaoService.buscarDataRelatorioUltimaInspecao(itemCotacao));
			}
		}
		
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO) {
			efetuaValidacao = true;
		} else {
			// Para os casos de endosso, enviar valor default
			cotacaoView.setIdEstadoCivil(EstadoCivilEnum.SOLTEIRO);
			if (Arrays.asList(
					TipoEndossoEnum.CANCELAMENTO_APOLICE,
					TipoEndossoEnum.CANCELAMENTO_ENDOSSO,
					TipoEndossoEnum.CANCELAMENTO_INCLUSAO).contains(cotacao.getIdTipoEndosso())) {
				efetuaValidacao = cotacao.getIdSolicitanteEndosso() != null && cotacao.getIdSolicitanteEndosso().getCalcula();
			} else if(cotacao.getIdTipoEndosso() != null) {
				efetuaValidacao = cotacao.getIdTipoEndosso().getCalcula();
			}
		}
		
		listaValidacao = validar(proposta,efetuaValidacao,cotacao,user,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao);
		
		if(!listaValidacao.isEmpty()) {
			return listaValidacao;
		}
		
		populaDadosCC(proposta, cotacao);
		OpcaoParcelamento opcaoParcelamento = null;

		if (cotacao.getValorPremioLiquido() != null) {
			if (cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0) {	
				opcaoParcelamento = opcaoParcelamentoRepository.findOpcaoParcelamentoSelecionada(cotacao.getSequencialCotacaoProposta());				
				if(opcaoParcelamento == null){
					listaValidacao.add(new Validacao("Favor selecionar uma opção de parcelamento."));
					return listaValidacao;
				}
				
				if (recebimento != null && recebimento.getDataProcessoCobranca() != null){
					opcaoParcelamento.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
				}

				if(!FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
					cotacao.setDataVencimentoProgramada(proposta.getCotacao().getDataVencimentoProgramada());
				}
				// TODO - Melhorar condição, caso algum endosso  trabalhe com novas parcelas
				if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoEndosso() != null && opcaoParcelamento != null)) {
					proposta.setCodigoFormaParcelamento(opcaoParcelamento.getCodigoFormaParcelamento());
					if(opcaoParcelamento != null) {
						opcaoParcelamento.setDataVencimentoParcela(proposta.getDataVencimentoParcela());
					}

					if(FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
						opcaoParcelamento.setDataVencimentoParcela(DateUtils.addDays(cotacao.getDataInicioVigencia(), 7));
					}

					if(!FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
						cotacao.setDataVencimentoProgramada(proposta.getCotacao().getDataVencimentoProgramada());
					}
					cotacao.setDataTransmissaoProposta(new Date());
					cotacao.setDataProposta(cotacao.getDataProposta() == null ? new Date() : cotacao.getDataProposta());
		
					if (recebimento != null && recebimento.getDataProcessoCobranca() != null){
						opcaoParcelamento.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
						proposta.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
					}else{
						if (cotacao.getDataVencimentoProgramada() != null){
							if (opcaoParcelamento.getIdEntrada() == SimNaoEnum.NAO){
//								opcaoParcelamento.setDataVencimentoParcela(cotacao.getDataVencimentoProgramada());
							}
						}
					}

					if (recebimento == null) {
						if(opcaoParcelamento.getIdEntrada() == SimNaoEnum.SIM && cotacaoView.getNumeroBancoDebito() != null && cotacaoView.getNumeroBancoDebito().equals(BancosEnum.CAIXA_ECONOMICA.codigo().intValue())) {
							listaValidacao.add(new Validacao("Para CAIXA ECONOMICA FEDERAL só é permitido a primeira parcela em boleto."));
						}
					}

					if(!FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
						if (efetuaValidacao) {
							if(recebimento == null) {
								listaValidacao.addAll(vencimentoParcelaValidator.validaDataPrimeiraParcela(
										cotacao,
										proposta.getDataVencimentoParcela(),
										opcaoParcelamento.getCodigoFormaPagamento(),
										opcaoParcelamento.getCodigoFormaParcelamento()));
							}

							if (opcaoParcelamento.getDataVencimentoParcela() != null
									&& cotacao.getDataVencimentoProgramada() != null) {
								if (DateUtils.truncatedCompareTo(opcaoParcelamento.getDataVencimentoParcela(), cotacao.getDataVencimentoProgramada(), Calendar.MINUTE) >= 0) {
									listaValidacao.add(new Validacao("Vencimento programado inválido."));
								}
							}

							listaValidacao.addAll(vencimentoProgramadoValidator.validaDataVencimentoProgramado(
									cotacao,
									opcaoParcelamento.getCodigoFormaPagamento(),
									opcaoParcelamento.getCodigoFormaParcelamento()));
			
						}
					}
					
					if(cotacao.getDataVencimentoProgramada() != null || opcaoParcelamento.getDataVencimentoParcela() != null) {
						ConsultaDataCancelamentoRequest request = new ConsultaDataCancelamentoRequest();
						request.setDiaFechamento(cotacao.getDataFimVigencia());
						request.setCodPais("BR");
						request.setCodEstado("SP");
						request.setCodCidade(1);
						request.setTipoCalc(-1);
						request.setQtdDias(18);
						request.setTipoDias("U");
						request.setRetDiaUtil("S");
						
						Date dataCalculada = consultaDataCancelamentoService.consultarDataCancelamento(request);
						
						List<ParcelamentoJanelado> parcelas = parcelamentoJaneladoService.calcularQuantidadeMaximaParcelas(cotacao, opcaoParcelamento);
						
						for(ParcelamentoJanelado p: parcelas) {
							System.out.println(p.getDataVencimentoParcela());
						}
						if (parcelas.stream().filter(it -> DateUtils.truncatedCompareTo(it.getDataVencimentoParcela(),
								dataCalculada, Calendar.MINUTE) >= 0).count() > 0) {
							listaValidacao.add(new Validacao(
									"Não é possível continuar com a contratação com esta quantidade de parcelas e data de vencimento. Favor diminuir a data de vencimento ou a quantidade de parcelas."));
						}
					}
				}
			}
		}
		if(cotacao.getListItem().stream()
				.flatMap(it -> it.getListItemCobertura().stream())
				.filter(cob -> cob.getIdCoberturaAvulsa() == SimNaoEnum.SIM)
				.count() > 0) {
				listaValidacao.add(new Validacao("Não é possível contratar uma proposta com cobertura avulsa. É necessário regularizar essa cobertura para contratar."));
		}
		
		if(listaValidacao.isEmpty()) {
			
			if(proposta.isPossuiRecebimento()) {

				cotacao.setDataProposta(cotacao.getDataProposta() == null ? new Date() : cotacao.getDataProposta());
			}

			populaDadosSegurado(cotacaoView, cotacao);
			populaEndereco(cotacaoView, cotacao);
			populaDadosDevolucao(cotacaoView, cotacao);
			
			/*
			 * TODO reducao de IS confirmar esse trecho
			 * */
			populaDadosDocumentoDigital(proposta.getDocumentoDigital(), cotacao, user);
			
			ClienteDados clienteDados = new ClienteDados();
			clienteService.populaDadosCliente(proposta, cotacao, clienteDados);
			

			cotacao.setIdDestinoEmissao(DestinoEmissaoEnum.ACX);
			
			try {
				clienteService.salvarCliente(cotacao, clienteDados, opcaoParcelamento);	
			} catch(Exception e) {
				listaValidacao.add(new Validacao(e.getMessage()));
			} finally {
				/*
				 * IMPORTANTE: esta alteração deverá ser feita, pois quando há alteração de segurado, mas a forma de pagamento não foi alterada-
				 * a forma de pagamento do segurado anterior é salva para o novo segurado e, temporariamente, o id do banco utilizado pelo segurado anterior é
				 * setado no objeto cotação. Os campos são setados para null (abaixo) pois caso estejam preenchidos compromete a funcionalidade da tela - já
				 * que o novo segurado não alterou forma de pagamento.
				 * */  
				if(endossoAlteracaoCadastralTdoService.isAlteracaoDadosCadastraisTdo(cotacao) && (proposta.getCotacao().getAlterarFormaPagamento() == null || 
						   proposta.getCotacao().getAlterarFormaPagamento().equals(SimNaoEnum.NAO))) {
					cotacao.setNumeroBancoBoleto(null);
					cotacao.setNumeroBancoDebito(null);
					cotacao.setIdToken(null);
				}
			}
			
			
			
			//valida os dados para devolução
			listaValidacao.addAll(devolucaoService.validarDadosDevolucao(cotacao, proposta));//
			
			try {
				//cadastra a forma de devolução
				formaDevolucaoClienteService.cadastrarFormaDevolucao(cotacao,proposta,user);	
			} catch(Exception e) {
				listaValidacao.add(new Validacao(e.getMessage()));
			}

			
			if (!listaValidacao.isEmpty()){
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}
			
			//faz a provisão do conta corrente
			provisaoService.provisionar(user, cotacao,listaValidacao);
			
			if (!listaValidacao.isEmpty()){
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}
			
			isProvisionado = true;

			if (efetuaValidacao) {
				try {
					listaValidacao.addAll(pagamentoAntecipadoService.gerarPagamentoAntecipado(cotacao,user));
				} catch (Exception e) {
					logger.error("Erro ao gerar pagamento antecipado ", e);
					listaValidacao.add(new Validacao(SecurityUtils.isCorretor() ? "Erro geral ao gerar pagamento antecipado." : "Erro ao chamar o serviço de geração de PA. Entrar em contato com TI."));
				}
			}
			
			if (!listaValidacao.isEmpty()){
				estornarProvisao(user, isProvisionado, cotacao);
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}

			if(cotacao.getDocumentoDigital() == null || cotacao.getDocumentoDigital().getSequencialDocumentoDigital() == null) {
				cotacao.setDocumentoDigital(null);
			}
			listaValidacao.addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(cotacao));
			
			if (!listaValidacao.isEmpty()){
				estornarProvisao(user, isProvisionado, cotacao);
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}

			cotacao.setCodigoSituacao(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue());
			cotacao.setNomeSituacao(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getDescricao());
			
			cotacao.setDataTransmissaoProposta(new Date());
			cotacao.setDataProposta(cotacao.getDataProposta() == null ? new Date() : cotacao.getDataProposta());
			
			if(cotacao.getDocumentoDigital() == null || cotacao.getDocumentoDigital().getSequencialDocumentoDigital() == null) {
				cotacao.setDocumentoDigital(null);
			}

			if (cotacao.getIdOrigemContratacao() == null) {
				cotacao.setIdOrigemContratacao(cotacaoService.definirOrigemContratacao(cotacao,user));
			}
			
			if (!listaValidacao.isEmpty()){
				estornarProvisao(user, isProvisionado, cotacao);
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}
			devolucaoService.ajustesDevolucaoAntesDeTransmitir(cotacao);
			//cria parcelamento temporário para a devolução
			transmissaoRepository.salvarAcsel(cotacao);
			devolucaoService.ajustesDevolucaoAposTransmitir(cotacao);
		} else {
			estornarProvisao(user, isProvisionado, cotacao);
			transmissaoRepository.evict(cotacao);
		}
		
		return listaValidacao;
	}

	private void estornarProvisao(User user, Boolean isProvisionado, Cotacao cotacao) throws ServiceException {
		if(isProvisionado) {
			provisaoService.estornar(user, cotacao);
			if(cotacao.getListContaCorrenteGlobal() != null && !cotacao.getListContaCorrenteGlobal().isEmpty()) {
				for(ContaCorrenteGlobal c : cotacao.getListContaCorrenteGlobal()) {
					c.setNumeroProtocoloProvisaoCCG(null);
					contaCorrenteRepository.update(c);
				}
			}
		}
	}

	private List<Validacao> validar(PropostaView proposta, Boolean efetuaValidacao, Cotacao cotacao, 
			User user, Map<BigInteger, List<ItemInspecao>> duplicidadeInspecaoPorItem,
			Map<BigInteger, Date> ultimaInspecaoPorCotacao) throws ServiceException {

		List<Validacao> listaValidacao = new ArrayList<>();

		if(proposta.getCotacao().getIdCEPSegurado() == null) {
			listaValidacao.add(new Validacao("Favor informar o CEP"));
		}

		if(proposta.getCotacao().getEnderecoSegurado() == null || proposta.getCotacao().getEnderecoSegurado().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar o Logradouro"));
		}

		if(proposta.getCotacao().getNumeroEnderecoSegurado() == null) {
			listaValidacao.add(new Validacao("Favor informar o Número do Logradouro"));
		}

		if(StringUtils.isEmpty(proposta.getCotacao().getNomeBairroSegurado())) {
			listaValidacao.add(new Validacao("Favor informar o Bairro"));
		}

		if(proposta.getCotacao().getNumeroDDDSegurado() == null || proposta.getCotacao().getNumeroTelefoneSegurado() == null) {
			listaValidacao.add(new Validacao("Favor informar o Telefone"));
		}

		if(StringUtils.isBlank(proposta.getCotacao().getIdEmailSegurado())) {
			listaValidacao.add(new Validacao("Favor informar o e-mail do segurado"));
		} else {
			if(!EmailUtil.valida(proposta.getCotacao().getIdEmailSegurado())) {
				listaValidacao.add(new Validacao("E-mail informado inválido"));
			}
		}

		if(proposta.getCotacao().getNumeroDDDCelularSegurado() == null || proposta.getCotacao().getNumeroCelularSegurado() == null) {
			listaValidacao.add(new Validacao("Favor informar o Celular"));
		}

		try {
			if(proposta.getCotacao().getNumeroDDDCelularSegurado() != null
					&& proposta.getCotacao().getNumeroCelularSegurado() != null
					&& !CelularUtil.valida(proposta.getCotacao().getNumeroDDDCelularSegurado().intValue(),
										  proposta.getCotacao().getNumeroCelularSegurado().intValue(), Calendar.getInstance())) {
					listaValidacao.add(new Validacao("Celular informado inválido"));
			}
		} catch(Exception e) {
			cotacao.setNumeroDDDCelularSegurado(null);
			cotacao.setNumeroCelularSegurado(null);
		}

		if(proposta.getCotacao().getEnderecoSegurado() == null || proposta.getCotacao().getEnderecoSegurado().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar a Cidade"));
		}

		if(proposta.getCotacao().getEnderecoSegurado() == null || proposta.getCotacao().getEnderecoSegurado().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar a UF"));
		}

		if (efetuaValidacao) {
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE ||  cotacao.getIdTipoEndosso() != TipoEndossoEnum.REDUCAO_IS_SINISTRO){
				listaValidacao.addAll(validaDocumentoDigital(proposta));
			}
			listaValidacao.addAll(validaDadosPLD(proposta));
		}
		
		Boolean isAlteracaoCadastralComAltPagto = endossoAlteracaoCadastralTdoService.isAlteracaoCadastralComAlteracaoPagamento(proposta, cotacao);
		Boolean hasNecessidadeAlteracaoPagto = false;
		if(!isAlteracaoCadastralComAltPagto) {
			hasNecessidadeAlteracaoPagto = endossoAlteracaoCadastralTdoService.hasNecessidadeAlteracaoPagamento(cotacao);
		}
				
		
		listaValidacao.addAll(validarAlteracaoCadastralComAlteracaoPagamento(proposta, isAlteracaoCadastralComAltPagto || hasNecessidadeAlteracaoPagto));
		if(efetuaValidacao || isAlteracaoCadastralComAltPagto) {
			listaValidacao.addAll(validaDadosCC(proposta));	
		}
		
		if(isAlteracaoCadastralComAltPagto && 
			proposta.getCotacao().getFormaPagamentoAlteracao().equals(FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo()) &&
			StringUtils.isBlank(cotacao.getIdToken())) {
			listaValidacao.add(new Validacao("Favor Inserir / Alterar Dados do Cartão"));
		}
		
		
		List<ItemCobertura> listaItensCobertura = itemCoberturaRepository.findCoberturasExigeOficio(proposta.getCotacao());
		if(!SecurityUtils.isCorretor()) {
			for(ItemCobertura cobertura: listaItensCobertura) {
				if(cobertura.getCodigoRessegurador() == null) {
					listaValidacao.add(new Validacao("Favor informar o ressegurador para esta proposta"));
					break;
				}
			}
		}
		 
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE ||
				Arrays.asList(TipoEndossoEnum.DEVOLUCAO,
							TipoEndossoEnum.ADICIONAL,
							TipoEndossoEnum.SEM_MOVIMENTO).contains(cotacao.getIdTipoEndosso())) {

			if (user.getGrupoUsuario().equals(GrupoUsuarioEnum.CORRETOR) || cotacaoService.isRegraNegocioFechado(cotacao, user)){

				boolean solicitaContatoInspecao = false;

				// Busca todos os itens para apólice e busca todos os itens que foram alterados no endosso.
				for (ItemCotacao itemCotacao : cotacao.getListItem()
						.stream()
						.filter(it -> cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && it.getIdTipoEndosso() != null))
						.collect(Collectors.toList())) {
					if (itemCotacao.getListItemInspecao().stream().count() == 0){
						solicitaContatoInspecao = true;
						break;
					}

					if (inspecaoService.existeNecessidadeInspecaoItem(itemCotacao,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao)) {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.SIM);
					} else {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.NAO);
					}
				}

				if(user.getCdUsuro() == 402676) {
					solicitaContatoInspecao = false;
				}
				if (solicitaContatoInspecao) {
					listaValidacao.add(new Validacao("Favor informar os dados para solicitação de inspeção."));
				}
				
			} else {

				if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE){
					if (Arrays.asList(
							TipoSeguroEnum.RENOVACAO_TOKIO,
							TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR)
						.contains(cotacao.getIdTipoSeguro())) {
						inspecaoService.existeNecessidadeInspecaoRenovacao(cotacao,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao);
					}
				}
				
				for (ItemCotacao itemCotacao : cotacao.getListItem()
						.stream()
						.filter(it -> cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && it.getIdTipoEndosso() != null))
						.collect(Collectors.toList())) {

					if (inspecaoService.existeNecessidadeInspecaoItem(itemCotacao,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao)) {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.SIM);
					} else {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.NAO);
					}

					if (InspecaoUtil.existeNecessidadeInspecao(itemCotacao)){	
						if (itemCotacao.getListItemInspecao().stream().count() == 0){
							listaValidacao.add(new Validacao("Favor informar os dados para solicitação de inspeção do item " + itemCotacao.getNumeroItem()));
						}
					}
				}
			}

		}
		return listaValidacao;
	}


	private List<Validacao> validarAlteracaoCadastralComAlteracaoPagamento(PropostaView proposta,
			Boolean isAlteracaoCadastralComAltPagto) {
		
		List<Validacao> validacao = new ArrayList<>();
		//ajusta a forma de pagamento na propostaView
		if(isAlteracaoCadastralComAltPagto) {
			if(proposta.getCotacao().getFormaPagamentoAlteracao() == null || proposta.getCotacao().getFormaPagamentoAlteracao().equals(0)) {
				if(proposta.getCotacao().getAlterarFormaPagamento() == null || proposta.getCotacao().getAlterarFormaPagamento().equals(SimNaoEnum.NAO)) {
					validacao.add(new Validacao("Favor alterar a Forma de Pagamento"));
				} else {
					validacao.add(new Validacao("Favor selecionar uma Forma de Pagamento"));	
				}
				
			} else {
				proposta.setCodigoFormaPagamento(proposta.getCotacao().getFormaPagamentoAlteracao());	
			}
		}
		
		return validacao;
	}
	


	private List<Validacao> validaDocumentoDigital(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();

		FormaEnvioDocumentoDigitalEnum formaEnvio = FormaEnvioDocumentoDigitalEnum.getById(proposta.getDocumentoDigital().getFormaEnvio());
		DestinoDocumentoDigitalEnum destino = DestinoDocumentoDigitalEnum.getById(proposta.getDocumentoDigital().getDestino());

		if(formaEnvio == null) {
			listaValidacao.add(new Validacao("Favor informar a Forma de Envio"));
		}

		if(destino == null) {
			proposta.getDocumentoDigital().setDestino(DestinoDocumentoDigitalEnum.CORRETOR.getId());
		}

		if(proposta.getDocumentoDigital().getEmailCorretor() == null || proposta.getDocumentoDigital().getEmailCorretor().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar o(s) E-mails do Corretor"));
		}

		if(listaValidacao.isEmpty()) {
			String[] emails = proposta.getDocumentoDigital().getEmailCorretor().split(";");
			if(emails.length == 0) {
				listaValidacao.add(new Validacao("Favor informar o(s) E-mails do Corretor"));
			} else {
				listaValidacao.addAll(validaEmails(emails));
			}
			
			if(proposta.getDocumentoDigital().getIdEnvioSegurado() == SimNaoEnum.SIM) {
				if(StringUtils.isEmpty(proposta.getDocumentoDigital().getEmailSegurado())) {
					listaValidacao.add(new Validacao("Favor informar o e-mail do segurado"));
				} else if(!EmailUtil.valida(proposta.getDocumentoDigital().getEmailSegurado())) {
					listaValidacao.add(new Validacao("E-mail do Segurado está em um Formato Inválido"));
				}
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaEmails(String[] emails) {
		List<Validacao> listaValidacao = new ArrayList<>();
		for(String email: emails) {
			if(!EmailUtil.valida(email)) {
				listaValidacao.add(new Validacao("E-mail do Corretor inválido (os e-mails deve estar num formato válido e separado por ponto e vírgula (;)) "));
				break;
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaDadosCC(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		if (proposta.getCodigoFormaPagamento() != null) {

			if(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
				if(proposta.getCotacao().getNumeroBancoDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Banco"));
				}
	
				if(proposta.getCotacao().getNumeroAgenciaDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Número da Agência"));
				}
				
				//validação especifica caixa economica (acsel)
				if(proposta.getCotacao().getNumeroBancoDebito() != null && proposta.getCotacao().getNumeroBancoDebito().equals(BancosEnum.CAIXA_ECONOMICA.codigo().intValue())) {
					if(StringUtils.isEmpty(proposta.getCotacao().getTipoContaCorrenteDebito())) {
						listaValidacao.add(new Validacao("Favor informar o Tipo da Conta Corrente"));	
					}
				}
	
				if(proposta.getCotacao().getNumeroContaCorrenteDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Número da Conta Corrente"));
				}
	
				if(StringUtils.isEmpty(proposta.getCotacao().getNumeroDigitoContaCorrenteDebito())) {
					listaValidacao.add(new Validacao("Favor informar o Digito Verificador"));
				}
				
				if(proposta.getCotacao().getIdRelacaoPagadorDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Parentesco/Vínculo com a empresa"));
				}
				
				if (proposta.getCotacao().getIdRelacaoPagadorDebito() != null && !proposta.getCotacao().getIdRelacaoPagadorDebito().equals(10)) {
					//TODO verificar
				}
				/*
				try {
					ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroDadosContaCorrente();
					String url = parametroGeralService.getUrlByNome(urlEnum);
					Map<Object, Object> dadosConta = new HashMap<>();
					dadosConta.put("p_nr_digito_conta_corrente", proposta.getCotacao().getNumeroDigitoContaCorrenteDebito());
					dadosConta.put("p_cd_banco", proposta.getCotacao().getNumeroBancoDebito());
					dadosConta.put("p_nr_digito_agencia", "");
					dadosConta.put("p_cd_agencia", proposta.getCotacao().getNumeroAgenciaDebito());
					dadosConta.put("p_cd_conta_corrente", proposta.getCotacao().getNumeroContaCorrenteDebito());

					DadosContaDebitoView dadosContaDebitoView = restTemplate.postForObject(url, dadosConta, DadosContaDebitoView.class);
					if(!"S".equals(dadosContaDebitoView.getP_id_conta_valida())) {
						listaValidacao.add(new Validacao("Dados da conta corrente para débito inválidos. Favor Verificar."));
					}
				} catch (Exception e) {
					logger.error("Falha ao chamar o serviço de validação de conta corrente ",e);
					listaValidacao.add(new Validacao("Dados da conta corrente para débito inválidos. Favor Verificar."));
				}999*/
			} else if(exigirPreenchimentoBancoBoleto(proposta)) {
				listaValidacao.add(new Validacao("Favor informar o Banco"));
			} else if(FormaPagamentoEnum.CARTAO_DE_CREDITO.getCodigo().equals(proposta.getCodigoFormaPagamento())) {
				System.out.println("-----------------------");
				System.out.println(proposta.getCartao());
				if(proposta.getCartao() == null || StringUtils.isBlank(proposta.getCartao().getToken())) {
					listaValidacao.add(new Validacao("Favor informar os Dados do Cartão"));
				}
			}
		}

		return listaValidacao;
	}
	/**
	 * O preechimento do banco boleto deverá ser exigido quando:
	 * <ul>
	 * 		<li>Forma de Pagamento igual a CARNÊ</li>
	 * 		<li>Número Banco Boleto igual a NULL (não foi selecionado pelo usuário)</li>
	 * 		<li>NÃO possuir recebimento OU possuir recebimento E Tipo Crédito for igual a CREDITO_VINCULADO</li>
	 * </ul>
	 * @param proposta
	 * @return
	 */
	private Boolean exigirPreenchimentoBancoBoleto(PropostaView proposta) {
		return FormaPagamentoEnum.CARNE.getCodigo().equals(proposta.getCodigoFormaPagamento()) &&
				proposta.getCotacao().getNumeroBancoBoleto() == null && 
				(!proposta.isPossuiRecebimento() ||  
				(proposta.isPossuiRecebimento() && TipoCreditoEnum.CREDITO_VINCULADO.equals(proposta.getIdTipoCredito()))); 
	}

	private List<Validacao> validaDadosPLD(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		CotacaoView cotacao = proposta.getCotacao();

		if(cotacao.getEstrangeiro() == SimNaoEnum.SIM) {
			validaDadosEstrangeiro(proposta);
		}

		if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {

			if(cotacao.getIdTipoSexo() == null) {
				listaValidacao.add(new Validacao("Favor informar o Sexo"));
			}
			
			if(cotacao.getDataNascimentoCliente() == null) {
				listaValidacao.add(new Validacao("Favor informar a Data de Nascimento"));
			}
			
			if(StringUtils.isEmpty(cotacao.getTipoDocumento()) && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar o Tipo do Documento"));
			}
			
			if(StringUtils.isEmpty(cotacao.getNumeroRG()) && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar o Número do Documento"));
			}

			if(StringUtils.isEmpty(cotacao.getNomeOrgaoExpedidor()) && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar o Órgão Expedidor"));
			}

			if(cotacao.getDataExpedicao() == null && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar a Data de Expedição"));
			}

			if(cotacao.getIdEstadoCivil() == null) {
				listaValidacao.add(new Validacao("Favor informar o Estado Civil"));
			}
			
			if(StringUtils.isEmpty(cotacao.getEscolaridade())) {
				listaValidacao.add(new Validacao("Favor informar a Escolaridade"));
			}
			
			if(cotacao.getDataNascimentoCliente() != null 
					&& cotacao.getDataExpedicao() != null 
					&& !cotacao.getDataNascimentoCliente().before(cotacao.getDataExpedicao())) {
				listaValidacao.add(new Validacao("A Data de Nascimento deve ser anterior à data de expedição"));
			}
			
			if (cotacao.getEstrangeiro() == SimNaoEnum.NAO && cotacao.getDataExpedicao() != null && cotacao.getDataNascimentoCliente() != null && 
					cotacao.getDataExpedicao().before(cotacao.getDataNascimentoCliente())) {
				listaValidacao.add(new Validacao("Data de Expedição não deve ser menor que a Data de Nascimento."));
			}
			
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || cotacao.getIdTipoEndosso() != TipoEndossoEnum.REDUCAO_IS_SINISTRO){
			
				if(cotacao.getIdProfissao() == null) {
					listaValidacao.add(new Validacao("Favor informar a Profissão"));
				}
				/*	
				if(cotacao.getIdPatrimonio() == null) {
					listaValidacao.add(new Validacao("Favor informar o Patrimônio Declarado"));
				}*/
	
				if(cotacao.getIdRenda() == null) {
					listaValidacao.add(new Validacao("Favor informar a Faixa de Renda"));
				}
			}
			
		} else {
			
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || cotacao.getIdTipoEndosso() != TipoEndossoEnum.REDUCAO_IS_SINISTRO){
				if(cotacao.getPatrimonioLiquido() == null) {
					listaValidacao.add(new Validacao("Favor informar o Capital Social"));
				}
	
				if(cotacao.getReceita() == null) {
					listaValidacao.add(new Validacao("Favor informar o Faturamento Presumido"));
				}
				
				if(cotacao.getRamoAtividade() == null) {
					listaValidacao.add(new Validacao("Favor informar o Ramo atividade"));
				}

				if(cotacao.getTipoEmpresa() == null) {
					listaValidacao.add(new Validacao("Favor informar o tipo de empresa"));
				}

				if(cotacao.getControlador() == null) {
					listaValidacao.add(new Validacao("Favor informar a existência de controladores, administradores e procuradores"));
				}
			}
			
		}

		return listaValidacao;
	}
	
	private List<Validacao> validaDadosEstrangeiro(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		if(proposta.getCotacao().getPossuiRNE() == SimNaoEnum.SIM) {
			if(StringUtils.isEmpty(proposta.getCotacao().getNumeroRNE())) {
				listaValidacao.add(new Validacao("Favor informar o RNE"));
			}

			if(proposta.getCotacao().getDataExpedicao() == null){
				listaValidacao.add(new Validacao("Favor informar a Data de Expedição"));
			}
		} else {
			if(StringUtils.isEmpty(proposta.getCotacao().getNumeroPassaporte())) {
				listaValidacao.add(new Validacao("Favor informar o Passaporte"));
			}

			if(proposta.getCotacao().getIdPais() == null) {
				listaValidacao.add(new Validacao("Favor informar o País Emisssor"));
			}
		}

		return listaValidacao;
	}

	private void populaEndereco(CotacaoView cotacaoView, Cotacao cotacao) {
		cotacao.setEnderecoSegurado(cotacaoView.getEnderecoSegurado());
		cotacao.setNumeroEnderecoSegurado(cotacaoView.getNumeroEnderecoSegurado());
		cotacao.setNomeComplementoEnderecoSegurado(cotacaoView.getNomeComplementoEnderecoSegurado());
		cotacao.setNomeBairroSegurado(cotacaoView.getNomeBairroSegurado());
		cotacao.setNomeMunicipioSegurado(cotacaoView.getNomeMunicipioSegurado());
		cotacao.setIdUFSegurado(cotacaoView.getIdUFSegurado());
		cotacao.setIdEmailSegurado(cotacaoView.getIdEmailSegurado());
		cotacao.setNumeroDDDSegurado(cotacaoView.getNumeroDDDSegurado());
		cotacao.setNumeroTelefoneSegurado(cotacaoView.getNumeroTelefoneSegurado());
		cotacao.setNumeroDDDCelularSegurado(cotacaoView.getNumeroDDDCelularSegurado());
		cotacao.setNumeroCelularSegurado(cotacaoView.getNumeroCelularSegurado());
		if(cotacaoView.getIdCEPSegurado() != null && !cotacaoView.getIdCEPSegurado().isEmpty()) {
			cotacao.setIdCEPSegurado(Long.valueOf(cotacaoView.getIdCEPSegurado()));
		} else {
			cotacao.setIdCEPSegurado(null);
		}

		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			itemCotacao.setEnderecoSegurado(cotacaoView.getEnderecoSegurado());
			itemCotacao.setNumeroEnderecoSegurado(cotacaoView.getNumeroEnderecoSegurado());
			itemCotacao.setNomeComplementoEnderecoSegurado(cotacaoView.getNomeComplementoEnderecoSegurado());
			itemCotacao.setNomeBairroSegurado(cotacaoView.getNomeBairroSegurado());
			itemCotacao.setNomeMunicipioSegurado(cotacaoView.getNomeMunicipioSegurado());
			itemCotacao.setIdUFSegurado(cotacaoView.getIdUFSegurado());
			itemCotacao.setIdEmailSegurado(cotacaoView.getIdEmailSegurado());
			itemCotacao.setNumeroDDDSegurado(cotacaoView.getNumeroDDDSegurado());
			itemCotacao.setNumeroTelefoneSegurado(cotacaoView.getNumeroTelefoneSegurado());
			itemCotacao.setNumeroDDDCelularSegurado(cotacaoView.getNumeroDDDCelularSegurado());
			itemCotacao.setNumeroCelularSegurado(cotacaoView.getNumeroCelularSegurado());

			if(cotacaoView.getIdCEPSegurado() != null && !cotacaoView.getIdCEPSegurado().isEmpty()) {
				itemCotacao.setIdCEPSegurado(Long.valueOf(cotacaoView.getIdCEPSegurado()));
			} else {
				itemCotacao.setIdCEPSegurado(null);
			}
		}

//		itemCotacaoVal.setCodigoAtividadePrincipal(cotacaoView.getCodigoAtividadePrincipal());
//		itemCotacaoVal.setDescricaoAtividadePrincipal(cotacaoView.getDescricaoAtividadePrincipal());
	}
	
	private void populaDadosCC(PropostaView proposta, Cotacao cotacao) {
		if(proposta.isDebitoEmConta()) {
			cotacao.setNumeroBancoBoleto(null);
			cotacao.setNumeroBancoDebito(proposta.getCotacao().getNumeroBancoDebito());
			cotacao.setNumeroAgenciaDebito(proposta.getCotacao().getNumeroAgenciaDebito());
			if(proposta.getCotacao().getNumeroBancoDebito() != null && proposta.getCotacao().getNumeroContaCorrenteDebito() != null) {
				cotacao.setNumeroContaCorrenteDebito(verificarNrCcDebit(proposta.getCotacao().getNumeroBancoDebito().toString()
						,proposta.getCotacao().getNumeroContaCorrenteDebito().toString()
						,proposta.getCotacao().getTipoContaCorrenteDebito()));
			}
			cotacao.setNumeroDigitoContaCorrenteDebito(proposta.getCotacao().getNumeroDigitoContaCorrenteDebito());
			cotacao.setIdRelacaoPagadorDebito(proposta.getCotacao().getIdRelacaoPagadorDebito());	
		} else {
			cotacao.setNumeroBancoBoleto(proposta.getCotacao().getNumeroBancoBoleto());
			cotacao.setNumeroBancoDebito(null);
			cotacao.setNumeroAgenciaDebito(null);
			cotacao.setNumeroContaCorrenteDebito(null);
			cotacao.setNumeroDigitoContaCorrenteDebito(null);
			cotacao.setIdRelacaoPagadorDebito(null);
		}
	}
	
	
	private Long verificarNrCcDebit(String banco, String contaCorrente, String tipoCaixaEconomica)
	{
		String nrCcDebitConta = contaCorrente;
		if ((tipoCaixaEconomica != null) && (BancosEnum.CAIXA_ECONOMICA.codigo().toString().equals(banco))) {
			nrCcDebitConta = StringUtils.trimToEmpty(tipoCaixaEconomica)
					.concat(StringUtils.leftPad(nrCcDebitConta, 8, '0'));
		}
		return Long.valueOf(nrCcDebitConta);
	}

	private void populaDadosDocumentoDigital(DocumentoDigitalView documentoDigitalView, Cotacao cotacao, User user) {
		
		if(documentoDigitalView.getDestino() == null) {
			documentoDigitalView.setDestino(DestinoDocumentoDigitalEnum.CORRETOR.getId());
		}
		
		DocumentoDigital documentoDigital = cotacao.getDocumentoDigital();
		if(documentoDigital == null) {
			documentoDigital = new DocumentoDigital();
			documentoDigital.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			documentoDigital.setDataAtualizacao(new Date());
			documentoDigital.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			documentoDigital.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			documentoDigital.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());

			cotacao.setDocumentoDigital(documentoDigital);
		}

		documentoDigital.setFormaEnvio(FormaEnvioDocumentoDigitalEnum.getById(documentoDigitalView.getFormaEnvio()));
		documentoDigital.setDestino(DestinoDocumentoDigitalEnum.getById(documentoDigitalView.getDestino()));
		documentoDigital.setEmailCorretor(documentoDigitalView.getEmailCorretor());
		documentoDigital.setEmailSegurado(documentoDigitalView.getEmailSegurado());
		documentoDigital.setIdEnvioSegurado(documentoDigitalView.getIdEnvioSegurado());
		documentoDigital.setCotacao(cotacao);
	}
	
	private void populaDadosDevolucao(CotacaoView cotacaoView, Cotacao cotacao) {
		cotacao.setCodigoFormaDevolucao(cotacaoView.getCodigoFormaDevolucao());
		cotacao.setNumeroBancoDevolucao(cotacaoView.getNumeroBancoDevolucao());
		cotacao.setNumeroAgenciaDevolucao(cotacaoView.getNumeroAgenciaDevolucao());
		cotacao.setNumeroDigitoAgenciaDevolucao(cotacaoView.getNumeroDigitoAgenciaDevolucao());
		cotacao.setNumeroContaCorrenteDevolucao(cotacaoView.getNumeroContaCorrenteDevolucao());
		cotacao.setNumeroDigitoContaCorrenteDevolucao(cotacaoView.getNumeroDigitoContaCorrenteDevolucao());
	}

	private void populaDadosSegurado(CotacaoView cotacaoView, Cotacao cotacao) {
		cotacao.setNumeroPropostaCorretor(cotacaoView.getNumeroPropostaCorretor());

		cotacao.setIdTipoSexo(cotacaoView.getIdTipoSexo());
		cotacao.setDataNascimentoCliente(cotacaoView.getDataNascimentoCliente());
		cotacao.setIdEstadoCivil(cotacaoView.getIdEstadoCivil());
		
		cotacao.setNumeroRG(cotacaoView.getNumeroRG());
		cotacao.setDataExpedicao(cotacaoView.getDataExpedicao());
		cotacao.setNomeOrgaoExpedidor(cotacaoView.getNomeOrgaoExpedidor());

		if(cotacaoView.getEstrangeiro() != SimNaoEnum.SIM) {
			cotacaoView.setPossuiRNE(null);
		}

		cotacao.setEstrangeiro(cotacaoView.getEstrangeiro());
		cotacao.setPossuiRNE(cotacaoView.getPossuiRNE());
		cotacao.setNumeroRNE(cotacaoView.getNumeroRNE());
		cotacao.setNumeroPassaporte(cotacaoView.getNumeroPassaporte());
		cotacao.setIdPais(cotacaoView.getIdPais());
		cotacao.setIdProfissao(cotacaoView.getIdProfissao());
		cotacao.setIdCapitalSocial(cotacaoView.getIdCapitalSocial());
		cotacao.setIdPatrimonio(cotacaoView.getIdPatrimonio());
		cotacao.setIdSeguradoPEP(cotacaoView.getIdSeguradoPEP());
		cotacao.setIdFaturamentoPresumido(cotacaoView.getIdFaturamentoPresumido());
		cotacao.setIdRenda(cotacaoView.getIdRenda());

		cotacao.setNomeAgenciaDebito(cotacaoView.getNomeAgenciaDebito());
		cotacao.setNumeroTelefoneAgencia(cotacaoView.getNumeroTelefoneAgencia());
		cotacao.setNomeCidadeAgencia(cotacaoView.getNomeCidadeAgencia());
		cotacao.setNomeBairroAgencia(cotacaoView.getNomeBairroAgencia());
		cotacao.setIdCepAgencia(cotacaoView.getIdCepAgencia());
		cotacao.setEnderecoAgencia(cotacaoView.getEnderecoAgencia());

		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			itemCotacao.setNumeroRG(cotacaoView.getNumeroRG());
			itemCotacao.setDataExpedicao(cotacaoView.getDataExpedicao());
			itemCotacao.setNomeOrgaoExpedidor(cotacaoView.getNomeOrgaoExpedidor());

			itemCotacao.setEstrangeiro(cotacaoView.getEstrangeiro());
			itemCotacao.setPossuiRNE(cotacaoView.getPossuiRNE());
			itemCotacao.setNumeroRNE(cotacaoView.getNumeroRNE());
			itemCotacao.setNumeroPassaporte(cotacaoView.getNumeroPassaporte());
			itemCotacao.setIdPais(cotacaoView.getIdPais());
			itemCotacao.setIdProfissao(cotacaoView.getIdProfissao());
			itemCotacao.setIdCapitalSocial(cotacaoView.getIdCapitalSocial());
			itemCotacao.setIdPatrimonio(cotacaoView.getIdPatrimonio());
			itemCotacao.setIdSeguradoPEP(cotacaoView.getIdSeguradoPEP());
			itemCotacao.setIdFaturamentoPresumido(cotacaoView.getIdFaturamentoPresumido());
			itemCotacao.setIdRenda(cotacaoView.getIdRenda());
		}
	}

	@LogPerformance
	public CartaoView validarCartao(CartaoView cartao) throws ServiceException {

		String url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroPaymentServer()) + "v1/credit-cards";
		
		String username = "ctpj";
		String senha = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroSenhaPaymentServer());

		String plainCreds = username + ":" + senha;
		String base64Creds = Base64Utils.encodeToString(plainCreds.getBytes());

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);

		try {
			CartaoResponse cartaoRequest = new CartaoResponse();
			cartaoRequest.setAnoExpiracao(cartao.getAnoValidade());
			cartaoRequest.setBandeira(cartao.getBandeira().toUpperCase());
			cartaoRequest.setMesExpiracao(cartao.getMesValidade());
			ClienteCartao cliente = new ClienteCartao();
			cliente.setDocumento(cartao.getDocumento().replaceAll("[^\\d]", ""));
			cliente.setNome(cartao.getNomeTitular());
			cartaoRequest.setCliente(cliente);
			cartaoRequest.setNumero(cartao.getNumeroCartao());
			cartaoRequest.setPortador(cartao.getNomeTitular());

			ResponseEntity<CartaoResponse> response = restTemplate.postForEntity(url, new HttpEntity<>(cartaoRequest, headers), CartaoResponse.class, new Object[0]);

			if (!response.getStatusCode().is2xxSuccessful()) {
				throw new RuntimeException("Erro ao efetuar a operação de cartão de crédito: StatusCode: " + response.getStatusCode());
			}
			
			CartaoResponse cartaoCriado = (CartaoResponse)response.getBody();
			
			if (cartaoCriado != null && !StringUtils.isBlank(cartaoCriado.getId())) {
				cartao.setToken(cartaoCriado.getId());
				cartao.setNumeroCartao(cartaoCriado.getNumero());
				Cotacao cotacao = cotacaoRepository.findById(cartao.getCotacao());
				LocalDateTime localDateTime = LocalDateTime.ofInstant(cotacao.getDataInicioVigencia().toInstant(), ZoneId.systemDefault());
				LocalDate localDate = localDateTime.toLocalDate();
				LocalDate diaFatura = LocalDate.of(localDate.getYear(), localDate.getMonthValue(), cartao.getDiaFatura());
				Date dataVencimentoProgramado = Date.from(diaFatura.atStartOfDay(ZoneId.systemDefault()).toInstant()); 
				cotacao.setDataVencimentoProgramada(dataVencimentoProgramado);

				cotacao.setIdToken(cartao.getToken());
				cotacaoRepository.save(cotacao);
				return cartao;
			} else {
				throw new ServiceException("Não foi possível validar o cartão do cliente");
			}
		} catch (HttpClientErrorException e) {
			logger.error("Validação cartao: " + e.getResponseBodyAsString());
			throw new ServiceException("Não foi possível validar o cartão do cliente");
		} catch (Exception e) {
			logger.error("Validação cartao ", e);
			throw new ServiceException("Não foi possível validar o cartão do cliente");
		}
	}
	
	public Boolean exigeOficio(PropostaView proposta) throws ServiceException {
		Boolean exigeOficio = Boolean.FALSE;
		List<ItemCobertura> listaItensCobertura = new ArrayList<>();
		try {
			listaItensCobertura = itemCoberturaRepository.findCoberturasExigeOficio(proposta.getCotacao());
			if(listaItensCobertura != null && !listaItensCobertura.isEmpty()){
				exigeOficio = Boolean.TRUE;
			}
		} catch (Exception e) {
			logger.error("Erro ao buscar informações para verificar se exige Ofício", e);
			throw new ServiceException(e.getMessage(), e);
		}
		return exigeOficio;
	}
	
	@LogPerformance
	public ResultadoREST<ResponseInterfaceCSF> validaIdDocstoreCotacao(BigInteger sequencialCotacaoProposta,User user) throws ServiceException{
		
		ResultadoREST<ResponseInterfaceCSF> response = new ResultadoREST<>();
		
		try{
			response = cotacaoPrintService.gerarImpressaoCotacao(sequencialCotacaoProposta,"S",user);
		}catch (Exception e) {
			logger.error("Erro ao validar informações para verificar se exige Ofício", e);
			throw new ServiceException(e.getMessage(), e);
		}
		return response;
	}
	
	public String validaUrl(ParametroGeralEnum urlEnum) throws ServiceException {
		if (urlEnum == null) {
			logger.error("Erro ao na busca url, urlEnum igual a nulo.");
			throw new ServiceException("Erro ao na busca url, urlEnum igual a nulo.");
		}

		String url = null;
		try {
			url = parametroGeralService.getUrlByNome(urlEnum);
		} catch (Exception e) {
			logger.error("Erro ao realizar a busca da URL." + e.getMessage());
			throw new ServiceException("Erro ao realizar a busca da URL.",e);
		}

		if (StringUtils.isEmpty(url)) {
			logger.error("URL de acesso igual a nulo ou vazia.");
			throw new ServiceException("URL de acesso igual a nulo ou vazia.");
		}
		return url;
	}

	@Async
	@LogPerformance
	public void enviaContratacao(BigInteger sequencialCotacaoProposta, User user) {
		try {
			String url = validaUrl(ParametroGeralEnum.getParametroEnviarFilaContratacao());
			List<Validacao> listaValidacao = mensageriaService.chamarFilaContratacao(sequencialCotacaoProposta,user,url);
			if(listaValidacao != null && !listaValidacao.isEmpty()) {
				mailUtilService.sendMailErro(String.format("Erro ao enviar para a fila de contratação [%s] ", sequencialCotacaoProposta) 
						+ listaValidacao.stream()
							.map(Validacao::getDescricao)
							.collect(Collectors.joining(";")));
			}
		} catch (ServiceException e) {
			mailUtilService.sendMailErro(String.format("Erro ao enviar para a fila de contratação [%s] ", sequencialCotacaoProposta) + ExceptionUtils.getStackTrace(e));
			logger.error("Erro ao enviar para a fila de contratação: " + sequencialCotacaoProposta,e);
		}
	}

	/**
	 * Retorna a lista de e-mails da solicitação (parte CONTATO do SCT) + os e-mails da BU <br/>
	 * Qualquer problema retorna uma lista vazia
	 * 
	 * @param proposta
	 * @return a lista de e-mails da solicitação + BU
	 */
	public List<String> listarEmails(PropostaView proposta) {
		try {
			String url = validaUrl(ParametroGeralEnum.getParametroSCTEmailsSolicitacao());
			List<String> emails = proposta.getDocumentoDigital().getEmailCorretor() != null ? 
					new ArrayList(Arrays.asList(proposta.getDocumentoDigital().getEmailCorretor().split(";"))) : Collections.emptyList();
//			ResponseEntity<EmailContatoSolicitacao> emailsSolicitacao = restTemplate.getForEntity(
//					url + "/" + proposta.getCotacao().getNumeroCotacaoProposta(),
//					EmailContatoSolicitacao.class);
//
//			if(emailsSolicitacao.getBody() != null && emailsSolicitacao.getBody().getCodigo() == 0) {
//				emailsSolicitacao.getBody().getEmailSolicitacaoCotacao().forEach((EmailContato email) -> {
//					if(EmailUtil.valida(email.getDsEmail())) {
//						emails.add(email.getDsEmail());
//					}
//				});
//			}
			return emails;
		} catch (Exception e) {
			logger.error("Erro ao listar os e-mails da solicitação ", e);
			return  proposta.getDocumentoDigital().getEmailCorretor() != null ? 
					Arrays.asList(proposta.getDocumentoDigital().getEmailCorretor().split(";")) : Collections.emptyList();
		}
	}
	
	public static class EmailContatoSolicitacao {
		private int codigo;
		private String mensagem;
		private List<EmailContato> emailSolicitacaoCotacao;

		public int getCodigo() {
			return codigo;
		}

		public void setCodigo(int codigo) {
			this.codigo = codigo;
		}

		public String getMensagem() {
			return mensagem;
		}

		public void setMensagem(String mensagem) {
			this.mensagem = mensagem;
		}

		public List<EmailContato> getEmailSolicitacaoCotacao() {
			return emailSolicitacaoCotacao;
		}

		public void setEmailSolicitacaoCotacao(List<EmailContato> emailSolicitacaoCotacao) {
			this.emailSolicitacaoCotacao = emailSolicitacaoCotacao;
		}

		@Override
		public String toString() {
			return "EmailContatoSolicitacao [codigo=" + codigo + ", mensagem=" + mensagem + ", emailSolicitacaoCotacao="
					+ emailSolicitacaoCotacao + "]";
		}
	}
	
	public static class EmailContato {
		
		private int idTipoEmail;
		private String dsEmail;

		public int getIdTipoEmail() {
			return idTipoEmail;
		}

		public void setIdTipoEmail(int idTipoEmail) {
			this.idTipoEmail = idTipoEmail;
		}

		public String getDsEmail() {
			return dsEmail;
		}

		public void setDsEmail(String dsEmail) {
			this.dsEmail = dsEmail;
		}

		@Override
		public String toString() {
			return "EmailContato [idTipoEmail=" + idTipoEmail + ", dsEmail=" + dsEmail + "]";
		}
	}
	
	public static void main(String[] args) {
		System.out.println(StringUtils.trimToEmpty("001")
					.concat(StringUtils.leftPad("3618", 8, '0')));
	}
}