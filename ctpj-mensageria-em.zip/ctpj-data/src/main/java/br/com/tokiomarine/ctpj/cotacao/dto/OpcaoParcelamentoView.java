package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

public class OpcaoParcelamentoView implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -8827468060157443221L;
	private BigInteger sequencialOpcaoParcelamento;
	private String descricaoFormaParcelamento;
	private String descricaoFormaPagamento;
	private BigDecimal valorPrimeiraParcela;
	private BigDecimal valorPremioTotal;
	private SimNaoEnum idParcelamentoEscolhido;

	public BigInteger getSequencialOpcaoParcelamento() {
		return sequencialOpcaoParcelamento;
	}

	public void setSequencialOpcaoParcelamento(BigInteger sequencialOpcaoParcelamento) {
		this.sequencialOpcaoParcelamento = sequencialOpcaoParcelamento;
	}

	public String getDescricaoFormaParcelamento() {
		return descricaoFormaParcelamento;
	}

	public void setDescricaoFormaParcelamento(String descricaoFormaParcelamento) {
		this.descricaoFormaParcelamento = descricaoFormaParcelamento;
	}

	public String getDescricaoFormaPagamento() {
		return descricaoFormaPagamento;
	}

	public void setDescricaoFormaPagamento(String descricaoFormaPagamento) {
		this.descricaoFormaPagamento = descricaoFormaPagamento;
	}

	public BigDecimal getValorPrimeiraParcela() {
		return valorPrimeiraParcela;
	}

	public void setValorPrimeiraParcela(BigDecimal valorPrimeiraParcela) {
		this.valorPrimeiraParcela = valorPrimeiraParcela;
	}

	public BigDecimal getValorPremioTotal() {
		return valorPremioTotal;
	}

	public void setValorPremioTotal(BigDecimal valorPremioTotal) {
		this.valorPremioTotal = valorPremioTotal;
	}

	public SimNaoEnum getIdParcelamentoEscolhido() {
		return idParcelamentoEscolhido;
	}

	public void setIdParcelamentoEscolhido(SimNaoEnum idParcelamentoEscolhido) {
		this.idParcelamentoEscolhido = idParcelamentoEscolhido;
	}

}
