package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoSolicitacaoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.PrazoVigenciaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.sct.request.SolicitacaoCotacaoFakeCTPJ;

@Service
public class SolicitacaoCotacaoFakeService {
	
	private static Logger logger = LogManager.getLogger(SolicitacaoCotacaoFakeService.class);
	
	
	public SolicitacaoCotacaoFakeCTPJ bindSolcitacaoFake(){
		
		logger.info("SolicitacaoCotacaoFakeService.bindSolcitacaoFake");
		
		SolicitacaoCotacaoFakeCTPJ solicitacao = new SolicitacaoCotacaoFakeCTPJ();
		solicitacao.setNrSolctCotac(new BigInteger("829634"));
		solicitacao.setCdApoliRenov(1L);
		solicitacao.setCdAtivdPrcpa(1);
		solicitacao.setCdCiaSgdra(1);
		solicitacao.setCdCrtorAcsel(1L);
		solicitacao.setCdCrtorPlatf(40);
		solicitacao.setCdGrp(101);
		solicitacao.setCdLocal(5);
		solicitacao.setCdUsuro(105252);
		solicitacao.setNmUsuro("JOÃO DAS NEVES");
		solicitacao.setCdNivelAutz(10L);
		solicitacao.setDsEnder("Avenida Francisco Prestes Maia");
		solicitacao.setNrEnder(1633);
		solicitacao.setRecalculo(true);
		solicitacao.setDsCmploEnder(null);
		solicitacao.setNmBairr("Sta. Terezinha");
		solicitacao.setNrCep(9770000);
		solicitacao.setNmCidad("São Bernardo Do Campo");
		solicitacao.setIcUf("SP");
		solicitacao.setNrDddCelul(11);
		solicitacao.setNrCelul(991468265);
		solicitacao.setNrDddTelef(11);
		solicitacao.setNrTelef(335615885);
		solicitacao.setDsEmail("ctpj@tokiomarine.com.br");
		solicitacao.setCdPrdut(1851);
		solicitacao.setCdProtr(100004);
		solicitacao.setCdRamoPrdutRenov(1);
		solicitacao.setCdSbloc(4);
		solicitacao.setCdSituc(314);
		solicitacao.setCdSubct(100006);
		solicitacao.setDtEntrCotac(Calendar.getInstance().getTime());
		solicitacao.setIcTipoPesoa(TipoSeguradoEnum.FISICA.getId());
		solicitacao.setNmCrtorPlatf("TESTE CORRETOR");
		solicitacao.setNmLocal("SÃO PAULO");
		solicitacao.setNmPrdut("RISCOS NOMEADOS - LMI");
		solicitacao.setNmProtr("GERENTE COMERCIAL");
		solicitacao.setNmSbloc("CAMPINAS");
		solicitacao.setNmSgrdo("SEGURADO");
		solicitacao.setNmSituc("CADASTRO COTAÇÃO");
		solicitacao.setNmSubct("SUBSCRITOR");
		solicitacao.setNrApoliCongr("123.154.678");
		solicitacao.setNrCnpjCpfSgrdo(40473469502L);
		solicitacao.setIdMongodb("5d10f753768b4b76e84e731a");
		solicitacao.setIdDestinoEmissao(DestinoEmissaoEnum.ACX);
		solicitacao.setSucesso(true);
		
		solicitacao.setDtCotac(Calendar.getInstance().getTime());
		solicitacao.setIdCossegurado(1);
		solicitacao.setDsPerctSnlid("dsPerctSnlid");
		solicitacao.setCdPerctSnlid(1);
		solicitacao.setDtInicioVigencia(Calendar.getInstance().getTime());
		solicitacao.setIcTipoSegur(TipoSolicitacaoCotacaoEnum.RENOVACAO_TOKIO);
		solicitacao.setCdClasseBonus(1);
		solicitacao.setPcComissaoRamo(new BigDecimal("10.2"));
		solicitacao.setCdMoeda(MoedaEnum.REAL);
		solicitacao.setIdResseguroFacultativo(SimNaoEnum.SIM);
		solicitacao.setIdPrazoVigencia(PrazoVigenciaEnum.ANUAL);
		solicitacao.setNrProcessoSusep("101516165165");
		solicitacao.setDtTerminoVigencia(Calendar.getInstance().getTime());
		
		return solicitacao;
	}
	
	public void bindComplementoEndosso(SolicitacaoCotacaoFakeCTPJ solicitacao){
		
		logger.info("SolicitacaoCotacaoFakeService.bindComplementoEndosso");
		
		solicitacao.setIdMongodb("5909cdda29fa4beb3abe516b");	
		solicitacao.setCdRamoPrdutApoliTmsrEndso(180);
		solicitacao.setCdApoliTmsrEndso(123456L);
	}

}
