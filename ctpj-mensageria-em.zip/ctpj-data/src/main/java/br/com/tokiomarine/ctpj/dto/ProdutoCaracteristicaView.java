package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;

public class ProdutoCaracteristicaView implements Serializable {

	private static final long serialVersionUID = -7301691320673521775L;

	private CaracteristicaView cep;
	private CaracteristicaView logradouro;
	private CaracteristicaView numero;
	private CaracteristicaView complemento;
	private CaracteristicaView municipio;
	private CaracteristicaView uf;
	private CaracteristicaView atividade;
	private CaracteristicaView atividadeAlternativa;
	private CaracteristicaView valorEmRisco;
	private CaracteristicaView classeConstrucao;
	private CaracteristicaView classeLocalizacao;
	private CaracteristicaView classeOcupacao;
	private CaracteristicaView localizacao;
	private CaracteristicaView bemCoberto;
	private CaracteristicaView percentISVR;
	private CaracteristicaView percentDMPVR;
	private CaracteristicaView idDistribuicaoVR;
	private CaracteristicaView sistemaProtecional;
	private CaracteristicaView ambitoGeografico;
	private CaracteristicaView tipoFundacao;
	private CaracteristicaView severidade;
	private CaracteristicaView tipoConstrucao;
	private CaracteristicaView tipoPoco;
	private CaracteristicaView classeMercadoria;
	private CaracteristicaView classificacaoPessoa;
	private CaracteristicaView classeResseguro;
	private CaracteristicaView classeBonus;
	private CaracteristicaView percSinistroPremio;
	private CaracteristicaView galpaoVinilona;
	private CaracteristicaView bairro;

	public CaracteristicaView getCep() {
		return cep;
	}

	public void setCep(CaracteristicaView cep) {
		this.cep = cep;
	}

	public CaracteristicaView getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(CaracteristicaView logradouro) {
		this.logradouro = logradouro;
	}

	public CaracteristicaView getNumero() {
		return numero;
	}

	public void setNumero(CaracteristicaView numero) {
		this.numero = numero;
	}

	public CaracteristicaView getComplemento() {
		return complemento;
	}

	public void setComplemento(CaracteristicaView complemento) {
		this.complemento = complemento;
	}

	public CaracteristicaView getMunicipio() {
		return municipio;
	}

	public void setMunicipio(CaracteristicaView municipio) {
		this.municipio = municipio;
	}

	public CaracteristicaView getUf() {
		return uf;
	}

	public void setUf(CaracteristicaView uf) {
		this.uf = uf;
	}

	public CaracteristicaView getAtividade() {
		return atividade;
	}

	public void setAtividade(CaracteristicaView atividade) {
		this.atividade = atividade;
	}

	public CaracteristicaView getAtividadeAlternativa() {
		return atividadeAlternativa;
	}

	public void setAtividadeAlternativa(CaracteristicaView atividadeAlternativa) {
		this.atividadeAlternativa = atividadeAlternativa;
	}

	public CaracteristicaView getValorEmRisco() {
		return valorEmRisco;
	}

	public void setValorEmRisco(CaracteristicaView valorEmRisco) {
		this.valorEmRisco = valorEmRisco;
	}

	public CaracteristicaView getClasseConstrucao() {
		return classeConstrucao;
	}

	public void setClasseConstrucao(CaracteristicaView classeConstrucao) {
		this.classeConstrucao = classeConstrucao;
	}

	public CaracteristicaView getClasseLocalizacao() {
		return classeLocalizacao;
	}

	public void setClasseLocalizacao(CaracteristicaView classeLocalizacao) {
		this.classeLocalizacao = classeLocalizacao;
	}

	public CaracteristicaView getClasseOcupacao() {
		return classeOcupacao;
	}

	public void setClasseOcupacao(CaracteristicaView classeOcupacao) {
		this.classeOcupacao = classeOcupacao;
	}

	public CaracteristicaView getLocalizacao() {
		return localizacao;
	}

	public void setLocalizacao(CaracteristicaView localizacao) {
		this.localizacao = localizacao;
	}

	public CaracteristicaView getBemCoberto() {
		return bemCoberto;
	}

	public void setBemCoberto(CaracteristicaView bemCoberto) {
		this.bemCoberto = bemCoberto;
	}

	public CaracteristicaView getPercentISVR() {
		return percentISVR;
	}

	public void setPercentISVR(CaracteristicaView percentISVR) {
		this.percentISVR = percentISVR;
	}

	public CaracteristicaView getPercentDMPVR() {
		return percentDMPVR;
	}

	public void setPercentDMPVR(CaracteristicaView percentDMPVR) {
		this.percentDMPVR = percentDMPVR;
	}

	public CaracteristicaView getIdDistribuicaoVR() {
		return idDistribuicaoVR;
	}

	public void setIdDistribuicaoVR(CaracteristicaView idDistribuicaoVR) {
		this.idDistribuicaoVR = idDistribuicaoVR;
	}

	public CaracteristicaView getSistemaProtecional() {
		return sistemaProtecional;
	}

	public void setSistemaProtecional(CaracteristicaView sistemaProtecional) {
		this.sistemaProtecional = sistemaProtecional;
	}

	public CaracteristicaView getAmbitoGeografico() {
		return ambitoGeografico;
	}

	public void setAmbitoGeografico(CaracteristicaView ambitoGeografico) {
		this.ambitoGeografico = ambitoGeografico;
	}

	public CaracteristicaView getTipoFundacao() {
		return tipoFundacao;
	}

	public void setTipoFundacao(CaracteristicaView tipoFundacao) {
		this.tipoFundacao = tipoFundacao;
	}

	public CaracteristicaView getSeveridade() {
		return severidade;
	}

	public void setSeveridade(CaracteristicaView severidade) {
		this.severidade = severidade;
	}

	public CaracteristicaView getTipoConstrucao() {
		return tipoConstrucao;
	}

	public void setTipoConstrucao(CaracteristicaView tipoConstrucao) {
		this.tipoConstrucao = tipoConstrucao;
	}

	public CaracteristicaView getTipoPoco() {
		return tipoPoco;
	}

	public void setTipoPoco(CaracteristicaView tipoPoco) {
		this.tipoPoco = tipoPoco;
	}

	public CaracteristicaView getClasseMercadoria() {
		return classeMercadoria;
	}

	public void setClasseMercadoria(CaracteristicaView classeMercadoria) {
		this.classeMercadoria = classeMercadoria;
	}

	public CaracteristicaView getClassificacaoPessoa() {
		return classificacaoPessoa;
	}

	public void setClassificacaoPessoa(CaracteristicaView classificacaoPessoa) {
		this.classificacaoPessoa = classificacaoPessoa;
	}

	public CaracteristicaView getClasseResseguro() {
		return classeResseguro;
	}

	public void setClasseResseguro(CaracteristicaView classeResseguro) {
		this.classeResseguro = classeResseguro;
	}

	public CaracteristicaView getClasseBonus() {
		return classeBonus;
	}

	public void setClasseBonus(CaracteristicaView classeBonus) {
		this.classeBonus = classeBonus;
	}

	public CaracteristicaView getPercSinistroPremio() {
		return percSinistroPremio;
	}

	public void setPercSinistroPremio(CaracteristicaView percSinistroPremio) {
		this.percSinistroPremio = percSinistroPremio;
	}

	public CaracteristicaView getGalpaoVinilona() {
		return galpaoVinilona;
	}

	public void setGalpaoVinilona(CaracteristicaView galpaoVinilona) {
		this.galpaoVinilona = galpaoVinilona;
	}

	public CaracteristicaView getBairro() {
		return bairro;
	}

	public void setBairro(CaracteristicaView bairro) {
		this.bairro = bairro;
	}
}