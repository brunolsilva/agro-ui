package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

public class RenumeracaoItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7944231788634579536L;
	
	private BigInteger sequencialItemCotacao;
	private BigInteger novoNumeroItem;
	private boolean excluiItem;
	
	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}
	
	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}
	
	public BigInteger getNovoNumeroItem() {
		return novoNumeroItem;
	}
	
	public void setNovoNumeroItem(BigInteger novoNumeroItem) {
		this.novoNumeroItem = novoNumeroItem;
	}
	
	public boolean isExcluiItem() {
		return excluiItem;
	}
	
	public void setExcluiItem(boolean excluiItem) {
		this.excluiItem = excluiItem;
	}

}
