package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemOutroSeguroView implements Serializable {

	private static final long serialVersionUID = -4743916387323264722L;
	
	private BigInteger sequencialItemOutroSeguro;
	private Long codigoCompanhiaSeguradora;
	private String nomeCompanhiaSeguradora;
	private String numeroApolice;
	private BigDecimal valorLMG;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone="America/Sao_Paulo")
	private Date dataFimVigencia;
	private Integer numeroItem;
	private BigInteger sequencialItemCotacao;
	private MoedaEnum moeda;

	public BigInteger getSequencialItemOutroSeguro() {
		return sequencialItemOutroSeguro;
	}
	public void setSequencialItemOutroSeguro(BigInteger sequencialItemOutroSeguro) {
		this.sequencialItemOutroSeguro = sequencialItemOutroSeguro;
	}
	public Long getCodigoCompanhiaSeguradora() {
		return codigoCompanhiaSeguradora;
	}
	public void setCodigoCompanhiaSeguradora(Long codigoCompanhiaSeguradora) {
		this.codigoCompanhiaSeguradora = codigoCompanhiaSeguradora;
	}
	public String getNomeCompanhiaSeguradora() {
		return nomeCompanhiaSeguradora;
	}
	public void setNomeCompanhiaSeguradora(String nomeCompanhiaSeguradora) {
		this.nomeCompanhiaSeguradora = nomeCompanhiaSeguradora;
	}
	public String getNumeroApolice() {
		return numeroApolice;
	}
	public void setNumeroApolice(String numeroApolice) {
		this.numeroApolice = numeroApolice;
	}
	public BigDecimal getValorLMG() {
		return valorLMG;
	}
	public void setValorLMG(BigDecimal valorLMG) {
		this.valorLMG = valorLMG;
	}
	public Date getDataFimVigencia() {
		return dataFimVigencia;
	}
	public void setDataFimVigencia(Date dataFimVigencia) {
		this.dataFimVigencia = dataFimVigencia;
	}
	public Integer getNumeroItem() {
		return numeroItem;
	}
	public void setNumeroItem(Integer numeroItem) {
		this.numeroItem = numeroItem;
	}
	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}
	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}
	
	public MoedaEnum getMoeda() {
		return moeda;
	}
	
	public void setMoeda(MoedaEnum moeda) {
		this.moeda = moeda;
	}
	
	
}