package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemRelacaoEnderecoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoEndereco;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemRelacaoEnderecoService {

	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0120
	 */
	public void validarRelacaoEndereco(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiRelacaoEndereco = itemEndosso.getListItemRelacaoEndereco() != null && !itemEndosso.getListItemRelacaoEndereco().isEmpty();
		boolean itemApolicePossuiRelacaoEndereco = itemApolice.getListItemRelacaoEnderecoApolice() != null && !itemApolice.getListItemRelacaoEnderecoApolice().isEmpty();
		
		//1 - percorre a relação de endereços do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiRelacaoEndereco){			
			for(ItemRelacaoEndereco itemEndossoRelacEnd : itemEndosso.getListItemRelacaoEndereco()){
				boolean enderecoExiste = false;
				if(itemApolicePossuiRelacaoEndereco){
					for(ItemRelacaoEnderecoApolice itemApoliceRelacEnd : itemApolice.getListItemRelacaoEnderecoApolice()){
						if(AssertUtils.compareNull(itemEndossoRelacEnd.getSequencialRelacaoEndereco(),itemApoliceRelacEnd.getSequencialRelacaoEndereco())){
							//valida cep
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getIdCEP() , itemEndossoRelacEnd.getIdCEP(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- CEP: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida endereço
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getEnderecoSegurado(), itemEndossoRelacEnd.getEnderecoSegurado(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- Endereço: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida bairro
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getNomeBairro(), itemEndossoRelacEnd.getNomeBairro(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- Bairro: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida numero endereço
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getNumeroEndereco(), itemEndossoRelacEnd.getNumeroEndereco(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- Nº: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida complemento endereço
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getNomeComplemento(), itemEndossoRelacEnd.getNomeComplemento(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- Complemento: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida cidade
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getNomeMunicipio(), itemEndossoRelacEnd.getNomeMunicipio(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- Cidade: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida uf
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getIdUF(), itemEndossoRelacEnd.getIdUF(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- UF: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida classe construção
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceRelacEnd.getCodigoClasseConstrucao(), itemEndossoRelacEnd.getCodigoClasseConstrucao(), TipoMensagemEndossoEnum.ALT_ENDERECOS, "- Classe de construção: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							enderecoExiste = true;
							break;
						}						
					}
				}
				
				//se o endereço não existir
				if(!enderecoExiste){ 
					logarInclusaoEndereco(itemEndossoRelacEnd,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os endereços da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiRelacaoEndereco){
			for(ItemRelacaoEnderecoApolice itemApoliceRelacEnd : itemApolice.getListItemRelacaoEnderecoApolice()){
				boolean enderecoExiste = false;
				if(itemEndossoPossuiRelacaoEndereco){
					for(ItemRelacaoEndereco itemEndossoRelacEnd : itemEndosso.getListItemRelacaoEndereco()){
						if(AssertUtils.compareNull(itemEndossoRelacEnd.getSequencialRelacaoEndereco(),itemApoliceRelacEnd.getSequencialRelacaoEndereco())){
							enderecoExiste = true;
							break;
						}
					}
				}
				
				if(!enderecoExiste){
					logarExclusaoEndereco(itemApoliceRelacEnd,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoEndereco(ItemRelacaoEndereco itemEndossoRelacEnd, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_ENDERECOS, itemEndossoRelacEnd.getSequencialRelacaoEndereco().toString(), user));
	}
	
		
	private void logarExclusaoEndereco(ItemRelacaoEnderecoApolice itemApoliceRelacEnd, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_ENDERECOS, itemApoliceRelacEnd.getSequencialRelacaoEndereco().toString(), user));
	}	
}
