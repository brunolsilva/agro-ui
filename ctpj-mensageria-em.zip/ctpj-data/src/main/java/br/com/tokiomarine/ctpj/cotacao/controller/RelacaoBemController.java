package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemRelacaoBemView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.FranquiaService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.cotacao.service.RelacaoBemService;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ControllerInternalErrorException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.ItemRelacaoBemMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping("/relacaoBem")
public class RelacaoBemController {
	private static final Logger logger = LogManager.getLogger(RelacaoBemController.class);
	@Autowired
	private RelacaoBemService relacaoBemService;

	@Autowired
	private FranquiaService franquiaService;
	
	@Autowired
	private ItemRelacaoBemMapper itemRBMapper;
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;	
	
	@GetMapping(value = "/{seqCotacao}")
	public String home(@PathVariable BigInteger seqCotacao, Model model){		
		List<ItemCotacao> itens;
		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(seqCotacao);
			itens = franquiaService.getItemsComEndereco(seqCotacao);
			model.addAttribute("cabecalhoCotacao",cotacaoView);
			model.addAttribute("readOnly",isReadOnly(cotacaoView));
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}
		
		model.addAttribute("itensCotacao", itens);
		model.addAttribute("itensRB", getItensRelacaoBemView(seqCotacao));
		model.addAttribute("seqCotacao", seqCotacao);
		return Paginas.relacaoBem.value();
	}
	
	private boolean isReadOnly(CotacaoView cotacaoView) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario) && !cotacaoView.getCodigoSituacaoReadOnly().equals(CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao().intValue());
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se � usu�rio do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}
	
	@PostMapping(value = "/{seqCotacao}/itens")
	public  ResponseEntity<?> salvaItem(@RequestBody @Valid ItemRelacaoBemView itemRBView, @PathVariable BigInteger seqCotacao) throws ServiceException {
		if(itemRBView.isIncluirParaTodos()){
			List<ItemRelacaoBemView> itensRBView = relacaoBemService.salvaItemRelacaoBemParaTodosItensDaCotacao(itemRBView, seqCotacao);
			return ResponseEntity.ok().body(itensRBView);
		}else{
			itemRBView = relacaoBemService.salvaItemRelacaoBem(itemRBView);
			return ResponseEntity.ok().body(itemRBView);
		}
	}
	
	@DeleteMapping(value = "/{seqCotacao}/itens/{idItemRB}")
	public ResponseEntity<Void> excluirItem(@PathVariable BigInteger idItemRB) {
		relacaoBemService.excluiItemRelacaoBem(idItemRB);
		
		return ResponseEntity.ok().build();
	}

	private List<ItemRelacaoBemView> getItensRelacaoBemView(BigInteger idCotacao) {
		List<ItemRelacaoBem> itens = relacaoBemService.listaItensRelacaoBem(idCotacao);
		List<ItemRelacaoBemView> itensView = itemRBMapper.toListOfItemRelacaoBemView(itens);
		return itensView;
	}
}
