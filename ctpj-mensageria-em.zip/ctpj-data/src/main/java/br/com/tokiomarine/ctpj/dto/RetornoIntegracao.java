package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;
import java.util.List;

import br.com.tokiomarine.ctpj.enums.StatusEnum;

public class RetornoIntegracao implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = -4132315522057180453L;
	private StatusEnum status;
	private List<ValidacaoLote> mensagens;

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}

	public List<ValidacaoLote> getMensagens() {
		return mensagens;
	}

	public void setMensagens(List<ValidacaoLote> mensagens) {
		this.mensagens = mensagens;
	}

	@Override
	public String toString() {
		return "RetornoIntegracao [status=" + status + ", mensagens=" + mensagens + "]";
	}

	public boolean contemMensagem(String mensagem){
		if(mensagens != null && mensagens.size() > 0){
			for(ValidacaoLote m:mensagens){
				if(m.getDescricao().equalsIgnoreCase(mensagem)){
					return true;
				}
			}
		}
		return false;
	}





}
