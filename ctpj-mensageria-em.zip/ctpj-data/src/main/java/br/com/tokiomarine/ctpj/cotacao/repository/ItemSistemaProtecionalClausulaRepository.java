package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecionalClausula;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class ItemSistemaProtecionalClausulaRepository extends BaseDAO{
	
	private static final String EXCLUI_ITEM_SISTEMA_PROTECIONAL_CLAUSULA_POR_COTACAO = 
			"delete from ItemSistemaProtecionalClausula ispc1 " + 
			"where ispc1 in ( " +
					"select ispc2 " +
					"from ItemSistemaProtecionalClausula ispc2 " +
					"where ispc2.itemSistemaProtecional.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao and ispc2.idClausulaAutomatica = :clausulaAutomatica)";
	
	private static final String EXCLUI_ITEM_SITEMA_PROTECIONAL_CLAUSULA_POR_ITEM_COTACAO = 
			"delete from ItemSistemaProtecionalClausula ispc1 " + 
			"where ispc1 in ( " +
					"select ispc2 " +
					"from ItemSistemaProtecionalClausula ispc2 " +
					"where ispc2.itemSistemaProtecional.itemCotacao.sequencialItemCotacao = :seqItemCotacao and ispc2.idClausulaAutomatica = :clausulaAutomatica)";
	
	private static final String BUSCA_ITEM_SISTEMA_PROTECIONAL_CLAUSULA_POR_ITEM_PROTECIONAL_E_CLAUSULA = 
			"select ispc " +
			"from ItemSistemaProtecionalClausula ispc " +
			"where ispc.itemSistemaProtecional.sequencialItemSistemaProtecional = :seqItemSistemaProtecional and ispc.codigoClausula = :codClausula";
	
	
	private static final String BUSCA_ITEM_SISTEMA_PROTECIONAL_POR_ITEM_COTACAO_E_ITEM_SIST_PROTECIONAL_E_CLAUSULA = 
			"select ispc " + 
			"from ItemSistemaProtecionalClausula ispc " +
			"where ispc.itemSistemaProtecional.itemCotacao.sequencialItemCotacao = :seqItemCotacao " +
			"and ispc.itemSistemaProtecional.sequencialItemSistemaProtecional = :seqItemSistemaProtecional " +
			"and ispc.codigoClausula = :codClausula "; 
	
	private static final String BUSCA_ITEM_SISTEMA_PROTECIONAL_POR_COTACAO_E_ITEM_SIST_PROTECIONAL_E_CLAUSULA = 
			"select ispc " + 
			"from ItemSistemaProtecionalClausula ispc " +
			"where ispc.itemSistemaProtecional.itemCotacao.cotacao.sequencialCotacaoProposta = :seqCotacao " +
			"and ispc.itemSistemaProtecional.sequencialItemSistemaProtecional = :seqItemSistemaProtecional " +
			"and ispc.codigoClausula = :codClausula " +
			"and ispc.idClausulaAutomatica = :clausulaAutomatica"; 

	public ItemSistemaProtecionalClausula salva(ItemSistemaProtecionalClausula item){
		getCurrentSession().save(item);
		return item;
	}
	
	public void exclui(ItemSistemaProtecionalClausula item) {
		getCurrentSession().delete(item);
	}
	
	public void exlcluiClausulasManuaisPorCotacao(BigInteger seqCotacao) {
		getCurrentSession()
		.createQuery(EXCLUI_ITEM_SISTEMA_PROTECIONAL_CLAUSULA_POR_COTACAO)
		.setParameter("seqCotacao", seqCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	@LogPerformance
	public void exlcluiClausulasManuaisPorCotacao(Cotacao cotacao) {
		getCurrentSession()
		.createQuery(EXCLUI_ITEM_SISTEMA_PROTECIONAL_CLAUSULA_POR_COTACAO)
		.setParameter("seqCotacao", cotacao.getSequencialCotacaoProposta())
		.setParameter("clausulaAutomatica", SimNaoEnum.SIM)
		.executeUpdate();
	}
	
	public void excluiClausulasManuaisPorItemCotacao(BigInteger seqItemCotacao){
		getCurrentSession()
		.createQuery(EXCLUI_ITEM_SITEMA_PROTECIONAL_CLAUSULA_POR_ITEM_COTACAO)
		.setParameter("seqItemCotacao", seqItemCotacao)
		.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
		.executeUpdate();
	}
	
	public List<ItemSistemaProtecionalClausula> buscaPorItemSistemaProtecionalECodClausula(ItemSistemaProtecional itemSistemaProtecional, Integer codClausula){
		return buscaPorItemSistemaProtecionalECodClausula(itemSistemaProtecional.getSequencialItemSistemaProtecional(), codClausula);
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemSistemaProtecionalClausula> buscaPorItemSistemaProtecionalECodClausula(BigInteger seqItemSistemaProtecinal, Integer codClausula){
		List<ItemSistemaProtecionalClausula> itensSistProtecionalClausula = getCurrentSession()
				.createQuery(BUSCA_ITEM_SISTEMA_PROTECIONAL_CLAUSULA_POR_ITEM_PROTECIONAL_E_CLAUSULA)
				.setParameter("seqItemSistemaProtecional", seqItemSistemaProtecinal).setParameter("codClausula", codClausula)
				.list();
		
		return itensSistProtecionalClausula;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemSistemaProtecionalClausula> buscaPorItemCotacaoEItemSistemaProtecionalEClausula(BigInteger seqItemCotacao, BigInteger seqItemSistemaProtecional, Integer codClausula){
		List<ItemSistemaProtecionalClausula> itensSistProtecionalClausula = getCurrentSession()
				.createQuery(BUSCA_ITEM_SISTEMA_PROTECIONAL_POR_ITEM_COTACAO_E_ITEM_SIST_PROTECIONAL_E_CLAUSULA)
				.setParameter("seqItemCotacao", seqItemCotacao)
				.setParameter("seqItemSistemaProtecional", seqItemSistemaProtecional)
				.setParameter("codClausula", codClausula)
				.list();
		
		return itensSistProtecionalClausula;
	}
	
	@SuppressWarnings("unchecked")
	public List<ItemSistemaProtecionalClausula> buscaClausulasManuaisPorCotacaoEItemSistemaProtecionalEClausula(BigInteger seqCotacao, BigInteger seqItemSistemaProtecional, Integer codClausula){
		List<ItemSistemaProtecionalClausula> itensSistProtecionalClausula = getCurrentSession()
				.createQuery(BUSCA_ITEM_SISTEMA_PROTECIONAL_POR_COTACAO_E_ITEM_SIST_PROTECIONAL_E_CLAUSULA)
				.setParameter("seqCotacao", seqCotacao)
				.setParameter("seqItemSistemaProtecional", seqItemSistemaProtecional)
				.setParameter("codClausula", codClausula)
				.setParameter("clausulaAutomatica", SimNaoEnum.NAO)
				.list();
		
		return itensSistProtecionalClausula;
	}
	
	public boolean existeClausulaParaItemSistemaProtecionalEClausula(ItemSistemaProtecional itemSistemaProtecional, Integer codClausula){
		return !buscaPorItemSistemaProtecionalECodClausula(itemSistemaProtecional, codClausula).isEmpty();
	}
	
	public boolean existeClausulaParaItemSistemaProtecionalEClausula(BigInteger seqItemSistemaProtecinal, Integer codClausula){
		return !buscaPorItemSistemaProtecionalECodClausula(seqItemSistemaProtecinal, codClausula).isEmpty();
	}
	
	public boolean existeClausulaParaItemCotacaoEItemSistemaProtecionalEClausula(BigInteger seqItemCotacao, BigInteger seqItemSistemaProtecional, Integer codClausula){
		return !buscaPorItemCotacaoEItemSistemaProtecionalEClausula(seqItemCotacao, seqItemSistemaProtecional, codClausula).isEmpty();
	}

}
