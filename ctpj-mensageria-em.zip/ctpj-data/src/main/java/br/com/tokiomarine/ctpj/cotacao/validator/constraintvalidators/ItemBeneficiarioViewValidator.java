package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.math.BigInteger;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.ItemBeneficiarioViewValido;

/**
 * Validador para o dto ItemBeneficiarioView
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class ItemBeneficiarioViewValidator implements ConstraintValidator<ItemBeneficiarioViewValido, ItemBeneficiarioView> {

	@Override
	public void initialize(ItemBeneficiarioViewValido constraintAnnotation) {
				
	}

	@Override
	public boolean isValid(ItemBeneficiarioView itemView, ConstraintValidatorContext constraintValidatorContext) {
		BigInteger numeroItemCotacao = itemView.getNumeroItemCotacao();
		constraintValidatorContext.disableDefaultConstraintViolation();	
		
		if(!numeroItemCotacaoFornecido(itemView, constraintValidatorContext))
			return false;
		
		boolean itemCotacaoValido = validaItemCotacao(numeroItemCotacao , itemView, constraintValidatorContext);
		boolean nomePessoaValido = validaNomePessoa(numeroItemCotacao, itemView, constraintValidatorContext);
		boolean descricaoComplementoValido = validaDescricaoComplemento(numeroItemCotacao, itemView, constraintValidatorContext);
		
		return itemCotacaoValido && nomePessoaValido && descricaoComplementoValido;
	}
	
	private boolean numeroItemCotacaoFornecido(ItemBeneficiarioView itemView, ConstraintValidatorContext constraintValidatorContext){
		if(itemView.getNumeroItemCotacao() == null){
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("O número do item da cotação é obrigatório")
			.addConstraintViolation();
			
			return false;
		}
		
		return true;
	}
	
	private boolean validaItemCotacao(BigInteger numeroItemCotacao, ItemBeneficiarioView itemView, ConstraintValidatorContext constraintValidatorContext){
		if(itemView.getItemCotacao() == null){			
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao + " - Item da Cotação é obrigatório")
			.addConstraintViolation();
			
			return false;
		}		
		
		return true;
	}
	
	private boolean validaNomePessoa(BigInteger numeroItemCotacao, ItemBeneficiarioView itemView, ConstraintValidatorContext constraintValidatorContext){
		String nomePessoa = itemView.getNomePessoa();
		if(nomePessoa == null || nomePessoa.trim().length() == 0){
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao + " - Nome da Pessoa é obrigatório")
			.addConstraintViolation();
			
			return false;
		}
		
		if(nomePessoa.length() > 300){
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao + " - Nome da Pessoa deve possuir no máximo 300 caracteres")
			.addConstraintViolation();
			
			return false;
		}
		
		return true;
	}
	
	private boolean validaDescricaoComplemento(BigInteger numeroItemCotacao, ItemBeneficiarioView itemView, ConstraintValidatorContext constraintValidatorContext){
		String descricaoComplemento = itemView.getDescricaoComplemento();
		
		if(descricaoComplemento != null && descricaoComplemento.length() > 2000){
			constraintValidatorContext
			.buildConstraintViolationWithTemplate("Item " + numeroItemCotacao + " - Complemento deve possuir no máximo 2000 caracteres")
			.addConstraintViolation();
			
			return false;
		}
		
		
		return true;
	}

}
