package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCrivoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCrivo;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;

@Service
@Transactional
public class ItemCrivoService {

	private static Logger logger = LogManager.getLogger(ItemCrivoService.class);

	@Autowired
	private ItemCrivoRepository repository;

	@LogPerformance
	public void saveAll(List<ItemCrivo> itensCrivo) throws ServiceException {
		logger.info("Salvando Itens do Crivo....");
		try {
			for (ItemCrivo itemCrivo : itensCrivo) {
				itemCrivo.setDataAtualizacao(Calendar.getInstance().getTime());
				itemCrivo.getItemCotacao().getListItemCrivo().add(itemCrivo);
				if (itemCrivo.getSequencialItemCrivo()==null){
					repository.save(itemCrivo);
				}else{
					repository.update(itemCrivo);
				}
			}
		} catch (HibernateException h) {
			logger.error("Erro ao Gravar Itens do Crivo");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Gravar Item do Crivo");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public int deleteByItemCotacao(ItemCrivo itemCrivo) throws ServiceException {
		int countDelete = 0;
		try {
			countDelete = repository.deleteItemCrivo(itemCrivo.getSequencialItemCrivo());
		} catch (HibernateException h) {
			logger.error("Erro ao Exlcuir Item do Crivo");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Excluir Item do Crivo");
			throw new ServiceException(e.getMessage(),e);
		}
		return countDelete;
	}

	@LogPerformance
	public ItemCrivo save(ItemCrivo itemCrivo) throws ServiceException {
		logger.info("Salvando Item do Crivo....");
		try {
			itemCrivo.setDataAtualizacao(Calendar.getInstance().getTime());
			return repository.save(itemCrivo);
		} catch (HibernateException h) {
			logger.error("Erro ao Gravar Item do Crivo");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Gravar Item do Crivo");
			throw new ServiceException(e.getMessage(),e);
		}
	}


	@LogPerformance
	public ItemCrivo findItemCrivoBySequencialItem(BigInteger sequencialItemCotacao) throws ServiceException {
		logger.info("Salvando Itens do Crivo....");
		try {
			return repository.findItemCrivoByItemCotacao(sequencialItemCotacao);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar Item Crivo");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao buscar Item Crivo.");
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public List<ItemCrivo> findItemsCrivoBySequencialItem(List<BigInteger> itens) throws ServiceException {
		logger.info("Salvando Itens do Crivo....");
		try {
			return repository.findItemsCrivoByItemCotacao(itens);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar Item Crivo");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao buscar Item Crivo.");
			throw new ServiceException(e.getMessage(),e);
		}
	}

}
