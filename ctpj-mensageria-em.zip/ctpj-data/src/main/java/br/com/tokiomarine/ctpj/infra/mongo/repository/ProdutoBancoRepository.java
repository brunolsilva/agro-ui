package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.FormaPagamentoBanco;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.Banco;
import br.com.tokiomarine.ctpj.infra.domain.BancoFormaPagamentoCorretor;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialBanco;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoBanco;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Repository
public class ProdutoBancoRepository {

	private static Logger logger = LogManager.getLogger(ProdutoBancoRepository.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	@LogPerformance
	public List<FormaPagamentoBanco> findProdutoBanco(Long corretor, Integer produto, Date dataCalculo, Integer destinoEmissao) throws RepositoryException {
		return findProdutoBanco(null,corretor,produto,dataCalculo,destinoEmissao);
	}

	@LogPerformance
	public List<FormaPagamentoBanco> findProdutoBanco(Long perfilComercial, Long corretor, Integer produto,Date dataCalculo,
			Integer destinoEmissao) throws RepositoryException {
		try {
			Query q = query(
					where("produto").is(produto)
					.and("dataInicioVigencia").lte(new Date())
					.orOperator(
							where("dataTerminoVigencia").gte(new Date()),
							where("dataTerminoVigencia").is(null)));

			List<ProdutoBanco> pbs = mongoTemplate.find(q, ProdutoBanco.class);
			
			List<PB> pbEncontrados = new ArrayList<>();
			
			pbs.forEach(it -> {
				System.out.println(">>>> " + it.getBanco() + " - " + it.getFormaPagamento());
			});

			for(ProdutoBanco pb: pbs
					.stream()
					.filter(p->FormaPagamentoEnum.getByCodigo(p.getFormaPagamento()) == FormaPagamentoEnum.DEBITO_EM_CONTA ||
							FormaPagamentoEnum.getByCodigo(p.getFormaPagamento()) == FormaPagamentoEnum.CARTAO_DE_CREDITO ||
							(FormaPagamentoEnum.getByCodigo(p.getFormaPagamento()) == FormaPagamentoEnum.CARNE && p.getBancoPadraoBoleto() == SimNaoEnum.SIM))
					.collect(Collectors.toList())) {
				if(destinoEmissao.equals(pb.getSistema()) || pb.getSistema() == null) {
					pbEncontrados.add(new PB(pb.getBanco(), pb.getFormaPagamento()));
				}
			}

			q = query(
					where("corretor").is(corretor)
					.and("dataInicioVigencia").lte(new Date())
					.orOperator(
							where("dataTerminoVigencia").gte(new Date()),
							where("dataTerminoVigencia").is(null)));
			q.fields().include("formaPagamento").include("banco").include("bancoPadraoBoleto");
			
			List<BancoFormaPagamentoCorretor> listBfpc = mongoTemplate.find(q, BancoFormaPagamentoCorretor.class); 
			
			for(BancoFormaPagamentoCorretor bfpCc: listBfpc) {
				System.out.println(">>>> " + bfpCc.getBanco() + " - " + bfpCc.getFormaPagamento());
				pbEncontrados.add(new PB(bfpCc.getBanco(), bfpCc.getFormaPagamento()));
			}

			Set<Long> cdBancos = pbEncontrados.stream().map(PB::getBanco).collect(Collectors.toSet());

			List<PerfilComercialBanco> pcb = findPerfilComercialBanco(perfilComercial, cdBancos, dataCalculo);

			List<Banco> bancos = mongoTemplate.find(
					query(
							where("banco")
								.in(cdBancos)
								.and("ativo").is(SimNaoEnum.SIM)),
					Banco.class);

			Map<Long,Banco> mapBanco = bancos.stream().collect(Collectors.toMap(Banco::getCodigo, Function.identity()));

			List<FormaPagamentoBanco> formasPagamentoBanco = new ArrayList<>();
			
			System.out.println("cdBancos " + cdBancos);

			if(!pcb.isEmpty()) {
				for(PerfilComercialBanco p: pcb) {
					for(PB pb: pbEncontrados) {
						if(p.getBanco().equals(pb.getBanco())
								&& p.getFormaPagamento().equals(pb.getFormaPagamento())
								&& mapBanco.containsKey(p.getBanco())
								&& mapBanco.get(p.getBanco()).getAtivo() == SimNaoEnum.SIM) {
							formasPagamentoBanco.add(new FormaPagamentoBanco(p.getBanco(),mapBanco.get(p.getBanco()).getDescricao(),p.getFormaPagamento()));
						}
					}
				}
			} else {
				for(PB pb: pbEncontrados) {
					if(mapBanco.containsKey(pb.getBanco()) && mapBanco.get(pb.getBanco()).getAtivo() == SimNaoEnum.SIM) {
						formasPagamentoBanco.add(new FormaPagamentoBanco(pb.getBanco(),mapBanco.get(pb.getBanco()).getDescricao(),pb.getFormaPagamento()));
					}
				}
			}

			return formasPagamentoBanco;
		} catch (Exception e) {
			logger.error("Erro ao buscar o BancoProduto ", e);
			throw new RepositoryException(e.getMessage(), e);
		}
	}

	public ProdutoBanco findBancoWS(Integer produto,FormaPagamentoEnum formaPagamento) {
		return mongoTemplate.findOne(
				query(
						where("produto").is(produto)
						.and("formaPagamento").is(formaPagamento.getCodigo())
						.and("dataInicioVigencia").lte(new Date())
						.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))),
				ProdutoBanco.class);
	}

	private List<PerfilComercialBanco> findPerfilComercialBanco(Long perfilComercial, Set<Long> cdBancos, Date dataCalculo) {
		if(perfilComercial != null) {
			return mongoTemplate.find(
					query(
							where("banco").in(cdBancos)
							.and("perfilComercial").is(perfilComercial)
							.and("dataInicioVigencia").lte(dataCalculo)
							.orOperator(
									where("dataTerminoVigencia").gte(dataCalculo),
									where("dataTerminoVigencia").is(null))),
					PerfilComercialBanco.class);
		}

		return Collections.<PerfilComercialBanco>emptyList();
	}

	private static class PB {
		private Long banco;
		private Integer formaPagamento;
		
		public PB(Long banco,Integer formaPagamento) {
			this.banco = banco;
			this.setFormaPagamento(formaPagamento);
		}

		public Long getBanco() {
			return banco;
		}

		public Integer getFormaPagamento() {
			return formaPagamento;
		}

		public void setFormaPagamento(Integer formaPagamento) {
			this.formaPagamento = formaPagamento;
		}
	}
}