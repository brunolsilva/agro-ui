package br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * Responsável pela formatação dos valores Percentuais
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class FormatadorPercentualRelatorio {
	
	private static final NumberFormat PERCENT_FORMATTER = new DecimalFormat("#,###,##0.00000");
		
	/**
	 * Formata um valor como porcentagem
	 * 
	 * @param value Valor a ser formatado
	 * @param replace Valor default usado para os casos onde o valor é null
	 * @return O valor formatado como monetário ou o replace para os casos onde o valor é null
	 */
	public String asPercent(BigDecimal value, String replace){
		if(value == null)
			return replace;
		
		return PERCENT_FORMATTER.format(value);
	}
	
	/**
	 * Formata um valor como porcentagem
	 * 
	 * @param value Valor a ser formatado
	 * @return O valor formatado como monetário ou uma String vazia ("") para os casos onde o valor é null
	 */
	public String asPercent(BigDecimal value){
		return asPercent(value, "");
	}
}
