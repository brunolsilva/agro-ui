package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilCalculoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilComercialRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.domain.CoberturaAgrupamentoRestricao;
import br.com.tokiomarine.ctpj.infra.domain.CoberturaPeriodoIndenitario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCobertura;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCobertura;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracValorAtributo;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCobertura;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoMultiplo;
import br.com.tokiomarine.ctpj.infra.enums.TipoISEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Repository
public class CoberturaRepository {

	private static final int COBERTURA_BASICA = 1;
	private static final int COBERTURA_ADICIONAL = 2;
	private static final int COBERTURA_ESPECIAL = 3;
	private static final int COBERTURA_ESPECIAL_DA_ESPECIAL = 4;

	private static final Logger logger = LogManager.getLogger(CoberturaRepository.class);

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private PerfilComercialRepository perfilComercialRepository;
	
	@Autowired
	private PerfilCalculoRepository perfilCalculoRepository;
	
	@Autowired
	private ProdutoCaracValorAtributoRepository produtoCaracValorAtributoRepository;
	
	//@Cacheable("coberturasAdicionais")
	public List<Cobertura> findCoberturasAdicionais(boolean isEndosso) {
		Query query = new Query();
		query.addCriteria(where("tipo").ne(COBERTURA_BASICA));

		if(!isEndosso) {
			query.addCriteria(where("inativo").is(false));
		}
		return mongoTemplate.find(query, Cobertura.class);		
	}
	
	//@Cacheable("coberturasBasicas")
	public List<Cobertura> findCoberturasBasicas() {
		return mongoTemplate.find(
				query(
						where("tipo").is(COBERTURA_BASICA)
						.and("inativo").is(false)
						), Cobertura.class);	
	}

	@LogPerformance
	public List<Cobertura> findCoberturasBasicas(CotacaoView cotacao,List<Cobertura> coberturas) {
		if(SecurityUtils.isCorretor()) {
			coberturas = findCoberturasPorPerfil(cotacao, coberturas, new ArrayList<>());
		} else {
			List<ProdutoCobertura> produtosCobertura = findProdutosCobertura(cotacao, coberturas.stream().map(Cobertura::getCodigo).collect(Collectors.toList()));
			List<Integer> codigosProdutoCobertura = produtosCobertura.stream()
					.map(ProdutoCobertura::getCobertura)
					.collect(Collectors.toList()); 

			coberturas = coberturas.stream()
					.filter(c -> codigosProdutoCobertura.contains(c.getCodigo()))
					.collect(Collectors.toList());
		}

		return coberturas;
	}

	@LogPerformance
	public Map<Integer,List<CoberturaHierarquiaView>> findCoberturasAdicionaisDMView(CotacaoView cotacao, List<Integer> coberturasPrincipais, List<Cobertura> coberturas) {
		return this.findCoberturasAdicionaisDMView(cotacao, coberturasPrincipais, coberturas,null);
	}
	
	@LogPerformance
	public Map<Integer,List<CoberturaHierarquiaView>> findCoberturasAdicionaisDMView(
			CotacaoView cotacao, List<Integer> coberturasPrincipais,
			List<Cobertura> coberturas,
			Map<Integer, List<ProdutoCaracValorAtributo>> produtoCaracValorList) {
		Map<Integer, List<CoberturaHierarquiaView>> hierarquia = new HashMap<>();

		if(SecurityUtils.isCorretor()) {
			List<ProdutoCobertura> produtosCobertura = new ArrayList<>();
			List<Cobertura> coberturasDoPerfil = findCoberturasPorPerfil(cotacao, coberturas, produtosCobertura);
			montaHierarquia(coberturasPrincipais, hierarquia, produtosCobertura, coberturasDoPerfil,produtoCaracValorList);
		} else {
			List<ProdutoCobertura> produtosCobertura = findProdutosCobertura(cotacao, coberturas.stream().map(Cobertura::getCodigo).collect(Collectors.toList()));
			montaHierarquia(coberturasPrincipais, hierarquia, produtosCobertura, coberturas,produtoCaracValorList);
		}

		return hierarquia;
	}

	/**
	 * Monta um map com (coberturaBasica, List<Cobertura> adicionais)
	 * 
	 * @param coberturasPrincipais
	 * @param hierarquia
	 * @param produtosCobertura
	 * @param coberturasDoPerfil
	 */
	private void montaHierarquia(List<Integer> coberturasPrincipais,
			Map<Integer, List<CoberturaHierarquiaView>> hierarquia, List<ProdutoCobertura> produtosCobertura,
			List<Cobertura> coberturasDoPerfil,Map<Integer, List<ProdutoCaracValorAtributo>> caracs) {

		for(Integer coberturaPrincipal: coberturasPrincipais) {
			List<CoberturaHierarquiaView> listaHierarquia = new ArrayList<>();
			List<Integer> listaCoberturas = new ArrayList<>();
			
			List<Integer> codigosProdutoCobertura = produtosCobertura.stream()
					.map(ProdutoCobertura::getCobertura)
					.collect(Collectors.toList());

			// 0 adicional, 1 especial, 2 especial da especial
			Set<Integer> parents = new HashSet<>();

			for(int i = 0; i < 3; i++) {

				if(i == 0) {
					parents.add(coberturaPrincipal);
				}

				List<ProdutoCobertura> relacionamentos = produtosCobertura.stream()
						.filter(c -> parents.contains(c.getCoberturaPrincipal()))
						.collect(Collectors.toList());
				
				List<Integer> atuais = relacionamentos.stream()
						.map(ProdutoCobertura::getCobertura)
						.collect(Collectors.toList());
				
				listaCoberturas.addAll(atuais);
				
				parents.clear();
				parents.addAll(relacionamentos.stream()
						.map(ProdutoCobertura::getCobertura)
						.collect(Collectors.toList()));
				
				listaHierarquia.addAll(coberturasDoPerfil.stream()
						.filter(c -> codigosProdutoCobertura.contains(c.getCodigo()) && atuais.contains(c.getCodigo()))
						.map(cobertura -> new CoberturaHierarquiaView(cobertura.getCodigo(),null,cobertura.getDescricao(),cobertura.getIdVagasGaragem().getLogical(),cobertura.getTipo()))
						.collect(Collectors.toList()));

				//indica se a lista possui registros
				boolean listaProdutoCaracValorCarregada = caracs != null && !caracs.isEmpty();
				
				for(CoberturaHierarquiaView cobHierarquia: listaHierarquia) {
					List<Integer> pais = new ArrayList<>();
					for(ProdutoCobertura relacionamento: relacionamentos) {
						if(relacionamento.getCobertura().equals(cobHierarquia.getCodigoCobertura())) {
							pais.add(relacionamento.getCoberturaPrincipal());
							cobHierarquia.setCoberturaPai(pais);
						}
					}
					
					//verifica se a lista de rubrica x cobertura possui registros
					if(listaProdutoCaracValorCarregada){
						if(caracs.containsKey(cobHierarquia.getCodigoCobertura())) {
							cobHierarquia.setRubricasLiberadas(caracs.get(cobHierarquia.getCodigoCobertura()).stream()
									.map(ProdutoCaracValorAtributo::getValorCaracteristica)
									.collect(Collectors.toList()));
						}
					}
				}
			}

			listaHierarquia.sort(Comparator.comparing(CoberturaHierarquiaView::getTipo)
					.thenComparing(Comparator.comparing(CoberturaHierarquiaView::getDescricao)));

			hierarquia.put(coberturaPrincipal, listaHierarquia);
		}
	}

	public Cobertura findCobertura(Integer codigo) {
		return mongoTemplate.findOne(
				query(
						where("codigo").is(codigo)), Cobertura.class);
	}

	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura) {
		return mongoTemplate.findOne(
				query(
						where("produto").is(codigoProduto)
							.and("cobertura").is(codigoCobertura)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCobertura.class);
	}

	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura, Integer coberturaPrincipal) {
		return mongoTemplate.findOne(
				query(
						where("produto").is(codigoProduto)
							.and("cobertura").is(codigoCobertura)
							.and("coberturaPrincipal").is(coberturaPrincipal)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCobertura.class);
	}
	
	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura, Date data) {
		return mongoTemplate.findOne(
				query(
						where("produto").is(codigoProduto)
							.and("cobertura").is(codigoCobertura)
							.and("dataInicioVigencia").lte(data)
							.orOperator(
									where("dataTerminoVigencia").gte(data),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCobertura.class);
	}

	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura, Integer coberturaPrincipal, Date data) {
		return mongoTemplate.findOne(
				query(
						where("produto").is(codigoProduto)
							.and("cobertura").is(codigoCobertura)
							.and("coberturaPrincipal").is(coberturaPrincipal)
							.and("dataInicioVigencia").lte(data)
							.orOperator(
									where("dataTerminoVigencia").gte(data),
									where("dataTerminoVigencia").is(null))
				) , ProdutoCobertura.class);
	}

	public List<ProdutoCobertura> findProdutoCobertura(Integer codigoProduto, List<Integer> codigosCobertura) {
		return mongoTemplate.find(
				query(
						where("produto").is(codigoProduto)
							.and("cobertura").in(codigosCobertura)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))
				),ProdutoCobertura.class);
	}
	
	public List<ProdutoCobertura> findProdutoCobertura(Integer codigoProduto, List<Integer> codigosCobertura, Integer coberturaPrincipal) {
		return mongoTemplate.find(
				query(
						where("produto").is(codigoProduto)
							.and("cobertura").in(codigosCobertura)
							.and("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null),
									where("coberturaPrincipal").is(null),
									where("coberturaPrincipal").is(coberturaPrincipal))
				),ProdutoCobertura.class);
	}

	public List<Integer> getPeriodosIndenitarios(Integer produto, Integer cobertura, Date dataCotacao) {
		List<CoberturaPeriodoIndenitario> periodos = mongoTemplate.find(
				query(
						where("cobertura").in(cobertura)
						.and("produto").is(produto)
						.and("dataInicioVigencia").lte(dataCotacao)
						.orOperator(
								where("dataTerminoVigencia").gte(dataCotacao),
								where("dataTerminoVigencia").is(null))
				), CoberturaPeriodoIndenitario.class);

		if(SecurityUtils.isCorretor()) {
			return periodos.stream()
					.map(CoberturaPeriodoIndenitario::getPeriodoIndenitario)
					.filter(val -> val <= 12)
					.collect(Collectors.toList());
		} else {
			return periodos.stream()
					.map(CoberturaPeriodoIndenitario::getPeriodoIndenitario)
					.collect(Collectors.toList());
		}
	}

	public Map<String, List<BigDecimal>> getMultiplosFranquiaPrejuizo(Integer produto, Integer cobertura, Date dataCotacao) {
		List<ProdutoMultiplo> multiplos = mongoTemplate.find(
				query(
						where("cobertura").in(cobertura)
						.and("produto").is(produto)
						.and("dataInicioVigencia").lte(dataCotacao)
						.orOperator(
								where("dataTerminoVigencia").gte(dataCotacao),
								where("dataTerminoVigencia").is(null))
				), ProdutoMultiplo.class);

		List<BigDecimal> multiplosFranquia = multiplos.stream()
				.filter(m -> m.getMultiploFranquia() != null)
				.map(ProdutoMultiplo::getMultiploFranquia)
				.collect(Collectors.toList());

		List<BigDecimal> multiplosPrejuizo = multiplos.stream()
				.filter(m -> m.getMultiploPrejuizo() != null)
				.map(ProdutoMultiplo::getMultiploPrejuizo)
				.collect(Collectors.toList());
		
		Collections.sort(multiplosFranquia);
		Collections.sort(multiplosPrejuizo);

		Map<String, List<BigDecimal>> multiplosMap = new HashMap<>();
		multiplosMap.put("multiplosFranquia", multiplosFranquia);
		multiplosMap.put("multiplosPrejuizo", multiplosPrejuizo);

		return multiplosMap;
	}
	
	public Cobertura findByCodigo(Integer codigo){
		Query query = query(where("codigo").is(codigo));
		Cobertura cobertura = mongoTemplate.findOne(query, Cobertura.class);
		
		return cobertura;
	}
	
	public String getDescricaoByCodigo(Integer codigo){
		Query query = query(where("codigo").is(codigo));
		
		Cobertura cobertura = mongoTemplate.findOne(query, Cobertura.class);
		
		return cobertura != null ? cobertura.getDescricao() : null;
	}

	@LogPerformance
	public List<ProdutoCobertura> findParents(ProdutoCobertura produtoCobertura, Date dataCotacao) {//4
		Integer firstParent = produtoCobertura.getCoberturaPrincipal();//3
		List<ProdutoCobertura> parents = new ArrayList<>();
		if(firstParent != null) {
			for(int i = 0; i < 3; i++) {
				ProdutoCobertura parent = mongoTemplate.findOne(
						query(
								where("produto").is(produtoCobertura.getProduto())
								.and("cobertura").is(firstParent)
								.and("dataInicioVigencia").lte(dataCotacao)
								.orOperator(
										where("dataTerminoVigencia").gte(dataCotacao),
										where("dataTerminoVigencia").is(null))
						), ProdutoCobertura.class);

				parents.add(parent);

				if(parent.getCoberturaPrincipal() != null) {
					firstParent = parent.getCoberturaPrincipal();
				} else {
					break;
				}
			}
		}

		return parents;
	}

	public Map<Integer,Object> getExigeValorRisco(Integer produto, Integer cobertura, Date dataCotacao, Integer coberturaPrincipal) {
		Map<Integer,Object> map = new HashMap<>();
		ProdutoCobertura produtoCobertura = mongoTemplate.findOne(
				query(
						where("produto").is(produto)
						.and("cobertura").is(cobertura)
						.and("dataInicioVigencia").lte(dataCotacao)
						.and("coberturaPrincipal").is(coberturaPrincipal)
						.orOperator(
								where("dataTerminoVigencia").gte(dataCotacao),
								where("dataTerminoVigencia").is(null))
				), ProdutoCobertura.class);
		if(produtoCobertura != null) {
			map.put(2, produtoCobertura.getExigeValorRisco() != null ? produtoCobertura.getExigeValorRisco().getLogical() : false);
			map.put(4, produtoCobertura.getTipoIS() == TipoISEnum.INFORMADA_PELO_USUARIO ? true : false);
			map.put(5, produtoCobertura.getLmr() != null ? produtoCobertura.getLmr().getLogical() : false);
		}

		return map;
	}

	public boolean getExigeVagasGaragem(Integer cobertura) {
		Cobertura c = mongoTemplate.findOne(
				query(
						where("codigo").is(cobertura)),
				Cobertura.class);
		if(c == null) {
			return false;
		}
		return c.getIdVagasGaragem() != null ? c.getIdVagasGaragem().getLogical(): false;
	}
	
	/**
	 * <p>Retorna as coberturas para o determinado perfil.</p>
	 * 
	 * <p>Primeiro busca PerfilComercialCobertura, se este não existe, procura no PerfilCalculoCobertura.</p>
	 * 
	 * @param cotacao
	 * @param coberturas
	 * @return A lista com as coberturas desse perfil
	 */
	private List<Cobertura> findCoberturasPorPerfil(CotacaoView cotacao, List<Cobertura> coberturas, List<ProdutoCobertura> produtosCobertura) {
		
		List<Integer> coberturasDoPerfil;
		
		List<PerfilComercialCobertura> perfilComercialCoberturas = perfilComercialRepository.findPerfilComercialCobertura(
				SecurityUtils.getCurrentUser().getCdUsuro().longValue(),
				cotacao.getCodigoProduto(),
				cotacao.getDataCotacao());
		
		if(!perfilComercialCoberturas.isEmpty()) {
			coberturasDoPerfil = perfilComercialCoberturas.stream().map(PerfilComercialCobertura::getCobertura).collect(Collectors.toList());
		} else {
			List<PerfilCalculoCobertura> perfilCalculoCoberturas = perfilCalculoRepository.findPerfilCalculoCobertura(
					SecurityUtils.getCurrentUser().getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			coberturasDoPerfil = perfilCalculoCoberturas.stream().map(PerfilCalculoCobertura::getCobertura).collect(Collectors.toList());
		}
		
		produtosCobertura.addAll(findProdutosCobertura(cotacao, coberturasDoPerfil));

		List<Integer> codigosProdutoCobertura = produtosCobertura.stream()
				.map(ProdutoCobertura::getCobertura)
				.collect(Collectors.toList());

		coberturas = coberturas.stream()
				.filter(c -> codigosProdutoCobertura.contains(c.getCodigo()))
				.collect(Collectors.toList());

		return coberturas;
	}

	public List<Cobertura> findCoberturasPorPerfilWS(Integer produto, List<Integer> coberturasLiberadas, Long corretor) {

		List<Integer> coberturasDoPerfil;

		List<PerfilComercialCobertura> perfilComercialCoberturas = perfilComercialRepository.findPerfilComercialCobertura(
				corretor,
				produto,
				new Date());

		if(!perfilComercialCoberturas.isEmpty()) {
			coberturasDoPerfil = perfilComercialCoberturas.stream().map(PerfilComercialCobertura::getCobertura).collect(Collectors.toList());
		} else {
			List<PerfilCalculoCobertura> perfilCalculoCoberturas = perfilCalculoRepository.findPerfilCalculoCobertura(
					corretor,
					produto,
					new Date());
			coberturasDoPerfil = perfilCalculoCoberturas.stream().map(PerfilCalculoCobertura::getCobertura).collect(Collectors.toList());
		}
		List<Integer> codigos = new ArrayList<>();
		for(Integer cobertura: coberturasDoPerfil) {
			for(Integer coberturaLiberada: coberturasLiberadas) {
				if(cobertura.equals(coberturaLiberada)) {
					codigos.add(cobertura);
				}
			}
		}

		return mongoTemplate.find(
				query(
						where("codigo").in(codigos)
						.and("inativo").is(false)
						), Cobertura.class);	
	}

	public List<String> coberturasWS(Integer produto, Long bemCoberto, Long rubrica) {
		List<Integer> coberturas = produtoCaracValorAtributoRepository.findProdutoCaracByValor(produto,rubrica);
		if(coberturas != null && coberturas.isEmpty()) {
			
		}
		return Collections.emptyList();
	}

	/**
	 * Recuperar a lista de ProdutoCobertura das coberturas passadas, usando a dataCotacao + produto
	 * 
	 * @param cotacao
	 * @param coberturas
	 * @return uma lista com ProdutoCobertura daquelas coberturas naquele produto
	 */
	public List<ProdutoCobertura> findProdutosCobertura(CotacaoView cotacao, List<Integer> coberturas) {
		Date dataBusca = cotacao.getCodigoTipoEndossoSCT() != null ? cotacao.getDataInicioVigencia() : new Date();
		return mongoTemplate.find(
				query(
						where("produto").is(cotacao.getCodigoProduto())
						.and("dataInicioVigencia").lte(dataBusca)
						.and("cobertura").in(coberturas)
						.orOperator(
								where("dataTerminoVigencia").gte(dataBusca),
								where("dataTerminoVigencia").is(null))
						), ProdutoCobertura.class);
	}

	public List<CoberturaAgrupamentoRestricao> findAgrupamentosRestricaoPorProduto(Cotacao cotacao) {
		return mongoTemplate.find(
				query(
						where("produto").is(cotacao.getCodigoProduto())
						.and("dataInicioVigencia").lte(cotacao.getDataCotacao())
						.orOperator(
								where("dataTerminoVigencia").gte(cotacao.getDataCotacao()),
								where("dataTerminoVigencia").is(null))
						), CoberturaAgrupamentoRestricao.class);
	}
}