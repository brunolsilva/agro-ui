package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.repository.CosseguradoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;

/**
 * Serviço contendo regras e lógicas de negócio para entidade ItemCosseguro
 * 
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Service
@Transactional(rollbackFor=Exception.class)
public class CosseguradoService {

	@Autowired
	private CosseguradoRepository cosseguradoRepository;
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	/**
	 * Inclui um novo item cossegurado para a Cotação
	 * 
	 * @param itemCossegurado
	 * @return ItemCossegurado contendo o id recém criado
	 */
	public ItemCossegurado incluiItemCossegurado(ItemCossegurado itemCossegurado) {
		return cosseguradoRepository.salvaItemCossegurado(itemCossegurado);
	}
	
	/**
	 * Inclui um item cossegurado para todos os itens de uma dada cotação
	 * 
	 * @param itemCossegurado ItemCossegurado que será incluído para todos os itens de uma dada cotação
	 * @param cotacao Cotação para a qual os itens cosseguros serão incluídos nos itens da cotação
	 * @return Lista contendo os itens cossegurados atualizados com o id recém criado
	 * @throws ServiceException
	 */
	public List<ItemCossegurado> incluiItemCosseguradoParaTodosItensDaCotacao(ItemCossegurado itemCossegurado, Cotacao cotacao) throws ServiceException {
		return incluiItemCosseguradoParaTodosItensDaCotacao(itemCossegurado, cotacao.getSequencialCotacaoProposta());
	}

	/**
	 * Inclui um item cossegurado para todos os itens de uma dada cotação
	 * 
	 * @param itemCossegurado ItemCossegurado que será incluído para todos os itens de uma dada cotação
	 * @param sequencialCotacaoProposta Identificação da cotação para a qual os itens cosseguros serão incluídos nos itens da cotação
	 * @return Lista contendo os itens cossegurados atualizados com o id recém criado
	 * @throws ServiceException
	 */
	public List<ItemCossegurado> incluiItemCosseguradoParaTodosItensDaCotacao(ItemCossegurado itemCossegurado, BigInteger sequencialCotacaoProposta) throws ServiceException {
		List<ItemCotacao> itensCotacao;
		try {
			itensCotacao = cotacaoRepository.getItemsComEndereco(sequencialCotacaoProposta);
		} catch (RepositoryException e) {
			throw new ServiceException(e);
		}
		
		List<ItemCossegurado> itensCossegurados = new ArrayList<>();
		
		for(ItemCotacao ic : itensCotacao){
			if(ic.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || Arrays.asList(1,6).contains(ic.getIdTipoEndosso())) {
				ItemCossegurado itemCsg = new ItemCossegurado();
				BeanUtils.copyProperties(itemCossegurado, itemCsg);
				BigInteger nroCossegurado = cosseguradoRepository.proximoNroCossegurado(sequencialCotacaoProposta);
				
				itemCsg.setNumeroCossegurado(nroCossegurado);
				itemCsg.setItemCotacao(ic);
				
				cosseguradoRepository.salvaItemCossegurado(itemCsg);	
				
				itensCossegurados.add(itemCsg);
			}
		}

		return itensCossegurados;
	}	
	
	/**
	 * Exclui um ItemCossegurado pertecente a uma dada Cotação
	 * 
	 * @param sequencialItemCossegurado identificador do ItemCossegurado
	 */
	public void excluiItemCossegurado(BigInteger sequencialItemCossegurado){
		cosseguradoRepository.excluiItemCossegurado(sequencialItemCossegurado);
	}

	/**
	 * Lista os ItensCossegurados pertecentes a uma dada Cotação
	 * 
	 * @param sequencialCotacaoProposta identificador da Cotação
	 * @return Uma Lista contendo os ItensCossegurados. A lista será vazia caso não seja encontrados itens para o sequencialCotacaoProposta fornecido
	 */
	public List<ItemCossegurado> listaItensCosseguradoPorCotacao(BigInteger sequencialCotacaoProposta){
		return cosseguradoRepository.listaItensCosseguradoPorCotacao(sequencialCotacaoProposta);
	}
	
	public List<ItemCossegurado> salvaItemCossegurado(BigInteger seqCotacao, List<ItemCossegurado> itens){
		cosseguradoRepository.excluiItemCosseguradoPorCotacao(seqCotacao);
		if(!itens.isEmpty()) {
			cosseguradoRepository.salvaItemCossegurado(itens);
		}
		return itens;
	}

}
