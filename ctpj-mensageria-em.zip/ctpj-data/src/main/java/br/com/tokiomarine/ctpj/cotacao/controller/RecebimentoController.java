package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.cotacao.dto.AproveitamentoCreditoView;
import br.com.tokiomarine.ctpj.cotacao.dto.AvisoCreditoManualView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.CreditoDisponivelView;
import br.com.tokiomarine.ctpj.cotacao.dto.RecebimentoView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoRecebimentoEnum;
import br.com.tokiomarine.ctpj.exception.ControllerInternalErrorException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.mongo.service.BancoService;
import br.com.tokiomarine.ctpj.integracao.service.RecebimentoIntegracaoService;
import br.com.tokiomarine.ctpj.mapper.RecebimentoMapper;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping("/recebimento")
public class RecebimentoController extends AbstractController{
	
	private static Logger logger = LogManager.getLogger(RecebimentoController.class);

	@Autowired
	private RecebimentoService recebimentoService;

	@Autowired
	private RecebimentoIntegracaoService recebimentoIntegracaoService;
	
	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private BancoService bancoService;
	
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private RecebimentoMapper mapper;
	
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String home(@PathVariable BigInteger sequencialCotacaoProposta, Model model){		
		Set<Recebimento> recebimentos;
		Cotacao cotacao;
		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(sequencialCotacaoProposta);
			cotacao = cotacaoService.findCompleta(sequencialCotacaoProposta);
			recebimentos = cotacao.getListRecebimento();
			model.addAttribute("cabecalhoCotacao", cotacaoView);
			model.addAttribute("bancos",bancoService.findAll());
			model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly());
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}
		model.addAttribute("tiposRecebimentos",TipoRecebimentoEnum.valoresTipoRecebimentoCreditoPA());
		model.addAttribute("sequencialCotacaoProposta", sequencialCotacaoProposta);
		model.addAttribute("recebimentosCotacao", recebimentos);
		model.addAttribute("numeroCotacaoProposta", cotacao.getNumeroCotacaoProposta());
		
		return Paginas.recebimento.value();
	}
	
	@GetMapping("/{sequencialCotacaoProposta}/recebimentos")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<RecebimentoView> findRecebimentoBySeqCotacProp(@PathVariable("sequencialCotacaoProposta") BigInteger sequencialCotacaoProposta) throws ServiceException{
		List<Recebimento> listRecebimento = recebimentoService.findRecebimentoBySequencialCotacaoProposta(sequencialCotacaoProposta).stream().collect(Collectors.toList());
		return mapper.toListOfRecebimentoView(listRecebimento);
	}	

	@GetMapping("/listaAvisoCreditoManual")
	@ResponseBody
	public ResponseEntity<?> findAvisoCreditoManual(@RequestParam("numeroAvisoCredito") String numeroAvisoCredito) {
		ResultadoREST<AvisoCreditoManualView> resultado;
		try {
			resultado = recebimentoIntegracaoService.consultarAvisoCredito(numeroAvisoCredito);
			if(!resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(false);
			} else {
				resultado.setSuccess(true);
			}

			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Falha na listagem de aviso credito manual.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}	
	
	@GetMapping("/listaCreditoDisponivel")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<?> findCreditoDisponivel(@RequestParam("numeroCotacaoPropostaRecusada") BigInteger numeroCotacaoPropostaRecusada,
			@RequestParam("tipoRecebimento") String tipoRecebimento,
			@RequestParam("banco") Long banco,
			@RequestParam("numeroNossoNumeroTitulo") String numeroNossoNumeroTitulo,
			@RequestParam("valorRecebimento") BigDecimal valorRecebimento) throws ServiceException{
		ResultadoREST<Object> resultado;
		try{
			resultado = recebimentoIntegracaoService.consultarCreditoDisponivel(numeroCotacaoPropostaRecusada,tipoRecebimento,banco,numeroNossoNumeroTitulo,valorRecebimento);
			if(!resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(false);
			} else {
				resultado.setSuccess(true);
			}
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Falha na listagem de credito de pagamento antecipado ", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}

	@GetMapping("/listaAproveitamentoCredito")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<?> findAproveitamentoCredito(
			@RequestParam("numeroRamoProduto") Integer numeroRamoProduto,
			@RequestParam("numeroApolice") Long numeroApolice,
			@RequestParam("tipoEndosso") Integer tipoEndosso,
			@RequestParam("numeroEndosso") Long numeroEndosso ) throws ServiceException{
		ResultadoREST<AproveitamentoCreditoView> resultado;
		try{
			resultado = recebimentoIntegracaoService.consultarAproveitamentoCredito(numeroRamoProduto,numeroApolice,tipoEndosso,numeroEndosso);
			if(!resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(false);
			} else {
				resultado.setSuccess(true);
			}
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Falha na listagem do aproveitamento de crédito.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}
	
	@GetMapping("/incluiAvisoCreditoManual")
	@ResponseBody
	public ResponseEntity<?> incluiAvisoCreditoManual(
			@RequestParam("sequencialCotacaoProposta") BigInteger sequencialCotacaoPropota,
			@RequestParam("numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam("idAvisoCreditoManual") String idAvisoCreditoManual) {
		ResultadoREST<AvisoCreditoManualView> resultado;
		try {
			OpcaoParcelamento opcaoParcelamentoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(sequencialCotacaoPropota);
			resultado = recebimentoIntegracaoService.incluirAvisoCredito(sequencialCotacaoPropota,numeroCotacaoProposta,idAvisoCreditoManual,super.getUser());

			//faz o calculo das parcelas efetivas
			resultado.getListaValidacao().addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(sequencialCotacaoPropota));
			//caso seja um pagamento a vista, desmarca a opção selecionada
			opcaoParcelamentoService.desmarcarOpcaoParcelamentoSelecionada(opcaoParcelamentoSelecionada);
			
			if( resultado.getListaValidacao() != null && !resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(false);
			} else {
				resultado.setSuccess(true);
			}
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar incluir aviso manual.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}	
	
	@GetMapping("/incluiCreditoDisponivel")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<?> incluiCreditoDisponivel(
			@RequestParam("sequencialCotacaoProposta") BigInteger sequencialCotacaoPropota,
			@RequestParam("numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam("idCreditoDisponivel") String idCreditoDisponivel){
		ResultadoREST<CreditoDisponivelView> resultado;
		try{
			OpcaoParcelamento opcaoParcelamentoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(sequencialCotacaoPropota);
			resultado = recebimentoIntegracaoService.incluirCreditoDisponivel(sequencialCotacaoPropota,numeroCotacaoProposta,idCreditoDisponivel,super.getUser());
			//faz o calculo das parcelas efetivas
			resultado.getListaValidacao().addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(sequencialCotacaoPropota));
			//caso seja um pagamento a vista, desmarca a opção selecionada
			opcaoParcelamentoService.desmarcarOpcaoParcelamentoSelecionada(opcaoParcelamentoSelecionada);
			
			if( resultado.getListaValidacao() != null && !resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(false);
			} else {
				resultado.setSuccess(true);
			}

			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar incluir crédito disponível.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}	

	@GetMapping("/incluiAproveitamentoCredito")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<?> incluiAproveitamentoCredito(
			@RequestParam("sequencialCotacaoProposta") BigInteger sequencialCotacaoPropota,
			@RequestParam("numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam("idAproveitamentoCredito") String idAproveitamentoCredito) throws ServiceException{
		ResultadoREST<AproveitamentoCreditoView> resultado;
		try{
			OpcaoParcelamento opcaoParcelamentoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(sequencialCotacaoPropota);
			resultado = recebimentoIntegracaoService.incluirAproveitamentoCredito(sequencialCotacaoPropota,numeroCotacaoProposta,idAproveitamentoCredito,super.getUser());
			//faz o calculo das parcelas efetivas
			resultado.getListaValidacao().addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(sequencialCotacaoPropota));
			//caso seja um pagamento a vista, desmarca a opção selecionada
			opcaoParcelamentoService.desmarcarOpcaoParcelamentoSelecionada(opcaoParcelamentoSelecionada);
			if(!resultado.getListaValidacao().isEmpty()) {
				resultado.setSuccess(false);
			} else {
				resultado.setSuccess(true);
			}

			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar inclui aproveitamento credito.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}
	
	
	@GetMapping("/excluiRecebimento")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<?> excluiRecebimento(
			@RequestParam("sequencialCotacaoProposta") BigInteger sequencialCotacaoPropota,
			@RequestParam("numeroCotacaoProposta") BigInteger numeroCotacaoProposta,
			@RequestParam("sequencialRecebimento") BigInteger sequencialRecebimento) throws ServiceException{
		ResultadoREST<Object> resultado;
		try{
			//guarda o parcelamento selecionado
			OpcaoParcelamento opcaoParcelamentoSelecionado = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(sequencialCotacaoPropota);
			
			//exclui o recebimento
			resultado = recebimentoIntegracaoService.excluirRecebimento(sequencialCotacaoPropota,numeroCotacaoProposta,sequencialRecebimento,super.getUser());
			if (resultado.isSuccess()){

				//grava a opção de parcelamento selecionada anteriormente pelo usuario
				if(opcaoParcelamentoSelecionado != null){
					resultado.setListaValidacao(opcaoParcelamentoService.salvar(sequencialCotacaoPropota, opcaoParcelamentoSelecionado.getCodigoFormaPagamento(), opcaoParcelamentoSelecionado.getCodigoFormaParcelamento()));
					
					if(!resultado.getListaValidacao().isEmpty()) {
						resultado.setSuccess(false);
					}
				}
				
				//faz o calculo das parcelas efetivas
				resultado.getListaValidacao().addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(sequencialCotacaoPropota));
	
				if(!resultado.getListaValidacao().isEmpty()) {
					resultado.setSuccess(false);
				} else {
					resultado.setSuccess(true);
				}
			}
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar exclui recebimento.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}
	
}
