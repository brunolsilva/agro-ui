package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CobrancaAgenciaResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1647839999074848792L;
	@JsonProperty("id")
	private String id;
	@JsonProperty("codigoBanco")
	private Integer codigoBanco;
	@JsonProperty("codigoAgencia")
	private Integer codigoAgencia;
	@JsonProperty("tipoAgencia")
	private String tipoAgencia;
	@JsonProperty("nomeAgencia")
	private String nomeAgencia;
	@JsonProperty("endereco")
	private String endereco;
	@JsonProperty("cep")
	private String cep;
	@JsonProperty("bairro")
	private String bairro;
	@JsonProperty("cidade")
	private String cidade;
	@JsonProperty("telefone")
	private String telefone;
	@JsonProperty("dataAtualizacao")
	private String dataAtualizacao;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getCodigoBanco() {
		return codigoBanco;
	}
	public void setCodigoBanco(Integer codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	public Integer getCodigoAgencia() {
		return codigoAgencia;
	}
	public void setCodigoAgencia(Integer codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}
	public String getTipoAgencia() {
		return tipoAgencia;
	}
	public void setTipoAgencia(String tipoAgencia) {
		this.tipoAgencia = tipoAgencia;
	}
	public String getNomeAgencia() {
		return nomeAgencia;
	}
	public void setNomeAgencia(String nomeAgencia) {
		this.nomeAgencia = nomeAgencia;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getDataAtualizacao() {
		return dataAtualizacao;
	}
	public void setDataAtualizacao(String dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}
	
	
}