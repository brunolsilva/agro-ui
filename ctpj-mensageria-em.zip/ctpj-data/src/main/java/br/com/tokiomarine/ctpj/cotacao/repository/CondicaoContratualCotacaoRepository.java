package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.CondicaoContratualCotacao;

@Repository
public class CondicaoContratualCotacaoRepository extends BaseDAO {

	public void deleteBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("delete from CondicaoContratualCotacao cc ");
		sb.append("where  cc.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		query.executeUpdate();
	}

	public void saveList(List<CondicaoContratualCotacao> listaCondicaoContratual) {
		for (CondicaoContratualCotacao condicaoContratual : listaCondicaoContratual) {
			getCurrentSession().save(condicaoContratual);
		}
	}

}
