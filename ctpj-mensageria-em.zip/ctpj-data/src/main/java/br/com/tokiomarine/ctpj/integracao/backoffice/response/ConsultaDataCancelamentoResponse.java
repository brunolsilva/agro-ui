package br.com.tokiomarine.ctpj.integracao.backoffice.response;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ConsultaDataCancelamentoResponse implements Serializable {

	private static final long serialVersionUID = -8444835305978404248L;
	
	private Integer codigo;
	private String descricao;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone="America/Sao_Paulo")
	private Date dataCalculada;

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getDataCalculada() {
		return dataCalculada;
	}

	public void setDataCalculada(Date dataCalculada) {
		this.dataCalculada = dataCalculada;
	}

}