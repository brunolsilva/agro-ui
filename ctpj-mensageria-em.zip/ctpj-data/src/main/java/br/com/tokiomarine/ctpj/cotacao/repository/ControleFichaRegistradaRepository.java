package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Calendar;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ControleFichaRegistrada;
import br.com.tokiomarine.ctpj.exception.HibernateException;

@Repository
public class ControleFichaRegistradaRepository extends BaseDAO {

	public ControleFichaRegistrada save(ControleFichaRegistrada controleFichaRegistrada) throws HibernateException {
		controleFichaRegistrada.setDataAtualizacao(Calendar.getInstance().getTime());
		super.getCurrentSession().persist(controleFichaRegistrada);
		return controleFichaRegistrada;
	}

	public void update(ControleFichaRegistrada controleFichaRegistrada) throws HibernateException {
		controleFichaRegistrada.setDataAtualizacao(Calendar.getInstance().getTime());
		super.getCurrentSession().update(controleFichaRegistrada);
	}

	public void merge(ControleFichaRegistrada controleFichaRegistrada) throws HibernateException {
		controleFichaRegistrada.setDataAtualizacao(Calendar.getInstance().getTime());
		super.getCurrentSession().merge(controleFichaRegistrada);
	}

	
	public ControleFichaRegistrada getControleFichaRegistradaBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws HibernateException {
		StringBuffer hql = new StringBuffer();
		hql.append("	select	r ");
		hql.append("	from	ControleFichaRegistrada r  ");
		hql.append("	where	r.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");

		Query query = this.getCurrentSession().createQuery(hql.toString()).setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);

		return (ControleFichaRegistrada) query.uniqueResult();

	}

}
