package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.componente.utils.EmailUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.integracao.service.ArquivoGntService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Controller
@RequestMapping("/boleto")
public class EmailBoletoController {
	
	@Autowired
	private ArquivoGntService arquivoGntService;

	@PostMapping("/{id}/{numeroCotacao}/{enviaProposta}/{enviaBoleto}")
	@LogPerformance
	public ResponseEntity<?> envia(
			@PathVariable BigInteger id,
			@PathVariable BigInteger numeroCotacao,
			@PathVariable boolean enviaProposta,
			@PathVariable boolean enviaBoleto,
			@RequestBody List<String> envia) {
		List<String> emailsValidos = envia.stream()
				.filter(EmailUtil::valida)
				.collect(Collectors.toList());
		return arquivoGntService.enviarMailArquivoPropostaBoleto(id,numeroCotacao,enviaProposta,enviaBoleto,emailsValidos,SecurityUtils.getCurrentUser());
	}
	
	public String getRequest(List<String> emailsValidos, boolean enviaProposta, boolean enviaBoleto) {
		String request = "enviaProposta: " + enviaProposta + ", enviaBoleto: " + enviaBoleto;
		
		if(emailsValidos != null && !emailsValidos.isEmpty()){
			request += ", emailsValidos: " + emailsValidos;
		}
		
		return request;
	}
}
