package br.com.tokiomarine.ctpj.integracao.acsel.response;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "codigoRetorno", "descricaoCodigoRetorno", "cmensagem", "cretcode", "nvalorcreditos", "nqtdecreditos" })
public class SaldoFupResponse {

	@JsonProperty("codigoRetorno")
	private String codigo;
	@JsonProperty("descricaoCodigoRetorno")
	private String descricao;
	@JsonProperty("cmensagem")
	private String mensagem;
	@JsonProperty("cretcode")
	private String retCode;
	@JsonProperty("nvalorcreditos")
	private BigDecimal valorCreditos;
	@JsonProperty("nqtdecreditos")
	private Integer quantidadeCreditos;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	@JsonProperty("codigoRetorno")
	public String getCodigo() {
		return codigo;
	}

	@JsonProperty("codigoRetorno")
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@JsonProperty("descricaoCodigoRetorno")
	public String getDescricao() {
		return descricao;
	}

	@JsonProperty("descricaoCodigoRetorno")
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@JsonProperty("cmensagem")
	public String getMensagem() {
		return mensagem;
	}

	@JsonProperty("cmensagem")
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	@JsonProperty("cretcode")
	public String getRetCode() {
		return retCode;
	}

	@JsonProperty("cretcode")
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}

	@JsonProperty("nvalorcreditos")
	public BigDecimal getValorCreditos() {
		return valorCreditos;
	}

	@JsonProperty("nvalorcreditos")
	public void setValorCreditos(BigDecimal valorCreditos) {
		this.valorCreditos = valorCreditos;
	}

	@JsonProperty("nqtdecreditos")
	public Integer getQuantidadeCreditos() {
		return quantidadeCreditos;
	}

	@JsonProperty("nqtdecreditos")
	public void setQuantidadeCreditos(Integer quantidadeCreditos) {
		this.quantidadeCreditos = quantidadeCreditos;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}