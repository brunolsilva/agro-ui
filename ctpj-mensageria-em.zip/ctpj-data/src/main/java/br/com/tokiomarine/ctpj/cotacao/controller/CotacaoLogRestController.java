package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoLogResponse;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoLogService;

@RestController
@RequestMapping("/cotacaoLog")
public class CotacaoLogRestController {

	@Autowired
	private CotacaoLogService cotacaoLogService;
	
	@GetMapping(produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> busca(@RequestParam("seqCotacao")  BigInteger seqCotacao, @RequestParam("tipoProcessamento") Integer tipoProcessamento){
		Optional<CotacaoLogResponse> response = cotacaoLogService.buscaCotacaoLogMaisRecente(seqCotacao, tipoProcessamento);
		
		if(!response.isPresent())
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Não foi encontrado CotacaoLog");
		
		return ResponseEntity.ok(response.get());
	}
}
