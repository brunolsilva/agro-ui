package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracValorAtributo;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;

@Repository
public class ProdutoCaracValorAtributoRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static Logger logger = LogManager.getLogger(ProdutoCaracValorAtributoRepository.class);
	
	@LogPerformance
	public List<ProdutoCaracValorAtributo> findProdutoCaracByEquipamento(ItemCotacao itemCotacao){
		return mongoTemplate.find(
				query(where("produto").is(itemCotacao.getCotacao().getCodigoProduto())
						.and("caracteristica").is(Caracteristicas.ATIVIDADE.codigo())
						.and("valorCaracteristica").is(itemCotacao.getCodigoRubrica())), ProdutoCaracValorAtributo.class);
	}
	
	@Cacheable("produtoCaracValorAtributos")
	@LogPerformance
	public List<ProdutoCaracValorAtributo> findProdutoCaracByProduto(Integer codigoProduto) {
		return mongoTemplate.find(
				query(where("produto").is(codigoProduto)
						.and("caracteristica").is(Caracteristicas.ATIVIDADE.codigo())), ProdutoCaracValorAtributo.class);
	}

	@LogPerformance
	public List<Integer> findProdutoCaracByValor(Integer codigoProduto, Long valorCaracteristica) {
		return mongoTemplate.find(
				query(where("produto").is(codigoProduto)
						.and("valorCaracteristica").is(valorCaracteristica)
						.and("caracteristica").is(Caracteristicas.ATIVIDADE.codigo())), ProdutoCaracValorAtributo.class)
				.stream().map(ProdutoCaracValorAtributo::getCobertura)
				.collect(Collectors.toList());
	}
}
