package br.com.tokiomarine.ctpj.dto;

public class ItemInclusaoClausula {
	private Integer valorCaracteristica;
	private Integer clausulaNota;
	private boolean imprime;
	private String descricaoClausula;
	//private boolean clausulaAlterada;

	public Integer getValorCaracteristica() {
		return valorCaracteristica;
	}

	public void setValorCaracteristica(Integer valorCaracteristica) {
		this.valorCaracteristica = valorCaracteristica;
	}

	public Integer getClausulaNota() {
		return clausulaNota;
	}

	public void setClausulaNota(Integer clausulaNota) {
		this.clausulaNota = clausulaNota;
	}

	public boolean isImprime() {
		return imprime;
	}

	public void setImprime(boolean imprime) {
		this.imprime = imprime;
	}

	public String getDescricaoClausula() {
		return descricaoClausula;
	}

	public void setDescricaoClausula(String descricaoClausula) {
		this.descricaoClausula = descricaoClausula;
	}

}