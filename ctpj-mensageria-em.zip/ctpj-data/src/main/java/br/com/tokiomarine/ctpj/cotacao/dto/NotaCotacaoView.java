package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class NotaCotacaoView implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BigInteger sequencialNotaCotacao;
	private Integer sequencialNotaControle;
	private String nota;
	private BigInteger numeroCotacaoProposta;
	private Integer versaoCotacaoProposta;
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy HH:mm:ss")
	private Date dataAtualizacao;
	private Integer codigoGrupo;
	private Long usuarioAtualizacao;
	
	public BigInteger getSequencialNotaCotacao() {
		return sequencialNotaCotacao;
	}
	
	public void setSequencialNotaCotacao(BigInteger sequencialNotaCotacao) {
		this.sequencialNotaCotacao = sequencialNotaCotacao;
	}
	
	public Integer getSequencialNotaControle() {
		return sequencialNotaControle;
	}
	
	public void setSequencialNotaControle(Integer sequencialNotaControle) {
		this.sequencialNotaControle = sequencialNotaControle;
	}
	
	public String getNota() {
		return nota;
	}
	
	public void setNota(String nota) {
		this.nota = nota;
	}
	
	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}
	
	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}
	
	public Integer getVersaoCotacaoProposta() {
		return versaoCotacaoProposta;
	}
	
	public void setVersaoCotacaoProposta(Integer versaoCotacaoProposta) {
		this.versaoCotacaoProposta = versaoCotacaoProposta;
	}

	
	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	
	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	
	public Integer getCodigoGrupo() {
		return codigoGrupo;
	}

	
	public void setCodigoGrupo(Integer codigoGrupo) {
		this.codigoGrupo = codigoGrupo;
	}

	
	public Long getUsuarioAtualizacao() {
		return usuarioAtualizacao;
	}

	
	public void setUsuarioAtualizacao(Long usuarioAtualizacao) {
		this.usuarioAtualizacao = usuarioAtualizacao;
	}
	
	

}
