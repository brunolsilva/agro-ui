package br.com.tokiomarine.ctpj.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class JPAConfig {

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean session = new LocalSessionFactoryBean();
		session.setDataSource(dataSource());
		session.setPackagesToScan("br.com.tokiomarine.ctpj.domain");
		session.setHibernateProperties(additionalProperties());
		return session;
	}

	@Bean
	public DataSource dataSource() {

		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		DataSource dataSource = dsLookup.getDataSource("java:/ctpjDS");
		return dataSource;
	}

	@Bean
	public PlatformTransactionManager transactionManager(SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory);
		return transactionManager;
	}

	private Properties additionalProperties() {
		Properties properties = new Properties();
		properties.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
		properties.setProperty("hibernate.show_sql", "false");
//		properties.setProperty("hibernate.query.plan_cache_max_size", "2048");
		properties.setProperty("connection.provider_class", "org.hibernate.connection.C3P0ConnectionProvider");
		properties.setProperty("hibernate.c3p0.acquire_increment", "1");
		//properties.setProperty("hibernate.hbm2ddl.auto","create");
		properties.setProperty("hibernate.c3p0.idle_test_period", "300");
		properties.setProperty("hibernate.c3p0.timeout", "5000");
		properties.setProperty("hibernate.c3p0.max_size", "10");
		properties.setProperty("hibernate.c3p0.max_statements", "0");
		properties.setProperty("hibernate.c3p0.min_size", "1");
		properties.setProperty("hibernate.c3p0.acquireRetryAttempts", "3");
		properties.setProperty("hibernate.c3p0.acquireRetryDelay", "1000");
		//properties.setProperty("hibernate.generate_statistics", "true");
		
		return properties;
	}
}