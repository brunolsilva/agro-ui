package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;

public class OutroSeguroValidator {
	
	/**
	 * 
	 * Valida o Valor em Risco Calculado de Acordo com a existência ou não de Outros Seguros
	 * 
	 * @param cotacao
	 * @param outrosSeguros
	 * @return
	 */
	public List<ValidacaoLote> valida(Cotacao cotacao) {
		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		List<ItemOutroSeguro> outrosSeguros = new ArrayList<>();

		for(ItemCotacao item: cotacao.getListItem()) {
			if(item.getListItemOutroSeguro() !=  null && !item.getListItemOutroSeguro().isEmpty()) {
				for(ItemOutroSeguro ios: item.getListItemOutroSeguro()) {
					outrosSeguros.add(ios);
				}
			}
		}

		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			long temOutrosSeguros = outrosSeguros.stream()
					.filter(it -> it.getItemCotacao().getSequencialItemCotacao().equals(itemCotacao.getSequencialItemCotacao()))
					.count();
			if(temOutrosSeguros == 0) {
				validaSemOutroSeguro(listaValidacao, itemCotacao);
			} else {
				validaComOutroSeguro(cotacao, outrosSeguros, listaValidacao, itemCotacao);
			}
		}
		
		return listaValidacao;
	}

	/**
	 * Se existir Outros Seguros  para o item, então o  Valor em Risco Calculado + a soma dos LMG dos Outros Seguros deve ser menor ou igual ao Valor em Risco.
	 * 
	 * @param cotacao
	 * @param outrosSeguros
	 * @param listaValidacao
	 * @param itemCotacao
	 */
	private void validaComOutroSeguro(Cotacao cotacao, List<ItemOutroSeguro> outrosSeguros,
			List<ValidacaoLote> listaValidacao, ItemCotacao itemCotacao) {
		BigDecimal somaOS = calculaSomaLMGOutrosSeguros(outrosSeguros, itemCotacao);

		BigDecimal soma;
		BigDecimal valorRiscoBem;

		if(cotacao.getCodigoMoeda() == MoedaEnum.REAL) {
			soma = itemCotacao.getValorRiscoBemCalculado().add(somaOS);
			valorRiscoBem = itemCotacao.getValorRiscoBem();
		} else {
			soma = itemCotacao.getValorCalculadoMoedaEstrangeira().add(somaOS);
			valorRiscoBem = itemCotacao.getValorRiscoBemMoedaEstrangeira();
		}

		if(soma.compareTo(valorRiscoBem) > 0) {
			BigDecimal diferenca = valorRiscoBem.subtract(somaOS);
			listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(),
					String.format("A Soma do Valor em Risco Calculado e os LMG's dos Outros Seguros deve ser menor ou igual ao Valor em Risco. "
							+ "Ajustar o Valor em Risco Calculado para %s ou menor", diferenca)));
		}
	}

	/**
	 * Se não existir Outros Seguros para o item, então o Valor em Risco Calculado deve ser igual ao Valor em Risco.
	 * @param listaValidacao
	 * @param itemCotacao
	 */
	private void validaSemOutroSeguro(List<ValidacaoLote> listaValidacao, ItemCotacao itemCotacao) {
		if(itemCotacao.getValorRiscoBemCalculado() != null) {
			if(itemCotacao.getValorRiscoBem().compareTo(itemCotacao.getValorRiscoBemCalculado()) != 0) {	
				listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), "O Valor em Risco Calculado deve ser igual ao Valor em Risco."));
			}
		}
	}

	private BigDecimal calculaSomaLMGOutrosSeguros(List<ItemOutroSeguro> outrosSeguros, ItemCotacao itemCotacao) {
		return outrosSeguros.stream()
				.filter(it -> it.getItemCotacao().getSequencialItemCotacao().equals(itemCotacao.getSequencialItemCotacao()) && it.getValorLMG() != null)
				.map(ItemOutroSeguro::getValorLMG)
				.reduce(BigDecimal.ZERO,BigDecimal::add);
	}
}