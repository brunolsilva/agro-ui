package br.com.tokiomarine.ctpj.cotacao.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.dto.ValidationMessageList;
import br.com.tokiomarine.ctpj.exception.NegocioException;
import br.com.tokiomarine.ctpj.exception.RegraNegocioException;

/**
 * Centraliza o tratamento das exceções lançadas da camada de Controller
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler {
	
	@Autowired
	private MessageSource messageSource;	
	
	/**
	 * Trata exceções de validação de objetos (validações utilizando o @Valid) da camada de Controller
	 * 
	 * @param exception
	 * @return
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
	@ResponseBody
	public ResultadoREST<Void> trataExcecoesDeValidacao(MethodArgumentNotValidException exception){
		BindingResult bindingResult = exception.getBindingResult();
		ResultadoREST<Void> resultadoRest = new ResultadoREST<>();
		resultadoRest.setListaValidacao(bindingResult, messageSource);
		
		return  resultadoRest;
	}
	
	@ExceptionHandler(NegocioException.class)
	@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
	@ResponseBody
	public ResultadoREST<Void> trataExcecoesDeNegocio(NegocioException exception){
		List<Validacao> validacoes = exception.getValidacoes();
		ResultadoREST<Void> resultadoREST = new ResultadoREST<>();
		resultadoREST.setListaValidacao(validacoes);
		
		return resultadoREST;
	}	
	
	@ExceptionHandler(RegraNegocioException.class)
	@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
	@ResponseBody
	public ResultadoREST<Void> trataExcecoesDeNegocio(RegraNegocioException exception){
		ValidationMessageList messages = exception.getMessages();
		ResultadoREST<Void> resultadoREST = new ResultadoREST<>();
		List<Validacao> listValidacao = new ArrayList<>();
		
		messages.forEach(message -> listValidacao.add(new Validacao(message.getFullText())) );
		
		resultadoREST.setListaValidacao(listValidacao);
		
		return resultadoREST;
	}	

}
