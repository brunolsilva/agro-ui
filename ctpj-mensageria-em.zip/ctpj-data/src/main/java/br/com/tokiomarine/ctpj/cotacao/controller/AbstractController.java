package br.com.tokiomarine.ctpj.cotacao.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.context.SecurityContextHolder;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.dto.Mensagem;

public abstract class AbstractController {

	private static final Logger logger = Logger.getLogger(AbstractController.class);

	protected static final String MSG_ACESSO_NEGADO = "msgAcessoNegado";
	protected static final String SUCESSO = "sucesso";
	protected static final String ERRO = "erro";

	public User getUser() {
		User user = null;
		try {
			user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		} catch (Exception e) {
			logger.error("Erro ao Buscar Usuario SecurityContextHolder",e);
		}
		return user;
	}

	public void invalidateSession(HttpServletRequest request) {
		try {
			HttpSession session = request.getSession(false);
			SecurityContextHolder.clearContext();
			if (session != null) {
				session.invalidate();
			}
		} catch (Exception e) {
			logger.error("Erro ao Buscar invalidar a Sessao",e);

		}
	}

	protected void limpaMensagens(HttpServletRequest request) {
		try {
			request.getSession().removeAttribute(SUCESSO);
			request.getSession().removeAttribute(ERRO);
		} catch (Exception e) {
			logger.error("Erro ao Limpar Mensagens da Sessão: ",e);
		}
	}
	
	protected void limpaMensagens(HttpSession session) {
		try {
			session.removeAttribute(SUCESSO);
			session.removeAttribute(ERRO);
		} catch (Exception e) {
			logger.error("Erro ao Limpar Mensagens da Sessão: ",e);
		}
	}
	
	protected List<Mensagem> getMensagemErro (Throwable t) {
		List<Mensagem> mensagens = new ArrayList<Mensagem>();
		try {
			Mensagem mensagem = new Mensagem();
			mensagem.setCodigo(1);
			mensagem.setDescricao(t.getMessage());
			mensagens.add(mensagem);
		} catch (Exception e) {
			logger.error("Erro na montagem da mensagem de erro",e);
		}
		return mensagens;
	}
}