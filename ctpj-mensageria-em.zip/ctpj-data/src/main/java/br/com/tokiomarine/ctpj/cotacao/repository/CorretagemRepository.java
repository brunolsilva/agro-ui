package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;

@Repository
public class CorretagemRepository extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(CosseguroRepository.class);
	
	public List<CorretagemCotacao> findCorretagensByCotacao(BigInteger cotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		try {
			hql.append(" from CorretagemCotacao c");
			hql.append(" where c.cotacao = :cotacao");

			Query query = getCurrentSession().createQuery(hql.toString());
			Cotacao cotacaoParam = new Cotacao();
			cotacaoParam.setSequencialCotacaoProposta(cotacao);
			query.setParameter("cotacao", cotacaoParam);

			return (List<CorretagemCotacao>)query.list();
		} catch(Exception e) {
			throw new RepositoryException(e.getMessage(), e);
		}
	}

	public void salvar(List<CorretagemCotacao> corretagens) throws RepositoryException {
		for(CorretagemCotacao corretagem: corretagens) {
			getCurrentSession().save(corretagem);
		}
	}

	public void deleteCorretagem(BigInteger sequencialCotacaoProposta) {
		logger.info("Início delete da lista de Corretagens da Cotacao " + sequencialCotacaoProposta);

		Query query = getCurrentSession().createQuery("delete CorretagemCotacao c where c.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		query.executeUpdate();

		logger.info("Fim delete da lista de Corretagens da Cotacao " +sequencialCotacaoProposta);
	}

	public BigInteger getSequencialItemSinistroCobertura() {
		StringBuilder hql = new StringBuilder();
		hql.append("SELECT max(c.sequencialItemSinistroCobertura) + 1 FROM ItemCoberturaSinistro c ");

		Query query = getCurrentSession().createQuery(hql.toString());
		BigInteger seq = (BigInteger) query.uniqueResult();
		if(seq == null){
			seq = BigInteger.ONE;
		}
		return seq;
	}
}