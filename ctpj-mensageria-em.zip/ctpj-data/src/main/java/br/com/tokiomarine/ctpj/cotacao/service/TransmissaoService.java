package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.componente.utils.CelularUtil;
import br.com.tokiomarine.componente.utils.EmailUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosContaDebitoView;
import br.com.tokiomarine.ctpj.cotacao.dto.DocumentoDigitalView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.OpcaoParcelamentoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.RecebimentoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.TransmissaoRepository;
import br.com.tokiomarine.ctpj.cotacao.validation.LmrMinimoValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.VencimentoParcelaValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.VencimentoProgramadoValidator;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DocumentoDigital;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.CorretorApoliceDigital;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.enums.FormaEnvioDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.ModuloProdutoEnum;
import br.com.tokiomarine.ctpj.enums.OrigemContratacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.OpcaoParcelamentoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.EstadoCivilEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.service.KmeService;
import br.com.tokiomarine.ctpj.integracao.service.MensageriaService;
import br.com.tokiomarine.ctpj.integracao.service.PagamentoAntecipadoService;
import br.com.tokiomarine.ctpj.integracao.service.ProvisaoService;
import br.com.tokiomarine.ctpj.integracao.service.ServicosPortaisService;
import br.com.tokiomarine.ctpj.integracao.servicosportais.response.CorretorResponse;
import br.com.tokiomarine.ctpj.interfaceCSF.response.ResponseInterfaceCSF;
import br.com.tokiomarine.ctpj.print.service.CotacaoPrintService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.ctpj.type.FormaEnvioApoliceDigitalEnum;
import br.com.tokiomarine.ctpj.util.InspecaoUtil;
import br.com.tokiomarine.ctpj.util.RestTemplateUtil;

@EnableAsync
@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class TransmissaoService {

	private static Logger logger = LogManager.getLogger(TransmissaoService.class);

	@Autowired
	private TransmissaoRepository transmissaoRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private LmrMinimoValidator lmrMinimoValidator;

	@Autowired
	private VencimentoParcelaValidator vencimentoParcelaValidator;

	@Autowired
	private VencimentoProgramadoValidator vencimentoProgramadoValidator;
	
	@Autowired
	private OpcaoParcelamentoRepository opcaoParcelamentoRepository;
	
	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;
	
	@Autowired
	private MensageriaService mensageriaService;
	
	@Autowired
	private PagamentoAntecipadoService pagamentoAntecipadoService;
	
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;
	
	@Autowired
	private TransmissaoSalvarService transmissaoSalvarService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;
	
	@Autowired
	private CotacaoPrintService cotacaoPrintService;

	@Autowired
	private InspecaoService inspecaoService;
	
	@Autowired
	private RecebimentoRepository recebimentoRepository;

	@Autowired
	private MailUtilService mailUtilService;

	@Autowired
	private KmeService kmeService;
	
	@Autowired
	private ProvisaoService provisaoService;
	
	@Autowired
	private DevolucaoService devolucaoService;
	
	@Autowired
	private CorretagemService corretagemService;

	@Autowired
	ServicosPortaisService servicosPortaisService;
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private EndossoService endossoService;

	private RestTemplate restTemplate = RestTemplateUtil.restTemplate(400000);

	public PropostaView carregaDadosProposta(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			PropostaView proposta = transmissaoRepository.carregaDadosProposta(sequencialCotacaoProposta);
			String url = null;
			try {

				if (proposta.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE
						&& !CodigoSituacaoEnum
								.getCodigoSituacaoEnumByCdSituc(proposta.getCotacao().getCodigoSituacaoReadOnly()).isReadOnly()) {
					corretagemService.getCorretorFranqueador(
							ModuloProdutoEnum.getByProdutoAndOrigem(proposta.getCotacao().getCodigoProduto(), getOrigemContratacao()).getCodigoModuloProduto(),
							cotacaoRepository.findById(sequencialCotacaoProposta), new Date());
				}
				url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroConsultaApoliceDigital());
				if(proposta.getCotacao().getCodigoTipoEndossoSCT() != null || (proposta.getDocumentoDigital() != null && StringUtils.isBlank(proposta.getDocumentoDigital().getEmailCorretor()))) {
					CorretorApoliceDigital[] retornoApoliceDigital = restTemplate.getForObject(
							String.format(url, proposta.getCotacao().getCodigoCorretorACSEL(), proposta.getCotacao().getCodigoProduto()),
							CorretorApoliceDigital[].class);

					if(retornoApoliceDigital != null && retornoApoliceDigital.length > 0) {
						FormaEnvioApoliceDigitalEnum formaEnvio = FormaEnvioApoliceDigitalEnum.getById(retornoApoliceDigital[0].getIdApoliceDigital());
						if(formaEnvio != null) {
							proposta.setDocumentoDigital(formaEnvio.adicionaEmails(retornoApoliceDigital));
						}
					}
				}
			} catch (Exception e) {
				logger.error("Erro na consulta da busca do Parametro ou na recuperação dos e-mails: " + e.getMessage());
			}

			return proposta;
		} catch (Exception e) {
			logger.error("Erro ao carregar os dados da Proposta", e);
			throw new ServiceException(e.getMessage() + " cotacao  " + sequencialCotacaoProposta, e);
		}
	}

	public void salvar(PropostaView proposta,User user) throws OpcaoParcelamentoException {
		Cotacao cotacao = cotacaoRepository.findCompleta(proposta.getSequencialCotacaoProposta());
		if(isCotacaoNaoDisponivel(cotacao)) {
			return;
		}
		CotacaoView cotacaoView = proposta.getCotacao();
		cotacaoView.setIdTipoPessoa(cotacao.getIdTipoPessoa());
		Recebimento recebimento = recebimentoRepository.findRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());

		if (cotacao.getValorPremioLiquido() != null) {
			if (cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0) {	
				OpcaoParcelamento opcaoParcelamento = opcaoParcelamentoRepository.findOpcaoParcelamentoSelecionada(cotacao.getSequencialCotacaoProposta());
				if(opcaoParcelamento != null){
					cotacao.setDataVencimentoProgramada(proposta.getCotacao().getDataVencimentoProgramada() != null ? proposta.getCotacao().getDataVencimentoProgramada() : null);
					if (recebimento == null || recebimento.getIdTipoCredito() == TipoCreditoEnum.CREDITO_VINCULADO) {
						opcaoParcelamento.setDataVencimentoParcela(proposta.getDataVencimentoParcela());
						populaDadosCC(proposta, cotacao);
					}
				}			
			}
		}
		populaDadosSegurado(cotacaoView, cotacao);
		populaEndereco(cotacaoView, cotacao);
		populaDadosDevolucao(cotacaoView, cotacao);
		populaDadosDocumentoDigital(proposta.getDocumentoDigital(), cotacao, user);
		
		if (!EmailUtil.valida(cotacao.getIdEmailSegurado())) {
			cotacao.setIdEmailSegurado(null);
		}
		
		transmissaoRepository.salvar(cotacao);
	}

	public List<Validacao> enviar(PropostaView proposta,User user) throws ServiceException {
		Boolean efetuaValidacao = false;
		Boolean isProvisionado = false;
		
		Cotacao cotacao = cotacaoRepository.findCotacaoItemInspecaoCompletaBySeqCotacao(proposta.getSequencialCotacaoProposta());

		List<Validacao> listaValidacao = new ArrayList<>();
		String msgLmrMinimoValidator = lmrMinimoValidator.validar(cotacao);
		if(msgLmrMinimoValidator != null) {
			listaValidacao.add(new Validacao(msgLmrMinimoValidator));
			return listaValidacao;
		}
		
		endossoService.validarDataAlteracaoInicioVigenciaItemTransmissao(cotacao, listaValidacao);
		
		if(listaValidacao != null && !listaValidacao.isEmpty()) {
			return listaValidacao;
		}

		if(isCotacaoNaoDisponivel(cotacao)) {
			listaValidacao.add(new Validacao("Cotação já contratada ou não disponível para cálculo"));
			return listaValidacao;
		}

		Recebimento recebimento = recebimentoRepository.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		if(recebimento != null && recebimento.getValorRecebimento() != null && recebimento.getValorRecebimento().compareTo(BigDecimal.ZERO) > 0){
			proposta.setPossuiRecebimento(true);
		}
		
		CotacaoView cotacaoView = proposta.getCotacao();
		cotacaoView.setIdTipoPessoa(cotacao.getIdTipoPessoa());
		Map<BigInteger, List<ItemInspecao>> duplicidadeInspecaoPorItem = new LinkedHashMap<>();
		Map<BigInteger, Date> ultimaInspecaoPorCotacao = new LinkedHashMap<>();

		if (!Arrays.asList(
				TipoEndossoEnum.CANCELAMENTO_APOLICE,
				TipoEndossoEnum.CANCELAMENTO_ENDOSSO,
				TipoEndossoEnum.REDUCAO_IS_SINISTRO,
				TipoEndossoEnum.REINTEGRA_IS_SINISTRO,
				TipoEndossoEnum.CANCELAMENTO_INCLUSAO,
				TipoEndossoEnum.PRORROGACAO_VIGENCIA).contains(cotacao.getIdTipoEndosso())) {
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				duplicidadeInspecaoPorItem.put(itemCotacao.getNumeroItem(), inspecaoService.buscarDuplicidadeItemInspecao(itemCotacao));
				if(itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO || itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR) {
					ultimaInspecaoPorCotacao.put(itemCotacao.getNumeroItem(), inspecaoService.buscarDataRelatorioUltimaInspecao(itemCotacao));
				}
			}
		}
		
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO) {
			efetuaValidacao = true;
		} else {
			// Para os casos de endosso, enviar valor default
			cotacaoView.setIdEstadoCivil(EstadoCivilEnum.SOLTEIRO);
			if (Arrays.asList(
					TipoEndossoEnum.CANCELAMENTO_APOLICE,
					TipoEndossoEnum.CANCELAMENTO_ENDOSSO,
					TipoEndossoEnum.CANCELAMENTO_INCLUSAO).contains(cotacao.getIdTipoEndosso())) {
				efetuaValidacao = cotacao.getIdSolicitanteEndosso() != null && cotacao.getIdSolicitanteEndosso().getCalcula();
			} else if(cotacao.getIdTipoEndosso() != null) {
				efetuaValidacao = cotacao.getIdTipoEndosso().getCalcula();
			}
		}

		listaValidacao = validar(proposta,efetuaValidacao,cotacao,user,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao);		

		if (cotacao.getValorPremioLiquido() != null) {
			if (cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0) {	
				OpcaoParcelamento opcaoParcelamento = opcaoParcelamentoRepository.findOpcaoParcelamentoSelecionada(cotacao.getSequencialCotacaoProposta());				
				if(opcaoParcelamento == null){
					listaValidacao.add(new Validacao("Favor selecionar uma opção de parcelamento."));
					return listaValidacao;
				}
				
				if (recebimento != null && recebimento.getDataProcessoCobranca() != null){
					opcaoParcelamento.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
				}

				cotacao.setDataVencimentoProgramada(proposta.getCotacao().getDataVencimentoProgramada());
				// TODO - Melhorar condição, caso algum endosso  trabalhe com novas parcelas
				if((cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoEndosso() != null && opcaoParcelamento != null)) && !proposta.isPossuiRecebimento()) {
					proposta.setCodigoFormaParcelamento(opcaoParcelamento.getCodigoFormaParcelamento());
					if(opcaoParcelamento != null) {
						opcaoParcelamento.setDataVencimentoParcela(proposta.getDataVencimentoParcela());
					}
		
					if (recebimento != null && recebimento.getDataProcessoCobranca() != null){
						opcaoParcelamento.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
					} else {
						if (cotacao.getDataVencimentoProgramada() != null){
							if (opcaoParcelamento.getIdEntrada() == SimNaoEnum.NAO){
								opcaoParcelamento.setDataVencimentoParcela(cotacao.getDataVencimentoProgramada());
							}
						}
					}

					if (recebimento == null || recebimento.getIdTipoCredito() == TipoCreditoEnum.CREDITO_VINCULADO) {
						populaDadosCC(proposta, cotacao);
					}

					if (efetuaValidacao) {
						listaValidacao.addAll(vencimentoParcelaValidator.validaDataPrimeiraParcela(
								cotacao,
								proposta.getDataVencimentoParcela(),
								opcaoParcelamento.getCodigoFormaPagamento(),
								opcaoParcelamento.getCodigoFormaParcelamento()));
		
						listaValidacao.addAll(vencimentoProgramadoValidator.validaDataVencimentoProgramado(
								cotacao,
								opcaoParcelamento.getCodigoFormaPagamento(),
								opcaoParcelamento.getCodigoFormaParcelamento()));
		
					}
				}
			}
			
		}
		if(cotacao.getListItem().stream()
				.flatMap(it -> it.getListItemCobertura().stream())
				.filter(cob -> cob.getIdCoberturaAvulsa() == SimNaoEnum.SIM)
				.count() > 0) {
				listaValidacao.add(new Validacao("Não é possível contratar uma proposta com cobertura avulsa. É necessário regularizar essa cobertura para contratar."));
		}
		if(proposta.isPossuiRecebimento()) {
			if(!proposta.isExibeBoleto()) {
				populaDadosCC(proposta, cotacao);
			}
		}
		
		//valida os dados para devolução
		listaValidacao.addAll(validarDadosDevolucao(cotacao, proposta));

		if(listaValidacao.isEmpty()) {

			populaDadosSegurado(cotacaoView, cotacao);
			populaEndereco(cotacaoView, cotacao);
			populaDadosDevolucao(cotacaoView, cotacao);
			
			/*
			 * TODO reducao de IS confirmar esse trecho
			 * */
			populaDadosDocumentoDigital(proposta.getDocumentoDigital(), cotacao, user);

			transmissaoSalvarService.salvarAntesDeTransmitir(cotacao);

			//faz a provisão do conta corrente
			provisaoService.provisionar(user, cotacao,listaValidacao);
			
			if (!listaValidacao.isEmpty()){
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}
			
			if (efetuaValidacao) {
				try {
					listaValidacao.addAll(pagamentoAntecipadoService.gerarPagamentoAntecipado(cotacao,user));
				} catch (Exception e) {
					logger.error("Erro ao gerar pagamento antecipado ", e);
					listaValidacao.add(new Validacao(SecurityUtils.isCorretor() ? "Erro geral ao gerar pagamento antecipado." : "Erro ao chamar o serviço de geração de PA. Entrar em contato com TI."));
				}
			}
						
			if (!listaValidacao.isEmpty()){
				estornarProvisao(user, isProvisionado, cotacao);
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}

			if(cotacao.getDocumentoDigital() == null || cotacao.getDocumentoDigital().getSequencialDocumentoDigital() == null) {
				cotacao.setDocumentoDigital(null);
			}
			listaValidacao.addAll(opcaoParcelamentoService.calcularOpcaoParcelamentoEfetivado(cotacao));
			
			if (!listaValidacao.isEmpty()){
				estornarProvisao(user, isProvisionado, cotacao);
				transmissaoRepository.evict(cotacao);
				return listaValidacao;
			}

			cotacao.setCodigoSituacao(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue());
			cotacao.setNomeSituacao(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getDescricao());
			
			cotacao.setDataTransmissaoProposta(new Date());
			cotacao.setDataProposta(cotacao.getDataProposta() == null ? new Date() : cotacao.getDataProposta());
			
			if(cotacao.getDocumentoDigital() == null || cotacao.getDocumentoDigital().getSequencialDocumentoDigital() == null) {
				cotacao.setDocumentoDigital(null);
			}

			if (cotacao.getIdOrigemContratacao() == null) {
				cotacao.setIdOrigemContratacao(cotacaoService.definirOrigemContratacao(cotacao,user));
			}

			transmissaoRepository.salvar(cotacao);
		} else {
			estornarProvisao(user, isProvisionado, cotacao);
			transmissaoRepository.evict(cotacao);
		}
		
		return listaValidacao;
	}
	
	private List<Validacao> validarDadosDevolucao(Cotacao cotacao, PropostaView proposta){
		List<Validacao> listaValidacao = new ArrayList<>();
		if(cotacao.getIdTipoEndosso() != null && cotacao.getIdTipoEndosso().equals(TipoEndossoEnum.CANCELAMENTO_APOLICE) && cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) < 0 ){
			CotacaoView cotacaoView = proposta.getCotacao();
			if(cotacaoView.getCodigoFormaDevolucao().equals(FormaDevolucaoApoliceEnum.CREDITO_CONTA)){
				if(cotacaoView.getNumeroBancoDevolucao() == null){
					listaValidacao.add(new Validacao("Favor informar o Banco para devolução de crédito"));		
				}
				
				if(cotacaoView.getNumeroAgenciaDevolucao() == null){
					listaValidacao.add(new Validacao("Favor informar a Agência para devolução de crédito"));
				}

				if(cotacaoView.getNumeroContaCorrenteDevolucao() == null){
					listaValidacao.add(new Validacao("Favor informar a Conta Corrente para devolução de crédito"));
				}
				
				if(cotacaoView.getNumeroDigitoContaCorrenteDevolucao() == null || cotacaoView.getNumeroDigitoContaCorrenteDevolucao().isEmpty()){
					listaValidacao.add(new Validacao("Favor informar o Dígito da Conta Corrente para devolução de crédito"));
				}
			} else if(cotacaoView.getCodigoFormaDevolucao().equals(FormaDevolucaoApoliceEnum.RECIBO)){
//				if(cotacaoView.getNumeroBancoDevolucao() == null){
//					listaValidacao.add(new Validacao("Favor informar o Banco para devolução de crédito"));		
//				}
//				
//				if(cotacaoView.getNumeroAgenciaDevolucao() == null){
//					listaValidacao.add(new Validacao("Favor informar a Agência para devolução de crédito"));
//				}
			}
		}
		return listaValidacao;
	}

	private List<Validacao> validar(PropostaView proposta, Boolean efetuaValidacao, Cotacao cotacao, 
			User user, Map<BigInteger, List<ItemInspecao>> duplicidadeInspecaoPorItem,
			Map<BigInteger, Date> ultimaInspecaoPorCotacao) throws ServiceException {

		List<Validacao> listaValidacao = new ArrayList<>();

		if(proposta.getCotacao().getIdCEPSegurado() == null || "0".equals(proposta.getCotacao().getIdCEPSegurado())) {
			listaValidacao.add(new Validacao("Favor informar o CEP"));
		}

		if(proposta.getCotacao().getEnderecoSegurado() == null || proposta.getCotacao().getEnderecoSegurado().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar o Logradouro"));
		}

		if(proposta.getCotacao().getNumeroEnderecoSegurado() == null) {
			listaValidacao.add(new Validacao("Favor informar o Número do Logradouro"));
		}

		if(StringUtils.isEmpty(proposta.getCotacao().getNomeBairroSegurado())) {
			listaValidacao.add(new Validacao("Favor informar o Bairro"));
		}

		if(proposta.getCotacao().getNumeroDDDSegurado() == null || proposta.getCotacao().getNumeroTelefoneSegurado() == null) {
			listaValidacao.add(new Validacao("Favor informar o Telefone"));
		}

//		if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
//			if(StringUtils.isBlank(proposta.getCotacao().getIdEmailSegurado())) {
//				listaValidacao.add(new Validacao("Favor informar o e-mail do segurado"));
//			} else {
//				if(!EmailUtil.valida(proposta.getCotacao().getIdEmailSegurado())) {
//					listaValidacao.add(new Validacao("E-mail informado inválido"));
//				}
//			}
//		}

		if(proposta.getCotacao().getNumeroDDDCelularSegurado() == null || proposta.getCotacao().getNumeroCelularSegurado() == null) {
			proposta.getCotacao().setNumeroDDDCelularSegurado(null);
			proposta.getCotacao().setNumeroCelularSegurado(null);
		}

		try {
			if(proposta.getCotacao().getNumeroDDDCelularSegurado() != null
					&& proposta.getCotacao().getNumeroCelularSegurado() != null
					&& !CelularUtil.valida(proposta.getCotacao().getNumeroDDDCelularSegurado().intValue(),
										  proposta.getCotacao().getNumeroCelularSegurado().intValue(), Calendar.getInstance())) {
					listaValidacao.add(new Validacao("Celular informado inválido"));
			}
		} catch(Exception e) {
			cotacao.setNumeroDDDCelularSegurado(null);
			cotacao.setNumeroCelularSegurado(null);
		}

		if(proposta.getCotacao().getEnderecoSegurado() == null || proposta.getCotacao().getEnderecoSegurado().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar a Cidade"));
		}

		if(proposta.getCotacao().getEnderecoSegurado() == null || proposta.getCotacao().getEnderecoSegurado().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar a UF"));
		}

		if (efetuaValidacao) {
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE ||  cotacao.getIdTipoEndosso() != TipoEndossoEnum.REDUCAO_IS_SINISTRO){
				listaValidacao.addAll(validaDocumentoDigital(proposta));
			}
			listaValidacao.addAll(validaDadosCC(proposta));
			listaValidacao.addAll(validaDadosPLD(proposta));
		}
		
		List<ItemCobertura> listaItensCobertura = itemCoberturaRepository.findCoberturasExigeOficio(proposta.getCotacao());
		if(!SecurityUtils.isCorretor()) {
			for(ItemCobertura cobertura: listaItensCobertura) {
				if(cobertura.getCodigoRessegurador() == null) {
					listaValidacao.add(new Validacao("Favor informar o ressegurador para esta proposta"));
					break;
				}
			}
		}
		 
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE ||
				Arrays.asList(TipoEndossoEnum.DEVOLUCAO,
							TipoEndossoEnum.ADICIONAL,
							TipoEndossoEnum.SEM_MOVIMENTO).contains(cotacao.getIdTipoEndosso())) {

			if (user.getGrupoUsuario().equals(GrupoUsuarioEnum.CORRETOR) || cotacaoService.isRegraNegocioFechado(cotacao, user)){

				boolean solicitaContatoInspecao = false;

				// Busca todos os itens para apólice e busca todos os itens que foram alterados no endosso.
				for (ItemCotacao itemCotacao : cotacao.getListItem()
						.stream()
						.filter(it -> cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && it.getIdTipoEndosso() != null))
						.collect(Collectors.toList())) {
					if (itemCotacao.getListItemInspecao().stream().count() == 0){
						solicitaContatoInspecao = true;
						break;
					}

					if (inspecaoService.existeNecessidadeInspecaoItem(itemCotacao,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao)) {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.SIM);
					} else {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.NAO);
					}
				}
				
				if (solicitaContatoInspecao) {
					listaValidacao.add(new Validacao("Favor informar os dados para solicitação de inspeção."));
				}
				
			} else {

				if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE){
					if (Arrays.asList(
							TipoSeguroEnum.RENOVACAO_TOKIO,
							TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR)
						.contains(cotacao.getIdTipoSeguro())) {
						inspecaoService.existeNecessidadeInspecaoRenovacao(cotacao,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao);
					}
				}
				
				for (ItemCotacao itemCotacao : cotacao.getListItem()
						.stream()
						.filter(it -> cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && it.getIdTipoEndosso() != null))
						.collect(Collectors.toList())) {

					if (inspecaoService.existeNecessidadeInspecaoItem(itemCotacao,duplicidadeInspecaoPorItem,ultimaInspecaoPorCotacao)) {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.SIM);
					} else {
						itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.NAO);
					}

					if (InspecaoUtil.existeNecessidadeInspecao(itemCotacao)){	
						if (itemCotacao.getListItemInspecao().stream().count() == 0){
							listaValidacao.add(new Validacao("Favor informar os dados para solicitação de inspeção do item " + itemCotacao.getNumeroItem()));
						}
					}
				}
			}

		}
		return listaValidacao;
	}

	private List<Validacao> validaDocumentoDigital(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();

		FormaEnvioDocumentoDigitalEnum formaEnvio = FormaEnvioDocumentoDigitalEnum.getById(proposta.getDocumentoDigital().getFormaEnvio());
		DestinoDocumentoDigitalEnum destino = DestinoDocumentoDigitalEnum.getById(proposta.getDocumentoDigital().getDestino());

		if(formaEnvio == null) {
			listaValidacao.add(new Validacao("Favor informar a Forma de Envio"));
		}

		if(destino == null) {
			proposta.getDocumentoDigital().setDestino(DestinoDocumentoDigitalEnum.CORRETOR.getId());
		}

		if(proposta.getDocumentoDigital().getEmailCorretor() == null || proposta.getDocumentoDigital().getEmailCorretor().isEmpty()) {
			listaValidacao.add(new Validacao("Favor informar o(s) E-mails do Corretor"));
		}

		if(listaValidacao.isEmpty()) {
			String[] emails = proposta.getDocumentoDigital().getEmailCorretor().split(";");
			if(emails.length == 0) {
				listaValidacao.add(new Validacao("Favor informar o(s) E-mails do Corretor"));
			} else {
				listaValidacao.addAll(validaEmails(emails));
			}
			
			if(proposta.getDocumentoDigital().getIdEnvioSegurado() == SimNaoEnum.SIM) {
				if(StringUtils.isEmpty(proposta.getDocumentoDigital().getEmailSegurado())) {
					listaValidacao.add(new Validacao("Favor informar o e-mail do segurado"));
				} else if(!EmailUtil.valida(proposta.getDocumentoDigital().getEmailSegurado())) {
					listaValidacao.add(new Validacao("E-mail do Segurado está em um Formato Inválido"));
				}
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaEmails(String[] emails) {
		List<Validacao> listaValidacao = new ArrayList<>();
		for(String email: emails) {
			if(!EmailUtil.valida(email)) {
				listaValidacao.add(new Validacao("E-mail do Corretor inválido (os e-mails deve estar num formato válido e separado por ponto e vírgula (;)) "));
				break;
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaDadosCC(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		if (proposta.getCodigoFormaPagamento() != null) {

			if(!proposta.isExibeBoleto()) {
				if(proposta.getCotacao().getNumeroBancoDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Banco"));
				}
	
				if(proposta.getCotacao().getNumeroAgenciaDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Número da Agência"));
				}
	
				if(proposta.getCotacao().getNumeroContaCorrenteDebito() == null) {
					listaValidacao.add(new Validacao("Favor informar o Número da Conta Corrente"));
				}
	
				if(StringUtils.isEmpty(proposta.getCotacao().getNumeroDigitoContaCorrenteDebito())) {
					listaValidacao.add(new Validacao("Favor informar o Digito Verificador"));
				}
	
//				if(listaValidacao.isEmpty() &&
//						(StringUtils.isEmpty(proposta.getCotacao().getNomeAgenciaDebito())
//						|| StringUtils.isEmpty(proposta.getCotacao().getNumeroTelefoneAgencia())
//						|| StringUtils.isEmpty(proposta.getCotacao().getNomeCidadeAgencia())
//						|| StringUtils.isEmpty(proposta.getCotacao().getEnderecoAgencia())
//						|| StringUtils.isEmpty(proposta.getCotacao().getNomeBairroAgencia())
//						|| StringUtils.isEmpty(proposta.getCotacao().getIdCepAgencia()))) {
//					listaValidacao.add(new Validacao("Dados da conta corrente para débito inválidos. Favor Verificar."));
//				}

				try {
					ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroDadosContaCorrente();
					String url = parametroGeralService.getUrlByNome(urlEnum);
					Map<Object, Object> dadosConta = new HashMap<>();
					dadosConta.put("p_nr_digito_conta_corrente", proposta.getCotacao().getNumeroDigitoContaCorrenteDebito());
					dadosConta.put("p_cd_banco", proposta.getCotacao().getNumeroBancoDebito());
					dadosConta.put("p_nr_digito_agencia", "");
					dadosConta.put("p_cd_agencia", proposta.getCotacao().getNumeroAgenciaDebito());
					dadosConta.put("p_cd_conta_corrente", proposta.getCotacao().getNumeroContaCorrenteDebito());

					DadosContaDebitoView dadosContaDebitoView = restTemplate.postForObject(url, dadosConta, DadosContaDebitoView.class);
					if(!"S".equals(dadosContaDebitoView.getP_id_conta_valida())) {
						listaValidacao.add(new Validacao("Dados da conta corrente para débito inválidos. Favor Verificar."));
					}
				} catch (Exception e) {
					logger.error("Falha ao chamar o serviço de validação de conta corrente ",e);
					listaValidacao.add(new Validacao("Dados da conta corrente para débito inválidos. Favor Verificar."));
				}
			} else {
				if(proposta.getCotacao().getNumeroBancoBoleto() == null) {
					listaValidacao.add(new Validacao("Favor informar o Banco"));
				}
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaDadosPLD(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		CotacaoView cotacao = proposta.getCotacao();

		if(cotacao.getEstrangeiro() == SimNaoEnum.SIM) {
			listaValidacao.addAll(validaDadosEstrangeiro(proposta));
		}

		if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			
			
			
			/*
			 * TODO redução de IS gambs
			 * 
			if(cotacao.getIdTipoPedidoCotacao().equals(TipoPedidoCotacaoEnum.ENDOSSO) && cotacao.getIdTipoEndosso().equals(TipoEndossoEnum.REDUCAO_IS_SINISTRO)){
				cotacao.setIdTipoSexo(SexoEnum.MASCULINO);
				cotacao.setDataNascimentoCliente(Calendar.getInstance().getTime());
				cotacao.setIdProfissao(BigInteger.ONE);
				cotacao.setIdRenda(BigInteger.ZERO);
				cotacao.setIdPatrimonio(BigInteger.ZERO);
			}*/
			
			
			if(StringUtils.isBlank(cotacao.getNumeroRG()) && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar o RG"));
			}

			if(StringUtils.isBlank(cotacao.getNomeOrgaoExpedidor()) && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar o Órgão Expedidor"));
			}

			if(cotacao.getDataExpedicao() == null && cotacao.getEstrangeiro() == SimNaoEnum.NAO) {
				listaValidacao.add(new Validacao("Favor informar a Data de Expedição"));
			}
			
			if(cotacao.getEstrangeiro() == SimNaoEnum.SIM) {
				cotacao.setDataExpedicao(new Date());
			}

			if(cotacao.getIdTipoSexo() == null) {
				listaValidacao.add(new Validacao("Favor informar o Sexo"));
			}

			if(cotacao.getIdEstadoCivil() == null) {
				listaValidacao.add(new Validacao("Favor informar o Estado Civil"));
			}

			if(cotacao.getDataNascimentoCliente() == null) {
				listaValidacao.add(new Validacao("Favor informar a Data de Nascimento"));
			}
			
			if(cotacao.getDataNascimentoCliente() != null 
					&& cotacao.getDataExpedicao() != null 
					&& !cotacao.getDataNascimentoCliente().before(cotacao.getDataExpedicao())) {
				listaValidacao.add(new Validacao("A Data de Nascimento deve ser anterior à data de expedição"));
			}

			if(cotacao.getDataExpedicao() != null && cotacao.getDataExpedicao().after(new Date())) {
				listaValidacao.add(new Validacao("Data de expedição do documento inválida"));
			}

			Date dataMinima = DateUtils.addYears(new Date(), -99);

			if(cotacao.getDataNascimentoCliente() != null
					&& cotacao.getDataNascimentoCliente().before(dataMinima)) {
				listaValidacao.add(new Validacao("Data de nascimento inválida"));
			}
			
			if (cotacao.getEstrangeiro() == SimNaoEnum.NAO && cotacao.getDataExpedicao() != null && cotacao.getDataNascimentoCliente() != null && 
					cotacao.getDataExpedicao().before(cotacao.getDataNascimentoCliente())) {
				listaValidacao.add(new Validacao("Data de Expedição não deve ser menor que a Data de Nascimento."));
			}
			
			/*
			 * TODO redução de IS gambs
			 */
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || cotacao.getIdTipoEndosso() != TipoEndossoEnum.REDUCAO_IS_SINISTRO){
			
				if(cotacao.getIdProfissao() == null) {
					listaValidacao.add(new Validacao("Favor informar a Profissão"));
				}
	
				if(cotacao.getIdPatrimonio() == null) {
					listaValidacao.add(new Validacao("Favor informar o Patrimônio Declarado"));
				}
	
				if(cotacao.getIdRenda() == null) {
					listaValidacao.add(new Validacao("Favor informar a Faixa de Renda"));
				}
			}
			
		} else {
			
			/*
			 * TODO redução de IS gambs
			 */
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || cotacao.getIdTipoEndosso() != TipoEndossoEnum.REDUCAO_IS_SINISTRO){
				if(cotacao.getIdCapitalSocial() == null) {
					listaValidacao.add(new Validacao("Favor informar o Capital Social"));
				}
	
				if(cotacao.getIdFaturamentoPresumido() == null) {
					listaValidacao.add(new Validacao("Favor informar o Faturamento Presumido"));
				}
			}
			
		}

		return listaValidacao;
	}

	private List<Validacao> validaDadosEstrangeiro(PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		if(proposta.getCotacao().getPossuiRNE() == SimNaoEnum.SIM) {
			if(StringUtils.isEmpty(proposta.getCotacao().getNumeroRNE())) {
				listaValidacao.add(new Validacao("Favor informar o RNE"));
			}

			if(proposta.getCotacao().getDataExpedicao() == null){
				listaValidacao.add(new Validacao("Favor informar a Data de Expedição"));
			}
		} else {
			if(StringUtils.isEmpty(proposta.getCotacao().getNumeroPassaporte())) {
				listaValidacao.add(new Validacao("Favor informar o Passaporte"));
			}

			if(proposta.getCotacao().getIdPais() == null) {
				listaValidacao.add(new Validacao("Favor informar o País Emisssor"));
			}
		}

		return listaValidacao;
	}

	private void populaEndereco(CotacaoView cotacaoView, Cotacao cotacao) {
		cotacao.setEnderecoSegurado(cotacaoView.getEnderecoSegurado());
		cotacao.setNumeroEnderecoSegurado(cotacaoView.getNumeroEnderecoSegurado());
		cotacao.setNomeComplementoEnderecoSegurado(cotacaoView.getNomeComplementoEnderecoSegurado());
		cotacao.setNomeBairroSegurado(cotacaoView.getNomeBairroSegurado());
		cotacao.setNomeMunicipioSegurado(cotacaoView.getNomeMunicipioSegurado());
		cotacao.setIdUFSegurado(cotacaoView.getIdUFSegurado());
		cotacao.setIdEmailSegurado(cotacaoView.getIdEmailSegurado());
		cotacao.setNumeroDDDSegurado(cotacaoView.getNumeroDDDSegurado());
		cotacao.setNumeroTelefoneSegurado(cotacaoView.getNumeroTelefoneSegurado());
		cotacao.setNumeroDDDCelularSegurado(cotacaoView.getNumeroDDDCelularSegurado());
		cotacao.setNumeroCelularSegurado(cotacaoView.getNumeroCelularSegurado());
		if(cotacaoView.getIdCEPSegurado() != null && !cotacaoView.getIdCEPSegurado().isEmpty()) {
			cotacao.setIdCEPSegurado(Long.valueOf(cotacaoView.getIdCEPSegurado()));
		} else {
			cotacao.setIdCEPSegurado(null);
		}

		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			itemCotacao.setEnderecoSegurado(cotacaoView.getEnderecoSegurado());
			itemCotacao.setNumeroEnderecoSegurado(cotacaoView.getNumeroEnderecoSegurado());
			itemCotacao.setNomeComplementoEnderecoSegurado(cotacaoView.getNomeComplementoEnderecoSegurado());
			itemCotacao.setNomeBairroSegurado(cotacaoView.getNomeBairroSegurado());
			itemCotacao.setNomeMunicipioSegurado(cotacaoView.getNomeMunicipioSegurado());
			itemCotacao.setIdUFSegurado(cotacaoView.getIdUFSegurado());
			itemCotacao.setIdEmailSegurado(cotacaoView.getIdEmailSegurado());
			itemCotacao.setNumeroDDDSegurado(cotacaoView.getNumeroDDDSegurado());
			itemCotacao.setNumeroTelefoneSegurado(cotacaoView.getNumeroTelefoneSegurado());
			itemCotacao.setNumeroDDDCelularSegurado(cotacaoView.getNumeroDDDCelularSegurado());
			itemCotacao.setNumeroCelularSegurado(cotacaoView.getNumeroCelularSegurado());
			itemCotacao.setNomeSegurado(cotacao.getNomeSegurado());

			if(cotacaoView.getIdCEPSegurado() != null && !cotacaoView.getIdCEPSegurado().isEmpty()) {
				itemCotacao.setIdCEPSegurado(Long.valueOf(cotacaoView.getIdCEPSegurado()));
			} else {
				itemCotacao.setIdCEPSegurado(null);
			}
		}

//		itemCotacaoVal.setCodigoAtividadePrincipal(cotacaoView.getCodigoAtividadePrincipal());
//		itemCotacaoVal.setDescricaoAtividadePrincipal(cotacaoView.getDescricaoAtividadePrincipal());
	}

	private void populaDadosCC(PropostaView proposta, Cotacao cotacao) {
		if(proposta.isExibeBoleto()) {
			cotacao.setNumeroBancoBoleto(proposta.getCotacao().getNumeroBancoBoleto());
			cotacao.setNumeroBancoDebito(null);
			cotacao.setNumeroAgenciaDebito(null);
			cotacao.setNumeroContaCorrenteDebito(null);
			cotacao.setNumeroDigitoContaCorrenteDebito(null);
			cotacao.setIdRelacaoPagadorDebito(null);
		} else {
			cotacao.setNumeroBancoBoleto(null);
			cotacao.setNumeroBancoDebito(proposta.getCotacao().getNumeroBancoDebito());
			cotacao.setNumeroAgenciaDebito(proposta.getCotacao().getNumeroAgenciaDebito());
			cotacao.setNumeroContaCorrenteDebito(proposta.getCotacao().getNumeroContaCorrenteDebito());
			cotacao.setNumeroDigitoContaCorrenteDebito(proposta.getCotacao().getNumeroDigitoContaCorrenteDebito());
			cotacao.setIdRelacaoPagadorDebito(1);
		}
		
	}

	private void populaDadosDocumentoDigital(DocumentoDigitalView documentoDigitalView, Cotacao cotacao, User user) {
		
		if(documentoDigitalView.getDestino() == null) {
			documentoDigitalView.setDestino(DestinoDocumentoDigitalEnum.CORRETOR.getId());
		}
		
		DocumentoDigital documentoDigital = cotacao.getDocumentoDigital();
		if(documentoDigital == null) {
			documentoDigital = new DocumentoDigital();
			documentoDigital.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			documentoDigital.setDataAtualizacao(new Date());
			documentoDigital.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			documentoDigital.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			documentoDigital.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());

			cotacao.setDocumentoDigital(documentoDigital);
		}

		documentoDigital.setFormaEnvio(FormaEnvioDocumentoDigitalEnum.getById(documentoDigitalView.getFormaEnvio()));
		documentoDigital.setDestino(DestinoDocumentoDigitalEnum.getById(documentoDigitalView.getDestino()));
		documentoDigital.setEmailCorretor(documentoDigitalView.getEmailCorretor());
		documentoDigital.setEmailSegurado(documentoDigitalView.getEmailSegurado());
		documentoDigital.setIdEnvioSegurado(documentoDigitalView.getIdEnvioSegurado());
		documentoDigital.setCotacao(cotacao);
	}
	
	private void populaDadosDevolucao(CotacaoView cotacaoView, Cotacao cotacao) {
		cotacao.setCodigoFormaDevolucao(cotacaoView.getCodigoFormaDevolucao());
		cotacao.setNumeroBancoDevolucao(cotacaoView.getNumeroBancoDevolucao());
		cotacao.setNumeroAgenciaDevolucao(cotacaoView.getNumeroAgenciaDevolucao());
		cotacao.setNumeroDigitoAgenciaDevolucao(cotacaoView.getNumeroDigitoAgenciaDevolucao());
		cotacao.setNumeroContaCorrenteDevolucao(cotacaoView.getNumeroContaCorrenteDevolucao());
		cotacao.setNumeroDigitoContaCorrenteDevolucao(cotacaoView.getNumeroDigitoContaCorrenteDevolucao());
	}

	private void populaDadosSegurado(CotacaoView cotacaoView, Cotacao cotacao) {
		cotacao.setNumeroPropostaCorretor(cotacaoView.getNumeroPropostaCorretor());

		cotacao.setIdTipoSexo(cotacaoView.getIdTipoSexo());
		cotacao.setDataNascimentoCliente(cotacaoView.getDataNascimentoCliente());
		cotacao.setIdEstadoCivil(cotacaoView.getIdEstadoCivil());
		
		cotacao.setNumeroRG(cotacaoView.getNumeroRG());
		cotacao.setDataExpedicao(cotacaoView.getDataExpedicao());
		cotacao.setNomeOrgaoExpedidor(cotacaoView.getNomeOrgaoExpedidor());

		if(cotacaoView.getEstrangeiro() != SimNaoEnum.SIM) {
			cotacaoView.setPossuiRNE(null);
		}

		cotacao.setEstrangeiro(cotacaoView.getEstrangeiro());
		cotacao.setPossuiRNE(cotacaoView.getPossuiRNE());
		cotacao.setNumeroRNE(cotacaoView.getNumeroRNE());
		cotacao.setNumeroPassaporte(cotacaoView.getNumeroPassaporte());
		cotacao.setIdPais(cotacaoView.getIdPais());
		cotacao.setIdProfissao(cotacaoView.getIdProfissao());
		cotacao.setIdCapitalSocial(cotacaoView.getIdCapitalSocial());
		cotacao.setIdPatrimonio(cotacaoView.getIdPatrimonio());
		cotacao.setIdSeguradoPEP(cotacaoView.getIdSeguradoPEP());
		cotacao.setIdFaturamentoPresumido(cotacaoView.getIdFaturamentoPresumido());
		cotacao.setIdRenda(cotacaoView.getIdRenda());

		cotacao.setNomeAgenciaDebito(cotacaoView.getNomeAgenciaDebito());
		cotacao.setNumeroTelefoneAgencia(cotacaoView.getNumeroTelefoneAgencia());
		cotacao.setNomeCidadeAgencia(cotacaoView.getNomeCidadeAgencia());
		cotacao.setNomeBairroAgencia(cotacaoView.getNomeBairroAgencia());
		cotacao.setIdCepAgencia(cotacaoView.getIdCepAgencia());
		cotacao.setEnderecoAgencia(cotacaoView.getEnderecoAgencia());

		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			itemCotacao.setNumeroRG(cotacaoView.getNumeroRG());
			itemCotacao.setDataExpedicao(cotacaoView.getDataExpedicao());
			itemCotacao.setNomeOrgaoExpedidor(cotacaoView.getNomeOrgaoExpedidor());

			itemCotacao.setEstrangeiro(cotacaoView.getEstrangeiro());
			itemCotacao.setPossuiRNE(cotacaoView.getPossuiRNE());
			itemCotacao.setNumeroRNE(cotacaoView.getNumeroRNE());
			itemCotacao.setNumeroPassaporte(cotacaoView.getNumeroPassaporte());
			itemCotacao.setIdPais(cotacaoView.getIdPais());
			itemCotacao.setIdProfissao(cotacaoView.getIdProfissao());
			itemCotacao.setIdCapitalSocial(cotacaoView.getIdCapitalSocial());
			itemCotacao.setIdPatrimonio(cotacaoView.getIdPatrimonio());
			itemCotacao.setIdSeguradoPEP(cotacaoView.getIdSeguradoPEP());
			itemCotacao.setIdFaturamentoPresumido(cotacaoView.getIdFaturamentoPresumido());
			itemCotacao.setIdRenda(cotacaoView.getIdRenda());
		}
	}
	
	public Boolean exigeOficio(PropostaView proposta) throws ServiceException {
		Boolean exigeOficio = Boolean.FALSE;
		List<ItemCobertura> listaItensCobertura = new ArrayList<>();
		try {
			listaItensCobertura = itemCoberturaRepository.findCoberturasExigeOficio(proposta.getCotacao());
			if(listaItensCobertura != null && !listaItensCobertura.isEmpty()){
				exigeOficio = Boolean.TRUE;
			}
		} catch (Exception e) {
			logger.error("Erro ao buscar informações para verificar se exige Ofício", e);
			throw new ServiceException(e.getMessage(), e);
		}
		return exigeOficio;
	}
	
	@LogPerformance
	public ResultadoREST<ResponseInterfaceCSF> validaIdDocstoreCotacao(BigInteger sequencialCotacaoProposta,User user) throws ServiceException{
		
		ResultadoREST<ResponseInterfaceCSF> response = new ResultadoREST<>();
		
		try{
			response = cotacaoPrintService.gerarImpressaoCotacao(sequencialCotacaoProposta,"S",user);
		}catch (Exception e) {
			logger.error("Erro ao validar informações para verificar se exige Ofício", e);
			throw new ServiceException(e.getMessage(), e);
		}
		return response;
	}
	
	public String validaUrl(ParametroGeralEnum urlEnum) throws ServiceException {
		if (urlEnum == null) {
			logger.error("Erro ao na busca url, urlEnum igual a nulo.");
			throw new ServiceException("Erro ao na busca url, urlEnum igual a nulo.");
		}

		String url = null;
		try {
			url = parametroGeralService.getUrlByNome(urlEnum);
		} catch (Exception e) {
			logger.error("Erro ao realizar a busca da URL." + e.getMessage());
			throw new ServiceException("Erro ao realizar a busca da URL.",e);
		}

		if (StringUtils.isEmpty(url)) {
			logger.error("URL de acesso igual a nulo ou vazia.");
			throw new ServiceException("URL de acesso igual a nulo ou vazia.");
		}
		return url;
	}

	@Async
	public void enviaContratacao(BigInteger sequencialCotacaoProposta, User user) {
		try {
			String url = validaUrl(ParametroGeralEnum.getParametroEnviarFilaContratacao());
			List<Validacao> listaValidacao = mensageriaService.chamarFilaContratacao(sequencialCotacaoProposta,user,url);
			if(listaValidacao != null && !listaValidacao.isEmpty()) {
				mailUtilService.sendMailErro(String.format("Erro ao enviar para a fila de contratação [%s] ", sequencialCotacaoProposta) 
						+ listaValidacao.stream()
							.map(Validacao::getDescricao)
							.collect(Collectors.joining(";")));
			}
			kmeService.atualizaConsultaIntegradaTransmitida(sequencialCotacaoProposta,user);
		} catch (ServiceException e) {
			try {
				kmeService.atualizaConsultaIntegradaTransmitida(sequencialCotacaoProposta,user);
			} catch (ServiceException se) {
				mailUtilService.sendMailErro(String.format("Erro ao atualizar consulta integrada [%s] ", sequencialCotacaoProposta) + ExceptionUtils.getStackTrace(e));
				logger.error("Erro ao atualizar consulta integrada : " + sequencialCotacaoProposta,se);
			}
			mailUtilService.sendMailErro(String.format("Erro ao enviar para a fila de contratação [%s] ", sequencialCotacaoProposta) + ExceptionUtils.getStackTrace(e));
			logger.error("Erro ao enviar para a fila de contratação: " + sequencialCotacaoProposta,e);
		}
	}

	/**
	 * Retorna a lista de e-mails da solicitação (parte CONTATO do SCT) + os e-mails da BU <br/>
	 * Qualquer problema retorna uma lista vazia
	 * 
	 * @param proposta
	 * @return a lista de e-mails da solicitação + BU
	 */
	public List<String> listarEmails(PropostaView proposta) {
		try {
			String url = validaUrl(ParametroGeralEnum.getParametroSCTEmailsSolicitacao());
			List<String> emails = proposta.getDocumentoDigital().getEmailCorretor() != null ? 
					new ArrayList(Arrays.asList(proposta.getDocumentoDigital().getEmailCorretor().split(";"))) : Collections.emptyList();
//			ResponseEntity<EmailContatoSolicitacao> emailsSolicitacao = restTemplate.getForEntity(
//					url + "/" + proposta.getCotacao().getNumeroCotacaoProposta(),
//					EmailContatoSolicitacao.class);
//
//			if(emailsSolicitacao.getBody() != null && emailsSolicitacao.getBody().getCodigo() == 0) {
//				emailsSolicitacao.getBody().getEmailSolicitacaoCotacao().forEach((EmailContato email) -> {
//					if(EmailUtil.valida(email.getDsEmail())) {
//						emails.add(email.getDsEmail());
//					}
//				});
//			}
			return emails;
		} catch (Exception e) {
			logger.error("Erro ao listar os e-mails da solicitação ", e);
			return  proposta.getDocumentoDigital().getEmailCorretor() != null ? 
					Arrays.asList(proposta.getDocumentoDigital().getEmailCorretor().split(";")) : Collections.emptyList();
		}
	}
	
	private void estornarProvisao(User user, Boolean isProvisionado, Cotacao cotacao) throws ServiceException {
		if(isProvisionado) {
			provisaoService.estornar(user, cotacao);
		}
	}
	
	private Integer getOrigemContratacao() {
		Integer origemContratacao = OrigemContratacaoEnum.ORIGEM_CORRETOR.getId();
		if(!SecurityUtils.isCorretor()) {
			origemContratacao = OrigemContratacaoEnum.ORIGEM_SUBSCRITOR.getId();
		}
		return origemContratacao;
	}
	
	public static class EmailContatoSolicitacao {
		private int codigo;
		private String mensagem;
		private List<EmailContato> emailSolicitacaoCotacao;

		public int getCodigo() {
			return codigo;
		}

		public void setCodigo(int codigo) {
			this.codigo = codigo;
		}

		public String getMensagem() {
			return mensagem;
		}

		public void setMensagem(String mensagem) {
			this.mensagem = mensagem;
		}

		public List<EmailContato> getEmailSolicitacaoCotacao() {
			return emailSolicitacaoCotacao;
		}

		public void setEmailSolicitacaoCotacao(List<EmailContato> emailSolicitacaoCotacao) {
			this.emailSolicitacaoCotacao = emailSolicitacaoCotacao;
		}

		@Override
		public String toString() {
			return "EmailContatoSolicitacao [codigo=" + codigo + ", mensagem=" + mensagem + ", emailSolicitacaoCotacao="
					+ emailSolicitacaoCotacao + "]";
		}
	}
	
	public static class EmailContato {
		
		private int idTipoEmail;
		private String dsEmail;

		public int getIdTipoEmail() {
			return idTipoEmail;
		}

		public void setIdTipoEmail(int idTipoEmail) {
			this.idTipoEmail = idTipoEmail;
		}

		public String getDsEmail() {
			return dsEmail;
		}

		public void setDsEmail(String dsEmail) {
			this.dsEmail = dsEmail;
		}

		@Override
		public String toString() {
			return "EmailContato [idTipoEmail=" + idTipoEmail + ", dsEmail=" + dsEmail + "]";
		}
	}
	
	public FormaDevolucaoApoliceEnum[] buscaFormaDevolucao(Cotacao cotacao) throws ServiceException {
		if (SecurityUtils.getCurrentUser().getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR) {
			CorretorResponse corretorResponse = servicosPortaisService.buscaCorretor(cotacao.getCodigoCorretorACSEL());
			if (corretorResponse != null && corretorResponse.getIdDevolucaoSomenteCredito() != null && corretorResponse.getIdDevolucaoSomenteCredito() == SimNaoEnum.SIM) {
				return cotacao.getCodigoFormaDevolucao() != null && cotacao.getCodigoFormaDevolucao() != FormaDevolucaoApoliceEnum.CREDITO_CONTA ?
						new FormaDevolucaoApoliceEnum[] {FormaDevolucaoApoliceEnum.CREDITO_CONTA,cotacao.getCodigoFormaDevolucao()} :
							new FormaDevolucaoApoliceEnum[] {FormaDevolucaoApoliceEnum.CREDITO_CONTA}; 
			} else {
				return FormaDevolucaoApoliceEnum.values();
			}
		} else {
			return FormaDevolucaoApoliceEnum.values();
		}
	}
	
	private boolean isCotacaoNaoDisponivel(Cotacao cotacao) {
		return CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly();
	}
}