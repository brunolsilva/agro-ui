package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoValorRiscoDistribuidoEnum;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;

@Component
public class DistribuicaoVrValidator {

	private static Logger logger = LogManager.getLogger(DistribuicaoVrValidator.class);
	
	/**
	 * Realiza o processo de validação dos ItemDistribuicao (Distribuicao de VR).
	 * 
	 * <p>
	 * Valida a obrigatoriedade dos campos e depois se a soma dos VR é igual 
	 * ao Valor em Risco do Item
	 * </p>
	 *
	 * <p>
	 * Uma lista vazia representa que não há inconsistências
	 * </p>
	 * @param cotacao Classe de Domínio representando uma Cotação e suas dependências
	 * @return uma lista (Item + Descrição) com as inconsistências geradas pelo processo de validação
	 */
	@LogPerformance
	public List<ValidacaoLote> validacaoItemDistribuicao(Cotacao cotacao) {
		logger.info("Início da validação do ItemDistribuicao " + cotacao.getSequencialCotacaoProposta());

		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		MoedaEnum moeda = cotacao.getCodigoMoeda();

		Map<ItemCotacao, List<ItemDistribuicao>> itemDistribuicaoPorItem = cotacao.getListItem().stream()
			.flatMap(item -> item.getListItemDistribuicao().stream())
			.collect(Collectors.groupingBy(ItemDistribuicao::getItemCotacao));

		validaObrigatoriedadeVR(itemDistribuicaoPorItem);

		validaSomaVR(listaValidacao,moeda,itemDistribuicaoPorItem);

		logger.info("Fim da validação do ItemDistribuicao " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}

	/**
	 * A soma da distribuição dos VR deve ser igual ao Valor em Risco do Item
	 * @param listaValidacao
	 * @param moeda
	 * @param map
	 */
	private void validaSomaVR(List<ValidacaoLote> listaValidacao,MoedaEnum moeda,Map<ItemCotacao,List<ItemDistribuicao>> map) {
		for (Map.Entry<ItemCotacao, List<ItemDistribuicao>> entry : map.entrySet()){
			if(moeda == MoedaEnum.REAL) {
				BigDecimal valorRiscoBem = entry.getKey().getValorRiscoBemCalculado();
				BigDecimal total = entry.getValue().stream()
						.filter(it -> it.getIdTipoValorRisco() == TipoValorRiscoDistribuidoEnum.DANOS_MATERIAS)
						.map(ItemDistribuicao::getValorRiscoBem)
						.reduce(BigDecimal.ZERO,BigDecimal::add);
				if(total.compareTo(BigDecimal.ZERO) != 0) {
					doValidaSomaVR(listaValidacao,entry,valorRiscoBem,total);
				}
			} else {
				BigDecimal valorRiscoBem = entry.getKey().getValorCalculadoMoedaEstrangeira();
				BigDecimal total = entry.getValue().stream()
						.filter(it -> it.getIdTipoValorRisco() == TipoValorRiscoDistribuidoEnum.DANOS_MATERIAS)
						.map(ItemDistribuicao::getValorRiscoBemMoedaEstrangeira)
						.reduce(BigDecimal.ZERO,BigDecimal::add);
				if(total.compareTo(BigDecimal.ZERO) != 0) {
					doValidaSomaVR(listaValidacao,entry,valorRiscoBem,total);
				}
			}
		}
	}

	/**
	 * Ação que compara a soma dos VR com o Valor em Risco do Item
	 * @param listaValidacao
	 * @param entry
	 * @param valorRiscoBem
	 * @param total
	 */
	private void doValidaSomaVR(
			List<ValidacaoLote> listaValidacao,
			Map.Entry<ItemCotacao,List<ItemDistribuicao>> entry,
			BigDecimal valorRiscoBem,
			BigDecimal total) {
		if(total.compareTo(valorRiscoBem) != 0) {
			listaValidacao.add(new ValidacaoLote(entry.getKey().getNumeroItem().intValue(),"A soma da Distribuição dos VR deve ser igual ao Valor em Risco Informado para este local de risco"));
		}
	}

	private void validaObrigatoriedadeVR(Map<ItemCotacao, List<ItemDistribuicao>> map) {

		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		for (Map.Entry<ItemCotacao, List<ItemDistribuicao>> entry : map.entrySet()){
			if(entry.getValue().size() != entry.getValue().stream().map(ItemDistribuicao::getDescricaoRiscoBem).distinct().count()) {
				listaValidacao.add(new ValidacaoLote(entry.getKey().getNumeroItem().intValue(),"Não é possível incluir duas descrições de VR iguais"));
			}
		}

		for (Map.Entry<ItemCotacao, List<ItemDistribuicao>> entry : map.entrySet()){
			MoedaEnum moeda = entry.getKey().getCotacao().getCodigoMoeda();
			Integer item = entry.getKey().getNumeroItem().intValue();
			for(ItemDistribuicao itemDistribuicao: entry.getValue()) {
				if(!StringUtils.isNotBlank(itemDistribuicao.getDescricaoRiscoBem())) {
					listaValidacao.add(new ValidacaoLote(item, "Obrigatório informar a Descrição do VR"));
				}

				if(itemDistribuicao.getIdTipoValorRisco() == null) {
					listaValidacao.add(new ValidacaoLote(item, "Obrigatório informar o tipo de VR"));
				}

				if(moeda == MoedaEnum.REAL) {
					if(itemDistribuicao.getValorRiscoBem() == null) {
						listaValidacao.add(new ValidacaoLote(item, "Obrigatório informar o VR"));
					}
				} else {
					if(itemDistribuicao.getValorRiscoBemMoedaEstrangeira() == null) {
						listaValidacao.add(new ValidacaoLote(item, "Obrigatório informar o VR"));
					}
				}
			}
		}
	}
}
