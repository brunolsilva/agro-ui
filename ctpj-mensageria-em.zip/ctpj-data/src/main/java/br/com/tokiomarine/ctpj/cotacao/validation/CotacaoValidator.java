package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import br.com.tokiomarine.componente.utils.CelularUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;
import br.com.tokiomarine.ctpj.util.CnpjCpfUtil;

public class CotacaoValidator {

	private static Logger logger = Logger.getLogger(CotacaoValidator.class);

	private ProdutoValidator produtoValidator;
	private PerfilComercialService perfilComercialService;
	private Map<Integer, ProdutoCaracteristica> caracteristicasDoProduto;

	public CotacaoValidator(
			ProdutoValidator produtoValidator,
			PerfilComercialService perfilComercialService,
			Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto) {
		this.produtoValidator = produtoValidator;
		this.perfilComercialService = perfilComercialService;
		this.caracteristicasDoProduto = caracteristicasDoProduto;
	}

	/**
	 * Realiza o processo de validação da cotação passada como argumento.
	 *
	 * <p>Primeiro valida os dados da Cotação (Capa), se houver inconsistências no processo
	 * pára neste instante retornando a lista de inconsistências da capa. Se não houver inconsistências,
	 * prossegue para a validação dos items/locais de risco e suas coberturas de acordo com o produto
	 * </p>
	 *
	 * <p>
	 * Uma lista vazia representa que não há inconsistências na cotação
	 * </p>
	 * @param cotacao Classe de Domínio representando uma Cotação e suas dependências
	 * @return uma lista (Item + Descrição) com as inconsistências geradas pelo processo de validação
	 */
	@LogPerformance
	public List<ValidacaoLote> validaCotacao(Cotacao cotacao) {
		logger.info("Início da Validação da Cotação " + cotacao.getSequencialCotacaoProposta());

		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		listaValidacao.addAll(this.validaCapa(cotacao));

		if(listaValidacao.isEmpty()) {
			listaValidacao.addAll(produtoValidator.valida(cotacao,caracteristicasDoProduto));
		}

		logger.info("Fim da Validação da Cotação " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}
	
	@LogPerformance
	public List<ValidacaoLote> validaEndosso(Cotacao cotacao) {
		logger.info("Início da Validação da Cotação " + cotacao.getSequencialCotacaoProposta());

		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		listaValidacao.addAll(this.validaCapa(cotacao)); // TODO - Verificar necessidade de criar validators para cada tipo de endosso 

		if ((listaValidacao.isEmpty()) && 
				(!Arrays.asList(
				TipoEndossoEnum.CANCELAMENTO_ENDOSSO,
				TipoEndossoEnum.CANCELAMENTO_APOLICE)
				.contains(cotacao.getIdTipoEndosso()))) {
			listaValidacao.addAll(produtoValidator.valida(cotacao,caracteristicasDoProduto));
		}

		logger.info("Fim da Validação da Cotação " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}

	private List<ValidacaoLote> validaCapa(Cotacao cotacao) {
		logger.info("Início da Validação da Capa da cotacao " + cotacao.getSequencialCotacaoProposta());
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		if(cotacao.getDataInicioVigencia() == null) {
			listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar o Início de Vigência"));
		}

		if(cotacao.getDataFimVigencia() == null) {
			listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar o Término de Vigência"));
		}

		if(cotacao.getNumeroCNPJCPFSegurado() == null) {
			listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar o CPF/CNPJ do Segurado"));
		}

		if(cotacao.getNumeroCNPJCPFSegurado() != null 
				&& cotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA
				&& !CnpjCpfUtil.getInstance().validaCPF(CnpjCpfUtil.getInstance().cleanCPF(cotacao.getNumeroCNPJCPFSegurado()))) {
			listaValidacao.add(new ValidacaoLote(0,"CPF inválido"));
		} else if(cotacao.getNumeroCNPJCPFSegurado() != null 
				&& cotacao.getIdTipoPessoa() == TipoSeguradoEnum.JURIDICA
				&& !CnpjCpfUtil.getInstance().validaCNPJ(CnpjCpfUtil.getInstance().cleanCNPJ(cotacao.getNumeroCNPJCPFSegurado()))) {
			listaValidacao.add(new ValidacaoLote(0,"CNPJ inválido"));
		}

		if(StringUtils.isBlank(cotacao.getNomeSegurado())) {
			listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar o Nome/Razão Social"));
		} else if(StringUtils.split(cotacao.getNomeSegurado(), " ").length < 2){
			listaValidacao.add(new ValidacaoLote(0,"Nome/Razão Social inválido"));
		}
		
		if(cotacao.getIdCEPSegurado() != null && Long.valueOf(0).equals(cotacao.getIdCEPSegurado())) {
			listaValidacao.add(new ValidacaoLote(0,"CEP do segurado inválido"));
		}

		if(cotacao.getNumeroDDDCelularSegurado() != null && cotacao.getNumeroCelularSegurado() != null) {
			if(!CelularUtil.valida(cotacao.getNumeroDDDCelularSegurado().intValue(), cotacao.getNumeroCelularSegurado().intValue(), Calendar.getInstance())) {
				listaValidacao.add(new ValidacaoLote(0,"Celular informado inválido"));
			}
		}

		if(listaValidacao.isEmpty() && cotacao.getIdTipoPedidoCotacao() != TipoPedidoCotacaoEnum.ENDOSSO) {
			new PrazoSeguroValidator().validaPrazoDoSeguro(cotacao, listaValidacao);
		}

		if(listaValidacao.isEmpty() && cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
			LocalDate dataInicio = LocalDate.from(cotacao.getDataInicioVigencia().toInstant().atZone(ZoneId.systemDefault()));
			LocalDate dataFim = LocalDate.from(cotacao.getDataFimVigencia().toInstant().atZone(ZoneId.systemDefault()));
			LocalDate dataAlteracao = LocalDate.from(cotacao.getDataAlteracao().toInstant().atZone(ZoneId.systemDefault()));
			new PrazoSeguroValidator().validaDataAlteracao(listaValidacao, dataInicio, dataFim, dataAlteracao, cotacao.getCodigoTipoEndossoSCT());
		}

		if(cotacao.getListComissaoCotacao() == null || cotacao.getListComissaoCotacao().isEmpty()) {
			List<ItemCobertura> coberturas = cotacao.getListItem().stream()
					.flatMap(item -> item.getListItemCobertura().stream())
					.collect(Collectors.toList());

			if(coberturas.stream()
					.filter(it -> it.getCoberturaPrincipal() == null
							&& (it.getCodigoGrupoRamoEmissao() == null
							|| it.getCodigoRamoCoberturaEmissao() == null))
					.count() > 0) {
				//listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar a Comissão"));
			}
		} else if(cotacao.getListComissaoCotacao().stream()
				.filter(it -> it.getPercentualComissao().compareTo(BigDecimal.ZERO) < 0)
				.count() > 0) {
			listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar a Comissão"));
		} else {
			Map<Integer, BigDecimal> comissaoDesconto = perfilComercialService.valorComissaoMinimoMaximo(
					SecurityUtils.getCurrentUser().getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());

			if(!SecurityUtils.isCorretor()) {
				if(cotacao.getPercentualDescontoGeral() == null) {
					listaValidacao.add(new ValidacaoLote(0,"Obrigatório informar o Desconto"));				
				} else {
					BigDecimal minimo = comissaoDesconto.get(3);
					BigDecimal maximo = comissaoDesconto.get(4);
	
					boolean valido = BigDecimalUtil.maiorIgual(cotacao.getPercentualDescontoGeral(),minimo) && BigDecimalUtil.menorIgual(cotacao.getPercentualDescontoGeral(),maximo);
					if(!valido) {
						listaValidacao.add(new ValidacaoLote(0,String.format("O desconto deve possuir um valor entre %s%% e %s%% ", minimo, maximo)));
					}
				}
			}

			Optional<BigDecimal> comissao = cotacao.getListComissaoCotacao().stream()
														.map(ComissaoCotacao::getPercentualComissao)
														.findFirst();
			
			if(comissao.isPresent() && comissao.get().compareTo(BigDecimal.ZERO) > 0) {
				BigDecimal minimo = comissaoDesconto.get(1);
				BigDecimal maximo = comissaoDesconto.get(2);
				boolean valido = BigDecimalUtil.maiorIgual(comissao.get(),minimo) && BigDecimalUtil.menorIgual(comissao.get(),maximo);
				
				if(SecurityUtils.isCorretor()) {
					BigDecimal comissaoMaximoComDesconto = comissaoDesconto.get(5);
					if(cotacao.getPercentualDescontoGeral() != null && cotacao.getPercentualDescontoGeral().compareTo(BigDecimal.ZERO) > 0) {
						valido = BigDecimalUtil.maiorIgual(comissao.get(),minimo) && BigDecimalUtil.menorIgual(comissao.get(),comissaoMaximoComDesconto);
						maximo = comissaoMaximoComDesconto;
					}
					
					BigDecimal minimoDesconto = comissaoDesconto.get(3);
					BigDecimal maximoDesconto = comissaoDesconto.get(4);

					if(cotacao.getPercentualDescontoGeral() != null) {
						boolean validoDesconto = BigDecimalUtil.maiorIgual(cotacao.getPercentualDescontoGeral(),minimoDesconto) && BigDecimalUtil.menorIgual(cotacao.getPercentualDescontoGeral(),maximoDesconto);
						if(!validoDesconto) {
							listaValidacao.add(new ValidacaoLote(0,String.format("O desconto deve possuir um valor entre %s%% e %s%% ", minimoDesconto, maximoDesconto)));
						}
					}
				}

				if(!valido) {
					listaValidacao.add(new ValidacaoLote(0,String.format("A comissão deve possuir um valor entre %s%% e %s%% ", minimo, maximo)));
				}
			}
		}

		logger.info("Fim da Validação da Capa da cotacao " + cotacao.getSequencialCotacaoProposta());

		return listaValidacao;
	}
	
}