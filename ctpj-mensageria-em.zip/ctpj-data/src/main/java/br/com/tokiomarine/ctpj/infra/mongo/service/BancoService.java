package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.FormaPagamentoBanco;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Banco;
import br.com.tokiomarine.ctpj.infra.domain.BancoCorretorIndisponivel;
import br.com.tokiomarine.ctpj.infra.domain.BancoFinalidade;
import br.com.tokiomarine.ctpj.infra.mongo.repository.BancoRepository;

@Service
public class BancoService {

	private static Logger logger = LogManager.getLogger(BancoService.class);

	@Autowired
	private BancoRepository repository;

	public Banco findBanco(Long banco)  throws ServiceException{
		return repository.findBancoByCodigo(banco);
	}

	public List<FormaPagamentoBanco> findAll(CotacaoView cotacao) throws ServiceException {
		try {
			List<FormaPagamentoBanco> retorno = repository.findAll(cotacao);
			List<FormaPagamentoBanco> listaIndisponivel = new ArrayList<>();
			List<BancoCorretorIndisponivel> indisponiveis = repository.bancosIndisponiveis(cotacao);
			for(BancoCorretorIndisponivel indisponivel: indisponiveis) {
				listaIndisponivel.add(new FormaPagamentoBanco(indisponivel.getBanco(), null, indisponivel.getFormaPagamento()));
			}
			retorno.sort(Comparator.comparing(FormaPagamentoBanco::getDescricaoBanco));
			if(!indisponiveis.isEmpty()) {
				retorno.removeAll(listaIndisponivel);
				return retorno;
			} else {
				return retorno;
			}
		} catch (RepositoryException e) {
			logger.error("Erro na Busca do Banco",e);
			throw new ServiceException("Erro na Busca do Banco",e);
		}
	}

	public List<Banco> findAll()  throws ServiceException{
		try {
			return repository.findAll();
		} catch (RepositoryException e) {
			logger.error("Erro na Busca do Banco",e);
			throw new ServiceException("Erro na Busca do Banco",e);
		}
	}
	
	public List<Banco> findAllAtivos()  throws ServiceException{
		try {
			return repository.findAllAtivos();
		} catch (RepositoryException e) {
			logger.error("Erro na Busca dos Bancos Ativos",e);
			throw new ServiceException("Erro na Busca dos Bancos Ativos",e);
		}
	}
	
	public List<BancoFinalidade> findBancoFinalidadeDevolucao()  throws ServiceException{
		try {
			return repository.findBancoFinalidadeDevolucao();
		} catch (RepositoryException e) {
			throw new ServiceException("Erro ao buscar banco com finalidade devolução. ",e);
		}
	}
	
	public List<FormaPagamentoBanco> findAllByCorretorAndProduto(Long codigoCorretor, Integer codigoProduto) throws ServiceException {
		try {
			return repository.findAllByCorretorAndProduto(codigoCorretor, codigoProduto);
		} catch (RepositoryException e) {
			logger.error("Erro na Busca do Banco Corretor/Produto",e);
			throw new ServiceException("Erro na Busca do Banco Corretor/Produto",e);
		}
	}
}