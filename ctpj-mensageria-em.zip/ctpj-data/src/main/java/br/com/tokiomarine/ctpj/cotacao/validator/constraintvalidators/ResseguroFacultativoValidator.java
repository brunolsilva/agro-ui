package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoCessaoForm;
import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoFaixaForm;
import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoForm;
import br.com.tokiomarine.ctpj.cotacao.service.CalculoCotacaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ValidationMessage;
import br.com.tokiomarine.ctpj.dto.ValidationMessage.Type;
import br.com.tokiomarine.ctpj.dto.ValidationMessageList;
import br.com.tokiomarine.ctpj.enums.IdCessaoEnum;

@Component
public class ResseguroFacultativoValidator{

	@Autowired
	private CalculoCotacaoService calculoService;
	
	public ValidationMessageList valida(ResseguroFacultativoForm form, Cotacao cotacao){
		ValidationMessageList messages = new ValidationMessageList();
		
		Optional<ValidationMessage> erroExistenciaDeFaixas = validaExistenciaDeFaixas(form);	
		if(erroExistenciaDeFaixas.isPresent()){
			messages.add(erroExistenciaDeFaixas.get());
			return messages;
		}		
		
		Set<ValidationMessage> errosPreenchimentoCessao = validaPreenchimentoObrigatório(form);
		if(!errosPreenchimentoCessao.isEmpty())
			return new ValidationMessageList(errosPreenchimentoCessao);
		
		validaValorIsLmgParaFaixas(form, cotacao).ifPresent(erroValidacao -> messages.add(erroValidacao));
		validaValorInicialValorFinalDasFaixas(form).ifPresent(erroValidacao -> messages.add(erroValidacao));
		validaLimiteDasFaixas(form).ifPresent(erroValidacao -> messages.add(erroValidacao));		
		
		messages.addAll(validaDistribuicoes(form));
		
		return messages;
	}
	
	public Optional<ValidationMessage> validaExistenciaDeFaixas(ResseguroFacultativoForm form){		
		List<ResseguroFacultativoCessaoForm> faixas = form.getResseguroFacultativoCessaoList();
		
		if(faixas == null || faixas.isEmpty())
			return Optional.of(new ValidationMessage("Faixas são obrigatórias", Type.ERROR));
		
		return Optional.empty();
	}
	
	public Set<ValidationMessage> validaPreenchimentoObrigatório(ResseguroFacultativoForm form){
		Set<ValidationMessage> messages = new HashSet<>(); 
		
		for(ResseguroFacultativoCessaoForm cessao : form.getResseguroFacultativoCessaoList()){
			BigDecimal valorInicial = cessao.getValorInicial();
			BigDecimal valorFinal = cessao.getValorFinal();
			BigDecimal percentualCedido = cessao.getPercentualCedido();			
			
			if(valorInicial == null || !maiorOuIgualAZero(valorInicial))
				messages.add(new ValidationMessage("O valor inicial é obrigatório e deve ser igual ou maior do que zero", Type.ERROR));
				
			if(valorFinal == null || !maiorOuIgualAZero(valorFinal))
				messages.add(new ValidationMessage("O valor final é obrigatório e deve ser igual ou maior do que zero", Type.ERROR));
			
			if(percentualCedido == null || !maiorOuIgualAZero(percentualCedido))
				messages.add(new ValidationMessage("O percentual cedido em resseguro é obrigatório e deve ser igual ou maior do que zero", Type.ERROR));
		}		
		
		return messages;		
	}
	
	public Optional<ValidationMessage> validaValorIsLmgParaFaixas(ResseguroFacultativoForm form, Cotacao cotacao){
		List<ResseguroFacultativoCessaoForm> faixas = form.getResseguroFacultativoCessaoList();
		
		ResseguroFacultativoCessaoForm ultimaFaixa = faixas.get(faixas.size() - 1);
		BigDecimal somaValoresLMR = calculoService.calculaSomaValoresLMR(cotacao);
		
		if(!menorOuIgualA(ultimaFaixa.getValorFinal(), somaValoresLMR)){
			return Optional.of(new ValidationMessage("O valor do IS/LMG é limitado ao valor do LMR, verifique o valor final da última faixa", Type.ERROR));
		}
		
		return  Optional.empty();
	}
	
	public Optional<ValidationMessage> validaValorInicialValorFinalDasFaixas(ResseguroFacultativoForm form){
		for (ResseguroFacultativoCessaoForm faixa : form.getResseguroFacultativoCessaoList()) {
			BigDecimal valorInicial = faixa.getValorInicial();
			BigDecimal valorFinal = faixa.getValorFinal();
			
			if(valorInicial == null || valorFinal == null)
				return Optional.of(new ValidationMessage("Os valores iniciais e finais da faixa são obrigatórios", Type.ERROR));
			
			if(!maiorOuIgualAZero(valorInicial) || !maiorOuIgualAZero(valorFinal))
				return Optional.of(new ValidationMessage("Os valores iniciais e finais da faixa devem ser igual ou maior do que zero", Type.ERROR));
			
			if(form.getIdCessao().equals(IdCessaoEnum.POR_FAIXAS)){
				if(!menorDoQue(valorInicial, valorFinal))
					return Optional.of(new ValidationMessage("Os valores iniciais devem ser menores que os valores finais nas faixas", Type.ERROR));		
			}
		}
		
		return Optional.empty();
	}

	public Optional<ValidationMessage> validaLimiteDasFaixas(ResseguroFacultativoForm form) {
		List<ResseguroFacultativoCessaoForm> faixas = form.getResseguroFacultativoCessaoList();

		Iterator<ResseguroFacultativoCessaoForm> iterator = faixas.iterator();
		ResseguroFacultativoCessaoForm primeiraFaixa = iterator.next();

		while (iterator.hasNext()) {
			ResseguroFacultativoCessaoForm segundaFaixa = iterator.next();

			if (primeiraFaixa.getValorFinal().equals(segundaFaixa.getValorInicial()))
				primeiraFaixa = segundaFaixa;
			else {
				return Optional.of(new ValidationMessage("O valor final de uma faixa deve ser igual ao valor inicial da faixa subsequente", Type.ERROR));
			}
		}

		return Optional.empty();
	}
	
	public List<ValidationMessage> validaDistribuicoes(ResseguroFacultativoForm form){
		Optional<ValidationMessage> erroFaixasSemDistribuicoes = validaFaixasComDistribuicoes(form);
		if(erroFaixasSemDistribuicoes.isPresent())
			return Arrays.asList(erroFaixasSemDistribuicoes.get());		
		
		Set<ValidationMessage> erroPreenchimentoObrigatorio = validaPreenchimentoObrigatorioCamposDasDistribuicoes(form);
		if(!erroPreenchimentoObrigatorio.isEmpty())
			return new ArrayList<ValidationMessage>(erroPreenchimentoObrigatorio);
		
		Optional<ValidationMessage> erroSomaPercentuaisCedido = validaSomaPercentuaisCedido(form);
		if(erroSomaPercentuaisCedido.isPresent())
			return Arrays.asList(erroSomaPercentuaisCedido.get());			
		
		return new ArrayList<ValidationMessage>();
	}
	
	public Set<ValidationMessage> validaPreenchimentoObrigatorioCamposDasDistribuicoes(ResseguroFacultativoForm form){
		Set<ValidationMessage> messages = new HashSet<>();
		
		for (ResseguroFacultativoCessaoForm cessao : form.getResseguroFacultativoCessaoList()) {
			for(ResseguroFacultativoFaixaForm faixa : cessao.getResseguroFacultativoFaixaList()){
				BigInteger codigoRessegurador = faixa.getCodigoRessegurador();
				BigDecimal percentualComissaoRessegurador = faixa.getPercentualComissaoRessegurador();
				BigDecimal percentualParticipacao = faixa.getPercentualParticipacao();
				BigDecimal valorPremioRessegurador = faixa.getValorPremioRessegurador();
				
				if(codigoRessegurador == null)
					messages.add(new ValidationMessage("O ressegurador é obrigatório", Type.ERROR));
				
				if(percentualComissaoRessegurador == null || !maiorOuIgualAZero(percentualComissaoRessegurador))
					messages.add(new ValidationMessage("O percentual de comissão do ressegurador é obrigatório", Type.ERROR));
				
				if(percentualParticipacao == null || !maiorOuIgualAZero(percentualParticipacao))
					messages.add(new ValidationMessage("O percentual de participação é obrigatório", Type.ERROR));
				
				if(valorPremioRessegurador == null || !maiorOuIgualAZero(valorPremioRessegurador))
					messages.add(new ValidationMessage("O prêmio de resseguro é obrigatório", Type.ERROR));
			}
		}
		
		return messages;
	}
	
	public Optional<ValidationMessage> validaSomaPercentuaisCedido(ResseguroFacultativoForm form){		
		for (ResseguroFacultativoCessaoForm cessao : form.getResseguroFacultativoCessaoList()) {
			BigDecimal somaPercentuaisParticipacao = cessao.getResseguroFacultativoFaixaList().stream().map(ResseguroFacultativoFaixaForm::getPercentualParticipacao).reduce(BigDecimal.ZERO, BigDecimal::add);
			if(!cessao.getPercentualCedido().equals(somaPercentuaisParticipacao))
				return Optional.of(new ValidationMessage("A soma dos percentuais de participação para uma faixa deve ser igual à porcentagem cedido em resseguro para esta faixa", Type.ERROR));
		}
		
		return Optional.empty();
	}
	
	public Optional<ValidationMessage> validaFaixasComDistribuicoes(ResseguroFacultativoForm form){
		for (ResseguroFacultativoCessaoForm cessao : form.getResseguroFacultativoCessaoList()) {
			List<ResseguroFacultativoFaixaForm> faixas = cessao.getResseguroFacultativoFaixaList();
			
			if(faixas == null || faixas.isEmpty())
				return Optional.of(new ValidationMessage("Todas as faixas de limite devem constar nas distribuiçoes e todas as distribuições devem possuir faixa", Type.ERROR));
		}
		
		return Optional.empty();
	}

	private boolean maiorOuIgualAZero(BigDecimal valor) {
		return valor.compareTo(BigDecimal.ZERO) >= 0;
	}

	private boolean menorDoQue(BigDecimal valorMenor, BigDecimal valorMaior) {
		return valorMenor.compareTo(valorMaior) < 0;
	}

	private boolean menorOuIgualA(BigDecimal valor1, BigDecimal valor2) {
		return valor1.compareTo(valor2) <= 0;
	}

}
