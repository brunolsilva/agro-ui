package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.dto.ListOfItemBeneficiarioView;
import br.com.tokiomarine.ctpj.cotacao.service.BeneficiarioService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.FranquiaService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ControllerInternalErrorException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.mapper.ItemBeneficiarioMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

/**
 * @author Hromenique Cezniowscki Leite Batista
 */
@Controller
@RequestMapping("/beneficiario/{seqCotacao}")
public class BeneficiarioController {	

	@Autowired
	private FranquiaService franquiaService;
	@Autowired
	private BeneficiarioService beneficiarioService;	
	@Autowired
	private ItemBeneficiarioMapper itemBenefMapper;	
	@Autowired
	private CotacaoService cotacaoService;
	@Autowired
	private PerfilComercialService perfilComercialService;
	
	private static Logger logger = LogManager.getLogger(BeneficiarioController.class);
	
	@GetMapping
	public String home(@PathVariable BigInteger seqCotacao, Model model){
		List<ItemCotacao> itens;
		try {
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(seqCotacao);
			itens = franquiaService.getItemsComEndereco(seqCotacao);
			model.addAttribute("cabecalhoCotacao",cotacaoView);
			model.addAttribute("readOnly",isReadOnly(cotacaoView));
		} catch (ServiceException e) {
			throw new ControllerInternalErrorException(e);
		}		
		
		model.addAttribute("seqCotacao", seqCotacao);
		model.addAttribute("itensCotacao", itens);
		
		return Paginas.beneficiario.value(); 
	}
	
	private boolean isReadOnly(CotacaoView cotacaoView) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario) && !cotacaoView.getCodigoSituacaoReadOnly().equals(CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao().intValue());
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se � usu�rio do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}
	
	@GetMapping("/itens")
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public List<ItemBeneficiarioView> listaItens(@PathVariable BigInteger seqCotacao){
		return getItensBeneficiarioView(seqCotacao);
	}
	
	@PostMapping("/itens")
	@ResponseStatus(HttpStatus.OK)
	public void salvaItem(@PathVariable BigInteger seqCotacao, @RequestBody @Valid ListOfItemBeneficiarioView itensView){		
		List<ItemBeneficiario> listOfItemBeneficiario = itemBenefMapper.toListOfItemBeneficiario(itensView);
		beneficiarioService.salvaItemBeneficiario(seqCotacao, listOfItemBeneficiario);		
	}
	
	@DeleteMapping("/itens/{idItemBeneficiario}")
	public ResponseEntity<Void> excluiItem(@PathVariable("idItemBeneficiario") BigInteger sequencialItemBeneficiario){
		beneficiarioService.excluiItemBeneficiario(sequencialItemBeneficiario);
		
		return ResponseEntity.ok().build();
	}
	
	@ModelAttribute(name="tiposPessoa")
	private List<TipoSeguradoEnum> getTipoPessoa(){
		return Arrays.asList(TipoSeguradoEnum.values());
	}
	
	private List<ItemBeneficiarioView> getItensBeneficiarioView(BigInteger idCotacao) {
		List<ItemBeneficiario> itens = beneficiarioService.listaItensBeneficiario(idCotacao);
		List<ItemBeneficiarioView> itensView = itemBenefMapper.toListOfItemBeneficiarioView(itens);
		return itensView;
	}
	
	
}
