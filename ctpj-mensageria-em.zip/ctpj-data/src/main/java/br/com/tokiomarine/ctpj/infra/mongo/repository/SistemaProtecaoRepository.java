package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.SistemaProtecao;

@Repository
public class SistemaProtecaoRepository {
	@Autowired
	private MongoTemplate mongoTemplate;
	
	public List<SistemaProtecao> findListIncendio(Integer produto, Sort sort){
		return mongoTemplate.find(
				query(
						where("tipoProtecional").is("I")
						.and("produto").is(produto)
						.and("ativo").in("S"))
				.with(sort)
				,SistemaProtecao.class);
	}
	
	public List<SistemaProtecao> findListRoubo(Integer produto, Sort sort){
		return mongoTemplate.find(
				query(
						where("tipoProtecional").is("R")
						.and("produto").is(produto)
						.and("ativo").in("S"))
				.with(sort)
				,SistemaProtecao.class);
	}
	
	public List<SistemaProtecao> findAll(Integer produto, Sort sort){
		return mongoTemplate.find(
				query(
						where("produto").is(produto)
						.and("ativo").in("S"))
				.with(sort)
				,SistemaProtecao.class);
	}
}
