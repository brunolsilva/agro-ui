package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request;

import java.io.Serializable;
import java.util.List;

public class BannerCampanhaRequest implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 7450710544727499945L;
	private String dataCalculo;
	private Long codigoCorretor;
	private List<ProdutoBannerCampanhaRequest> listaProduto;
	
	public String getDataCalculo() {
		return dataCalculo;
	}
	
	public void setDataCalculo(String dataCalculo) {
		this.dataCalculo = dataCalculo;
	}
	
	public Long getCodigoCorretor() {
		return codigoCorretor;
	}
	
	public void setCodigoCorretor(Long codigoCorretor) {
		this.codigoCorretor = codigoCorretor;
	}
	
	public List<ProdutoBannerCampanhaRequest> getListaProduto() {
		return listaProduto;
	}
	
	public void setListaProduto(List<ProdutoBannerCampanhaRequest> listaProduto) {
		this.listaProduto = listaProduto;
	}
	
}
