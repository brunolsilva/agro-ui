package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;

@Repository
public class NotaCotacaoRepository extends BaseDAO{
	
	private static final Logger logger = LogManager.getLogger(NotaCotacaoRepository.class);
	
	
	@LogPerformance
	public void deleteNotaCotacao(BigInteger sequencialNotaCotacao) throws HibernateException{
		logger.info("Delete Nota Cotação");
		StringBuilder hql = new StringBuilder();
		hql.append(" delete NotaCotacao n ");
		hql.append(" where n.sequencialNotaCotacao = :sequencialNotaCotacao");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialNotaCotacao", sequencialNotaCotacao);
		query.executeUpdate();
	}
	
	@LogPerformance
	public void deleteItemNotaCotacao(BigInteger sequencialNotaCotacao) throws HibernateException{
		logger.info("Delete Nota Cotação");
		StringBuilder hql = new StringBuilder();
		hql.append(" delete ItemNota i ");
		hql.append(" where i.sequencialItemNota = :sequencialItemNota");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialItemNota", sequencialNotaCotacao);
		query.executeUpdate();
	}
	
	@LogPerformance
	public void saveNota(NotaCotacao notaCatacao) throws HibernateException {		
		Integer numeroNota = this.getNrNotaCotacao(notaCatacao.getNumeroCotacaoProposta(),notaCatacao.getVersaoCotacaoProposta());
		notaCatacao.setSequencialNotaControle(numeroNota);
		super.getCurrentSession().save(notaCatacao);
	}
	
	@LogPerformance
	public void saveItemNota(ItemNota  itemNota) throws HibernateException {
		BigInteger numeroNota = this.getNrItemNotaCotacao(itemNota.getNumeroCotacaoProposta(),itemNota.getVersaoCotacaoProposta());
		itemNota.setCodigoSequencia(numeroNota);
		super.getCurrentSession().save(itemNota);
	}
	
	@LogPerformance
	public void atualizaItemNota(ItemNota  itemNota) throws HibernateException {
		super.getCurrentSession().update(itemNota);
	}
	
	@LogPerformance
	public void atualizaNotaCotacao(NotaCotacao  notaCotacao) throws HibernateException {
		super.getCurrentSession().update(notaCotacao);
	}
	
	@LogPerformance
	public BigInteger getNrItemNotaCotacao(BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta)throws HibernateException{
		StringBuilder hql = new StringBuilder();
		hql.append(" select max(i.codigoSequencia) + 1 from ItemNota i ");
		hql.append(" where i.numeroCotacaoProposta = :numeroCotacaoProposta");
		hql.append(" and i.versaoCotacaoProposta = :versaoCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		query.setParameter("versaoCotacaoProposta", versaoCotacaoProposta);
		BigInteger numeroNota = (BigInteger) query.uniqueResult();
		
		if(numeroNota == null){
			numeroNota = BigInteger.ONE;
		}
		return numeroNota;
		
	}
	
	@LogPerformance
	public Integer getNrNotaCotacao(BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta)throws HibernateException{
		StringBuilder hql = new StringBuilder();
		hql.append(" select max(n.sequencialNotaControle) + 1 from NotaCotacao n ");
		hql.append(" where n.numeroCotacaoProposta = :numeroCotacaoProposta");
		hql.append(" and n.versaoCotacaoProposta = :versaoCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		query.setParameter("versaoCotacaoProposta", versaoCotacaoProposta);
		Integer numeroNota = (Integer) query.uniqueResult();
		
		if(numeroNota == null){
			numeroNota = 0;
		}
		return numeroNota;
		
	}
	
	@LogPerformance
	public NotaCotacao findNotaCotacaBySequencialNotaCotacao(BigInteger sequencialNotaCotacao) throws HibernateException{
		logger.info("Find Nota Cotação by sequencialNotaCotacao");
		StringBuilder hql = new StringBuilder();
		hql.append(" Select n from NotaCotacao n ");
		hql.append(" where n.sequencialNotaCotacao = :sequencialNotaCotacao");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialNotaCotacao", sequencialNotaCotacao);
		return (NotaCotacao) query.uniqueResult();
	}
	
	@LogPerformance
	public ItemNota findItemNotaBySequencialItemNota(BigInteger sequencialItemNota) throws HibernateException{
		logger.info("Find Item Nota Cotação by sequencialItemNota");
		StringBuilder hql = new StringBuilder();
		hql.append(" Select i from ItemNota i ");
		hql.append(" where i.sequencialItemNota = :sequencialItemNota");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialItemNota", sequencialItemNota);
		return (ItemNota) query.uniqueResult();
	}
	
	
	
	

}
