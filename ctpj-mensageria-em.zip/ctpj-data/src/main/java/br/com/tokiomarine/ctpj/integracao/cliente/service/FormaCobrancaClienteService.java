package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.math.BigInteger;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import br.com.tokiomarine.cliente.dto.FormaCobrancaCliente;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.type.ServicosClienteEnum;
import br.com.tokiomarine.ctpj.type.TipoCobrancaEnum;

@Service
public class FormaCobrancaClienteService extends BaseClienteService {
	
	private static final String TITULAR_PROPRIO_SEGURADO = "10";
	
	public FormaCobrancaCliente consultarFormaCobrancaCliente(Cotacao cotacao) {
		
		if(cotacao.getCodigoCliente() == null || cotacao.getIdFormaCobrancaPrimeiraParcela()==null || cotacao.getIdFormaCobranca()==null) {
			return null;
		}
		
		BigInteger idFormaCobranca = cotacao.getIdFormaCobrancaPrimeiraParcela();
		if(cotacao.getIdFormaCobrancaPrimeiraParcela().compareTo(cotacao.getIdFormaCobranca()) != 0) {
			idFormaCobranca = cotacao.getIdFormaCobranca();
		}
		
		return this.consultarFormaCobrancaCliente(cotacao.getCodigoCliente(), idFormaCobranca);
	}
	
	public FormaCobrancaCliente getFormaCobrancaClienteFromApolice(Apolice apolice) {
		BigInteger idFormaCobranca = apolice.getIdFrmCobPrimeira() != null ? BigInteger.valueOf(apolice.getIdFrmCobPrimeira()) : BigInteger.valueOf(apolice.getIdFrmCobDemais());
		
		return consultarFormaCobrancaCliente(Long.valueOf(apolice.getIdCliente()), idFormaCobranca);
	}
	
	public Boolean isDebitoTitularEqualsProprioSegurado(FormaCobrancaCliente formaCobranca) {
		return TipoCobrancaEnum.DEBITO_EM_CONTA.getId().equals(formaCobranca.getTpCobrc()) && formaCobranca.getTpPrntcTtlarCc().equals(TITULAR_PROPRIO_SEGURADO);
	}
	
	public Boolean isDebitoTitularNotEqualsProprioSegurado(FormaCobrancaCliente formaCobranca) {
		return TipoCobrancaEnum.DEBITO_EM_CONTA.getId().equals(formaCobranca.getTpCobrc()) && !formaCobranca.getTpPrntcTtlarCc().equals(TITULAR_PROPRIO_SEGURADO);
	}
	
	public FormaCobrancaCliente consultarFormaCobrancaCliente(Long codigoCliente, BigInteger idFormaCobranca) {
		
		
		FormaCobrancaCliente clienteResponse = null;
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.FORMA_COBRANCA
														, new Object[] {codigoCliente, idFormaCobranca});

			clienteResponse = restTemplate.getForObject(uri,FormaCobrancaCliente.class);	
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Consultar Forma Cobrança Cliente ",e);
		}
		return clienteResponse;
	}
	
	public List<FormaCobrancaCliente> consultarListaCobrancaCliente(Long codigoCliente) {
		
		
		FormaCobrancaCliente[] clienteResponse = null;
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.LISTA_COBRANCA
														, new Object[] {codigoCliente});

			clienteResponse = restTemplate.getForObject(uri,FormaCobrancaCliente[].class);	
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Listar Forma Cobrança Cliente ",e);
		}
		return Arrays.asList(clienteResponse);
	}
	
	
}
