package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.net.URI;

import org.springframework.stereotype.Service;

import br.com.tokiomarine.cliente.dto.persistencia.EmailCliente;
import br.com.tokiomarine.ctpj.type.ServicosClienteEnum;

@Service
public class EmailClienteService extends BaseClienteService {
	public EmailCliente consultarEmailCliente(Object[] parametros) {
		
		EmailCliente emailClienteResponse = null;
		try{
			
			URI uri = endpointBuilderService.obterUri(getParametroGeral(), ServicosClienteEnum.PESQUISAR_EMAIL_POR_CODIGO
														, parametros);

			emailClienteResponse =  restTemplate.getForObject(uri,EmailCliente.class);		
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Consultar Email do Cliente ",e);
		}
		return emailClienteResponse;
	}
}
