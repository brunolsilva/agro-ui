package br.com.tokiomarine.ctpj.integracao.cliente.request;

import java.io.Serializable;

public class FormaDevolucaoRequest implements Serializable {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long cdAgencDebitConta;
	 private Integer cdBanco;
	 private Long cdClien;
	 private String cdUsuroUltmaAlter;
	 private String dsNumberCrtao;
	 private String dtUltmaAlter;
	 private String dtVenctPrmraParcela;
	 private String dvCcDebitConta;
	 private Integer idDadosBcros;
	 private Integer idDadosCrtao;
	 private Long idFormaDevol;
	 private String idToken;
	 private String nmBandeira;
	 private String nmTtlarCc;
	 private String nmTtlarCrtao;
	 private Integer nrAnoVldadCrtao;
	 private Long nrCcDebitConta;
	 private Long nrCpfCnpjTtlarCc;
	 private Long nrCpfCnpjTtlarCrtao;
	 private Integer nrDiaPagtoFtura;
	 private Integer nrMesVldadCrtao;
	 private String tpDevol;
	 private String tpPesoaTtlarCc;
	 private String tpPesoaTtlarCrtao;
	public Long getCdAgencDebitConta() {
		return cdAgencDebitConta;
	}
	public void setCdAgencDebitConta(Long cdAgencDebitConta) {
		this.cdAgencDebitConta = cdAgencDebitConta;
	}
	public Integer getCdBanco() {
		return cdBanco;
	}
	public void setCdBanco(Integer cdBanco) {
		this.cdBanco = cdBanco;
	}
	public Long getCdClien() {
		return cdClien;
	}
	public void setCdClien(Long cdClien) {
		this.cdClien = cdClien;
	}
	public String getCdUsuroUltmaAlter() {
		return cdUsuroUltmaAlter;
	}
	public void setCdUsuroUltmaAlter(String cdUsuroUltmaAlter) {
		this.cdUsuroUltmaAlter = cdUsuroUltmaAlter;
	}
	public String getDsNumberCrtao() {
		return dsNumberCrtao;
	}
	public void setDsNumberCrtao(String dsNumberCrtao) {
		this.dsNumberCrtao = dsNumberCrtao;
	}
	public String getDtUltmaAlter() {
		return dtUltmaAlter;
	}
	public void setDtUltmaAlter(String dtUltmaAlter) {
		this.dtUltmaAlter = dtUltmaAlter;
	}
	public String getDtVenctPrmraParcela() {
		return dtVenctPrmraParcela;
	}
	public void setDtVenctPrmraParcela(String dtVenctPrmraParcela) {
		this.dtVenctPrmraParcela = dtVenctPrmraParcela;
	}
	public String getDvCcDebitConta() {
		return dvCcDebitConta;
	}
	public void setDvCcDebitConta(String dvCcDebitConta) {
		this.dvCcDebitConta = dvCcDebitConta;
	}
	public Integer getIdDadosBcros() {
		return idDadosBcros;
	}
	public void setIdDadosBcros(Integer idDadosBcros) {
		this.idDadosBcros = idDadosBcros;
	}
	public Integer getIdDadosCrtao() {
		return idDadosCrtao;
	}
	public void setIdDadosCrtao(Integer idDadosCrtao) {
		this.idDadosCrtao = idDadosCrtao;
	}
	public Long getIdFormaDevol() {
		return idFormaDevol;
	}
	public void setIdFormaDevol(Long idFormaDevol) {
		this.idFormaDevol = idFormaDevol;
	}
	public String getIdToken() {
		return idToken;
	}
	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}
	public String getNmBandeira() {
		return nmBandeira;
	}
	public void setNmBandeira(String nmBandeira) {
		this.nmBandeira = nmBandeira;
	}
	public String getNmTtlarCc() {
		return nmTtlarCc;
	}
	public void setNmTtlarCc(String nmTtlarCc) {
		this.nmTtlarCc = nmTtlarCc;
	}
	public String getNmTtlarCrtao() {
		return nmTtlarCrtao;
	}
	public void setNmTtlarCrtao(String nmTtlarCrtao) {
		this.nmTtlarCrtao = nmTtlarCrtao;
	}
	public Integer getNrAnoVldadCrtao() {
		return nrAnoVldadCrtao;
	}
	public void setNrAnoVldadCrtao(Integer nrAnoVldadCrtao) {
		this.nrAnoVldadCrtao = nrAnoVldadCrtao;
	}
	public Long getNrCcDebitConta() {
		return nrCcDebitConta;
	}
	public void setNrCcDebitConta(Long nrCcDebitConta) {
		this.nrCcDebitConta = nrCcDebitConta;
	}
	public Long getNrCpfCnpjTtlarCc() {
		return nrCpfCnpjTtlarCc;
	}
	public void setNrCpfCnpjTtlarCc(Long nrCpfCnpjTtlarCc) {
		this.nrCpfCnpjTtlarCc = nrCpfCnpjTtlarCc;
	}
	public Long getNrCpfCnpjTtlarCrtao() {
		return nrCpfCnpjTtlarCrtao;
	}
	public void setNrCpfCnpjTtlarCrtao(Long nrCpfCnpjTtlarCrtao) {
		this.nrCpfCnpjTtlarCrtao = nrCpfCnpjTtlarCrtao;
	}
	public Integer getNrDiaPagtoFtura() {
		return nrDiaPagtoFtura;
	}
	public void setNrDiaPagtoFtura(Integer nrDiaPagtoFtura) {
		this.nrDiaPagtoFtura = nrDiaPagtoFtura;
	}
	public Integer getNrMesVldadCrtao() {
		return nrMesVldadCrtao;
	}
	public void setNrMesVldadCrtao(Integer nrMesVldadCrtao) {
		this.nrMesVldadCrtao = nrMesVldadCrtao;
	}
	public String getTpDevol() {
		return tpDevol;
	}
	public void setTpDevol(String tpDevol) {
		this.tpDevol = tpDevol;
	}
	public String getTpPesoaTtlarCc() {
		return tpPesoaTtlarCc;
	}
	public void setTpPesoaTtlarCc(String tpPesoaTtlarCc) {
		this.tpPesoaTtlarCc = tpPesoaTtlarCc;
	}
	public String getTpPesoaTtlarCrtao() {
		return tpPesoaTtlarCrtao;
	}
	public void setTpPesoaTtlarCrtao(String tpPesoaTtlarCrtao) {
		this.tpPesoaTtlarCrtao = tpPesoaTtlarCrtao;
	}
	 
	 
}
