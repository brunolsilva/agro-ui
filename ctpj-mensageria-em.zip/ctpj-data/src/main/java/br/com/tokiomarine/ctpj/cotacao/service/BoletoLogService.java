package br.com.tokiomarine.ctpj.cotacao.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.exception.ServiceException;

@Service
@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = {ServiceException.class, Exception.class})
public class BoletoLogService extends CotacaoLogService {
	
	public void save(CotacaoLog cotacaoLog) throws ServiceException {
		super.save(cotacaoLog);
	}
}
