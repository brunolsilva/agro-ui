//package br.com.tokiomarine.ctpj.cotacao.service;
//
//import java.math.BigInteger;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
//import br.com.tokiomarine.ctpj.mapper.PedidoMapper;
//import br.com.tokiomarine.pedidodto.PedidoDTO;
//
//@Service
//public class PedidoService {
//	
//	@Autowired
//	protected SessionFactory sessionFactory;
//	
//	@Transactional
//	public PedidoDTO recuperaPedido(BigInteger seqCotacao){
//		Cotacao cotacao = getCurrentSession().get(Cotacao.class, seqCotacao);
//		return PedidoMapper.getInstance().toPedido(cotacao);
//	}
//	
//	private Session getCurrentSession() {
//		return sessionFactory.getCurrentSession();
//	}
//
//}
