package br.com.tokiomarine.ctpj.cotacao.validation;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.enums.PrazoVigenciaEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;

public class PrazoSeguroValidator {

	@Autowired
	private ProdutoRepository produtoRepository;
	
	public PrazoSeguroValidator() {
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}
	
	/**
	 * Valida o preenchimento do Prazo do Seguro de acordo com o Perfil e o Prazo do Seguro
	 * 
	 * @param cotacao
	 * @param listaValidacao
	 */
	public void validaPrazoDoSeguro(Cotacao cotacao, List<ValidacaoLote> listaValidacao) {
		GrupoUsuarioEnum grupoUsuario = ((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getGrupoUsuario();
		PrazoVigenciaEnum prazo = cotacao.getIdPrazoVigencia();
		
		if(prazo == PrazoVigenciaEnum.ANUAL) {
			validaPrazoAnual(cotacao,grupoUsuario,listaValidacao);
		} else if(prazo == PrazoVigenciaEnum.PRO_RATA) {
			validaPrazoProRata(cotacao,grupoUsuario,listaValidacao);
		} else if(prazo == PrazoVigenciaEnum.PRAZO_DIFERENCIADO) {
			validaPrazoDiferenciado(cotacao,grupoUsuario,listaValidacao);
		}
	}

	private void validaPrazoAnual(Cotacao cotacao, GrupoUsuarioEnum grupoUsuario, List<ValidacaoLote> listaValidacao) {
		LocalDate dataInicio = LocalDate.from(cotacao.getDataInicioVigencia().toInstant().atZone(ZoneId.systemDefault()));
		LocalDate dataFim = LocalDate.from(cotacao.getDataFimVigencia().toInstant().atZone(ZoneId.systemDefault()));

		if (grupoUsuario == GrupoUsuarioEnum.CORRETOR && dataInicio.isBefore(LocalDate.now())) {
			cotacao.setDataInicioVigencia(new Date());
			cotacao.setDataFimVigencia(DateUtils.addYears(new Date(),1));
			cotacao.getListItem().forEach(item -> {
				item.setDataInicioVigencia(cotacao.getDataInicioVigencia());
				item.setDataFimVigencia(cotacao.getDataFimVigencia());
			});
		}
		
		if (grupoUsuario == GrupoUsuarioEnum.CORRETOR) {
			int dias = produtoRepository.findDiasVigenciaFutura(cotacao.getIdTipoSeguro(), cotacao.getCodigoProduto());
			if(cotacao.getDataInicioVigencia().after(DateUtils.addDays(new Date(), dias))) {
				listaValidacao.add(new ValidacaoLote(0,"A data de início de vigência não pode ultrapassar " + dias + " dias corridos!"));
			}
		}
		
		if(cotacao.getDataAlteracao() != null) {
			LocalDate dataAlteracao = LocalDate.from(cotacao.getDataAlteracao().toInstant().atZone(ZoneId.systemDefault()));
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				validaDataAlteracao(listaValidacao, dataInicio, dataFim, dataAlteracao, cotacao.getCodigoTipoEndossoSCT());
			}
		}

		if(dataFim.isBefore(dataInicio)) {
			listaValidacao.add(new ValidacaoLote(0,"A Data de Término de Vigência não pode ser menor que Início!"));
		}
		
		if(dataFim.compareTo(dataInicio.plusYears(1))  != 0) {
			listaValidacao.add(new ValidacaoLote(0,"A Data de Término de Vigência deve ser exatamente um Ano após a Data de Início!"));
		}		
	}

	private void validaPrazoProRata(Cotacao cotacao, GrupoUsuarioEnum grupoUsuario, List<ValidacaoLote> listaValidacao) {
		LocalDate dataInicio = LocalDate.from(cotacao.getDataInicioVigencia().toInstant().atZone(ZoneId.systemDefault()));
		LocalDate dataFim = LocalDate.from(cotacao.getDataFimVigencia().toInstant().atZone(ZoneId.systemDefault()));

		if(cotacao.getDataAlteracao() != null) {
			LocalDate dataAlteracao = LocalDate.from(cotacao.getDataAlteracao().toInstant().atZone(ZoneId.systemDefault()));
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				validaDataAlteracao(listaValidacao, dataInicio, dataFim, dataAlteracao, cotacao.getCodigoTipoEndossoSCT());
			}
		}

		if (grupoUsuario == GrupoUsuarioEnum.CORRETOR && dataInicio.isBefore(LocalDate.now())) {
			listaValidacao.add(new ValidacaoLote(0,"A Data de Início de Vigência não pode ser menor que a Data Atual!"));
		}
		
		if(dataFim.isBefore(dataInicio)) {
			listaValidacao.add(new ValidacaoLote(0,"A Data de Término de Vigência não pode ser menor que Início!"));
		}
	}

	private void validaPrazoDiferenciado(Cotacao cotacao, GrupoUsuarioEnum grupoUsuario, List<ValidacaoLote> listaValidacao) {
		LocalDate dataInicio = LocalDate.from(cotacao.getDataInicioVigencia().toInstant().atZone(ZoneId.systemDefault()));
		LocalDate dataFim = LocalDate.from(cotacao.getDataFimVigencia().toInstant().atZone(ZoneId.systemDefault()));
		
		if(cotacao.getDataAlteracao() != null) {
			LocalDate dataAlteracao = LocalDate.from(cotacao.getDataAlteracao().toInstant().atZone(ZoneId.systemDefault()));
			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				validaDataAlteracao(listaValidacao, dataInicio, dataFim, dataAlteracao, cotacao.getCodigoTipoEndossoSCT());
			}
		}

		if (grupoUsuario == GrupoUsuarioEnum.CORRETOR && dataInicio.isBefore(LocalDate.now())) {
			listaValidacao.add(new ValidacaoLote(0,"A Data de Início de Vigência não pode ser menor que a Data Atual!"));
		}

		if(dataFim.isBefore(dataInicio)) {
			listaValidacao.add(new ValidacaoLote(0,"A Data de Término de Vigência não pode ser menor que Início!"));
		}
		
	}

	public void validaDataAlteracao(List<ValidacaoLote> listaValidacao, LocalDate dataInicio, LocalDate dataFim,
			LocalDate dataAlteracao, TipoEndossoSctEnum tipoEndosso) {
		if (TipoEndossoSctEnum.PRORROGACAO_VIGENCIA == tipoEndosso) {
			if (!((dataAlteracao.isAfter(dataInicio) || dataAlteracao.isEqual(dataInicio))
					&& (dataAlteracao.isBefore(dataFim) || dataAlteracao.isEqual(dataFim)))) {
				listaValidacao.add(new ValidacaoLote(0, "A data de alteração deve estar dentro da vigência"));
			}
		} else {
			if (!((dataAlteracao.isAfter(dataInicio) || dataAlteracao.isEqual(dataInicio))
					&& (dataAlteracao.isBefore(dataFim)))) {
				listaValidacao.add(new ValidacaoLote(0, "A data de alteração deve estar dentro da vigência"));
			}
		}
	}
}