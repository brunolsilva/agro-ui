package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ContaCorrenteGlobal;

@Repository
public class ContaCorrenteRepository extends BaseDAO {

	@SuppressWarnings("unchecked")
	public Set<ContaCorrenteGlobal> findContaCorrenteGlobal(BigInteger sequencialCotacaoProposta){
		StringBuilder hql = new StringBuilder();
		hql.append(" select ccg ");
		hql.append(" from 	ContaCorrenteGlobal ccg ");
		hql.append(" where  ccg.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		List<ContaCorrenteGlobal> ccgs = query.list();
		return new HashSet<>(ccgs);		
	}
	
	public ContaCorrenteGlobal update(ContaCorrenteGlobal ccg) {
		ccg = (ContaCorrenteGlobal) getCurrentSession().merge(ccg);
		getCurrentSession().flush();
		return ccg;
	}

	public ContaCorrenteGlobal save(ContaCorrenteGlobal ccg) {
		getCurrentSession().persist(ccg);
		return ccg;
	}
}
