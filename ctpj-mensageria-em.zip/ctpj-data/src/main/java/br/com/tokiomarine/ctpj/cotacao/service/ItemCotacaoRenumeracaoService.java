package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.RenumeracaoItem;
import br.com.tokiomarine.ctpj.cotacao.form.RenumeracaoItensForm;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCotacaoRenumeracaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@Service
@Transactional(noRollbackFor = {ServiceException.class})
public class ItemCotacaoRenumeracaoService {

	private static Logger logger = LogManager.getLogger(ItemCotacaoRenumeracaoService.class);

	private static BigInteger NR_ITEM = BigInteger.ONE;

	@Autowired
	private ItemCotacaoRenumeracaoRepository itemCotacaoRenumeracaoRepository;

	@Autowired
	private CotacaoService cotacaoService;

	@LogPerformance
	public void backupNumeracaoItemCotacao(RenumeracaoItensForm form) throws ServiceException {
		try {
			Cotacao cotacao = cotacaoService.findCotacaoComItemRenumeracao(form.getSequencialCotacaoProposta());
			BigInteger maxNumeroItem = itemCotacaoRenumeracaoRepository.maxNumeroItemCotacao(form.getSequencialCotacaoProposta());

			List<ItemCotacao> listAuxItemCotacao = new ArrayList<ItemCotacao>();

			itemCotacaoRenumeracaoRepository.evict(cotacao);

			for (ItemCotacao itemCotacaoAtual : cotacao.getListItem()) {

				if (itemCotacaoAtual.getNumeroItem().compareTo(NR_ITEM) == 0 && cotacao.getIdLmiUnico().getId().equals(SimNaoEnum.SIM.getId())) {
					continue;
				}

				itemCotacaoAtual.setNumeroItemRenumeracao(itemCotacaoAtual.getNumeroItem());
				itemCotacaoAtual.setNumeroItem(itemCotacaoAtual.getNumeroItem().add(maxNumeroItem));
				itemCotacaoAtual.setUsuarioAtualizacao(form.getUser().getCdUsuro().longValue());
				itemCotacaoAtual.setCodigoGrupo(form.getUser().getGrupoUsuario().getCdGrp());
				listAuxItemCotacao.add(itemCotacaoAtual);

			}

			itemCotacaoRenumeracaoRepository.updateItemCotacao(listAuxItemCotacao);
		} catch (Exception e) {
			logger.error("Erro ao relizar backup do número do item cotação ",e);
			throw new ServiceException("Erro geral ao relizar backup do número do item cotação",e);
		}
	}

	@LogPerformance
	public void renumeraItemCotacao(RenumeracaoItensForm form) throws ServiceException {

		Cotacao cotacao = null;

		try {

			cotacao = cotacaoService.findCotacaoComItemRenumeracao(form.getSequencialCotacaoProposta());

			List<ItemCotacao> newListItemCotacao = new ArrayList<ItemCotacao>();
			
			

			for (RenumeracaoItem renumeracaoItem : form.getItensRenumeracao()) {

				if (renumeracaoItem.getSequencialItemCotacao() == null) {
					continue;
				}
				
				Iterator<ItemCotacao> iterator = cotacao.getListItem().iterator();
				
				 while(iterator.hasNext()){
					 
					 ItemCotacao itemCotacaoAtual = iterator.next();
					 iterator.remove();
					

					/*
					 * LMI - item 1 não pode ser renumerado
					 */
					if (itemCotacaoAtual.getNumeroItem().compareTo(NR_ITEM) == 0 && cotacao.getIdLmiUnico().getId().equals(SimNaoEnum.SIM.getId())) {
						newListItemCotacao.add(itemCotacaoAtual);
						continue;
					}

					if (renumeracaoItem.getSequencialItemCotacao().equals(itemCotacaoAtual.getSequencialItemCotacao()) && renumeracaoItem.isExcluiItem()) {
						itemCotacaoRenumeracaoRepository.deleteItemCotacao(itemCotacaoAtual);
						break;
					}

					if (renumeracaoItem.getSequencialItemCotacao().equals(itemCotacaoAtual.getSequencialItemCotacao())) {
						itemCotacaoAtual.setNumeroItem(renumeracaoItem.getNovoNumeroItem());
						itemCotacaoAtual.setNumeroItemRenumeracao(null);
						newListItemCotacao.add(itemCotacaoAtual);
						break;
					}
				}
			}

			itemCotacaoRenumeracaoRepository.updateItemCotacao(newListItemCotacao);

		} catch (Exception e) {
			logger.error("Erro ao renumerar item cotação ",e);
			throw new ServiceException("Erro geral ao renumerar item cotação",e);
		}

	}

}
