package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.RecebimentoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ControleFichaRegistrada;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.enums.TipoRecebimentoEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.BancoRepository;
import br.com.tokiomarine.ctpj.integracao.ficharegistrada.response.PagamentoAntecipadoResponse;
import br.com.tokiomarine.ctpj.integracao.scr.request.BoletoGenericoResponse;
import br.com.tokiomarine.ctpj.integracao.ssv.response.GerarRegistrarBoletoResponse;

@Service
@Transactional
public class RecebimentoService {

	private static Logger logger = LogManager.getLogger(RecebimentoService.class);

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private RecebimentoRepository recebimentoRepository;

	@Autowired
	private BancoRepository bancoRepository;
	
	public Recebimento bindRecebimentoByGeracaoBoleto(Cotacao cotacao,User user,OpcaoParcelamento opcaoParcelamento,ControleFichaRegistrada controleFicha,PagamentoAntecipadoResponse pagamentoAntecipado) throws ServiceException {
		Recebimento recebimento = new Recebimento();
		try {

			recebimento.setCotacao(cotacao);
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));

			Long count = this.countRecebimentoBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			if (count.equals(0L)) {
				count = 1L;
			} else {
				count++;
			}
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setSequencialControleRecebimento(count.intValue());
			recebimento.setIdTipoRecebimento(TipoRecebimentoEnum.FICHA_COMPENSACAO);
			recebimento.setNumeroBancoRecebimento(cotacao.getNumeroBancoBoleto());
			recebimento.setNumeroAgenciaRecebimento(pagamentoAntecipado.getCodigoAgencia());
			recebimento.setNumeroContaCorrenteRecebimento(pagamentoAntecipado.getCodigoContaCorrente());
			recebimento.setValorRecebimento(opcaoParcelamento.getValorPrimeiraParcela());
			recebimento.setNumeroFichaDeposito(controleFicha.getNossoNumero());
			recebimento.setDataProcessoCobranca(opcaoParcelamento.getDataVencimentoParcela());
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			recebimento.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			recebimento.setDataAtualizacao(new Date());
			recebimento.setNumeroParcela(1);
			recebimento.setIdTipoCredito(TipoCreditoEnum.BOLETO_GERADO);
		} catch (Exception e) {  
			logger.error("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto",e);
			throw new ServiceException("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto ",e);
		}
		return recebimento;
	}
	
	@LogPerformance
	public void saveRecebimentoByGeracaoBoletoSsv(Cotacao cotacao,User user,OpcaoParcelamento opcaoParcelamento,ControleFichaRegistrada controleFicha,
			GerarRegistrarBoletoResponse boletoResponse) throws ServiceException {
		
		try {

			Recebimento recebimento = new Recebimento();
			recebimento.setCotacao(cotacao);
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));

			Long count = this.countRecebimentoBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			if (count.equals(0L)) {
				count = 1L;
			} else {
				count++;
			}
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setSequencialControleRecebimento(count.intValue());
			recebimento.setIdTipoRecebimento(TipoRecebimentoEnum.FICHA_COMPENSACAO);
			recebimento.setNumeroBancoRecebimento(cotacao.getNumeroBancoBoleto());
			//recebimento.setNumeroAgenciaRecebimento(pagamentoAntecipado.getCodigoAgencia());
			//recebimento.setNumeroContaCorrenteRecebimento(pagamentoAntecipado.getCodigoContaCorrente());
			recebimento.setValorRecebimento(opcaoParcelamento.getValorPrimeiraParcela());
			recebimento.setNumeroFichaDeposito(controleFicha.getNossoNumero());
			recebimento.setDataProcessoCobranca(opcaoParcelamento.getDataVencimentoParcela());
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());			
			recebimento.setDataAtualizacao(new Date());
			recebimento.setNumeroParcela(1);
			recebimento.setIdTipoCredito(TipoCreditoEnum.BOLETO_GERADO);
			
			this.save(recebimento);
			
		} catch (Exception e) {  
			logger.error("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto",e);
			throw new ServiceException("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto ",e);
		}
	}

	@LogPerformance
	public void saveRecebimentoByGeracaoBoletoScr(Cotacao cotacao,User user,OpcaoParcelamento opcaoParcelamento,ControleFichaRegistrada controleFicha) throws ServiceException {
		
		try {

			Recebimento recebimento = new Recebimento();
			recebimento.setCotacao(cotacao);
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));

			Long count = this.countRecebimentoBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			if (count.equals(0L)) {
				count = 1L;
			} else {
				count++;
			}
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setSequencialControleRecebimento(count.intValue());
			recebimento.setIdTipoRecebimento(TipoRecebimentoEnum.FICHA_COMPENSACAO);
			recebimento.setNumeroBancoRecebimento(cotacao.getNumeroBancoBoleto());
			//recebimento.setNumeroAgenciaRecebimento(pagamentoAntecipado.getCodigoAgencia());
			//recebimento.setNumeroContaCorrenteRecebimento(pagamentoAntecipado.getCodigoContaCorrente());
			recebimento.setValorRecebimento(opcaoParcelamento.getValorPrimeiraParcela());
			recebimento.setNumeroFichaDeposito(controleFicha.getNossoNumero());
			recebimento.setDataProcessoCobranca(opcaoParcelamento.getDataVencimentoParcela());
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());			
			recebimento.setDataAtualizacao(new Date());
			recebimento.setNumeroParcela(1);
			recebimento.setIdTipoCredito(TipoCreditoEnum.BOLETO_GERADO);
			
			this.save(recebimento);
			
		} catch (Exception e) {  
			logger.error("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto",e);
			throw new ServiceException("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto ",e);
		}
	}

	@LogPerformance
	public Recebimento getRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws ServiceException {
		logger.info("Buscando Recebimento by sequencial cotacao");
		try {
			return recebimentoRepository.getRecebimentoBySequencialCotacaoProposta(sequencialCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Recebimento");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao buscar Recebimento ",e);
			throw new ServiceException("Erro geral ao buscar Recebimento ",e);
		}
	}
	
	@LogPerformance
	public Recebimento getRecebimentoByNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) throws ServiceException {
		logger.info("Buscando Recebimento by numero cotacao proposta");
		try {
			return recebimentoRepository.getRecebimentoByNumeroCotacaoProposta(numeroCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Recebimento");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao buscar Recebimento ",e);
			throw new ServiceException("Erro geral ao buscar Recebimento ",e);
		}
	}
	
	//getRecebimentoByNumeroCotacaoProposta

	@LogPerformance
	public Long getSequencialRecebimentoOffLine() throws ServiceException {
		logger.info("Buscando getSequencialRecebimentoOffLine");
		try {
			return recebimentoRepository.getSequencialRecebimentoOffLine();
		} catch (HibernateException h) {
			logger.error("Erro ao buscar getSequencialRecebimentoOffLine");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao buscar getSequencialRecebimentoOffLine ",e);
			throw new ServiceException("Erro geral ao buscar getSequencialRecebimentoOffLine ",e);
		}
	}

	@LogPerformance
	public void save(Recebimento recebimento) throws ServiceException {
		logger.info("Salvando Recebimento");
		try {
			recebimento.setDataAtualizacao(Calendar.getInstance().getTime());
			recebimentoRepository.save(recebimento);
		} catch (HibernateException h) {
			logger.error("Erro ao Salvar Recebimento");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Salvar Recebimento ",e);
			throw new ServiceException("Erro geral ao Salvar Recebimento ",e);
		}

	}

	@LogPerformance
	public Long countRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws ServiceException {
		logger.info("Count Recebimento");
		try {
			return recebimentoRepository.countRecebimentoBySequencialCotacaoProposta(sequencialCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao executar Count do Recebimento por Sequencial da Cotacao");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao executar Count do Recebimento por Sequencial da Cotacao",e);
			throw new ServiceException("Erro geral ao executar Count do Recebimento por Sequencial da Cotacao ",e);
		}

	}

	public Set<Recebimento> findRecebimentoBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			Set<Recebimento> listRecebimento = new HashSet<Recebimento>(cotacaoRepository.findCotacaoRecebimentoBySequencialCotacaoProposta(sequencialCotacaoProposta)); 
			for (Recebimento recebimento : listRecebimento){
				if (recebimento.getNumeroBancoRecebimento() != null){
					recebimento.setNomeBancoRecebimento(bancoRepository.findBancoByCodigo(recebimento.getNumeroBancoRecebimento().longValue()).getDescricao());
				}
			}
			return listRecebimento; 
		} catch (HibernateException h) {
			logger.error("Erro ao buscar lista de recebimento.");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao buscar lista de recebimento por sequencial da cotacao. ",e);
			throw new ServiceException("Erro geral ao buscar lista de recebimento por sequencial da cotacao. ",e);
		}
	}
	
	public Recebimento findRecebimentoByNumeroCotacaoProposta(Cotacao cotacao)
	{
		return recebimentoRepository.findRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());		
	}

	public Recebimento bindRecebimentoByDebito(Cotacao cotacao,User user,OpcaoParcelamento parcelamentoEscolhido,PagamentoAntecipadoResponse response) throws ServiceException {
		Recebimento recebimento = new Recebimento();
		try {

			recebimento.setCotacao(cotacao);
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));

			Long count = this.countRecebimentoBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			if (count.equals(0L)) {
				count = 1L;
			} else {
				count++;
			}
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setSequencialControleRecebimento(count.intValue());
			recebimento.setIdTipoRecebimento(TipoRecebimentoEnum.DEBITO_CONTA_CORRENTE);
			recebimento.setNumeroBancoRecebimento(cotacao.getNumeroBancoDebito());
			recebimento.setNumeroAgenciaRecebimento(response.getCodigoAgencia());
			recebimento.setNumeroContaCorrenteRecebimento(response.getCodigoContaCorrente());
			recebimento.setValorRecebimento(parcelamentoEscolhido.getValorPrimeiraParcela());
			recebimento.setNumeroFichaDeposito(response.getNrTituloMovimento().toString());
			recebimento.setDataProcessoCobranca(parcelamentoEscolhido.getDataVencimentoParcela());
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			recebimento.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			recebimento.setDataAtualizacao(new Date());
			recebimento.setNumeroParcela(1);
			recebimento.setIdTipoCredito(TipoCreditoEnum.DEBITO_AGENDADO);
		} catch (Exception e) {  
			logger.error("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto",e);
			throw new ServiceException("Erro geral ao realizar o Bind getRecebimentoByGeracaoBoleto ",e);
		}
		return recebimento;
	}

	public Recebimento bindRecebimentoByDebitoACX(Cotacao cotacao,User user,OpcaoParcelamento parcelamentoEscolhido,ControleFichaRegistrada controleFichaRegistrada) throws ServiceException {
		Recebimento recebimento = new Recebimento();
		try {

			recebimento.setCotacao(cotacao);
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));

			Long count = this.countRecebimentoBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			if (count.equals(0L)) {
				count = 1L;
			} else {
				count++;
			}
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setSequencialControleRecebimento(count.intValue());
			recebimento.setIdTipoRecebimento(TipoRecebimentoEnum.DEBITO_CONTA_CORRENTE);
			//recebimento.setNumeroBancoRecebimento(cotacao.getNumeroBancoDebito());
			//recebimento.setNumeroAgenciaRecebimento(response.getCodigoAgencia());
			//recebimento.setNumeroContaCorrenteRecebimento(response.getCodigoContaCorrente());
			recebimento.setValorRecebimento(parcelamentoEscolhido.getValorPrimeiraParcela());
			recebimento.setNumeroFichaDeposito(controleFichaRegistrada.getNossoNumero());
			recebimento.setDataProcessoCobranca(parcelamentoEscolhido.getDataVencimentoParcela());
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			recebimento.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			recebimento.setDataAtualizacao(new Date());
			recebimento.setNumeroParcela(1);
			recebimento.setIdTipoCredito(TipoCreditoEnum.DEBITO_AGENDADO);
		} catch (Exception e) {  
			logger.error("Erro geral ao realizar o Bind bindRecebimentoByDebitoACX",e);
			throw new ServiceException("Erro geral ao realizar o Bind bindRecebimentoByDebitoACX ",e);
		}
		return recebimento;
	}

	public Recebimento bindRecebimentoByCartaoACX(Cotacao cotacao,User user,OpcaoParcelamento parcelamentoEscolhido) throws ServiceException {
		Recebimento recebimento = new Recebimento();
		try {

			recebimento.setCotacao(cotacao);
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));

			Long count = this.countRecebimentoBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());

			if (count.equals(0L)) {
				count = 1L;
			} else {
				count++;
			}
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setSequencialControleRecebimento(count.intValue());
			recebimento.setIdTipoRecebimento(TipoRecebimentoEnum.CARTAO);
			recebimento.setValorRecebimento(parcelamentoEscolhido.getValorPrimeiraParcela());
			recebimento.setDataProcessoCobranca(parcelamentoEscolhido.getDataVencimentoParcela());
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			recebimento.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			recebimento.setDataAtualizacao(new Date());
			recebimento.setNumeroParcela(1);
			recebimento.setIdTipoCredito(TipoCreditoEnum.CARTAO);
		} catch (Exception e) {  
			logger.error("Erro geral ao realizar o Bind bindRecebimentoByCartaoACX",e);
			throw new ServiceException("Erro geral ao realizar o Bind bindRecebimentoByCartaoACX ",e);
		}
		return recebimento;
	}
}