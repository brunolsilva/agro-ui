package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.infra.domain.EndossoTipoAlteracao;
import br.com.tokiomarine.ctpj.infra.domain.EndossoTipoAlteracaoAgrupamento;
import br.com.tokiomarine.ctpj.infra.domain.EndossoTipoAlteracaoRamo;

@Repository
public class EndossoTipoAlteracaoRepository{

	@Autowired
	private MongoTemplate mongoTemplate;

	public EndossoTipoAlteracao findEndossoTipoAlteracao(Integer codigoTipoAlteracao) {

		EndossoTipoAlteracao endossoTipoAlteracao = mongoTemplate.findOne(
				query(
						where("codigo").is(codigoTipoAlteracao)
						), EndossoTipoAlteracao.class);

		return endossoTipoAlteracao;
	}

	public EndossoTipoAlteracaoAgrupamento findEndossoTipoAlteracaoAgrupamento(Integer codigoGrupoRamo,Integer codigoRamo, Integer codigoTipoAlteracao) {

		EndossoTipoAlteracaoAgrupamento endossoTipoAlteracaoAgrupamento = mongoTemplate.findOne(
				query(
						where("grupoRamo").is(codigoGrupoRamo)
						.and("ramo").is(codigoRamo)
						.and("tipoAlteracao").is(codigoTipoAlteracao)
						), EndossoTipoAlteracaoAgrupamento.class);

		return endossoTipoAlteracaoAgrupamento;
	}

	public EndossoTipoAlteracaoRamo findEndossoTipoAlteracaoRamo(Integer codigoGrupoRamo,Integer codigoRamo, Integer codigoTipoAlteracao) {

		EndossoTipoAlteracaoRamo endossoTipoAlteracaoRamo = mongoTemplate.findOne(
				query(
						where("grupoRamo").is(codigoGrupoRamo)
						.and("ramo").is(codigoRamo)
						.and("tipoAlteracao").is(codigoTipoAlteracao)
						), EndossoTipoAlteracaoRamo.class);

		return endossoTipoAlteracaoRamo;
	}
	
}
