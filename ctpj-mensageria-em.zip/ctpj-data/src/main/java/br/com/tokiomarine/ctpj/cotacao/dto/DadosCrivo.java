package br.com.tokiomarine.ctpj.cotacao.dto;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(content = Include.NON_NULL)
public class DadosCrivo {

	private String idCnae;
	private String operacao;
	private String retorno;
	private String idEvento;
	private String evento;
	private String bairro;
	private String cep;
	private String cidade;
	private String logradouro;
	private String atividade;
	private String razaoSocial;
	private String nrLogradouro;
	private String uf;
	private Integer idAtividadePrincipal;

	public String getIdCnae() {
		return idCnae;
	}

	public void setIdCnae(String idCnae) {
		this.idCnae = idCnae;
	}

	public String getOperacao() {
		return operacao;
	}

	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	public String getRetorno() {
		return retorno;
	}

	public void setRetorno(String retorno) {
		this.retorno = retorno;
	}

	public String getIdEvento() {
		return idEvento;
	}

	public void setIdEvento(String idEvento) {
		this.idEvento = idEvento;
	}

	public String getEvento() {
		return evento;
	}

	public void setEvento(String evento) {
		this.evento = evento;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getAtividade() {
		return atividade;
	}

	public void setAtividade(String atividade) {
		this.atividade = atividade;
	}

	public String getRazaoSocial() {
		if(!StringUtils.isBlank(razaoSocial)) {
			return StringUtils.substring(razaoSocial, 0, 50);
		}
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getNrLogradouro() {
		return nrLogradouro;
	}

	public void setNrLogradouro(String nrLogradouro) {
		this.nrLogradouro = nrLogradouro;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public Integer getIdAtividadePrincipal() {
		return idAtividadePrincipal;
	}

	public void setIdAtividadePrincipal(Integer idAtividadePrincipal) {
		this.idAtividadePrincipal = idAtividadePrincipal;
	}

	@Override
	public String toString() {
		return "DadosCrivo [idCnae=" + idCnae + ", operacao=" + operacao + ", retorno=" + retorno + ", idEvento=" + idEvento + ", evento=" + evento + ", bairro=" + bairro + ", cep=" + cep + ", cidade=" + cidade + ", logradouro=" + logradouro + ", atividade=" + atividade + ", razaoSocial="
				+ razaoSocial + ", nrLogradouro=" + nrLogradouro + ", uf=" + uf + ", idAtividadePrincipal=" + idAtividadePrincipal + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((atividade == null) ? 0 : atividade.hashCode());
		result = prime * result + ((bairro == null) ? 0 : bairro.hashCode());
		result = prime * result + ((cep == null) ? 0 : cep.hashCode());
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result + ((evento == null) ? 0 : evento.hashCode());
		result = prime * result + ((idAtividadePrincipal == null) ? 0 : idAtividadePrincipal.hashCode());
		result = prime * result + ((idCnae == null) ? 0 : idCnae.hashCode());
		result = prime * result + ((idEvento == null) ? 0 : idEvento.hashCode());
		result = prime * result + ((logradouro == null) ? 0 : logradouro.hashCode());
		result = prime * result + ((nrLogradouro == null) ? 0 : nrLogradouro.hashCode());
		result = prime * result + ((operacao == null) ? 0 : operacao.hashCode());
		result = prime * result + ((razaoSocial == null) ? 0 : razaoSocial.hashCode());
		result = prime * result + ((retorno == null) ? 0 : retorno.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DadosCrivo other = (DadosCrivo) obj;
		if (atividade == null) {
			if (other.atividade != null)
				return false;
		} else if (!atividade.equals(other.atividade))
			return false;
		if (bairro == null) {
			if (other.bairro != null)
				return false;
		} else if (!bairro.equals(other.bairro))
			return false;
		if (cep == null) {
			if (other.cep != null)
				return false;
		} else if (!cep.equals(other.cep))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (evento == null) {
			if (other.evento != null)
				return false;
		} else if (!evento.equals(other.evento))
			return false;
		if (idAtividadePrincipal == null) {
			if (other.idAtividadePrincipal != null)
				return false;
		} else if (!idAtividadePrincipal.equals(other.idAtividadePrincipal))
			return false;
		if (idCnae == null) {
			if (other.idCnae != null)
				return false;
		} else if (!idCnae.equals(other.idCnae))
			return false;
		if (idEvento == null) {
			if (other.idEvento != null)
				return false;
		} else if (!idEvento.equals(other.idEvento))
			return false;
		if (logradouro == null) {
			if (other.logradouro != null)
				return false;
		} else if (!logradouro.equals(other.logradouro))
			return false;
		if (nrLogradouro == null) {
			if (other.nrLogradouro != null)
				return false;
		} else if (!nrLogradouro.equals(other.nrLogradouro))
			return false;
		if (operacao == null) {
			if (other.operacao != null)
				return false;
		} else if (!operacao.equals(other.operacao))
			return false;
		if (razaoSocial == null) {
			if (other.razaoSocial != null)
				return false;
		} else if (!razaoSocial.equals(other.razaoSocial))
			return false;
		if (retorno == null) {
			if (other.retorno != null)
				return false;
		} else if (!retorno.equals(other.retorno))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		return true;
	}
}
