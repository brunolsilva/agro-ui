package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.service.DocStoreService;
import br.com.tokiomarine.ctpj.interfaceCSF.response.ResponseInterfaceCSF;
import br.com.tokiomarine.ctpj.print.service.CotacaoPrintService;
import br.com.tokiomarine.ctpj.print.service.DeclaracaoPrintService;
import br.com.tokiomarine.ctpj.print.service.PropostaPrintService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
public class CotacaoPrintController extends AbstractController {

	private static Logger logger = LogManager.getLogger(CotacaoPrintController.class);
	
	@Autowired
	private DocStoreService docStoreService;

	@Autowired
	private DeclaracaoPrintService declaracaoPrintService;
	
	@Autowired
	private CotacaoPrintService cotacaoPrintService;
	
	@Autowired
	private PropostaPrintService propostaPrintService;

	@LogPerformance
	@GetMapping(value = "/print/declaracao/{sequencialCotacaoProposta}")
	public String gerarImpressaoDeclaracao(@PathVariable BigInteger sequencialCotacaoProposta,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
		try {
			logger.info("Carregando impressão Declaração... " + sequencialCotacaoProposta);
			ResultadoREST<ResponseInterfaceCSF> resultado = declaracaoPrintService.gerarImpressaoDeclaracao(sequencialCotacaoProposta,SecurityUtils.getCurrentUser());
			if(!resultado.isSuccess()) {
				return "erros/erroImpressao";
			}
			return "redirect:" + docStoreService.getURLdownloadArqAnexoDocStore(resultado.getRetornoObj().getIdArquivoDoc());
		} catch (final Exception e) {
			model.put("mensagem",e.getMessage());
			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro ao imprimir a declaracao " + sequencialCotacaoProposta,e);
			return Paginas.error.value();
		}
	}
	
	@LogPerformance
	@GetMapping(value = "/print/cotacao/{sequencialCotacaoProposta}/{idImprimeCondicaoContratual}")
	public String gerarImpressaoCotacao(@PathVariable BigInteger sequencialCotacaoProposta, @PathVariable String idImprimeCondicaoContratual,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
		try {
			logger.info("Carregando impressão cotação... " + sequencialCotacaoProposta);
			ResultadoREST<ResponseInterfaceCSF> resultado = cotacaoPrintService.gerarImpressaoCotacao(sequencialCotacaoProposta,idImprimeCondicaoContratual,SecurityUtils.getCurrentUser());
			if(!resultado.isSuccess()) {
				return "erros/erroImpressao";
			}
			return "redirect:" +  docStoreService.getURLdownloadArqAnexoDocStore(resultado.getRetornoObj().getIdArquivoDoc());
		} catch (final Exception e) {
			model.put("mensagem",e.getMessage());
			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro ao imprimir a cotação " + sequencialCotacaoProposta,e);
			return Paginas.error.value();
		}
	}
	
	@LogPerformance
	@GetMapping(value = "/print/proposta/{sequencialCotacaoProposta}/{idImprimeCondicaoContratual}")
	public String gerarImpressaoProposta(@PathVariable BigInteger sequencialCotacaoProposta, @PathVariable String idImprimeCondicaoContratual,HttpServletRequest request,HttpServletResponse response,ModelMap model) throws ServiceException {
		try {
			logger.info("Carregando impressão Proposta... " + sequencialCotacaoProposta);
			ResultadoREST<ResponseInterfaceCSF> resultado = propostaPrintService.gerarImpressaoProposta(sequencialCotacaoProposta,idImprimeCondicaoContratual,SecurityUtils.getCurrentUser());
			if(!resultado.isSuccess() || resultado.getRetornoObj() == null) {
				return "erros/erroImpressao";
			}
			return "redirect:" + docStoreService.getURLdownloadArqAnexoDocStore(resultado.getRetornoObj().getIdArquivoDoc());
		} catch (final Exception e) {
			model.put("mensagem",e.getMessage());
			model.put("stacktrace",ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro ao imprimir a declaracao " + sequencialCotacaoProposta,e);
			return Paginas.error.value();
		}
	}	

	@GetMapping(value = "/print/validaDeclaracao")
	public ResponseEntity<?> gerarImpressaoProposta() {
		if(SecurityUtils.getCurrentUser() != null && SecurityUtils.getCurrentUser().getCdNivelAutz() >= 7) {
			return ResponseEntity.ok(true);
		}
		return ResponseEntity.ok(false);
	}
}
