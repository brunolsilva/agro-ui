package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

public class NotaCotacaoEIemForm implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private NotaCotacaoView nota;
	private ItemNotaView itemNota;
	
	public ItemNotaView getItemNota() {
		return itemNota;
	}
	
	public void setItemNota(ItemNotaView itemNota) {
		this.itemNota = itemNota;
	}

	
	public NotaCotacaoView getNota() {
		return nota;
	}

	
	public void setNota(NotaCotacaoView nota) {
		this.nota = nota;
	}
	
	
	
	
	

}
