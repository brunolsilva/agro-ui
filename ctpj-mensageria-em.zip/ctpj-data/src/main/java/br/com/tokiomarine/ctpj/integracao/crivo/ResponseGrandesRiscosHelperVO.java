
package br.com.tokiomarine.ctpj.integracao.crivo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de ResponseGrandesRiscosHelperVO complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conte�do esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="ResponseGrandesRiscosHelperVO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bairroSRF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cepSRF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cidadeSRF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codCNAE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codCNAECompleto" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codEvent" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codOperacao" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codReturn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dscEvent" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="idCache" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="logradrouSRF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nmAtividade" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nmRazaoSocial" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nrLogradouroSRF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="retChToken" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="tpSinistro" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ufSRF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResponseGrandesRiscosHelperVO", propOrder = {
    "bairroSRF",
    "cepSRF",
    "cidadeSRF",
    "codCNAE",
    "codCNAECompleto",
    "codEvent",
    "codOperacao",
    "codReturn",
    "dscEvent",
    "idCache",
    "logradrouSRF",
    "nmAtividade",
    "nmRazaoSocial",
    "nrLogradouroSRF",
    "retChToken",
    "tpSinistro",
    "ufSRF"
})
public class ResponseGrandesRiscosHelperVO {

    @XmlElement(required = true, nillable = true)
    protected String bairroSRF;
    @XmlElement(required = true, nillable = true)
    protected String cepSRF;
    @XmlElement(required = true, nillable = true)
    protected String cidadeSRF;
    @XmlElement(required = true, nillable = true)
    protected String codCNAE;
    @XmlElement(required = true, nillable = true)
    protected String codCNAECompleto;
    @XmlElement(required = true, nillable = true)
    protected String codEvent;
    @XmlElement(required = true, nillable = true)
    protected String codOperacao;
    @XmlElement(required = true, nillable = true)
    protected String codReturn;
    @XmlElement(required = true, nillable = true)
    protected String dscEvent;
    @XmlElement(required = true, nillable = true)
    protected String idCache;
    @XmlElement(required = true, nillable = true)
    protected String logradrouSRF;
    @XmlElement(required = true, nillable = true)
    protected String nmAtividade;
    @XmlElement(required = true, nillable = true)
    protected String nmRazaoSocial;
    @XmlElement(required = true, nillable = true)
    protected String nrLogradouroSRF;
    @XmlElement(required = true, nillable = true)
    protected String retChToken;
    @XmlElement(required = true, nillable = true)
    protected String tpSinistro;
    @XmlElement(required = true, nillable = true)
    protected String ufSRF;

    /**
     * Obt�m o valor da propriedade bairroSRF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBairroSRF() {
        return bairroSRF;
    }

    /**
     * Define o valor da propriedade bairroSRF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBairroSRF(String value) {
        this.bairroSRF = value;
    }

    /**
     * Obt�m o valor da propriedade cepSRF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCepSRF() {
        return cepSRF;
    }

    /**
     * Define o valor da propriedade cepSRF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCepSRF(String value) {
        this.cepSRF = value;
    }

    /**
     * Obt�m o valor da propriedade cidadeSRF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCidadeSRF() {
        return cidadeSRF;
    }

    /**
     * Define o valor da propriedade cidadeSRF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCidadeSRF(String value) {
        this.cidadeSRF = value;
    }

    /**
     * Obt�m o valor da propriedade codCNAE.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodCNAE() {
        return codCNAE;
    }

    /**
     * Define o valor da propriedade codCNAE.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodCNAE(String value) {
        this.codCNAE = value;
    }

    /**
     * Obt�m o valor da propriedade codCNAECompleto.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodCNAECompleto() {
        return codCNAECompleto;
    }

    /**
     * Define o valor da propriedade codCNAECompleto.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodCNAECompleto(String value) {
        this.codCNAECompleto = value;
    }

    /**
     * Obt�m o valor da propriedade codEvent.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodEvent() {
        return codEvent;
    }

    /**
     * Define o valor da propriedade codEvent.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodEvent(String value) {
        this.codEvent = value;
    }

    /**
     * Obt�m o valor da propriedade codOperacao.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodOperacao() {
        return codOperacao;
    }

    /**
     * Define o valor da propriedade codOperacao.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodOperacao(String value) {
        this.codOperacao = value;
    }

    /**
     * Obt�m o valor da propriedade codReturn.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodReturn() {
        return codReturn;
    }

    /**
     * Define o valor da propriedade codReturn.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodReturn(String value) {
        this.codReturn = value;
    }

    /**
     * Obt�m o valor da propriedade dscEvent.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDscEvent() {
        return dscEvent;
    }

    /**
     * Define o valor da propriedade dscEvent.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDscEvent(String value) {
        this.dscEvent = value;
    }

    /**
     * Obt�m o valor da propriedade idCache.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdCache() {
        return idCache;
    }

    /**
     * Define o valor da propriedade idCache.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdCache(String value) {
        this.idCache = value;
    }

    /**
     * Obt�m o valor da propriedade logradrouSRF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogradrouSRF() {
        return logradrouSRF;
    }

    /**
     * Define o valor da propriedade logradrouSRF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogradrouSRF(String value) {
        this.logradrouSRF = value;
    }

    /**
     * Obt�m o valor da propriedade nmAtividade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNmAtividade() {
        return nmAtividade;
    }

    /**
     * Define o valor da propriedade nmAtividade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNmAtividade(String value) {
        this.nmAtividade = value;
    }

    /**
     * Obt�m o valor da propriedade nmRazaoSocial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNmRazaoSocial() {
        return nmRazaoSocial;
    }

    /**
     * Define o valor da propriedade nmRazaoSocial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNmRazaoSocial(String value) {
        this.nmRazaoSocial = value;
    }

    /**
     * Obt�m o valor da propriedade nrLogradouroSRF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNrLogradouroSRF() {
        return nrLogradouroSRF;
    }

    /**
     * Define o valor da propriedade nrLogradouroSRF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNrLogradouroSRF(String value) {
        this.nrLogradouroSRF = value;
    }

    /**
     * Obt�m o valor da propriedade retChToken.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetChToken() {
        return retChToken;
    }

    /**
     * Define o valor da propriedade retChToken.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetChToken(String value) {
        this.retChToken = value;
    }

    /**
     * Obt�m o valor da propriedade tpSinistro.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTpSinistro() {
        return tpSinistro;
    }

    /**
     * Define o valor da propriedade tpSinistro.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTpSinistro(String value) {
        this.tpSinistro = value;
    }

    /**
     * Obt�m o valor da propriedade ufSRF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUfSRF() {
        return ufSRF;
    }

    /**
     * Define o valor da propriedade ufSRF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUfSRF(String value) {
        this.ufSRF = value;
    }

}
