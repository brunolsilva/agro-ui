package br.com.tokiomarine.ctpj.integracao.acsel.response;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ParcelamentoApoliceAcselResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -685531898857352829L;
	/**
	 * 
	 */
	@JsonProperty("codigo")
	private Integer codigo;
	@JsonProperty("mensagem")
	private String mensagem;
	@JsonIgnore
	private transient Map<String, Object> additionalProperties = new HashMap<>();

	@JsonProperty("codigo")
	public Integer getCodigo() {
		return codigo;
	}

	@JsonProperty("codigo")
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	@JsonProperty("mensagem")
	public String getMensagem() {
		return mensagem;
	}

	@JsonProperty("mensagem")
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
	

}
