package br.com.tokiomarine.ctpj.cotacao.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.service.AgenciaService;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.dadosconta.AgenciaVO;

@Controller
@RequestMapping("/agencia")
public class AgenciaController {
	
	@Autowired
	private AgenciaService agenciaService;
	
	@LogPerformance
	@GetMapping(value = "/consulta")
	public @ResponseBody AgenciaVO consultaAgencia(@RequestParam String nrAgencia, @RequestParam String nrBanco) throws ServiceException {
		return agenciaService.consultaAgencia(nrBanco, nrAgencia);
	}

}
