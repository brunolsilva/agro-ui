package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;

public class ProdutoValorCarac implements Serializable {

	private static final long serialVersionUID = -5852801292826234173L;

	private Integer produto;
	private Integer caracteristica;
	private Long valorCaracteristica;
	private String descricaoValor;
	private Long idKme;
	private boolean sugestao = false;

	public Integer getProduto() {
		return produto;
	}

	public void setProduto(Integer produto) {
		this.produto = produto;
	}

	public Integer getCaracteristica() {
		return caracteristica;
	}

	public void setCaracteristica(Integer caracteristica) {
		this.caracteristica = caracteristica;
	}

	public Long getValorCaracteristica() {
		return valorCaracteristica;
	}

	public void setValorCaracteristica(Long valorCaracteristica) {
		this.valorCaracteristica = valorCaracteristica;
	}

	public String getDescricaoValor() {
		return descricaoValor;
	}

	public void setDescricaoValor(String descricaoValor) {
		this.descricaoValor = descricaoValor;
	}

	
	
	
	public Long getIdKme() {
		return idKme;
	}

	
	public void setIdKme(Long idKme) {
		this.idKme = idKme;
	}
	

	public boolean isSugestao() {
		return sugestao;
	}

	public void setSugestao(boolean sugestao) {
		this.sugestao = sugestao;
	}

	@Override
	public String toString() {
		return "ValorCaracProdutoDTO [produto=" + produto + ", caracteristica=" + caracteristica +
				", valorCaracteristica=" + valorCaracteristica + ", descricaoValor=" + descricaoValor + "]";
	}
}