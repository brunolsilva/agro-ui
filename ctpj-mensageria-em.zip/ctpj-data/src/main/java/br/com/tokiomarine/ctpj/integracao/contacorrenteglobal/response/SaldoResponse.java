package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

public class SaldoResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 7554019016467590463L;
	private String dataValidade;
	private BigInteger idSaldo;
	private String nomeVerba;
	private String tipoVerba;
	private BigDecimal valorProvisionado;
	private BigDecimal valorSaldo;

	public String getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(String dataValidade) {
		this.dataValidade = dataValidade;
	}

	public BigInteger getIdSaldo() {
		return idSaldo;
	}

	public void setIdSaldo(BigInteger idSaldo) {
		this.idSaldo = idSaldo;
	}

	public String getNomeVerba() {
		return nomeVerba;
	}

	public void setNomeVerba(String nomeVerba) {
		this.nomeVerba = nomeVerba;
	}

	public String getTipoVerba() {
		return tipoVerba;
	}

	public void setTipoVerba(String tipoVerba) {
		this.tipoVerba = tipoVerba;
	}

	public BigDecimal getValorProvisionado() {
		return valorProvisionado;
	}

	public void setValorProvisionado(BigDecimal valorProvisionado) {
		this.valorProvisionado = valorProvisionado;
	}

	public BigDecimal getValorSaldo() {
		return valorSaldo;
	}

	public void setValorSaldo(BigDecimal valorSaldo) {
		this.valorSaldo = valorSaldo;
	}

}
