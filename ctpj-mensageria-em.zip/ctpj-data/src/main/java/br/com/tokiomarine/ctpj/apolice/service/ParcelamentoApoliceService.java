package br.com.tokiomarine.ctpj.apolice.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ParcelamentoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.SolicitanteEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SituacaoParcelamentoEnum;
import br.com.tokiomarine.ctpj.integracao.acsel.response.ParcelamentoApoliceAcselResponse;
import br.com.tokiomarine.ctpj.integracao.gestaoapolice.response.ParcelamentoApoliceResponse;
import br.com.tokiomarine.ctpj.integracao.gestaoapolice.service.GestaoApoliceService;
import br.com.tokiomarine.ctpj.integracao.service.CorretorBaseUnicaService;
import br.com.tokiomarine.ctpj.integracao.service.EndpointBuilderService;
import br.com.tokiomarine.ctpj.mapper.CorretorMapper;
import br.com.tokiomarine.ctpj.request.ParcelamentoApoliceRequest;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.type.RetornoREST;
import br.com.tokiomarine.ctpj.type.ServicosGestaoApoliceEnum;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.ctpj.util.RestTemplateUtil;
import br.com.tokiomarine.ctpj.util.StringUtil;

@Service
public class ParcelamentoApoliceService {
	
	private static Logger logger = LogManager.getLogger(ParcelamentoApoliceService.class);

	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired
	private EndpointBuilderService endpointBuilderService;
	
	@Autowired
	private GestaoApoliceService gestaoApoliceService;
		
	@Autowired
	private CorretorBaseUnicaService corretorBaseUnicaService;
	
	private RestTemplate restTemplate = RestTemplateUtil.restTemplate(30000);
	
	public ParcelamentoApolice findByPredicate(Cotacao cotacao, Predicate<ParcelamentoApolice> predicate) {
		Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
		if(apolice != null && apolice.getListParcelamentoApolice() != null && !apolice.getListParcelamentoApolice().isEmpty()) {
			Optional<ParcelamentoApolice> optParcelamentoApolice = apolice.getListParcelamentoApolice().stream()
																									   .filter(predicate)
																									   .findFirst();
			
			return optParcelamentoApolice.isPresent() ? optParcelamentoApolice.get() : null;
		}
		return null;
	}
	
	public Boolean isPagamentoPendente(Cotacao cotacao) {
		Predicate<ParcelamentoApolice> pagamentoPendente = p -> p.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE);
		return findByPredicate(cotacao, pagamentoPendente) != null;
	}
	
	public Boolean isPrimeiraParcelaPendente(Cotacao cotacao) {
		Predicate<ParcelamentoApolice> pagamentoPrimeiraParcelaPendente = p -> p.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE) && p.getNumeroParcela().equals(1);
		return findByPredicate(cotacao, pagamentoPrimeiraParcelaPendente) != null;
	}
	
	public Boolean isDemaisParcelasPendentes(Cotacao cotacao) {
		Predicate<ParcelamentoApolice> pagamentoDemaisParcelasPendente = p -> p.getIdSituacaoParcelamento().equals(SituacaoParcelamentoEnum.PENDENTE) && !p.getNumeroParcela().equals(1);
		return findByPredicate(cotacao, pagamentoDemaisParcelasPendente) != null;
	}
	
	/**
	 * 
	 * @param apolice
	 * @param solicitacaoCotacao
	 */
	public void atualizarParcelamentoApolice(Apolice apolice,SolicitacaoCotacao solicitacaoCotacao) {
		List<ParcelamentoApoliceResponse> listParcelamentoApoliceResponse = consultaParcelamento(apolice,solicitacaoCotacao);
		List<ParcelamentoApolice> listParcelamentoApolice = new ArrayList<>();
		if(listParcelamentoApoliceResponse != null && !listParcelamentoApoliceResponse.isEmpty()) {
			for(ParcelamentoApoliceResponse parcelamentoResponse : listParcelamentoApoliceResponse) {
				ParcelamentoApolice parcelamento = new ParcelamentoApolice();
				parcelamento.setCodigoRamoProduto(parcelamentoResponse.getCodigoRamoProduto());
				parcelamento.setCodigoApolice(parcelamentoResponse.getCodigoApolice());
				parcelamento.setCodigoTipoEndosso(parcelamentoResponse.getCodigoTipoEndosso());
				parcelamento.setCodigoEndosso(parcelamentoResponse.getCodigoEndosso());
				parcelamento.setNumeroParcela(parcelamentoResponse.getNumeroParcela());
				if(!StringUtils.isEmpty(parcelamentoResponse.getIdSituacaoParcelamento())) {
					parcelamento.setIdSituacaoParcelamento(SituacaoParcelamentoEnum.getBySiglaAcsel(parcelamentoResponse.getIdSituacaoParcelamento()));	
				}
				parcelamento.setDataVencimento(parcelamentoResponse.getDataVencimento());
				parcelamento.setValorParcela(parcelamentoResponse.getValorParcela());
				parcelamento.setValorJuros(parcelamentoResponse.getValorJuros());
				parcelamento.setValorCustoApolice(parcelamentoResponse.getValorCustoApolice());
				parcelamento.setValorIof(parcelamentoResponse.getValorIof());
				parcelamento.setDataRecebimento(parcelamentoResponse.getDataRecebimento());
				parcelamento.setValorRecebido(parcelamentoResponse.getValorRecebido());
				parcelamento.setValorJurosRecebido(parcelamentoResponse.getValorJurosRecebido());
				parcelamento.setValorIofRecebido(parcelamentoResponse.getValorIofRecebido());
				parcelamento.setCodigoFormaParcelamento(parcelamentoResponse.getCodigoFormaParcelamento());
				parcelamento.setCodigoFormaPagamento(parcelamentoResponse.getCodigoFormaPagamento());
				parcelamento.setCodigoEndosso(0);
				parcelamento.setIdPagador(parcelamentoResponse.getIdPagador());
				parcelamento.setCdFormaPagto(parcelamentoResponse.getCdFormaPagto());
				listParcelamentoApolice.add(parcelamento);
			}
			apolice.setListParcelamentoApolice(listParcelamentoApolice);
		}
	}
	
	/**
	 * atualiza os dados de pagamento da apólice
	 * @param cotacao
	 */
	public void atualizarParcelamentoApolice(Cotacao cotacao) {
		if(!CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly()) {
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			Corretor corretor = CorretorMapper.INSTANCE.fromCorretorBaseUnicaToCorretor(corretorBaseUnicaService.findCorretorByCodigo(Long.valueOf(apolice.getCodigoCorretorACSEL())));
			SolicitacaoCotacao solicitacaoCotacao = gestaoApoliceService.montarObjetoSolicitacaoCotacao(apolice, corretor);
			atualizarParcelamentoApolice(apolice, solicitacaoCotacao);		
			try {
				apoliceRepository.save(apolice);
			} catch (RepositoryException e) {
				logger.error("Ocorreu um erro ao salvar o parcelamento na apólice, sq cotac ppota "+cotacao.getSequencialCotacaoProposta(),e);
			}
		}
	}
	
	private List<ParcelamentoApoliceResponse> consultaParcelamento(Apolice apolice,SolicitacaoCotacao solicitacaoCotacao) {
		return consultaParcelamento(solicitacaoCotacao.getCdRamoPrdutApoliTmsrEndso(), solicitacaoCotacao.getCdApoliTmsrEndso(), solicitacaoCotacao.getCdEndosEndso());
	}
		
	public ParcelamentoApoliceAcselResponse consultaParcelamentoApolice(ParcelamentoApoliceRequest request){
		ParcelamentoApoliceAcselResponse response = new ParcelamentoApoliceAcselResponse();
		response.setCodigo(RetornoREST.sucesso.codigo());
		List<ParcelamentoApoliceResponse> parcelamentoApoliceResponse = null;
		try {
			if(TipoEndossoEnum.CANCELAMENTO_APOLICE.getId().equals(request.getIdTipoEndosso()) && SolicitanteEndossoEnum.MOTIVO_INTERNO.getId().equals(request.getIdSolicitanteEndosso())) {
				parcelamentoApoliceResponse = consultaParcelamento(request.getCodigoRamo(), request.getCodigoApolice(), null);
				if(parcelamentoApoliceResponse != null && !parcelamentoApoliceResponse.isEmpty()) {
					Optional<ParcelamentoApoliceResponse> optParcelamentoRecebido = parcelamentoApoliceResponse.stream().filter(p -> SituacaoParcelamentoEnum.RECEBIDO.getSiglaAcsel().equals(p.getIdSituacaoParcelamento())).findFirst();
					if(!optParcelamentoRecebido.isPresent()) {
						response.setMensagem("Não existe parcela paga para a apólice informada. Para o cancelamento de apólice por motivo interno é necessário ter parcelas pagas.");
					}
				}
			}			
		} catch(Exception e) {
			Integer codigoErro = 99;
			String mensagemErro = "Ocorreu um erro ao consultar parcelamento da apólice";
			StringBuilder sbErro = new StringBuilder();
			sbErro.append(mensagemErro);
			try {
				sbErro.append(" request: "+JacksonDatabindUtil.getInstance().bindObjectToJson(request));
			} catch (Exception e1) {
				logger.error(e1);
			}
					
			response.setCodigo(codigoErro);
			response.setMensagem(mensagemErro);
			logger.error(sbErro, e);
		}

		
		return response;
	}
	
	private List<ParcelamentoApoliceResponse> consultaParcelamento(Integer codigoRamo, Long codigoApolice, Long endosso) {
		ParcelamentoApoliceResponse[] parcelamentoApoliceResponse = null;
		List<ParcelamentoApoliceResponse> response = null;
		try {			
			//monta a request
			Map<String,Object> request = new HashMap<>();
			request.put("codRamoCli", codigoRamo);
			request.put("numApolice", codigoApolice);
			if(endosso != null) {
				request.put("numEndosso", endosso);
			}
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosGestaoApoliceEnum.CONSULTA_PARCELAMENTO);
			parcelamentoApoliceResponse = restTemplate.postForObject(uri, request, ParcelamentoApoliceResponse[].class);
			ajustarSituacaoParcelamento(parcelamentoApoliceResponse);
			response = Arrays.asList(parcelamentoApoliceResponse);
		} catch (Exception e) {
			logger.error("Erro na chamada do serviço de gestao apolice ao consultar parcelamento ", e);
			response = new ArrayList<>();
		}
		return response;
	}
	
	/**
	 * os parcelamentos com status ACF devem virar ACT (Pendente)
	 * @param response
	 */
	private void ajustarSituacaoParcelamento(ParcelamentoApoliceResponse[] response) {
		/*os parcelamentos com status ACF devem virar ACT (Pendente), foi feito o ajuste diretamente no retorno do serviço, pois caso o ajuste fosse feito
		 * no SituacaoParcelamentoEnum (acrescentando o ACT no item PENDENTE do enum) teríamos vários pontos de código alterados
		 */
		final String ACF = "ACF";
		final String ACT = "ACT";
		if(response != null && response.length > 0) {
			for(ParcelamentoApoliceResponse r : response) {
				if(!StringUtil.isEmptyOrNull(r.getIdSituacaoParcelamento()) && r.getIdSituacaoParcelamento().equals(ACF)) {
					r.setIdSituacaoParcelamento(ACT);
				}
			}
		}
	}

	private ParametroGeralEnum getParametroGeral() {
		return ParametroGeralEnum.getParametroServicoGestaoEmissao();
	}
}