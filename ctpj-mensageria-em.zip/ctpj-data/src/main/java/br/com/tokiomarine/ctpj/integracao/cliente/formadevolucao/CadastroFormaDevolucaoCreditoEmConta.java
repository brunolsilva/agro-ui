package br.com.tokiomarine.ctpj.integracao.cliente.formadevolucao;

import org.apache.commons.lang3.StringUtils;

import br.com.tokiomarine.cliente.dto.FormaDevolucaoCliente;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.integracao.cliente.request.FormaDevolucaoRequest;
import br.com.tokiomarine.ctpj.type.BancosEnum;

/**
 * cria a request para forma de devolução crédito em conta
 * 
 * @author T804294
 *
 */
public class CadastroFormaDevolucaoCreditoEmConta implements CadastroFormaDevolucao {

	private static final int SANTANDER = 0;
	private static final int DEMAIS_BANCOS = 1;
	
	@Override
	public FormaDevolucaoRequest bindToRequest(Cotacao cotacao,FormaDevolucaoCliente formaDevolucao,PropostaView propostaView) {
		FormaDevolucaoRequest request = new FormaDevolucaoRequest();
		CotacaoView cotacaoView = propostaView.getCotacao();
		request.setCdClien(cotacao.getCodigoCliente());
		request.setTpPesoaTtlarCc(cotacaoView.getTipoPessoaTitularContaCorrenteDevolucao().getId());
		request.setNrCpfCnpjTtlarCc(cotacaoView.getNumeroCNPJCPFTitularContaCorrenteDevolucao());
		request.setNmTtlarCc(cotacaoView.getNometitularContaCorrenteDevolucao());
		request.setCdBanco(cotacao.getNumeroBancoDevolucao());
		request.setCdAgencDebitConta(cotacao.getNumeroAgenciaDevolucao());
		request.setNrCcDebitConta(cotacao.getNumeroContaCorrenteDevolucao());
		request.setDvCcDebitConta(cotacao.getNumeroDigitoContaCorrenteDevolucao());
		if(cotacao.getNumeroBancoDevolucao().equals(BancosEnum.SANTANDER.codigo().intValue())) {
			request.setTpDevol(FormaDevolucaoApoliceEnum.CREDITO_CONTA.getTiposDevolucao().get(SANTANDER));	
		}
		else {
			request.setTpDevol(FormaDevolucaoApoliceEnum.CREDITO_CONTA.getTiposDevolucao().get(DEMAIS_BANCOS));
		}
		
		
		if(formaDevolucao != null) {
			request.setIdFormaDevol(formaDevolucao.getIdFormaDevol());
		}
		return request;
	}
	
	@Override
	public Boolean dadosValidos(Cotacao cotacao) {
		return cotacao.getNumeroBancoDevolucao() != null && 
			   cotacao.getNumeroAgenciaDevolucao() != null && 
			   cotacao.getNumeroContaCorrenteDevolucao() != null &&
			   !StringUtils.isEmpty(cotacao.getNumeroDigitoContaCorrenteDevolucao());
	}

}
