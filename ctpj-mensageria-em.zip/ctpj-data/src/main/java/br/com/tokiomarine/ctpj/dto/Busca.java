package br.com.tokiomarine.ctpj.dto;

public class Busca {

	boolean usaProcedure = false;

	public boolean isUsaProcedure() {
		return usaProcedure;
	}

	public void setUsaProcedure(boolean usaProcedure) {
		this.usaProcedure = usaProcedure;
	}

}
