package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import java.math.BigDecimal;
import java.math.BigInteger;

import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorMonetarioRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorPercentualRelatorio;
import br.com.tokiomarine.ctpj.cotacao.relatorios.formatadores.FormatadorStringRelatorio;

public class DadosDistribRessegLloyds {

	private static final FormatadorStringRelatorio FORMATADOR_STRING = new FormatadorStringRelatorio();
	private static final FormatadorMonetarioRelatorio FORMATADOR_MONETARIO = new FormatadorMonetarioRelatorio();
	private static final FormatadorPercentualRelatorio FORMATADOR_PERCENTUAL = new FormatadorPercentualRelatorio();
	
	private Integer faixa;
	private BigInteger codigoSusep;
	private String nome;
	private BigDecimal premioDeResseguro;
	private BigDecimal porcentagemDeParticipacao;
	private BigDecimal premioPorRessegurador;
	private BigDecimal porcentagemComissaoResseguro;
	private BigDecimal premioLiquidoPorRessegurador;

	public String getFormatedFaixa() {
		return FORMATADOR_STRING.asString(faixa);
	}

	public String getFormatedCodigoSusep() {
		return FORMATADOR_STRING.asString(codigoSusep);
	}

	public String getFormatedNome() {
		return FORMATADOR_STRING.asString(nome);
	}

	public String getFormatedPremioDeResseguro() {
		return FORMATADOR_MONETARIO.asMoney(premioDeResseguro);
	}

	public String getFormatedPorcentagemDeParticipacao() {
		return  FORMATADOR_PERCENTUAL.asPercent(porcentagemDeParticipacao);
	}

	public String getFormatedPorcentagemComissaoResseguro() {
		return FORMATADOR_PERCENTUAL.asPercent(porcentagemComissaoResseguro);
	}
	
	public String getFormatedPremioPorRessegurador(){
		return FORMATADOR_MONETARIO.asMoney(premioPorRessegurador);
	}
	
	public String getFormatedPremioLiquidoPorRessegurador(){
		return FORMATADOR_MONETARIO.asMoney(premioLiquidoPorRessegurador);
	}

	public void setFaixa(Integer faixa) {
		this.faixa = faixa;
	}

	public void setCodigoSusep(BigInteger codigoSusep) {
		this.codigoSusep = codigoSusep;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setPremioDeResseguro(BigDecimal premioDeResseguro) {
		this.premioDeResseguro = premioDeResseguro == null ? BigDecimal.ZERO : premioDeResseguro;
	}

	public void setPorcentagemDeParticipacao(BigDecimal porcentagemDeParticipacao) {
		this.porcentagemDeParticipacao = porcentagemDeParticipacao == null ? BigDecimal.ZERO : porcentagemDeParticipacao;
	}

	public void setPorcentagemComissaoResseguro(BigDecimal porcentagemComissaoResseguro) {
		this.porcentagemComissaoResseguro = porcentagemComissaoResseguro;
	}

	public static FormatadorStringRelatorio getFormatadorString() {
		return FORMATADOR_STRING;
	}

	public Integer getFaixa() {
		return faixa;
	}

	public BigInteger getCodigoSusep() {
		return codigoSusep;
	}

	public String getNome() {
		return nome;
	}

	public BigDecimal getPremioDeResseguro() {
		return premioDeResseguro;
	}

	public BigDecimal getPorcentagemDeParticipacao() {
		return porcentagemDeParticipacao;
	}

	public BigDecimal getPorcentagemComissaoResseguro() {
		return porcentagemComissaoResseguro;
	}

	public BigDecimal getPremioLiquidoPorRessegurador() {
		return premioLiquidoPorRessegurador;
	}

	public void setPremioLiquidoPorRessegurador(BigDecimal premioLiquidoPorRessegurador) {
		this.premioLiquidoPorRessegurador = premioLiquidoPorRessegurador;
	}

	public void setPremioPorRessegurador(BigDecimal premioPorRessegurador) {
		this.premioPorRessegurador = premioPorRessegurador;
	}

}
