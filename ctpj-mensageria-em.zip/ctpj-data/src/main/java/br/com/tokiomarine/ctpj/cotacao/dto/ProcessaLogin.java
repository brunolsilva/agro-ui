package br.com.tokiomarine.ctpj.cotacao.dto;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;

public class ProcessaLogin {

	private Cotacao cotacao;
	boolean sucesso;
	private StringBuilder mensagens;
	boolean endosso;
	private boolean bloqueada = false;
	private boolean exibeImpressos = true;
	private boolean possuiRestricaoCrivo = false;
	private Integer codigoRetornoCrivo = 0;
	

	public Cotacao getCotacao() {
		return cotacao;
	}

	public void setCotacao(Cotacao cotacao) {
		this.cotacao = cotacao;
	}

	public boolean isSucesso() {
		return sucesso;
	}

	public void setSucesso(boolean sucesso) {
		this.sucesso = sucesso;
	}

	public StringBuilder getMensagens() {
		return mensagens;
	}

	public void setMensagens(StringBuilder mensagens) {
		this.mensagens = mensagens;
	}

	public boolean isEndosso() {
		return endosso;
	}

	public void setEndosso(boolean endosso) {
		this.endosso = endosso;
	}

	public boolean isBloqueada() {
		return bloqueada;
	}

	public void setBloqueada(boolean bloqueada) {
		this.bloqueada = bloqueada;
	}

	public boolean isExibeImpressos() {
		return exibeImpressos;
	}

	public void setExibeImpressos(boolean exibeImpressos) {
		this.exibeImpressos = exibeImpressos;
	}

	public boolean isPossuiRestricaoCrivo() {
		return possuiRestricaoCrivo;
	}

	public void setPossuiRestricaoCrivo(boolean possuiRestricaoCrivo) {
		this.possuiRestricaoCrivo = possuiRestricaoCrivo;
	}

	public Integer getCodigoRetornoCrivo() {
		return codigoRetornoCrivo;
	}

	public void setCodigoRetornoCrivo(Integer codigoRetornoCrivo) {
		this.codigoRetornoCrivo = codigoRetornoCrivo;
	}
}
