package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemBeneficiarioApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemBeneficiarioService {

	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0119
	 */
	public void validarBeneficiario(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiBeneficiario = itemEndosso.getListItemBeneficiario() != null && !itemEndosso.getListItemBeneficiario().isEmpty();
		boolean itemApolicePossuiBeneficiario = itemApolice.getListItemBeneficiarioApolice() != null && !itemApolice.getListItemBeneficiarioApolice().isEmpty();
		
		//1 - percorre os beneficiarios do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiBeneficiario){			
			for(ItemBeneficiario itemEndossoBeneficiario : itemEndosso.getListItemBeneficiario()){
				boolean beneficiarioExiste = false;
				if(itemApolicePossuiBeneficiario){
					for(ItemBeneficiarioApolice itemApoliceBeneficiario : itemApolice.getListItemBeneficiarioApolice()){
						if(AssertUtils.compareNull(itemEndossoBeneficiario.getNumeroBeneficiario(),itemApoliceBeneficiario.getCdBeneficiario())){
							//valida tipo pessoa
							validacaoParametrosEndossoService.compararParametrosItem(
									(itemApoliceBeneficiario.getTipoPessoa() != null ? itemApoliceBeneficiario.getTipoPessoa().getId() : null),
									itemEndossoBeneficiario.getTipoPessoa() != null ? itemEndossoBeneficiario.getTipoPessoa().getId() : null,
									TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- Tipo Pessoa: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida cpf cnpj
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceBeneficiario.getNumeroCpfCnpj(), itemEndossoBeneficiario.getNumeroCPFCNPJ(), TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- CNPJ/CPF: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida nome pessoa
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceBeneficiario.getNomePessoa(), itemEndossoBeneficiario.getNomePessoa(), TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- Nome: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida percentual de participação
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceBeneficiario.getPercentualDistribuicao(), itemEndossoBeneficiario.getPercentualDistribuicao(), TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- %Participação: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida valor de participação
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceBeneficiario.getValorDistribuicao(), itemEndossoBeneficiario.getValorDistribuicao(), TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- Valor de Participação: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida valor de participação em dolar
							validacaoParametrosEndossoService.compararParametrosItem(itemApoliceBeneficiario.getValorDistribuicaoMoedaEstrangeira(), itemEndossoBeneficiario.getValorDistribuicaoMoedaEstrangeira(), TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- Valor de Participação em dólar: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida complemento
							validacaoParametrosEndossoService.compararParametrosItem(StringUtils.defaultIfBlank(itemApoliceBeneficiario.getDescricaoComplemento(),""), StringUtils.defaultIfBlank(itemEndossoBeneficiario.getDescricaoComplemento(),""), TipoMensagemEndossoEnum.ALT_BENEFICIARIO, "- Complemento: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							beneficiarioExiste = true;
							break;
						}						
					}
				}
				
				//se o beneficiario não existir
				if(!beneficiarioExiste){ 
					logarInclusaoBeneficiario(itemEndossoBeneficiario,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os beneficiarios da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiBeneficiario){
			for(ItemBeneficiarioApolice itemApoliceBeneficiario : itemApolice.getListItemBeneficiarioApolice()){
				boolean beneficiarioExiste = false;
				if(itemEndossoPossuiBeneficiario){
					for(ItemBeneficiario itemEndossoBeneficiario : itemEndosso.getListItemBeneficiario()){
						if(AssertUtils.compareNull(itemEndossoBeneficiario.getNumeroBeneficiario(),itemApoliceBeneficiario.getCdBeneficiario())){
							beneficiarioExiste = true;
							break;
						}
					}
				}
				
				if(!beneficiarioExiste){
					logarExclusaoBeneficiario(itemApoliceBeneficiario,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoBeneficiario(ItemBeneficiario itemEndossoBeneficiario, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_BENEFICIARIO, itemEndossoBeneficiario.getNumeroBeneficiario().toString(), user));
	}
	
		
	private void logarExclusaoBeneficiario(ItemBeneficiarioApolice itemApoliceBeneficiario, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_BENEFICIARIO, itemApoliceBeneficiario.getCdBeneficiario().toString(), user));
	}	
}
