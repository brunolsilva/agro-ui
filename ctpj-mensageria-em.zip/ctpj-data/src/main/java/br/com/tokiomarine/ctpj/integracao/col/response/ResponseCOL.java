package br.com.tokiomarine.ctpj.integracao.col.response;

import java.io.Serializable;
import java.util.List;

public class ResponseCOL implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -2014896047163277917L;

	String retorno;

	List<Colaborador> colaboradores;

	public String getRetorno() {
		return retorno;
	}

	public void setRetorno(String retorno) {
		this.retorno = retorno;
	}

	public List<Colaborador> getColaboradores() {
		return colaboradores;
	}

	public void setColaboradores(List<Colaborador> colaboradores) {
		this.colaboradores = colaboradores;
	}
}

