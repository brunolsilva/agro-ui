package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import br.com.tokiomarine.ctpj.blaze.dto.CotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCoberturaBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ItemCotacaoBlaze;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

public class CalculoValidator {

	private static Logger logger = Logger.getLogger(CalculoValidator.class);
	
	public List<ValidacaoLote> validacaoCotacaoBlaze(CotacaoBlaze cotacaoBlaze) {
		logger.info("Inicio da validacao da cotação Blaze " + cotacaoBlaze.getSequencialCotacaoProposta());
		
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		for (ItemCotacaoBlaze item : cotacaoBlaze.getListItem()) {
			for (ItemCoberturaBlaze cobertura : item.getListItemCobertura()){
				validaValorPremioCoberturaApolice(listaValidacao,cotacaoBlaze.getIdTipoPedidoCotacao(),item.getNumeroItem(),cobertura);
			}
		}
		
		logger.info("Fim da validacao da cotação Blaze " + cotacaoBlaze.getSequencialCotacaoProposta());
		return listaValidacao;
	}
	
	protected void validaValorPremioCoberturaApolice(List<ValidacaoLote> listaValidacao,String tipoPedidoCotacao, Long numeroItem, ItemCoberturaBlaze itemCoberturaBlaze ) {
		if(BigDecimalUtil.menor(new BigDecimal(itemCoberturaBlaze.getValorPremio()),BigDecimal.ZERO) || tipoPedidoCotacao.equals(TipoPedidoCotacaoEnum.APOLICE.getId())) {
			listaValidacao.add(new ValidacaoLote(numeroItem.intValue(), "Prêmio da cobertura "+itemCoberturaBlaze.getCodigoCobertura()+" com valor negativo para a apólice."));
		}
	}
	
}
