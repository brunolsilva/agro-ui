package br.com.tokiomarine.ctpj.endosso.service;

import java.math.BigInteger;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemOutroSeguroApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemOutrosSegurosService {
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0116
	 */
	public void validarOutrosSeguros(Cotacao endosso, ItemCotacao itemEndosso, ItemApolice itemApolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean itemEndossoPossuiOutrosSeguros = itemEndosso.getListItemOutroSeguro() != null && !itemEndosso.getListItemOutroSeguro().isEmpty();
		boolean itemApolicePossuiOutrosSeguros = itemApolice.getListItemOutroSeguroApolice() != null && !itemApolice.getListItemOutroSeguroApolice().isEmpty();
		
		//1 - percorre os outros seguros do itemEndosso e compara com os do itemApolice
		if(itemEndossoPossuiOutrosSeguros){			
			for(ItemOutroSeguro itemEndossoOutroSeg : itemEndosso.getListItemOutroSeguro()){
				boolean outroSegurExiste = false;
				if(itemApolicePossuiOutrosSeguros){
					for(ItemOutroSeguroApolice itemApolOutroSeg : itemApolice.getListItemOutroSeguroApolice()){
						if(AssertUtils.compareNull(itemEndossoOutroSeg.getSequencialItemOutroControle(),itemApolOutroSeg.getSequencialItemOutroApoliceControle())){
							//valida companhia segurada
							validacaoParametrosEndossoService.compararParametrosItem(itemApolOutroSeg.getCodigoCompanhiaSeguradora(), itemEndossoOutroSeg.getCodigoCompanhiaSeguradora(), TipoMensagemEndossoEnum.ALT_OUTROS_SEGUROS, "- Seguradora: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida numero apolice
							validacaoParametrosEndossoService.compararParametrosItem(StringUtils.defaultIfBlank(itemApolOutroSeg.getNumeroApolice(),""), StringUtils.defaultIfBlank(itemEndossoOutroSeg.getNumeroApolice(),""), TipoMensagemEndossoEnum.ALT_OUTROS_SEGUROS, "- Apólice: ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							//valida valor limite máximo de garantia
							validacaoParametrosEndossoService.compararParametrosItem(itemApolOutroSeg.getValorLimiteMaximoGarantia(), itemEndossoOutroSeg.getValorLMG(), TipoMensagemEndossoEnum.ALT_OUTROS_SEGUROS, "- LMG: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida valor limite máximo de garantia moeda estrangeira
							validacaoParametrosEndossoService.compararParametrosItem(itemApolOutroSeg.getValorLimiteMaximoGarantiaMoedaEstrangeira(), itemEndossoOutroSeg.getValorLMGMoedaEstrangeira(), TipoMensagemEndossoEnum.ALT_OUTROS_SEGUROS, "- LMG em dólar: ", endosso, itemEndosso, alteracoesEndossoList, user);

							//valida fim de vigencia
							validacaoParametrosEndossoService.compararParametrosItem(itemApolOutroSeg.getDataFimVigencia(), itemEndossoOutroSeg.getDataFimVigencia(), TipoMensagemEndossoEnum.ALT_OUTROS_SEGUROS, "- Término de vigência ", endosso, itemEndosso, alteracoesEndossoList, user);
							
							outroSegurExiste = true;
							break;
						}						
					}
				}
				
				//se o item relacao bem não existir
				if(!outroSegurExiste){ 
					logarInclusaoItem(itemEndossoOutroSeg,itemEndosso,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre os outros seguros da itemApolice e compara com os do itemEndosso
		if(itemApolicePossuiOutrosSeguros){
			for(ItemOutroSeguroApolice itemApolOutroSeg : itemApolice.getListItemOutroSeguroApolice()){
				boolean outroSegurExiste = false;
				if(itemEndossoPossuiOutrosSeguros){
					for(ItemOutroSeguro itemEndossoOutroSeg : itemEndosso.getListItemOutroSeguro()){
						if(AssertUtils.compareNull(itemEndossoOutroSeg.getSequencialItemOutroControle(),itemApolOutroSeg.getSequencialItemOutroApoliceControle())){
							outroSegurExiste = true;
							break;
						}
					}
				}
				
				if(!outroSegurExiste){
					logarExclusaoItem(itemApolOutroSeg,itemEndosso,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoItem(ItemOutroSeguro itemEndossoOutroSeg, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.INC_OUTROS_SEGUROS, itemEndossoOutroSeg.getSequencialItemOutroControle().toString(), user));
	}
	
		
	private void logarExclusaoItem(ItemOutroSeguroApolice itemApolOutroSeg, ItemCotacao itemEndosso,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, TipoMensagemEndossoEnum.EXC_OUTROS_SEGUROS, itemApolOutroSeg.getSequencialItemOutroApoliceControle().toString(), user));
	}
}
