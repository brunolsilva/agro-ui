package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.LinhaClausulaNotaView;
import br.com.tokiomarine.ctpj.cotacao.dto.LinhaCoberturaView;
import br.com.tokiomarine.ctpj.cotacao.dto.LinhaRubricaView;
import br.com.tokiomarine.ctpj.cotacao.dto.LinhaSistProtecionalView;
import br.com.tokiomarine.ctpj.cotacao.service.ClausulaService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRubricaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecionalClausula;
import br.com.tokiomarine.ctpj.dto.InclusaoClausulaItemCobertura;
import br.com.tokiomarine.ctpj.dto.InclusaoClausulaItemSistemaProtecional;
import br.com.tokiomarine.ctpj.dto.ItemInclusaoClausula;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ClausulaNota;
import br.com.tokiomarine.ctpj.mapper.ClausulaMapper;
import br.com.tokiomarine.ctpj.mapper.ClausulaNotaViewMapper;
import br.com.tokiomarine.ctpj.mapper.InclusaoItensClausulasCoberturaMapper;
import br.com.tokiomarine.ctpj.mapper.InclusaoItensClausulasResponseMapper;
import br.com.tokiomarine.ctpj.mapper.ItemCoberturaViewMapper;
import br.com.tokiomarine.ctpj.mapper.LinhaRubricaViewMapper;
import br.com.tokiomarine.ctpj.mapper.SistemasProtecionaisViewMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping("clausulasManuais/{seqCotacao}")
public class ClausulasManuaisController {
	
	@Autowired
	private CotacaoService cotacaoService;
	@Autowired
	private ClausulaService clausulaService;
	@Autowired
	private ClausulaNotaViewMapper clausulaNotaViewMapper;
	@Autowired
	private SistemasProtecionaisViewMapper sistProtecViewMapper;
	@Autowired
	private ItemCoberturaViewMapper itemCoberturaViewMapper;
	@Autowired
	private LinhaRubricaViewMapper atividadeViewMapper;
	@Autowired
	private ClausulaMapper clausulaMapper;
	@Autowired
	private InclusaoItensClausulasResponseMapper inclusaoItensClausulasRespMapper;
	@Autowired
	private InclusaoItensClausulasCoberturaMapper inclusaoClausulasCoberturaRespMapper;
	
	@GetMapping
	public ModelAndView home(@PathVariable("seqCotacao") BigInteger seqCotacao) throws ServiceException{	
		List<ItemCotacao> itens = cotacaoService.buscaItensFiltradosPorTipoPedidoCotacao(seqCotacao);
		CotacaoView  cotacao = cotacaoService.findCotacaoCabecalho(seqCotacao);
		ModelAndView mv = new ModelAndView(Paginas.clausulasManuais.value());		
		mv.addObject("seqCotacaoProposta", seqCotacao);
		mv.addObject("cabecalhoCotacao", cotacao);
		mv.addObject("itens", itens);
		mv.addObject("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacaoReadOnly()).isReadOnly());
		return mv;
	}
	
	@GetMapping("/clausulasCapa")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public List<LinhaClausulaNotaView> listaClausulasCapa(@PathVariable("seqCotacao") BigInteger seqCotacao) throws ServiceException{
		List<ClausulaNota> clausulasCapa = clausulaService.listaClausulasCapaManuais(seqCotacao);
		return clausulaNotaViewMapper.toLinhaClausulaNotaViews(clausulasCapa, seqCotacao);
	}	
	
	@PostMapping("/clausulasCapa")	
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasCapa(@PathVariable("seqCotacao") BigInteger seqCotacao, @RequestBody List<ItemInclusaoClausula> listOfInclusaoClausula){
		clausulaService.salvaClausulasCapasManuais(seqCotacao, clausulaMapper.toListOfClausulaCotacaoManual(seqCotacao, listOfInclusaoClausula,SecurityUtils.getCurrentUser()));
	}
	
	@GetMapping("/atividades")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public List<LinhaRubricaView> listaAtividades(@PathVariable("seqCotacao") BigInteger seqCotacao) throws ServiceException{
		return atividadeViewMapper.fromCotacaotoLinhasRubricaView(seqCotacao);
	}
	
	@GetMapping("/atividades/{seqItemCotacao}")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public LinhaRubricaView listaAtividades(@PathVariable("seqCotacao") BigInteger seqCotacao, @PathVariable("seqItemCotacao") BigInteger seqItemCotacao) throws ServiceException{
		return atividadeViewMapper.fromItemCotacaotoLinhaRubricaView(seqItemCotacao);
	}
	
	@PostMapping("/atividades")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasAtividadesParaTodosOsItens(@PathVariable("seqCotacao") BigInteger seqCotacao, @RequestBody List<ItemInclusaoClausula> listOfInclusaoClausula) throws ServiceException{
		List<ItemRubricaClausula> itensRubricaClausula = inclusaoItensClausulasRespMapper.toListOfItemRubricaClausulaParaTodosItensDaCotacao(seqCotacao, listOfInclusaoClausula);
		clausulaService.salvaOuAtualizaItensRubricaClausulaParaCotacao(seqCotacao, itensRubricaClausula);
	}
	
	@PostMapping("/atividades/{seqItemCotacao}")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasAtividadesParaUmItem(@PathVariable("seqCotacao") BigInteger seqCotacao, @PathVariable("seqItemCotacao") BigInteger seqItemCotacao, @RequestBody List<ItemInclusaoClausula> listOfInclusaoClausula) throws ServiceException{
		List<ItemRubricaClausula> itensRubricaClausula = inclusaoItensClausulasRespMapper.toListOfItemRubricaClausula(seqItemCotacao, listOfInclusaoClausula);
		clausulaService.salvaOuAtualizaItensRubricaClausulaParaItemCotacao(seqItemCotacao, itensRubricaClausula);
	}	
	
	@GetMapping("/sistemasProtecionais")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public List<LinhaSistProtecionalView> listaSistemasProtecional(@PathVariable("seqCotacao") BigInteger seqCotacao) throws ServiceException{
		return sistProtecViewMapper.toLinhaSistProtecionalViewFromCotacao(seqCotacao);
	}
	
	@GetMapping("/sistemasProtecionais/{seqItemCotacao}")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public List<LinhaSistProtecionalView> listaSistemasProtecional(@PathVariable("seqCotacao") BigInteger seqCotacao , @PathVariable("seqItemCotacao") BigInteger seqItemCotacao) throws ServiceException{
		return sistProtecViewMapper.toLinhaSistProtecionalViewFromItemCotacao(seqItemCotacao);
	}	
	
	@PostMapping("/sistemasProtecionais")
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasSistemasProtecionaisParaTodosOsItens(@PathVariable("seqCotacao") BigInteger seqCotacao, @RequestBody List<InclusaoClausulaItemSistemaProtecional> listOfInclusaoClausulaItemSistProtec) throws ServiceException{
		List<ItemSistemaProtecionalClausula> itensSistemaProtecClausula = inclusaoItensClausulasRespMapper.toListOfItemProtecionalClausulaParaTodosItensDaCotacao(seqCotacao, listOfInclusaoClausulaItemSistProtec);
		clausulaService.salvaOuAtualizaItemSistemaProtecionalClausulaParaCotacao(seqCotacao, itensSistemaProtecClausula);
	}
	
	@PostMapping("/sistemasProtecionais/{seqItemCotacao}")
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasSistemasProtecionaisParaUmItem(@PathVariable("seqCotacao") BigInteger seqCotacao, @PathVariable("seqItemCotacao") BigInteger seqItemCotacao, @RequestBody List<InclusaoClausulaItemSistemaProtecional> listOfInclusaoClausulaItemSistProtec) throws ServiceException{
		List<ItemSistemaProtecionalClausula> itensSistemaProtecClausula = inclusaoItensClausulasRespMapper.toListOfItemProtecionalClausula(seqItemCotacao, listOfInclusaoClausulaItemSistProtec);
		clausulaService.salvaOuAtualizaItemSistemaProtecionalClausulaParaItemCotacao(seqItemCotacao, itensSistemaProtecClausula);
	}
	
	@GetMapping("/coberturas")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public List<LinhaCoberturaView> listaCoberturas(@PathVariable("seqCotacao") BigInteger seqCotacao) throws ServiceException{
		return itemCoberturaViewMapper.toLinhasCoberturaViewParaCotacao(seqCotacao);
	}
	
	@GetMapping("/coberturas/{seqItemCotacao}")
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public List<LinhaCoberturaView> listaCoberturas(@PathVariable("seqCotacao") BigInteger seqCotacao, @PathVariable("seqItemCotacao") BigInteger seqItemCotacao) throws ServiceException{
		return itemCoberturaViewMapper.toLinhaCoberturaViewParaItemCotacao(seqItemCotacao);
	}
	
	@PostMapping("/coberturas")
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasCoberturasParaTodosItens(@PathVariable("seqCotacao") BigInteger seqCotacao, @RequestBody List<InclusaoClausulaItemCobertura> listOfItemInclusaoClausulaCobertura){
		List<ItemCoberturaClausula> itens = inclusaoClausulasCoberturaRespMapper.toListOfItemClausulaCoberturaParaTodosItensCotacao(seqCotacao, listOfItemInclusaoClausulaCobertura);
		clausulaService.salvaOuAtualizaItensClausualCoberturaParaCotacao(seqCotacao, itens);
	}
	
	@PostMapping("/coberturas/{seqItemCotacao}")
	@ResponseStatus(HttpStatus.OK)
	public void salvaClausulasCoberturasParaUmItem(@PathVariable("seqCotacao") BigInteger seqCotacao, @PathVariable("seqItemCotacao") BigInteger seqItemCotacao, @RequestBody List<InclusaoClausulaItemCobertura> listOfInclusaoClausulaItemSistProtec){
		List<ItemCoberturaClausula> itens = inclusaoClausulasCoberturaRespMapper.toListOfItemCoberturaClausula(seqItemCotacao, listOfInclusaoClausulaItemSistProtec);
		clausulaService.salvaOuAtualizaItensClausualCoberturaParaItemCotacao(seqItemCotacao, itens);		
	}	
	
}
