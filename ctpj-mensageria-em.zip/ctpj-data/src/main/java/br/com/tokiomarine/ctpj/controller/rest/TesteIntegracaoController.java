package br.com.tokiomarine.ctpj.controller.rest;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.GeraMensagemEndossoService;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.integracao.crivo.RequestGrandesRiscosHelperVO;
import br.com.tokiomarine.ctpj.integracao.service.CrivoService;

@Controller
public class TesteIntegracaoController {

	private static Logger logger = LogManager.getLogger(TesteIntegracaoController.class);

	@Autowired
	private CrivoService controladoriaService;

	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private GeraMensagemEndossoService geraMensagemEndossoService;
	
	

	@GetMapping(value = "/rest/crivo")
	public @ResponseBody ResponseEntity<Object> jmsProdutor() {

		try {
			RequestGrandesRiscosHelperVO request = new RequestGrandesRiscosHelperVO();
			StringBuilder sb = new StringBuilder();

			/*
			 * sb.append("P").append("\r\n");
			 * sb.append("		Modulo Produto;1806").append("\r\n");
			 * sb.append("Placa;").append("\r\n");
			 * sb.append("Chassi;").append("\r\n");
			 * sb.append("Ramo;18").append("\r\n");
			 * sb.append("ID_CEP_LOCAL_RISCO;1327001").append("\r\n");
			 * sb.append("NR_ENDERECO_RISCO;RUA TREZE DE MAIO").append("\r\n");
			 * sb.append("Tipo de seguro;N").append("\r\n");
			 * sb.append("CPF;01234567890").append("\r\n");
			 * sb.append("Modalidade;").append("\r\n");
			 * sb.append("Nome;TESTE TESTE").append("\r\n");
			 * sb.append("Valor para análise;");
			 * request.setCdCorret("7002"); request.setCdSegmento("30");
			 * request.setCdSisOrigem("KME"); request.setChToken("2614151");
			 * request.setIdLogin("KME"); request.setNoCNPJ("01234567890");
			 * request.setPolicy("Política de PJ");
			 */

			sb.append("P").append("\r\n");
			sb.append("		Modulo Produto;31").append("\r\n");
			sb.append("Placa;").append("\r\n");
			sb.append("Chassi;").append("\r\n");
			sb.append("Ramo;31").append("\r\n");
			sb.append("Tipo de seguro;N").append("\r\n");
			sb.append("CPF;11528644832").append("\r\n");
			sb.append("Modalidade;").append("\r\n");
			sb.append("Nome;MONICA LAFAYETE CARCANHOLO E PRATA").append("\r\n");
			sb.append("Valor para análise;");

			request.setCdCorret("7002");
			request.setCdSisOrigem("PLT");
			request.setChToken("7108");
			request.setIdLogin("ADMPLT");
			request.setNoCNPJ("11528644832");
			request.setPolicy("TMB - Política de PF");

			request.setValidationInstruction(sb.toString());

			Cotacao cotacao = new Cotacao();
			User user = new User();

			// ResponseGrandesRiscosHelperVO response =
			// controladoriaService.invokeCrivo(request,cotacao,user);
			// logger.info(response.toString());
		} catch (Exception e) {
			logger.error("ERRO Teste Crivo",e);
		}

		return new ResponseEntity<Object>(null,HttpStatus.OK);

	}
	
	@GetMapping(value = "/rest/regerarMensagensEndosso/{sequencialCotacaoProposta}")
	@ResponseBody
	public ResponseEntity<Object> regerarMensagensEndosso(@PathVariable BigInteger sequencialCotacaoProposta) {
		
		ResultadoREST<String> result = new ResultadoREST<String>();	
		List<String> mensagens = new ArrayList<String>();
		try {
			List<AlteracaoEndosso> listAntes = geraMensagemEndossoService.listAteracaoEndossoBysequencialCotacaoProposta(sequencialCotacaoProposta);
			
			mensagens.add("lista de mensagens antes: ");
			mensagens.add("");
			int count = 0;
			for (AlteracaoEndosso alteracaoEndosso : listAntes) {
				mensagens.add(count+" - "+alteracaoEndosso.getDescricaoTipoRegistro());
				count++;
			}
			
			geraMensagemEndossoService.regerarMensagensEndosso(sequencialCotacaoProposta);
			
			List<AlteracaoEndosso> listDepois = geraMensagemEndossoService.listAteracaoEndossoBysequencialCotacaoProposta(sequencialCotacaoProposta);
			mensagens.add("");
			mensagens.add("lista de mensagens depois: ");
			mensagens.add("");
			
			count = 0;
			for (AlteracaoEndosso alteracaoEndosso : listDepois) {
				mensagens.add(count+" - "+alteracaoEndosso.getDescricaoTipoRegistro());
				count++;
			}
			
			result.setSuccess(true);
			result.setMensagem("Executado com sucesso");
			result.setListaRetorno(mensagens);
		} catch (Exception e) {
			String msg = String.format("Erro ao regerar Mensagens de Endosso para o sequencial da cotação: [%s]  ",sequencialCotacaoProposta) + ExceptionUtils.getFullStackTrace(e);
			logger.error(msg);
			result.setMensagem(msg);
			result.setSuccess(false);
			
		}
		return new ResponseEntity<Object>(result,HttpStatus.OK);
		
	}
	
	@GetMapping(value = "/rest/card")
	public void oi() {
		String url = "http://dkapp-act.tokiomarine.com.br/arquitetura/payment-server/v1/payments";

	    String username = "ctpj";
	    String pass = "123456";

	    String plainCreds = username + ":" + pass;
	    String base64Creds = Base64Utils.encodeToString(plainCreds.getBytes());

	    HttpHeaders headers = new HttpHeaders();
	    headers.add("Authorization", "Basic " + base64Creds);

	    HttpEntity<String> entity = new HttpEntity<String>(headers);

	    RestTemplate restTemplate = new RestTemplate();

	    try {
	    	ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
	    	logger.info(">>>> " + response.getStatusCodeValue());
	 	    logger.info(">>>> " + response.getBody());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}