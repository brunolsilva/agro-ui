package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.DevolucaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.cotacao.service.TransmissaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.FormaEnvioDocumentoDigitalEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.OpcaoParcelamentoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.EstadoCivilEnum;
import br.com.tokiomarine.ctpj.infra.enums.SexoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.BancoService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.PldService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ResseguradorService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Controller
@RequestMapping(value = "/transmissao")
public class TransmissaoController extends AbstractController {

	private static Logger logger = LogManager.getLogger(TransmissaoController.class);	

	@Autowired
	private MailUtilService mailUtilService;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private TransmissaoService transmissaoService;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private BancoService bancoService;

	@Autowired
	private PldService pldService;
	
	@Autowired
	private RecebimentoService recebimentoService;

	@Autowired
	private ResseguradorService resseguradorService;

	@Autowired
	private PerfilComercialService perfilComercialService;
	
	@Autowired
	private OpcaoParcelamentoService parcelamentoService;
	
	@Autowired
	private DevolucaoService devolucaoService;
	
	private static final String DESTINO_CORRESPONDENCIA = "Esta opção estará disponível somente se selecionada a opção “Correio”<br>"+ 
													"1. Segurado: Será enviada uma via para o segurado<br>"+
													"2. Corretor: Será enviada uma via ao corretor<br>"+
													"3. Ambos: Serão enviadas 2 vias. Uma para o segurado e uma para o corretor.";

	private static final String FORMA_ENVIO = "1. Correio (100% dos documentos impressos)<br>"+
											  "2. E-mail (100% dos documentos digitais)";

	@GetMapping("/{id}")
	@LogPerformance
	public String index(@PathVariable BigInteger id, Model model) {
		logger.info("Inicio index contratação cotação: " + id);
		Boolean exibeFormaPagamento = false;
		Boolean exibeBotoes = true;
		Boolean exibeEstadoCivil = false;
		try {			
			CotacaoView cabecalhoCotacao = cotacaoService.findCotacaoCabecalho(id);
			if(cabecalhoCotacao.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO) {
				return "/erros/404";
			}
			PropostaView proposta = transmissaoService.carregaDadosProposta(id);
			Cotacao cotacao = cotacaoService.findById(id);
			Recebimento recebimento = recebimentoService.findRecebimentoByNumeroCotacaoProposta(cotacao);
			
			if (cotacao.getValorPremioLiquido() != null) {
				//Verifica se exibe dados do pagamento para endosso
				if ((cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) || ((cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) && (cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0 ))) {
					exibeFormaPagamento = true;
					
				}
			}
			//Verifica se exibe botões de cobertura, resseguro, ...
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
				exibeBotoes = false;				
			}
			//Solicitado pelo Weliton Santana
			if (!SecurityUtils.isCorretor()){
				if (proposta.getCotacao().getIdFaturamentoPresumido() == null){
					proposta.getCotacao().setIdFaturamentoPresumido(new BigInteger("1"));
				}
				if (proposta.getCotacao().getIdCapitalSocial() == null){
					proposta.getCotacao().setIdCapitalSocial(new BigInteger("8"));
				}
			}
			model.addAttribute("bancos", bancoService.findAll(cabecalhoCotacao));
			model.addAttribute("ufs",caracteristicaService.findUFs());
			cabecalhoCotacao.setComissaoAntecipada(cotacao.getIcComissaoAntecipada());
			model.addAttribute("cabecalhoCotacao",cabecalhoCotacao);
			model.addAttribute("proposta",proposta);
			model.addAttribute("exibeFormaPagamento", exibeFormaPagamento);
			model.addAttribute("exibeBotoes", exibeBotoes);
			model.addAttribute("exibeVinculoRecebimento", proposta.getCodigoFormaParcelamento() != null && proposta.isEntrada() || recebimento != null && recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO));

			model.addAttribute("destinos",DestinoDocumentoDigitalEnum.values());
			model.addAttribute("formasEnvio",FormaEnvioDocumentoDigitalEnum.values());

			model.addAttribute("listaPais",pldService.listarPais());

			model.addAttribute("listaCapitalSocial",pldService.listarCapitalSocial());
			model.addAttribute("listaFaturamentoPresumido",pldService.listarFaturamentoPresumido());

			model.addAttribute("listaProfissao",pldService.listarProfissao());
			model.addAttribute("listaPatrimonio",pldService.listarPatrimonio());
			model.addAttribute("listaRenda",pldService.listarRenda());

			model.addAttribute("resseguradores",resseguradorService.findAll());
			model.addAttribute("exigeOficio", transmissaoService.exigeOficio(proposta));
			
			model.addAttribute("destinoCorrespondencia",DESTINO_CORRESPONDENCIA);
			model.addAttribute("formaEnvio",FORMA_ENVIO);
			if(!StringUtils.isBlank(proposta.getUrlBoleto())) {
				model.addAttribute("docstoreBoleto",proposta.getUrlBoleto().substring(proposta.getUrlBoleto().lastIndexOf("/") + 1));
			}
			
			model.addAttribute("emailsArquivos", transmissaoService.listarEmails(proposta));
			model.addAttribute("listaSexo",SexoEnum.values());
			
			if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE 
					|| Arrays.asList(TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO,TipoEndossoSctEnum.REINTEGRACAO_IS).contains(cotacao.getCodigoTipoEndossoSCT())
					|| Arrays.asList(TipoEndossoEnum.ALTERACAO_DADOS_CADASTRAIS,TipoEndossoEnum.ALTERACAO_SEGURADO_TDO).contains(cotacao.getIdTipoEndosso())) {
				exibeEstadoCivil = true;
				model.addAttribute("listaEstadoCivil",EstadoCivilEnum.values());
			}
			
			model.addAttribute("exibeEstadoCivil",exibeEstadoCivil);
			if(CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue() == proposta.getCodigoSituacao()) {
				model.addAttribute("sucesso","Proposta enviada com sucesso!");
				model.addAttribute("printProposta", true);
			}
			model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cabecalhoCotacao.getCodigoSituacaoReadOnly()).isReadOnly());
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			if(perfilComercialService.hasPerfilComercial(grupoUsuario) && !cotacaoService.isRegraNegocioFechado(cotacao, super.getUser())) {
				model.addAttribute("readOnly",true);
			}
			//carrega os atributos abaixo em caso de cancelamento de apólice
			if (cotacao.getIdTipoEndosso() != null && cotacao.getValorPremioLiquido() != null && cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) < 0 ){
				model.addAttribute("formasDevolucao",transmissaoService.buscaFormaDevolucao(cotacao));
				model.addAttribute("bancosFinalidadeDevolucao",bancoService.findBancoFinalidadeDevolucao());
				model.addAttribute("exibeDadosDevolucao", true);
			} else {
				model.addAttribute("exibeDadosDevolucao", false);
			}
			List<OpcaoParcelamento> opcaoParcelamento = parcelamentoService.listar(cotacao.getSequencialCotacaoProposta(), cotacao.getNumeroCotacaoProposta());
			model.addAttribute("opcaoParcelamento", opcaoParcelamento);
			model.addAttribute("grupoUsuario", this.getUser().getGrupoUsuario());
			model.addAttribute("regraNegocioFechado", cotacaoService.isRegraNegocioFechado(cotacao, this.getUser()));

		} catch (ServiceException e) {
			logger.error(String.format("Erro ao carregar a tela de transmissao [cotacao=%s]", id), e);
			if (!AmbienteUtil.isServidorLocal()) {
				mailUtilService.sendMailErro(e);
			}
		}

		logger.info("Fim index contratação cotação: " + id);
		return "/cotacao/contratar";
	}

	@GetMapping("/endosso/dadosDevolucaoSCT/{numeroSolicitacaoCotacao}")
	public ResponseEntity<?> consultarDadosDevolucaoSCT(@PathVariable BigInteger numeroSolicitacaoCotacao) {
		try {
			return ResponseEntity.ok(devolucaoService.consultaDadosDevolucaoSCT(numeroSolicitacaoCotacao));
		} catch (Exception e) {
			logger.error("Erro ao consultar dados devolucao SCT", e);
			return ResponseEntity.badRequest().build();
		}
	}

	private void preCondicoesProposta(BigInteger id) {
		//
	}

	@PostMapping(value = "/salvar")
	@LogPerformance
	public ResponseEntity<ResultadoREST<Object>> salvar(@RequestBody PropostaView proposta) throws ServiceException {
		logger.info("Inicio do Salvar da cotação " + proposta.getSequencialCotacaoProposta());

		ResultadoREST<Object> resultado = new ResultadoREST<>();
		
		try {
			User user = SecurityUtils.getCurrentUser();
			transmissaoService.salvar(proposta,user);
			resultado.setSuccess(true);

			logger.info("Fim do Salvar da cotação " + proposta.getSequencialCotacaoProposta());

			return ResponseEntity.ok(resultado);
		} catch(OpcaoParcelamentoException o){
			resultado.setSuccess(false);
			resultado.getListaValidacao().add(new Validacao("Favor selecionar uma opção de parcelamento"));
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao Salvar os Dados da Proposta ", e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}

	@PostMapping(value = "/enviar")
	@LogPerformance
	public ResponseEntity<ResultadoREST<Object>> enviar(@RequestBody PropostaView proposta, RedirectAttributes redirect) throws ServiceException {
		logger.info("Inicio da Contratação da cotação " + proposta.getSequencialCotacaoProposta());
		
		ResultadoREST<Object> resultado = new ResultadoREST<>();

		try {			
			User user = SecurityUtils.getCurrentUser();
			List<Validacao> validacao = transmissaoService.enviar(proposta,user);
			resultado.setSuccess(true);
			if(validacao != null && !validacao.isEmpty()) {
				resultado.setListaValidacao(validacao);
				resultado.setSuccess(false);
			}

			if(validacao == null || validacao.isEmpty()) {
				transmissaoService.enviaContratacao(proposta.getSequencialCotacaoProposta(),user);
			}

			logger.info("Fim da Contratação da cotação " + proposta.getSequencialCotacaoProposta());

			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao Salvar os Dados da Proposta ", e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}
	
	@PostMapping(value = "/salvarRessegurador")
	@LogPerformance
	public ResponseEntity<ResultadoREST<Object>> salvarRessegurador(@RequestBody PropostaView proposta) throws ServiceException {
		ResultadoREST<Object> resultado = new ResultadoREST<>();

		try {
			resseguradorService.salvarRessegurador(proposta);
			resultado.setSuccess(true);
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error(String.format("Erro ao Salvar os Dados do Ressegurador [numero=%s versao=%s]",
					proposta.getCotacao().getNumeroCotacaoProposta(),
					proposta.getCotacao().getVersaoCotacaoProposta()), e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}
}