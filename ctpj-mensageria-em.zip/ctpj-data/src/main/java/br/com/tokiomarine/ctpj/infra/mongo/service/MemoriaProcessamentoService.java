package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaProcessamento;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaProcesso;
import br.com.tokiomarine.ctpj.enums.TipoMemoriaEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.mongo.repository.MemoriaProcessamentoRepository;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.util.DateUtil;

@Service
public class MemoriaProcessamentoService {

	@Autowired
	private MemoriaProcessamentoRepository repository;

	private static Logger logger = LogManager.getLogger(MemoriaProcessamentoService.class);

	public void saveMemoria(Cotacao cotacao,User user,StringBuilder sbMemoria, TipoMemoriaEnum tipoMemoriaEnum) throws ServiceException{

		try {

			MemoriaProcessamento memoriaProcessamento = repository.findOneBySessionIdAndNrCotacAndVsCotac(user.getSessionId(), cotacao.getNumeroCotacaoProposta(), cotacao.getVersaoCotacaoProposta());

			boolean isNull = (memoriaProcessamento == null ? true : false);

			List<MemoriaProcesso> memorias = new ArrayList<MemoriaProcesso>();

			if (isNull) {
				memoriaProcessamento = new MemoriaProcessamento();
				memoriaProcessamento.setSessionId(user.getSessionId());
				memoriaProcessamento.setNrCotac(cotacao.getNumeroCotacaoProposta());
				memoriaProcessamento.setVsCotac(cotacao.getVersaoCotacaoProposta());
				memoriaProcessamento.setUsuarioAtualizacao(user.getCdUsuro().toString());
				memoriaProcessamento.setDataAtualizacao(Calendar.getInstance().getTime());
			}

			MemoriaProcesso memoria = new MemoriaProcesso();
			memoria.setTipo(tipoMemoriaEnum);
			memoria.setTexto(sbMemoria.toString());

			if (isNull) {
				memorias.add(memoria);
				memoriaProcessamento.setMemorias(memorias);
			}else{
				memoriaProcessamento.getMemorias().add(memoria);
			}

			repository.save(memoriaProcessamento);
		} catch (Exception e) {
			logger.error("Erro ao Salvar Memória de Processamento MongoDB ", e);
		}

	}

	public void appendMemoria(StringBuilder sbMemoria,String texto){
		try{
			sbMemoria.append(CTP.quebraDeLinha.caracter()).append(DateUtil.formataCompleta(Calendar.getInstance().getTime())).append(" - ").append(texto).append(CTP.quebraDeLinha.caracter());
		}catch (Exception e) {
			logger.error("Erro ao Gerar linha Memória de Processo de Processamento MongoDB ", e);
		}
	}

}
