package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.cotacao.repository.PerfilCalculoRepository;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculo;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCoberturaLimiteIs;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoJurosParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;

@Service
public class PerfilCalculoService {

	@Autowired
	private PerfilCalculoRepository perfilCalculoRepository;
	
	@Autowired
	private ProdutoRepository produtoRepository;
	
	public void copiarPerfilCalculo(Long perfilOrigem, Long perfilDestino, Integer produto) throws ServiceException {
		PerfilCalculo perfilCalculoOrigem = perfilCalculoRepository.getPerfilCalculo(perfilOrigem);
		PerfilCalculo perfilCalculoDestino = perfilCalculoRepository.getPerfilCalculo(perfilDestino);
		Produto produtoObj = produtoRepository.findByCodigo(produto);
		
		if(perfilCalculoOrigem == null) {
			throw new ServiceException("Perfil de origem informado não encontrado");
		}
		
		if(perfilCalculoDestino == null) {
			throw new ServiceException("Perfil de destino informado não encontrado");
		}
		
		if(produtoObj == null) {
			throw new ServiceException("Produto informado não encontrado");
		}
		
		//faz a cópia das collections associadas ao perfil de origem
		PerfilCalculoCondicao perfilCalculoCondicaoDestino = copiarPerfilCalculoCondicao(perfilOrigem, perfilDestino, produto);
		List<PerfilCalculoJurosParcelamento> jurosParcelamentosDestino = copiarPerfilCalculoJurosParcelamento(perfilOrigem, perfilDestino, produto);
		List<PerfilCalculoCoberturaLimiteIs> coberturasLimitesIsDestino = copiarPerfilCalculoCoberturaLimiteIs(perfilOrigem, perfilDestino, produto);
		
		//salva as cópias para o novo perfil
		perfilCalculoRepository.insertPerfilCalculoCondicao(perfilCalculoCondicaoDestino);
		perfilCalculoRepository.insertPerfisCalculoJurosParcelamento(jurosParcelamentosDestino);
		perfilCalculoRepository.insertPerfisCalculoCoberturaLimiteIs(coberturasLimitesIsDestino);
		
	}

	private List<PerfilCalculoCoberturaLimiteIs> copiarPerfilCalculoCoberturaLimiteIs(Long perfilOrigem, Long perfilDestino,
			Integer produto) {
		List<PerfilCalculoCoberturaLimiteIs> cobLimitesOrigem = perfilCalculoRepository.findCoberturaLimiteIsByPerfilCalculo(perfilOrigem, produto);
		List<PerfilCalculoCoberturaLimiteIs> cobLimitesDestino = new ArrayList<>();
		if(cobLimitesOrigem != null && !cobLimitesOrigem.isEmpty()) {
			for(PerfilCalculoCoberturaLimiteIs cobLimiteOrigem : cobLimitesOrigem) {
				PerfilCalculoCoberturaLimiteIs cobLimiteDestino = new PerfilCalculoCoberturaLimiteIs();
				cobLimiteDestino.setCobertura(cobLimiteOrigem.getCobertura());
				cobLimiteDestino.setCoberturaOrigem(cobLimiteOrigem.getCoberturaOrigem());
				cobLimiteDestino.setCodigoGrupoUsuario(cobLimiteOrigem.getCodigoGrupoUsuario());
				cobLimiteDestino.setDataAtualizacao(cobLimiteOrigem.getDataAtualizacao());
				cobLimiteDestino.setDataInicioVigencia(cobLimiteOrigem.getDataInicioVigencia());
				cobLimiteDestino.setDataTerminoVigencia(cobLimiteOrigem.getDataTerminoVigencia());
				cobLimiteDestino.setMoeda(cobLimiteOrigem.getMoeda());
				cobLimiteDestino.setPercentualISVRMax(cobLimiteOrigem.getPercentualISVRMax());
				cobLimiteDestino.setPercentualISVRMin(cobLimiteOrigem.getPercentualISVRMin());
				cobLimiteDestino.setPerfilCalculo(perfilDestino);
				cobLimiteDestino.setProduto(cobLimiteOrigem.getProduto());
				cobLimiteDestino.setTipoCobertura(cobLimiteOrigem.getTipoCobertura());
				cobLimiteDestino.setUsuarioAtualizacao(cobLimiteOrigem.getUsuarioAtualizacao());
				cobLimiteDestino.setValorMaximoIS(cobLimiteOrigem.getValorMaximoIS());
				cobLimiteDestino.setValorMinimoIS(cobLimiteOrigem.getValorMinimoIS());
				cobLimiteDestino.setVlLmiMaxExigeValorRisco(cobLimiteOrigem.getVlLmiMaxExigeValorRisco());
				
				cobLimitesDestino.add(cobLimiteDestino);
			}
		}
		return cobLimitesDestino;
	}

	private List<PerfilCalculoJurosParcelamento> copiarPerfilCalculoJurosParcelamento(Long perfilOrigem, Long perfilDestino,
			Integer produto) {
		List<PerfilCalculoJurosParcelamento> jurosParcelamentosOrigem = perfilCalculoRepository.findPerfilCalculoJurosParcelamentoByPerfilCalculo(perfilOrigem, produto);
		List<PerfilCalculoJurosParcelamento> jurosParcelamentosDestino = new ArrayList<>();
		if(jurosParcelamentosOrigem != null && !jurosParcelamentosOrigem.isEmpty()) {
			for(PerfilCalculoJurosParcelamento pflOrig : jurosParcelamentosOrigem) {
				PerfilCalculoJurosParcelamento pflDestn = new PerfilCalculoJurosParcelamento();
				pflDestn.setCodigoGrupoUsuario(pflOrig.getCodigoGrupoUsuario());
				pflDestn.setDataAtualizacao(pflOrig.getDataAtualizacao());
				pflDestn.setDataInicioVigencia(pflOrig.getDataInicioVigencia());
				pflDestn.setDataTerminoVigencia(pflOrig.getDataTerminoVigencia());
				pflDestn.setFormaPagamento(pflOrig.getFormaPagamento());
				pflDestn.setFormaParcelamento(pflOrig.getFormaParcelamento());
				pflDestn.setIdImpressao(pflOrig.getIdImpressao());
				pflDestn.setPercentualJuros(pflOrig.getPercentualJuros());
				pflDestn.setPerfilCalculo(perfilDestino);
				pflDestn.setProduto(pflOrig.getProduto());
				pflDestn.setUsuarioAtualizacao(pflOrig.getUsuarioAtualizacao());
				pflDestn.setValorParcelaMinima(pflOrig.getValorParcelaMinima());
				jurosParcelamentosDestino.add(pflDestn);
			}
				
			
		}
		return jurosParcelamentosDestino;
	}

	private PerfilCalculoCondicao copiarPerfilCalculoCondicao(Long perfilOrigem, Long perfilDestino, Integer produto) {
		PerfilCalculoCondicao pflOrigem = perfilCalculoRepository.getPerfilCalculoCondicaoByCodigoAndProdutoFull(perfilOrigem, produto);
		
		PerfilCalculoCondicao pflDestino = new PerfilCalculoCondicao();
		pflDestino.setCodigoGrupoUsuario(pflOrigem.getCodigoGrupoUsuario());
		pflDestino.setDataAtualizacao(new Date());
		pflDestino.setDataInicioVigencia(pflOrigem.getDataInicioVigencia());
		pflDestino.setDataTerminoVigencia(pflOrigem.getDataTerminoVigencia());
		pflDestino.setNumeroDiasValidadeCotacao(pflOrigem.getNumeroDiasValidadeCotacao());
		pflDestino.setNumeroDiasVencimentoBoleto(pflOrigem.getNumeroDiasVencimentoBoleto());
		pflDestino.setNumeroDiasVencimentoPremioFinanciavel(pflOrigem.getNumeroDiasVencimentoPremioFinanciavel());
		pflDestino.setNumeroDiasVencimentoProgramadoMaximo(pflOrigem.getNumeroDiasVencimentoProgramadoMaximo());
		pflDestino.setNumeroDiasVencimentoProgramadoMinimo(pflOrigem.getNumeroDiasVencimentoProgramadoMinimo());
		pflDestino.setPercentualComissaoMaxima(pflOrigem.getPercentualComissaoMaxima());
		pflDestino.setPercentualComissaoMaximaComDesconto(pflOrigem.getPercentualComissaoMaximaComDesconto());
		pflDestino.setPercentualComissaoMinima(pflOrigem.getPercentualComissaoMinima());
		pflDestino.setPercentualComissaoPadrao(pflOrigem.getPercentualComissaoPadrao());
		pflDestino.setPercentualDescontoMaximo(pflOrigem.getPercentualDescontoMaximo());
		pflDestino.setPercentualDescontoMinimo(pflOrigem.getPercentualDescontoMinimo());
		pflDestino.setPercentualDescontoPadrao(pflOrigem.getPercentualDescontoPadrao());
		pflDestino.setPerfilCalculo(perfilDestino);
		pflDestino.setProduto(pflOrigem.getProduto());
		pflDestino.setReferenciaDataVencimentoBoleto(pflOrigem.getReferenciaDataVencimentoBoleto());
		pflDestino.setTipoSeguro(pflOrigem.getTipoSeguro());
		pflDestino.setUsuarioAtualizacao(pflOrigem.getUsuarioAtualizacao());
		
		return pflDestino;
	}
}
