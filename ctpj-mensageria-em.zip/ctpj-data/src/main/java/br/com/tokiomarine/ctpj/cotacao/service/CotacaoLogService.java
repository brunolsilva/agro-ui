package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoLogResponse;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoLogRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.enums.StatusEnum;
import br.com.tokiomarine.ctpj.enums.TipoProcessamentoEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.CotacaoLogMapper;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Service
@Transactional
public class CotacaoLogService {

	private static Logger logger = LogManager.getLogger(CotacaoLogService.class);

	private static final String QUEBRA_LINHA = "\n\r";

	@Autowired
	private CotacaoLogRepository repository;

	public void save(CotacaoLog cotacaoLog) throws ServiceException {
		try {
			cotacaoLog.setDataAtualizacao(Calendar.getInstance().getTime());
			repository.save(cotacaoLog);
		} catch (HibernateException h) {
			logger.error("Erro ao Salvar Cotacao Log ");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral Salvar Cotacao Log ",e);
			throw new ServiceException("Erro geral ao  Salvar Cotacao Log ",e);
		}

	}

	public CotacaoLog bindCotacaoLogBasicSucesso(Cotacao cotacao,User user,TipoProcessamentoEnum tipoLog) throws ServiceException {
		return this.bindCotacaoLogBasicSucesso(cotacao,user,tipoLog,null);
	}

	public CotacaoLog bindCotacaoLogBasicSucesso(Cotacao cotacao,User user,TipoProcessamentoEnum tipoLog,String observacao) throws ServiceException {
		CotacaoLog cotacaoLog = new CotacaoLog();
		cotacaoLog.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		cotacaoLog.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		cotacaoLog.setCotacao(cotacao);
		cotacaoLog.setIdTipoLog(tipoLog.getId());
		cotacaoLog.setStatusLog(StatusEnum.SUCESSO.getId());
		cotacaoLog.setSessionId(user.getSessionId());
		cotacaoLog.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		cotacaoLog.setUsuarioAtualizacao(user.getCdUsuro().longValue());

		StringBuilder sbObs = new StringBuilder();

		sbObs.append(tipoLog.getDescricao()).append(QUEBRA_LINHA);

		if (!StringUtils.isEmpty(observacao)) {
			sbObs.append(observacao);
		}
		return cotacaoLog;

	}

	public CotacaoLog bindCotacaoLogBasicErro(Cotacao cotacao,User user,TipoProcessamentoEnum tipoLog,String observacao,String request,String response) throws ServiceException {
		CotacaoLog cotacaoLog = new CotacaoLog();
		cotacaoLog.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		cotacaoLog.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
		cotacaoLog.setCotacao(cotacao);
		cotacaoLog.setIdTipoLog(tipoLog.getId());
		cotacaoLog.setStatusLog(StatusEnum.ERRO.getId());
		cotacaoLog.setSessionId(user.getSessionId());
		cotacaoLog.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		cotacaoLog.setUsuarioAtualizacao(user.getCdUsuro().longValue());

		StringBuilder sbObs = new StringBuilder();

		sbObs.append(tipoLog.getDescricao()).append(QUEBRA_LINHA);

		if (!StringUtils.isEmpty(observacao)) {
			sbObs.append(observacao);
		}

		if (!StringUtils.isEmpty(request)) {
			cotacaoLog.setRequest(request);
		}

		if (!StringUtils.isEmpty(response)) {
			cotacaoLog.setResponse(response);
		}

		return cotacaoLog;

	}
	
	public List<CotacaoLog> getCotacoesLogBySequencialCotacaoPropostaErro(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			return repository.getCotacoesLogBySequencialCotacaoPropostaErro(sequencialCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Cotacao Logs Erro ");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral Cotacao Logs Erro ",e);
			throw new ServiceException("Erro geral ao Cotacao Logs Erro ",e);
		}
	}
	
	public Optional<CotacaoLogResponse> buscaCotacaoLogMaisRecente(BigInteger seqCotacao, Integer tipoProcessamento){
		Optional<CotacaoLog> cotacaoLog = repository.buscaCotacaoLogMaisRecente(seqCotacao, tipoProcessamento);	
		return CotacaoLogMapper.getInstance().toCotacaoLogResponse(cotacaoLog);
	}
	
	@LogPerformance
	@Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = {ServiceException.class,Exception.class})
	public void saveLogRequiresNew(CotacaoLog cotacaoLog) throws ServiceException {
		cotacaoLog.setDataAtualizacao(Calendar.getInstance().getTime());
		repository.save(cotacaoLog);
	}
	
	public void logarChamadaComSucesso(Cotacao cotacao, User user, TipoProcessamentoEnum tipoProcessamento, Object request,
			Object response) {
		try {
			CotacaoLog cotacaoLog = bindCotacaoLogBasicSucesso(cotacao,user,tipoProcessamento);
			cotacaoLog.setRequest(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request));
			cotacaoLog.setResponse(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
			save(cotacaoLog);
		}
		catch(Exception e) {
			logger.error("Ocorreu um erro ao logar a chamada com sucesso ao serviço "+tipoProcessamento+": "+e.getMessage());
		}

	}
	
	public void logarChamadaComErro(Cotacao cotacao, User user, TipoProcessamentoEnum tipoProcessamento, Object request,
			Object response, Exception exception) {
		try {
			CotacaoLog cotacaoLog = bindCotacaoLogBasicErro(cotacao,user,tipoProcessamento,exception.getMessage(),JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request),JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
			save(cotacaoLog);			
		}
		catch(Exception e) {
			logger.error("Ocorreu um erro ao logar a chamada com erro ao serviço "+tipoProcessamento+": "+e.getMessage());
		}
	}
}
