package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ImpressaoCsf;
import br.com.tokiomarine.ctpj.infra.enums.TipoImpresaoCSFEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ImpressaoCsfRepository;

@Service
public class ImpressaoCsfService {

	private static Logger logger = LogManager.getLogger(ImpressaoCsfService.class);

	@Autowired
	private ImpressaoCsfRepository repository;

	public List<ImpressaoCsf> findImpressaoCsfByProdutoAndTipoDocumento(Integer produto,TipoImpresaoCSFEnum tipoDocumentoCSF)  throws ServiceException{
		try {
			return repository.findImpressaoCsfByProdutoAndTipoDocumento(produto,tipoDocumentoCSF);
		} catch (RepositoryException e) {
			logger.error("Erro na Busca do Impressao CSF",e);
			throw new ServiceException("Erro na Impressao CSF",e);
		}
	}

}
