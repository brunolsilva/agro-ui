package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import br.com.tokiomarine.ctpj.enums.TipoProcessamentoEnum;

public class CotacaoLogResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private BigInteger sequencialCotacaoLog;
	private BigInteger sequencialItemCotacao;
	private BigInteger seqCotacao;
	private BigInteger numeroItem;
	private TipoProcessamentoEnum idTipoLog;
	private String request;
	private String response;
	private String sessionId;
	private String statusLog;
	private String observacao;
	private BigInteger codigoCobertura;

	public BigInteger getSequencialCotacaoLog() {
		return sequencialCotacaoLog;
	}

	public void setSequencialCotacaoLog(BigInteger sequencialCotacaoLog) {
		this.sequencialCotacaoLog = sequencialCotacaoLog;
	}

	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}

	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}

	public BigInteger getSeqCotacao() {
		return seqCotacao;
	}

	public void setSeqCotacao(BigInteger seqCotacao) {
		this.seqCotacao = seqCotacao;
	}

	public BigInteger getNumeroItem() {
		return numeroItem;
	}

	public void setNumeroItem(BigInteger numeroItem) {
		this.numeroItem = numeroItem;
	}

	public TipoProcessamentoEnum getIdTipoLog() {
		return idTipoLog;
	}

	public void setIdTipoLog(TipoProcessamentoEnum idTipoLog) {
		this.idTipoLog = idTipoLog;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getStatusLog() {
		return statusLog;
	}

	public void setStatusLog(String statusLog) {
		this.statusLog = statusLog;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public BigInteger getCodigoCobertura() {
		return codigoCobertura;
	}

	public void setCodigoCobertura(BigInteger codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}

}
