package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemCosseguradoView;
import br.com.tokiomarine.ctpj.cotacao.validator.constraint.IncluirParaTodosItemCossegurado;

public class IncluirParaTodosItemCosseguradoValidator implements ConstraintValidator<IncluirParaTodosItemCossegurado, ItemCosseguradoView> {

	@Override
	public void initialize(IncluirParaTodosItemCossegurado constraintAnnotation) {
		
	}

	@Override
	public boolean isValid(ItemCosseguradoView item, ConstraintValidatorContext context) {
		if(!item.getIncluirParaTodos()){
			return possuiItemCotacao(item);
		}		
		
		return true;
	}

	private boolean possuiItemCotacao(ItemCosseguradoView item) {
		return item.getItemCotacao() == null ? false : true;
	}

}
