package br.com.tokiomarine.ctpj.infra.mongo.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoValoresResseguro;

@Repository
public class ProdutoValoresResseguroRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	@LogPerformance
	public ProdutoValoresResseguro findByProduto(Cotacao cotacao) {
		return mongoTemplate.findOne(
				query(
						where("produto").is(cotacao.getCodigoProduto())
						.and("dataInicioVigencia").lte(new Date())
						.orOperator(
								where("dataTerminoVigencia").gte(new Date()),
								where("dataTerminoVigencia").is(null))), 
				ProdutoValoresResseguro.class);
	}
}
