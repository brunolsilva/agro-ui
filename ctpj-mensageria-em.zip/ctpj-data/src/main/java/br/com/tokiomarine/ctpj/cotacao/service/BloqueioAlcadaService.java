package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.repository.BloqueioAlcadaRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class BloqueioAlcadaService {

	private static Logger logger = LogManager.getLogger(BloqueioAlcadaService.class);

	@Autowired
	private BloqueioAlcadaRepository repository;

	public List<BloqueioAlcada> listaMensagensBloqueio(BigInteger cotacao) {
		return repository.listaMensagensBloqueio(cotacao);
	}

	@LogPerformance
	public void saveAll(List<BloqueioAlcada> bloqueios) throws ServiceException {
		try {
			for (BloqueioAlcada bloqueioAlcada : bloqueios) {
				bloqueioAlcada.setDataAtualizacao(Calendar.getInstance().getTime());
				repository.save(bloqueioAlcada);
			}
		} catch (HibernateException h) {
			logger.error("Erro ao Gravar Bloqueio Alcada");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Gravar Bloqueio Alcada");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public BloqueioAlcada save(BloqueioAlcada bloqueioAlcada) throws ServiceException {
		logger.info("Salvando bloqueio alçada....");
		try {
			bloqueioAlcada.setDataAtualizacao(Calendar.getInstance().getTime());
			return repository.save(bloqueioAlcada);
		} catch (HibernateException h) {
			logger.error("Erro ao Gravar Bloqueio Alcada");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Gravar Bloqueio Alcada");
			throw new ServiceException(e.getMessage(),e);
		}
	}

}
