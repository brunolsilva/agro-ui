package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.sct.response.DadosDevolucaoSctResponse;
import br.com.tokiomarine.ctpj.util.RestTemplateUtil;

@Service
public class DevolucaoService {

	private static Logger logger = LogManager.getLogger(DevolucaoService.class);

	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private ItemCotacaoRepository itemCotacaoRepository;

	@Autowired
	private ParametroGeralService parametroGeralService;

	private RestTemplate restTemplate = RestTemplateUtil.restTemplate(400000);

	// mensagens de validação
	public static final String MENSAGEM_FORMA_DEVOLUCAO_NULA = "Favor informar uma Forma de Devolução";
	public static final String MENSAGEM_DIGITO_CONTA_CORRENTE_NULO = "Favor informar o Dígito da Conta Corrente para devolução de crédito";
	public static final String MENSAGEM_CONTA_CORRENTE_NULA = "Favor informar a Conta Corrente para devolução de crédito";
	public static final String MENSAGEM_AGENCIA_NULA = "Favor informar a Agência para devolução de crédito";
	public static final String MENSAGEM_BANCO_NULO = "Favor informar o Banco para devolução de crédito";

	/**
	 * valida se há necessidade de devolução de crédito
	 * 
	 * @param cotacao
	 * @return
	 */
	public Boolean ehDevolucao(Cotacao cotacao) {
		if (cotacao == null) {
			return false;
		}
		Boolean premioEstaNegativo = cotacao.getValorPremioLiquido() != null && cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) < 0;
		return cotacao.getIdTipoPedidoCotacao().equals(TipoPedidoCotacaoEnum.ENDOSSO) && premioEstaNegativo;
	}
	
	public List<Validacao> validarDadosDevolucao(Cotacao cotacao, PropostaView proposta) {
		List<Validacao> listaValidacao = new ArrayList<>();
		
		if (this.ehDevolucao(cotacao) && cotacaoViewPreenchida(proposta)) {
			CotacaoView cotacaoView = proposta.getCotacao();
			ValidacaoFormaDevolucao validacaoFormaDevolucao = FormaDevolucaoFactory.getFormaDevolucao(cotacaoView.getCodigoFormaDevolucao())
																					.orElse(new ValidacaoFormaDevolucaoNula());
			validacaoFormaDevolucao.validar(cotacao, listaValidacao, cotacaoView);
		}

		return listaValidacao;
	}

	public DadosDevolucaoSctResponse consultaDadosDevolucaoSCT(BigInteger numeroSolicitacaoCotacao) throws ServiceException {
		DadosDevolucaoSctResponse reponseDadosDevolucaoSct = new DadosDevolucaoSctResponse();
		try {
			String url;

			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroSctConsultaDadosDevolucao();
			if (urlEnum == null) {
				logger.error("Erro ao na busca da url, urlEnum nula: " + urlEnum);
				throw new ServiceException("Não foi possível buscar os dados de devolução do SCT. Favor tentar novamente.");
			}

			try {
				url = parametroGeralService.getUrlByNome(urlEnum);
			} catch (ServiceException e) {
				logger.error("Erro ao recuperar url ", e);
				throw new ServiceException("Não foi possível buscar os dados de devolução do SCT. Favor tentar novamente.");
			}
			url = url+numeroSolicitacaoCotacao;
			logger.info("Url de buscaDadosDevolucaoSCT " + url);

			reponseDadosDevolucaoSct = restTemplate.getForObject(url,DadosDevolucaoSctResponse.class);

		} catch (HttpClientErrorException e) {
			logger.info("Erro buscar os dados de devolução do SCT: "+ e.getResponseBodyAsString());
			throw new ServiceException("Não foi possível buscar os dados de devolução do SCT. Favor tentar novamente.");
		} catch (Exception e) {
			logger.info("Erro buscar os dados de devolução do SCT:", e);
			throw new ServiceException("Erro buscar os dados de devolução do SCT:", e);
		}
		
		return reponseDadosDevolucaoSct;

	}
	
	public void ajustesDevolucaoAntesDeTransmitir(Cotacao cotacao) {
		opcaoParcelamentoService.criarOpcaoParcelamentoDevolucao(cotacao);
//		alterarTipoEndossoItensDevolucao(cotacao, TipoEndossoEnum.ALTERACAO);
	}

	private void alterarTipoEndossoItensDevolucao(Cotacao cotacao, TipoEndossoEnum tipoEndosso) {
		if(ehDevolucao(cotacao) && cotacao.getIdTipoEndosso().equals(TipoEndossoEnum.CANCELAMENTO_APOLICE)) {
			Set<ItemCotacao> itensCotacao = cotacao.getListItem();
			if(itensCotacao!= null && !itensCotacao.isEmpty()) {
				for(ItemCotacao item : itensCotacao) {
					item.setIdTipoEndosso(tipoEndosso.getId());
					itemCotacaoRepository.update(item);
				}
			}			
		}
	}
	
	public void ajustesDevolucaoAposTransmitir(Cotacao cotacao) {
		opcaoParcelamentoService.alterarParcelamentoEscolhidoDevolucao(cotacao);
		alterarTipoEndossoItensDevolucao(cotacao, TipoEndossoEnum.CANCELAMENTO_APOLICE);
	}
	
	private boolean cotacaoViewPreenchida(PropostaView proposta) {
		return proposta != null && proposta.getCotacao() != null;
	}
}

/**
 * interface validação forma devolução
 * 
 * @author T804294
 *
 */
interface ValidacaoFormaDevolucao {
	void validar(Cotacao cotacao, List<Validacao> listaValidacao, CotacaoView cotacaoView);
}

/**
 * validação para forma de devolução em recibo
 * 
 * @author T804294
 *
 */
class ValidacaoRecibo implements ValidacaoFormaDevolucao {

	@Override
	public void validar(Cotacao cotacao, List<Validacao> listaValidacao, CotacaoView cotacaoView) {
		
		if(cotacao.getIdDestinoEmissao() != DestinoEmissaoEnum.ACX) {
//			if (cotacaoView.getNumeroBancoDevolucao() == null) {
//				listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_BANCO_NULO));
//			}
//
//			if (cotacaoView.getNumeroAgenciaDevolucao() == null) {
//				listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_AGENCIA_NULA));
//			}			
		}
	}
}

/**
 * validação para forma de devolução crédito em conta
 * 
 * @author T804294
 *
 */
class ValidacaoCreditoEmConta implements ValidacaoFormaDevolucao {

	@Override
	public void validar(Cotacao cotacao, List<Validacao> listaValidacao, CotacaoView cotacaoView) {
		if (cotacaoView.getNumeroBancoDevolucao() == null) {
			listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_BANCO_NULO));
		}

		if (cotacaoView.getNumeroAgenciaDevolucao() == null) {
			listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_AGENCIA_NULA));
		}

		if (cotacaoView.getNumeroContaCorrenteDevolucao() == null) {
			listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_CONTA_CORRENTE_NULA));
		}

		if (cotacaoView.getNumeroDigitoContaCorrenteDevolucao() == null
				|| cotacaoView.getNumeroDigitoContaCorrenteDevolucao().isEmpty()) {
			listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_DIGITO_CONTA_CORRENTE_NULO));
		}
	}
}

/**
 * validação para forma de devolução nula
 * 
 * @author T804294
 *
 */
class ValidacaoFormaDevolucaoNula implements ValidacaoFormaDevolucao {

	@Override
	public void validar(Cotacao cotacao, List<Validacao> listaValidacao, CotacaoView cotacaoView) {
		if (cotacaoView.getCodigoFormaDevolucao() == null) {
			listaValidacao.add(new Validacao(DevolucaoService.MENSAGEM_FORMA_DEVOLUCAO_NULA));
		}
	}

}

/**
 * validação para forma de devolução cheque
 * 
 * @author T804294
 *
 */
class ValidacaoCheque implements ValidacaoFormaDevolucao {
	@Override
	public void validar(Cotacao cotacao, List<Validacao> listaValidacao, CotacaoView cotacaoView) {
		// do nothing
	}
}

class FormaDevolucaoFactory {
	private FormaDevolucaoFactory() {
	}

	static EnumMap<FormaDevolucaoApoliceEnum, ValidacaoFormaDevolucao> formaDevolucaoMap = new EnumMap<>(
			FormaDevolucaoApoliceEnum.class);
	static {
		formaDevolucaoMap.put(FormaDevolucaoApoliceEnum.CHEQUE, new ValidacaoCheque());
		formaDevolucaoMap.put(FormaDevolucaoApoliceEnum.CREDITO_CONTA, new ValidacaoCreditoEmConta());
		formaDevolucaoMap.put(FormaDevolucaoApoliceEnum.RECIBO, new ValidacaoRecibo());
	}

	public static Optional<ValidacaoFormaDevolucao> getFormaDevolucao(FormaDevolucaoApoliceEnum formaDevolucao) {
		return Optional.ofNullable(formaDevolucaoMap.get(formaDevolucao));
	}
}
