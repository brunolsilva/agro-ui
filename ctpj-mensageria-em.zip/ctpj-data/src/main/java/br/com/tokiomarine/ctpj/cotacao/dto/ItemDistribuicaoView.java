package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.enums.TipoValorRiscoDistribuidoEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemDistribuicaoView implements Serializable {

	private static final long serialVersionUID = 4836238359223464265L;

	private String descricaoRiscoBem;
	private String valorRiscoBem;
	private TipoValorRiscoDistribuidoEnum idTipoValorRisco;

	public String getDescricaoRiscoBem() {
		return descricaoRiscoBem;
	}

	public void setDescricaoRiscoBem(String descricaoRiscoBem) {
		this.descricaoRiscoBem = descricaoRiscoBem;
	}

	public String getValorRiscoBem() {
		return valorRiscoBem;
	}

	public void setValorRiscoBem(String valorRiscoBem) {
		this.valorRiscoBem = valorRiscoBem;
	}

	public TipoValorRiscoDistribuidoEnum getIdTipoValorRisco() {
		return idTipoValorRisco;
	}

	public void setIdTipoValorRisco(TipoValorRiscoDistribuidoEnum idTipoValorRisco) {
		this.idTipoValorRisco = idTipoValorRisco;
	}
}