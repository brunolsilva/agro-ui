package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;
import java.util.List;

/**
 * View que transporta os dados de claúsula capa para serem salvos
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class ListClausulaCapaView {
	
	private BigInteger cotacao;
	private List<Integer> codigosClausulas;

	public BigInteger getCotacao() {
		return cotacao;
	}

	public void setCotacao(BigInteger cotacao) {
		this.cotacao = cotacao;
	}

	public List<Integer> getCodigosClausulas() {
		return codigosClausulas;
	}

	public void setCodigosClausulas(List<Integer> codigosClausulas) {
		this.codigosClausulas = codigosClausulas;
	}

}
