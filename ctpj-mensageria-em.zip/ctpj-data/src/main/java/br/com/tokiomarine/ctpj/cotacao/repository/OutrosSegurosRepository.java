package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;

@Repository
public class OutrosSegurosRepository extends BaseDAO {

	@SuppressWarnings("unchecked")
	public List<ItemOutroSeguro> find(BigInteger cotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" from 	ItemOutroSeguro os ");
		hql.append(" where	os.itemCotacao.cotacao.sequencialCotacaoProposta = :cotacao");
		hql.append(" order 	by os.itemCotacao.numeroItem ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("cotacao", cotacao);
		
		return (List<ItemOutroSeguro>) query.list();
	}

	public ItemOutroSeguro save(ItemOutroSeguro outroSeguro) {
		return (ItemOutroSeguro) getCurrentSession().merge(outroSeguro);
	}

	public void delete(BigInteger outroSeguro) {
		ItemOutroSeguro os = new ItemOutroSeguro();
		os.setSequencialItemOutroSeguro(outroSeguro);
		getCurrentSession().delete(os);
	}
	
	public Integer geraSequencialControle(BigInteger sqItemCotacao) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select max(os.sequencialItemOutroControle) from 	ItemOutroSeguro os ");
		hql.append(" where	os.itemCotacao.sequencialItemCotacao = :sqItemCotacao ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sqItemCotacao", sqItemCotacao);
		
		return (Integer) query.uniqueResult();
	}
}