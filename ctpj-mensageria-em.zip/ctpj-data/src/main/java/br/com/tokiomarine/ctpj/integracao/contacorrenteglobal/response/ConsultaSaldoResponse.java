package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class ConsultaSaldoResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -961818572323169375L;
	private long codigoErro;
	private List<SaldoResponse> listaSaldo = null;
	private List<String> mensagensErro = null;
    private String tipoOperacao;
    private BigDecimal valorAgravo;
    private BigDecimal valorMaximoDesconto;

	public long getCodigoErro() {
		return codigoErro;
	}

	public void setCodigoErro(long codigoErro) {
		this.codigoErro = codigoErro;
	}

	public List<SaldoResponse> getListaSaldo() {
		return listaSaldo;
	}

	public void setListaSaldo(List<SaldoResponse> listaSaldo) {
		this.listaSaldo = listaSaldo;
	}

	public List<String> getMensagensErro() {
		return mensagensErro;
	}

	public void setMensagensErro(List<String> mensagensErro) {
		this.mensagensErro = mensagensErro;
	}

	public String getTipoOperacao() {
		return tipoOperacao;
	}

	public void setTipoOperacao(String tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

	public BigDecimal getValorAgravo() {
		return valorAgravo;
	}

	public void setValorAgravo(BigDecimal valorAgravo) {
		this.valorAgravo = valorAgravo;
	}

	public BigDecimal getValorMaximoDesconto() {
		return valorMaximoDesconto;
	}

	public void setValorMaximoDesconto(BigDecimal valorMaximoDesconto) {
		this.valorMaximoDesconto = valorMaximoDesconto;
	}

	@Override
	public String toString() {
		return "ConsultaSaldoResponse [codigoErro=" + codigoErro + ", listaSaldo=" + listaSaldo + ", mensagensErro="
				+ mensagensErro + ", tipoOperacao=" + tipoOperacao + ", valorAgravo=" + valorAgravo
				+ ", valorMaximoDesconto=" + valorMaximoDesconto + "]";
	}
}
