package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.cliente.dto.Consulta;
import br.com.tokiomarine.cliente.dto.persistencia.EnderecoCliente;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CobrancaAgenciaResponse;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosAgenciaView;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosContaDebitoView;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosCrivo;
import br.com.tokiomarine.ctpj.cotacao.dto.DataMinimaVencimentoView;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.SeguradoEndereco;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Municipio;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.MunicipioService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.cliente.service.EnderecoClienteService;
import br.com.tokiomarine.ctpj.integracao.service.CrivoService;
import br.com.tokiomarine.ctpj.mapper.ConsultaAgenciaMapper;
import br.com.tokiomarine.ctpj.mapper.DadosAgenciaViewMapper;
import br.com.tokiomarine.ctpj.service.BaseUnicaService;

@Controller
@RequestMapping(value = "/commons")
public class CotacaoCommonsController {

	private static final Logger logger = LogManager.getLogger(CotacaoCommonsController.class);
	
	private static final String MENSAGEM_URL_NULA = "Erro ao na busca da url, urlEnum nula: "; 

	@Autowired
	private BaseUnicaService baseUnicaService;

	@Autowired
	private MunicipioService municipioService;

	private RestTemplate restTemplate = new RestTemplate();
	
	@Autowired
	private ParametroGeralService parametroGeralService;
	
	@Autowired
	private CrivoService crivoService;
	
	@Autowired
	private EnderecoClienteService enderecoClienteService;
	
	@LogPerformance
	@RequestMapping(value = "/endereco",method = RequestMethod.GET)
	public @ResponseBody ResultadoREST<SeguradoEndereco> findEndereco(
			@RequestParam(value = "cep", required = false) String cep) {
		ResultadoREST<SeguradoEndereco> retorno = new ResultadoREST<>();
		try {
			List<SeguradoEndereco> enderecos = baseUnicaService.getEnderecoByCEP(cep);
			retorno.setSuccess(Boolean.TRUE);
			retorno.setListaRetorno(enderecos);
		} catch (Exception e) {
			logger.error("Erro na busca de CEP", e);
			retorno.setSuccess(Boolean.FALSE);
			retorno.setThrowable(e);
			retorno.setMensagem("Serviço de Busca de CEP indisponível. Informe os Dados Manualmente.");
		}

		return retorno;
	}

	@LogPerformance
	@RequestMapping(value = "/cep/{endereco}/{bairro}/{municipio}/{uf}",method = RequestMethod.GET)
	public @ResponseBody ResultadoREST<SeguradoEndereco> findEndereco(
			@PathVariable("endereco") String endereco,
			@PathVariable("bairro") String bairro,
			@PathVariable("municipio") String municipio,
			@PathVariable("uf") String uf) {

		ResultadoREST<SeguradoEndereco> retorno = new ResultadoREST<>();
		try {
			List<SeguradoEndereco> enderecos = baseUnicaService.getCepByEndereco(endereco,bairro,municipio,uf);
			retorno.setSuccess(Boolean.TRUE);
			retorno.setListaRetorno(enderecos);
		} catch (Exception e) {
			logger.error("Erro na busca de CEP", e);
			retorno.setSuccess(Boolean.FALSE);
			retorno.setThrowable(e);
			retorno.setMensagem("Serviço de Busca de CEP indisponível. Informe os Dados Manualmente.");
		}

		return retorno;
	}
	
	@LogPerformance
	@RequestMapping(value = "/enderecoComMunicipio",method = RequestMethod.GET)
	public @ResponseBody ResultadoREST<SeguradoEndereco> findEnderecoComMunicipio(
			@RequestParam(value = "cep", required = false) String cep) {
		ResultadoREST<SeguradoEndereco> retorno = new ResultadoREST<>();
		try {
			List<SeguradoEndereco> enderecos = baseUnicaService.getEnderecoByCEP(cep);
			if(enderecos != null && enderecos.size() == 1) {
				SeguradoEndereco endereco = enderecos.get(0);
				municipioService.getMunicipioByCep(endereco);
			}

			retorno.setSuccess(Boolean.TRUE);
			retorno.setListaRetorno(enderecos);
		} catch (Exception e) {
			logger.error("Erro na busca de CEP", e);
			retorno.setSuccess(Boolean.FALSE);
			retorno.setThrowable(e);
			retorno.setMensagem("Serviço de Busca de CEP indisponível. Informe os Dados Manualmente.");
		}

		return retorno;
	}

	@LogPerformance
	@RequestMapping(value = "/municipios",method = RequestMethod.GET)
	public @ResponseBody ResultadoREST<Municipio> findMunicipios(
			@RequestParam(value = "uf", required = false) String uf) {
		ResultadoREST<Municipio> retorno = new ResultadoREST<>();
		try {
			List<Municipio> municipios = municipioService.findMunicipios(uf);
			retorno.setSuccess(Boolean.TRUE);
			retorno.setListaRetorno(municipios);
		} catch (Exception e) {
			logger.error("Erro na busca de CEP", e);
			retorno.setSuccess(Boolean.FALSE);
			retorno.setThrowable(e);
			retorno.setMensagem("Serviço de Busca de Municípios indisponível. Tente Novamente!");
		}

		return retorno;
	}

	@LogPerformance
	@PostMapping(value = "/devolverDadosAgencia")
	public @ResponseBody ResultadoREST<DadosAgenciaView> devolverDadosAgencia(@RequestBody Map<String, Object> dadosAgencia) {
		logger.info("Chamando devolverDadosAgencia " + dadosAgencia);
		ResultadoREST<DadosAgenciaView> resultado = new ResultadoREST<>();
		try {
		
			String codigoBanco = dadosAgencia.get("p_cd_banco").toString();
			String codigoAgencia = dadosAgencia.get("p_cd_agencia").toString();
			
			CobrancaAgenciaResponse cobrancaAgenciaResponse = getDadosAgencia(codigoBanco, codigoAgencia);
			resultado.setRetornoObj(DadosAgenciaViewMapper.getInstance().toDadosAgenciaView(cobrancaAgenciaResponse));
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		}
		catch (HttpClientErrorException hcee) {
			DadosAgenciaView retorno = new DadosAgenciaView();
			retorno.setCodigoRetorno("00");
			retorno.setDescricaoCodigoRetorno("");
			resultado.setRetornoObj(retorno);
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		}
		catch (Exception e) {
			logger.error("Erro na busca de Agência", e);
			resultado.setSuccess(Boolean.FALSE);
			resultado.setMensagem("Serviço de busca de dados de agência indisponível. Tente Novamente!");
			return resultado;
		}
	}

	private CobrancaAgenciaResponse getDadosAgencia(String codigoBanco, String codigoAgencia)
			throws ServiceException {
		ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroDadosAgencia();
		if (urlEnum == null) {
			
			logger.error(MENSAGEM_URL_NULA + urlEnum);
			throw new ServiceException(MENSAGEM_URL_NULA);
		}	
		
		String url = String.format(recuperaParametro(urlEnum), codigoBanco, codigoAgencia);
		
		return restTemplate.getForObject(url, CobrancaAgenciaResponse.class);
		
	}
	
	@LogPerformance
	@GetMapping(value = "/devolverDadosAgenciaCliente/{codigoBanco}/{codigoAgencia}")
	public @ResponseBody ResultadoREST<Consulta> devolverDadosAgenciaCliente(@PathVariable String codigoBanco, @PathVariable String codigoAgencia) {
		logger.info("Chamando devolverDadosAgencia " + codigoAgencia);
		ResultadoREST<Consulta> resultado = new ResultadoREST<>();
		try {
			CobrancaAgenciaResponse cobrancaAgenciaResponse = getDadosAgencia( codigoBanco, codigoAgencia);
			Consulta consultaRespose = ConsultaAgenciaMapper.getInstance().toConsulta(cobrancaAgenciaResponse);
			resultado.setRetornoObj(consultaRespose);
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		} 
		catch (HttpClientErrorException hcee) {
			//retorna desta forma pois o serviço anterior, quando não encontrava o banco informado, retornava os dados desta forma para a tela
			Consulta retorno = new Consulta();
			final String strTraco = "-";
			retorno.setEndereco(strTraco);
			retorno.setCidade(strTraco);
			retorno.setBairro(strTraco);
			retorno.setCep(strTraco);
			retorno.setNomeAgencia(strTraco);
			retorno.setTel(strTraco);
			resultado.setRetornoObj(retorno);
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		}
		catch (Exception e) {
			logger.error("Erro na busca de Agência Cliente", e);
			resultado.setSuccess(Boolean.FALSE);
			resultado.setMensagem("Serviço de busca de dados de agência cliente indisponível. Tente Novamente!");
			return resultado;
		}
	}
	
	@LogPerformance
	@GetMapping(value = "/devolverEnderecosCadastradosCliente/{codigoCliente}")
	public @ResponseBody ResultadoREST<List<EnderecoCliente>> devolverEnderecosCadastradosCliente(@PathVariable Long codigoCliente) {
		logger.info("Chamando devolverEnderecosCadastradosCliente " + codigoCliente);
		ResultadoREST<List<EnderecoCliente>> resultado = new ResultadoREST<>();
		try {
			List<EnderecoCliente> consultaResponse = enderecoClienteService.consultarEnderecosCliente(new Object[] {codigoCliente});
			resultado.setRetornoObj(consultaResponse);
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		} catch (Exception e) {
			logger.error("Erro na busca de Endereços do Cliente", e);
			resultado.setSuccess(Boolean.FALSE);
			resultado.setMensagem("Serviço de busca de endereços do cliente indisponível. Tente Novamente!");
			return resultado;
		}
	}
	

	@LogPerformance
	@PostMapping(value = "/devolverContaCorrente")
	public @ResponseBody ResultadoREST<DadosContaDebitoView> devolverContaCorrente(@RequestBody Map<Object, Object> dadosConta) {
		logger.info("Chamando devolverContaCorrente " + dadosConta);
		ResultadoREST<DadosContaDebitoView> resultado = new ResultadoREST<>();
		try {
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroDadosContaCorrente();
			if (urlEnum == null) {
				logger.error(MENSAGEM_URL_NULA + urlEnum);
				throw new ServiceException("Erro ao na busca da url, urlEnum nula ");
			}			
			
			String url = recuperaParametro(urlEnum);
			
			DadosContaDebitoView dadosContaDebitoView = restTemplate.postForObject(url, dadosConta, DadosContaDebitoView.class);
			resultado.setRetornoObj(dadosContaDebitoView);
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		} catch (Exception e) {
			logger.error("Erro na validação da conta", e);
			resultado.setSuccess(Boolean.FALSE);
			resultado.setMensagem("Serviço de validação da conta indisponível. Tente Novamente!");
			return resultado;
		}
	}
	
	@LogPerformance
	@PostMapping(value = "/dataMinimaVencimento")
	public @ResponseBody ResultadoREST<DataMinimaVencimentoView> dataMinimaVencimento(@RequestBody Map<String, Object> dadosBanco) {
		logger.info("Chamando devolverContaCorrente " + dadosBanco);
		ResultadoREST<DataMinimaVencimentoView> resultado = new ResultadoREST<>();
		try {
			
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroDataVencimentoDebito();
			if (urlEnum == null) {
				logger.error("Erro ao na busca da url, urlEnum nula: " + urlEnum);
				throw new ServiceException("Erro ao na busca da url, urlEnum nula ");
			}			
			
			String url = recuperaParametro(urlEnum);
			
			DataMinimaVencimentoView dataMinimaVencimentoView = restTemplate.postForObject(url, dadosBanco, DataMinimaVencimentoView.class);
			resultado.setRetornoObj(dataMinimaVencimentoView);
			resultado.setSuccess(Boolean.TRUE);
			return resultado;
		} catch (Exception e) {
			logger.error("Falha ao recuperar a data de vencimento", e);
			resultado.setSuccess(Boolean.FALSE);
			resultado.setMensagem("Falha ao recuperar a data de vencimento. Tente Novamente!");
			return resultado;
		}
	}

	private String recuperaParametro(ParametroGeralEnum urlEnum) throws ServiceException {
		try {
			return parametroGeralService.getUrlByNome(urlEnum);
		} catch (Exception e) {
			logger.error("Erro ao na consulta na busca do Parametro: " + e.getMessage());
			throw new ServiceException("Erro ao na consulta na busca do Parametro: ",e);
		}
	}
	
	@GetMapping("/dadosCrivo")
	public ResponseEntity<?> buscaDadosCrivo(@RequestParam("nroCotacao") BigInteger numeroCotacaoProposta, 
			@RequestParam("codProduto") Integer codProduto, @RequestParam("tipoPessoa") TipoSeguradoEnum tipoPessoa, 
			@RequestParam("cpfCnpj") String cpfCnpj, @RequestParam("codCorretor") String codCorretorACSEL){
		
		try {
			DadosCrivo dadosCrivo = crivoService.buscaDadosCrivo(numeroCotacaoProposta, codProduto, tipoPessoa, cpfCnpj, codCorretorACSEL);
			return ResponseEntity.ok(dadosCrivo);
		} catch (ServiceException e) {
			logger.error("Erro na busca dos dados do crivo", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro na busca dos dados do crivo");
		}
		
	}
}
