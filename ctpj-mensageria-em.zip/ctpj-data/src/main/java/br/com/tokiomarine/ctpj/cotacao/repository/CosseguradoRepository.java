package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;

/**
 * Repositório de acesso e manutenção da entidade ItemCossegurado
 * 
 * @author Hromenique Cezniowscki Leite Batiata
 *
 */
@Repository
public class CosseguradoRepository extends BaseDAO{
	private static final String PROX_NRO_COSSEGURADO_HQL = 
			"select max(itemCosseg.numeroCossegurado) " +
			"from ItemCossegurado itemCosseg " + 
				"join itemCosseg.itemCotacao itemCot " +	
				"join itemCot.cotacao cot " +
			"where " +
				"cot.sequencialCotacaoProposta = :sequencialCotacaoProposta ";
	
	private static final String LISTA_ITENS_COTACAO_POR_COTACAO_HQL = 
			"select itemCosseg " +
			"from ItemCossegurado itemCosseg " + 
				"join itemCosseg.itemCotacao itemCot " +	
				"join itemCot.cotacao cot " +
			"where " +
				"cot.sequencialCotacaoProposta = :sequencialCotacaoProposta " +
			"order by itemCosseg.numeroCossegurado";
	
	private static final String BUSCA_ITENS_COSSEGURADO_HQL = 
			"select itemCoss " +
			"from ItemCossegurado itemCoss " + 
				"join itemCoss.itemCotacao itemCot " +	
				"join itemCot.cotacao cot " +
			"where " +
				"cot.sequencialCotacaoProposta = :seqCotacao ";
	
	private static final String EXCLUI_ITENS_COSSEGURADO_POR_COTACAO = 
			"delete from ItemCossegurado ib " +
			"where ib in (" + BUSCA_ITENS_COSSEGURADO_HQL + ")";
	
	/**
	 * Salva um item cossegurado
	 * 
	 * @param item
	 * @return O item cossegurado salvo e atualizado com a chave primária criada
	 */
	public ItemCossegurado salvaItemCossegurado(ItemCossegurado item){
		getCurrentSession().persist(item);
		
		return item;
	}

	/**
	 * Retorna o próximo número de cossegurado
	 * 
	 * @param sequencialCotacaoProposta
	 * @return
	 */
	@LogPerformance
	public BigInteger proximoNroCossegurado(BigInteger sequencialCotacaoProposta) {
		Query query = getCurrentSession().createQuery(PROX_NRO_COSSEGURADO_HQL);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		BigInteger maiorNroCossegurado = (BigInteger)query.uniqueResult();
		
		if(maiorNroCossegurado == null)
			return BigInteger.ONE;
		
		return maiorNroCossegurado.add(BigInteger.ONE);
	}
	
	/**
	 * Lista os ItensCossegurados pertecentes a uma dada Cotação
	 * 
	 * @param sequencialCotacaoProposta identificador da Cotação
	 * @return Uma Lista contendo os ItensCossegurados. A lista será vazia caso não seja encontrados itens para o sequencialCotacaoProposta fornecido
	 */
	@LogPerformance
	@SuppressWarnings("unchecked")
	public List<ItemCossegurado> listaItensCosseguradoPorCotacao(BigInteger sequencialCotacaoProposta){
		Query query = getCurrentSession().createQuery(LISTA_ITENS_COTACAO_POR_COTACAO_HQL);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		
		return (List<ItemCossegurado>) query.list();
	}

	/**
	 * Exclui um ItemCossegurado pertecente a uma dada Cotação
	 * 
	 * @param sequencialItemCossegurado identificador do ItemCossegurado
	 */
	@LogPerformance
	public void excluiItemCossegurado(BigInteger sequencialItemCossegurado) {
		ItemCossegurado itemParaExclusao = new ItemCossegurado();
		itemParaExclusao.setSequencialItemCossegurado(sequencialItemCossegurado);
		getCurrentSession().delete(itemParaExclusao);
	}

	public int excluiItemCosseguradoPorCotacao(BigInteger seqCotacao) {
		return getCurrentSession()
				.createQuery(EXCLUI_ITENS_COSSEGURADO_POR_COTACAO)
				.setParameter("seqCotacao", seqCotacao)
				.executeUpdate();
	}

	public List<ItemCossegurado> salvaItemCossegurado(List<ItemCossegurado> itens) {
		itens.forEach(item -> salvaItemCossegurado(item));
		return itens;
	}
}
