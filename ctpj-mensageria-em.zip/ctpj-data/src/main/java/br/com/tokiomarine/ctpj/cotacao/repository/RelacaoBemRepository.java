package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;

/**
 * Repositório de acesso a dados para a entidade RelacaoBem e entidades relacionadas
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Repository
public class RelacaoBemRepository extends BaseDAO {
	
	private static final String BUSCA_ITENS_RELACAO_BEM_HQL = 
			"select itemRB " +
			"from ItemRelacaoBem itemRB " + 
				"join itemRB.itemCotacao itemCot " +	
				"join itemCot.cotacao cot " +
			"where " +
				"cot.sequencialCotacaoProposta = :sequencialCotacaoProposta ";
	
	private static final String BUSCA_ITENS_RELACAO_BEM_ASC_HQL = 
			BUSCA_ITENS_RELACAO_BEM_HQL + 
			"order by itemRB.sequencialRelacaoBem ASC ";
	
	private static final String PROX_NRO_SEQ_ITEM_RELACAO_BEM_HQL = 
			BUSCA_ITENS_RELACAO_BEM_HQL + 
			"order by itemRB.sequencialRelacaoBem DESC ";
	
	private static final String EXCLUI_ITENS_RELACAO_POR_COTACAO = 
			"delete from ItemRelacaoBem ib " +
			"where ib in (" + BUSCA_ITENS_RELACAO_BEM_HQL + ")";
	
	
	/**
	 * Retorna o próximo número sequencial da entidade ItemRelacaoBem
	 * 
	 * @param sequencialCotacaoProposta identificador do item da cotação para o qual o ItemRelacaoBem pertence 
	 * @return
	 */
	@LogPerformance
	public BigInteger proximoNrolItemRelacaoBem(BigInteger sequencialCotacaoProposta){
		Query query = getCurrentSession().createQuery(PROX_NRO_SEQ_ITEM_RELACAO_BEM_HQL);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		query.setMaxResults(1);
		ItemRelacaoBem result = (ItemRelacaoBem) query.uniqueResult();
		
		if(result == null)
			return BigInteger.ONE;
		
		return result.getSequencialRelacaoBem().add(BigInteger.ONE); 
	}


	/**
	 * Busca os Itens de Relação Bem
	 * 
	 * @param sequencialCotacaoProposta identificador da cotação para o qual os itens da relação de bens serão recuperados
	 * @return
	 */
	@LogPerformance
	@SuppressWarnings("unchecked")
	public List<ItemRelacaoBem> buscaListaItemRelacaoBem(BigInteger sequencialCotacaoProposta) {
		Query query = getCurrentSession().createQuery(BUSCA_ITENS_RELACAO_BEM_ASC_HQL);
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		
		return (List<ItemRelacaoBem>) query.list();
	}
	

	/**
	 * Salva um ItemRelacaoBem
	 * 
	 * @param itemRelacaoBem
	 * @return
	 */
	@LogPerformance
	public void salvaItemRelacaoBem(ItemRelacaoBem itemRelacaoBem) {
		getCurrentSession().persist(itemRelacaoBem);
	}
	
	public List<ItemRelacaoBem> salvaItemRelacaoBem(List<ItemRelacaoBem> itens){
		itens.forEach(item -> salvaItemRelacaoBem(item));
		return itens;
	}

	/**
	 * Exclui um ItemRelacaoBem
	 * 
	 * @param sequencialItemRelacaoBem
	 */
	@LogPerformance
	public void excluiItemRelacaoBem(BigInteger sequencialItemRelacaoBem) {
		ItemRelacaoBem item = new ItemRelacaoBem();
		item.setSequencialItemRelacaoBem(sequencialItemRelacaoBem);
		
		getCurrentSession().delete(item);
	}
	
	public int excluiItemRelacaoPorCotacao(BigInteger seqCotacao){
		return getCurrentSession()
				.createQuery(EXCLUI_ITENS_RELACAO_POR_COTACAO)
				.setParameter("sequencialCotacaoProposta", seqCotacao)
				.executeUpdate();
	}
}