package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.infra.domain.BancoCorretorPadrao;
import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.infra.domain.CorretorValorRisco;

@Repository
public class CorretorRepository {
	@Autowired
	private MongoTemplate mongoTemplate;

	public List<Corretor> findCorretores() {
		return mongoTemplate.find(
				query(
						where("dataInicioVigencia").lte(new Date())
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))

				).with(new Sort(Direction.ASC, "nome")) , Corretor.class);
	}

	public Corretor findCorretorByCodigo(Long codigoCorretor) {
		return (Corretor) mongoTemplate.findOne(
				query(
						where("codigo").is(codigoCorretor)
				), Corretor.class);
	}

	public List<Corretor> findCorretoresByNome(String q) {
		List<Corretor> corretores = mongoTemplate.find(
				query(
						where("dataInicioVigencia").lte(new Date())
							.and("nome").regex(".*" + q + ".*", "i")
							.orOperator(
									where("dataTerminoVigencia").gte(new Date()),
									where("dataTerminoVigencia").is(null))

				).with(new Sort(Direction.ASC, "nome")), Corretor.class);
		if(corretores != null && corretores.isEmpty()) {
			try {
				corretores = mongoTemplate.find(
						query(
								where("dataInicioVigencia").lte(new Date())
									.and("codigo").is(Long.parseLong(q))
									.orOperator(
											where("dataTerminoVigencia").gte(new Date()),
											where("dataTerminoVigencia").is(null))

						).with(new Sort(Direction.ASC, "nome")), Corretor.class);
			} catch (Exception e) {
				/**
				 * 
				 */
			}
		}
		return corretores;
	}
	
	public CorretorValorRisco findCorretorVR(Cotacao cotacao) {
		return mongoTemplate.findOne(
				query(
						where("corretor").is(cotacao.getCodigoCorretorACSEL())
				).with(new Sort(Direction.ASC, "nome")) , CorretorValorRisco.class);
	}

	public void save(Corretor corretor) {
		mongoTemplate.save(corretor);
	}
	
	public BancoCorretorPadrao findBancoCorretorPadraoByCodigo(Long codigoCorretor) {
		return (BancoCorretorPadrao) mongoTemplate.findOne(
				query(where("corretor").is(codigoCorretor)
						.and("dataInicioVigencia").lte(new Date())
				).with(new Sort(Direction.DESC, "dataInicioVigencia")), BancoCorretorPadrao.class);
	}


}
