package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;
import java.util.List;

/**
 * Objeto da camada de View que representa uma linha na tabela de Rubricas
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class LinhaRubricaView {

	private BigInteger itemCotacao;
	private Long codigoRubrica;
	private String descricaoRubrica;
	private List<ClausulaView> clausulas;
	
	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public Long getCodigoRubrica() {
		return codigoRubrica;
	}

	public Long getCocodigoRubrica() {
		return codigoRubrica;
	}

	public void setCodigoRubrica(Long codigoRubrica) {
		this.codigoRubrica = codigoRubrica;
	}

	public String getDescricaoRubrica() {
		return descricaoRubrica;
	}

	public void setDescricaoRubrica(String descricaoRubrica) {
		this.descricaoRubrica = descricaoRubrica;
	}

	public List<ClausulaView> getClausulas() {
		return clausulas;
	}

	public void setClausulas(List<ClausulaView> clausulas) {
		this.clausulas = clausulas;
	}
}
