package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoPagamentoView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.ComissaoAntecipadaService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.ParcelamentoJaneladoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.ParcelamentoJanelado;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemRequestEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@RequestMapping(value = "/parcelamento")
@Controller
public class ParcelamentoController extends AbstractController {
	
	private static Logger logger= LogManager.getLogger(ParcelamentoController.class);
	
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private RecebimentoService recebimentoService;
	
	@Autowired
	private ComissaoAntecipadaService comissaoAntecipadaService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;

	@Autowired
	private ParcelamentoJaneladoService parcelamentoJaneladoService;

	@LogPerformance
	@GetMapping(value = "/{id}")
	public String parcelamento(@PathVariable BigInteger id, Model model) {
		try {
			this.opcoesParcelamento(id, model, false,TipoOrigemRequestEnum.COTACAO);
		} catch (AccessDeniedException e) {
//			model.addAttribute("msgAcessoNegado", "Você não tem permissão!");
			return "/erros/404";
		} catch (Exception e) {
			logger.error("Erro ao recuperar as opções de Pagamento ", e);
			return "/erro";
		}
		
		return "/cotacao/parcelamentos";
	}
	
	@LogPerformance
	@GetMapping(value = "/efetivado/{id}/origem/{origem}")
	public String parcelamentoEfetivado(@PathVariable BigInteger id,@PathVariable Integer origem, Model model) {
		try {
			this.opcoesParcelamento(id, model, true, TipoOrigemRequestEnum.COTACAO.getId() == origem ? TipoOrigemRequestEnum.COTACAO : TipoOrigemRequestEnum.PROPOSTA);
		} catch (Exception e) {
			logger.error("Erro ao recuperar as opções de Pagamento ", e);
			return "/erro";
		}
		
		return "/cotacao/parcelamentos";
	}
	
	private void opcoesParcelamento(BigInteger id, Model model, Boolean verificarParcelamentoEfetivado, TipoOrigemRequestEnum origem) throws ServiceException{
		Cotacao cotacao = cotacaoService.findCotacaoParcelamento(id);
		CotacaoView cotacaoCabecalho = cotacaoService.findCotacaoCabecalho(cotacao.getSequencialCotacaoProposta());
		if(cotacaoCabecalho.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO) {
			throw new AccessDeniedException("Cotação não calculada!");
		}
		model.addAttribute("cabecalhoCotacao", cotacaoCabecalho);
		List<OpcaoParcelamento> parcelamentos = opcaoParcelamentoService.listar(cotacao.getSequencialCotacaoProposta(),cotacao.getNumeroCotacaoProposta());

		Optional<ComissaoCotacao> optComissoes = cotacao.getListComissaoCotacao().stream().findFirst();

		if(optComissoes.isPresent() && optComissoes.get().getPercentualComissao() != null) {
			model.addAttribute("comissao", optComissoes.get().getPercentualComissao());
		} else {
			model.addAttribute("comissao", "0.0");
		}
		
		model.addAttribute("parcelamentos", parcelamentos);
		model.addAttribute("cotacao", cotacao);
		if(verificarParcelamentoEfetivado){
			validarParcelamentoEfetivado(model, cotacao, parcelamentos);
			model.addAttribute("telaOrigem",origem.equals(TipoOrigemRequestEnum.COTACAO) ? TipoOrigemRequestEnum.COTACAO.getId() : TipoOrigemRequestEnum.PROPOSTA.getId());
		}
		model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly());
		GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
		if(perfilComercialService.hasPerfilComercial(grupoUsuario) && !CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao().equals(cotacao.getCodigoSituacao().longValue())) {
			model.addAttribute("readOnly",true);
		}
	}

	private void validarParcelamentoEfetivado(Model model, Cotacao cotacao, List<OpcaoParcelamento> parcelamentos)
			throws ServiceException {
		//recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO)
		Recebimento recebimento = recebimentoService.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		if(recebimento != null && recebimento.getIdTipoCredito() != null ){
			model.addAttribute("tipoCredito",recebimento.getIdTipoCredito().getId());
			if(recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO)){
				model.addAttribute("parcelamentoEfetivado", "S");
			}
			
		}
	}

	@LogPerformance
	@PostMapping(value = "/salvar")
	public ResponseEntity<ResultadoREST<Object>> salvar(@RequestBody List<CotacaoPagamentoView> pagamento) {
		ResultadoREST<Object> resultado = new ResultadoREST<>();
		resultado.setSuccess(true);
		try {
			if(pagamento.get(0).getOpcaoSelecionada() == null) {
				resultado.setListaValidacao(Arrays.asList(new Validacao("É obrigatório escolher uma opção de pagamento")));
				resultado.setSuccess(false);
				return ResponseEntity.ok(resultado);
			}
			
			if(pagamento.get(0).getCotacao() != null) {
				User user = SecurityUtils.getCurrentUser();
				comissaoAntecipadaService.atualizarComissaoAntecipada(pagamento,user);
				List<Validacao> validacao = opcaoParcelamentoService.salvar(pagamento);
				resultado.setSuccess(true);
				if(validacao != null && !validacao.isEmpty()) {
					resultado.setListaValidacao(validacao);
					resultado.setSuccess(false);
				}
			}
			
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error(String.format("Erro ao atualizar a opção de pagamento cotacao[%s] pagamento[%s]", pagamento.get(0).getCotacao(), pagamento.get(0).getOpcaoSelecionada()), e);
			resultado.setSuccess(false);
			return ResponseEntity.ok(resultado);
		}
	}

	@LogPerformance
	@GetMapping(value = "/{id}/janelado")
	public String exibirParcelamentoJanelado(@PathVariable BigInteger id, Model model) {
		try {
			Cotacao cotacao = cotacaoService.findCotacaoParcelamento(id);
			CotacaoView cotacaoCabecalho = cotacaoService.findCotacaoCabecalho(cotacao.getSequencialCotacaoProposta());
			if(cotacaoCabecalho.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO) {
				throw new AccessDeniedException("Cotação não calculada!");
			}
			List<ParcelamentoJanelado> parcelas = parcelamentoJaneladoService.listar(cotacao.getNumeroCotacaoProposta(),
					cotacao.getVersaoCotacaoProposta());
			if(parcelas.isEmpty()) {
				parcelas = parcelamentoJaneladoService.calcularSugestoes(cotacao);		
			}

			model.addAttribute("cabecalhoCotacao", cotacaoCabecalho);
			model.addAttribute("parcelamentos", parcelas);
			return "/cotacao/parcelamentoJanelado";
		} catch (Exception e) {
			logger.error("Erro ao exibir o parcelamento janelado " + id, e);
			return "/erro";
		}
	}

	@LogPerformance
	@PostMapping(value = "/{id}/janelado")
	public ResponseEntity<?> salvarParcelamentoJanelado(@PathVariable BigInteger id, @RequestBody List<ParcelamentoJanelado> parcelas) {
		try {
			Cotacao cotacao = cotacaoService.findById(id);
			OpcaoParcelamento opcaoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(id);
			for(ParcelamentoJanelado p: parcelas) {
				p.setIdEntrada(opcaoSelecionada.getIdEntrada());
			}
			
			for(ParcelamentoJanelado pj: parcelas) {
				pj.setOpcaoParcelamento(opcaoSelecionada);
				pj.setDataAtualizacao(new Date());
				pj.setDescricaoFormaParcelamento(opcaoSelecionada.getDescricaoFormaParcelamento());
				pj.setIdEntrada(opcaoSelecionada.getIdEntrada());

				pj.setNumeroParcela(pj.getNumeroParcela());
				pj.setQuantidadeParcelas(opcaoSelecionada.getQuantidadeParcelas());

				pj.setNumeroCotacaoProposta(opcaoSelecionada.getNumeroCotacaoProposta());
				pj.setVersaoCotacaoProposta(opcaoSelecionada.getVersaoCotacaoProposta());

				pj.setCodigoGrupo(SecurityUtils.getCurrentUser().getGrupoUsuario().getCdGrp());
				pj.setUsuarioAtualizacao(SecurityUtils.getCurrentUser().getCdUsuro().longValue());				
			}
			
			List<Validacao> validacoes = parcelamentoJaneladoService.validar(cotacao, parcelas);
			if(!validacoes.isEmpty()) {
				return ResponseEntity.badRequest().body(validacoes);
			}
			parcelamentoJaneladoService.salvar(id, parcelas);
			return ResponseEntity.ok("ok");
		} catch (Exception e) {
			logger.error("Erro ao exibir o parcelamento janelado " + id, e);
			return ResponseEntity.badRequest().build();
		}
	}
}