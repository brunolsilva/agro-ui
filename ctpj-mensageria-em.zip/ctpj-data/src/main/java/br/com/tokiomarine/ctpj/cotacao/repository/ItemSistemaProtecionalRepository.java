package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Collection;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;

@Repository
@Transactional
public class ItemSistemaProtecionalRepository extends BaseDAO {

	private static final String FIND_SIST_PROTECIONAIS_BY_ITEM_COTACAO_HQL = "select ip " + "from ItemCotacao ic " + "join ic.listItemSistemaProtecional ip " + "where ic.sequencialItemCotacao = :sequencialItemCotacao ";

	private static final String FIND_SIST_PROTECIONAIS_BY_COTACAO_HQL = "select ip " + "from ItemCotacao ic " + "join  ic.listItemSistemaProtecional ip " + "where ic.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta";

	private static final String FIND_SIST_PROTECIONAIS_BY_ITEM_COTACAO_AND_COD_SIST_PROTECIONAL_HQL = "select ip " + "from ItemSistemaProtecional ip " + "where ip.itemCotacao.sequencialItemCotacao = :seqItemCotacao and ip.codigoSistemaProtecional = :codSistProtecional";

	public ItemSistemaProtecional findById(BigInteger seqItemSistProtecional) {
		return getCurrentSession().get(ItemSistemaProtecional.class, seqItemSistProtecional);
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> findSistemasProtecionaisBySeqCotac(BigInteger sequencialCotacaoProposta) {
		StringBuilder sb = new StringBuilder();
		sb.append("select i.numeroItem, isp.codigoSistemaProtecional ");
		sb.append("from   ItemCotacao i ");
		sb.append("join   i.listItemSistemaProtecional isp ");
		sb.append("where  i.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		sb.append("order by i.numeroItem, isp.codigoSistemaProtecional");
		Query query = getCurrentSession().createQuery(sb.toString());
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		return (List<Object[]>) query.list();
	}

	public List<ItemSistemaProtecional> findSistemasProtecionaisByCotacao(Cotacao cotacao) {
		return findSistemasProtecionaisByCotacao(cotacao.getSequencialCotacaoProposta());
	}

	@SuppressWarnings("unchecked")
	public List<ItemSistemaProtecional> findSistemasProtecionaisByCotacao(BigInteger sequencialCotacaoProposta) {
		return getCurrentSession().createQuery(FIND_SIST_PROTECIONAIS_BY_COTACAO_HQL).setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta).list();
	}

	public List<ItemSistemaProtecional> findSistemasProtecionaisByItemCotacao(ItemCotacao ItemCotacao) {
		return findSistemasProtecionaisByItemCotacao(ItemCotacao.getSequencialItemCotacao());
	}

	@SuppressWarnings("unchecked")
	public List<ItemSistemaProtecional> findSistemasProtecionaisByItemCotacao(BigInteger sequencialItemCotacao) {
		return getCurrentSession().createQuery(FIND_SIST_PROTECIONAIS_BY_ITEM_COTACAO_HQL).setParameter("sequencialItemCotacao", sequencialItemCotacao).list();
	}

	@SuppressWarnings("unchecked") // <---
	public List<ItemSistemaProtecional> findByCotacaoAndCodSistProtecional(BigInteger seqCotacao, Long codSistProtecional) {
		String hql = new StringBuilder()
				.append("select ip ")
				.append("from ItemCotacao ic ")
				.append("join  ic.listItemSistemaProtecional ip ")
				.append("where ic.cotacao.sequencialCotacaoProposta = :seqCotacao and ip.codigoSistemaProtecional = :codSistProtecional ")
				.toString();

		return getCurrentSession().createQuery(hql).setParameter("seqCotacao", seqCotacao).setParameter("codSistProtecional", codSistProtecional).list();
	}

	@SuppressWarnings("unchecked")
	public List<ItemSistemaProtecional> findByItensCotacaoAndCodSistProtecional(Long codSistProtecional, Collection<BigInteger> itensCotacao) {
		String hql = new StringBuilder()
				.append("select ip ")
				.append("from ItemCotacao ic ")
				.append("join  ic.listItemSistemaProtecional ip ")
				.append("where ic.sequencialItemCotacao in (:itensCotacao) and ip.codigoSistemaProtecional = :codSistProtecional ")
				.toString();

		return getCurrentSession()
				.createQuery(hql)
				.setParameterList("itensCotacao", itensCotacao)
				.setParameter("codSistProtecional", codSistProtecional)
				.list();
	}

	@SuppressWarnings("unchecked")
	public ItemSistemaProtecional findByItemCotacaoAndCodSistProtecional(BigInteger seqItemCotacao, Long codSistProtecional) {
		List<ItemSistemaProtecional> list = getCurrentSession().createQuery(FIND_SIST_PROTECIONAIS_BY_ITEM_COTACAO_AND_COD_SIST_PROTECIONAL_HQL).setParameter("seqItemCotacao", seqItemCotacao).setParameter("codSistProtecional", codSistProtecional).list();

		if (list.isEmpty())
			return null;

		return list.get(0);
	}

}
