package br.com.tokiomarine.ctpj.cotacao.service;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.BaseOpcaoParcelamentoView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoPagamentoView;
import br.com.tokiomarine.ctpj.cotacao.dto.OpcaoParcelamentoView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.JurosParcelamentoCotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.OpcaoParcelamentoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilCalculoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.RecebimentoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.JurosParcelamentoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.FormaPagamento;
import br.com.tokiomarine.ctpj.infra.domain.FormaParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoJurosParcelamento;
import br.com.tokiomarine.ctpj.infra.domain.TaxaIOF;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaPagamentoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.FormaParcelamentoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.TaxaIOFRepository;
import br.com.tokiomarine.ctpj.mapper.OpcaoParcelamentoMapper;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class,Exception.class})
public class OpcaoParcelamentoService {

	private static Logger logger = LogManager.getLogger(OpcaoParcelamentoService.class);

	@Autowired
	private TaxaIOFRepository taxaIOFRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private OpcaoParcelamentoRepository opcaoPactoPagtoCotacaoRepository;

	@Autowired
	private JurosParcelamentoCotacaoRepository jurosParcelamentoCotacaoRepository;

	@Autowired
	private FormaPagamentoRepository formaPagamentoRepository;

	@Autowired
	private FormaParcelamentoRepository formaParcelamentoRepository;

	@Autowired
	private PerfilCalculoRepository perfilCalculoRepository;

	@Autowired
	private RecebimentoRepository recebimentoRepository;
	
	@Autowired
	private DevolucaoService devolucaoService;
	
	@LogPerformance
	public List<OpcaoParcelamento> listar(BigInteger sequencialCotacao, BigInteger numeroCotacao) throws ServiceException {
		try {
			Recebimento recebimento = recebimentoRepository.findRecebimentoByNumeroCotacaoProposta(numeroCotacao);
			List<OpcaoParcelamento> opcoes = opcaoPactoPagtoCotacaoRepository.list(sequencialCotacao);
			if (recebimento != null) {
				return opcoes.stream()
						.filter(opcao -> 
						(TipoCreditoEnum.BOLETO_GERADO == recebimento.getIdTipoCredito() && opcao.getCodigoFormaPagamento().equals(FormaPagamentoEnum.CARNE.getCodigo())) ||
						(TipoCreditoEnum.DEBITO_AGENDADO == recebimento.getIdTipoCredito() && opcao.getCodigoFormaPagamento().equals(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo())) ||
						(TipoCreditoEnum.CREDITO_VINCULADO == recebimento.getIdTipoCredito()) &&
						isParcelamentoComEntrada(opcao)	)
						.collect(Collectors.toList());
			}
			return opcoes;
		} catch (Exception e) {
			logger.error("Erro ao listar as Opções de Parcelamento ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public List<OpcaoParcelamento> gerarOpcaoParcelamento(BigInteger sequencialCotacaoPropota, User user) throws ServiceException {
		Cotacao cotacao = cotacaoRepository.findById(sequencialCotacaoPropota);
		return this.gerarOpcaoParcelamento(cotacao,user);
	}
	
	@LogPerformance
	public List<OpcaoParcelamento> gerarOpcaoParcelamento(Cotacao cotacao,User user) throws ServiceException {
		int sqParcelamentoPagamentoCotacao = 0;

		OpcaoParcelamento opcaoParcelamentoPagamentoCotacao;
		List<OpcaoParcelamento> listaOpcaoParcelamentoPagamentoCotacao = new ArrayList<>();

		try {

			Date dataCalculo = new Date();
			if (cotacao.getDataCalculo()!=null){
				dataCalculo = cotacao.getDataCalculo();
			}
			Date dataInicioVigenciaParcelamento = buscarDataInicioVigenciaParcelamento(cotacao);
			Date dataTerminoVigencia	= opcaoPactoPagtoCotacaoRepository.findMinDataTermino(cotacao.getSequencialCotacaoProposta());
			Date dataMinimoTerminoVigencia = DateUtils.addDays(dataTerminoVigencia,-30);

			BigDecimal valorPremioLiquidoTotal = buscarValorPremioLiquidoTotal(cotacao);

			BigDecimal percentualIOF = buscarPercentualIOF(cotacao,dataInicioVigenciaParcelamento);
			BigDecimal valorIOF = BigDecimalUtil.trunc(valorPremioLiquidoTotal.multiply(percentualIOF).divide(new BigDecimal(100),MathContext.DECIMAL128));

			List<JurosParcelamentoCotacao> listJurosParcelamentoCotacao = jurosParcelamentoCotacaoRepository.list(cotacao.getSequencialCotacaoProposta());
			if (listJurosParcelamentoCotacao == null || listJurosParcelamentoCotacao.isEmpty()) {
				listJurosParcelamentoCotacao = buscarJurosParcelamentoPerfilCalculo(cotacao,dataCalculo,dataMinimoTerminoVigencia,user);
			}else{
				List<JurosParcelamentoCotacao> listJurosParcelamentoCotacaoPerfil = buscarJurosParcelamentoPerfilCalculo(cotacao,dataCalculo,dataMinimoTerminoVigencia,user);
				for (JurosParcelamentoCotacao jurosParcelamentoCotacao : listJurosParcelamentoCotacao){

					Optional<JurosParcelamentoCotacao> optionalJurosParcelamentoCotacaoPerfil = listJurosParcelamentoCotacaoPerfil
							.stream()
							.filter(j->j.getCodigoFormaPagamento().equals(jurosParcelamentoCotacao.getCodigoFormaPagamento()) && j.getCodigoFormaParcelamento().equals(jurosParcelamentoCotacao.getCodigoFormaParcelamento()))
							.findFirst();
					
					JurosParcelamentoCotacao jpc; 

					if (optionalJurosParcelamentoCotacaoPerfil.isPresent()){
						jpc = optionalJurosParcelamentoCotacaoPerfil.get();
						jurosParcelamentoCotacao.setValorParcelaMinima(jpc.getValorParcelaMinima());
						jurosParcelamentoCotacao.setIdImprime(jpc.getIdImprime());
					}else{
						jpc = buscarJurosParcelamentoPerfilCalculo(cotacao,dataCalculo,dataMinimoTerminoVigencia,jurosParcelamentoCotacao.getCodigoFormaPagamento(), jurosParcelamentoCotacao.getCodigoFormaParcelamento(),user);
						if(jpc != null) {
							jurosParcelamentoCotacao.setValorParcelaMinima(jpc.getValorParcelaMinima());
							jurosParcelamentoCotacao.setIdImprime(jpc.getIdImprime());
						}
					}
				}
			}

			if (listJurosParcelamentoCotacao.stream().filter(it -> it.getCodigoFormaPagamento() == 8).count() == 0) {
				listJurosParcelamentoCotacao.addAll(buscarJurosParcelamentoCartao(cotacao, dataCalculo, dataMinimoTerminoVigencia, user));
			}

			jurosParcelamentoCotacaoRepository.saveList(listJurosParcelamentoCotacao);

			long maiorQue500 = cotacao.getListItem().stream()
					.filter(it -> it.getValorRiscoBemCalculado().compareTo(new BigDecimal("500000")) > 0).count();
			List<BigInteger> ids = new ArrayList<>();
			if(maiorQue500 > 0) {
//			if(maiorQue500 > 0 || cotacao.getIdTipoOrigem() == TipoOrigemEnum.WS) {
				ids = listJurosParcelamentoCotacao.stream().filter(it -> it.getCodigoFormaPagamento() == 8)
						.map(JurosParcelamentoCotacao::getSequencialJurosParcelamentoCotacao)
						.collect(Collectors.toList());
				listJurosParcelamentoCotacao = listJurosParcelamentoCotacao.stream().filter(it -> it.getCodigoFormaPagamento() != 8)
						.collect(Collectors.toList());
			}
			
			jurosParcelamentoCotacaoRepository.delete(ids);

			Map<Integer,FormaParcelamento> formasParcelamento = formaParcelamentoRepository.findFormaParcelamentoByJuros(listJurosParcelamentoCotacao);
			Map<Integer,FormaPagamento> formasPagamento = formaPagamentoRepository.findFormaPagamentoByJuros(listJurosParcelamentoCotacao);

			for (JurosParcelamentoCotacao jurosParcelamentoCotacao : listJurosParcelamentoCotacao) {
				Integer qtdeParcelasLimite = 0;
				Date dataUltimaVencimento;

				FormaParcelamento formaParcelamento = formasParcelamento.get(jurosParcelamentoCotacao.getCodigoFormaParcelamento());
				FormaPagamento formaPagamento = formasPagamento.get(jurosParcelamentoCotacao.getCodigoFormaPagamento());

				if (formaParcelamento.getEntrada() == SimNaoEnum.SIM) {
					qtdeParcelasLimite = formaParcelamento.getQuantidadeParcelas() - 1;
					if (cotacao.getDataVencimentoProgramada() != null){
						qtdeParcelasLimite = qtdeParcelasLimite - 1;
					}
				} else {
					qtdeParcelasLimite = formaParcelamento.getQuantidadeParcelas();
					if (cotacao.getDataVencimentoProgramada() != null){
						qtdeParcelasLimite = qtdeParcelasLimite - 1;
					}
				}
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				dataUltimaVencimento = sdf.parse(sdf.format(new Date())); 
				if (cotacao.getDataVencimentoProgramada() != null) {
					dataUltimaVencimento = cotacao.getDataVencimentoProgramada();
				}

				if (	jurosParcelamentoCotacao.getCodigoFormaParcelamento() ==  1 ||
						DateUtils.addDays(dataUltimaVencimento,qtdeParcelasLimite*30).before(dataTerminoVigencia) || 
						DateUtils.addDays(dataUltimaVencimento,qtdeParcelasLimite*30).equals(dataTerminoVigencia) ){

					sqParcelamentoPagamentoCotacao++;
					BigDecimal valorJuros = BigDecimalUtil.trunc(BigDecimalUtil.trunc(valorPremioLiquidoTotal.multiply(jurosParcelamentoCotacao.getPercentualJuros(),MathContext.DECIMAL128)).divide(new BigDecimal(100),MathContext.DECIMAL128));
					BigDecimal valorIOFJuros = BigDecimalUtil.trunc(BigDecimalUtil.trunc(valorJuros.multiply(percentualIOF,MathContext.DECIMAL128)).divide(new BigDecimal(100),MathContext.DECIMAL128));
					BigDecimal valorPremioTotal = valorPremioLiquidoTotal.add(valorJuros).add(valorIOF).add(valorIOFJuros);
	
	
					BigDecimal valorDemaisParcela = BigDecimal.ZERO;
					if (!formaParcelamento.getQuantidadeParcelas().equals(1)) {
						valorDemaisParcela = BigDecimalUtil.trunc(valorPremioTotal.divide(new BigDecimal(formaParcelamento.getQuantidadeParcelas()),MathContext.DECIMAL128));
					}
					
					BigDecimal valorPrimeiraParcela = valorPremioTotal.subtract(new BigDecimal(formaParcelamento.getQuantidadeParcelas() - 1).multiply(valorDemaisParcela,MathContext.DECIMAL128));
					//se a quantidade de parcelas for igual 1 e o valor da primeira parcela for maior que o mínimo OU se o valor das demais for maior que o mínimo
					if ( (formaParcelamento.getQuantidadeParcelas().equals(1) && valorPrimeiraParcela.compareTo(BigDecimal.ZERO) > 0 && valorDemaisParcela.compareTo(BigDecimal.ZERO) == 0 ) ||
						 (valorDemaisParcela.compareTo(jurosParcelamentoCotacao.getValorParcelaMinima()) >= 0)){
						opcaoParcelamentoPagamentoCotacao = new OpcaoParcelamento();
						opcaoParcelamentoPagamentoCotacao.setCotacao(cotacao);
						opcaoParcelamentoPagamentoCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
						opcaoParcelamentoPagamentoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
						opcaoParcelamentoPagamentoCotacao.setCodigoProduto(cotacao.getCodigoProduto());
						opcaoParcelamentoPagamentoCotacao.setCodigoFormaPagamento(jurosParcelamentoCotacao.getCodigoFormaPagamento());
						opcaoParcelamentoPagamentoCotacao.setDescricaoFormaPagamento(formaPagamento.getDescricao());
						opcaoParcelamentoPagamentoCotacao.setCodigoFormaParcelamento(jurosParcelamentoCotacao.getCodigoFormaParcelamento());
						opcaoParcelamentoPagamentoCotacao.setDescricaoFormaParcelamento(formaParcelamento.getDescricao());
						opcaoParcelamentoPagamentoCotacao.setSequencialParcelamento(sqParcelamentoPagamentoCotacao);
						opcaoParcelamentoPagamentoCotacao.setValorIOFPremio(valorIOF);
						opcaoParcelamentoPagamentoCotacao.setValorJuros(valorJuros);
						opcaoParcelamentoPagamentoCotacao.setValorIOFJuros(valorIOFJuros);
						opcaoParcelamentoPagamentoCotacao.setPercentualIOFAplicado(percentualIOF);
						opcaoParcelamentoPagamentoCotacao.setPercentualJurosAplicado(jurosParcelamentoCotacao.getPercentualJuros());
						opcaoParcelamentoPagamentoCotacao.setValorPrimeiraParcela(valorPrimeiraParcela);
						opcaoParcelamentoPagamentoCotacao.setValorDemaisParcela(valorDemaisParcela);
						opcaoParcelamentoPagamentoCotacao.setValorPremioLiquido(valorPremioLiquidoTotal);
						opcaoParcelamentoPagamentoCotacao.setValorPremioTotal(valorPremioTotal);
						opcaoParcelamentoPagamentoCotacao.setQuantidadeParcelas(formaParcelamento.getQuantidadeParcelas());
						opcaoParcelamentoPagamentoCotacao.setDataAtualizacao(new Date());
						opcaoParcelamentoPagamentoCotacao.setIdEntrada(formaParcelamento.getEntrada());
						opcaoParcelamentoPagamentoCotacao.setIdImpressao(jurosParcelamentoCotacao.getIdImprime());
						opcaoParcelamentoPagamentoCotacao.setValorParcelaMinima(jurosParcelamentoCotacao.getValorParcelaMinima());
						opcaoParcelamentoPagamentoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
						opcaoParcelamentoPagamentoCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
						listaOpcaoParcelamentoPagamentoCotacao.add(opcaoParcelamentoPagamentoCotacao);
					}
				}
			}
			
			//guarda o parcelamento selecionado
			OpcaoParcelamento opcaoParcelamentoSelecionado = this.findOpcaoParcelamentoSelecionada(cotacao.getSequencialCotacaoProposta());
			
			opcaoPactoPagtoCotacaoRepository.delete(cotacao.getSequencialCotacaoProposta());
			opcaoPactoPagtoCotacaoRepository.saveList(listaOpcaoParcelamentoPagamentoCotacao);		
			
			//caso o usuario tenha selecionado alguma opção de parcelamento anteriormente, seleciona a mesma opção novamente
			if(opcaoParcelamentoSelecionado != null){
				this.salvar(cotacao.getSequencialCotacaoProposta(), opcaoParcelamentoSelecionado.getCodigoFormaPagamento(), opcaoParcelamentoSelecionado.getCodigoFormaParcelamento());
			}
			
			//verifica se será necessário calcular o parcelamento efetivo
			Recebimento recebimento = recebimentoRepository.findRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			if(cotacao.getValorPremioLiquido().compareTo(BigDecimal.ZERO) > 0 && recebimento != null && recebimento.getValorRecebimento().compareTo(BigDecimal.ZERO) > 0){
				this.calcularOpcaoParcelamentoEfetivado(cotacaoRepository.findCotacaoParcelamentoRecebimento(cotacao.getSequencialCotacaoProposta()));
				return cotacao.getListOpcaoParcelamento();
			}

		} catch (Exception e) {
			logger.error(String.format("Falha ao gerar as opçoes de parcelamento da cotacao %s",cotacao.getSequencialCotacaoProposta()),e);
			throw new ServiceException(e.getMessage(),e);
		}

		return listaOpcaoParcelamentoPagamentoCotacao;
	}
	
	private List<JurosParcelamentoCotacao> buscarJurosParcelamentoCartao(Cotacao cotacao,Date dtInicioVigenciaParcelamento,Date dtMaxTerminoVigencia,User user) {
		List<JurosParcelamentoCotacao> listJurosParcelamentoCotacaoPerfil = new ArrayList<>();
		List<PerfilCalculoJurosParcelamento> listPerfilCalculoJurosParcelamento = perfilCalculoRepository.findPerfilCalculoJurosParcelamento(user.getCdUsuro().longValue(),cotacao.getCodigoProduto(),dtInicioVigenciaParcelamento);
		long maiorQue500 = cotacao.getListItem().stream()
				.filter(it -> it.getValorRiscoBemCalculado().compareTo(new BigDecimal("500000")) > 0).count();
		if(maiorQue500 > 0) {
			listPerfilCalculoJurosParcelamento = listPerfilCalculoJurosParcelamento.stream()
					.filter(it -> it.getFormaPagamento() != 8).collect(Collectors.toList());
		}
		for (PerfilCalculoJurosParcelamento perfilCalculoJurosParcelamento : listPerfilCalculoJurosParcelamento) {
			if(perfilCalculoJurosParcelamento.getFormaPagamento() == 8) {
				JurosParcelamentoCotacao jurosParcelamentoCotacao = new JurosParcelamentoCotacao();
				jurosParcelamentoCotacao.setCotacao(cotacao);
				jurosParcelamentoCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
				jurosParcelamentoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
				jurosParcelamentoCotacao.setCodigoFormaPagamento(perfilCalculoJurosParcelamento.getFormaPagamento());
				jurosParcelamentoCotacao.setCodigoFormaParcelamento(perfilCalculoJurosParcelamento.getFormaParcelamento());
				jurosParcelamentoCotacao.setPercentualJuros(perfilCalculoJurosParcelamento.getPercentualJuros());
				jurosParcelamentoCotacao.setDataAtualizacao(new Date());
				jurosParcelamentoCotacao.setUsuarioAtualizacao(cotacao.getUsuarioAtualizacao());
				jurosParcelamentoCotacao.setCodigoGrupo(cotacao.getCodigoGrupo());
				if (perfilCalculoJurosParcelamento.getIdImpressao() == null){
					jurosParcelamentoCotacao.setIdImprime(SimNaoEnum.NAO);
				}else{
					jurosParcelamentoCotacao.setIdImprime(perfilCalculoJurosParcelamento.getIdImpressao());
				}
				jurosParcelamentoCotacao.setValorParcelaMinima(perfilCalculoJurosParcelamento.getValorParcelaMinima());
				listJurosParcelamentoCotacaoPerfil.add(jurosParcelamentoCotacao);
			}
		}
		return listJurosParcelamentoCotacaoPerfil;
	}

	private List<JurosParcelamentoCotacao> buscarJurosParcelamentoPerfilCalculo(Cotacao cotacao,Date dtInicioVigenciaParcelamento,Date dtMaxTerminoVigencia,User user) {
		List<JurosParcelamentoCotacao> listJurosParcelamentoCotacaoPerfil = new ArrayList<>();
		List<PerfilCalculoJurosParcelamento> listPerfilCalculoJurosParcelamento = perfilCalculoRepository.findPerfilCalculoJurosParcelamento(user.getCdUsuro().longValue(),cotacao.getCodigoProduto(),dtInicioVigenciaParcelamento);
		long maiorQue500 = cotacao.getListItem().stream()
				.filter(it -> it.getValorRiscoBemCalculado().compareTo(new BigDecimal("500000")) > 0).count();
		if(maiorQue500 > 0) {
			listPerfilCalculoJurosParcelamento = listPerfilCalculoJurosParcelamento.stream()
					.filter(it -> it.getFormaPagamento() != 8).collect(Collectors.toList());
		}
		for (PerfilCalculoJurosParcelamento perfilCalculoJurosParcelamento : listPerfilCalculoJurosParcelamento) {
			JurosParcelamentoCotacao jurosParcelamentoCotacao = new JurosParcelamentoCotacao();
			jurosParcelamentoCotacao.setCotacao(cotacao);
			jurosParcelamentoCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			jurosParcelamentoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			jurosParcelamentoCotacao.setCodigoFormaPagamento(perfilCalculoJurosParcelamento.getFormaPagamento());
			jurosParcelamentoCotacao.setCodigoFormaParcelamento(perfilCalculoJurosParcelamento.getFormaParcelamento());
			jurosParcelamentoCotacao.setPercentualJuros(perfilCalculoJurosParcelamento.getPercentualJuros());
			jurosParcelamentoCotacao.setDataAtualizacao(new Date());
			jurosParcelamentoCotacao.setUsuarioAtualizacao(cotacao.getUsuarioAtualizacao());
			jurosParcelamentoCotacao.setCodigoGrupo(cotacao.getCodigoGrupo());
			if (perfilCalculoJurosParcelamento.getIdImpressao() == null){
				jurosParcelamentoCotacao.setIdImprime(SimNaoEnum.NAO);
			}else{
				jurosParcelamentoCotacao.setIdImprime(perfilCalculoJurosParcelamento.getIdImpressao());
			}
			jurosParcelamentoCotacao.setValorParcelaMinima(perfilCalculoJurosParcelamento.getValorParcelaMinima());
			listJurosParcelamentoCotacaoPerfil.add(jurosParcelamentoCotacao);
		}
		return listJurosParcelamentoCotacaoPerfil;
	}
	
	private JurosParcelamentoCotacao buscarJurosParcelamentoPerfilCalculo(Cotacao cotacao,Date dtInicioVigenciaParcelamento,Date dtMaxTerminoVigencia,Integer codigoFormaPagamento, Integer codigoFormaParcelamento,User user) {
		PerfilCalculoJurosParcelamento perfilCalculoJurosParcelamento = 
				perfilCalculoRepository.findPerfilCalculoJurosParcelamento(
				user.getCdUsuro().longValue(),
				cotacao.getCodigoProduto(),
				codigoFormaPagamento,
				codigoFormaParcelamento,
				dtInicioVigenciaParcelamento);
		
		long maiorQue500 = cotacao.getListItem().stream()
				.filter(it -> it.getValorRiscoBemCalculado().compareTo(new BigDecimal("500000")) > 0).count();
		if(maiorQue500 > 0) {
			perfilCalculoJurosParcelamento = null;
		}

		JurosParcelamentoCotacao jurosParcelamentoCotacao = null;
		if (perfilCalculoJurosParcelamento != null){
			jurosParcelamentoCotacao = new JurosParcelamentoCotacao();
			jurosParcelamentoCotacao.setCotacao(cotacao);
			jurosParcelamentoCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			jurosParcelamentoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			jurosParcelamentoCotacao.setCodigoFormaPagamento(perfilCalculoJurosParcelamento.getFormaPagamento());
			jurosParcelamentoCotacao.setCodigoFormaParcelamento(perfilCalculoJurosParcelamento.getFormaParcelamento());
			jurosParcelamentoCotacao.setPercentualJuros(perfilCalculoJurosParcelamento.getPercentualJuros());
			jurosParcelamentoCotacao.setDataAtualizacao(new Date());
			jurosParcelamentoCotacao.setUsuarioAtualizacao(cotacao.getUsuarioAtualizacao());
			jurosParcelamentoCotacao.setCodigoGrupo(cotacao.getCodigoGrupo());
			if (perfilCalculoJurosParcelamento.getIdImpressao() == null){
				jurosParcelamentoCotacao.setIdImprime(SimNaoEnum.NAO);
			}else{
				jurosParcelamentoCotacao.setIdImprime(perfilCalculoJurosParcelamento.getIdImpressao());
			}
			jurosParcelamentoCotacao.setValorParcelaMinima(perfilCalculoJurosParcelamento.getValorParcelaMinima());
		}
		return jurosParcelamentoCotacao;
	}	

	private BigDecimal buscarValorPremioLiquidoTotal(Cotacao cotacao) {
		BigDecimal valorPremioLiquidoTotal = BigDecimal.ZERO;
		for (ItemCotacao itemCotacao : cotacao.getListItem()) {
			if(itemCotacao.getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
				for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
					valorPremioLiquidoTotal = valorPremioLiquidoTotal.add(itemCobertura.getValorPremio() == null ? BigDecimal.ZERO : itemCobertura.getValorPremio());
				}
			} else {
				if(itemCotacao.getCotacao().getCodigoTipoEndossoSCT() ==  TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO || itemCotacao.getCotacao().getCodigoTipoEndossoSCT() ==  TipoEndossoSctEnum.REINTEGRACAO_IS) {
					if(itemCotacao.getIdTipoEndosso() != null) {
						for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
							valorPremioLiquidoTotal = valorPremioLiquidoTotal.add(itemCobertura.getValorPremio() == null ? BigDecimal.ZERO : itemCobertura.getValorPremio());
						}
					}
				} else {
					for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
						valorPremioLiquidoTotal = valorPremioLiquidoTotal.add(itemCobertura.getValorPremio() == null ? BigDecimal.ZERO : itemCobertura.getValorPremio());
					}
				}
			}
		}
		return valorPremioLiquidoTotal;
	}

	private BigDecimal buscarPercentualIOF(Cotacao cotacao,Date dtInicioVigenciaParcelamento) throws ServiceException {
		BigDecimal percentualIOF;
		if (cotacao.getIdIsencaoImposto() != null && cotacao.getIdIsencaoImposto().equals(SimNaoEnum.SIM)) {
			percentualIOF = BigDecimal.ZERO;
		} else {
			List<Object[]> grupoRamoRamo = opcaoPactoPagtoCotacaoRepository.findGrupoRamoRamo(cotacao.getSequencialCotacaoProposta());
			TaxaIOF taxa = recuperaMaiorTaxa(grupoRamoRamo,dtInicioVigenciaParcelamento);
			if(taxa != null) {
				percentualIOF = taxa.getPercentualIOF();
			} else {
				throw new RuntimeException("IOF não encontrado");
			}
		}
		return percentualIOF;
	}

	private Date buscarDataInicioVigenciaParcelamento(Cotacao cotacao) {
		Date dtInicioVigenciaParcelamento = opcaoPactoPagtoCotacaoRepository.findDtMaxAlteracaoItem(cotacao.getSequencialCotacaoProposta());
		if (dtInicioVigenciaParcelamento == null) {
			dtInicioVigenciaParcelamento = opcaoPactoPagtoCotacaoRepository.findDtAlteracaoInicioVigenciaPedido(cotacao.getSequencialCotacaoProposta());
		}
		return dtInicioVigenciaParcelamento;
	}

	private TaxaIOF recuperaMaiorTaxa(List<Object[]> grupoRamoRamo,Date dataInicioVigencia) throws ServiceException {
		try {
			List<TaxaIOF> taxas = new ArrayList<>();
			for (Object[] grr : grupoRamoRamo) {
				Integer codigoGrupoRamo = (Integer) grr[0];
				Integer codigoRamo = (Integer) grr[1];
				TaxaIOF taxa = taxaIOFRepository.findTaxaIOF(codigoGrupoRamo,codigoRamo,dataInicioVigencia);
				if (taxa != null) {
					taxas.add(taxa);
				}
			}
			if (!taxas.isEmpty()) {
				Optional<TaxaIOF> taxaIOF = taxas.stream().max(Comparator.comparing(TaxaIOF::getPercentualIOF));
				return taxaIOF.isPresent() ? taxaIOF.get() : null;
			}
		} catch (Exception e) {
			logger.error("Erro ao recuperar a maior taxa: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return null;
	}

	public List<BaseOpcaoParcelamentoView> consultarOpcaoParcelamento(Cotacao cotacao) throws ServiceException {
		List<BaseOpcaoParcelamentoView> listaOpcaoParcelamentoView = new ArrayList<>();
		List<Object[]> listaFormasPagamento = opcaoPactoPagtoCotacaoRepository.findFormasPagamento(cotacao.getSequencialCotacaoProposta());
		try {
			for (Object[] formaPagamento : listaFormasPagamento) {
				BaseOpcaoParcelamentoView baseOpcaoParcelamentoView = new BaseOpcaoParcelamentoView();
				baseOpcaoParcelamentoView.setCodigoFormaPagamento((Integer) formaPagamento[0]);
				baseOpcaoParcelamentoView.setDescricaoFormaPagamento((String) formaPagamento[1]);
				List<OpcaoParcelamentoView> opcoesParcelamentoView = OpcaoParcelamentoMapper.INSTANCE.toView(opcaoPactoPagtoCotacaoRepository.findFormasParcelamento(cotacao.getSequencialCotacaoProposta(),baseOpcaoParcelamentoView.getCodigoFormaPagamento()));
				baseOpcaoParcelamentoView.setOpcoesParcelamento(opcoesParcelamentoView);
				listaOpcaoParcelamentoView.add(baseOpcaoParcelamentoView);
			}
		} catch (HibernateException re) {
			logger.error("Erro ao consultar opção parcelamento: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro geral ao consultar opção parcelamento: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return listaOpcaoParcelamentoView;
	}
	
	public void desmarcarOpcaoParcelamentoSelecionada(OpcaoParcelamento opcaoParcelamentoSelecionada){
		if(opcaoParcelamentoSelecionada != null && opcaoParcelamentoSelecionada.getIdEntrada().equals(SimNaoEnum.NAO) && opcaoParcelamentoSelecionada.getCodigoFormaParcelamento() == 1){
			Cotacao cotacao = cotacaoRepository.findCotacaoParcelamentoRecebimento(opcaoParcelamentoSelecionada.getCotacao().getSequencialCotacaoProposta());
			for(OpcaoParcelamento op : cotacao.getListOpcaoParcelamento()){
				if(op.getIdParcelamentoEscolhido() != null && op.getIdParcelamentoEscolhido().equals(SimNaoEnum.SIM)){
					op.setIdParcelamentoEscolhido(SimNaoEnum.NAO);
					opcaoPactoPagtoCotacaoRepository.update(op);
					break;
				}
			}			
		}
	}
	
	public List<Validacao> calcularOpcaoParcelamentoEfetivado(BigInteger sequencialCotacaoPropota) throws ServiceException {
		Cotacao cotacao = cotacaoRepository.findCotacaoParcelamentoRecebimento(sequencialCotacaoPropota);
		return this.calcularOpcaoParcelamentoEfetivado(cotacao);
	}

	public List<Validacao> calcularOpcaoParcelamentoEfetivado(Cotacao cotacao) throws ServiceException {
		List<Validacao> listaValidacao = new ArrayList<>();

		FormaPagamento formaPagamento = new FormaPagamento();
		FormaParcelamento formaParcelamento = new FormaParcelamento();
		Recebimento recebimento = recebimentoRepository.findRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		
		String mensagemErro = "";
		try {
			
			int qtdOpcoesParcelamento = cotacao.getListOpcaoParcelamento().size() - 1;

			while	(qtdOpcoesParcelamento >= 0){
				OpcaoParcelamento opcaoParcelamento = cotacao.getListOpcaoParcelamento().get(qtdOpcoesParcelamento);
				opcaoParcelamento.setCotacao(cotacao);
				formaParcelamento = formaParcelamentoRepository.findFormaParcelamentoByCodigo(opcaoParcelamento.getCodigoFormaParcelamento());
				formaPagamento = formaPagamentoRepository.findFormaPagamentoByCodigo(opcaoParcelamento.getCodigoFormaPagamento());
				atualizaParcelasEfetivamente(formaPagamento,formaParcelamento,recebimento,opcaoParcelamento);
				atualizaIOFEfetivamente(formaParcelamento,opcaoParcelamento);
				atualizaJurosEfetivamente(formaParcelamento,opcaoParcelamento);
				//valida se é uma opção de parcelamento para exclusao
				if(isOpcaoParcelamentoParaExclusao(recebimento, opcaoParcelamento)){
					opcaoPactoPagtoCotacaoRepository.delete(opcaoParcelamento);			
				}
				else {
					mensagemErro = validaEntradaMaiorSegundaDemaisParcelas(opcaoParcelamento);
					opcaoPactoPagtoCotacaoRepository.update(opcaoParcelamento);
				}
				qtdOpcoesParcelamento--;
			}
			
			if (mensagemErro != null && !mensagemErro.isEmpty()) {
				listaValidacao.add(new Validacao(mensagemErro));
			} else {
				cotacaoRepository.update(cotacao);
			}
			
		} catch (Exception e) {
			logger.error("Erro ao calcular opção parcelamento efetivado ",e);
			throw new ServiceException("Erro ao calcular opção parcelamento efetivado ",e);
		}
		return listaValidacao;
	}

	protected boolean isOpcaoParcelamentoParaExclusao(Recebimento recebimento, OpcaoParcelamento opcaoParcelamento) {
		
		if(recebimento != null && isParcelamentoSemEntrada(opcaoParcelamento)) {
			return true;
		}
		
		return 	isParcelamentoComEntrada(opcaoParcelamento) &&
				(isSegundaParcelaEfetivamenteMenorParcelaMinima(opcaoParcelamento) ||
				isDemaisParcelasEfetivamenteMenorParcelaMinima(opcaoParcelamento) ||
				getTotalParcelasEfetivamente(opcaoParcelamento).compareTo(opcaoParcelamento.getValorPremioTotal()) < 0 || 
				isPremioLiquidoParcelamentoMenorQuePremioLiquidoEfetiva(opcaoParcelamento)	||
				isPremioTotalPrimeiraParcelaDiferentePremioTotalRecebimento(recebimento, opcaoParcelamento));
	}

	protected boolean isPremioTotalPrimeiraParcelaDiferentePremioTotalRecebimento(Recebimento recebimento,
			OpcaoParcelamento opcaoParcelamento) {
		return opcaoParcelamento.getQuantidadeParcelas() == 1 &&
		recebimento != null &&
		opcaoParcelamento.getValorPremioTotal().compareTo(recebimento.getValorRecebimento()) != 0;
	}

	protected boolean isParcelamentoSemEntrada(OpcaoParcelamento opcaoParcelamento) {
		return opcaoParcelamento.getIdEntrada() == SimNaoEnum.NAO;
	}

	protected boolean isParcelamentoComEntrada(OpcaoParcelamento opcaoParcelamento) {
		return opcaoParcelamento.getIdEntrada() == SimNaoEnum.SIM;
	}
	
	protected Boolean isSegundaParcelaEfetivamenteMenorParcelaMinima(OpcaoParcelamento opcaoParcelamento){
		return opcaoParcelamento.getQuantidadeParcelas() == 2 && opcaoParcelamento.getValorSegundaParcelaEfetivamente().compareTo(opcaoParcelamento.getValorParcelaMinima()) < 0;
	}
	
	protected Boolean isDemaisParcelasEfetivamenteMenorParcelaMinima(OpcaoParcelamento opcaoParcelamento){
		return opcaoParcelamento.getQuantidadeParcelas() > 2 && (opcaoParcelamento.getValorSegundaParcelaEfetivamente().compareTo(opcaoParcelamento.getValorParcelaMinima()) < 0 || opcaoParcelamento.getValorDemaisParcelasEfetivamente().compareTo(opcaoParcelamento.getValorParcelaMinima()) < 0);
	}
	
	/**
	 * valida se o prêmio liquido da parcela está menor que o premio liquido da primeira efetiva
	 * @param opcaoParcelamento
	 * @return
	 */
	protected Boolean isPremioLiquidoParcelamentoMenorQuePremioLiquidoEfetiva(OpcaoParcelamento opcaoParcelamento){
		
		BigDecimal resultado = opcaoParcelamento.getValorPrimeiraEfetivamente();
		
		//subtrai o iof efetivamente
		if(opcaoParcelamento.getValorIOFPrimeiraEfetivamente() != null) {
			resultado = resultado.subtract(opcaoParcelamento.getValorIOFPrimeiraEfetivamente());
		}
		
		//subtrai o juros efetivamente
		if(opcaoParcelamento.getValorJurosPrimeiraEfetivamente() != null) {
			resultado = resultado.subtract(opcaoParcelamento.getValorJurosPrimeiraEfetivamente());
		}
		
		return opcaoParcelamento.getValorPremioLiquido().compareTo(resultado) < 0;
	}
	
	protected BigDecimal getTotalParcelasEfetivamente(OpcaoParcelamento opcaoParcelamento){
		
		BigDecimal soma = new BigDecimal(0);
		soma = soma.add(opcaoParcelamento.getValorPrimeiraEfetivamente());
		if(opcaoParcelamento.getValorSegundaParcelaEfetivamente() != null && opcaoParcelamento.getValorSegundaParcelaEfetivamente().compareTo(BigDecimal.ZERO) > 0){
			soma = soma.add(opcaoParcelamento.getValorSegundaParcelaEfetivamente());
		}
		
		if(opcaoParcelamento.getValorDemaisParcelasEfetivamente() != null && opcaoParcelamento.getValorDemaisParcelasEfetivamente().compareTo(BigDecimal.ZERO) > 0){
			soma = soma.add(opcaoParcelamento.getValorDemaisParcelasEfetivamente().multiply(new BigDecimal(opcaoParcelamento.getQuantidadeParcelas() - 2)));
		}
		
		return soma;
	}

	public OpcaoParcelamento findOpcaoParcelamentoPagamentoEscolhida(Cotacao cotacao) {
		Optional<OpcaoParcelamento> opcaoParcelamento = cotacao.getListOpcaoParcelamento().stream().filter(op -> op.getIdParcelamentoEscolhido() == SimNaoEnum.SIM).findFirst();
		if (opcaoParcelamento.isPresent()) {
			return opcaoParcelamento.get();
		}
		return null;
	}

	public Recebimento findRecebimento(Cotacao cotacao) {
		Optional<Recebimento> recebimento = cotacao.getListRecebimento().stream().findFirst();
		if (recebimento.isPresent()) {
			return recebimento.get();
		}
		return null;
	}

	protected void atualizaJurosEfetivamente(FormaParcelamento formaParcelamento,OpcaoParcelamento opcaoPagtoParcelEscolhido) {

		BigDecimal valorJurosPrimeiraParcelaEfetivamente = null;
		BigDecimal valorJurosSegundaParcelaEfetivamente;
		BigDecimal valorJurosDemaisParcelasEfetivamente;

		BigDecimal valorJurosTotal = opcaoPagtoParcelEscolhido.getValorJuros();

		if (formaParcelamento.getQuantidadeParcelas() > 2) {
//			valorJurosDemaisParcelasEfetivamente = BigDecimalUtil.trunc(opcaoPagtoParcelEscolhido.getValorDemaisParcelasEfetivamente()
//					.subtract(opcaoPagtoParcelEscolhido.getValorDemaisParcelasEfetivamente()
//							.divide(calculaPercentualFormaDecimal(opcaoPagtoParcelEscolhido.getPercentualJurosAplicado()),MathContext.DECIMAL128)));
//			valorJurosSegundaParcelaEfetivamente = BigDecimalUtil.trunc(opcaoPagtoParcelEscolhido.getValorSegundaParcelaEfetivamente()
//					.subtract(opcaoPagtoParcelEscolhido.getValorSegundaParcelaEfetivamente()
//							.divide(calculaPercentualFormaDecimal(opcaoPagtoParcelEscolhido.getPercentualJurosAplicado()),MathContext.DECIMAL128)));
//			valorJurosPrimeiraParcelaEfetivamente = BigDecimalUtil.trunc(valorJurosTotal
//					.subtract(valorJurosSegundaParcelaEfetivamente)
//					.subtract(valorJurosDemaisParcelasEfetivamente.multiply(new BigDecimal(formaParcelamento.getQuantidadeParcelas()-2))));
			valorJurosDemaisParcelasEfetivamente = BigDecimalUtil.trunc(valorJurosTotal.divide(new BigDecimal(formaParcelamento.getQuantidadeParcelas()),MathContext.DECIMAL128));
			valorJurosSegundaParcelaEfetivamente = BigDecimalUtil.trunc(valorJurosTotal.divide(new BigDecimal(formaParcelamento.getQuantidadeParcelas()),MathContext.DECIMAL128));
			valorJurosPrimeiraParcelaEfetivamente = BigDecimalUtil.trunc(valorJurosTotal
					.subtract(valorJurosSegundaParcelaEfetivamente)
					.subtract(valorJurosDemaisParcelasEfetivamente.multiply(new BigDecimal(formaParcelamento.getQuantidadeParcelas()-2))));
		} else {
			if (formaParcelamento.getQuantidadeParcelas() > 1) {
				valorJurosSegundaParcelaEfetivamente = BigDecimalUtil.trunc(valorJurosTotal.divide(new BigDecimal(2),MathContext.DECIMAL128));
				valorJurosPrimeiraParcelaEfetivamente = BigDecimalUtil.trunc(valorJurosTotal.subtract(valorJurosSegundaParcelaEfetivamente));
				valorJurosDemaisParcelasEfetivamente = new BigDecimal(0);
			} else {
				valorJurosPrimeiraParcelaEfetivamente = BigDecimalUtil.trunc(valorJurosTotal);
				valorJurosSegundaParcelaEfetivamente = new BigDecimal(0);
				valorJurosDemaisParcelasEfetivamente = new BigDecimal(0);
			}
		}

		opcaoPagtoParcelEscolhido.setValorJurosPrimeiraEfetivamente(valorJurosPrimeiraParcelaEfetivamente);
		opcaoPagtoParcelEscolhido.setValorJurosSegundaEfetivamente(valorJurosSegundaParcelaEfetivamente);
		opcaoPagtoParcelEscolhido.setValorJurosDemaisEfetivamente(valorJurosDemaisParcelasEfetivamente);
	}

	/**
	 * Calcula percentual em forma decimal exemplo
	 * (1 + (percentual / 100))
	 * 
	 * @param percentual
	 * @return
	 */
	public BigDecimal calculaPercentualFormaDecimal(BigDecimal percentual) {
		return new BigDecimal(1).add(percentual.divide(new BigDecimal(100),MathContext.DECIMAL128));
	}

	private void atualizaIOFEfetivamente(FormaParcelamento formaParcelamento,OpcaoParcelamento opcaoPagamentoParcelamento) {
		BigDecimal valorIOFPrimeiraParcelaEfetivamente;
		BigDecimal valorIOFSegundaParcelaEfetivamente;
		BigDecimal valorIOFDemaisParcelasEfetivamente;

		BigDecimal valorIofTotal = BigDecimalUtil.trunc(opcaoPagamentoParcelamento.getValorPremioLiquido().multiply(opcaoPagamentoParcelamento.getPercentualIOFAplicado().divide(new BigDecimal(100),MathContext.DECIMAL128)))
				.add(BigDecimalUtil.trunc(opcaoPagamentoParcelamento.getValorJuros().multiply(opcaoPagamentoParcelamento.getPercentualIOFAplicado().divide(new BigDecimal(100),MathContext.DECIMAL128))));		

		if (formaParcelamento.getQuantidadeParcelas() > 2) {
			valorIOFDemaisParcelasEfetivamente = BigDecimalUtil.trunc(opcaoPagamentoParcelamento.getValorDemaisParcelasEfetivamente()
					.subtract(opcaoPagamentoParcelamento.getValorDemaisParcelasEfetivamente()
							.divide(calculaPercentualFormaDecimal(opcaoPagamentoParcelamento.getPercentualIOFAplicado()),MathContext.DECIMAL128)));

			valorIOFSegundaParcelaEfetivamente = BigDecimalUtil.trunc(opcaoPagamentoParcelamento.getValorSegundaParcelaEfetivamente().subtract(opcaoPagamentoParcelamento.getValorSegundaParcelaEfetivamente().divide(calculaPercentualFormaDecimal(opcaoPagamentoParcelamento.getPercentualIOFAplicado()),MathContext.DECIMAL128)));

			valorIOFPrimeiraParcelaEfetivamente = BigDecimalUtil.trunc(valorIofTotal
					.subtract(valorIOFSegundaParcelaEfetivamente)
					.subtract(valorIOFDemaisParcelasEfetivamente.multiply(new BigDecimal(formaParcelamento.getQuantidadeParcelas()-2))));

		} else {
			if (formaParcelamento.getQuantidadeParcelas() > 1) {
				valorIOFDemaisParcelasEfetivamente = new BigDecimal(0);
				valorIOFSegundaParcelaEfetivamente = BigDecimalUtil.trunc(opcaoPagamentoParcelamento.getValorSegundaParcelaEfetivamente().subtract(opcaoPagamentoParcelamento.getValorSegundaParcelaEfetivamente().divide(calculaPercentualFormaDecimal(opcaoPagamentoParcelamento.getPercentualIOFAplicado()),MathContext.DECIMAL128)));
				valorIOFPrimeiraParcelaEfetivamente = BigDecimalUtil.trunc(valorIofTotal.subtract(valorIOFSegundaParcelaEfetivamente));
			} else {
				valorIOFPrimeiraParcelaEfetivamente = opcaoPagamentoParcelamento.getValorIOFPremio();
				valorIOFSegundaParcelaEfetivamente = new BigDecimal(0);
				valorIOFDemaisParcelasEfetivamente = new BigDecimal(0);
			}
		}

		opcaoPagamentoParcelamento.setValorIOFPrimeiraEfetivamente(valorIOFPrimeiraParcelaEfetivamente);
		opcaoPagamentoParcelamento.setValorIOFSegundaEfetivamente(valorIOFSegundaParcelaEfetivamente);
		opcaoPagamentoParcelamento.setValorIOFDemaisEfetivamente(valorIOFDemaisParcelasEfetivamente);
	}

	private void atualizaParcelasEfetivamente(FormaPagamento formaPagamento,FormaParcelamento formaParcelamento,Recebimento recebimento,OpcaoParcelamento opcaoPagtoParcelEscolhido) {
		BigDecimal valorPremioTotal = opcaoPagtoParcelEscolhido.getValorPremioTotal();
		
		BigDecimal valorPrimeiraParcela = opcaoPagtoParcelEscolhido.getValorPrimeiraParcela();
		BigDecimal valorDemaisParcela = opcaoPagtoParcelEscolhido.getValorDemaisParcela();

		BigDecimal valorPrimeiraParcelaEfetivamente;
		BigDecimal valorDemaisParcelasEfetivamente;
		BigDecimal valorSegundaParcelaEfetivamente;
		if (formaPagamento.getExigeRecebimento().equals(SimNaoEnum.NAO) && opcaoPagtoParcelEscolhido.getIdEntrada().equals(SimNaoEnum.SIM)) {

			BigDecimal valorPrimeiraParcelaPaga = valorPrimeiraParcela;
			if (recebimento != null){
				valorPrimeiraParcelaPaga = recebimento.getValorRecebimento();
			}
			if (valorPrimeiraParcelaPaga != valorPrimeiraParcela) {
				valorPrimeiraParcelaEfetivamente = valorPrimeiraParcelaPaga;
				if (formaParcelamento.getQuantidadeParcelas() > 1) {
					if (formaParcelamento.getQuantidadeParcelas() > 2) {
						
						valorDemaisParcelasEfetivamente = BigDecimalUtil.trunc(valorPremioTotal
								.subtract(valorPrimeiraParcelaEfetivamente)
								.divide(new BigDecimal(formaParcelamento.getQuantidadeParcelas()-1),MathContext.DECIMAL128));
						valorSegundaParcelaEfetivamente = BigDecimalUtil.trunc(valorPremioTotal
								.subtract(valorPrimeiraParcelaEfetivamente)
								.subtract(valorDemaisParcelasEfetivamente.multiply(new BigDecimal(formaParcelamento.getQuantidadeParcelas() - 2))));
					} else {
						valorSegundaParcelaEfetivamente = BigDecimalUtil.trunc(valorPremioTotal.subtract(valorPrimeiraParcelaEfetivamente));
						valorDemaisParcelasEfetivamente = new BigDecimal(0);
					}
				} else {
					valorSegundaParcelaEfetivamente = new BigDecimal(0);
					valorDemaisParcelasEfetivamente = new BigDecimal(0);
				}
			} else {
				if (formaParcelamento.getQuantidadeParcelas() > 1) {
					if (formaParcelamento.getQuantidadeParcelas() > 2) {
						valorPrimeiraParcelaEfetivamente = valorPrimeiraParcela;
						valorSegundaParcelaEfetivamente = valorDemaisParcela;
						valorDemaisParcelasEfetivamente = valorDemaisParcela;
					} else {
						valorPrimeiraParcelaEfetivamente = valorPrimeiraParcela;
						valorSegundaParcelaEfetivamente = valorDemaisParcela;
						valorDemaisParcelasEfetivamente = new BigDecimal(0);
					}
				} else {
					valorPrimeiraParcelaEfetivamente = valorPrimeiraParcela;
					valorSegundaParcelaEfetivamente = new BigDecimal(0);
					valorDemaisParcelasEfetivamente = new BigDecimal(0);
				}
			}
		} else {
			valorPrimeiraParcelaEfetivamente = valorPrimeiraParcela;
			if (formaParcelamento.getQuantidadeParcelas() > 2) {
				valorDemaisParcelasEfetivamente = valorDemaisParcela;
				valorSegundaParcelaEfetivamente = valorDemaisParcela;
			} else {
				if (formaParcelamento.getQuantidadeParcelas() > 1) {
					valorSegundaParcelaEfetivamente = valorDemaisParcela;
					valorDemaisParcelasEfetivamente = new BigDecimal(0);
				} else {
					valorSegundaParcelaEfetivamente = new BigDecimal(0);
					valorDemaisParcelasEfetivamente = new BigDecimal(0);
				}
			}
		}
		
		opcaoPagtoParcelEscolhido.setValorPrimeiraEfetivamente(valorPrimeiraParcelaEfetivamente);
		opcaoPagtoParcelEscolhido.setValorSegundaParcelaEfetivamente(valorSegundaParcelaEfetivamente);
		opcaoPagtoParcelEscolhido.setValorDemaisParcelasEfetivamente(valorDemaisParcelasEfetivamente);
	}

	private String validaEntradaMaiorSegundaDemaisParcelas(OpcaoParcelamento opcaoPagtoParcelEscolhido) {
		if (BigDecimalUtil.menor(BigDecimalUtil.nvl(opcaoPagtoParcelEscolhido.getValorSegundaParcelaEfetivamente(),BigDecimal.ZERO),new BigDecimal(0)) || 
			BigDecimalUtil.menor(BigDecimalUtil.nvl(opcaoPagtoParcelEscolhido.getValorDemaisParcelasEfetivamente(),BigDecimal.ZERO),new BigDecimal(0))) {
			return "Atenção! Valor da entrada maior que o valor total do prêmio.";
		} else {
			return "";
		}

	}

	public OpcaoParcelamento getOpcaoParcelamentoEntradaBoleto(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			return opcaoPactoPagtoCotacaoRepository.getOpcaoParcelamentoEntradaBoleto(sequencialCotacaoProposta);
		} catch (HibernateException e) {
			String msgErro = "Erro ao buscar opcão de Parcelamento com entrada em boleto " + sequencialCotacaoProposta;
			logger.error(msgErro,e);
			throw new ServiceException(msgErro,e);
		}
	}

	public CotacaoPagamentoView findOpcaoParcelamentoSelecionada(Cotacao cotacao) throws ServiceException {
		try {
			CotacaoPagamentoView pagamento = opcaoPactoPagtoCotacaoRepository.findOpcaoParcelamentoSelecionada(cotacao);
			if(pagamento != null && pagamento.getTotal() != null) {
				pagamento.setPremioLiquido(cotacao.getValorPremioLiquido());
				return pagamento;
			}
			pagamento = new CotacaoPagamentoView();
			pagamento.setPremioLiquido(cotacao.getValorPremioLiquido());
			return pagamento;
		} catch (Exception e) {
			String msgErro = "Erro ao buscar opcão de Parcelamento selecionada " + cotacao.getSequencialCotacaoProposta();
			logger.error(msgErro,e);
			throw new ServiceException(msgErro,e);
		}
	}

	public OpcaoParcelamento findOpcaoParcelamentoSelecionada(BigInteger cotacao) throws ServiceException {
		try {
			return opcaoPactoPagtoCotacaoRepository.findOpcaoParcelamentoSelecionada(cotacao);
		} catch (Exception e) {
			String msgErro = "Erro ao buscar opcão de Parcelamento " + cotacao;
			logger.error(msgErro,e);
			throw new ServiceException(msgErro,e);
		}
	}

	public List<Validacao> salvar(List<CotacaoPagamentoView> pagamento) throws ServiceException {
		List<Validacao> listaValidacao = new ArrayList<>();
		try {
			
			Cotacao cotacao = cotacaoRepository.findById(pagamento.get(0).getCotacao());
			
			OpcaoParcelamento opcaoParcelamento = opcaoPactoPagtoCotacaoRepository.findOpcaoParcelamentoById(pagamento.get(0).getOpcaoSelecionada());
			Recebimento recebimento = recebimentoRepository.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			if(opcaoParcelamento != null && opcaoParcelamento.getIdEntrada().equals(SimNaoEnum.NAO)){
				if(recebimento != null && recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO)){
					listaValidacao.add(new Validacao("Alteração não realizada: remova o(s) recebimentos vinculados antes de alterar para esta forma de pagamento."));
					return listaValidacao;
				}				
			}

			listaValidacao = opcaoPactoPagtoCotacaoRepository.salvar(pagamento, opcaoParcelamento, recebimento);
		} catch (Exception e) {
			String msgErro = "Erro ao atualizar opcão de Parcelamento " + pagamento.get(0).getCotacao();
			logger.error(msgErro,e);
			listaValidacao.add(new Validacao("Ocorreu ao Salvar a Forma de Pagamento!"));
		}
		return listaValidacao;
	}

	public List<Validacao> salvar(BigInteger sequencialCotacaoPropota, Integer codigoFormaPagamento, Integer codigoFormaParcelamento) throws ServiceException {
		List<Validacao> listaValidacao = new ArrayList<>();
		try {
			
			Cotacao cotacao = cotacaoRepository.findById(sequencialCotacaoPropota);
			//busca na base uma opção de pagamento/parcelamento igual a selecionada anteriormente
			OpcaoParcelamento opcaoParcelamento = opcaoPactoPagtoCotacaoRepository.findOpcaoParcelamentoByTipoPagtoAndTipoParcl(sequencialCotacaoPropota, codigoFormaPagamento, codigoFormaParcelamento);
			
			if(opcaoParcelamento != null) {
				if(opcaoParcelamento.getIdEntrada().equals(SimNaoEnum.NAO)){
					Recebimento recebimento = recebimentoRepository.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
					if(recebimento != null && recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO)){
						listaValidacao.add(new Validacao("Alteração não realizada: remova o(s) recebimentos vinculados antes de alterar para esta forma de pagamento."));
						return listaValidacao;
					}				
				}
				
				opcaoPactoPagtoCotacaoRepository.salvar(sequencialCotacaoPropota, opcaoParcelamento);
			}
		} catch (Exception e) {
			String msgErro = "Erro ao atualizar opcão de Parcelamento " + sequencialCotacaoPropota;
			logger.error(msgErro,e);
			listaValidacao.add(new Validacao("Ocorreu um erro ao salvar a forma de pagamento!"));
		}
		return listaValidacao;
	}
	
	public List<Validacao> salvar(CotacaoPagamentoView pagamento) throws ServiceException {
		List<Validacao> listaValidacao = new ArrayList<>();
		try {
			
			Cotacao cotacao = cotacaoRepository.findById(pagamento.getCotacao());
			
			OpcaoParcelamento opcaoParcelamento = opcaoPactoPagtoCotacaoRepository.findOpcaoParcelamentoById(pagamento.getOpcaoSelecionada());
			if(opcaoParcelamento.getIdEntrada().equals(SimNaoEnum.NAO)){
				Recebimento recebimento = recebimentoRepository.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
				if(recebimento != null && recebimento.getIdTipoCredito().equals(TipoCreditoEnum.CREDITO_VINCULADO)){
					listaValidacao.add(new Validacao("Alteração não realizada: remova o(s) recebimentos vinculados antes de alterar para esta forma de pagamento."));
					return listaValidacao;
				}				
			}

			opcaoPactoPagtoCotacaoRepository.salvar(pagamento.getCotacao(), opcaoParcelamento);
		} catch (Exception e) {
			String msgErro = "Erro ao atualizar opcão de Parcelamento " + pagamento.getCotacao();
			logger.error(msgErro,e);
			listaValidacao.add(new Validacao("Ocorreu ao Salvar a Forma de Pagamento!"));
		}
		return listaValidacao;
	}
	
	/**
	 * Cria um parcelamento temporário para a devolução
	 * @param cotacao
	 */
	public void criarOpcaoParcelamentoDevolucao(Cotacao cotacao) {
		if(devolucaoService.ehDevolucao(cotacao) && (cotacao.getListOpcaoParcelamento()==null || cotacao.getListOpcaoParcelamento().isEmpty())) {
			
			final String FORMA_PAGAMENTO_BOLETO = "BOLETO";
			final String FORMA_PARCELAMENTO_A_VISTA ="A VISTA"; 
			BigDecimal valorPremioLiquidoTotal = buscarValorPremioLiquidoTotal(cotacao);
			OpcaoParcelamento opcaoParcelamento = new OpcaoParcelamento();
			opcaoParcelamento.setCotacao(cotacao);
			opcaoParcelamento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			opcaoParcelamento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			opcaoParcelamento.setSequencialParcelamento(1);
			opcaoParcelamento.setCodigoProduto(cotacao.getCodigoProduto());
			opcaoParcelamento.setCodigoFormaParcelamento(1);
			opcaoParcelamento.setCodigoFormaPagamento(1);
			opcaoParcelamento.setValorPremioLiquido(valorPremioLiquidoTotal);
			opcaoParcelamento.setValorPremioTotal(valorPremioLiquidoTotal);
			opcaoParcelamento.setValorPrimeiraParcela(valorPremioLiquidoTotal);
			opcaoParcelamento.setValorPrimeiraEfetivamente(valorPremioLiquidoTotal);
			opcaoParcelamento.setValorJuros(BigDecimal.ZERO);
			opcaoParcelamento.setValorIOFPrimeiraEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorIOFPremio(BigDecimal.ZERO);
			opcaoParcelamento.setValorIOFJuros(BigDecimal.ZERO);
			opcaoParcelamento.setValorDemaisParcela(BigDecimal.ZERO);
			opcaoParcelamento.setDescricaoFormaPagamento(FORMA_PAGAMENTO_BOLETO);
			opcaoParcelamento.setDescricaoFormaParcelamento(FORMA_PARCELAMENTO_A_VISTA);
			opcaoParcelamento.setIdEntrada(SimNaoEnum.SIM);
			opcaoParcelamento.setValorSegundaParcelaEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorDemaisParcelasEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorJurosPrimeiraEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorJurosSegundaEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorJurosDemaisEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorIOFSegundaEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setValorIOFDemaisEfetivamente(BigDecimal.ZERO);
			opcaoParcelamento.setQuantidadeParcelas(1);
			opcaoParcelamento.setIdImpressao(SimNaoEnum.SIM);
			opcaoParcelamento.setPercentualJurosAplicado(BigDecimal.ZERO);
			opcaoParcelamento.setPercentualIOFAplicado(BigDecimal.ZERO);
			opcaoParcelamento.setIdParcelamentoEscolhido(SimNaoEnum.SIM);
			opcaoParcelamento.setDataAtualizacao(new Date());
			try {
				opcaoPactoPagtoCotacaoRepository.salvar(cotacao.getSequencialCotacaoProposta(), opcaoParcelamento);
				cotacao.getListOpcaoParcelamento().add(opcaoParcelamento);
			} catch (RepositoryException e) {
				logger.error("Ocorreu um erro ao gerar opção de parcelamento para a devolução sq cotacao: "+cotacao.getSequencialCotacaoProposta(),e);
			}
		}
	}
	
	/**
	 * Exclui o parcelamento temporário criado para a devolução
	 * @param cotacao
	 */
	public void excluirOpcaoParcelamentoDevolucao(Cotacao cotacao) {
		if(devolucaoService.ehDevolucao(cotacao)) {
			try {
				if(cotacao.getListOpcaoParcelamento() != null && !cotacao.getListOpcaoParcelamento().isEmpty()) {
					List<OpcaoParcelamento> opcoesParcelamento = opcaoPactoPagtoCotacaoRepository.findOpcoesParcelamento(cotacao.getSequencialCotacaoProposta());
					for(OpcaoParcelamento opcaoParcelamento : opcoesParcelamento) {
						opcaoPactoPagtoCotacaoRepository.delete(opcaoParcelamento);
					}
				}
				
			}
			catch(Exception e) {
				logger.error("Ocorreu um erro ao excluir opção de parcelamento para a devolução sq cotacao: "+cotacao.getSequencialCotacaoProposta(),e);
			}
		}
	}
	
	public void alterarParcelamentoEscolhidoDevolucao(Cotacao cotacao) {		
		if(devolucaoService.ehDevolucao(cotacao) && cotacao.getListOpcaoParcelamento() != null && !cotacao.getListOpcaoParcelamento().isEmpty()) {
			cotacao.getListOpcaoParcelamento().get(0).setIdParcelamentoEscolhido(SimNaoEnum.NAO);	
		}
	}

	public FormaParcelamento buscarFormaParcelamentoQuantidade(Integer quantidadeParcelas, SimNaoEnum entrada) {
		return formaParcelamentoRepository.findByQuantidadeParcelas(quantidadeParcelas, entrada);
	}
}
