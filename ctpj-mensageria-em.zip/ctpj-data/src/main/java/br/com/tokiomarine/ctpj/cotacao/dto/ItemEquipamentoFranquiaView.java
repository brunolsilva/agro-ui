package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemEquipamentoFranquiaView implements Serializable {

	private static final long serialVersionUID = -8327847817076976869L;

	private BigInteger sequencialItemEquipamantoFranquia;
	private BigInteger codigoEquipamento;
	private String descricaoEquipamento;
	private FormaFranquiaEnum idFormaFranquia;
	private Integer numeroHorasFranquia;
	private Integer numeroDiasFranquia;
	private String taxaFranquia;
	private String valorFranquia;
	private String valorFranquiaMinimo;
	private String valorFranquiaMaximo;
	private String taxaImportanciaSegurada;
	private String taxaImportanciaSeguradaMinimo;
	private String taxaImportanciaSeguradaMaximo;
	private Integer idTextoFranquia;
	private String descricaoTextoFranquia;
	private BigInteger numeroCotacaoProposta;
	private Integer versaoCotacaoProposta;
	private BigInteger sequencialItemCobertura;
	private boolean deleteItem;
	private BigInteger sequencialItemCotacao;

	public BigInteger getSequencialItemEquipamantoFranquia() {
		return sequencialItemEquipamantoFranquia;
	}

	public void setSequencialItemEquipamantoFranquia(BigInteger sequencialItemEquipamantoFranquia) {
		this.sequencialItemEquipamantoFranquia = sequencialItemEquipamantoFranquia;
	}

	public BigInteger getCodigoEquipamento() {
		return codigoEquipamento;
	}

	public void setCodigoEquipamento(BigInteger codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}

	public String getDescricaoEquipamento() {
		return descricaoEquipamento;
	}

	public void setDescricaoEquipamento(String descricaoEquipamento) {
		this.descricaoEquipamento = descricaoEquipamento;
	}

	public FormaFranquiaEnum getIdFormaFranquia() {
		return idFormaFranquia;
	}

	public void setIdFormaFranquia(FormaFranquiaEnum idFormaFranquia) {
		this.idFormaFranquia = idFormaFranquia;
	}

	public Integer getNumeroHorasFranquia() {
		return numeroHorasFranquia;
	}

	public void setNumeroHorasFranquia(Integer numeroHorasFranquia) {
		this.numeroHorasFranquia = numeroHorasFranquia;
	}

	public Integer getNumeroDiasFranquia() {
		return numeroDiasFranquia;
	}

	public void setNumeroDiasFranquia(Integer numeroDiasFranquia) {
		this.numeroDiasFranquia = numeroDiasFranquia;
	}

	public String getTaxaFranquia() {
		return taxaFranquia;
	}

	public void setTaxaFranquia(String taxaFranquia) {
		this.taxaFranquia = taxaFranquia;
	}

	public String getValorFranquia() {
		return valorFranquia;
	}

	public void setValorFranquia(String valorFranquia) {
		this.valorFranquia = valorFranquia;
	}

	public String getValorFranquiaMinimo() {
		return valorFranquiaMinimo;
	}

	public void setValorFranquiaMinimo(String valorFranquiaMinimo) {
		this.valorFranquiaMinimo = valorFranquiaMinimo;
	}

	public String getValorFranquiaMaximo() {
		return valorFranquiaMaximo;
	}

	public void setValorFranquiaMaximo(String valorFranquiaMaximo) {
		this.valorFranquiaMaximo = valorFranquiaMaximo;
	}

	public String getTaxaImportanciaSegurada() {
		return taxaImportanciaSegurada;
	}

	public void setTaxaImportanciaSegurada(String taxaImportanciaSegurada) {
		this.taxaImportanciaSegurada = taxaImportanciaSegurada;
	}

	public String getTaxaImportanciaSeguradaMinimo() {
		return taxaImportanciaSeguradaMinimo;
	}

	public void setTaxaImportanciaSeguradaMinimo(String taxaImportanciaSeguradaMinimo) {
		this.taxaImportanciaSeguradaMinimo = taxaImportanciaSeguradaMinimo;
	}

	public String getTaxaImportanciaSeguradaMaximo() {
		return taxaImportanciaSeguradaMaximo;
	}

	public void setTaxaImportanciaSeguradaMaximo(String taxaImportanciaSeguradaMaximo) {
		this.taxaImportanciaSeguradaMaximo = taxaImportanciaSeguradaMaximo;
	}

	public Integer getIdTextoFranquia() {
		return idTextoFranquia;
	}

	public void setIdTextoFranquia(Integer idTextoFranquia) {
		this.idTextoFranquia = idTextoFranquia;
	}

	public String getDescricaoTextoFranquia() {
		return descricaoTextoFranquia;
	}

	public void setDescricaoTextoFranquia(String descricaoTextoFranquia) {
		this.descricaoTextoFranquia = descricaoTextoFranquia;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public Integer getVersaoCotacaoProposta() {
		return versaoCotacaoProposta;
	}

	public void setVersaoCotacaoProposta(Integer versaoCotacaoProposta) {
		this.versaoCotacaoProposta = versaoCotacaoProposta;
	}

	public BigInteger getSequencialItemCobertura() {
		return sequencialItemCobertura;
	}

	public void setSequencialItemCobertura(BigInteger sequencialItemCobertura) {
		this.sequencialItemCobertura = sequencialItemCobertura;
	}

	public boolean isDeleteItem() {
		return deleteItem;
	}

	public void setDeleteItem(boolean deleteItem) {
		this.deleteItem = deleteItem;
	}

	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}

	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}

}
