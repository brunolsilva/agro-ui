package br.com.tokiomarine.ctpj.cotacao.service;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.repository.TransmissaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.ServiceException;

@Service
@Transactional(rollbackFor = {ServiceException.class,Exception.class})
public class TransmissaoSalvarService {

	@Autowired
	private TransmissaoRepository transmissaoRepository;

	@LogPerformance
	@Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = {ServiceException.class,Exception.class})
	public void salvarAntesDeTransmitir(Cotacao cotacao) throws ServiceException {
		transmissaoRepository.salvar(cotacao);
	}
}
