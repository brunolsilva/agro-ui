package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.tokiomarine.ctpj.cotacao.dto.DadosCotacaoParaResseguroFacultativo;
import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoForm;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.ResseguroFacultativoService;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;
import br.com.tokiomarine.ctpj.domain.mongo.Broker;
import br.com.tokiomarine.ctpj.enums.IdCessaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoRelatorioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Ressegurador;
import br.com.tokiomarine.ctpj.infra.enums.TipoResseguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.BrokerService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ResseguradorService;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping("/resseguroFacultativo/{seqCotacao}")
public class ResseguroFacultativoController {
	
	@Autowired
	private CotacaoService cotacaoService;
	@Autowired
	private ResseguradorService resseguradorService;
	@Autowired
	private BrokerService brokerService;
	@Autowired
	private ResseguroFacultativoService resseguroFacultativoService;
	
	private static Logger logger = LogManager.getLogger(ResseguroFacultativoController.class);
	
	@GetMapping
	public String page(@PathVariable BigInteger seqCotacao, @RequestHeader(value = "referer", required = false) String referer,  Model model) throws ServiceException{
		DadosCotacaoParaResseguroFacultativo dadosRisco = resseguroFacultativoService.recuperarDadosDoRisco(seqCotacao);
		Optional<ResseguroFacultativo> ressegFacultativo = resseguroFacultativoService.buscaPorCotacao(seqCotacao);
		
		model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(seqCotacao));
		model.addAttribute("seqCotacao", seqCotacao);
		model.addAttribute("dadosRisco", dadosRisco);
		model.addAttribute("origem", referer);
		if(ressegFacultativo.isPresent())
			model.addAttribute("ressegFacul", ressegFacultativo.get());		
		
		return Paginas.resseguroFacultativo.value();
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.OK)
	public void salva(@RequestBody @Valid ResseguroFacultativoForm form, @PathVariable BigInteger seqCotacao){
		resseguroFacultativoService.salvaResseguroFacultativo(form, seqCotacao);
	}
	
	@SuppressWarnings("deprecation")
	@GetMapping("/pdf")
	public void geraPdf(@PathVariable BigInteger seqCotacao, HttpServletResponse response){
		try{
			byte[] pdf = resseguroFacultativoService.geraResseguroFacultativoEmPDF(seqCotacao);
			response.setContentType(TipoRelatorioEnum.PDF_CONTENT_TYPE.getText());
			String headerValue = TipoRelatorioEnum.ATTACHMENT_FILENAME.getText().concat("resseguro-facultativo").concat(TipoRelatorioEnum.FILE_TYPE_PDF.getText());
			response.setHeader(TipoRelatorioEnum.CONTENT_DISPOSITION.getText(), headerValue);
			response.setContentLength(pdf.length);
			response.getOutputStream().write(pdf);
			response.getOutputStream().flush();
		}catch(Exception e){
			logger.error("Ocorreu um erro na geração do pdf", e);
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro interno na geração do pdf");
		}	
	}
	
	@ModelAttribute("tipoResseguros")
	public TipoResseguroEnum[] getTipoResseguros(){
		return TipoResseguroEnum.values();
	}
	
	@ModelAttribute("tiposCessao")
	public IdCessaoEnum[] getTipoCessao(){
		return IdCessaoEnum.values();
	}
	
	@ModelAttribute("resseguradores")
	public List<Ressegurador> getResseguradores() throws ServiceException{
		return resseguradorService.findAll();
	}
	
	@ModelAttribute("brokers")
	public List<Broker> getBrokers(){
		return brokerService.buscaTodos();
	}

}
