package br.com.tokiomarine.ctpj.cotacao.repository;

import static org.hibernate.criterion.Restrictions.eq;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.ServicoCotacao;

@Repository
public class AlteracaoEndossoRepository extends BaseDAO{
	
	private static final String EXCLUI_ALTERACAO_ENDOSSO_POR_SEQUENCIA_COTACAO = 
			"delete from AlteracaoEndosso where cotacao.sequencialCotacaoProposta = :seqCotacao";
	
	public void save(AlteracaoEndosso alteracaoEndosso){
		getCurrentSession().save(alteracaoEndosso);
	}
	
	public AlteracaoEndosso find(BigInteger numeroCotacaoProposta, Integer versaoCotacaoProposta,Integer codigoTipoAlteracao){
		AlteracaoEndosso alteracaoEndosso = (AlteracaoEndosso) getCurrentSession().createCriteria(AlteracaoEndosso.class)
				.add(eq("numeroCotacaoProposta", numeroCotacaoProposta))
				.add(eq("versaoCotacaoProposta", versaoCotacaoProposta))
				.add(eq("codigoTipoAlteracao", codigoTipoAlteracao))
				.uniqueResult();
		
		return alteracaoEndosso;
	}
	
	public void delete(BigInteger seqCotacao) {
		getCurrentSession()
		.createQuery(EXCLUI_ALTERACAO_ENDOSSO_POR_SEQUENCIA_COTACAO)
		.setParameter("seqCotacao", seqCotacao)
		.executeUpdate();
	}
	
	public List<AlteracaoEndosso> listAlteracaoEndosso(BigInteger sequencialCotacaoProposta) throws Exception{
		StringBuilder hql = new StringBuilder();
		hql.append("Select  a from AlteracaoEndosso a");
		hql.append(" where a.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		return (List<AlteracaoEndosso>) getCurrentSession()
				.createQuery(hql.toString())
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.list();
	}
	

}
