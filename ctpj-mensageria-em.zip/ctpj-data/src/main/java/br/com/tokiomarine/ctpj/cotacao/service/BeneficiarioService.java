package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.repository.BeneficiarioRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;

/**
 * Serviço para a entidade ItemBeneficiario
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class BeneficiarioService {
	
	@Autowired
	private BeneficiarioRepository repository;
	
	public ItemBeneficiario salvaItemBeneficiario(ItemBeneficiario item){
		return repository.salvaItemBeneficiario(item);
	}
	
	public List<ItemBeneficiario> salvaItemBeneficiario(BigInteger seqCotacao, List<ItemBeneficiario> itens){
		repository.excluiItemBeneficiarioPorCotacao(seqCotacao);
		repository.salvaItemBeneficiario(itens);
		
		return itens;
	}
	
	public List<ItemBeneficiario> listaItensBeneficiario(BigInteger sequencialCotacaoProposta){
		return repository.listaItensBeneficiario(sequencialCotacaoProposta);
	}
	
	public void excluiItemBeneficiario(BigInteger sequencialItemBeneficiario){
		repository.excluiItemBeneficiario(sequencialItemBeneficiario);
	}

}
