package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ClausulaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CondicaoContratualCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemAeronave;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemAjustamentoPremio;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDadosObra;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarcacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarque;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemPiloto;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemQBR;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoEndereco;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ParecerCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.integracao.service.CorretorBaseUnicaService;
import br.com.tokiomarine.ctpj.mapper.CorretorMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Service
@Transactional(rollbackFor = {Exception.class})
public class DuplicarCotacaoService {

	private static Logger logger = LogManager.getLogger(DuplicarCotacaoService.class);

	private final Integer VS_COTAC_FIRST = 1;
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private CorretorBaseUnicaService corretorBaseUnicaService;
	
	@LogPerformance
	public List<Validacao> copiarConteudoParaCotacao(
			BigInteger idDestino,
			BigInteger numeroCotacaoProposta,
			Integer versaoCotacao) {

		try {
			Cotacao destino = cotacaoRepository.findById(idDestino);
			Cotacao origem = cotacaoRepository.findByNumeroAndVersao(numeroCotacaoProposta,versaoCotacao);
			Corretor corretor = CorretorMapper.INSTANCE.fromCorretorBaseUnicaToCorretor(corretorBaseUnicaService.findCorretorByCodigo(Long.valueOf(destino.getCodigoCorretorACSEL())));
			List<Validacao> validacoes = validaCopia(origem, destino);
			if(!validacoes.isEmpty()) {
				return validacoes;
			}

			String codigoCorretorACSEL = destino.getCodigoCorretorACSEL();
			String nomeCorretor = destino.getNomeCorretor();
			BigInteger numeroCotacao = destino.getNumeroCotacaoProposta();
			Integer versao = destino.getVersaoCotacaoProposta();

			User user = SecurityUtils.getCurrentUser();
			destino = cotacaoRepository.duplicaCotacaoExistente(origem,destino);

			destino.setCodigoSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getSituacao().intValue());
			destino.setNomeSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getDescricao());
			destino.setCodigoCorretorACSEL(codigoCorretorACSEL);
			destino.setNomeCorretor(nomeCorretor);
			destino.setNumeroCotacaoProposta(numeroCotacao);
			destino.setVersaoCotacaoProposta(versao);
			
			if (destino.getListComissaoCotacao() != null && !destino.getListComissaoCotacao().isEmpty()) {
				this.bindComissaoCotacao(destino.getListComissaoCotacao(),destino,user);
			}

			if (destino.getListCondicaoContratual() != null && !destino.getListCondicaoContratual().isEmpty()) {
				bindCondicaoContratual(destino.getListCondicaoContratual(), destino, user);
			}
			if (destino.getListCorretagemCotacao() != null && !destino.getListCorretagemCotacao().isEmpty()) {
				this.bindCorretagemCotacao(destino.getListCorretagemCotacao(),destino,user,corretor);
			}
			
			if (destino.getListCosseguroCotacao() != null && !destino.getListCosseguroCotacao().isEmpty()) {
				this.bindCosseguroCotacao(destino.getListCosseguroCotacao(),destino,user);
			}
			
			if (destino.getListRecebimento() != null && !destino.getListRecebimento().isEmpty()) {
				this.bindRecebimento(destino.getListRecebimento(),destino,user);
			}
			
			if (destino.getListComissaoCotacao() != null && !destino.getListComissaoCotacao().isEmpty()) {
				this.bindComissaoCotacao(destino.getListComissaoCotacao(),destino,user);
			}
			
			if (destino.getListNotaCotacao() != null && !destino.getListNotaCotacao().isEmpty()) {
				this.bindNotaCotacao(destino.getListNotaCotacao(),destino,user);
			}
			
			if(destino.getPareceresCotacao() != null && !destino.getPareceresCotacao().isEmpty()){
				this.bindPareceres(destino.getPareceresCotacao(),destino,user);
			}

			if (destino.getListItem() != null && !destino.getListItem().isEmpty()) {
				this.bindItemCotacao(destino.getListItem(),destino,user);
			}

			return Collections.emptyList();
		} catch (Exception e) {
			logger.error("Erro ", e);
			throw new RuntimeException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public void duplicarItem(BigInteger item, Integer quantidade, int ultimoItem) {
		try {
			ItemCotacao itemCotacao = cotacaoRepository.findItem(item);
			List<ItemCotacao> itemsDuplicados = cotacaoRepository.duplicaItem(itemCotacao, quantidade, ultimoItem);
			for (ItemCotacao itemCotacaoDuplicado : itemsDuplicados) {
				cotacaoRepository.save(itemCotacaoDuplicado);
			} 
		} catch (Exception e) {
			logger.error("Erro ao duplicar item " + item, e);
			throw new RuntimeException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public void bindCotacaoDuplicada(Cotacao cotacao,User user) throws ServiceException {
		logger.info("ajustando Cotacao");

		Corretor corretor = CorretorMapper.INSTANCE.fromCorretorBaseUnicaToCorretor(corretorBaseUnicaService.findCorretorByCodigo(Long.valueOf(cotacao.getCodigoCorretorACSEL())));
		
		cotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		cotacao.setVersaoCotacaoProposta(VS_COTAC_FIRST);
		cotacao.setSequencialCotacaoProposta(null);

		cotacao.setCodigoSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getSituacao().intValue());
		cotacao.setNomeSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getDescricao());

		cotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
		cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		cotacao.setDataAtualizacao(Calendar.getInstance().getTime());

		cotacao.setListAlteracaoEndosso(null);
		cotacao.setListBloqueioAlcada(null);
		cotacao.setListCondicaoContratual(null);
		cotacao.setListContaCorrenteGlobal(null);
		cotacao.setListDescontoCCG(null);
		cotacao.setListHistoricoSituacao(null);
		cotacao.setListOpcaoParcelamento(null);
		cotacao.setListServicoCotacao(null);
		cotacao.setListJurosParcelamento(null);
		cotacao.setControlesFichaRegistrada(null);

		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			this.bindComissaoCotacao(cotacao.getListComissaoCotacao(),cotacao,user);
		}
		
		if (cotacao.getListCorretagemCotacao() != null && !cotacao.getListCorretagemCotacao().isEmpty()) {
			this.bindCorretagemCotacao(cotacao.getListCorretagemCotacao(),cotacao,user,corretor);
		}
		
		if (cotacao.getListCosseguroCotacao() != null && !cotacao.getListCosseguroCotacao().isEmpty()) {
			this.bindCosseguroCotacao(cotacao.getListCosseguroCotacao(),cotacao,user);
		}
		
		if (cotacao.getListRecebimento() != null && !cotacao.getListRecebimento().isEmpty()) {
			this.bindRecebimento(cotacao.getListRecebimento(),cotacao,user);
		}
		
		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			this.bindComissaoCotacao(cotacao.getListComissaoCotacao(),cotacao,user);
		}
		
		if (cotacao.getListNotaCotacao() != null && !cotacao.getListNotaCotacao().isEmpty()) {
			this.bindNotaCotacao(cotacao.getListNotaCotacao(),cotacao,user);
		}
		
		if(cotacao.getPareceresCotacao() != null && !cotacao.getPareceresCotacao().isEmpty()){
			this.bindPareceres(cotacao.getPareceresCotacao(),cotacao,user);
		}

		if (cotacao.getListItem() != null && !cotacao.getListItem().isEmpty()) {
			this.bindItemCotacao(cotacao.getListItem(),cotacao,user);
		}
	}

	@LogPerformance
	private void bindComissaoCotacao(Set<ComissaoCotacao> set,Cotacao cotacao,User user) {
		for (ComissaoCotacao comissaoCotacao : set) {
			comissaoCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			comissaoCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			comissaoCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			comissaoCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			comissaoCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			comissaoCotacao.setCotacao(cotacao);
		}
	}
	
	@LogPerformance
	private void bindCondicaoContratual(List<CondicaoContratualCotacao> condicoes,Cotacao cotacao,User user) {
		for (CondicaoContratualCotacao condicaoContratual : condicoes) {
			condicaoContratual.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			condicaoContratual.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			condicaoContratual.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			condicaoContratual.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			condicaoContratual.setDataAtualizacao(Calendar.getInstance().getTime());
			condicaoContratual.setCotacao(cotacao);
		}
	}

	@LogPerformance
	private void bindCorretagemCotacao(List<CorretagemCotacao> listCorretagemCotacao,Cotacao cotacao,User user,Corretor corretor) {
		for (CorretagemCotacao corretagemCotacao : listCorretagemCotacao) {
			
			if(corretagemCotacao.getIdCorretorLider().equals(SimNaoEnum.SIM)){
				corretagemCotacao.setCodigoCorretorAcsel(cotacao.getCodigoCorretorACSEL());
				corretagemCotacao.setNomeCorretorAcsel(corretor.getNome());
			}
			
			corretagemCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			corretagemCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			corretagemCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			corretagemCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			corretagemCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			corretagemCotacao.setCotacao(cotacao);
		}

	}

	@LogPerformance
	private void bindCosseguroCotacao(Set<CosseguroCotacao> listCosseguroCotacao,Cotacao cotacao,User user) {
		for (CosseguroCotacao cosseguroCotacao : listCosseguroCotacao) {
			cosseguroCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			cosseguroCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			cosseguroCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			cosseguroCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			cosseguroCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			cosseguroCotacao.setCotacao(cotacao);
		}

	}

	@LogPerformance
	private void bindRecebimento(Set<Recebimento> listRecebimento,Cotacao cotacao,User user) {
		for (Recebimento recebimento : listRecebimento) {
			recebimento.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			recebimento.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			recebimento.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			recebimento.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			recebimento.setDataAtualizacao(Calendar.getInstance().getTime());
			recebimento.setCotacao(cotacao);
		}

	}

	@LogPerformance
	private void bindClausulaCotacao(List<ClausulaCotacao> listClausulaCotacao,Cotacao cotacao,User user) {
		for (ClausulaCotacao clausulaCotacao : listClausulaCotacao) {
			clausulaCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			clausulaCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			clausulaCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			clausulaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			clausulaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			clausulaCotacao.setCotacao(cotacao);
		}

	}

	@LogPerformance
	private void bindNotaCotacao(List<NotaCotacao> listNotaCotacao,Cotacao cotacao,User user) {
		for (NotaCotacao notaCotacao : listNotaCotacao) {
			notaCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			notaCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			notaCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			notaCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			notaCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			notaCotacao.setCotacao(cotacao);
		}

	}
	
	@LogPerformance
	private void bindPareceres(List<ParecerCotacao> pareceres,Cotacao cotacao,User user){
		for (ParecerCotacao parecerCotacao : pareceres) {
			parecerCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			parecerCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			parecerCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			parecerCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			parecerCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			parecerCotacao.setCotacao(cotacao);
		} 
	}

	@LogPerformance
	private void bindItemCotacao(Set<ItemCotacao> listItemCotacao,Cotacao cotacao,User user) {
		for (ItemCotacao itemCotacao : listItemCotacao) {
			
			itemCotacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemCotacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemCotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCotacao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCotacao.setCotacao(cotacao);
			
			itemCotacao.setListItemRamo(null);
			itemCotacao.setListItemRamoEmissao(null);
			
			
			if(itemCotacao.getListItemAeronave() != null && !itemCotacao.getListItemAeronave().isEmpty()){
				this.bindItemAeronave(itemCotacao.getListItemAeronave(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemBeneficiario() != null && !itemCotacao.getListItemBeneficiario().isEmpty()){
				this.bindItemBeneficiario(itemCotacao.getListItemBeneficiario(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemCossegurado() != null && !itemCotacao.getListItemCossegurado().isEmpty()){
				this.bindItemCossegurado(itemCotacao.getListItemCossegurado(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemDadosObra() != null && !itemCotacao.getListItemDadosObra().isEmpty()){
				this.bindItemDadosObra(itemCotacao.getListItemDadosObra(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemDistribuicao() != null && !itemCotacao.getListItemDistribuicao().isEmpty()){
				this.bindItemDistribuicao(itemCotacao.getListItemDistribuicao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemEmbarcacao() != null && !itemCotacao.getListItemEmbarcacao().isEmpty()){
				this.bindItemEmbarcacao(itemCotacao.getListItemEmbarcacao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemEmbarque() != null && !itemCotacao.getListItemEmbarque().isEmpty()){
				this.bindItemEmbarque(itemCotacao.getListItemEmbarque(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemInspecao() != null && !itemCotacao.getListItemInspecao().isEmpty()){
				this.bindItemInspecao(itemCotacao.getListItemInspecao(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemNota() != null && !itemCotacao.getListItemNota().isEmpty()){
				this.bindItemNota(itemCotacao.getListItemNota(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemOutroSeguro() != null && !itemCotacao.getListItemOutroSeguro().isEmpty()){
				this.bindItemOutroSeguro(itemCotacao.getListItemOutroSeguro(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemPiloto() != null && !itemCotacao.getListItemPiloto().isEmpty()){
				this.bindItemPiloto(itemCotacao.getListItemPiloto(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemQBR() != null && !itemCotacao.getListItemQBR().isEmpty()){
				this.bindItemQBR(itemCotacao.getListItemQBR(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemRelacaoBem() != null && !itemCotacao.getListItemRelacaoBem().isEmpty()){
				this.bindItemRelacaoBem(itemCotacao.getListItemRelacaoBem(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemRelacaoEndereco() != null && !itemCotacao.getListItemRelacaoEndereco().isEmpty()){
				this.bindItemRelacaoEndereco(itemCotacao.getListItemRelacaoEndereco(),itemCotacao,cotacao,user);
			}
			
			if(itemCotacao.getListItemSistemaProtecional() != null && !itemCotacao.getListItemSistemaProtecional().isEmpty()){
				this.bindItemSistemaProtecional(itemCotacao.getListItemSistemaProtecional(),itemCotacao,cotacao,user);
			}
			
//			if(itemCotacao.getListItemClausula() != null && !itemCotacao.getListItemClausula().isEmpty()){
//				this.bindClausulaItem(itemCotacao.getListItemClausula(),itemCotacao,cotacao,user);
//			}
			
			if(itemCotacao.getListItemAjustamentoPremio() != null && !itemCotacao.getListItemAjustamentoPremio().isEmpty()){
				
			}
			
			if(itemCotacao.getListItemCobertura() != null && !itemCotacao.getListItemCobertura().isEmpty()){
				this.bindItemCobertura(itemCotacao.getListItemCobertura(),itemCotacao,cotacao,user);
			}
			

		}

	}

	@LogPerformance
	private void bindItemAeronave(List<ItemAeronave> listItemAeronave,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemAeronave itemAeronave : listItemAeronave) {
			itemAeronave.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemAeronave.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemAeronave.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemAeronave.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemAeronave.setDataAtualizacao(Calendar.getInstance().getTime());
			itemAeronave.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemBeneficiario(List<ItemBeneficiario> listItemBeneficiario,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemBeneficiario itemBeneficiario : listItemBeneficiario) {
			itemBeneficiario.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemBeneficiario.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemBeneficiario.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemBeneficiario.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemBeneficiario.setDataAtualizacao(Calendar.getInstance().getTime());
			itemBeneficiario.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemCossegurado(List<ItemCossegurado> listItemCossegurado,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemCossegurado itemCossegurado : listItemCossegurado) {
			itemCossegurado.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemCossegurado.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemCossegurado.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCossegurado.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCossegurado.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCossegurado.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemDadosObra(List<ItemDadosObra> listItemDadosObra,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemDadosObra itemDadosObra : listItemDadosObra) {
			itemDadosObra.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemDadosObra.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemDadosObra.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemDadosObra.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemDadosObra.setDataAtualizacao(Calendar.getInstance().getTime());
			itemDadosObra.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemDistribuicao(Set<ItemDistribuicao> listItemDistribuicao,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemDistribuicao itemDistribuicao : listItemDistribuicao) {
			itemDistribuicao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemDistribuicao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemDistribuicao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemDistribuicao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemDistribuicao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemDistribuicao.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemEmbarcacao(List<ItemEmbarcacao> listItemEmbarcacao,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemEmbarcacao itemEmbarcacao : listItemEmbarcacao) {
			itemEmbarcacao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemEmbarcacao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemEmbarcacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemEmbarcacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemEmbarcacao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemEmbarcacao.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemEmbarque(List<ItemEmbarque> listItemEmbarque,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemEmbarque itemEmbarque : listItemEmbarque) {
			itemEmbarque.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemEmbarque.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemEmbarque.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemEmbarque.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemEmbarque.setDataAtualizacao(Calendar.getInstance().getTime());
			itemEmbarque.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemInspecao(Set<ItemInspecao> listItemInspecao,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemInspecao itemInspecao : listItemInspecao) {
			itemInspecao.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemInspecao.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemInspecao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemInspecao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemInspecao.setDataAtualizacao(Calendar.getInstance().getTime());
			itemInspecao.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemNota(List<ItemNota> listItemNota,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemNota ItemNota : listItemNota) {
			ItemNota.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			ItemNota.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			ItemNota.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			ItemNota.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			ItemNota.setDataAtualizacao(Calendar.getInstance().getTime());
			ItemNota.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemOutroSeguro(List<ItemOutroSeguro> listItemOutroSeguro,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemOutroSeguro itemOutroSeguro : listItemOutroSeguro) {
			itemOutroSeguro.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemOutroSeguro.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemOutroSeguro.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemOutroSeguro.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemOutroSeguro.setDataAtualizacao(Calendar.getInstance().getTime());
			itemOutroSeguro.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemPiloto(List<ItemPiloto> listItemPiloto,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemPiloto itemPiloto : listItemPiloto) {
			itemPiloto.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemPiloto.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemPiloto.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemPiloto.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemPiloto.setDataAtualizacao(Calendar.getInstance().getTime());
			itemPiloto.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemQBR(List<ItemQBR> listItemQBR,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemQBR itemQBR : listItemQBR) {
			itemQBR.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemQBR.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemQBR.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemQBR.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemQBR.setDataAtualizacao(Calendar.getInstance().getTime());
			itemQBR.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemRelacaoBem(List<ItemRelacaoBem> listItemRelacaoBem,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemRelacaoBem itemRelacaoBem : listItemRelacaoBem) {
			itemRelacaoBem.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemRelacaoBem.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemRelacaoBem.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemRelacaoBem.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemRelacaoBem.setDataAtualizacao(Calendar.getInstance().getTime());
			itemRelacaoBem.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemRelacaoEndereco(List<ItemRelacaoEndereco> listItemRelacaoEndereco,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemRelacaoEndereco itemRelacaoEndereco : listItemRelacaoEndereco) {
			itemRelacaoEndereco.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemRelacaoEndereco.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemRelacaoEndereco.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemRelacaoEndereco.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemRelacaoEndereco.setDataAtualizacao(Calendar.getInstance().getTime());
			itemRelacaoEndereco.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemSistemaProtecional(Set<ItemSistemaProtecional> listItemSistemaProtecional,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemSistemaProtecional itemSistemaProtecional : listItemSistemaProtecional) {
			itemSistemaProtecional.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemSistemaProtecional.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemSistemaProtecional.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemSistemaProtecional.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemSistemaProtecional.setDataAtualizacao(Calendar.getInstance().getTime());
			itemSistemaProtecional.setItemCotacao(itemCotacao);
		}

	}

	@LogPerformance
	private void bindItemAjustamentoPremio(List<ItemAjustamentoPremio> listItemAjustamentoPremio,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemAjustamentoPremio itemAjustamentoPremio : listItemAjustamentoPremio) {			
			itemAjustamentoPremio.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemAjustamentoPremio.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemAjustamentoPremio.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemAjustamentoPremio.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemAjustamentoPremio.setDataAtualizacao(Calendar.getInstance().getTime());
			itemAjustamentoPremio.setItemCotacao(itemCotacao);
			
		}
	}
		
	@LogPerformance
	private void bindItemCobertura(Set<ItemCobertura> listItemCobertura,ItemCotacao itemCotacao,Cotacao cotacao,User user) {
		for (ItemCobertura itemCobertura : listItemCobertura) {
			
			itemCobertura.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemCobertura.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemCobertura.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemCobertura.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemCobertura.setDataAtualizacao(Calendar.getInstance().getTime());
			itemCobertura.setItemCotacao(itemCotacao);
			
			itemCobertura.setListDescontoAgravacao(null);
			
			if(itemCobertura.getListaItemCoberturaClausula() != null &&  !itemCobertura.getListaItemCoberturaClausula().isEmpty()){
				this.bindClausulaItemCobertura(itemCobertura.getListaItemCoberturaClausula(),itemCobertura,cotacao,user);
			}
			
			if(itemCobertura.getListItemEquipamentoFranquia() != null && !itemCobertura.getListItemEquipamentoFranquia().isEmpty()){
				this.bindItemEquipamentoFranquia(itemCobertura.getListItemEquipamentoFranquia(),itemCobertura,cotacao,user);
			}
			
			
			
		}

	}
	

	@LogPerformance
	private void bindClausulaItemCobertura(List<ItemCoberturaClausula> listClausulaItemCobertura,ItemCobertura itemCobertura,Cotacao cotacao,User user) {
		for (ItemCoberturaClausula ClausulaItemCobertura : listClausulaItemCobertura) {
			ClausulaItemCobertura.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			ClausulaItemCobertura.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			ClausulaItemCobertura.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			ClausulaItemCobertura.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			ClausulaItemCobertura.setDataAtualizacao(Calendar.getInstance().getTime());
			ClausulaItemCobertura.setItemCobertura(itemCobertura);
		}

	}

	@LogPerformance
	private void bindItemEquipamentoFranquia(List<ItemEquipamentoFranquia> listItemEquipamentoFranquia,ItemCobertura itemCobertura,Cotacao cotacao,User user) {
		for (ItemEquipamentoFranquia itemEquipamentoFranquia : listItemEquipamentoFranquia) {
			itemEquipamentoFranquia.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			itemEquipamentoFranquia.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			itemEquipamentoFranquia.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
			itemEquipamentoFranquia.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemEquipamentoFranquia.setDataAtualizacao(Calendar.getInstance().getTime());
			itemEquipamentoFranquia.setItemCobertura(itemCobertura);
		}

	}

	private List<Validacao> validaCopia(Cotacao origem, Cotacao destino) {
		List<Validacao> validacoes = new ArrayList<>();
		if(origem == null) {
			validacoes.add(new Validacao("Cotação não encontrada!"));
			return validacoes;
		}
		
		if(!origem.getCodigoProduto().equals(destino.getCodigoProduto())) {
			validacoes.add(new Validacao("O produto das cotações devem ser o mesmo!"));
		}

		if(!Arrays.asList(TipoSeguroEnum.NOVO,TipoSeguroEnum.RENOVACAO_CONGENERE).contains(origem.getIdTipoSeguro())) {
			validacoes.add(new Validacao("Somente é possível duplicar cotações do tipo Novo e Renovação Congênere!"));
		}

		if(!Arrays.asList(TipoSeguroEnum.NOVO,TipoSeguroEnum.RENOVACAO_CONGENERE).contains(destino.getIdTipoSeguro())) {
			validacoes.add(new Validacao("Somente é possível duplicar cotações do tipo Novo e Renovação Congênere!"));
		}

		if(destino.getIdTipoSeguro() != origem.getIdTipoSeguro()) {
			validacoes.add(new Validacao("O tipo de seguro da cotação deve ser o mesmo!"));
		}
		
		if(!origem.getNumeroCNPJCPFSegurado().equals(destino.getNumeroCNPJCPFSegurado())) {
			validacoes.add(new Validacao("O segurado (CPF/CNPJ) deve ser o mesmo!"));
		}

		return validacoes;
	}

	/*
	 * COTACAO
	 * private List<ComissaoCotacao> listComissaoCotacao;
	 * private List<CorretagemCotacao> listCorretagemCotacao;
	 * private Set<CosseguroCotacao> listCosseguroCotacao;
	 * private List<Recebimento> listRecebimento;
	 * private Set<ItemCotacao> listItem;
	 * private List<ClausulaCotacao> listClausulaCotacao;
	 * private List<NotaCotacao> listNotaCotacao;
	 * ItemCotacao
	 * private List<ItemAeronave> listItemAeronave;
	 * private List<ItemBeneficiario> listItemBeneficiario;
	 * private List<ItemClasseMercadoria> listItemClasseMercadoria;
	 * private List<ItemCossegurado> listItemCossegurado;
	 * private List<ItemDadosObra> listItemDadosObra;
	 * private Set<ItemDistribuicao> listItemDistribuicao;
	 * private List<ItemEmbarcacao> listItemEmbarcacao;
	 * private List<ItemEmbarque> listItemEmbarque;
	 * private List<ItemInspecao> listItemInspecao;
	 * private List<ItemNota> listItemNota;
	 * private List<ItemOutroSeguro> listItemOutroSeguro;
	 * private List<ItemPiloto> listItemPiloto;
	 * private List<ItemQBR> listItemQBR;
	 * private List<ItemRelacaoBem> listItemRelacaoBem;
	 * private List<ItemRelacaoEndereco> listItemRelacaoEndereco;
	 * private Set<ItemSistemaProtecional> listItemSistemaProtecional;
	 * private Set<ItemCobertura> listItemCobertura;
	 * private List<ClausulaItem> listClausulaItem;
	 * ItemCobertura
	 * private List<ClausulaItemCobertura> listaClausulaItemCobertura;
	 * private List<ItemCoberturaFranquia> listItemCoberturaFranquia;
	 */

}
