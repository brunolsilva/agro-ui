package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import br.com.tokiomarine.ctpj.cotacao.service.CalculaSublimiteService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCoberturaLimiteIs;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoISEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.CoberturaService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

public class BaseCoberturaValidator {
	
	private static Logger logger = LogManager.getLogger(BaseCoberturaValidator.class);
	
	@Autowired
	private CoberturaService coberturaService;

	@Autowired
	private CalculaSublimiteService calculaSublimiteService;
	
	public BaseCoberturaValidator() {
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}

	protected void validaCoberturaCoberturaAvulsa(ItemCobertura itemCobertura, List<ValidacaoLote> listaValidacao, int numeroItem) {
		
		if(itemCobertura.getIdCoberturaAvulsa() != null && itemCobertura.getIdCoberturaAvulsa() == SimNaoEnum.NAO) {
			return;
		}
		
		if(StringUtils.isEmpty(itemCobertura.getDescricaoCobertura())) {
			return;
		}
		
		if(itemCobertura.getPercentualTaxaCalculoPremio() == null) {
			listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar a Taxa da Cobertura Avulsa"));
		}
	}
	
	public void validaValoresCoberturaDM(
			ItemCobertura itemCobertura,
			MoedaEnum moeda,
			List<ValidacaoLote> listaValidacao,
			Integer numeroItem) {

		if(itemCobertura.isExigeVagasGaragem() && (itemCobertura.getNumeroVagasGaragem() == null || itemCobertura.getNumeroVagasGaragem() <= 0)) {
			listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o número de vagas na garagem da cobertura " + itemCobertura.getDescricaoCobertura()));
		}

		if(itemCobertura.isExigePeriodoIndenitario() && itemCobertura.getCodigoPeriodoIndenitario() == null) {
			listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o período indenitário da cobertura " + itemCobertura.getDescricaoCobertura(), 1));
		}

		listaValidacao.addAll(validaIS(itemCobertura, moeda, numeroItem));

		if(listaValidacao.isEmpty()) {
			if(moeda == MoedaEnum.REAL) {
				if(itemCobertura.getValorRiscoBem() == null && itemCobertura.isExigeValorRisco()) {
					if(itemCobertura.getPerfilCalculoCoberturaLimiteIs() != null && itemCobertura.getPerfilCalculoCoberturaLimiteIs().getVlLmiMaxExigeValorRisco() != null && BigDecimalUtil.maior(itemCobertura.getValorImportanciaSegurada(),itemCobertura.getPerfilCalculoCoberturaLimiteIs().getVlLmiMaxExigeValorRisco())) {
						listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o Valor em Risco da cobertura " + itemCobertura.getDescricaoCobertura()));
					}
				} else if(itemCobertura.isExigeValorRisco() && BigDecimalUtil.safeMenor(itemCobertura.getValorRiscoBem(),itemCobertura.getValorImportanciaSegurada())) {
					listaValidacao.add(new ValidacaoLote(numeroItem, "O valor em risco não pode ser menor que o LMI da cobertura " + itemCobertura.getDescricaoCobertura()));
				}
			} else {
				if(itemCobertura.getValorRiscoBemMoedaEstrangeira() == null && itemCobertura.isExigeValorRisco()) {
					if(itemCobertura.getPerfilCalculoCoberturaLimiteIs().getVlLmiMaxExigeValorRisco() != null && BigDecimalUtil.maior(itemCobertura.getValorISMoedaEstrangeira(),itemCobertura.getPerfilCalculoCoberturaLimiteIs().getVlLmiMaxExigeValorRisco())) {
						listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o Valor em Risco da cobertura " + itemCobertura.getDescricaoCobertura()));
					}
				} else if(itemCobertura.isExigeValorRisco() && BigDecimalUtil.safeMenor(itemCobertura.getValorRiscoBemMoedaEstrangeira(),itemCobertura.getValorISMoedaEstrangeira())) {
					listaValidacao.add(new ValidacaoLote(numeroItem, "O valor em risco não pode ser menor que o LMI da cobertura " + itemCobertura.getDescricaoCobertura()));
				}
			}
		}
	}

	private List<ValidacaoLote> validaIS(ItemCobertura itemCobertura, MoedaEnum moeda, Integer numeroItem) {
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		if(moeda == MoedaEnum.REAL) {
			if(itemCobertura.getValorImportanciaSegurada() == null && itemCobertura.getTipoIS() == TipoISEnum.INFORMADA_PELO_USUARIO) {
				listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o LMI da Cobertura " + itemCobertura.getDescricaoCobertura(), 1));
			}
		} else {
			if(itemCobertura.getValorISMoedaEstrangeira() == null && itemCobertura.getTipoIS() == TipoISEnum.INFORMADA_PELO_USUARIO) {
				listaValidacao.add(new ValidacaoLote(numeroItem, "Obrigatório informar o LMI da Cobertura " + itemCobertura.getDescricaoCobertura(), 1));
			}
		}

		if(itemCobertura.getTipoIS() == TipoISEnum.INFORMADA_PELO_USUARIO && listaValidacao.isEmpty() && itemCobertura.isFormaLimiteIS()) {
			listaValidacao.addAll(validaLimiteIS(itemCobertura.getItemCotacao().getCotacao(),itemCobertura,moeda,numeroItem));
		}

		return listaValidacao;
	}

	public List<ValidacaoLote> validaLimiteIS(Cotacao cotacao, ItemCobertura itemCobertura, MoedaEnum moeda,
			Integer numeroItem) {

		PerfilCalculoCoberturaLimiteIs perfilCalculoCoberturaLimiteIs = itemCobertura.getPerfilCalculoCoberturaLimiteIs();
		System.out.println("00 " + perfilCalculoCoberturaLimiteIs);
		
		if(cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO 
				&& !TipoEndossoEnum.isItemAlteracaoInclusao(itemCobertura.getItemCotacao().getIdTipoEndosso(), cotacao.getIdLmiUnico().getLogical())) {
			return Collections.<ValidacaoLote>emptyList();
		}

		if(perfilCalculoCoberturaLimiteIs != null) {
			ItemCobertura coberturaPrincipal = itemCobertura.getItemCotacao().getListItemCobertura().stream()
					.filter(it -> it.getCodigoCobertura().equals(itemCobertura.getCoberturaPrincipal()))
					.findAny()
					.orElse(null);

			if(coberturaPrincipal == null) {
				return Collections.singletonList(new ValidacaoLote(numeroItem, "É necessário contratar a cobertura " + coberturaService.findCobertura(itemCobertura.getCoberturaPrincipal()).getDescricao()));
			}

			/**
			 *  Se o PerfilCalculoCoberturaLimiteIs tiver um tipo de cobertura, a cobertura principal para calculo
			 *  será sobrescrita até chegar ao id do tipo de cobertura que está no PerfilCalculoCoberturaLimiteIs.
			 */
			if (perfilCalculoCoberturaLimiteIs.getTipoCobertura() != null) {
				Integer nivelCoberturaPrincipal = coberturaPrincipal.getIdTipoCobertura();
				Integer nivelCoberturaPerfilCalculo = perfilCalculoCoberturaLimiteIs.getTipoCobertura().getId();
				while (nivelCoberturaPrincipal > nivelCoberturaPerfilCalculo) {
					for (ItemCobertura itemCoberturaPrincipal : coberturaPrincipal.getItemCotacao().getListItemCobertura()) {
						if (itemCoberturaPrincipal.getCodigoCobertura().equals(coberturaPrincipal.getCoberturaPrincipal())) {
							coberturaPrincipal = itemCoberturaPrincipal;
							nivelCoberturaPrincipal--;
						}
					}
				}
			}

			BigDecimal percentualLimiteCobertura = perfilCalculoCoberturaLimiteIs.getPercentualLimiteCobertura();
			BigDecimal valorMaximoIS = perfilCalculoCoberturaLimiteIs.getValorMaximoIS();
			BigDecimal valorMinimoIS = perfilCalculoCoberturaLimiteIs.getValorMinimoIS();

			if(valorMaximoIS != null && itemCobertura.getValorImportanciaSegurada() != null) {
				if(BigDecimalUtil.maior(itemCobertura.getValorImportanciaSegurada(),valorMaximoIS) && itemCobertura.getIdExclusaEndosso() == SimNaoEnum.NAO) {
					itemCobertura.setValorImportanciaSegurada(valorMaximoIS);
					itemCobertura.setDescricaoCoberturaAjustada(
							String.format("A contratação da cobertura %s,<br> está limitada a %s%% da cobertura <br>%s<br> com o mínimo de R$%s e o máximo de R$%s",
							itemCobertura.getDescricaoCobertura(),
							percentualLimiteCobertura,
							coberturaPrincipal.getDescricaoCobertura(),
							BigDecimalUtil.formatBigDecimal(valorMinimoIS,2),
							BigDecimalUtil.formatBigDecimal(valorMaximoIS,2)
					));
					calculaSublimiteService.populaValorSublimiteOriginal(itemCobertura, moeda, cotacao.getCoeficienteConversaoMoeda());
				}
			}

			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
				if(valorMinimoIS != null && itemCobertura.getValorImportanciaSegurada() != null) {
					if(BigDecimalUtil.menor(itemCobertura.getValorImportanciaSegurada(),valorMinimoIS) && itemCobertura.getIdExclusaEndosso() == SimNaoEnum.NAO) {
						itemCobertura.setValorImportanciaSegurada(valorMinimoIS);
						itemCobertura.setDescricaoCoberturaAjustada(
								String.format("A contratação da cobertura %s,<br> está limitada a %s%% da cobertura <br>%s<br> com o mínimo de R$%s e o máximo de R$%s",
								itemCobertura.getDescricaoCobertura(),
								percentualLimiteCobertura,
								coberturaPrincipal.getDescricaoCobertura(),
								BigDecimalUtil.formatBigDecimal(valorMinimoIS,2),
								BigDecimalUtil.formatBigDecimal(valorMaximoIS,2)
						));
						calculaSublimiteService.populaValorSublimiteOriginal(itemCobertura, moeda, cotacao.getCoeficienteConversaoMoeda());
					}
				}
			}

			if(cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
				if(percentualLimiteCobertura != null) {
					BigDecimal valorMaximo = valorMaximoIS(coberturaPrincipal.getValorImportanciaSegurada(), percentualLimiteCobertura);
					if(BigDecimalUtil.maior(itemCobertura.getValorImportanciaSegurada(), valorMaximo) && itemCobertura.getIdExclusaEndosso() == SimNaoEnum.NAO) {
						itemCobertura.setValorImportanciaSegurada(valorMaximo);
						itemCobertura.setDescricaoCoberturaAjustada(
								String.format("A contratação da cobertura %s,<br> está limitada a %s%% da cobertura <br>%s<br> com o mínimo de R$%s e o máximo de R$%s",
								itemCobertura.getDescricaoCobertura(),
								percentualLimiteCobertura,
								coberturaPrincipal.getDescricaoCobertura(),
								BigDecimalUtil.formatBigDecimal(valorMinimoIS,2),
								BigDecimalUtil.formatBigDecimal(valorMaximoIS,2)
						));
						calculaSublimiteService.populaValorSublimiteOriginal(itemCobertura, moeda, cotacao.getCoeficienteConversaoMoeda());
					}
				}
			}
		}
		return Collections.<ValidacaoLote>emptyList();
	}

	private BigDecimal valorMaximoIS(BigDecimal valorISPrincipal, BigDecimal percentualLimiteCobertura) {
		return valorISPrincipal != null ? valorISPrincipal.multiply(percentualLimiteCobertura, MathContext.DECIMAL128).divide(BigDecimal.valueOf(100L)) : BigDecimal.ZERO;
	}
}