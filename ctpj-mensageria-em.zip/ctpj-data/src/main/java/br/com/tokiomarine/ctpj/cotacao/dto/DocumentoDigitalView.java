package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentoDigitalView implements Serializable {

	private static final long serialVersionUID = -8002270649999175233L;

	private Integer formaEnvio;
	private Integer destino;
	private String emailCorretor;
	private SimNaoEnum idEnvioSegurado;
	private String emailSegurado;

	public Integer getFormaEnvio() {
		return formaEnvio;
	}

	public void setFormaEnvio(Integer formaEnvio) {
		this.formaEnvio = formaEnvio;
	}

	public Integer getDestino() {
		return destino;
	}

	public void setDestino(Integer destino) {
		this.destino = destino;
	}

	public String getEmailCorretor() {
		return emailCorretor;
	}

	public void setEmailCorretor(String emailCorretor) {
		this.emailCorretor = emailCorretor;
	}

	public SimNaoEnum getIdEnvioSegurado() {
		return idEnvioSegurado;
	}

	public void setIdEnvioSegurado(SimNaoEnum idEnvioSegurado) {
		this.idEnvioSegurado = idEnvioSegurado;
	}

	public String getEmailSegurado() {
		return emailSegurado;
	}

	public void setEmailSegurado(String emailSegurado) {
		this.emailSegurado = emailSegurado;
	}	
}