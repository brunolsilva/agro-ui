package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.ControleFichaRegistradaRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ControleFichaRegistrada;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;

@Service
@Transactional
public class ControleFichaRegistradaService {

	private static Logger logger = LogManager.getLogger(ControleFichaRegistradaService.class);

	@Autowired
	private ControleFichaRegistradaRepository repository;


	public ControleFichaRegistrada save(ControleFichaRegistrada controleFichaRegistrada) throws ServiceException {
		try {
			return repository.save(controleFichaRegistrada);
		} catch (HibernateException h) {
			logger.error("Erro ao Gravar ControleFichaRegistrada");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Gravar ControleFichaRegistrada");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public void update(ControleFichaRegistrada controleFichaRegistrada) throws ServiceException {
		try {
			repository.update(controleFichaRegistrada);
		} catch (HibernateException h) {
			logger.error("Erro ao Atualizar ControleFichaRegistrada");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Atualizar ControleFichaRegistrada");
			throw new ServiceException(e.getMessage(),e);
		}

	}

	public void merge(ControleFichaRegistrada controleFichaRegistrada) throws ServiceException {
		try {
			repository.merge(controleFichaRegistrada);
		} catch (HibernateException h) {
			logger.error("Erro ao Atualizar ControleFichaRegistrada");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Atualizar ControleFichaRegistrada");
			throw new ServiceException(e.getMessage(),e);
		}

	}

	public ControleFichaRegistrada getControleFichaRegistradaBySequencialCotacaoProposta(Cotacao cotacao,User user) throws ServiceException {
		try {			
			
			ControleFichaRegistrada c = repository.getControleFichaRegistradaBySequencialCotacaoProposta(cotacao.getSequencialCotacaoProposta());
			if(c == null){
				c = new ControleFichaRegistrada();
				c.setCotacao(cotacao);
				c.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
				c.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
				c.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
				c.setDataAtualizacao(new Date());
				c.setCodigoGrupo(cotacao.getCodigoGrupo());
				c = this.save(c);
			}
			
			return c;
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar ControleFichaRegistrada",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Gravar Buscar ControleFichaRegistrada",e);
			throw new ServiceException(e.getMessage(),e);
		}

	}

	public ControleFichaRegistrada getControleFichaRegistradaBySequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) throws ServiceException {
		return repository.getControleFichaRegistradaBySequencialCotacaoProposta(sequencialCotacaoProposta);
	}

}
