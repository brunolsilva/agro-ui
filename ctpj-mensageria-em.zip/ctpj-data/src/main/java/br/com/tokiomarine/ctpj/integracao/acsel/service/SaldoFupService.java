package br.com.tokiomarine.ctpj.integracao.acsel.service;

import java.net.URI;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.integracao.acsel.request.SaldoFupRequest;
import br.com.tokiomarine.ctpj.integracao.acsel.response.SaldoFupResponse;
import br.com.tokiomarine.ctpj.integracao.service.EndpointBuilderService;
import br.com.tokiomarine.ctpj.type.ServicosAcselEnum;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Service
public class SaldoFupService {
	private static Logger logger = LogManager.getLogger(SaldoFupService.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private EndpointBuilderService endpointBuilderService;
	
	/**
	 * Busca o saldo fup no Acsel
	 * 
	 * @param request
	 * @return
	 * @throws ServiceException
	 */
	@LogPerformance
	public SaldoFupResponse find(SaldoFupRequest request) throws ServiceException {
		try {
			URI uri = endpointBuilderService.obterUri(ParametroGeralEnum.getParametroServicoAcselWs(),ServicosAcselEnum.OBTER_SALDO_FUP);
			logger.info("Url obter saldo FUP (Acsel): "+uri);
			logger.info("Request obter saldo FUP (Acsel): "+JacksonDatabindUtil.getInstance().bindObjectToJson(request));
			SaldoFupResponse response = restTemplate.postForObject(uri, request, SaldoFupResponse.class);
			logger.info("Response obter saldo FUP (Acsel): "+JacksonDatabindUtil.getInstance().bindObjectToJson(response));
			return response;
		} catch (Exception e) {
			logger.error("Erro na chamada do serviço obter saldo fup do acsel ", e);
			throw new ServiceException(e);
		}
	}
	
	/**
	 * Retorna mensagem de erro amigável para o usuário
	 * @param codigo
	 * @return
	 */
	public String tratarMensagem(SaldoFupResponse response) {
		/**
		 * o serviço do acsel possui os seguintes retornos:
		 * 
		 * cRetcode  := '00' - cMensagem := 'Consulta Efetuada com Sucesso';
		 * cRetcode  := '01' - cMensagem := 'Não foi encontrado Título ativo em FUP. Ramo: ...
		 * cRetcode  := '02' - cMensagem := 'Erro ao Consultar. Ramo:...
		 * cRetCode  := '03' - cMensagem := 'Obrigatório informar Ramo e Número da Apólice';
		 * cRetCode  := '04' - cMensagem := sqlcode || ' ' || sqlerrm; (retorna o erro da base de dados) 
		 */
		
		//se o retorno e o código de retorno não forem nulos, valida o tipo de código e retorna a mensagem correspondente
		if(response != null && !StringUtils.isEmpty(response.getRetCode())) {
			Integer codigo = Integer.valueOf(response.getRetCode());
			if(codigo.equals(1)) {
				return "Não foi encontrado título ativo para os dados informados";
			}
			
			if(codigo.equals(3)) {
				return "Obrigatório informar o ramo e número da apólice";
			}			
		}

		return "Ocorreu um erro ao consultar os dados informados";
	}
}
