package br.com.tokiomarine.ctpj.dao;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.tokiomarine.ctpj.exception.HibernateException;

public class BaseDAO {

	private static Logger logger = LogManager.getLogger(BaseDAO.class);
	
	protected static final String P_MENS = "p_mens";

	@Autowired
	protected SessionFactory sessionFactory;

	protected Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public BaseDAO() {}

	public void evict(Object domain) {
		getCurrentSession().evict(domain);
	}
	
	public void validaRetornoDaProcedure(String procedureReturn) throws HibernateException {

		if (procedureReturn != null && procedureReturn.length() > 0) {
			logger.info("P_MENS: " + procedureReturn);
			throw new HibernateException(procedureReturn);
		}

    }
	
}
