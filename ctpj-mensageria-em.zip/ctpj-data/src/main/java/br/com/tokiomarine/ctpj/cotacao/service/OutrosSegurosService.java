package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.OutrosSegurosRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.service.CotacaoDolarService;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class OutrosSegurosService {

	@Autowired
	private OutrosSegurosRepository outrosSegurosRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private CotacaoDolarService cotacaoDolarService;

	public List<ItemOutroSeguro> list(BigInteger cotacao) {
		return outrosSegurosRepository.find(cotacao);
	}

	public ItemOutroSeguro save(ItemOutroSeguro outroSeguro) throws RepositoryException {
		ItemCotacao itemCotacao = cotacaoRepository.findItem(outroSeguro.getItemCotacao().getSequencialItemCotacao());
		Integer lastSequencialControle = outrosSegurosRepository.geraSequencialControle(itemCotacao.getSequencialItemCotacao());
		if(lastSequencialControle == null) {
			outroSeguro.setSequencialItemOutroControle(1);
		} else {
			outroSeguro.setSequencialItemOutroControle(lastSequencialControle + 1);
		}

		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		outroSeguro.setDataAtualizacao(new Date());
		outroSeguro.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		outroSeguro.setUsuarioAtualizacao(user.getCdUsuro().longValue());

		outroSeguro.setNumeroCotacaoProposta(itemCotacao.getNumeroCotacaoProposta());
		outroSeguro.setVersaoCotacaoProposta(itemCotacao.getVersaoCotacaoProposta());
		outroSeguro.setItemCotacao(itemCotacao);

		if(outroSeguro.getValorLMG() != null) {
			itemCotacao.setValorRiscoBem(itemCotacao.getValorRiscoBem().add(outroSeguro.getValorLMG()));
		}

		try{
			cotacaoDolarService.ajusteOutrosSegurosLMGMoedaEstrangeira(outroSeguro);
		}catch (Exception e) {
			throw new RepositoryException(e.getMessage(),e);
		}
		
		return outrosSegurosRepository.save(outroSeguro);
	}

	public void delete(BigInteger outroSeguro) {
		outrosSegurosRepository.delete(outroSeguro);
	}
}
