package br.com.tokiomarine.ctpj.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CorretorApoliceDigital implements Serializable {

	private static final long serialVersionUID = -3399122507801299254L;

	@JsonProperty("CD_CRTOR")
	private Integer corretor;
	@JsonProperty("IC_APOLI_DIGTL")
	private String idApoliceDigital;
	@JsonProperty("EMAIL")
	private String email;

	public Integer getCorretor() {
		return corretor;
	}

	public void setCorretor(Integer corretor) {
		this.corretor = corretor;
	}

	public String getIdApoliceDigital() {
		return idApoliceDigital;
	}

	public void setIdApoliceDigital(String idApoliceDigital) {
		this.idApoliceDigital = idApoliceDigital;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "CorretorApoliceDigital [corretor=" + corretor + ", idApoliceDigital=" + idApoliceDigital + ", email="
				+ email + "]";
	}
}