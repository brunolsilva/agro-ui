package br.com.tokiomarine.ctpj.cotacao.dto;

/**
 * Representa a entidade Cláusula na camada de View
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class ClausulaView {

	private Integer codigoGrupoRamo;
	private Integer codigoRamo;
	private Integer codigoClausulaNota;
	private String descricao;
	private String descricaoOriginal;
	private Integer valorCaracteristica;
	private boolean imprimir;
	private boolean selecionado;
	
	public ClausulaView(){
		
	}

	public ClausulaView(Integer codigoGrupoRamo, Integer codigoRamo, Integer codigoClausulaNota, String descricao) {
		super();
		this.codigoGrupoRamo = codigoGrupoRamo;
		this.codigoRamo = codigoRamo;
		this.codigoClausulaNota = codigoClausulaNota;
		this.descricao = descricao;
	}

	public Integer getCodigoGrupoRamo() {
		return codigoGrupoRamo;
	}

	public void setCodigoGrupoRamo(Integer codigoGrupoRamo) {
		this.codigoGrupoRamo = codigoGrupoRamo;
	}

	public Integer getCodigoRamo() {
		return codigoRamo;
	}

	public void setCodigoRamo(Integer codigoRamo) {
		this.codigoRamo = codigoRamo;
	}

	public Integer getCodigoClausulaNota() {
		return codigoClausulaNota;
	}

	public void setCodigoClausulaNota(Integer codigoClausulaNota) {
		this.codigoClausulaNota = codigoClausulaNota;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public Integer getValorCaracteristica() {
		return valorCaracteristica;
	}

	public void setValorCaracteristica(Integer valorCaracteristica) {
		this.valorCaracteristica = valorCaracteristica;
	}

	public String getDescricaoOriginal() {
		return descricaoOriginal;
	}

	public void setDescricaoOriginal(String descricaoOriginal) {
		this.descricaoOriginal = descricaoOriginal;
	}

	public boolean isImprimir() {
		return imprimir;
	}

	public void setImprimir(boolean imprimir) {
		this.imprimir = imprimir;
	}	

}
