package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.MongoRegexCreator;
import org.springframework.data.repository.query.parser.Part;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.CaracteristicaValor;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;

@Repository
public class CaracteristicaValorRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public List<CaracteristicaValor> findListCaracValorByCaracAndValorCarac(Integer caracteristica, List<Integer>valoresCaracteristica, Sort sort){
		return mongoTemplate.find(
				query(
						where("caracteristica").is(caracteristica)
						.and("valorCaracteristica").in(valoresCaracteristica))
				.with(sort)
				,CaracteristicaValor.class);
	}
	
	public List<CaracteristicaValor> findListCaracValorByCaracAndValorCarac(Integer caracteristica, List<Integer>valoresCaracteristica, String q){
		return mongoTemplate.find(
				query(
						where("caracteristica").is(caracteristica)
						.and("valorCaracteristica").in(valoresCaracteristica)
						.and("descricaoValor").regex(MongoRegexCreator.INSTANCE.toRegularExpression(q, Part.Type.EXISTS), "i"))
				.with(new Sort(Direction.ASC,"descricaoValor"))
				,CaracteristicaValor.class);
	}

	public CaracteristicaValor findCaracteristicaValorByCaracAndValorCarac(Integer caracteristica, Long valorCaracteristica){
		return (CaracteristicaValor) mongoTemplate.findOne(
				query(
						where("caracteristica").is(caracteristica)
						.and("valorCaracteristica").is(valorCaracteristica))
				,CaracteristicaValor.class);
	}

	public CaracteristicaValor findCaracteristicaValorByCaracAndValorCarac(Integer caracteristica, Integer  valorCaracteristica){
		return (CaracteristicaValor) mongoTemplate.findOne(
				query(
						where("caracteristica").is(caracteristica)
						.and("valorCaracteristica").is(valorCaracteristica))
				,CaracteristicaValor.class);
	}

	public Map<Integer, ProdutoCaracteristica> findCaracteristicaDoProduto(Integer produto, Date dataCotacao){
		List<ProdutoCaracteristica> caracteristicasDoProduto = mongoTemplate.find(
				query(
						where("produto").is(produto)
						.and("dataInicioVigencia").lte(dataCotacao)
						.orOperator(
								where("dataTerminoVigencia").gte(dataCotacao),
								where("dataTerminoVigencia").is(null))
						), ProdutoCaracteristica.class);
		return caracteristicasDoProduto
				.stream()
				.collect(
						Collectors.toMap(ProdutoCaracteristica::getCaracteristica, Function.identity()));
	}
}
