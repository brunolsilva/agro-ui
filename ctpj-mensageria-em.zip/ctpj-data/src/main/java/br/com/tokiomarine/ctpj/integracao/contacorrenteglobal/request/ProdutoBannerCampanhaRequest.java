package br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request;

import java.io.Serializable;

public class ProdutoBannerCampanhaRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8279275320861468349L;
    private Long codigoProduto;
    private Long numeroRamo;

	public Long getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(Long codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public Long getNumeroRamo() {
		return numeroRamo;
	}

	public void setNumeroRamo(Long numeroRamo) {
		this.numeroRamo = numeroRamo;
	}
}
