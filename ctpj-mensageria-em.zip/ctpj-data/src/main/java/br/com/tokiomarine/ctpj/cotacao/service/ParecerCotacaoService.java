package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.ParecerView;
import br.com.tokiomarine.ctpj.cotacao.repository.ParecerCotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ParecerCotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.ParecerViewMapper;
import br.com.tokiomarine.ctpj.util.StringUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class ParecerCotacaoService {

	private static Logger logger = LogManager.getLogger(ParecerCotacaoService.class);
	
	@Autowired
	private ParecerCotacaoRepository parecerCotacaoRepository;

	@LogPerformance
	public List<ParecerView> getListParecerView(Cotacao cotacao) throws ServiceException {

		List<ParecerView> pereceresView = new ArrayList<ParecerView>();

		try {
			if (cotacao.getPareceresCotacao() != null && !cotacao.getPareceresCotacao().isEmpty()) {
				pereceresView = ParecerViewMapper.INSTANCE.toPareceresView(cotacao.getPareceresCotacao());
			}
		} catch (Exception e) {
			logger.error("Erro ao fazer bind para ParecerView",e);
			throw new ServiceException(e.getMessage(),e.getCause());
		}
		
		return pereceresView;
		
	}
	
	@LogPerformance
	public void saveParecer(ParecerView parecerView) throws ServiceException {
		try {
			ParecerCotacao parecerCotacao =  ParecerViewMapper.INSTANCE.toParecerCotacao(parecerView);
			parecerCotacao.setDescricaoParecer(StringUtils.substring(StringUtil.replaceAspas(parecerView.getDescricaoParecer()), 0, 40000));
			Cotacao cotacao = new Cotacao();
			cotacao.setSequencialCotacaoProposta(parecerView.getSequencialCotacaoProposta());
			parecerCotacao.setNumeroCotacaoProposta(parecerView.getNumeroCotacaoProposta());
			parecerCotacao.setVersaoCotacaoProposta(parecerView.getVersaoCotacaoProposta());
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			parecerCotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			parecerCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			parecerCotacao.setCotacao(cotacao);
			parecerCotacaoRepository.saveParecerCotacao(parecerCotacao);
		} catch (HibernateException h) {
			logger.error("Erro ao salvar Parecer ",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao salvar Parecer ",e);
			throw new ServiceException("Erro geral ao  Salvar Cotacao Log ",e);
		}
		
	}
	
	@LogPerformance
	public void deleteParecerCotacao(BigInteger sequencialParecerCotacao) throws ServiceException{
		try {
			parecerCotacaoRepository.deleteParecerCotacao(sequencialParecerCotacao);
		} catch (HibernateException h) {
			logger.error("Erro ao salvar Parecer ",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao salvar Parecer ",e);
			throw new ServiceException("Erro geral ao  Salvar Cotacao Log ",e);
		}
	}

}
