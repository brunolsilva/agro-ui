package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ServicoCotacao;

@Repository
public class ServicoCotacaoRepository extends BaseDAO {

	public void delete(BigInteger cotacao) {
		List<ServicoCotacao> listServicoCotacao = list(cotacao);
		for(ServicoCotacao op: listServicoCotacao) {
			getCurrentSession().delete(op);
		}

		getCurrentSession().flush();
	}
	
	@SuppressWarnings("unchecked")
	public List<ServicoCotacao> list(BigInteger sequencialCotacaoProposta) {
		return (List<ServicoCotacao>) getCurrentSession()
				.createQuery("select os from ServicoCotacao os where os.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta")
				.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta)
				.list();
	}

	public void saveList(List<ServicoCotacao> listServicoCotacao) {
		for (ServicoCotacao servicoCotacao : listServicoCotacao) {
			getCurrentSession().save(servicoCotacao);
		}
	}
	
}
