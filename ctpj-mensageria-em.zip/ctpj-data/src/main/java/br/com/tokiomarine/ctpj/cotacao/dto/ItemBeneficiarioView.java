package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

import br.com.tokiomarine.ctpj.cotacao.validator.constraint.ItemBeneficiarioViewValido;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@ItemBeneficiarioViewValido
public class ItemBeneficiarioView {

	private BigInteger sequencialItemBeneficiario;
	//@NotNull(message="Item da Cotação é obrigatório")	
	private BigInteger itemCotacao;
	private BigInteger numeroItemCotacao;
	private String tipoPessoa;
	private String numeroCPFCNPJ;
	//@NotBlank(message="Nome da Pessoa é obrigatório")
	//@Length(max = 300,message = "Nome da Pessoa deve possuir no máximo 300 caracteres")
	private String nomePessoa;
	//@Max(value=100, message="Percentual de Distrubuição não pode ultrapassar 100%")
	private BigDecimal percentualDistribuicao;
	private BigDecimal valorDistribuicao;
	//@Length(max=2000, message="Complemento deve possuir no máximo 2000 caracteres")
	private String descricaoComplemento;
	private BigInteger numeroBeneficiario;

	public ItemBeneficiarioView(){
		
	}
	
	public ItemBeneficiarioView(BigInteger sequencialItemBeneficiario, BigInteger itemCotacao, BigInteger numeroItemCotacao,  String tipoPessoa, String numeroCPFCNPJ, String nomePessoa,
			BigDecimal percentualDistribuicao, BigDecimal valorDistribuicao, String descricaoComplemento, BigInteger numeroBeneficiario) {
		super();
		this.sequencialItemBeneficiario = sequencialItemBeneficiario;
		this.itemCotacao = itemCotacao;
		this.numeroItemCotacao = numeroItemCotacao;
		this.tipoPessoa = tipoPessoa;
		this.numeroCPFCNPJ = numeroCPFCNPJ;
		this.nomePessoa = nomePessoa;
		this.percentualDistribuicao = percentualDistribuicao;
		this.valorDistribuicao = valorDistribuicao;
		this.descricaoComplemento = descricaoComplemento;
		this.numeroBeneficiario = numeroBeneficiario;
	}

	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public BigInteger getSequencialItemBeneficiario() {
		return sequencialItemBeneficiario;
	}

	public void setSequencialItemBeneficiario(BigInteger sequencialItemBeneficiario) {
		this.sequencialItemBeneficiario = sequencialItemBeneficiario;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public BigInteger getNumeroItemCotacao() {
		return numeroItemCotacao;
	}

	public void setNumeroItemCotacao(BigInteger numeroItemCotacao) {
		this.numeroItemCotacao = numeroItemCotacao;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public String getNumeroCPFCNPJ() {
		return numeroCPFCNPJ;
	}

	public void setNumeroCPFCNPJ(String numeroCPFCNPJ) {
		this.numeroCPFCNPJ = numeroCPFCNPJ;
	}

	public String getNomePessoa() {
		return nomePessoa;
	}

	public void setNomePessoa(String nomePessoa) {
		this.nomePessoa = nomePessoa;
	}

	public BigDecimal getPercentualDistribuicao() {
		return percentualDistribuicao;
	}

	public void setPercentualDistribuicao(BigDecimal percentualDistribuicao) {
		this.percentualDistribuicao = percentualDistribuicao;
	}

	public BigDecimal getValorDistribuicao() {
		return valorDistribuicao;
	}

	public void setValorDistribuicao(BigDecimal valorDistribuicao) {
		this.valorDistribuicao = valorDistribuicao;
	}

	public String getDescricaoComplemento() {
		return descricaoComplemento;
	}

	public void setDescricaoComplemento(String descricaoComplemento) {
		this.descricaoComplemento = descricaoComplemento;
	}	

	public BigInteger getNumeroBeneficiario() {
		return numeroBeneficiario;
	}

	public void setNumeroBeneficiario(BigInteger numeroBeneficiario) {
		this.numeroBeneficiario = numeroBeneficiario;
	}

	@Override
	public String toString() {
		return "ItemBeneficiarioView [itemCotacao=" + itemCotacao + ", tipoPessoa=" + tipoPessoa + ", numeroCPFCNPJ="
				+ numeroCPFCNPJ + ", nomePessoa=" + nomePessoa + ", percentualDistribuicao=" + percentualDistribuicao
				+ ", valorDistribuicao=" + valorDistribuicao + ", descricaoComplemento=" + descricaoComplemento + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descricaoComplemento == null) ? 0 : descricaoComplemento.hashCode());
		result = prime * result + ((itemCotacao == null) ? 0 : itemCotacao.hashCode());
		result = prime * result + ((nomePessoa == null) ? 0 : nomePessoa.hashCode());
		result = prime * result + ((numeroCPFCNPJ == null) ? 0 : numeroCPFCNPJ.hashCode());
		result = prime * result + ((percentualDistribuicao == null) ? 0 : percentualDistribuicao.hashCode());
		result = prime * result + ((tipoPessoa == null) ? 0 : tipoPessoa.hashCode());
		result = prime * result + ((valorDistribuicao == null) ? 0 : valorDistribuicao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemBeneficiarioView other = (ItemBeneficiarioView) obj;
		if (descricaoComplemento == null) {
			if (other.descricaoComplemento != null)
				return false;
		} else if (!descricaoComplemento.equals(other.descricaoComplemento))
			return false;
		if (itemCotacao == null) {
			if (other.itemCotacao != null)
				return false;
		} else if (!itemCotacao.equals(other.itemCotacao))
			return false;
		if (nomePessoa == null) {
			if (other.nomePessoa != null)
				return false;
		} else if (!nomePessoa.equals(other.nomePessoa))
			return false;
		if (numeroCPFCNPJ == null) {
			if (other.numeroCPFCNPJ != null)
				return false;
		} else if (!numeroCPFCNPJ.equals(other.numeroCPFCNPJ))
			return false;
		if (percentualDistribuicao == null) {
			if (other.percentualDistribuicao != null)
				return false;
		} else if (!percentualDistribuicao.equals(other.percentualDistribuicao))
			return false;
		if (tipoPessoa == null) {
			if (other.tipoPessoa != null)
				return false;
		} else if (!tipoPessoa.equals(other.tipoPessoa))
			return false;
		if (valorDistribuicao == null) {
			if (other.valorDistribuicao != null)
				return false;
		} else if (!valorDistribuicao.equals(other.valorDistribuicao))
			return false;
		return true;
	}	

}
