package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CosseguroView;
import br.com.tokiomarine.ctpj.cotacao.repository.CosseguroRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.CosseguroMapper;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;

@Transactional(rollbackFor = {ServiceException.class})
@Service
public class CosseguroService {

	private static final Logger logger = LogManager.getLogger(CosseguroService.class);

	@Autowired
	private CosseguroRepository cosseguroRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;

	public List<CosseguroView> findCossegurosByCotacao(BigInteger cotacao) throws ServiceException {
		try {
			List<CosseguroCotacao> cosseguros = cosseguroRepository.findCossegurosByCotacao(cotacao);
			return CosseguroMapper.INSTANCE.toView(cosseguros);
		} catch (RepositoryException e) {
			logger.error("Erro ao buscar listagem de cosseguros ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	public void salvar(List<CosseguroView> cosseguros) throws ServiceException {
		try {

			Object[] cotacaoVersao = cotacaoRepository.getCotacaoVersaoMoeda(cosseguros.get(0).getSequencialCotacaoProposta());
			List<CosseguroCotacao> cossegurosSalvar = new ArrayList<>();

			/**
			 * Remove os cosseguros e insere novamente
			 */
			cosseguroRepository.deleteCosseguro(cosseguros.get(0).getSequencialCotacaoProposta());

			if(cosseguros.size() > 1) {
				for(CosseguroView cosseguro: cosseguros) {
					CosseguroCotacao cosseguroCotacao = new CosseguroCotacao();
					CotacaoViewMapper.INSTANCE.toCosseguroCotacao(cosseguro, cosseguroCotacao);
					cosseguroCotacao.setNumeroCotacaoProposta((BigInteger) cotacaoVersao[0]);
					cosseguroCotacao.setVersaoCotacaoProposta((Integer) cotacaoVersao[1]);
					Cotacao cotacao = new Cotacao();
					cotacao.setSequencialCotacaoProposta(cosseguros.get(0).getSequencialCotacaoProposta());
					cosseguroCotacao.setCotacao(cotacao);

					User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
					cosseguroCotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
					cosseguroCotacao.setDataAtualizacao(new Date());
					cosseguroCotacao.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
					
					cossegurosSalvar.add(cosseguroCotacao);
				}

				cosseguroRepository.salvar(cossegurosSalvar);
			}

		} catch (RepositoryException e) {
			logger.error("Erro ao salvar cosseguros ", e);
			throw new ServiceException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Erro ao salvar cosseguros ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
}