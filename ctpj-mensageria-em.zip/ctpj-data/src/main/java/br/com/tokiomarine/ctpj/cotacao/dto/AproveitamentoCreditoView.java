package br.com.tokiomarine.ctpj.cotacao.dto;

public class AproveitamentoCreditoView {

	private String banco;
	private String agencia;
	protected String valorCredito;
	private String idAproveitamentoCredito;

	public AproveitamentoCreditoView() {}

	public AproveitamentoCreditoView(String valorCredito,String idAproveitamentoCredito) {
		super();
		this.valorCredito = valorCredito;
		this.idAproveitamentoCredito = idAproveitamentoCredito;
	}

	public String getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(String valorCredito) {
		this.valorCredito = valorCredito;
	}

	public String getIdAproveitamentoCredito() {
		return idAproveitamentoCredito;
	}

	public void setIdAproveitamentoCredito(String idAproveitamentoCredito) {
		this.idAproveitamentoCredito = idAproveitamentoCredito;
	}

	@Override
	public String toString() {
		return "AproveitamentoCreditoView [valorCredito=" + valorCredito + ", idAproveitamentoCredito="
				+ idAproveitamentoCredito + "]";
	}

}
