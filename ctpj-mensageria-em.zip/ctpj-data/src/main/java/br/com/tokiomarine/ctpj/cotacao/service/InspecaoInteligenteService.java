package br.com.tokiomarine.ctpj.cotacao.service;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.InspecaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.ParecerInspecaoEnum;
import br.com.tokiomarine.ctpj.enums.SituacaoInspecaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.CancelamentoInspecaoInteligente;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.CancelamentoInspecaoInteligenteResponse;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.CoberturaInspecaoInteligente;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.ContatoInspecaoInteligente;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.DadosGeraisInspecaoInteligente;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.InspecaoInteligente;
import br.com.tokiomarine.ctpj.integracao.inspecaointeligente.dto.SolicitacaoInspecaoInteligenteResponse;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.util.DateUtil;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Service
@Transactional
public class InspecaoInteligenteService {

	private static Logger logger = LogManager.getLogger(InspecaoInteligenteService.class);

	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	InspecaoRepository inspecaoRepository;
	
	protected RestTemplate restTemplate = new RestTemplate();

	/*
	 * Processo utilizado para solicitar uma inspeção inteligente pelo CTPJ
	 */
	public ResultadoREST<Object> solicitaInspecaoInteligente(BigInteger sequencialItemInspecao,User user) throws ServiceException {
		ResultadoREST<Object> resultado = new ResultadoREST<>();
		resultado.setCodigo(1);
		try {
			String url = findUrlInspecaoInteligenteSolicitacao();
			Cotacao cotacao = cotacaoRepository.findCotacaoItemInspecaoBySeqItemInspecao(sequencialItemInspecao);
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				for (ItemInspecao itemInspecao : itemCotacao.getListItemInspecao()) {
					InspecaoInteligente ii = bindToInspecaoInteligente(cotacao,itemCotacao,itemInspecao,itemCotacao.getListItemCobertura());
					List<Validacao> validacaoList = validarCamposObrigatorios(ii);
					if(validacaoList != null && !validacaoList.isEmpty()){
						resultado.getListaValidacao().add(new Validacao("Campo(s) obrigatório(s): "));
						resultado.getListaValidacao().addAll(validacaoList);
						return resultado;
					}
					
					SolicitacaoInspecaoInteligenteResponse response = restTemplate.postForObject(url,ii,SolicitacaoInspecaoInteligenteResponse.class);
					if (response.getCodigoRetorno() == null) {
						throw new ServiceException("Serviço "+url+" sem retorno.\r\n\r\nJson envio "+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(ii));
					}
					if (!response.getCodigoRetorno().equals(0)) {
						throw new ServiceException("Serviço "+url+" com retorno diferente de 0.\r\n\r\nJson retorno"+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
					}
					atualizarInspecaoInteligenteSolicitada(response,itemInspecao,user);
					resultado.setCodigo(response.getCodigoRetorno());
				}
			}
		}catch (RestClientException e) {
			logger.error("Erro na comunicação com sistema de Inspeção Inteligente.",e);
			throw new ServiceException(e.getMessage(),e);
		} catch (Exception e) {
			logger.error("Erro ao processar a solicitação Inspeção Inteligente",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return resultado;
	}
	
	private List<Validacao> validarCamposObrigatorios(InspecaoInteligente ii) throws ServiceException{
		List<Validacao> validacaoList = new ArrayList<Validacao>();
		if(ii == null){
			logger.error("Os dados de inspeção inteligente não foram preenchidos");
			throw new ServiceException("Os dados de inspeção inteligente não foram preenchidos");
		} else {
			validacaoList.addAll(validarCamposObrigatoriosDadosGerais(ii.getDadosgerais()));
			
			//valida as coberturas
			if(ii.getCoberturas() == null || ii.getCoberturas().isEmpty()){
				logger.error("Os dados de coberturas não foram preenchidos na inspeção inteligente");
				validacaoList.add(new Validacao("Os dados de coberturas não foram preenchidos na inspeção inteligente"));
			}
			//valida o contato da inspeção
			validacaoList.addAll(validarCamposObrigatoriosContato(ii.getContatoInspecao()));
		}
		return validacaoList;
	}
	
	private List<Validacao> validarCamposObrigatoriosContato(ContatoInspecaoInteligente c) throws ServiceException {
		List<Validacao> validacaoList = new ArrayList<Validacao>();
		if(c == null){
			logger.error("Os dados do contato de inspeção inteligente não foram preeenchidos");
			validacaoList.add(new Validacao("Os dados do contato de inspeção inteligente não foram preeenchidos"));
		} else {
			if(c.getNomeContato() == null || c.getNomeContato().isEmpty()){
				validacaoList.add(new Validacao("Nome do contato"));
			}
			
			if(c.getNumeroDDDTelefoneContato1() == null || c.getNumeroDDDTelefoneContato1() == 0 || c.getNumeroTelefoneContato1() == null || c.getNumeroTelefoneContato1() == 0){
				validacaoList.add(new Validacao("Telefone 1"));
			}
		}
		
		return validacaoList;
	}

	private List<Validacao> validarCamposObrigatoriosDadosGerais(DadosGeraisInspecaoInteligente dg) throws ServiceException {
		List<Validacao> validacaoList = new ArrayList<Validacao>();
		//valida dados gerais	
		if(dg == null){
			logger.error("Os dados gerais de inspeção inteligente não foram preeenchidos");
			validacaoList.add(new Validacao("Os dados gerais de inspeção inteligente não foram preeenchidos"));
		} else {
			if(dg.getSistemaOrigem() == null || dg.getSistemaOrigem().isEmpty()){
				validacaoList.add(new Validacao("Sistema origem"));
			}
			
			if(dg.getNumeroPropostaOrigem() == null || dg.getNumeroPropostaOrigem().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Número proposta origem"));
			}
			
			if(dg.getNumItemProposta() == null || dg.getNumItemProposta().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Número item proposta"));
			}
			
			if(dg.getCodigoProduto() == null || dg.getCodigoProduto().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Código produto"));
			}
			
			if(dg.getCodigoAtividade() == null || dg.getCodigoAtividade().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Código atividade"));
			}
			
			if(dg.getIndReinspecao() == null || dg.getIndReinspecao().isEmpty()){
				validacaoList.add(new Validacao("Reinspeção"));
			}
			
			if(dg.getCodigoCorretor() == null || dg.getCodigoCorretor().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Código corretor"));	
			}
			
			if(dg.getSucursalComercial() == null){
				validacaoList.add(new Validacao("Sucursal comercial"));
			}
			
			if(dg.getCodigoEmissorSubscritor() == null || dg.getCodigoEmissorSubscritor().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Código emissor/subscritor"));
			}
			
			if(dg.getCpfCnpjSegurado() == null || dg.getCpfCnpjSegurado().compareTo(BigInteger.ZERO) <= 0){
				validacaoList.add(new Validacao("Cpf/Cnpj segurado"));
			}
			
			if(dg.getRazaoSocial() == null || dg.getRazaoSocial().isEmpty()){
				validacaoList.add(new Validacao("Razão social"));
			}
			
			if(dg.getLogradouroLocalRisco() == null || dg.getLogradouroLocalRisco().isEmpty()){
				validacaoList.add(new Validacao("Logradouro do local em risco"));
			}
			
			if(dg.getNumeroLogradouroLocalRisco() == null || dg.getNumeroLogradouroLocalRisco().compareTo(BigInteger.ZERO) < 0){
				validacaoList.add(new Validacao("Número do local em risco"));
			}
			
			if(dg.getBairroLocalRisco() == null || dg.getBairroLocalRisco().isEmpty()){
				validacaoList.add(new Validacao("Bairro do local em risco"));
			}
			
			if(dg.getCidadeLocalRisco() == null || dg.getCidadeLocalRisco().isEmpty()){
				validacaoList.add(new Validacao("Cidade do local em risco"));
			}
			
			if(dg.getEstadoLocalRisco() == null || dg.getEstadoLocalRisco().isEmpty()){
				validacaoList.add(new Validacao("Estado do local em risco"));
			}
			
			if(dg.getEmailSubscritorEmissor() == null || dg.getEmailSubscritorEmissor().isEmpty()){
				validacaoList.add(new Validacao("E-mail emissor/subscritor"));
			}			
		}
		return validacaoList;
	}

	/*
	 * Processo utilizado para solicitar uma inspeção inteligente pelo CTPJ
	 */
	public Integer solicitaCancelamentoInspecaoInteligente(BigInteger sequencialItemInspecao,User user) throws ServiceException {
		Integer retorno = 1;
		try {
			String url = findUrlInspecaoInteligenteSolicitacaoCancelamento();
			Cotacao cotacao = cotacaoRepository.findCotacaoItemInspecaoBySeqItemInspecao(sequencialItemInspecao);
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				for (ItemInspecao itemInspecao : itemCotacao.getListItemInspecao()) {
					CancelamentoInspecaoInteligente cancelamentoSolicitacao = bindToCancelamentoInspecaoInteligente(cotacao,itemCotacao,itemInspecao);
					CancelamentoInspecaoInteligenteResponse response = restTemplate.postForObject(url,cancelamentoSolicitacao,CancelamentoInspecaoInteligenteResponse.class);
					if (response.getCodigoRetorno() == null) {
						throw new ServiceException("Serviço "+url+" sem retorno.\r\n\r\nJson envio "+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(cancelamentoSolicitacao));
					}
							
					if (!response.getCodigoRetorno().equals(0)) {
						throw new ServiceException("Serviço "+url+" com retorno diferente de 0.\r\n\r\nJson retorno "+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
					}
					atualizarCancelamentoInspecao(response,itemInspecao,user);
					retorno = response.getCodigoRetorno();
				}
			}
		} catch (RestClientException e) {
			logger.error("Erro na comunicação com sistema de Inspeção Inteligente.",e);
			throw new ServiceException(e.getMessage(),e);
		} catch (Exception e) {
			logger.error("Erro ao processar o cancelamento da solicitação Inspeção Inteligente",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return retorno;
	}

	public String findUrlInspecaoInteligenteSolicitacaoCancelamento() throws ServiceException {
		try {
			
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroInspecaoInteligenteSolicitacaoCancelamento(parametroGeralService.getUrlByNome(ParametroGeralEnum.INSPECAO_INTELIGENTE_TOMCAT));
			if (urlEnum == null) { 
				throw new ServiceException("Erro ao buscar URL referente a solicitação de cancelamento de inspeção inteligente."); 
			}
			String url = parametroGeralService.getUrlByNome(urlEnum);
			if (StringUtils.isEmpty(url)) { 
				throw new ServiceException("URL de acesso a solicitação de cancelamento de inspeção inteligente nula ou vazia."); 
			}
			return url;
		} catch (Exception e) {
			logger.error("Erro ao atualizar % IS VR",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public String findUrlInspecaoInteligenteSolicitacao() throws ServiceException {
		try {
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroInspecaoInteligenteSolicitacao(parametroGeralService.getUrlByNome(ParametroGeralEnum.INSPECAO_INTELIGENTE_TOMCAT));
			if (urlEnum == null) {
				throw new ServiceException("Erro ao buscar URL referente a solicitação de inspeção inteligente.");
			}
			String url = parametroGeralService.getUrlByNome(urlEnum);
			if (StringUtils.isEmpty(url)) {
				throw new ServiceException("URL de acesso a solicitação de inspeção inteligente nula ou vazia.");
			}
			return url;
		} catch (Exception e) {
			logger.error("Erro ao atualizar % IS VR",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public InspecaoInteligente bindToInspecaoInteligente(Cotacao cotacao,ItemCotacao itemCotacao,ItemInspecao itemInspecao,Set<ItemCobertura> listItemCobertura) {
		InspecaoInteligente	inspecao = new InspecaoInteligente();
		inspecao.setDadosgerais(bindToDadosGerais(cotacao,itemCotacao,itemInspecao));
		inspecao.setCoberturas(bindToItemListCobertura(listItemCobertura));
		inspecao.setContatoInspecao(bindToContatoInspecao(itemInspecao));
		return inspecao;
	}

	public DadosGeraisInspecaoInteligente bindToDadosGerais(Cotacao cotacao,ItemCotacao itemCotacao,ItemInspecao itemInspecao) {
		DadosGeraisInspecaoInteligente dadosGeraisRequest = new DadosGeraisInspecaoInteligente(); 
		dadosGeraisRequest.setNumeroPropostaOrigem(cotacao.getNumeroCotacaoProposta());
		dadosGeraisRequest.setNumItemProposta(itemCotacao.getNumeroItem());
		dadosGeraisRequest.setCodigoProduto(new BigInteger(cotacao.getCodigoProduto().toString()));
		dadosGeraisRequest.setCodigoAtividade(new BigInteger(cotacao.getCodigoProduto() + "7"));
		dadosGeraisRequest.setCodigoSubatividade(new BigInteger(itemCotacao.getCodigoRubrica().toString()));
		dadosGeraisRequest.setVlRisco(itemCotacao.getValorRiscoBem());
		dadosGeraisRequest.setAtividade(StringUtils.substring(itemCotacao.getDescricaoRubrica(),0,249));
		dadosGeraisRequest.setDataInicioVigencia(DateUtil.formataDiaMesAno(itemCotacao.getDataInicioVigencia()));
		dadosGeraisRequest.setDataFimVigencia(DateUtil.formataDiaMesAno(itemCotacao.getDataFimVigencia()));
		Calendar dataLimiteAceitacao = Calendar.getInstance();
		dataLimiteAceitacao.add(Calendar.DATE,15);
		dadosGeraisRequest.setDataLimiteAceitacao(DateUtil.formataDiaMesAno(dataLimiteAceitacao));
		dadosGeraisRequest.setDataProposta(cotacao.getDataProposta() != null ? DateUtil.formataDiaMesAno(cotacao.getDataProposta()) : DateUtil.formataDiaMesAno(Calendar.getInstance()));
		if (itemCotacao.getIdTipoSeguro().equals(TipoSeguroEnum.RENOVACAO_CONGENERE)) {
			dadosGeraisRequest.setApoliceRenovacao(itemCotacao.getNumeroApoliceCongenere());
		} else if (itemCotacao.getIdTipoSeguro().equals(TipoSeguroEnum.RENOVACAO_TOKIO)) {
			dadosGeraisRequest.setApoliceRenovacao(StringUtils.leftPad(itemCotacao.getCodigoRamoProdutoRenovada().toString(),3," ") + " " + StringUtils.leftPad(itemCotacao.getCodigoApoliceRenovada().toString(),10," "));
		}
		dadosGeraisRequest.setIndReinspecao("N");
		dadosGeraisRequest.setCodigoCorretor(new BigInteger(cotacao.getCodigoCorretorACSEL()));
		dadosGeraisRequest.setCodigoEmissorSubscritor(new BigInteger(cotacao.getCodigoSubscritor().toString()));
		dadosGeraisRequest.setCpfCnpjSegurado(new BigInteger(itemCotacao.getNumeroCNPJCPFSegurado().toString()));
		dadosGeraisRequest.setRazaoSocial(itemCotacao.getNomeSegurado());
		dadosGeraisRequest.setLogradouroLocalRisco(itemCotacao.getEnderecoLocalRisco());
		dadosGeraisRequest.setNumeroLogradouroLocalRisco(itemCotacao.getNumeroEnderecoLocalRisco() != null ? new BigInteger(itemCotacao.getNumeroEnderecoLocalRisco().toString()) : new BigInteger("0"));
		dadosGeraisRequest.setCepLocalRisco(itemCotacao.getIdCEPLocalRisco() != null ? new BigInteger(itemCotacao.getIdCEPLocalRisco().toString()) : BigInteger.ZERO);
		dadosGeraisRequest.setBairroLocalRisco(itemCotacao.getNomeBairroLocalRisco() != null ? itemCotacao.getNomeBairroLocalRisco() : "-");
		dadosGeraisRequest.setCidadeLocalRisco(itemCotacao.getNomeMunicipioLocalRisco() != null ? itemCotacao.getNomeMunicipioLocalRisco() : "-");
		dadosGeraisRequest.setEstadoLocalRisco(itemCotacao.getIdUFLocalRisco());
		dadosGeraisRequest.setCmploEnder(itemCotacao.getNomeComplementoEnderecoLocalRisco());
		dadosGeraisRequest.setEmailSubscritorEmissor(cotacao.getEmailSubscritor());
		dadosGeraisRequest.setSucursalComercial(cotacao.getCodigoSucursalComercial() != null ? new BigInteger(cotacao.getCodigoSucursalComercial().toString()) : BigInteger.ZERO);
		dadosGeraisRequest.setEmailCorretor(cotacao.getEmailCorretorInspecao());
		dadosGeraisRequest.setEmailAcessoria(cotacao.getEmailAssessoria());
		dadosGeraisRequest.setTextoObservacoes(itemInspecao.getDescricaoObservacao());
		dadosGeraisRequest.setTpEmissao(cotacao.getIdTipoPedidoCotacao() != null ? cotacao.getIdTipoPedidoCotacao().getId() : null);
		dadosGeraisRequest.setTpSolct("A");
		dadosGeraisRequest.setSistemaOrigem("PLT");
		dadosGeraisRequest.setVersaoProposta( cotacao.getVersaoCotacaoProposta() != null ? new BigInteger(cotacao.getVersaoCotacaoProposta().toString()) : BigInteger.ONE);
		dadosGeraisRequest.setNmSubct(cotacao.getNomeSubscritor());
		dadosGeraisRequest.setModuloOrigem("CTP");
		return dadosGeraisRequest;
	}

	public List<CoberturaInspecaoInteligente> bindToItemListCobertura(Set<ItemCobertura> listItemCobertura) {
		List<CoberturaInspecaoInteligente> listCoberturaRequest = new ArrayList<>();
		Integer idxCobertura = 0;
		for (ItemCobertura itemCobertura : listItemCobertura) {
			idxCobertura++;
			CoberturaInspecaoInteligente coberturaRequest = new CoberturaInspecaoInteligente();
			coberturaRequest.setSeqCobertura(idxCobertura);
			coberturaRequest.setNomeCobertura(StringUtils.substring(itemCobertura.getDescricaoCobertura(),0,99));
			coberturaRequest.setValorISCobertura(itemCobertura.getValorImportanciaSegurada());
			listCoberturaRequest.add(coberturaRequest);
		}
		return listCoberturaRequest;
	}

	public ContatoInspecaoInteligente bindToContatoInspecao(ItemInspecao itemInspecao) {
		ContatoInspecaoInteligente contatoInspecao = new ContatoInspecaoInteligente();
		contatoInspecao.setTipoContatoTelefone1("C");
		contatoInspecao.setNumeroDDDTelefoneContato1(itemInspecao.getNumeroDDD1() != null ? itemInspecao.getNumeroDDD1().intValue() : null);
		contatoInspecao.setTipoContatoTelefone2("C");
		contatoInspecao.setNumeroDDDTelefoneContato2(itemInspecao.getNumeroDDD2() != null ? itemInspecao.getNumeroDDD2().intValue() : null);
		contatoInspecao.setNumeroTelefoneContato1(itemInspecao.getNumeroTelefone1());
		contatoInspecao.setNumeroTelefoneContato2(itemInspecao.getNumeroTelefone2());
		contatoInspecao.setNomeContato(itemInspecao.getDescricaoContato());
		contatoInspecao.setEmailContato(StringUtils.substring(itemInspecao.getEmailContatoInspecao(),0,99));
		contatoInspecao.setContatoConfirmado("S");
		contatoInspecao.setComentarios(itemInspecao.getDescricaoContato());
		return contatoInspecao;
	}

	private CancelamentoInspecaoInteligente bindToCancelamentoInspecaoInteligente(Cotacao cotacao,ItemCotacao itemCotacao,ItemInspecao itemInspecao) {
		CancelamentoInspecaoInteligente cancelamento = new CancelamentoInspecaoInteligente();
		cancelamento.setNumeroProposta(cotacao.getNumeroCotacaoProposta());
		cancelamento.setNumeroItem(itemCotacao.getNumeroItem());
		cancelamento.setNumeroSolicitacao(new BigInteger(itemInspecao.getNumeroRelatorio()));
		cancelamento.setNumeroItem(itemCotacao.getNumeroItem());
		cancelamento.setJustificativa("SOLICITACAO DE DISPENSA DE INSPECAO REALIZADA PELO SUBSCRITOR");
		cancelamento.setTipoEmissao(cotacao.getIdTipoPedidoCotacao().getId());
		cancelamento.setSistemaOrigem(CTP.SISTEMORIGEMPARAGRADE.value());
		return cancelamento;
	}


	public void atualizarInspecaoInteligenteSolicitada(SolicitacaoInspecaoInteligenteResponse response,ItemInspecao itemInspecao,User user) throws ServiceException {
		try {
			if (response.getCodigoRetorno().equals(0)) {
				itemInspecao.setDataAtualizacao(new Date());
				itemInspecao.setNumeroRelatorio(response.getNumeroSolicitacao().toString());
				itemInspecao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
				itemInspecao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
				itemInspecao.setIdSituacao(SituacaoInspecaoEnum.INSPECAO_INICIADA_PENDENTE_ATRIBUICAO);
				itemInspecao.setVersaoCotacaoPropostaSolicitacao(itemInspecao.getVersaoCotacaoProposta());
				itemInspecao.setNumeroItemSolicitacao(itemInspecao.getItemCotacao().getNumeroItem());
				inspecaoRepository.update(itemInspecao);
			}
		} catch (Exception e) {
			logger.error("Problemas ao atualizar retorno da solicitação de inspeção.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	public void processarAtualizacaoFluxoInspecaoInteligente(BigInteger numeroCotacaoProposta,BigInteger numeroItemCotacaoProposta,Integer versaoCotacaoProposta,Integer idParecerInspecao,Integer idStatusFluxoInspecao) throws ServiceException {
		try {
			logger.info(numeroCotacaoProposta+" - "+versaoCotacaoProposta+" - "+numeroItemCotacaoProposta);
			for (ItemInspecao itemInspecao : inspecaoRepository.findItemInspecaoByNrCotacAndVsCotacAndNrItem(numeroCotacaoProposta,versaoCotacaoProposta,numeroItemCotacaoProposta)) {
				itemInspecao.setIdSituacao(SituacaoInspecaoEnum.getById(idStatusFluxoInspecao));
				atualizarDataAgendamento(idStatusFluxoInspecao,itemInspecao);
				atualizarParecerDataRelatorioLaudo(idParecerInspecao,itemInspecao);
				atualizarDataAtualizacao(itemInspecao);
				inspecaoRepository.update(itemInspecao);
			}
		} catch (Exception e) {
			throw new ServiceException(String.format("Parâmetros enviados. Nº Cotação %s - Nº Item %s - Nº Versão %s - Parecer %s - Fluxo %s.",numeroCotacaoProposta,numeroItemCotacaoProposta,versaoCotacaoProposta,idParecerInspecao,idStatusFluxoInspecao)+" "+e.getMessage(),e);
		}
	}
	

	private void atualizarDataAtualizacao(ItemInspecao itemInspecao) {
		itemInspecao.setDataAtualizacao(new Date());
	}

	private void atualizarParecerDataRelatorioLaudo(Integer idParecerInspecao,ItemInspecao itemInspecao) {
		if(itemInspecao.getIdSituacao() != null) {
			if (itemInspecao.getIdSituacao().getIdRelatorioFinalizado().equals(SimNaoEnum.SIM)) {
				if (idParecerInspecao.equals(1)) {
					itemInspecao.setIdParecer(ParecerInspecaoEnum.NORMAL);
				} else if (idParecerInspecao.equals(4)) {
					itemInspecao.setIdParecer(ParecerInspecaoEnum.NORMAL_COM_MELHORIAS);
				} else if (idParecerInspecao.equals(2)) {
					itemInspecao.setIdParecer(ParecerInspecaoEnum.AGRAVADO);
				} else if (idParecerInspecao.equals(3)) {
					itemInspecao.setIdParecer(ParecerInspecaoEnum.RUIM);
				}
				itemInspecao.setDataRelatorio(new Date());
				if (itemInspecao.getIdSituacao().equals(SituacaoInspecaoEnum.RELATORIO_INSPECAO_TRANSMITIDO_SEM_SCORE)) {
					itemInspecao.setIdLaudoSemScore(SimNaoEnum.SIM);
				} else {
					itemInspecao.setIdLaudoSemScore(SimNaoEnum.NAO);
				}
			}
		}
	}

	private void atualizarDataAgendamento(Integer idStatusFluxoInspecao,ItemInspecao itemInspecao) {
		if (idStatusFluxoInspecao == 4) {
			itemInspecao.setDataAgendamento(new Date());
		}
	}

	public InspecaoInteligente buscarDadosInspecaoInteligente(BigInteger numeroCotacaoProposta,BigInteger numeroItemCotacaoProposta) throws ServiceException {
		try {
			Cotacao cotacao = cotacaoRepository.findCotacaoItemInspecaoByNumeroCotacAndNumeroItem(numeroCotacaoProposta,numeroItemCotacaoProposta);
			InspecaoInteligente inspecao = null;
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				for (ItemInspecao itemInspecao : itemCotacao.getListItemInspecao()) {
					inspecao = bindToInspecaoInteligente(cotacao,itemCotacao,itemInspecao,itemCotacao.getListItemCobertura());
				}
			}
			return inspecao;
		} catch (Exception e) {
			throw new ServiceException(String.format("Parâmetros enviados. Nº Cotação %s - Nº Item %s.",numeroCotacaoProposta,numeroItemCotacaoProposta)+" "+e.getMessage(),e);
		}
	}

	public void atualizarCancelamentoInspecao(CancelamentoInspecaoInteligenteResponse response,ItemInspecao itemInspecao,User user) throws ServiceException {
		try {

			itemInspecao.setDataAtualizacao(new Date());
			itemInspecao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			itemInspecao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			itemInspecao.setIdSituacao(SituacaoInspecaoEnum.SOLICITACAO_INSPECAO_CANCELADA);
			inspecaoRepository.update(itemInspecao);
			
		} catch (Exception e) {
			logger.error("Problemas ao cancelar retorno do cancelamento da inspeção inteligente.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public void requestValidatorAtualizarFluxoInspecao(BigInteger numeroCotacaoProposta,BigInteger numeroItemCotacao,Integer versaoCotacaoProposta,Integer idParecerInspecao,Integer idStatusFluxoInspecao) throws ServiceException {
		if (numeroCotacaoProposta == null) {
			throw new ServiceException("Numero cotação proposta é obrigatório.");
		}
		if (numeroItemCotacao == null) {
			throw new ServiceException("Numero do item da cotação é obrigatório.");
		}
		if (versaoCotacaoProposta == null) {
			throw new ServiceException("Versão da proposta é obrigatório.");
		}
//		if (idParecerInspecao == null){
//			throw new ServiceException("Identificador do parecer da inspeção é obrigatório.");
//		}
//		if (idStatusFluxoInspecao == null){
//			throw new ServiceException("Identificador de status do fluxo de inspeção é obrigatório.");
//		}
	}
}
