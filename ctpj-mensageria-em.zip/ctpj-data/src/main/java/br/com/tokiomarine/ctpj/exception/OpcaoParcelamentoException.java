package br.com.tokiomarine.ctpj.exception;

public class OpcaoParcelamentoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8662453210329455942L;

	public OpcaoParcelamentoException(String message) {
		super(message);
	}

	public OpcaoParcelamentoException(String message,Throwable cause) {
		super(message,cause);
	}

	
	
}
