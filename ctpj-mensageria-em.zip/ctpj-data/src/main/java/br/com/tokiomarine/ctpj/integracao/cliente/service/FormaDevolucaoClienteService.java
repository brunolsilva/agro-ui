package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.math.BigInteger;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;

import br.com.tokiomarine.cliente.dto.FormaDevolucaoCliente;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.service.DevolucaoService;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoProcessamentoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.integracao.cliente.formadevolucao.CadastroFormaDevolucao;
import br.com.tokiomarine.ctpj.integracao.cliente.formadevolucao.FormaDevolucaoFactory;
import br.com.tokiomarine.ctpj.integracao.cliente.request.FormaDevolucaoRequest;
import br.com.tokiomarine.ctpj.integracao.service.ServicosPortaisService;
import br.com.tokiomarine.ctpj.integracao.servicosportais.response.CorretorResponse;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.ServicosClienteEnum;

@Service
public class FormaDevolucaoClienteService extends BaseClienteService {

	@Autowired
	private ServicosPortaisService servicosPortaisService;

	@Autowired
	private DevolucaoService devolucaoService;
			
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	
	/**
	 * consulta as formas de devolução liberadas para o cliente	
	 * @param cotacao
	 * @return
	 */
	private List<FormaDevolucaoCliente> consultarFormaDevolucao(Cotacao cotacao) {
		//monta a request
		Map<String,Long> request = new HashMap<>();
		request.put("cdClien", cotacao.getCodigoCliente());
		request.put("idFormaCobrc", getIdFormaCobrancaPrimeiraParcela(cotacao));
		
		FormaDevolucaoCliente[] formasDevolucaoResponse = null;
		try{
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_FORMAS_DEVOLUCAO, null);
			formasDevolucaoResponse =  restTemplate.postForObject(uri,request,FormaDevolucaoCliente[].class);		
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Listar Formas de Devolução ",e);
		}
		
		return ajustarFormasDevolucao(formasDevolucaoResponse);
	}
	
	private List<FormaDevolucaoCliente> ajustarFormasDevolucao(FormaDevolucaoCliente[] formasDevolucao){
		if(formasDevolucao != null && formasDevolucao.length > 0) {
			for(FormaDevolucaoCliente formaDevolucao : formasDevolucao) {
				if(formaDevolucao.getIdFormaDevol() == null) {
					formaDevolucao.setIdFormaDevol(0l);
				}
			}
			Arrays.sort(formasDevolucao, Comparator.comparing(FormaDevolucaoCliente::getIdFormaDevol).reversed());
			
			
		}
		return Arrays.asList(formasDevolucao);
	}

	/**
	 * obtem o id da forma de cobranca da primeira parcela 
	 * @param cotacao
	 * @return
	 */
	private Long getIdFormaCobrancaPrimeiraParcela(Cotacao cotacao) {
		
		//caso já tenha sido definida uma forma de devolução para a cotação atual, retorna este id
		if(cotacao.getIdFormaCobrancaPrimeiraParcela() != null) {
			return cotacao.getIdFormaCobrancaPrimeiraParcela().longValue();
		}
		
		//busca na apólice que gerou o endosso atual a forma de cobrança utilizada na primeira parcela
		if(cotacao.getCodigoSituacao().equals(CodigoSituacaoEnum.CALCULADA_318.getSituacao().intValue()) && !StringUtils.isEmpty(cotacao.getIdMongoEndosso())) {
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			if(apolice != null) {
				return apolice.getIdFrmCobPrimeira();
			}
		}
		return 0l;
	}
	
	/**
	 * retorna as formas de devolução liberadas para o cliente
	 * @param cadastroFormaDevolucao
	 * @param cotacao
	 * @param formaDevolucao
	 * @return
	 */
	public List<FormaDevolucaoApoliceEnum> formasDevolucaoLiberadasCliente(Cotacao cotacao, CotacaoView cotacaoView){
		List<FormaDevolucaoApoliceEnum> retorno = new ArrayList<>();
		try {
			List<FormaDevolucaoCliente> formasDevolucaoCliente = consultarFormaDevolucao(cotacao);
			//guarda as formas de devolução pois serão utilizadas posteriormente
			cotacaoView.setFormasDevolucaoClienteLiberadas(formasDevolucaoCliente);
			//percorre as formas de devolução liberadas para o cliente (pelo serviço) e adiciona ao retorno os enums correspondentes
			if(formasDevolucaoCliente != null && !formasDevolucaoCliente.isEmpty()) {
				for(FormaDevolucaoCliente formaDevolucaoCliente : formasDevolucaoCliente) {
					FormaDevolucaoApoliceEnum formaDevolucao = FormaDevolucaoApoliceEnum.getByTipoDevolucao(formaDevolucaoCliente.getTpDevol());
					if(!retorno.contains(formaDevolucao)) {
						retorno.add(FormaDevolucaoApoliceEnum.getByTipoDevolucao(formaDevolucaoCliente.getTpDevol()));	
					}
					
				}

				if (SecurityUtils.getCurrentUser().getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR) {
					CorretorResponse corretorResponse = servicosPortaisService.buscaCorretor(cotacao.getCodigoCorretorACSEL());
					if (corretorResponse != null && corretorResponse.getIdDevolucaoSomenteCredito() != null && corretorResponse.getIdDevolucaoSomenteCredito() == SimNaoEnum.SIM) {

						if(!retorno.contains(FormaDevolucaoApoliceEnum.CREDITO_CONTA)) {
							retorno.add(FormaDevolucaoApoliceEnum.CREDITO_CONTA);	
						}
						retorno.remove(FormaDevolucaoApoliceEnum.CHEQUE);
						retorno.remove(FormaDevolucaoApoliceEnum.RECIBO);
					}
				} else {
					if(!retorno.contains(FormaDevolucaoApoliceEnum.CREDITO_CONTA)) {
						retorno.add(FormaDevolucaoApoliceEnum.CREDITO_CONTA);	
					}
				}

				//ordena as formas de devolução liberadas
				Collections.sort(retorno, new Comparator<FormaDevolucaoApoliceEnum>() {
			        @Override
			        public int compare(FormaDevolucaoApoliceEnum forma2, FormaDevolucaoApoliceEnum forma1)
			        {
			        	return  forma2.getDescricao().compareTo(forma1.getDescricao());
			        }
			    });
			}			
		}
		catch(Exception e) {
			logger.error("Erro Geral ao carregar Formas de Devolução Liberadas para o Cliente",e);
		}

		return retorno;
	}
	
	/**
	 * valida se a opção de crédito em conta está liberada para o cliente
	 * @param cotacao
	 * @return
	 */
	public Boolean creditoEmContaLiberado(List<FormaDevolucaoApoliceEnum> formasDevolucaoLiberadas) {
		return formasDevolucaoLiberadas.contains(FormaDevolucaoApoliceEnum.CREDITO_CONTA);
			
	}
	
	/**
	 * cadastra os dados da forma de devolução sem disparar exception em caso de erro. deverá ser usado ao salvar dados
	 * @param cotacao
	 * @param propostaView
	 * @param user
	 */
	public void cadastrarFormaDevolucaoSemException(Cotacao cotacao, PropostaView propostaView,User user) {
		try {
			this.cadastrarFormaDevolucao(cotacao, propostaView, user);
		} catch (ServiceException e) {
			logger.error("Erro ao chamar serviço Cadastrar Forma de Devolução (Salvar) "+cotacao.getSequencialCotacaoProposta(),e);
		}
	}
	
	/**
	 * cadastra a forma de devolução escolhida para o cliente
	 * @param cotacao
	 * @param propostaView
	 * @param user
	 * @throws ServiceException
	 */
	public void cadastrarFormaDevolucao(Cotacao cotacao, PropostaView propostaView,User user) throws ServiceException {
		if(devolucaoService.ehDevolucao(cotacao)) {
			CadastroFormaDevolucao cadastroFormaDevolucao = FormaDevolucaoFactory.getFormaDevolucao(cotacao.getCodigoFormaDevolucao()).orElse(null);
			if(cadastroFormaDevolucao != null) {
				FormaDevolucaoCliente formaDevolucao = consultarFormaDevolucao(cotacao).stream()
																				.filter(f -> cotacao.getCodigoFormaDevolucao().getTiposDevolucao().contains(f.getTpDevol()))
																				.findFirst()
																				.orElse(null);
				FormaDevolucaoCliente formaDevolucaoCliente =  cadastrarFormaDevolucao(cadastroFormaDevolucao, cotacao,formaDevolucao,propostaView,user);
				if(formaDevolucaoCliente != null && formaDevolucaoCliente.getIdFormaDevol() != null) {
					cotacao.setIdFormaCobrancaPrimeiraParcela(BigInteger.valueOf(formaDevolucaoCliente.getIdFormaDevol())); 
				}
			}
			
		}
	}
	
	/**
	 * chama o serviço que cadastra a forma de devolução escolhida para o cliente
	 * @param cotacao
	 * @param propostaView
	 * @param user
	 * @throws ServiceException
	 */
	private FormaDevolucaoCliente cadastrarFormaDevolucao(CadastroFormaDevolucao cadastroFormaDevolucao, Cotacao cotacao, FormaDevolucaoCliente formaDevolucao,PropostaView propostaView,User user) throws ServiceException {
		if(cadastroFormaDevolucao.dadosValidos(cotacao)) {
			FormaDevolucaoRequest request = null;
			FormaDevolucaoCliente response = null;
			try{
				request = cadastroFormaDevolucao.bindToRequest(cotacao,formaDevolucao,propostaView);
				URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.CADASTRAR_FORMA_DEVOLUCAO, null);
				response =restTemplate.postForObject(uri,request,FormaDevolucaoCliente.class); 
				cotacaoLogService.logarChamadaComSucesso(cotacao
													 , user
													 , TipoProcessamentoEnum.CADASTRAR_FORMA_DEVOLUCAO_CLIENTE
													 , request
													 , response);
				return response;
			}
			catch(HttpServerErrorException se){
				tratarHttpServerErrorException(cotacao,se);
				
			} catch (Exception e) {
				cotacaoLogService.logarChamadaComErro(cotacao, user, TipoProcessamentoEnum.CADASTRAR_FORMA_DEVOLUCAO_CLIENTE, request, response, e);
				logger.error("Erro ao chamar serviço Cadastrar Forma de Devolução (Enviar) "+cotacao.getSequencialCotacaoProposta(),e);
				throw new ServiceException("Ocorreu um erro ao salvar forma de devolução");
			}
		}

		return null;
	}
}