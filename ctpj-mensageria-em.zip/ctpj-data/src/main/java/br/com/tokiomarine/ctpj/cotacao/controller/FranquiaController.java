package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaEFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.FranquiaService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Controller
@RequestMapping(value = "/franquia")
public class FranquiaController extends AbstractController {

	private static Logger logger = LogManager.getLogger(FranquiaController.class);

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private FranquiaService franquiaService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;

	@LogPerformance
	@GetMapping(value = "/{sqCotacao}")
	public String franquia(@PathVariable BigInteger sqCotacao,Model model,HttpServletRequest request) {

		try {
			limpaMensagens(request);
			CotacaoView cotacaoView = cotacaoService.findCotacaoCabecalho(sqCotacao);
			List<ItemCotacao> itens = franquiaService.getItemsComEndereco(sqCotacao);

			model.addAttribute("cabecalhoCotacao",cotacaoView);
			model.addAttribute("items",itens);
			List<ItemCoberturaFranquiaView> coberturasFranquia = franquiaService.findDadosFranquia(null,sqCotacao,cotacaoView.getCodigoProduto());
			model.addAttribute("coberturas",coberturasFranquia);
			model.addAttribute("formasFranquia",Arrays.asList(FormaFranquiaEnum.values()).stream().filter(f -> !f.isDisabled()).collect(Collectors.toList()));
			model.addAttribute("produto",cotacaoView.getNomeProduto());
			model.addAttribute("codigoProduto",cotacaoView.getCodigoProduto());
			model.addAttribute("numeroCotacaoProposta",cotacaoView.getNumeroCotacaoProposta());
			model.addAttribute("sqCotacao",cotacaoView.getSequencialCotacaoProposta());
			model.addAttribute("readOnly",isReadOnly(cotacaoView));
			model.addAttribute("ehTipoLMIUnico", itens.isEmpty() ? "NÃO" : itens.get(0).getCotacao().getIdLmiUnico().getDescricao());
			model.addAttribute("seqPrimeiroItemCotacao", itens.isEmpty() ? -1 : itens.get(0).getSequencialItemCotacao());
		} catch (ServiceException e) {
			logger.error("Erro ao carregar os dados de Franquia: ",e);
		}

		return "cotacao/cobertura/franquia";
	}

	private boolean isReadOnly(CotacaoView cotacaoView) {
		boolean isReadOnly =CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly(); 
		if(!isReadOnly) {
			GrupoUsuarioEnum grupoUsuario = SecurityUtils.getCurrentUser().getGrupoUsuario();
			try {
				isReadOnly = perfilComercialService.hasPerfilComercial(grupoUsuario);
			} catch (ServiceException e) {
				logger.error("Ocorreu um erro ao verificar se é usuário do comercial:" + e.getMessage());
			}
		}
		return isReadOnly; 
	}

	@LogPerformance
	@GetMapping(value = "/findDadosFranquia/{sqItemCotacao}/{sqCotac}/{codigoProduto}")
	public @ResponseBody List<ItemCoberturaFranquiaView> findDadosFranquia(
			@PathVariable BigInteger sqItemCotacao,
			@PathVariable BigInteger sqCotac,
			@PathVariable Integer codigoProduto,
			Model model) {
		try {
			return franquiaService.findDadosFranquia(sqItemCotacao,sqCotac,codigoProduto);
		} catch (ServiceException e) {
			logger.error("Erro ao recuperar as franquias por item ",e);
			return Collections.emptyList();
		}
	}
	
	@GetMapping("/dados/{seqCotacao}")
	public ResponseEntity<?> findDadosFranquiaParaCorretor(@PathVariable BigInteger seqCotacao) {
		List<CoberturaEFranquiaView> franquiasECoberturas = franquiaService.findCoberturasEFranquiasPorCotacao(seqCotacao);
		return ResponseEntity.ok(franquiasECoberturas);
	}
	
	@GetMapping("/dados/{seqCotacao}/{seqItemCotacao}")
	public ResponseEntity<?> findDadosFranquiaParaCorretor(@PathVariable BigInteger seqCotacao, @PathVariable BigInteger seqItemCotacao) {
		try{
			List<CoberturaEFranquiaView> franquiasECoberturas = franquiaService.findCoberturasEFranquiasPorItemCotacao(seqItemCotacao);			
			return ResponseEntity.ok(franquiasECoberturas);
		}catch(Exception e){
			logger.error("Erro ao recuperar as franquias", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ocorreu um erro ao recuperar as franquias");
		}	
	}

	@LogPerformance
	@PostMapping(value = "/saveFranquia")
	@PreAuthorize("!hasAuthority('_ROLE_CRTOR')")
	public @ResponseBody ResultadoREST<ItemCoberturaFranquiaView> saveFranquia(
			@RequestBody List<ItemCoberturaFranquiaView> franquias,
			@RequestParam(value = "itemAitemOrTodosItens",required = true) Long itemAitemOrTodosItens,
			@RequestParam(value = "sqCotacao",required = true) BigInteger sqCotacao) {
		ResultadoREST<ItemCoberturaFranquiaView> resultado = new ResultadoREST<>();
		try {
			resultado = franquiaService.verificaSalvaTodosItensOrItemAItem(franquias,itemAitemOrTodosItens,sqCotacao);
		} catch (Exception e) {
			resultado.setSuccess(false);
			logger.error("Erro ao salvar franquia ",e);
		}
		return resultado;
	}

	@LogPerformance
	@GetMapping(value = "/limpaFranquia/{id}")
	public @ResponseBody ResultadoREST<ItemCoberturaFranquiaView> limpaFranquia(@PathVariable BigInteger id) {
		ResultadoREST<ItemCoberturaFranquiaView> resultado = new ResultadoREST<>();
		try {
			resultado.setSuccess(franquiaService.limpaFranquiaInformada(id));
			return resultado;
		} catch (ServiceException e) {
			resultado.setSuccess(false);
			logger.error("Erro ao Limpar os Dados da Franquia ",e);
			return resultado;
		}
	}
}
