package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.CondContratualApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.CondicaoContratualCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class EndossoCondicaoContratualService {
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0109
	 */
	public void validarCondicaoContratual(Produto produto, Cotacao endosso,Apolice apolice, List<AlteracaoEndosso> alteracoesEndossoList, User user){
		
		boolean endossoPossuiCondicoesContratuais = endosso.getListCondicaoContratual() != null && !endosso.getListCondicaoContratual().isEmpty();
		boolean apolicePossuiCondicoesContratuais = apolice.getCondContratual() != null && !apolice.getCondContratual().isEmpty();
		
		//1 - percorre as condições contratuais do endosso e compara com as da apólice
		//no caso de a apólice possui mesma condição que o endosso, porém a versão for diferente, loga que houve alteração
		//no caso de a apólice não possuir uma condição que o endosso possua, loga que houve inclusão
		if(endossoPossuiCondicoesContratuais){			
			for(CondicaoContratualCotacao condContrEndosso : endosso.getListCondicaoContratual()){
				boolean condicaoExiste = false;
				if(apolicePossuiCondicoesContratuais){
					for(CondContratualApolice condContrApolice : apolice.getCondContratual()){
						if(this.isCondicaoContratualEquals(condContrApolice, condContrEndosso)){
							this.compararParametrosCodigoVersao(condContrApolice.getCdVersao(), condContrEndosso.getCodigoVersao().longValue(), condContrApolice.getCdClausula(), condContrApolice.getCodigoGrupoRamo(), condContrApolice.getCdRamoClausula(), TipoMensagemEndossoEnum.ALT_CLAUSULA, "-vs ", produto, endosso, alteracoesEndossoList, user);
							condicaoExiste = true;
							break;
						}						
					}
				}
				
				//se a condição não existe
				if(!condicaoExiste){
					logarInclusaoCondicaoContratual(condContrEndosso.getCodigoClausula(), produto, endosso, alteracoesEndossoList, user); 
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as condições contratuais da apólice e compara com as do endosso
		// no caso de o endosso não possuir alguma condição que está na apólice, loga que a mesma foi excluída 
		if(apolicePossuiCondicoesContratuais){
			for(CondContratualApolice condContrApolice : apolice.getCondContratual()){
				boolean condicaoExiste = false;
				if(endossoPossuiCondicoesContratuais){
					for(CondicaoContratualCotacao condContrEndosso : endosso.getListCondicaoContratual()){
						if(this.isCondicaoContratualEquals(condContrApolice, condContrEndosso)){
							condicaoExiste = true;
							break;
						}
					}
				}
				
				if(!condicaoExiste){
					logarExclusaoCondicaoContratual(condContrApolice.getCdClausula(), produto, endosso, alteracoesEndossoList, user);
				}
			}
		}
		//2 - fim
	}
	
	private boolean isCondicaoContratualEquals(CondContratualApolice condContrApolice, CondicaoContratualCotacao condContrEndosso){
		return AssertUtils.compareNull(condContrApolice.getCodigoGrupoRamo(), condContrEndosso.getCodigoGrupoRamo()) && 
				condContrEndosso.getCodigoRamoClausula() != null && 
				AssertUtils.compareNull(condContrApolice.getCdRamoClausula(), condContrEndosso.getCodigoRamoClausula().longValue()) &&
				AssertUtils.compareNull(condContrApolice.getCdClausula(), condContrEndosso.getCodigoClausula());
	}
	
	private void logarInclusaoCondicaoContratual(String codigoClausula, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){

		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, TipoMensagemEndossoEnum.INC_CLAUSULA, codigoClausula.toString(), user));
	}
	
	private void logarExclusaoCondicaoContratual(String codigoClausula, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){

		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, TipoMensagemEndossoEnum.EXC_CLAUSULA, codigoClausula.toString(), user));
	}
	
	private void compararParametrosCodigoVersao(Long parametro1, Long parametro2, String codigoClausula, Integer codigoGrupoRamo, Long codigoRamo, TipoMensagemEndossoEnum tipoMensagem, String descricaoParametro, Produto produto, Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		if(!AssertUtils.compareNull(parametro1, parametro2)){
			StringBuilder descricaoAlteracao = new StringBuilder();
			descricaoAlteracao.append(descricaoParametro);
			descricaoAlteracao.append(parametro1);
			descricaoAlteracao.append(" alterada p/ ");
			descricaoAlteracao.append(parametro2);
			descricaoAlteracao.append(" da cláusula ");
			descricaoAlteracao.append(codigoClausula);
			descricaoAlteracao.append(" do ramo ");
			descricaoAlteracao.append(StringUtils.leftPad(codigoGrupoRamo.toString(), 2, '0'));
			descricaoAlteracao.append(codigoRamo);
			alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(produto, endosso, tipoMensagem, descricaoAlteracao.toString(), user));
		}
	}
}
