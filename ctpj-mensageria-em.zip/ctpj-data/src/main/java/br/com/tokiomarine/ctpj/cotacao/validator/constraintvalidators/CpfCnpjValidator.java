package br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators;

import java.lang.reflect.Field;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ValidationException;

import br.com.tokiomarine.ctpj.cotacao.validator.constraint.CpfCnpj;

/**
 * Validador para a anotação de CpfCnpj
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class CpfCnpjValidator implements ConstraintValidator<CpfCnpj, Object>{

	private String cnpjKey;
	private String cpfKey;
	private String valueFieldName;
	private String keyFieldName;

	@Override
	public void initialize(CpfCnpj annotation) {
		cnpjKey = annotation.cnpjKey();
		cpfKey = annotation.cpfKey();
		valueFieldName = annotation.valueField();
		keyFieldName = annotation.keyField();		
	}

	@Override
	public boolean isValid(Object obj, ConstraintValidatorContext context) {
		Class<? extends Object> clazz = obj.getClass();
		
		try {
			
			if(cnpjKey == null || cpfKey == null || valueFieldName == null || keyFieldName == null || cnpjKey.isEmpty() || cpfKey.isEmpty() || valueFieldName.isEmpty() || keyFieldName.isEmpty())
				return true; //não valida

			String value = getFieldValue(clazz, obj, valueFieldName);
			String key = getFieldValue(clazz, obj, keyFieldName);

			if(value == null || key == null || value.isEmpty())
				return true; //não valida
			
			if (key.equals(cnpjKey)) {				
				return ValidaCpfCnpj.isValidCNPJ(value);
			}

			if (key.equals(cpfKey)) {				
				return ValidaCpfCnpj.isValidCPF(value);
			}

			return false;

		} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			throw new ValidationException("Ocorreu um erro durante a validação do CPF/CNPJ", e);
		}
		
	}
	
	private String getFieldValue(Class<? extends Object> clazz, Object obj, String fieldName) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
		Field field = clazz.getDeclaredField(fieldName);
		field.setAccessible(true);
		return (String) field.get(obj);
	}
	
	

}
