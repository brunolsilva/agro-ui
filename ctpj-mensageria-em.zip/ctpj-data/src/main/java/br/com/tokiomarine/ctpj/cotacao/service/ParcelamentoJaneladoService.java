package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.repository.OpcaoPactoPagtoCotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ParcelamentoJaneladoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.ParcelamentoJanelado;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.util.DateUtil;

@Transactional(rollbackFor = {Exception.class})
@Service
public class ParcelamentoJaneladoService {

	private static Logger logger = LogManager.getLogger(ParcelamentoJaneladoService.class);

	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private OpcaoPactoPagtoCotacaoRepository opcaoPactoPagtoCotacaoRepository;

	@Autowired
	private ParcelamentoJaneladoRepository parcelamentoJaneladoRepository;

//	public static void main(String[] args) {
//		try {
//			/*OpcaoParcelamento opcaoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao);*/
//			OpcaoParcelamento opcaoSelecionada = new OpcaoParcelamento();
//			opcaoSelecionada.setIdEntrada(SimNaoEnum.SIM);
//			Integer codigoFormaPagamento = 1;
//			Integer codigoFormaParcelamento = 10;
//			Integer numeroDias = 7;
//			Integer quantidadeParcelas = 10;
//			Date dataVencimentoParcela = null;
//			List<Date> datas = new ArrayList<>();
//			Date dataEmissao = new Date();
//			for(int i = 0; i < quantidadeParcelas; i++) {
//				if(i == 0 && SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
//					datas.add(opcaoSelecionada.getDataVencimentoParcela());//READONLY
//				} else {
//					System.out.println(i);
//					if(dataVencimentoParcela != null) {
//						if(SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
//							datas.add(DateUtils.addMonths(dataVencimentoParcela, i - 1));
//						} else {
//							datas.add(DateUtils.addMonths(dataVencimentoParcela, i));
//						}
//					} else {
//						if(SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
//							datas.add(DateUtils.addDays(new Date(), i * 30));
//						} else {
//							datas.add(DateUtils.addDays(new Date(), (i+1) * 30));
//						}
//					}
//				}
//			}
//			System.out.println(datas);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
	public List<ParcelamentoJanelado> calcularSugestoes(Cotacao cotacao) throws ServiceException {
		try {
			OpcaoParcelamento opcaoSelecionada = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao.getSequencialCotacaoProposta());
			Integer quantidadeParcelas = opcaoSelecionada.getQuantidadeParcelas();
			Date dataVencimentoParcela = opcaoSelecionada.getDataVencimentoParcela();
			
			Date dataReferencia = cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE
					? new Date()
					: new Date();
			List<ParcelamentoJanelado> parcelamentos = new ArrayList<>();
			for(int i = 0; i < quantidadeParcelas; i++) {
				Date vencimento = null;
				if(i == 0 && SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
					vencimento = opcaoSelecionada.getDataVencimentoParcela();
					setVencimento(parcelamentos, vencimento, i + 1, opcaoSelecionada);
				} else {
					if(opcaoSelecionada.getDataVencimentoParcela() != null) {
						//if(SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
							//vencimento = DateUtils.addMonths(dataVencimentoParcela, i - 1);
						//} else {
							vencimento = DateUtils.addMonths(dataVencimentoParcela, i);
						//}
						setVencimento(parcelamentos, vencimento, i + 1, opcaoSelecionada);
					} else {
						if(SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
							vencimento = DateUtils.addDays(dataReferencia, i * 30);
						} else {
							vencimento = DateUtils.addDays(dataReferencia, (i + 1) * 30);
						}
						setVencimento(parcelamentos, vencimento, i + 1, opcaoSelecionada);
					}
				}
			}
			return parcelamentos;
		} catch (Exception e) {
			logger.error("Erro ao calcular sugestoes " + cotacao.getSequencialCotacaoProposta(), e);
			throw new ServiceException("Erro ao calcular sugestoes " + cotacao.getSequencialCotacaoProposta(), e);
		}
	}

	public List<ParcelamentoJanelado> calcularQuantidadeMaximaParcelas(Cotacao cotacao, OpcaoParcelamento opcaoSelecionada) throws ServiceException {
		try {
			Integer quantidadeParcelas = opcaoSelecionada.getQuantidadeParcelas();
			Date dataVencimentoParcela = opcaoSelecionada.getDataVencimentoParcela();
			Date vencimentoProgramado = cotacao.getDataVencimentoProgramada();
			Date dataReferencia = (opcaoSelecionada.getDataVencimentoParcela() != null  && cotacao.getDataVencimentoProgramada() == null)
					? opcaoSelecionada.getDataVencimentoParcela()
					: cotacao.getDataVencimentoProgramada();

			List<ParcelamentoJanelado> parcelamentos = new ArrayList<>();

			for(int i = 0; i < quantidadeParcelas; i++) {
				Date vencimento = null;
				if(i == 0 && SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
					vencimento = dataVencimentoParcela;
					setVencimento(parcelamentos, vencimento, i + 1, opcaoSelecionada);
				} else {
					if ((vencimentoProgramado != null && opcaoSelecionada.getIdEntrada() == SimNaoEnum.SIM
							&& (i + 1) == 2)
							|| (vencimentoProgramado != null && opcaoSelecionada.getIdEntrada() == SimNaoEnum.NAO
									&& (i + 1) == 1)) {
						setVencimento(parcelamentos, vencimentoProgramado, i + 1, opcaoSelecionada);
					} else {
						if(SimNaoEnum.SIM == opcaoSelecionada.getIdEntrada()) {
							int index = i;
							if(opcaoSelecionada.getDataVencimentoParcela() != null  && cotacao.getDataVencimentoProgramada() != null) {
								index = i - 1;
							}
							vencimento = DateUtils.addMonths(dataReferencia, index);
							System.out.println(vencimento + " 1");
							System.out.println(index);
						} else {
							vencimento = DateUtils.addMonths(dataReferencia, (i));
							System.out.println(vencimento + " 0");
						}
						setVencimento(parcelamentos, vencimento, i + 1, opcaoSelecionada);
					}
				}
			}

			return parcelamentos;
		} catch (Exception e) {
			logger.error("Erro ao calcular sugestoes " + cotacao.getSequencialCotacaoProposta(), e);
			throw new ServiceException("Erro ao calcular sugestoes " + cotacao.getSequencialCotacaoProposta(), e);
		}
	}

	public List<Validacao> validar(Cotacao cotacao, List<ParcelamentoJanelado> parcelas) throws ServiceException {
		try {
			List<Validacao> validacoes = new ArrayList<>();
			Integer diasMinimo = 7;
			Integer diasMaximo = 60;
			Date dataReferencia = cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE
					? new Date()
					: new Date();
			for(ParcelamentoJanelado p: parcelas) {
				Date vencimento = p.getDataVencimentoParcela();
				if(vencimento == null) {
					validacoes.add(new Validacao("Favor preencher a data de vencimento da parcela " + p.getNumeroParcela()));
				} else {
					if(p.getNumeroParcela() == 1 && p.getIdEntrada() == SimNaoEnum.NAO) {
						validaPrimeiraParcela(validacoes, diasMinimo, diasMaximo, dataReferencia, p, vencimento);
					} else {
						validaDemais(cotacao, validacoes, p, vencimento);
					}

					if(compareToDatasTruncadas(p.getDataVencimentoParcela(), dataReferencia) < 0) {
						validacoes.add(new Validacao(String.format(
								"A data de vencimento da parcela %s está menor que o mínimo permitido (%s)",
								p.getNumeroParcela(), DateUtil.formataSemHora(cotacao.getDataInicioVigencia()))));
					}
				}
			}

			if(validacoes.isEmpty()) {
				for(int i = 0; i < parcelas.size(); i++) {
					ParcelamentoJanelado parcelaAtual = parcelas.get(i);
					if((i) < parcelas.size() - 1) {
						ParcelamentoJanelado parcelaProxima = parcelas.get(i + 1);
						if (DateUtils.truncatedCompareTo(parcelaAtual.getDataVencimentoParcela(),
								parcelaProxima.getDataVencimentoParcela(), Calendar.MINUTE) >= 0) {
							validacoes.add(new Validacao("Favor verificar as datas das parcelas"));
						}
					}
				}
			}
			return validacoes;
		} catch (Exception e) {
			logger.error("Erro ao validar janelado " + cotacao.getSequencialCotacaoProposta(), e);
			throw new ServiceException("Erro ao validar janelado " + cotacao.getSequencialCotacaoProposta(), e);
		}
	}
	
	public void salvar(BigInteger cotacao, List<ParcelamentoJanelado> parcelas) throws ServiceException {
		try {
			parcelamentoJaneladoRepository.saveAll(parcelas);
		} catch (Exception e) {
			logger.error("Erro ao salvar janelado " + cotacao, e);
			throw new ServiceException("Erro ao salvar janelado " + cotacao, e);
		}
	}
	
	public List<ParcelamentoJanelado> listar(BigInteger numeroCotacao, Integer versaoCotacao) throws ServiceException {
		try {
			return parcelamentoJaneladoRepository.listar(numeroCotacao, versaoCotacao);
		} catch (Exception e) {
			logger.error("Erro ao salvar janelado " + numeroCotacao, e);
			throw new ServiceException("Erro ao salvar janelado " + numeroCotacao, e);
		}
	}
	
	private void validaDemais(Cotacao cotacao, List<Validacao> validacoes, ParcelamentoJanelado p, Date vencimento) {
		Date dataTerminoVigencia = opcaoPactoPagtoCotacaoRepository.findMinDataTermino(cotacao.getSequencialCotacaoProposta());
		Date dataMinimoTerminoVigencia = DateUtils.addDays(dataTerminoVigencia,-30);
		if(compareToDatasTruncadas(vencimento, dataMinimoTerminoVigencia) > 0) {
			validacoes.add(new Validacao(String.format(
					"A data de vencimento da parcela %s não pode ser maior que 30 dias do término de vigencia (%s)",
					p.getNumeroParcela(), DateUtil.formataSemHora(dataTerminoVigencia))));
		}
	}

	private void validaPrimeiraParcela(List<Validacao> validacoes, Integer diasMinimo, Integer diasMaximo, Date dataReferencia,
			ParcelamentoJanelado p, Date vencimento) {
		Date dataMinima = DateUtils.addDays(dataReferencia, diasMinimo);
		if(compareToDatasTruncadas(vencimento, dataMinima) < 0) {
			validacoes.add(new Validacao(String.format(
					"A data de vencimento da parcela %s está menor que o permitido (%s)",
					p.getNumeroParcela(), DateUtil.formataSemHora(dataMinima))));
		} else {
			Date dataMaxima = DateUtils.addDays(dataReferencia, diasMaximo);
			if(compareToDatasTruncadas(vencimento, dataMaxima) > 0) {
				validacoes.add(new Validacao(String.format(
						"A data de vencimento da parcela %s está maior que o permitido (%s)",
						p.getNumeroParcela(), DateUtil.formataSemHora(dataMaxima))));
			}
		}
	}

	private ParcelamentoJanelado setVencimento(List<ParcelamentoJanelado> parcelamentos, Date vencimento,
			int numeroParcela, OpcaoParcelamento opcaoSelecionada) {
		ParcelamentoJanelado pj = new ParcelamentoJanelado();
		pj.setDataVencimentoParcela(vencimento);
		pj.setNumeroParcela(numeroParcela);
		pj.setIdEntrada(opcaoSelecionada.getIdEntrada());
		parcelamentos.add(pj);
		return pj;
	}

	private int compareToDatasTruncadas(Date data1, Date data2) {
		return DateUtils.truncatedCompareTo(data1, data2, Calendar.MINUTE);
	}
	
	public static void main(String[] args) {
		Cotacao cotacao = new Cotacao();
		cotacao.setDataVencimentoProgramada(DateUtil.parseAnoMesDiaComBarra("12/04/2020"));
		OpcaoParcelamento opcaoSelecionada = new OpcaoParcelamento();
		opcaoSelecionada.setQuantidadeParcelas(9);
		opcaoSelecionada.setIdEntrada(SimNaoEnum.SIM);
		opcaoSelecionada.setDataVencimentoParcela(DateUtil.parseAnoMesDiaComBarra("12/03/2020"));
		try {
			List<ParcelamentoJanelado> calcularQuantidadeMaximaParcelas = new ParcelamentoJaneladoService().calcularQuantidadeMaximaParcelas(cotacao, opcaoSelecionada);
			for(ParcelamentoJanelado p: calcularQuantidadeMaximaParcelas) { 
				System.out.println(p.getDataVencimentoParcela());
			}
		} catch (ServiceException e) {
			e.printStackTrace();
		}
	}
}
