package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoberturaBasicaHierarquiaView implements Serializable {

	private static final long serialVersionUID = -6110332746368311366L;

	private Integer coberturaBasica;
	private List<CoberturaHierarquiaView> filhas;

	public Integer getCoberturaBasica() {
		return coberturaBasica;
	}

	public void setCoberturaBasica(Integer coberturaBasica) {
		this.coberturaBasica = coberturaBasica;
	}

	public List<CoberturaHierarquiaView> getFilhas() {
		return filhas;
	}

	public void setFilhas(List<CoberturaHierarquiaView> filhas) {
		this.filhas = filhas;
	}
}