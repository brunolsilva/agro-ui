package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilCalculoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilComercialRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCoberturaLimiteIs;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoUsuario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCorretor;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;

@Service
public class PerfilComercialService {

	private static Logger logger = LogManager.getLogger(PerfilComercialService.class);

	@Autowired
	private PerfilComercialRepository perfilComercialRepository;

	@Autowired
	private PerfilCalculoRepository perfilCalculoRepository;

	public PerfilComercialCorretor findPerfilComercial(Long corretor,Integer produto,Date dataCotacao) throws ServiceException {
		try {
			return perfilComercialRepository.findPerfilComercial(corretor,produto,dataCotacao);
		} catch (Exception e) {
			logger.error(String.format("Erro ao buscar o perfil Comercial do Corretor: %s", corretor), e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
	
	public PerfilCalculoUsuario findPerfilCalculo(Long corretor,Date dataCotacao) throws ServiceException {
		try {
			return perfilCalculoRepository.findPerfilCalculo(corretor, dataCotacao);
		} catch (Exception e) {
			logger.error(String.format("Erro ao buscar o perfil PerfilCalculoUsuario do Corretor: %s", corretor), e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	public boolean hasPerfilCalculo(Integer usuario, Date dataCotacao) throws ServiceException {
		try {
			PerfilCalculoUsuario perfilCalculoUsuario = perfilCalculoRepository.findPerfilCalculo(usuario.longValue(),dataCotacao);
			if(perfilCalculoUsuario != null) {
				return true; 
			}
			return false;
		} catch (Exception e) {
			logger.error(String.format("Erro ao buscar o perfil Comercial do Corretor: %s", usuario), e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
	
	public boolean hasPerfilComercial(GrupoUsuarioEnum grupoUsuario) throws ServiceException {
		try {
			return grupoUsuario != null && (grupoUsuario.equals(GrupoUsuarioEnum.GERENTE_COMERCIAL) 
					|| grupoUsuario.equals(GrupoUsuarioEnum.ASSISTENTE_COMERCIAL) 
					|| grupoUsuario.equals(GrupoUsuarioEnum.GERENTE_SUCURSAL)
					|| grupoUsuario.equals(GrupoUsuarioEnum.DIGITADOR));
		} catch (Exception e) {
			logger.error(String.format("Erro ao buscar o perfil Comercial Grupo usuário: %s", grupoUsuario), e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	public Map<Integer,Object> valoresPerfil(Long corretor,Integer produto, Date dataCotacao) {
		PerfilComercialCorretor perfilComercialCorretor = perfilComercialRepository.findPerfilComercial(corretor,produto,dataCotacao);
		if(perfilComercialCorretor != null) {
			Long perfilComercial = perfilComercialCorretor.getPerfilComercial();
			if(perfilComercial != null) {
				PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(corretor,produto,dataCotacao);
				Map<Integer,Object> map = new HashMap<>();
				map.put(1,perfilComercialCondicao.getPercentualComissaoPadrao());
				map.put(2,perfilComercialCondicao.getPercentualDescontoPadrao());
				map.put(3,perfilComercialCondicao.getNumeroDiasValidadeCotacao());
				if(perfilComercialCondicao.getPercentualDescontoMinimo().compareTo(BigDecimal.ZERO) == 0
						&& perfilComercialCondicao.getPercentualDescontoMaximo().compareTo(BigDecimal.ZERO) == 0) {
					map.put(4, false);
				}
				if(perfilComercialCondicao.getTipoSeguro() != null && !perfilComercialCondicao.getTipoSeguro().isEmpty()) {
					map.put(5, perfilComercialCondicao.getTipoSeguro());
				}
				return map;
			}
		} else {
			PerfilCalculoUsuario perfilCalculoUsuario = perfilCalculoRepository.findPerfilCalculo(corretor,dataCotacao);
			if(perfilCalculoUsuario != null) {
				Long perfilCalculo = perfilCalculoUsuario.getPerfilCalculo();
				if(perfilCalculo != null) {
					PerfilCalculoCondicao perfilCalculoCondicao = perfilCalculoRepository.findPerfilCalculoCondicao(corretor, produto,dataCotacao);
					if(perfilCalculoCondicao != null){
						Map<Integer,Object> map = new HashMap<>();
						map.put(1,perfilCalculoCondicao.getPercentualComissaoPadrao());
						map.put(2,perfilCalculoCondicao.getPercentualDescontoPadrao());
						map.put(3,perfilCalculoCondicao.getNumeroDiasValidadeCotacao());
						if(perfilCalculoCondicao.getPercentualDescontoMinimo().compareTo(BigDecimal.ZERO) == 0
								&& perfilCalculoCondicao.getPercentualDescontoMaximo().compareTo(BigDecimal.ZERO) == 0) {
							map.put(4, false);
						}
						if(perfilCalculoCondicao.getTipoSeguro() != null && !perfilCalculoCondicao.getTipoSeguro().isEmpty()) {
							map.put(5, perfilCalculoCondicao.getTipoSeguro());
						}
						return map;
					}
				}
			}
		}

		return Collections.emptyMap();
	}

	public Map<Integer, BigDecimal> valorComissaoMinimoMaximo(Long corretor,Integer produto, Date dataCotacao) {
		PerfilComercialCorretor perfilComercialCorretor = perfilComercialRepository.findPerfilComercial(corretor,produto,dataCotacao);
		if(perfilComercialCorretor != null) {
			Long perfilComercial = perfilComercialCorretor.getPerfilComercial();
			if(perfilComercial != null) {
				PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(corretor,produto,dataCotacao);
				Map<Integer,BigDecimal> map = new HashMap<>();
				map.put(1,perfilComercialCondicao.getPercentualComissaoMinima());
				map.put(2,perfilComercialCondicao.getPercentualComissaoMaxima());
				map.put(3,perfilComercialCondicao.getPercentualDescontoMinimo());
				map.put(4,perfilComercialCondicao.getPercentualDescontoMaximo());
				map.put(5,perfilComercialCondicao.getPercentualComissaoMaximaComDesconto());
				return map;
			}
		} else {
			PerfilCalculoUsuario perfilCalculoUsuario = perfilCalculoRepository.findPerfilCalculo(corretor,dataCotacao);
			if(perfilCalculoUsuario != null) {
				Long perfilCalculo = perfilCalculoUsuario.getPerfilCalculo();
				if(perfilCalculo != null) {
					PerfilCalculoCondicao perfilCalculoCondicao = perfilCalculoRepository.findPerfilCalculoCondicao(corretor,produto,dataCotacao);
					if(perfilCalculoCondicao != null){
						Map<Integer,BigDecimal> map = new HashMap<>();
						map.put(1,perfilCalculoCondicao.getPercentualComissaoMinima());
						map.put(2,perfilCalculoCondicao.getPercentualComissaoMaxima());
						map.put(3,perfilCalculoCondicao.getPercentualDescontoMinimo());
						map.put(4,perfilCalculoCondicao.getPercentualDescontoMaximo());
						map.put(5,perfilCalculoCondicao.getPercentualComissaoMaximaComDesconto());
						return map;
					}
				}
			}
		}

		return Collections.emptyMap();
	}
	
	public List<TipoSeguroEnum> getTiposSeguroDesconto(Long corretor,Integer produto, Date dataCotacao) {
		PerfilComercialCorretor perfilComercialCorretor = perfilComercialRepository.findPerfilComercial(corretor,produto,dataCotacao);
		if(perfilComercialCorretor != null) {
			Long perfilComercial = perfilComercialCorretor.getPerfilComercial();
			if(perfilComercial != null) {
				PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(corretor,produto,dataCotacao);
				return perfilComercialCondicao.getTipoSeguro() != null ? perfilComercialCondicao.getTipoSeguro() : Collections.emptyList();
			}
		} else {
			PerfilCalculoUsuario perfilCalculoUsuario = perfilCalculoRepository.findPerfilCalculo(corretor,dataCotacao);
			if(perfilCalculoUsuario != null) {
				Long perfilCalculo = perfilCalculoUsuario.getPerfilCalculo();
				if(perfilCalculo != null) {
					PerfilCalculoCondicao perfilCalculoCondicao = perfilCalculoRepository.findPerfilCalculoCondicao(corretor,produto,dataCotacao);
					if(perfilCalculoCondicao != null){
						return perfilCalculoCondicao.getTipoSeguro() != null ? perfilCalculoCondicao.getTipoSeguro() : Collections.emptyList();
					}
				}
			}
		}

		return Collections.emptyList();
	}

	@LogPerformance
	public List<PerfilCalculoCoberturaLimiteIs> findCoberturaLimiteIs(Cotacao cotacao,List<Integer> coberturas) {
		return perfilCalculoRepository.findCoberturaLimiteIs(cotacao,coberturas);
	}
	
	public void save(PerfilCalculoUsuario perfilCalculoUsuario) {
		perfilCalculoRepository.save(perfilCalculoUsuario);
	}
	
	public void save(PerfilComercialCorretor perfilComercialCorretor) {
		perfilCalculoRepository.save(perfilComercialCorretor);
	}
	
	@LogPerformance
	public List<PerfilCalculoCoberturaLimiteIs> findCoberturaLimiteIs(Cotacao cotacao,List<Integer> coberturas, User user) {
		return perfilCalculoRepository.findCoberturaLimiteIs(cotacao,coberturas,user);
	}
}