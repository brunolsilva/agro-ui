package br.com.tokiomarine.ctpj.integracao.backoffice.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsultaCreditoDisponivelResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6612123223826100824L;

	@JsonProperty("codigoRetorno")
	private String codigoRetorno;

	@JsonProperty("descricaoCodigoRetorno")
	private String descricaoCodigoRetorno;

	@JsonProperty("p_mensagem")
	private String mensagem;

	@JsonProperty("p_mens")
	private String mensagemErro;

	@JsonProperty("p_tb_lista_credito")
	private List<CreditoDisponivelResponse> listCreditoDisponivelResponse;

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getMensagemErro() {
		return mensagemErro;
	}

	public void setMensagemErro(String mensagemErro) {
		this.mensagemErro = mensagemErro;
	}

	public List<CreditoDisponivelResponse> getListCreditoDisponivelResponse() {
		return listCreditoDisponivelResponse;
	}

	public void setListCreditoDisponivelResponse(List<CreditoDisponivelResponse> listCreditoDisponivelResponse) {
		this.listCreditoDisponivelResponse = listCreditoDisponivelResponse;
	}

	@Override
	public String toString() {
		return "ConsultaCreditoDisponivelResponse [codigoRetorno=" + codigoRetorno + ", descricaoCodigoRetorno=" + descricaoCodigoRetorno + 
				", mensagem=" + mensagem + ", mensagemErro=" + mensagemErro + ", listCreditoDisponivelResponse=" + listCreditoDisponivelResponse + "]";
	}
	
}
