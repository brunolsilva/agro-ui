package br.com.tokiomarine.ctpj.cotacao.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.componente.utils.EmailUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaAdicionar;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaExclusao;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ProcessaLogin;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.cotacao.validation.BaseCoberturaValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.CotacaoValidator;
import br.com.tokiomarine.ctpj.cotacao.validation.ResseguroFacultativoLimiteService;
import br.com.tokiomarine.ctpj.cotacao.validation.ValidationRegistry;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.dto.CotacaoComProduto;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.OrigemContratacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoApoliceEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.CoberturaAgrupamentoRestricao;
import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCoberturaLimiteIs;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoUsuario;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCorretor;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracValorAtributo;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoSusep;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.PrazoVigenciaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoISEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CorretorRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoCaracValorAtributoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CoberturaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.infra.type.CTPJInfraCommons;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.integracao.service.CotacaoDolarService;
import br.com.tokiomarine.ctpj.integracao.service.CrivoService;
import br.com.tokiomarine.ctpj.jms.response.CotacaoBatchResponse;
import br.com.tokiomarine.ctpj.mapper.CotacaoParaSolicitacaoMapper;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.sct.form.EmailContatoSCT;
import br.com.tokiomarine.ctpj.sct.request.SolicitacaoCotacaoFakeCTPJ;
import br.com.tokiomarine.ctpj.sct.response.ConsultaCotacaoSCTResponse;
import br.com.tokiomarine.ctpj.sct.response.MensagemCTPJ;
import br.com.tokiomarine.ctpj.sct.response.ParecerInterfaceRetorno;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.sct.service.SCTService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.service.MailUtilService;
import br.com.tokiomarine.ctpj.type.RestricaoCrivoEnum;
import br.com.tokiomarine.ctpj.util.DateUtil;
import br.com.tokiomarine.ctpj.util.RestTemplateUtil;
import br.com.tokiomarine.ctpj.validation.ValidationComponent;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class CotacaoService {

	private static Logger logger = LogManager.getLogger(CotacaoService.class);

	private static final Integer VS_COTAC_FIRST = 1;

	@Autowired
	private CotacaoRepository repository;

	@Autowired
	private ValidationComponent validationComponent;

	@Autowired
	private CrivoService crivoService;

	@Autowired
	private ProdutoService produtoService;

	@Autowired
	private DuplicarCotacaoService duplicarCotacaoService;

	@Autowired
	private NovaVersaoCotacaoService novaVersaoCotacaoService;

	@Autowired
	private CotacaoDolarService cotacaoDolarService;

	@Autowired
	private PerfilComercialService perfilComercialService;

	@Autowired
	private SCTService sctService;
	
	@Autowired
	private MailUtilService mailUtilService;
	
	@Autowired
	private EndossoService endossoService;
	
	@Autowired
	private BaseService baseService;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private CorretorRepository corretorRepository;
	
	@Autowired
	private ProdutoCaracValorAtributoRepository produtoCaracValorAtributoRepository;
	
	@Autowired
	private RenovacaoService renovacaoService;
	
	@Autowired
	private ResseguroFacultativoLimiteService resseguroFacultativoLimiteService;
	
	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;
	
	@Autowired
	private CoberturaService coberturaService;
	
	private RestTemplate restTemplate = RestTemplateUtil.restTemplate(2000, 2000);
	
	private List<String> tiposSeguro = Arrays.asList("N","O","R");
	private List<Long> situacoes = Arrays.asList(
			CodigoSituacaoEnum.RECUSADA_PELO_COMERCIAL_314.getSituacao(),
			CodigoSituacaoEnum.CANCELADA_320.getSituacao(),
			CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao(),
			CodigoSituacaoEnum.RECUSADA_PELO_COMERCIAL_314.getSituacao(),
			CodigoSituacaoEnum.FECHADAS_PELO_ROBO_AUTOMATICO_433.getSituacao());
	
	@LogPerformance
	public CotacaoBatchResponse processaLoginBatch(SolicitacaoCotacao solicitacaoCotacao) throws Exception {
		CtpjToken token = new CtpjToken();
		User user = new User();
		CotacaoBatchResponse cotacaoBatchResponse = new CotacaoBatchResponse();
		
		token.setSolicitacaoCotacao(solicitacaoCotacao);
		user.setGrupoUsuario(GrupoUsuarioEnum.SUBSCRITOR_DEMAIS_RAMOS);
		user.setCdUsuro(CTPJInfraCommons.USER_INTERFACE.number());
		ProcessaLogin processaLogin = this.processaLogin(token,user);
		
		if(processaLogin.isSucesso()){
			cotacaoBatchResponse.setSucesso(true);
			cotacaoBatchResponse.setSequencialCotacaoProposta(processaLogin.getCotacao().getSequencialCotacaoProposta());
		}else{
			List<Mensagem> mensagens = new ArrayList<>();						
			Mensagem mensagem = new Mensagem();
			mensagem.setCodigo(1);
			mensagem.setDescricao(processaLogin.getMensagens().toString());
			mensagens.add(mensagem);
			cotacaoBatchResponse.setSucesso(false);
			cotacaoBatchResponse.setMensagens(mensagens);
		}
		return cotacaoBatchResponse;
	}
	
	@LogPerformance
	public ProcessaLogin processaLogin(CtpjToken token, User user) throws ServiceException {

		ProcessaLogin processaLogin = new ProcessaLogin();
		Cotacao cotacao = null;
		processaLogin.setSucesso(true);
		StringBuilder mensagens = new StringBuilder();
		processaLogin.setMensagens(mensagens);

		try {

			boolean hasPerfilCalculo = perfilComercialService.hasPerfilCalculo(user.getCdUsuro(),new Date());
			boolean hasPerfilComercial = perfilComercialService.findPerfilComercial(
				user.getCdUsuro().longValue(),
				token.getSolicitacaoCotacao().getCdPrdut(),
				new Date()) != null ? true : false;
			boolean isUsuarioSucursal = perfilComercialService.hasPerfilComercial(user.getGrupoUsuario());
			if(isUsuarioSucursal) {
				processaLogin.setBloqueada(true);
				processaLogin.setExibeImpressos(true);
			} else if (!hasPerfilCalculo) {
				if(user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR) {
					PerfilCalculoUsuario perfilCalculoUsuario = new PerfilCalculoUsuario();
					perfilCalculoUsuario.setDataAtualizacao(new Date());
					perfilCalculoUsuario.setDataInicioVigencia(DateUtils.addDays(new Date(), -30));
					perfilCalculoUsuario.setGrupoUsuario(GrupoUsuarioEnum.CORRETOR);
					perfilCalculoUsuario.setPerfilCalculo(1001L);
					perfilCalculoUsuario.setUsuario(user.getCdUsuro().longValue());
					perfilCalculoUsuario.setUsuarioAtualizacao("CARGA");
					perfilComercialService.save(perfilCalculoUsuario);
				} else {
					processaLogin.getMensagens().append("Usuário sem perfil cadastrado. Entrar em contato com a Seguradora!");
					processaLogin.getMensagens().append(user);
					processaLogin.setSucesso(false);
				}
			}
			
			if(!hasPerfilComercial && SecurityUtils.isCorretor()) {
				PerfilComercialCorretor perfilComercialCorretor = new PerfilComercialCorretor();
				perfilComercialCorretor.setDataAtualizacao(new Date());
				perfilComercialCorretor.setDataInicioVigencia(DateUtils.addDays(new Date(), -30));
				perfilComercialCorretor.setPerfilComercial(1L);
				perfilComercialCorretor.setCorretor(user.getCdUsuro().longValue());
				perfilComercialCorretor.setProduto(token.getSolicitacaoCotacao().getCdPrdut());
				perfilComercialCorretor.setUsuarioAtualizacao("CARGA");
				perfilComercialService.save(perfilComercialCorretor);
			}
			
			if (token != null && token.getSolicitacaoCotacao() != null) {
				Corretor corretor = corretorRepository.findCorretorByCodigo(token.getSolicitacaoCotacao().getCdCrtorAcsel());
				if(corretor == null) {
					corretor = new Corretor();
					corretor.setCodigo(token.getSolicitacaoCotacao().getCdCrtorAcsel());
					corretor.setNome(token.getSolicitacaoCotacao().getNmCrtorPlatf());
					corretor.setRegistroSusep(token.getSolicitacaoCotacao().getIdRegistroSusep());
					corretor.setDataInicioVigencia(new Date());
					corretor.setDataAtualizacao(new Date());
					corretorRepository.save(corretor);
				}
			}

			if (token == null || token.getSolicitacaoCotacao() == null) {

				processaLogin.getMensagens().append("CtpjToken não presente na Session processo abortado");
				processaLogin.setSucesso(false);

			} else if (processaLogin.isSucesso()) {
				if("S".equals(token.getSolicitacaoCotacao().getIcPossuiAnaliseTecnica()) && SecurityUtils.isCorretor()
						&& !Integer.valueOf(310).equals(token.getSolicitacaoCotacao().getCdSituc())) {
					processaLogin.setBloqueada(true);
					processaLogin.setExibeImpressos(false);
				}
				/*
				 * Tipo de Solicitacao de Cotacao
				 * */
				switch (token.getSolicitacaoCotacao().getIcTipoSegur()) {
					case ENDOSSO:
						cotacao = processaSeguroEndosso(token,user,processaLogin);
						break;
					case RENOVACAO_TOKIO:
						cotacao = processaSeguroRenovacaoTokio(token,user,processaLogin);
						break;
					case NOVO:
						cotacao = processaSeguroNovo(token,user,processaLogin);
						break;
					case RENOVACAO_CONGENERE:
						cotacao = processaSeguroRenovacaoCongenere(token,user,processaLogin);
						break;
				}

			}

			if (processaLogin.isSucesso()) {
				if (!crivoService.validaCrivoCapa(token,cotacao,processaLogin,user)
						&& user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR
						&& cotacao != null
						&& TipoSeguroEnum.RENOVACAO_TOKIO != cotacao.getIdTipoSeguro()) {
					processaLogin.getMensagens().append(RestricaoCrivoEnum.getByCodigo(processaLogin.getCodigoRetornoCrivo()).getMensagem());
					processaLogin.setSucesso(false);
					processaLogin.setPossuiRestricaoCrivo(true);
				} else {
					processaLogin.setCotacao(cotacao);
				}
			}

		} catch (HibernateException re) {
			logger.error("Erro ao Processar Entrada via SCT: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao Processar Entrada via SCT: ",e);
			throw new ServiceException(e.getMessage(),e);
		}

		return processaLogin;
	}

	private void verificaUsuario(SolicitacaoCotacao solicitacaoCotacao) throws ServiceException {
		Corretor corretor = corretorRepository.findCorretorByCodigo(solicitacaoCotacao.getCdCrtorAcsel());
		if(corretor == null) {
			corretor = new Corretor();
			corretor.setCodigo(solicitacaoCotacao.getCdCrtorAcsel());
			corretor.setNome(solicitacaoCotacao.getNmCrtorPlatf());
			corretor.setRegistroSusep(solicitacaoCotacao.getIdRegistroSusep());
			corretor.setDataInicioVigencia(new Date());
			corretor.setDataAtualizacao(new Date());
			corretorRepository.save(corretor);
		}
	}
	
	private Cotacao processaSeguroNovo(CtpjToken token,User user,ProcessaLogin processaLogin) throws Exception {
		return processaSeguroNovoRenovacaoCongenere(token,user,processaLogin);
	}
	
	private Cotacao processaSeguroRenovacaoCongenere(CtpjToken token,User user,ProcessaLogin processaLogin) throws Exception {
		
		SolicitacaoCotacao solicitacao = token.getSolicitacaoCotacao();
		
		/* Valida se o Bind de Solicitacao para cotacao Endosso foi OK */
		StringBuilder sbMsg = new StringBuilder();
		
		Cotacao cotacao = null;

		if(token.getSolicitacaoCotacao().getCdCiaSgdra() == null || solicitacao.getCdCiaSgdra() <= 0){
			sbMsg.append("cdCiaSgdra não informada!").append("\r");
		}
		
		if(token.getSolicitacaoCotacao().getNrApoliCongr()  == null  || solicitacao.getNrApoliCongr().isEmpty() ){
			sbMsg.append("nrApoliCongr não informada!").append("\r");
		}
		
		if (sbMsg.length() > 0) {
			processaLogin.setMensagens(sbMsg);
			processaLogin.setSucesso(false);
		} else {
			cotacao = this.processaSeguroNovoRenovacaoCongenere(token,user,processaLogin);
		}
		
		return cotacao;
		
	}

	private Cotacao processaSeguroNovoRenovacaoCongenere(CtpjToken token,User user,ProcessaLogin processaLogin) throws Exception {

		Cotacao cotacao;
			
		boolean duplicaCotacao = true;
		
		if (token.getSolicitacaoCotacao().getNrSolctCotacDupliAbetu() != null) {
			
			duplicaCotacao =  this.existeCotacaoDuplicada(token);
			logger.info("Cotação a duplicar já existe");
			logger.info("Cotação nova.......:	"+token.getSolicitacaoCotacao().getNrSolctCotac());
			logger.info("Cotação a duplicar.:	"+token.getSolicitacaoCotacao().getNrSolctCotacDupliAbetu());
			
		}
		
		if (!duplicaCotacao) {
			logger.info("Cotacao duplicada");

			cotacao = findCotacaoDuplicada(token);

			if (cotacao != null) {
				cotacao = this.duplicaCotacao(cotacao,token,user);
			} else {
				logger.error("Cotacao não encontrada.....: " + token.getSolicitacaoCotacao().getNrSolctCotacDupliAbetu());
				processaLogin.setSucesso(false);
			}

		} else if(processaLogin.isBloqueada() && !perfilComercialService.hasPerfilComercial(user.getGrupoUsuario())){
			cotacao = findCotacaoTelaByNumeroCotacaoBloqueada(token.getSolicitacaoCotacao().getNrSolctCotac());
		} else {
			cotacao = findCotacaoTelaByNumeroCotacao(token.getSolicitacaoCotacao().getNrSolctCotac());
		}

		Integer cdSituc = token.getSolicitacaoCotacao().getCdSituc();
		if (SecurityUtils.isCorretor() && cotacao != null && cotacao.getVersaoCotacaoProposta() > 1
				&& !Integer.valueOf(310).equals(cdSituc)) {
			cotacao = findCotacaoTelaByNumeroCotacaoBloqueada(token.getSolicitacaoCotacao().getNrSolctCotac());
		}
		
		if(cotacao != null && (cdSituc == 310 || cdSituc == 309)) {
			cotacao.setCodigoSituacao(cdSituc);
			cotacao.setNomeSituacao(CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cdSituc).getDescricao());
			cotacao = saveCotacao(cotacao);
		}

		cotacao = geraNovaVersaoContratacao(token, cotacao);

		if (cotacao == null) {

			this.ajustaDsEnderecoSegurado(token.getSolicitacaoCotacao());

			cotacao = CotacaoParaSolicitacaoMapper.INSTANCE.toCotacao(token.getSolicitacaoCotacao());
			if(token.getSolicitacaoCotacao().getIdDestinoEmissao() == DestinoEmissaoEnum.ACX) {
				cotacao.setIdDestinoEmissao(DestinoEmissaoEnum.ACX);
			} else {
				cotacao.setIdDestinoEmissao(null);
			}

			this.completarInfoCotacao(token,cotacao,user);

			/* Valida se o Bind de Solicitacao para cotacao foi OK */
			StringBuilder sbMsg = validationCotacao(cotacao);

			if (sbMsg != null) {
				processaLogin.setMensagens(sbMsg);
				processaLogin.setSucesso(false);
			} else {
				cotacao = saveCotacao(cotacao);
			}
		}

		return cotacao;

	}

	private Cotacao processaSeguroEndosso(CtpjToken token,User user,ProcessaLogin processaLogin) throws Exception {

		SolicitacaoCotacao solicitacao = token.getSolicitacaoCotacao();
		
		/* Valida se o Bind de Solicitacao para cotacao Endosso foi OK */
		StringBuilder sbMsg = new StringBuilder();
		
		if(StringUtils.isEmpty(solicitacao.getIdMongodb())){
			sbMsg.append("IdMongoDb não informado!").append("\r");
		} 
		
		if(solicitacao.getCdRamoPrdutApoliTmsrEndso() == null || solicitacao.getCdRamoPrdutApoliTmsrEndso() <= 0){
			sbMsg.append("CdRamoPrdutApoliTmsrEndso não informado!").append("\r");
		} 
		
		if(solicitacao.getCdApoliTmsrEndso() == null || solicitacao.getCdApoliTmsrEndso() <= 0){
			sbMsg.append("CdApoliTmsrEndso não informado!").append("\r");
		}
		
		if(solicitacao.getCdTipoEndosSsc() == TipoEndossoSctEnum.CANCELAMENTO_ENDOSSO_POR_FALTA_PAGAMENTO || solicitacao.getCdTipoEndosSsc() == TipoEndossoSctEnum.CANCELAMENTO_ENDOSSO_POR_MOTIVO_INTERNO) {
			if(solicitacao.getCdEndosEndso() == null || solicitacao.getCdEndosEndso() < 0){
				sbMsg.append("CdEndosEndso não informado!").append("\r");
			} 
			
			if(solicitacao.getCdTipoEndosEndso() == null || solicitacao.getCdTipoEndosEndso() < 0){
				sbMsg.append("CdTipoEndosEndso não informado!").append("\r");
			}
			
		}
		
		Cotacao cotacao = null;
		
		if (sbMsg.length() > 0) {
			processaLogin.setMensagens(sbMsg);
			processaLogin.setSucesso(false);
		} else {
			this.ajustaDsEnderecoSegurado(token.getSolicitacaoCotacao());
			cotacao = endossoService.consultaOuGeraEndosso(solicitacao);

			Integer cdSituc = token.getSolicitacaoCotacao().getCdSituc();
			if (SecurityUtils.isCorretor() && cotacao != null && cotacao.getVersaoCotacaoProposta() > 1
					&& !Integer.valueOf(310).equals(cdSituc)) {
				cotacao = findCotacaoTelaByNumeroCotacaoBloqueada(token.getSolicitacaoCotacao().getNrSolctCotac());
			}

			if(cotacao != null && (cdSituc == 310 || cdSituc == 309 || cdSituc == 320 || cdSituc == 314 || cdSituc == 308)) {
				cotacao.setCodigoSituacao(cdSituc);
				cotacao.setNomeSituacao(CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cdSituc).getDescricao());
				cotacao = saveCotacao(cotacao);
			}

			cotacao = geraNovaVersaoContratacao(token, cotacao);
		}

		return cotacao;

	}
	
	private Cotacao processaSeguroRenovacaoTokio(CtpjToken token,User user,ProcessaLogin processaLogin) throws Exception {

		SolicitacaoCotacao solicitacao = token.getSolicitacaoCotacao();
		
		/* Valida se o Bind de Solicitacao para cotacao Endosso foi OK */
		StringBuilder sbMsg = new StringBuilder();
		
		Cotacao cotacao = null;
		
		if(StringUtils.isEmpty(solicitacao.getIdMongodb())){
			sbMsg.append("IdMongoDb não informado!").append("\r");
		}
				
		if(token.getSolicitacaoCotacao().getCdRamoPrdutRenov() == null || solicitacao.getCdRamoPrdutRenov() <= 0){
			sbMsg.append("cdRamoPrdutRenov não informada!").append("\r");
		}
		
		if(token.getSolicitacaoCotacao().getCdApoliRenov()  == null  || solicitacao.getCdApoliRenov() <= 0){
			sbMsg.append("cdApoliRenov não informada!").append("\r");
		}
		
		
		if (sbMsg.length() > 0) {
			processaLogin.setMensagens(sbMsg);
			processaLogin.setSucesso(false);
		} else {
			this.ajustaDsEnderecoSegurado(token.getSolicitacaoCotacao());

			cotacao = renovacaoService.processaSeguroRenovacaoTokio(token,user,processaLogin);
			Integer produto = cotacao.getCodigoProduto();
			
			Integer cdSituc = token.getSolicitacaoCotacao().getCdSituc();
			if (SecurityUtils.isCorretor() && cotacao != null && cotacao.getVersaoCotacaoProposta() > 1
					&& !Integer.valueOf(310).equals(cdSituc)) {
				cotacao = findCotacaoTelaByNumeroCotacaoBloqueada(token.getSolicitacaoCotacao().getNrSolctCotac());
			}
			
			if(cotacao != null && (cdSituc == 310 || cdSituc == 309 || cdSituc == 320)) {
				cotacao.setCodigoSituacao(cdSituc);
				cotacao.setNomeSituacao(CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cdSituc).getDescricao());
				cotacao = saveCotacao(cotacao);
			}

			cotacao = geraNovaVersaoContratacao(token, cotacao);

			List<ProdutoValorCarac> observacao = caracteristicaService.getValoresCaracteristica(
					produto,Caracteristicas.OBSERVACAO_CAPA.codigo(),
					new Sort(Direction.ASC, "valorCaracteristica"));
			if(observacao != null && !observacao.isEmpty()) {
				cotacao.setDescricaoObservacao(observacao.get(0).getDescricaoValor());
			}
		}

		return cotacao;

	}

	private Cotacao geraNovaVersaoContratacao(CtpjToken token, Cotacao cotacaoUltimaVersao) throws ServiceException {
		Integer versaoContratacao = token.getSolicitacaoCotacao().getNrVrsaoPpotaEschi();

		if (versaoContratacao != null && cotacaoUltimaVersao != null
				&& !cotacaoUltimaVersao.getVersaoCotacaoProposta().equals(versaoContratacao)) {

			Cotacao cotacaoContratacao = findCotacaoByNrCotacAndVsCotac(cotacaoUltimaVersao.getNumeroCotacaoProposta(),
					versaoContratacao);

			if (cotacaoUltimaVersao.getSequencialCotacaoPropostaOrigem() != null && cotacaoUltimaVersao
					.getSequencialCotacaoPropostaOrigem().equals(cotacaoContratacao.getSequencialCotacaoProposta())) {
				return cotacaoUltimaVersao;
			} else {
				geraNovaVersao(cotacaoContratacao.getSequencialCotacaoProposta(), SecurityUtils.getCurrentUser(),
						false);
				cotacaoUltimaVersao = repository
						.findCotacaoTelaByNumeroCotacao(cotacaoUltimaVersao.getNumeroCotacaoProposta());
				if (cotacaoUltimaVersao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE) {
					if (cotacaoUltimaVersao.getIdPrazoVigencia() == PrazoVigenciaEnum.ANUAL) {
						cotacaoUltimaVersao.setDataInicioVigencia(new Date());
						cotacaoUltimaVersao.setDataFimVigencia(DateUtils.addYears(new Date(), 1));
						for (ItemCotacao item : cotacaoUltimaVersao.getListItem()) {
							item.setDataInicioVigencia(cotacaoUltimaVersao.getDataInicioVigencia());
							item.setDataFimVigencia(cotacaoUltimaVersao.getDataFimVigencia());
						}
					} else {
						Long dias = DateUtil.retornaDias(cotacaoUltimaVersao.getDataInicioVigencia(),
								cotacaoUltimaVersao.getDataFimVigencia());
						cotacaoUltimaVersao.setDataInicioVigencia(new Date());
						cotacaoUltimaVersao.setDataFimVigencia(DateUtils.addDays(new Date(), dias.intValue()));
						for (ItemCotacao item : cotacaoUltimaVersao.getListItem()) {
							item.setDataInicioVigencia(cotacaoUltimaVersao.getDataInicioVigencia());
							item.setDataFimVigencia(cotacaoUltimaVersao.getDataFimVigencia());
						}
					}
				}
				cotacaoUltimaVersao = saveCotacao(cotacaoUltimaVersao);
			}
		}
		
		return cotacaoUltimaVersao;
	}
	
	private void ajustaDsEnderecoSegurado(SolicitacaoCotacao solicitacao) throws Exception {
		/**
		 * @TODO
		 * 		SUBSTRING PALEATIVO PARA ANALISE
		 *       DO CAMPO ENDERECO SEGURADO
		 *       NO SCT CAMPO DE TAMANHO 100 E NO COTADOR 70
		 */

		String enderecoSegurado = solicitacao.getDsEnder();

		logger.info("Validacao paliativo endereco Segurado");

		if (enderecoSegurado != null && enderecoSegurado.length() > 70) {

			String enderecoSeguradoDepois = enderecoSegurado.substring(0,69);
			solicitacao.setDsEnder(enderecoSeguradoDepois);
		}
	}

	public void completarInfoCotacao(CtpjToken token,Cotacao cotacao,User user) throws ServiceException {

		cotacao.setVersaoCotacaoProposta(VS_COTAC_FIRST);
		cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
		cotacao.setUsuarioAtualizacao(new Long(user.getCdUsuro()));
		cotacao.setDataAtualizacao(Calendar.getInstance().getTime());
		if(token.getSolicitacaoCotacao().getDtIniVigen() != null) {
			cotacao.setDataInicioVigencia(token.getSolicitacaoCotacao().getDtIniVigen());
		} else {
			cotacao.setDataInicioVigencia(Calendar.getInstance().getTime());
		}
		
		if(cotacao.getIdEmailSegurado() != null && !EmailUtil.valida(cotacao.getIdEmailSegurado())) {
			cotacao.setIdEmailSegurado(null);
		}

		cotacao.setDataCotacao(Calendar.getInstance().getTime());
		cotacao.setCodigoSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getSituacao().intValue());
		cotacao.setNomeSituacao(CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getDescricao());
		if(StringUtils.isBlank(cotacao.getEmailSubscritor())) {
			try {
				ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroColaboradorPorMatricula();
				if (urlEnum == null) {
					throw new ServiceException("Erro ao buscar URL referente ao COL por matricula.");
				}

				String url = parametroGeralService.getUrlByNome(urlEnum);
				if (StringUtils.isEmpty(url)) { 
					throw new ServiceException("URL de acesso ao COL por matricula."); 
				}

				ResponseEntity<ColaboradorMatricula> retorno = restTemplate.getForEntity(url + cotacao.getCodigoSubscritor(), ColaboradorMatricula.class);
				ColaboradorMatricula colaborador = retorno.getBody();
				if(!StringUtils.isBlank(colaborador.getEmail())) {
					cotacao.setEmailSubscritor(colaborador.getEmail());
				}
			} catch (Exception e) {
				logger.error("Erro ao recuperar o e-mail do subscritor!" + cotacao.getCodigoSubscritor());
			}
		}

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR,1);
		cotacao.setDataFimVigencia(cal.getTime());
		
		cotacao.setIdTipoSeguro(TipoSeguroEnum.fromId(token.getSolicitacaoCotacao().getIcTipoSegur().getId()));

		cotacao.setIdTipoPessoa(TipoSeguradoEnum.getById(token.getSolicitacaoCotacao().getIcTipoPesoa()));

		Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
		
		ProdutoSusep produtoSusep = produtoService.findProduoSusepByProduto(cotacao.getCodigoProduto());

		cotacao.setCodigoMoeda(produto.getMoeda());

		cotacao.setIdLmiUnico(produto.getLmiUnico());
		cotacao.setIdResseguroFacultativo(SimNaoEnum.NAO);

		TipoPedidoCotacaoEnum idTipoPedidoCotacao = TipoPedidoCotacaoEnum.APOLICE;
		if (cotacao.getIdTipoEndosso() != null) {
			idTipoPedidoCotacao = TipoPedidoCotacaoEnum.ENDOSSO;
		}
		cotacao.setIdTipoPedidoCotacao(idTipoPedidoCotacao);

		cotacao.setIdPrazoVigencia(produto.getPrazoVigencia());
		cotacao.setIdTipoApolice(TipoApoliceEnum.COLETIVA);
		cotacao.setIdContaFaturaMensal(SimNaoEnum.NAO);
		cotacao.setNumeroProcessoSUSEP(produtoSusep.getDescricao());
		cotacao.setIdSeguroEstipulante(SimNaoEnum.SIM);
		List<ProdutoValorCarac> observacao = caracteristicaService.getValoresCaracteristica(
				cotacao.getCodigoProduto(),Caracteristicas.OBSERVACAO_CAPA.codigo(),
				new Sort(Direction.ASC, "valorCaracteristica"));
		if(observacao != null && !observacao.isEmpty()) {
			cotacao.setDescricaoObservacao(observacao.get(0).getDescricaoValor());
		}
		
		if(user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR) {
			cotacao.setIdTipoOrigem(TipoOrigemEnum.CORRETOR);
		} else {
			cotacao.setIdTipoOrigem(TipoOrigemEnum.INTERNO);
		}
	}

	public Cotacao saveCotacao(Cotacao cotacao) throws ServiceException {

		try {
			cotacao = repository.save(cotacao);
		} catch (HibernateException re) {
			logger.error("Erro ao Processar Entrada via SCT: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao Processar Entrada via SCT: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return cotacao;
	}

	private StringBuilder validationCotacao(Cotacao cotacao) {

		List<String> atributosIgnore = new ArrayList<>();
		atributosIgnore.add("sequencialCotacaoProposta");

		List<Mensagem> listaError = validationComponent.validatorComAtributosIgnore(cotacao,atributosIgnore);

		StringBuilder sbMsg = null;

		if (listaError != null) {
			sbMsg = new StringBuilder();
			sbMsg.append("Erro ao transformar Solicitação de Cotacao em Cotação").append('\r');
			sbMsg.append("Para a Cotação número: " + cotacao.getNumeroCotacaoProposta()).append('\r');
			sbMsg.append("foram encontrados os erros: ");
			for (Mensagem mensagem : listaError) {
				sbMsg.append("Código: " + mensagem.getCodigo() + " - Descrição: " + mensagem.getDescricao()).append('\r');
			}
		}

		return sbMsg;

	}

	@LogPerformance
	public void insert(SolicitacaoCotacao solicitacaoCotacao) throws ServiceException {
		try {
			Cotacao cotacao = repository.findByNumeroCotacaoProposta(solicitacaoCotacao.getNrSolctCotac());
			repository.save(cotacao);
		} catch (HibernateException re) {
			logger.error("Erro ao Salvar a Cotação: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao Salvar a Cotação: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public Cotacao saveGetSqCotacaoFake(SolicitacaoCotacaoFakeCTPJ solicitacaoCotacao) throws ServiceException {
		try {
			Cotacao cotacao = CotacaoParaSolicitacaoMapper.INSTANCE.toCotacaoFake(solicitacaoCotacao);
			// cotacao.setCdNivelAutz(solicitacaoCotacao.getCdNivelAutz());
			Cotacao ctc = repository.update(cotacao);
			return ctc;
		} catch (HibernateException re) {
			logger.error("Erro ao Salvar a Cotação: ",re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao Salvar a Cotação: ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findByNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) throws ServiceException {
		try {
			return repository.findByNumeroCotacaoProposta(numeroCotacaoProposta);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + numeroCotacaoProposta,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + numeroCotacaoProposta,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findById(BigInteger sqCotac) throws ServiceException {
		try {
			return repository.findById(sqCotac);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCompleta(BigInteger sqCotac) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findCompleta(sqCotac);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public Cotacao findComPrimeiroItem(BigInteger sqCotac) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findCompleta(sqCotac);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação com Primeiro Item: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação com Primeiro Item: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	

	@LogPerformance
	public Cotacao findCotacaoParcelamento(BigInteger sqCotac) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findCotacaoParcelamento(sqCotac);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoContaCorrente(BigInteger sqCotac) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findCotacaoContaCorrente(sqCotac);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoTela(BigInteger sqCotac) throws ServiceException {
		try {
			logger.info("find....");
			boolean lmi = repository.isCotacaoLMI(sqCotac);
			if (lmi) {
				return repository.findCotacaoTelaLMI(sqCotac);
			} else {
				return repository.findCotacaoTela(sqCotac);
			}
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoTelaByNumeroCotacao(BigInteger numeroCotacaoProposta) throws ServiceException {
		try {
			logger.info("findCotacaoTelaByNumeroCotacao....");
			Cotacao cotacao = repository.findCotacaoTelaByNumeroCotacao(numeroCotacaoProposta);
			return cotacao;
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + numeroCotacaoProposta,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + numeroCotacaoProposta,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public Cotacao findCotacaoTelaByNumeroCotacaoBloqueada(BigInteger numeroCotacaoProposta) throws ServiceException {
		try {
			logger.info("findCotacaoTelaByNumeroCotacao....");
			return repository.findCotacaoTelaByNumeroCotacaoBloqueada(numeroCotacaoProposta);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + numeroCotacaoProposta,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + numeroCotacaoProposta,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public ItemCotacao findItemCotacao(BigInteger seqItemCotacao) throws ServiceException {
		try {
			return repository.findItem(seqItemCotacao);
		} catch (RepositoryException e) {
			throw new ServiceException(e);
		}
	}

	/**
	 * Realiza o processo de atualização dos dados da Cotação
	 * <p>
	 * </p>
	 * <p>
	 * Uma lista vazia representa que não há inconsistências na cotação
	 * </p>
	 * 
	 * @param cotacaoView Classe de tela
	 * @return uma lista (Item + Descrição) com as inconsistências geradas pelo processo de validação
	 */
	@LogPerformance
	public List<ValidacaoLote> save(CotacaoView cotacaoView) throws ServiceException {

		BigDecimal coeficienteConversaoMoeda = null;

		try {

			Cotacao cotacao = repository.findCotacaoTela(cotacaoView.getSequencialCotacaoProposta());
			if (isCotacaoNaoDisponivel(cotacao)) {
				List<ValidacaoLote> listaValidacao = new ArrayList<>();
				listaValidacao.add(new ValidacaoLote(0, "Cotação já contratada ou não disponível para cálculo"));
				return listaValidacao;
			}

			cotacaoView.setLiberaLMR(produtoService.findProduto(cotacao.getCodigoProduto()).getLiberaLMR());
			/**
			 * Busca o coeficiente de Conversão de Moeda
			 * e já atualiza o coeficienteConversaoMoeda para os itens
			 * da cotação se a moeda for Dolar
			 */
			if (cotacaoView.getCodigoMoeda().getId().equals(MoedaEnum.DOLAR_VENDA.getId())) {
				coeficienteConversaoMoeda = cotacaoView.getCoeficienteConversaoMoeda();
			}

			int sequencialItemDistribuicao = 1;

			if(!SecurityUtils.isCorretor()) {
				Set<ItemCotacao> listItemCotacaoBkp = cotacao.getListItem();
				Set<ItemCotacao> itensCotacao = new HashSet<>();
				Map<BigInteger,ItemCotacao> itemCotacaoMapa = new HashMap<>();
				for(ItemCotacao itemCotacao: cotacao.getListItem()) {
					itemCotacaoMapa.put(itemCotacao.getNumeroItem(),itemCotacao);
				}
				cotacaoView.getListItem().forEach(itemView -> {
					itensCotacao.add(itemCotacaoMapa.get(itemView.getNumeroItem()));
				});
				cotacao.setListItem(itensCotacao);
				repository.deleteItemDistribuicao(cotacao);
				cotacao.setListItem(listItemCotacaoBkp);
				Optional<BigInteger> distribuicaoMaximo = cotacao.getListItem().stream()
						.flatMap(it -> it.getListItemDistribuicao().stream())
						.map(ItemDistribuicao::getSequencialDistribuicaoValorRisco)
						.max(Comparator.naturalOrder());
				if(distribuicaoMaximo.isPresent()) {
					sequencialItemDistribuicao = distribuicaoMaximo.get().intValue() + 1;
				}
			}

			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				for (ItemCotacaoView itemCotacaoView : cotacaoView.getListItem()) {
					if (itemCotacao.getNumeroItem().equals(itemCotacaoView.getNumeroItem())) {
						if (itemCotacaoView.getProtecionais() != null && !itemCotacaoView.getProtecionais().isEmpty()) {
							repository.deleteProtecionais(itemCotacao,itemCotacaoView.getProtecionais());
						} else {
							repository.deleteProtecionais(itemCotacao,Arrays.asList(0L));
						}
					}
				}
			}

			if(SecurityUtils.isCorretor()) {
				for(ItemCotacao item: cotacao.getListItem()) {
					for(ItemCotacaoView itemView: cotacaoView.getListItem()) {
						if(item.getNumeroItem().equals(itemView.getNumeroItem())) {
							itemView.setIdNecessidadeInspecao(item.getIdNecessidadeInspecao());
						}
					}
				}
			}

			CotacaoViewMapper.INSTANCE.toCotacao(cotacaoView,cotacao);
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			cotacao.setDataAtualizacao(new Date());
			cotacao.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));

			/**
			 * Popula os dados do item/local de risco e suas dependências (coberturas, protecionais, distribuicaoVR, etc)
			 */

			baseService.populaItem(cotacaoView,cotacao,sequencialItemDistribuicao,coeficienteConversaoMoeda);

			List<Integer> coberturas = cotacao.getListItem().stream()
					.flatMap(it -> it.getListItemCobertura().stream())
					.map(ItemCobertura::getCodigoCobertura)
					.distinct().collect(Collectors.toList());

			baseService.populaComissao(cotacaoView,cotacao);

			List<PerfilCalculoCoberturaLimiteIs> perfisCoberturaLimiteIs = perfilComercialService.findCoberturaLimiteIs(cotacao,coberturas);

			List<ItemCobertura> cobs = cotacao.getListItem().stream()
					.flatMap(it -> it.getListItemCobertura()
							.stream())
					.collect(Collectors.toList());

			for (ItemCobertura cob : cobs) {
				for (PerfilCalculoCoberturaLimiteIs p : perfisCoberturaLimiteIs) {
					if (cob.getCodigoCobertura() != null && p != null && cob.getCodigoCobertura().equals(p.getCobertura())) {
						cob.setPerfilCalculoCoberturaLimiteIs(p);
					}
				}
			}

			/**
			 * Se veio do botão salvar a cotação obterá apenas os itens da view para realizar a validação
			 * Se veio do calcular vai ser validado todos os itens da cotação
			 */
			Set<ItemCotacao> listItemCotacaoBkp = cotacao.getListItem();
			if (cotacaoView.isSalvarCotacao()) {
				Set<ItemCotacao> itensCotacao = new HashSet<>();
				Map<BigInteger,ItemCotacao> itemCotacaoMapa = new HashMap<>();
				for(ItemCotacao itemCotacao: cotacao.getListItem()) {
					itemCotacaoMapa.put(itemCotacao.getNumeroItem(),itemCotacao);
				}
				cotacaoView.getListItem().forEach(itemView -> {
					itensCotacao.add(itemCotacaoMapa.get(itemView.getNumeroItem()));
				});
				cotacao.setListItem(itensCotacao);
			} else {
				for (ItemCobertura cob : cobs) {
					if(cob.getTipoIS() == null) {
						baseService.populaDadosProdutoCobertura(cob);
					}
				}
			}

			/**
			 * valida os dados da cotacao
			 */
			Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto = caracteristicaService.findCaracteristicaDoProduto(cotacao.getCodigoProduto(), cotacao.getDataCotacao());
			CotacaoValidator cotacaoValidator = new CotacaoValidator(
					ValidationRegistry.getValidators().get(cotacao.getCodigoProduto()),
					perfilComercialService,
					caracteristicasDoProduto);
			List<ValidacaoLote> listaValidacao = cotacaoValidator.validaCotacao(cotacao);

			if(SecurityUtils.isCorretor()) {
				List<CoberturaAgrupamentoRestricao> agrupamentos = coberturaService.findAgrupamentosRestricaoPorProduto(cotacao);
				for(CoberturaAgrupamentoRestricao agrupamento: agrupamentos)  {
					for(ItemCotacao itemCotacao: cotacao.getListItem()) {
						int contadorItem = 0;
						for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
							if(agrupamento.getCoberturas().contains(itemCobertura.getCodigoCobertura())) {
								contadorItem++;
								if(contadorItem > 1) {
									break;
								}
							}
						}
						if(contadorItem > 1) {
							listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), agrupamento.getMensagem()));
						}
					}
				}
			}

			/**
			 * Após a validação a cotação assume sua lista se veio do botão salvar
			 */
			if (cotacaoView.isSalvarCotacao()) {
				cotacao.setListItem(listItemCotacaoBkp);
			}
			
			int numeroItem = 1;
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				itemCotacao.setNumeroItem(new BigInteger(String.valueOf(numeroItem++)));
				//validarCoberturas(itemCotacao);
			}
			
			BaseCoberturaValidator baseCobertura = new BaseCoberturaValidator();
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
					if(itemCobertura.getIdTipoCobertura() != null &&!itemCobertura.getIdTipoCobertura().equals(1)) {
						if(itemCobertura.getTipoIS() == TipoISEnum.INFORMADA_PELO_USUARIO && listaValidacao.isEmpty() && itemCobertura.isFormaLimiteIS()) {
							baseCobertura.validaLimiteIS(cotacao, itemCobertura, cotacao.getCodigoMoeda(), itemCotacao.getNumeroItem().intValue());
						}
					}
				}
			}
			
			Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
			resseguroFacultativoLimiteService.marcaResseguroFacultativo(cotacao, produto);
			
			cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);

			if(cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
				for (Iterator<ValidacaoLote> iterator = listaValidacao.iterator(); iterator.hasNext();) {
					ValidacaoLote validacao = iterator.next();
					if(validacao.getItem() > 1 && validacao.getTipo() == 1) {
						iterator.remove();
					}
				}
			}

			/**
			 * Se a moeda da cotação for Dolar
			 * verifica os valores após a conversão
			 */
			if (cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA) {
				cotacaoDolarService.validaValoresAntesCalculoBlaze(cotacao,coeficienteConversaoMoeda);
			}

			if (listaValidacao != null && listaValidacao.isEmpty()) {
				for (ItemCotacao itemCotacao: cotacao.getListItem()) {
					for (ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
						if (!StringUtils.isBlank(itemCobertura.getDescricaoCoberturaAjustada())) {
							listaValidacao.add(new ValidacaoLote(null, itemCobertura.getDescricaoCoberturaAjustada(), itemCobertura.getDescricaoCobertura()));
						}
					}
				}
				repository.update(cotacao);
			} else {
				repository.evict(cotacao);
			}

			return listaValidacao;
		} catch (Exception e) {
			logger.error(String.format("Erro ao salvar a Cotação [%s]: ",cotacaoView.getSequencialCotacaoProposta()),e);
			throw new ServiceException(e.getMessage() + String.format("Cotacao [%s]",cotacaoView.getSequencialCotacaoProposta()),e);
		}
	}

	private boolean isCotacaoNaoDisponivel(Cotacao cotacao) {
		return CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly()
				|| (SecurityUtils.isCorretor() && Arrays.asList(1, 3).contains(cotacao.getIdTipoOrigem()));
	}
	
	@LogPerformance
	private void validarCoberturas(ItemCotacao itemCotacao) throws RepositoryException{
		//
		List<ProdutoCaracValorAtributo> produtoCaracValorAtributoList = produtoCaracValorAtributoRepository.findProdutoCaracByEquipamento(itemCotacao);
		
		for (Iterator<ItemCobertura> iterator = itemCotacao.getListItemCobertura().iterator(); iterator.hasNext();) {
			ItemCobertura itemCobertura = iterator.next();
			Boolean coberturaPertenceRubricaSelecionada = false;
			for(ProdutoCaracValorAtributo p : produtoCaracValorAtributoList){
				if(p.getCobertura().equals(itemCobertura.getCodigoCobertura())){
					coberturaPertenceRubricaSelecionada = true;
					break;
				}
			}
			
			if(!coberturaPertenceRubricaSelecionada){
				//itemCotacao.getListItemCobertura().remove(itemCobertura);
				iterator.remove();
			}
		}
		//
	}
	
	@LogPerformance
	public void excluiItem(BigInteger item) throws ServiceException { 
		try {
			repository.excluiItem(item);
		} catch (Exception e) {
			logger.error(String.format("Erro ao excluir o item: %s",item),e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public ResultadoREST<CoberturaAdicionar> excluiItemCobertura(List<CoberturaExclusao> coberturas) throws ServiceException {
		try {
			return repository.excluiItemCobertura(coberturas);
		} catch (Exception e) {
			logger.error(String.format("Erro ao excluir o(s) item(s): %s",coberturas),e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Integer countItems(BigInteger sqCotacao) throws ServiceException {
		try {
			return repository.countItems(sqCotacao);
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage(),e);
		}
	}	

	@LogPerformance
	public Cotacao duplicaCotacao(Cotacao cotacao,CtpjToken token,User user) throws ServiceException {
		try {
			Cotacao c = repository.duplicaCotacao(cotacao);
			c.setNumeroCotacaoProposta(token.getSolicitacaoCotacao().getNrSolctCotac());
			c.setVersaoCotacaoProposta(VS_COTAC_FIRST);
			c.setCodigoSucursalComercial(token.getSolicitacaoCotacao().getCdSubLocalReal() != null ? token.getSolicitacaoCotacao().getCdSubLocalReal().intValue() : null);

			duplicarCotacaoService.bindCotacaoDuplicada(c,user);
			c = repository.save(c);
			return c;
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Cotação");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Buscar Cotacao");
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	public Cotacao duplicaCotacao(BigInteger numeroCotacao, BigInteger numeroNovo, User user) throws ServiceException {
		try {
			Cotacao cotacao = findByNumeroCotacaoProposta(numeroCotacao);
			Cotacao c = repository.duplicaCotacao(cotacao);
			c.setNumeroCotacaoProposta(numeroNovo);
			c.setVersaoCotacaoProposta(VS_COTAC_FIRST);
			duplicarCotacaoService.bindCotacaoDuplicada(c,user);
			c = repository.save(c);
			return c;
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Cotação");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Buscar Cotacao");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public BigInteger novaVersaoCotacao(BigInteger sequencialCotacaoPropostaNovaVersao,User user,boolean isVsp) throws ServiceException {
		try {
			// Busca a cotação com a versão escolhida
			Cotacao cotacaoOrigem = repository.findById(sequencialCotacaoPropostaNovaVersao);
			// Faz o Clone da Versão Escolhida usando o Ignore
			Cotacao cotacaoNovaVersao = repository.novaVersaoCotacao(cotacaoOrigem);
			// Busca o número da nova versão usando max (1) baseada na sequencia escolhida
			Integer nrNovaVersao = repository.getNrNovaVersaoCotacao(cotacaoOrigem.getNumeroCotacaoProposta());
			// Seta a nova versão e número da propota na cotação clonada
			cotacaoNovaVersao.setVersaoCotacaoProposta(nrNovaVersao);
			// Faz o bind da cotação versionada (Aqui vai ter as regras de negócio da nova versão)
			novaVersaoCotacaoService.bindCotacaoNovaVersao(cotacaoNovaVersao, cotacaoOrigem, user,isVsp);
			// Persiste a cotação versionada
			cotacaoNovaVersao = repository.save(cotacaoNovaVersao);
			// Retorna a nova sequencia gerada da cotação persistida
			return cotacaoNovaVersao.getSequencialCotacaoProposta();
		} catch (HibernateException h) {
			logger.error("Erro ao executar processo de Nova Versão da Cotação");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao executar processo de Nova Versão da Cotação");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoDuplicada(CtpjToken token) throws ServiceException {
		try {
			return repository.findByNumeroCotacaoProposta(token.getSolicitacaoCotacao().getNrSolctCotacDupliAbetu());
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Cotação");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Buscar Cotacao");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public boolean existeCotacaoDuplicada(CtpjToken token) throws ServiceException {
		try {
			return repository.existeCotacaoDuplicada(token.getSolicitacaoCotacao().getNrSolctCotac());
		} catch (HibernateException h) {
			logger.error("Erro ao Validar existeCotacaoDuplicada");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Validar existeCotacaoDuplicada");
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	@LogPerformance
	@PostAuthorize(
			"authentication.principal.grupoUsuario.cdGrp == 76 ? "
			+ " returnObject.codigoCorretorACSEL == authentication.principal.cdUsuro.toString() "
			+ " : true")
	public CotacaoView findCotacaoCabecalho(BigInteger cotacao) throws ServiceException {
		try {
			return repository.findCotacaoCabecalho(cotacao);
		} catch (RepositoryException e) {
			logger.error("Erro ao buscar listagem de corretagem ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoParcelamentoRecebimento(BigInteger sqCotac) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findCotacaoParcelamentoRecebimento(sqCotac);
		} catch (HibernateException re) {
			logger.error("Erro ao Buscar a Cotação: " + sqCotac,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro Geral ao ao Buscar a Cotação: " + sqCotac,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoComItemRenumeracao(BigInteger sqCotac) throws ServiceException {
		try {
			return repository.findCotacaoComItemRenumeracao(sqCotac);
		} catch (HibernateException h) {
			logger.error("Erro ao Buscar Cotação com item para Renumeração");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao Buscar Cotacao  com item para Renumeração");
			throw new ServiceException(e.getMessage(),e);
		}

	}

	@LogPerformance
	public Cotacao findCotacaoByNrCotacAndVsCotac(BigInteger numeroCotacaoProposta,Integer versaoCotacaoProposta) throws ServiceException {
		try {
			return repository.findCotacaoByNrCotacAndVsCotac(numeroCotacaoProposta,versaoCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao findCotacaoByNrCotacAndVsCotac",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao findCotacaoByNrCotacAndVsCotac",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public boolean existeCotacaoNrCotac(BigInteger numeroCotacaoProposta) throws ServiceException {
		try {
			return repository.existeCotacaoNrCotac(numeroCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao existeCotacaoNrCotac",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao existeCotacaoNrCotac",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public Cotacao findCotacaoPareceres(BigInteger sqCotac) throws ServiceException {
		try {
			return repository.findCotacaoPareceres(sqCotac);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao findCotacaoPareceres",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao findCotacaoPareceres",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public void enviaCotacaoParaAnaliseTecnica(BigInteger sqCotacao) throws ServiceException {
		try {
			User user = SecurityUtils.getCurrentUser();
			Cotacao cotacao = findById(sqCotacao);
			cotacao.setCodigoSituacao(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getSituacao().intValue());
			cotacao.setNomeSituacao(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getDescricao());
			cotacao.setDataAtualizacao(new Date());
			cotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());

			repository.update(cotacao);
			ParecerInterfaceRetorno response = sctService.enviaParecerSCT(cotacao, CodigoSituacaoEnum.ANALISE_NA_COMERCIAL_305, "Cotação com restrições enviada para análise técnica pelo corretor", user);
			if (response.getCodigo().compareTo(BigDecimal.ZERO) != 0) {
				logger.error(String.format("Erro ao inserir status [cotacao=%s] [%s]",sqCotacao,response.getMensagem()));
				throw new ServiceException(String.format("Erro ao inserir status [cotacao=%s] [%s]",sqCotacao,response.getMensagem()));
			}
		} catch (ServiceException e) {
			logger.error("Erro ao enviar a cotacao com restricao para analise tecnica: " + sqCotacao,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public void enviaCotacaoParaAnaliseTecnica(BigInteger sqCotacao,EmailContatoSCT emailContato) throws ServiceException {
		try {
			ResponseEntity<MensagemCTPJ> response = sctService.insereEmailContatoSCT(emailContato);
			if (!response.getBody().getCodigo().equals(0L)) {
				logger.error(String.format("Erro ao inserir email [cotacao=%s] [%s]",sqCotacao,response.getBody().getMensagem()));
				throw new ServiceException(String.format("Erro ao inserir email [cotacao=%s] [%s]",sqCotacao,response.getBody().getMensagem()));
			}
		} catch (ServiceException e) {
			logger.error("Erro ao inserir email : " + sqCotacao,e);
			throw new ServiceException(e.getMessage(),e);
		}

		try {
			User user = SecurityUtils.getCurrentUser();
			Cotacao cotacao = findById(sqCotacao);
			cotacao.setIdTipoOrigem(TipoOrigemEnum.ORCAMENTO);
			cotacao.setCodigoSituacao(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getSituacao().intValue());
			cotacao.setNomeSituacao(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getDescricao());
			cotacao.setDataAtualizacao(new Date());
			cotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());

			repository.update(cotacao);
			ParecerInterfaceRetorno response = sctService.enviaParecerSCT(cotacao, CodigoSituacaoEnum.ANALISE_NA_COMERCIAL_305, "Cotação com restrições enviada para análise técnica pelo corretor", user);
			if (response.getCodigo().compareTo(BigDecimal.ZERO) != 0) {
				logger.error(String.format("Erro ao inserir status [cotacao=%s] [%s]",sqCotacao,response.getMensagem()));
				throw new ServiceException(String.format("Erro ao inserir status [cotacao=%s] [%s]",sqCotacao,response.getMensagem()));
			}
		} catch (ServiceException e) {
			logger.error("Erro ao enviar a cotacao com restricao para analise tecnica: " + sqCotacao,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public void enviaCotacaoParaAnaliseTecnica(BigInteger sqCotacao,EmailContatoSCT emailContato, String mensagem) throws ServiceException {
		try {
			ResponseEntity<MensagemCTPJ> response = sctService.insereEmailContatoSCT(emailContato);
			if (!response.getBody().getCodigo().equals(0L)) {
				logger.error(String.format("Erro ao inserir email [cotacao=%s] [%s]",sqCotacao,response.getBody().getMensagem()));
				throw new ServiceException(String.format("Erro ao inserir email [cotacao=%s] [%s]",sqCotacao,response.getBody().getMensagem()));
			}
		} catch (ServiceException e) {
			logger.error("Erro ao inserir email : " + sqCotacao,e);
			throw new ServiceException(e.getMessage(),e);
		}

		try {
			User user = SecurityUtils.getCurrentUser();
			Cotacao cotacao = findById(sqCotacao);
			cotacao.setIdTipoOrigem(TipoOrigemEnum.ORCAMENTO);
			cotacao.setCodigoSituacao(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getSituacao().intValue());
			cotacao.setNomeSituacao(CodigoSituacaoEnum.ANALISE_NA_TECNICA_307.getDescricao());
			cotacao.setDataAtualizacao(new Date());
			cotacao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());

			repository.update(cotacao);
			ParecerInterfaceRetorno response = sctService.enviaParecerSCT(cotacao, CodigoSituacaoEnum.ANALISE_NA_COMERCIAL_305, "Cotação com restrições enviada para análise técnica pelo corretor", user);
			if (response.getCodigo().compareTo(BigDecimal.ZERO) != 0) {
				logger.error(String.format("Erro ao inserir status [cotacao=%s] [%s]",sqCotacao,response.getMensagem()));
				throw new ServiceException(String.format("Erro ao inserir status [cotacao=%s] [%s]",sqCotacao,response.getMensagem()));
			}
		} catch (ServiceException e) {
			logger.error("Erro ao enviar a cotacao com restricao para analise tecnica: " + sqCotacao,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoNotas(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			return repository.findCotacaoNotas(sequencialCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao findCotacaoNotas",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao findCotacaoNotas",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public Cotacao findCotacaoComItensCotacao(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			return repository.findCotacaoComItensCotacao(sequencialCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao findCotacaoComItensCotacao",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao findCotacaoComItensCotacao",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public List<ItemCotacao> findItensCotacaoAndItemNotas(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			return repository.findItensCotacaoAndItemNotas(sequencialCotacaoProposta);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao findCotacaoComItensCotacao",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao findCotacaoComItensCotacao",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	@LogPerformance
	public ItemCotacao findItensCotacaoAndItemNotaBySequencialItemCotacao(BigInteger sequencialItemCotacao) throws ServiceException {
		try {
			return repository.findItensCotacaoAndItemNotaBySequencialItemCotacao(sequencialItemCotacao);
		} catch (HibernateException h) {
			logger.error("Erro ao buscar cotacao findItensCotacaoAndItemNotaBySequencialItemCotacao",h);
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro Geral ao buscar cotacao findItensCotacaoAndItemNotaBySequencialItemCotacao",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public TreeMap<Integer,Object> findVersoes(BigInteger numeroCotacaoProposta) {
		return repository.findVersoes(numeroCotacaoProposta);
	}
	
	public BigInteger geraNovaVersao(BigInteger sqCotacaoEscolhidaParaNovaVersao,User user, boolean isVsp) throws ServiceException{
		
		logger.info("Gerando nova versão baseada na sequencia: "+sqCotacaoEscolhidaParaNovaVersao);
		// Chama o método para buscar a nova versão
		BigInteger nrSqNovaVersaoCotacao = this.novaVersaoCotacao(sqCotacaoEscolhidaParaNovaVersao, user, isVsp);
		logger.info("Nova versao gerada - sequencia: "+nrSqNovaVersaoCotacao);
		return nrSqNovaVersaoCotacao;
	}
	
	@LogPerformance
	public List<ItemCotacao> getItemsSemInspecao(BigInteger sqCotacao) throws ServiceException {
		List<ItemCotacao> listItemCotacao = new ArrayList<>();
		try {
			for (ItemCotacao itemCotacao : repository.getItemsSemInspecao(sqCotacao)){
				//if (inspecaoService.existeNecessidadeInspecaoItem(itemCotacao)){
				listItemCotacao.add(itemCotacao);
				//}
			}
		} catch (RepositoryException e) {
			throw new ServiceException(e.getMessage(),e);
		}
		return listItemCotacao;
	}
	
	/**
	 * Busca os itens da cotação filtrados pelo tipo de pedido. Sendo que para Apólice todos os itens são retornados e 
	 * para Endosso, apenas os itens cujo tipo de endosso não é nulo ou igual a exclusão são retornados.
	 * 
	 * @param seqCotacao Identificador da cotação do qual  os itens serão recuperados
	 * @return itens da cotação filtrados, segundo a regra descrita acima
	 */
	public List<ItemCotacao> buscaItensFiltradosPorTipoPedidoCotacao(BigInteger seqCotacao){
		return filtraPorTipoPedidoCotacao(seqCotacao, repository.findItemByCotacao(seqCotacao));
	}

	
	/**
	 * Busca os itens da cotação baseando também no código da rubrica e filtrados pelo tipo de pedido. Sendo que para Apólice todos os itens são retornados e 
	 * para Endosso, apenas os itens cujo tipo de endosso não é nulo ou igual a exclusão são retornados.
	 * 
	 * @param seqCotacao Identificador da cotação do qual  os itens serão recuperados
	 * @param codRubrica Código da rúbrica
	 * @return itens da cotação filtrados, segundo a regra descrita acima
	 */
	public List<ItemCotacao> buscaItensPorCotacaoECodRubricaFiltradosPorTipoPedidoCotacao(BigInteger seqCotacao, Long codRubrica){
		return filtraPorTipoPedidoCotacao(seqCotacao, repository.findByCotacaoAndCdRubrica(seqCotacao, codRubrica));
	}
	
	/**
	 * Filtra uma lista de item cotação baseando-se no seu tipo de pedido. Sendo que para Apólice todos os itens são retornados e 
	 * para Endosso, apenas os itens cujo tipo de endosso não é nulo ou igual a exclusão são retornados.
	 * 
	 * @param seqCotacao Identificador da cotação cujo tipo de pedido pode ser ENDOSSO ou APOLICE
	 * @param itens Itens da Cotação a serem filtrados
	 * @return Itens filtrados segundo a regra descrita acima
	 */
	private List<ItemCotacao> filtraPorTipoPedidoCotacao(BigInteger seqCotacao, List<ItemCotacao> itens) {
		Cotacao cotacao = repository.findById(seqCotacao);
		
		if(cotacao.getIdTipoPedidoCotacao().equals(TipoPedidoCotacaoEnum.ENDOSSO)) {
			return itens.stream()
					.filter(item -> item.getIdTipoEndosso() != null && !item.getIdTipoEndosso().equals(TipoEndossoEnum.EXCLUSAO_ITEM.getId()))
					.collect(Collectors.toList());
		}
			
		return itens;
	}
	
	@LogPerformance
	public Cotacao findCotacaoComItem(BigInteger sqCotac) {
		return repository.findCotacaoComItem(sqCotac);
	}
	
	@LogPerformance
	public List<AlteracaoEndosso> findAlteracaoEndossoByItemCotacao(ItemCotacao itemCotacao) {
		return repository.findAlteracaoEndossoByItemCotacao(itemCotacao)
				.stream()
				.filter(ae -> ae.getItemCotacao() != null && ae.getItemCotacao().getSequencialItemCotacao().equals(itemCotacao.getSequencialItemCotacao()))
				.collect(Collectors.toList());
	}
	
	public List<ItemRamoEmissao> findItemRamoEmissaoByItemCotacao(ItemCotacao itemCotacao) {
		return repository.findItemRamoEmissaoByItemCotacao(itemCotacao);
	}
	
	public boolean isOrcamentoRamoCpfCnpj(Cotacao cotacao, User user){
		boolean retorno = false;
		if(user.getCdUsuro().equals(111119) || !AmbienteUtil.isServidorDeProducao()) {
			return false;
		}
		
		try {
			Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
			ConsultaCotacaoSCTResponse cotacoesSctList = sctService.consultarCotacoesSCTByRamoAndCpfCnpj(cotacao, user);
			if(cotacoesSctList != null && cotacoesSctList.getDuplicidades() != null && !cotacoesSctList.getDuplicidades().isEmpty()) {
				for(ConsultaCotacaoSCTResponse.Duplicidade consulta : cotacoesSctList.getDuplicidades()) {
					if(consulta != null && 
							consulta.getCdRamoPrdut() != null &&
							produto.getRamoContabil().longValue() == consulta.getCdRamoPrdut() &&
							consulta.getIdOrigemDuplicidade() != null && 
							(consulta.getIdOrigemDuplicidade().getOrigemDuplicidade() == 4 || consulta.getIdOrigemDuplicidade().getOrigemDuplicidade() == 2) &&
							tiposSeguro.contains(consulta.getIcTipoSegur()) && 
							(consulta.getCdCorretoAcsel() != null && 
							!StringUtils.stripStart(consulta.getCdCorretoAcsel(), "0").equals(cotacao.getCodigoCorretorACSEL())) &&
							!consulta.getNrSolctCotac().equals(cotacao.getNumeroCotacaoProposta().longValue())) {
						retorno = true;
						break;
					}
				}
			}
		} catch (Exception e){
			retorno = false;
			logger.error("Ocorreu um erro na validação de orçamento por ramo e cpf/cnpj para a cotação "+ cotacao.getNumeroCotacaoProposta(),e);
		}
		
		
		return retorno;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class ColaboradorMatricula implements Serializable {

		private static final long serialVersionUID = 437173375928546573L;

		private Long matricula;
		private String nome;
		private String email;
		public Long getMatricula() {
			return matricula;
		}
		public void setMatricula(Long matricula) {
			this.matricula = matricula;
		}
		public String getNome() {
			return nome;
		}
		public void setNome(String nome) {
			this.nome = nome;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
	}
	
	public CotacaoComProduto findCotacao(BigInteger numeroCotacao, Long codigoCorretor) throws ServiceException {
		try {
			return repository.findCotacao(numeroCotacao, codigoCorretor);
		} catch(Exception e) {
			logger.error(String.format("Erro ao buscar a cotação [%s] do corretor [%s]", numeroCotacao, codigoCorretor), e);
			throw new ServiceException(String.format("Erro ao buscar a cotação [%s] do corretor [%s]", numeroCotacao, codigoCorretor), e);
		}
	}
	
	@LogPerformance
	public List<ItemCobertura> getCoberturasByItem(
			BigInteger numeroCotacaoProposta, Integer versao, BigInteger numeroItem) throws ServiceException {
		try {
			return itemCoberturaRepository.getCoberturasByItem(numeroCotacaoProposta,versao,numeroItem);
		} catch(Exception e) {
			logger.error(String.format("Erro ao buscar coberturas cotação/versão/item [%s][%s][%s]", numeroCotacaoProposta,versao,numeroItem), e);
			throw new ServiceException(String.format("Erro ao buscar coberturas cotação/versão/item [%s][%s][%s]", numeroCotacaoProposta,versao,numeroItem), e);
		}
	}

	@LogPerformance
	public List<ItemCobertura> getCoberturasByItem(
			BigInteger numeroCotacaoProposta, Integer versao) throws ServiceException {
		try {
			return itemCoberturaRepository.getCoberturasByItem(numeroCotacaoProposta,versao);
		} catch(Exception e) {
			logger.error(String.format("Erro ao buscar coberturas cotação/versão/item [%s][%s]", numeroCotacaoProposta,versao), e);
			throw new ServiceException(String.format("Erro ao buscar coberturas cotação/versão/item [%s][%s]", numeroCotacaoProposta,versao), e);
		}
	}
	
	@LogPerformance
	public CotacaoBatchResponse processaLoginWebservice(SolicitacaoCotacao solicitacaoCotacao) throws Exception {
		CtpjToken token = new CtpjToken();
		User user = new User();
		CotacaoBatchResponse cotacaoBatchResponse = new CotacaoBatchResponse();
		
		token.setSolicitacaoCotacao(solicitacaoCotacao);
		token.getSolicitacaoCotacao().setIdEvnto("00");
		user.setGrupoUsuario(GrupoUsuarioEnum.CORRETOR);
		user.setCdUsuro(solicitacaoCotacao.getCdCrtorAcsel().intValue());
		ProcessaLogin processaLogin = this.processaLogin(token,user);
		
		if(processaLogin.isSucesso()){
			cotacaoBatchResponse.setSucesso(true);
			cotacaoBatchResponse.setSequencialCotacaoProposta(processaLogin.getCotacao().getSequencialCotacaoProposta());
		}else{
			List<Mensagem> mensagens = new ArrayList<>();						
			Mensagem mensagem = new Mensagem();
			mensagem.setCodigo(1);
			mensagem.setDescricao(processaLogin.getMensagens().toString());
			mensagens.add(mensagem);
			cotacaoBatchResponse.setSucesso(false);
			cotacaoBatchResponse.setMensagens(mensagens);
		}
		return cotacaoBatchResponse;
	}
	
	@LogPerformance
	public void atualizaCotacaoWS(Cotacao cotacao) {
		repository.merge(cotacao);
	}
	
	@LogPerformance
	public void updateCotacaoWS(Cotacao cotacao) {
		repository.update(cotacao);
	}
	
	@LogPerformance
	public void deleteProtecionais(Cotacao cotacao) {
		for(ItemCotacao itemCotacao: cotacao.getListItem()) {
			if(itemCotacao.getListItemSistemaProtecional() != null && !itemCotacao.getListItemSistemaProtecional().isEmpty()) {
				repository.deleteProtecionais(
						itemCotacao, 
						itemCotacao.getListItemSistemaProtecional().stream()
						.map(ItemSistemaProtecional::getCodigoSistemaProtecional)
						.collect(Collectors.toList()));
			}
		}
	}

	@LogPerformance
	public void deleteItemCobertura(List<Integer> coberturas, BigInteger sequencialItemCotacao) {
		repository.deleteItemCobertura(coberturas, sequencialItemCotacao); 
	}
	
	@LogPerformance
	public void calcularParcelamentoRamo(BigInteger sqCotac) throws ServiceException   {
		try {
			Cotacao cotacao = repository.findCompleta(sqCotac);
			repository.calcularParcelamentoRamo(cotacao);
			
		} catch (Exception e) {
			logger.error("Erro Geral ao Calcular Parcelamento Ramo (rest): ",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public List<ValidacaoLote> validacaoBatch(Cotacao cotacao) {
		try {
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			cotacao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			cotacao.setDataAtualizacao(new Date());
			cotacao.setUsuarioAtualizacao(Long.valueOf(user.getCdUsuro()));
			
			List<Integer> coberturas = cotacao.getListItem().stream()
					.flatMap(it -> it.getListItemCobertura().stream())
					.map(ItemCobertura::getCodigoCobertura)
					.distinct().collect(Collectors.toList());
			
			List<PerfilCalculoCoberturaLimiteIs> perfisCoberturaLimiteIs = perfilComercialService.findCoberturaLimiteIs(cotacao,coberturas);

			List<ItemCobertura> cobs = cotacao.getListItem().stream()
					.flatMap(it -> it.getListItemCobertura()
							.stream())
					.collect(Collectors.toList());

			for (ItemCobertura cob : cobs) {
				for (PerfilCalculoCoberturaLimiteIs p : perfisCoberturaLimiteIs) {
					if (cob.getCodigoCobertura() != null && p != null && cob.getCodigoCobertura().equals(p.getCobertura())) {
						cob.setPerfilCalculoCoberturaLimiteIs(p);
					}
				}
			}

			/**
			 * Se veio do botão salvar a cotação obterá apenas os itens da view para realizar a validação
			 * Se veio do calcular vai ser validado todos os itens da cotação
			 */
			for (ItemCobertura cob : cobs) {
				if(cob.getTipoIS() == null) {
					baseService.populaDadosProdutoCobertura(cob);
				}
			}

			/**
			 * valida os dados da cotacao
			 */
			Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto = caracteristicaService.findCaracteristicaDoProduto(cotacao.getCodigoProduto(), cotacao.getDataCotacao());
			CotacaoValidator cotacaoValidator = new CotacaoValidator(
					ValidationRegistry.getValidators().get(cotacao.getCodigoProduto()),
					perfilComercialService,
					caracteristicasDoProduto);
			List<ValidacaoLote> listaValidacao = cotacaoValidator.validaCotacao(cotacao);

			if(SecurityUtils.isCorretor()) {
				List<CoberturaAgrupamentoRestricao> agrupamentos = coberturaService.findAgrupamentosRestricaoPorProduto(cotacao);
				for(CoberturaAgrupamentoRestricao agrupamento: agrupamentos)  {
					for(ItemCotacao itemCotacao: cotacao.getListItem()) {
						int contadorItem = 0;
						for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
							if(agrupamento.getCoberturas().contains(itemCobertura.getCodigoCobertura())) {
								contadorItem++;
								if(contadorItem > 1) {
									break;
								}
							}
						}
						if(contadorItem > 1) {
							listaValidacao.add(new ValidacaoLote(itemCotacao.getNumeroItem().intValue(), agrupamento.getMensagem()));
						}
					}
				}
			}
			
			int numeroItem = 1;
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				itemCotacao.setNumeroItem(new BigInteger(String.valueOf(numeroItem++)));
				//validarCoberturas(itemCotacao);
			}
			
			BaseCoberturaValidator baseCobertura = new BaseCoberturaValidator();
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				for(ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
					if(itemCobertura.getIdTipoCobertura() != null &&!itemCobertura.getIdTipoCobertura().equals(1)) {
						if(itemCobertura.getTipoIS() == TipoISEnum.INFORMADA_PELO_USUARIO && listaValidacao.isEmpty() && itemCobertura.isFormaLimiteIS()) {
							baseCobertura.validaLimiteIS(cotacao, itemCobertura, cotacao.getCodigoMoeda(), itemCotacao.getNumeroItem().intValue());
						}
					}
				}
			}
			
			Produto produto = produtoService.findProduto(cotacao.getCodigoProduto());
			resseguroFacultativoLimiteService.marcaResseguroFacultativo(cotacao, produto);
			
			cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_NAO_CALCULADO);
			
			if (listaValidacao != null && listaValidacao.isEmpty()) {
				for (ItemCotacao itemCotacao: cotacao.getListItem()) {
					for (ItemCobertura itemCobertura: itemCotacao.getListItemCobertura()) {
						if (!StringUtils.isBlank(itemCobertura.getDescricaoCoberturaAjustada())) {
							listaValidacao.add(new ValidacaoLote(null, itemCobertura.getDescricaoCoberturaAjustada(), itemCobertura.getDescricaoCobertura()));
						}
					}
				}
				repository.update(cotacao);
			} else {
				repository.evict(cotacao);
			}
			
			listaValidacao.forEach(it -> {
				System.out.println(it.getDescricao());
			});

			return listaValidacao;	
		} catch (Exception e) {
			logger.error("eeeee ", e);
			throw new RuntimeException("erro", e);
		}
	}

	/**
	 * Indica se o ctpj deverá direcionar o usuário para a contratação de cotação com status "310 - NEGÓCIO FECHADO"
	 * @param cotacao
	 * @param user
	 * @return
	 * @throws ServiceException
	 */
	public boolean isRegraNegocioFechado(Cotacao cotacao, User user) throws ServiceException {
		
		if(cotacao.getCodigoSituacao().longValue() != CodigoSituacaoEnum.ACEITO_PELO_CORRETOR_310.getSituacao()) {
			return false;
		}
		
		if(SecurityUtils.isCorretor()) {
			return true;
		}
		
		return GrupoUsuarioEnum.GERENTE_COMERCIAL == user.getGrupoUsuario() || GrupoUsuarioEnum.ASSISTENTE_COMERCIAL == user.getGrupoUsuario(); 
		
	}	
	
	public OrigemContratacaoEnum definirOrigemContratacao(Cotacao cotacao, User user) throws ServiceException {
		if(user.getGrupoUsuario() == GrupoUsuarioEnum.CORRETOR || isRegraNegocioFechado(cotacao, user)) {
			return OrigemContratacaoEnum.ORIGEM_CORRETOR;
		}
		
		return OrigemContratacaoEnum.ORIGEM_SUBSCRITOR;
	}

}