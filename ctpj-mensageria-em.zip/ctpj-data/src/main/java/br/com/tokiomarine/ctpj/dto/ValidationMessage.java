package br.com.tokiomarine.ctpj.dto;

public class ValidationMessage {

	public enum Type {
		SUCCESS, INFO, ERROR, WARNING, DANGER
	}

	private String shortText;
	private String fullText;
	private Type type;	
	
	public ValidationMessage(String descricao, Type tipo) {
		super();
		this.shortText = descricao;
		this.fullText = descricao;
		this.type = tipo;
	}

	public ValidationMessage(String descricaoResumida, String descricaoCompleta, Type tipo) {
		super();
		this.shortText = descricaoResumida;
		this.fullText = descricaoCompleta;
		this.type = tipo;
	}

	public String getShortText() {
		return shortText;
	}

	public void setShortText(String descricaoResumida) {
		this.shortText = descricaoResumida;
	}

	public String getFullText() {
		return fullText;
	}

	public void setFullText(String descricaoCompleta) {
		this.fullText = descricaoCompleta;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type tipo) {
		this.type = tipo;
	}

}
