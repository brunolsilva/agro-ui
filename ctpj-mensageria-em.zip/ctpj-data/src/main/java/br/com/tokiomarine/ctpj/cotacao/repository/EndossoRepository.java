package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;

import javax.persistence.ParameterMode;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.type.PLUnitsCTPJ;

@Repository
public class EndossoRepository extends BaseDAO {
	
	private static Logger logger = LogManager.getLogger(EndossoRepository.class.getName());

	public void geraMensagemEndosso(BigInteger sqCotac, String idApolice) throws RepositoryException {
		try {
			ProcedureCall procedure = getCurrentSession()
					.createStoredProcedureCall(PLUnitsCTPJ.prc_msg_endosso.value())
					.registerParameter0("p_sq_cotac_ppota", BigInteger.class, ParameterMode.IN)
					.registerParameter0("p_id_apoliceCtpj", String.class, ParameterMode.IN)
					.registerParameter0("p_mens", String.class, ParameterMode.OUT);
			
			procedure.getParameterRegistration("p_sq_cotac_ppota").bindValue(sqCotac);
			procedure.getParameterRegistration("p_id_apoliceCtpj").bindValue(idApolice);
			
			ProcedureOutputs output = procedure.getOutputs();
			String pMens = (String) output.getOutputParameterValue("p_mens"); 								
			
	        super.validaRetornoDaProcedure(pMens);
		} catch (Exception e) {
			logger.error("Erro ao chamar procedure geraMensagemEndosso: " + e);
			throw new RepositoryException(e.getMessage(),e);
			
		}
    }
}
