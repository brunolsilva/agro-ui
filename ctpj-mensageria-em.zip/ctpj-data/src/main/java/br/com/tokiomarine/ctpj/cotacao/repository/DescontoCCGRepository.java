package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoCCG;

@Repository
public class DescontoCCGRepository extends BaseDAO {

	@SuppressWarnings("unchecked")
	public List<DescontoCCG> findContaCorrenteGlobal(BigInteger sequencialCotacaoProposta){
		StringBuilder hql = new StringBuilder();
		hql.append(" select desctCcg ");
		hql.append(" from 	DescontoCCG desctCcg ");
		hql.append(" where  desctCcg.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return (List<DescontoCCG>)query.list();
	}
	
	public DescontoCCG delete(DescontoCCG desctCcg) {
		getCurrentSession().delete(desctCcg);
		getCurrentSession().flush();
		return desctCcg;
	}
	
	public DescontoCCG update(DescontoCCG desctCcg) {
		desctCcg = (DescontoCCG) getCurrentSession().merge(desctCcg);
		getCurrentSession().flush();
		return desctCcg;
	}

	public DescontoCCG save(DescontoCCG desctCcg) {
		getCurrentSession().persist(desctCcg);
		return desctCcg;
	}
}
