package br.com.tokiomarine.ctpj.auth.controller;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.auth.dto.Autentica;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.cotacao.service.SolicitacaoCotacaoFakeService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoMemoriaEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.PerfilComercialBloqueioAtividadeRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.MemoriaProcessamentoService;
import br.com.tokiomarine.ctpj.sct.request.SolicitacaoCotacaoFakeCTPJ;
import br.com.tokiomarine.ctpj.sct.service.SCTService;
import br.com.tokiomarine.ctpj.security.CtpjAuthenticationToken;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationProvider;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationSuccessHandler;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.type.Paginas;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Controller
@RequestMapping(value = "/autentica")
public class AutenticaController {

	private static final Logger logger = Logger.getLogger(AutenticaController.class);

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private TokenAuthenticationSuccessHandler successHandler;

	@Autowired
	private TokenAuthenticationProvider authenticationManager;

	@Autowired
	private SCTService sctService;

	@Autowired
	private MemoriaProcessamentoService memoriaProcessamentoService;

	@Autowired
	private PerfilComercialService perfilComercialService;		
	
	@Autowired
	private SolicitacaoCotacaoFakeService fakeService;
	
	@Autowired
	private PerfilComercialBloqueioAtividadeRepository perfilComercialBloqueioAtividadeRepository;
	
	@GetMapping
	public String autentica(HttpSession session, HttpServletRequest request,ModelMap model) {
		if(AmbienteUtil.isServidorDeProducao()) {
			throw new RuntimeException("Acesso inválido");
		}

		SolicitacaoCotacaoFakeCTPJ solicitacao = fakeService.bindSolcitacaoFake();
		
		model.addAttribute("solicitacao",JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(solicitacao));
		model.addAttribute("simulador","simulador");

		return Paginas.simulador.value();
	}

	@GetMapping(value = "/login")
	public ResponseEntity<Map<String,Object>> autentica(@ModelAttribute Autentica autentica,HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException {
		if(AmbienteUtil.isServidorDeProducao()) {
			throw new RuntimeException("Acesso inválido");
		}
		
		CtpjAuthenticationToken token = new CtpjAuthenticationToken(new CtpjToken("123",78,100120));
		token.setDetails(new WebAuthenticationDetails(request));
		Authentication auth;
		try {
			auth = authenticationManager.authenticate(token);
		} catch (AuthenticationException e) {
			logger.error("Falha na autenticação: ",e);
			return new ResponseEntity<Map<String,Object>>(Collections.singletonMap("sucesso",false),HttpStatus.OK);
		}

		SecurityContextHolder.getContext().setAuthentication(auth);
		successHandler.onAuthenticationSuccess(request,response,auth);

		HttpSession session = request.getSession(true);
		session.setAttribute("SPRING_SECURITY_CONTEXT",SecurityContextHolder.getContext());

		return new ResponseEntity<Map<String,Object>>(Collections.singletonMap("sucesso",true),HttpStatus.OK);
	}
	
	@GetMapping(value="/endosso")
	public String autenticaEndosso(HttpSession session,HttpServletRequest request,ModelMap model) {
		if(AmbienteUtil.isServidorDeProducao()) {
			throw new RuntimeException("Acesso inválido");
		}

		SolicitacaoCotacaoFakeCTPJ solicitacao = fakeService.bindSolcitacaoFake();
		fakeService.bindComplementoEndosso(solicitacao);
		
		model.addAttribute("tipoEndossos", Arrays.asList(TipoEndossoSctEnum.values()));
		model.addAttribute("solicitacao", JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(solicitacao));
		model.addAttribute("simulador","simulador");

		return Paginas.simulador.value();
	}

	@PostMapping(value = "/cotador")
	public @ResponseBody ResponseEntity<Object> cotador(@RequestBody SolicitacaoCotacaoFakeCTPJ solicitacao,HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException {
		ResultadoREST<BigInteger> nrCotacaoAjax = new ResultadoREST<BigInteger>();
		try {
			nrCotacaoAjax.setSuccess(true);			

			CtpjToken ctpjToken = new CtpjToken();
			ctpjToken.setSolicitacaoCotacao(solicitacao);
			ctpjToken.setFake(true);
			ctpjToken.setCdGrpEnum(GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(solicitacao.getCdGrp()));
			ctpjToken.setCdUsuro(solicitacao.getCdUsuro());
			CtpjAuthenticationToken token = new CtpjAuthenticationToken(ctpjToken);
			token.setDetails(new WebAuthenticationDetails(request));
			Authentication auth = authenticationManager.authenticate(token);
			SecurityContextHolder.getContext().setAuthentication(auth);
			HttpSession session = request.getSession(true);
			session.setAttribute("SPRING_SECURITY_CONTEXT",SecurityContextHolder.getContext());
			session.setAttribute(CTP.ctpjToken.value(),ctpjToken);
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if(!perfilComercialService.hasPerfilComercial(GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(solicitacao.getCdGrp())) 
					&& !perfilComercialService.hasPerfilCalculo(user.getCdUsuro(),new Date())) {
				throw new BadCredentialsException(String.format("Usuário %s sem Perfil de Cálculo!",user.getCdUsuro()));
			}			

			Cotacao cotacao = null;
			
			if (solicitacao.isRecalculo()) {
				cotacao = cotacaoService.findByNumeroCotacaoProposta(solicitacao.getNrSolctCotac());
				if(cotacao != null){
					nrCotacaoAjax.setRetornoObj(cotacao.getSequencialCotacaoProposta());
					request.getSession().setAttribute("successHandlerFake", cotacao.getSequencialCotacaoProposta());
					sctService.saveLoginSct(cotacao,"Login Fake SCT",JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(solicitacao),new StringBuilder("Login Fake para entrada no Cotador"),user);
					memoriaProcessamentoService.saveMemoria(cotacao,user,token.getToken().getSbMemoria(),TipoMemoriaEnum.LOGIN_SCT);
				}
			}
			
		} catch (final Exception e) {
			logger.error("Falha na autenticação Fake: ",e);
			nrCotacaoAjax.setSuccess(false);
			nrCotacaoAjax.setMensagem(e.getMessage());
		}

		return new ResponseEntity<Object>(nrCotacaoAjax, HttpStatus.OK);
	}
	
	@GetMapping(value = "/cotacaoSimulador/{sqCotacao}")
	public String cotacaoSimulador(@PathVariable(value = "sqCotacao") BigInteger sqCotacao,HttpSession session,HttpServletRequest request,ModelMap model) {
		if(AmbienteUtil.isServidorDeProducao()) {
			throw new RuntimeException("Acesso inválido");
		}
		return Paginas.simulador.value();
	}

	@GetMapping(value = "/sair")
	@ResponseBody
	public ResponseEntity<Object> sair(HttpServletRequest request,HttpServletResponse response) {
		
		logger.info("\tEfetuando logout...");
		
		try {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			if (auth != null) {
				new SecurityContextLogoutHandler().logout(request,response,auth);
			}
		} catch (final Exception e) {
			logger.error("Falha ao efetuar logout: ",e);
		}

		return new ResponseEntity<Object>("",HttpStatus.OK);

	}

}
