package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.enums.StatusEnum;
import br.com.tokiomarine.ctpj.exception.HibernateException;

@Repository
public class CotacaoLogRepository extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(CotacaoLogRepository.class);

	public void save(CotacaoLog cotacaoLog) throws HibernateException {
		try {
			super.getCurrentSession().save(cotacaoLog);
		} catch (Exception e) {
			logger.error("Erro ao Salvar Cotacao Log ",e);
			throw new HibernateException("Erro ao Salvar Cotacao Log ",e);
		}
	}

	public CotacaoLog getCotacaoLogBySessionIdAndSequencialCotacaoProposta(String sessionId,BigInteger sequencialCotacaoProposta) throws HibernateException {
		CotacaoLog log = null;
		try {
			Query query = getCurrentSession().createQuery(" SELECT	c FROM CotacaoLog c "
														+ "	where	c.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta = :sequencialCotacaoProposta "
														+ "	and		c.sessionId = :sessionId");
			query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta).setParameter("sessionId",sessionId);
			log = (CotacaoLog) query.uniqueResult();
		} catch (Exception e) {
			logger.error("Erro ao Buscar Log de Processamento MongoDB ",e);
			throw new HibernateException("Erro ao Bucar Log de Processamento MongoDB ",e);
		}
		return log;
	}
	
	public List<CotacaoLog> getCotacoesLogBySequencialCotacaoPropostaErro(BigInteger sequencialCotacaoProposta) throws HibernateException {
		List<CotacaoLog> logs = null;
		try {
			Query query = getCurrentSession().createQuery(" SELECT	c FROM CotacaoLog c "
														+ "	where	c.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta "
														+ "	and		c.statusLog =  :statusLog ");
			query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta).setParameter("statusLog",StatusEnum.ERRO.getId());
			logs =  query.list();
		} catch (Exception e) {
			logger.error("Erro ao Buscar Log de Erro ",e);
			throw new HibernateException("Erro ao Bucar Log de erros",e);
		}
		return logs;
	}
	
	public Optional<CotacaoLog> buscaCotacaoLogMaisRecente(BigInteger seqCotacao, Integer idTipoLog){
		String hql = new StringBuilder()
				.append("select l ")
				.append("from CotacaoLog l ")
				.append("where l.cotacao.sequencialCotacaoProposta = :seqCotacao and l.idTipoLog = :idTipoLog ")
				.append("order by l.dataAtualizacao desc")
				.toString();
		
		CotacaoLog log = (CotacaoLog) getCurrentSession()
				.createQuery(hql)
				.setParameter("seqCotacao", seqCotacao)
				.setParameter("idTipoLog", idTipoLog)
				.setMaxResults(1)
				.uniqueResult();
		
		
		return Optional.ofNullable(log);
	}

}
