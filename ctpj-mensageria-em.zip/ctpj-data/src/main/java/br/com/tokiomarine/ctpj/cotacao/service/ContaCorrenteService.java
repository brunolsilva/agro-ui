package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.repository.ContaCorrenteRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ContaCorrenteGlobal;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.exception.HibernateException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request.ProvisaoRequest;
import br.com.tokiomarine.ctpj.integracao.contacorrenteglobal.request.ValorDescontoRequest;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.ws.request.CotacaoRequest;

@Service
@Transactional(rollbackFor = {ServiceException.class,Exception.class})
public class ContaCorrenteService {

	private static Logger logger = LogManager.getLogger(ContaCorrenteService.class);

	@Autowired
	ProdutoRepository produtoRepository;

	@Autowired
	ContaCorrenteRepository repository;

	@Autowired
	ProdutoService produtoService;

	@LogPerformance
	/**
	 * retorna os dados utilizados nas chamadas da Conta Corrente Global - tabela CTP0105_CC_GLOBA
	 * 
	 * @param sequencialCotacaoProposta
	 * @return
	 * @throws ServiceException
	 */
	public Set<ContaCorrenteGlobal> findContaCorrenteGlobal(BigInteger sequencialCotacaoProposta) throws ServiceException {
		try {
			logger.info("find....");
			return repository.findContaCorrenteGlobal(sequencialCotacaoProposta);
		} catch (HibernateException re) {
			logger.error("Erro ao buscar dados da conta corrente global para a sq cotação: " + sequencialCotacaoProposta,re);
			throw new ServiceException(re.getMessage(),re);
		} catch (Exception e) {
			logger.error("Erro ao buscar dados da conta corrente global para a sq cotação: " + sequencialCotacaoProposta,e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	/**
	 * atualiza os dados da Conta Corrente Global - tabela CTP0105_CC_GLOBA
	 * 
	 * @param ccg
	 * @return
	 * @throws ServiceException
	 */
	private ContaCorrenteGlobal update(ContaCorrenteGlobal ccg) throws ServiceException {
		try {
			ContaCorrenteGlobal c = repository.update(ccg);
			return c;
		} catch (HibernateException h) {
			logger.error("Erro ao atualizar dados da conta corrente global");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao atualizar dados da conta corrente global");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	/**
	 * insere os dados da Conta Corrente Global - tabela CTP0105_CC_GLOBA
	 * 
	 * @param ccg
	 * @return
	 * @throws ServiceException
	 */
	private ContaCorrenteGlobal save(ContaCorrenteGlobal ccg) throws ServiceException {
		try {
			ContaCorrenteGlobal c = repository.save(ccg);
			return c;
		} catch (HibernateException h) {
			logger.error("Erro ao salvar dados da conta corrente global");
			throw new ServiceException(h.getMessage(),h);
		} catch (Exception e) {
			logger.error("Erro geral ao salvar dados da conta corrente global");
			throw new ServiceException(e.getMessage(),e);
		}
	}

	/**
	 * valida se o uso da Conta Corrente Global está liberado - verificação por Produto x Vigência
	 * 
	 * @param cotacao
	 * @return
	 */
	public Boolean isContaCorrenteLiberada(Cotacao cotacao) {
		// validacao produto vigencia
		ProdutoControle produtoControle = produtoService.findProdutoControleByCodigoAndVigencia(cotacao.getCodigoProduto(),cotacao.getDataInicioVigencia());

		if (produtoControle == null || produtoControle.getContaCorrente().equals(SimNaoEnum.NAO) || cotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR) { return false; }

		return true;
	}

	/**
	 * aplica os agravos e desconto(s) utilizados no conta corrente - tabela CTP0105_CC_GLOBA
	 * 
	 * @param cotacao
	 * @param provisao
	 * @return
	 * @throws ServiceException
	 */
	public ContaCorrenteGlobal aplicarAgravoDesconto(Cotacao cotacao,ProvisaoRequest provisao) throws ServiceException {
		ContaCorrenteGlobal ccg = null;
		if(cotacao.getListContaCorrenteGlobal() != null && !cotacao.getListContaCorrenteGlobal().isEmpty()) {
			ccg = cotacao.getListContaCorrenteGlobal().stream().findFirst().orElse(null);
			if(ccg != null) {
				atualizarAgravo(provisao, ccg);		
				atualizarDesconto(provisao, ccg);
				// atualiza os valores de conta corrente
				ccg = this.update(ccg);
			}
		}
		return ccg;
	}

	private void atualizarDesconto(ProvisaoRequest provisao, ContaCorrenteGlobal ccg) {
		ccg.setValorDescontoCCG(null);
		if (provisao.getListaValorDesconto() != null && !provisao.getListaValorDesconto().isEmpty()) {
			// obtém a soma total dos descontos
			BigDecimal somaTotalDescontos = BigDecimal.ZERO;
			for (ValorDescontoRequest d : provisao.getListaValorDesconto()) {
				somaTotalDescontos = somaTotalDescontos.add(d.getValorDesconto() == null ? BigDecimal.ZERO : d.getValorDesconto());
			}

			// verifica se a soma total dos descontos é maior que zero
			if (somaTotalDescontos.compareTo(BigDecimal.ZERO) > 0) {
				ccg.setValorDescontoCCG(somaTotalDescontos);
			}

		}
	}

	private void atualizarAgravo(ProvisaoRequest provisao, ContaCorrenteGlobal ccg) {
		ccg.setValorAgravoCCG(null);
		if (provisao.getValorAgravo() != null && provisao.getValorAgravo().compareTo(BigDecimal.ZERO) > 0) {
			ccg.setValorAgravoCCG(provisao.getValorAgravo());
		}
	}

	@LogPerformance
	public void bindContaCorrenteGlobalByEntradaSCT(CtpjToken token,Cotacao cotacao, HttpServletRequest request) throws ServiceException {

		try {
			ContaCorrenteGlobal retContaCorrenteGlobal = findContaCorrenteGlobal(cotacao.getSequencialCotacaoProposta()).stream()
					.findFirst()
					.orElse(new ContaCorrenteGlobal());
			
			logger.info("Entrada bindContaCorrenteGlobalByEntradaSCT");

			if (token == null || token.getSolicitacaoCotacao() == null) {
				
				logger.info(" token ou Solicitacao nulo ");
				
			} else {

				SolicitacaoCotacao solicitacaoCotacao = token.getSolicitacaoCotacao();
				if (solicitacaoCotacao.getIdUsuroPrtal() != null && !solicitacaoCotacao.getIdUsuroPrtal().isEmpty()) {
					retContaCorrenteGlobal.setCodigoUsuarioPortal(new BigInteger(solicitacaoCotacao.getIdUsuroPrtal()));
				}
				
				String cpf = request.getHeader("CPF");
				cpf = StringUtils.isBlank(cpf) ? request.getHeader("cpf") : cpf; 
				logger.info("CPF do usuário logado: " + cpf);

				if(!StringUtils.isBlank(cpf)) {
					cpf = cpf.replace(".", "");
					cpf = cpf.replace("-", "");
					logger.info("CPF do usuário logado " + cpf);
					retContaCorrenteGlobal.setNumeroCPFPortal(Long.parseLong(cpf));
				} else {
					if (solicitacaoCotacao.getCpfUsuroPrtal() != null) {
						retContaCorrenteGlobal.setNumeroCPFPortal(solicitacaoCotacao.getCpfUsuroPrtal());
					}
				}

				if (solicitacaoCotacao.getCdNivelHierarquico() != null) {
					retContaCorrenteGlobal.setNumeroNivelHierarquicoPortal(new BigInteger(solicitacaoCotacao.getCdNivelHierarquico().toString()));
				}

				if (solicitacaoCotacao.getCdPnPmrio() != null && !",".equals(solicitacaoCotacao.getCdPnPmrio())) {
					retContaCorrenteGlobal.setCodigoParceiroNegocioPortal(solicitacaoCotacao.getCdPnPmrio());
				}

				if (solicitacaoCotacao.getNmPnPmrio() != null && !solicitacaoCotacao.getNmPnPmrio().isEmpty()) {
					retContaCorrenteGlobal.setNomeParceiroNegocioPortal(StringUtils.substring(solicitacaoCotacao.getNmPnPmrio(), 0, 100));
				}

				if (solicitacaoCotacao.getTpPnPmrio() != null && !solicitacaoCotacao.getTpPnPmrio().isEmpty()) {
					retContaCorrenteGlobal.setTipoParceiroNegocioPortal(new BigInteger(solicitacaoCotacao.getTpPnPmrio()));
				}

				if (solicitacaoCotacao.getDsTipoParceiro() != null && !solicitacaoCotacao.getDsTipoParceiro().isEmpty()) {
					retContaCorrenteGlobal.setDescricaoParceiroNegocioPortal(solicitacaoCotacao.getDsTipoParceiro());
				}

				if (solicitacaoCotacao.getCodigoCPFIndicadorVendaParceiroNegocio() != null) {
					retContaCorrenteGlobal.setCodigoCPFIndicadorVendaParceiroNegocio(solicitacaoCotacao.getCodigoCPFIndicadorVendaParceiroNegocio());
				}

				if (retContaCorrenteGlobal != null) {
					retContaCorrenteGlobal.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
					retContaCorrenteGlobal.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
					retContaCorrenteGlobal.setDataAtualizacao(new Date());
					retContaCorrenteGlobal.setUsuarioAtualizacao(cotacao.getUsuarioAtualizacao());
					retContaCorrenteGlobal.setCodigoGrupo(cotacao.getCodigoGrupo());

					retContaCorrenteGlobal.setCotacao(cotacao);
					this.save(retContaCorrenteGlobal);
				}
			}

		} catch (Exception e) {
			logger.error("Erro bind ContaCorrenteGlobal " + e.getMessage(),e);
			throw new ServiceException("Erro bind ContaCorrenteGlobal " + e.getMessage(),e);
		}

	}

	@LogPerformance
	public ContaCorrenteGlobal bindContaCorrenteGlobal(Cotacao cotacao, CotacaoRequest cotacaoRequest, String nomeParceiro) throws ServiceException {
		logger.info("Entrada bindContaCorrenteGlobalByEntradaSCT");
		try {
			ContaCorrenteGlobal retContaCorrenteGlobal;
			retContaCorrenteGlobal = findContaCorrenteGlobal(cotacao.getSequencialCotacaoProposta()).stream()
					.findFirst()
					.orElse(new ContaCorrenteGlobal());

			retContaCorrenteGlobal.setTipoParceiroNegocioPortal(new BigInteger("9"));
			if(cotacaoRequest.getCodigoParceiroNegocio() != null) {
				retContaCorrenteGlobal.setCodigoParceiroNegocioPortal(cotacaoRequest.getCodigoParceiroNegocio());
			} else {
				retContaCorrenteGlobal.setTipoParceiroNegocioPortal(new BigInteger("3"));
				retContaCorrenteGlobal.setCodigoParceiroNegocioPortal(cotacao.getCodigoCorretorACSEL());
			}
			retContaCorrenteGlobal.setNumeroNivelHierarquicoPortal(new BigInteger("50"));
			retContaCorrenteGlobal.setNumeroCPFPortal(cotacaoRequest.getCpfEmissor().longValue());
			retContaCorrenteGlobal.setNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
			retContaCorrenteGlobal.setVersaoCotacaoProposta(cotacao.getVersaoCotacaoProposta());
			retContaCorrenteGlobal.setDataAtualizacao(new Date());
			retContaCorrenteGlobal.setUsuarioAtualizacao(cotacao.getUsuarioAtualizacao());
			retContaCorrenteGlobal.setCodigoGrupo(cotacao.getCodigoGrupo());
			retContaCorrenteGlobal.setNomeParceiroNegocioPortal(nomeParceiro);

			retContaCorrenteGlobal.setCotacao(cotacao);
			return save(retContaCorrenteGlobal);
		} catch (Exception e) {
			logger.error("Erro bind ContaCorrenteGlobal " + e.getMessage(),e);
			throw new ServiceException("Erro bind ContaCorrenteGlobal " + e.getMessage(),e);
		}

	}
	
	public Boolean hasDescontoAplicado(ContaCorrenteGlobal ccg) {
		return ccg.getValorDescontoCCG() != null && ccg.getValorDescontoCCG().compareTo(BigDecimal.ZERO) > 0;
	}
}
