package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.InspecaoRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemInspecao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.NegocioException;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoEndosso;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoGrupoProduto;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoGrupoRubrica;
import br.com.tokiomarine.ctpj.infra.domain.InspecaoGrupoValidade;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoInspecao;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.InspecaoInfraRepository;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.inspecao.NecessidadeInspecao;
import br.com.tokiomarine.ctpj.inspecao.request.NecessidadeInspecaoRequest;
import br.com.tokiomarine.ctpj.inspecao.response.NecessidadeInspecaoResponse;
import br.com.tokiomarine.ctpj.mapper.ItemInspecaoMapper;
import br.com.tokiomarine.ctpj.sct.response.DadosInspecaoSctResponse;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;
import br.com.tokiomarine.ctpj.util.CnpjCpfUtil;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

/**
 * @author Hromenique Cezniowscki Leite Batista
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class InspecaoService {

	private static Logger logger = LogManager.getLogger(InspecaoService.class);

	@Autowired
	private InspecaoRepository inspecaoRepository;

	@Autowired
	private InspecaoInfraRepository inspecaoInfraRepository;

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private CotacaoService cotacaoService;

	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ItemInspecaoMapper mapper;

	/**
	 * Inclui um ItemInspecao para um dado Item de Cotacao/Cotacao
	 * 
	 * @param itemInsp ItemInspecao a ser incluído
	 * @return ItemInspecao incluído
	 * @throws NegocioException Quando já existe uma inspeção para o item da cotação
	 */
	public ItemInspecao incluiItemInspecao(ItemInspecao itemInsp) {
		if (existeItemInspecaoPara(itemInsp.getItemCotacao())) {
			throw new NegocioException(msgItemInspecaoJaExistenteParaItemCotacao(itemInsp.getItemCotacao()));
		}
		return inspecaoRepository.salvaItemInspecao(itemInsp);
	}

	/**
	 * Inclui um ItemInspecao para todos os itens de uma dada Cotacao
	 * 
	 * @param itemInspecao ItemInspecao a ser incluído
	 * @param cotacao Cotacao para a qual cada um dos seus itens terá a inclusão do ItemInspecao
	 * @return
	 * @throws ServiceException
	 * @throws NegocioException Quando já existe uma inspeção para o item da cotação
	 */
	public List<ItemInspecao> incluiItemInspecaoParaTodosItensDaCotacao(ItemInspecao itemInspecao,Cotacao cotacao) throws ServiceException {
		return incluiItemInspecaoParaTodosItensDaCotacao(itemInspecao,cotacao.getSequencialCotacaoProposta());
	}

	/**
	 * @param itemInspecao
	 * @param sequencialCotacaoProposta
	 * @return
	 * @throws ServiceException
	 * @throws NegocioException Quando já existe uma inspeção para o item da cotação
	 */
	public List<ItemInspecao> incluiItemInspecaoParaTodosItensDaCotacao(ItemInspecao itemInspecao,BigInteger sequencialCotacaoProposta) throws ServiceException {

		List<ItemCotacao> itensCotacao;
		try {
			itensCotacao = cotacaoRepository.getItemsComEndereco(sequencialCotacaoProposta);
		} catch (RepositoryException e) {
			throw new ServiceException(e);
		}

		if (itensCotacao.get(0).getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO) {
			List<ItemCotacao> itemsEndosso = new ArrayList<>();
			for (ItemCotacao item : itensCotacao) {
				if (TipoEndossoEnum.isItemAlteracaoInclusao(item.getIdTipoEndosso(),itensCotacao.get(0).getCotacao().getIdLmiUnico().getLogical())) {
					itemsEndosso.add(item);
				}
			}
			itensCotacao = new ArrayList<>(itemsEndosso);
		}

		List<ItemInspecao> itensInspecao = new ArrayList<>();

		itensCotacao.forEach(item -> {
			if (!existeItemInspecaoPara(item)) {
				ItemInspecao itemInsp = new ItemInspecao();
				BeanUtils.copyProperties(itemInspecao,itemInsp);
				itemInsp.setItemCotacao(item);

				inspecaoRepository.salvaItemInspecao(itemInsp);
				itensInspecao.add(itemInsp);
			}
		});

		return itensInspecao;
	}

	public List<ItemInspecao> listaItensInspecaoPorCotacao(BigInteger sequencialCotacaoProposta) {
		return inspecaoRepository.listaItensInspecaoPorCotacao(sequencialCotacaoProposta);
	}

	public void excluiItemInspecao(BigInteger idItemInspecao) {
		inspecaoRepository.excluiItemInspecao(idItemInspecao);
	}

	/**
	 * Verifica se existe um item inspecação cadastrado para um itemCotacao
	 * 
	 * @param itemCotacao ItemCotacao para verificação
	 * @return true se existe um ItemInspecao cadastrado para o ItemCotacao, false para o caso contrário
	 */
	private boolean existeItemInspecaoPara(ItemCotacao itemCotacao) {
		ItemInspecao item = inspecaoRepository.buscaItemInspecaoPorItemCotacao(itemCotacao);
		return item != null ? true : false;
	}

	private String msgItemInspecaoJaExistenteParaItemCotacao(ItemCotacao itemCotacao) {
		return "Já existe uma inspeção para o item da cotação " + getDescricaoItemCotacao(itemCotacao);
	}

	private String getDescricaoItemCotacao(ItemCotacao item) {
		String numeroItem = seNuloSubstituiPorVazio(item.getNumeroItem());
		String enderecoLocalRisco = item.getEnderecoLocalRisco();
		String numeroEnderecoLocalRisco = seNuloSubstituiPorVazio(item.getNumeroEnderecoLocalRisco());
		String nomeMunicipioLocalRisco = seNuloSubstituiPorVazio(item.getNomeMunicipioLocalRisco());
		String idUFLocalRisco = seNuloSubstituiPorVazio(item.getIdUFLocalRisco());
		String idCEPLocalRisco = seNuloSubstituiPorVazio(item.getIdCEPLocalRisco());

		return String.format("%s - %s %s %s - %s %s",numeroItem,enderecoLocalRisco,numeroEnderecoLocalRisco,nomeMunicipioLocalRisco,idUFLocalRisco,idCEPLocalRisco);
	}

	private String seNuloSubstituiPorVazio(Object obj) {
		if (obj == null)
			return "";

		return obj.toString();
	}

	/**
	 * Verifica se existe a necessidade de inspeção cadastrado para um itemCotacao
	 * 
	 * @param itemCotacao ItemCotacao
	 * @return true se existe Necessidade de Inspeção, false para o caso contrário
	 */
	@LogPerformance
	public boolean existeNecessidadeInspecaoItem(
			ItemCotacao itemCotacao,
			Map<BigInteger, List<ItemInspecao>> duplicidadeInspecaoPorItem,
			Map<BigInteger, Date> ultimaInspecaoPorCotacao) {

		Date dataCalculo = new Date();

		List<ItemInspecao> listaDuplicidadeItemItemInspecao = duplicidadeInspecaoPorItem.get(itemCotacao.getNumeroItem());
		if (listaDuplicidadeItemItemInspecao != null && !listaDuplicidadeItemItemInspecao.isEmpty()) {
			return false;
		}

		if (itemCotacao.getCotacao().getIdTipoPedidoCotacao().equals(TipoPedidoCotacaoEnum.APOLICE)) {
			if (itemCotacao.getIdTipoSeguro().equals(TipoSeguroEnum.RENOVACAO_TOKIO) || itemCotacao.getIdTipoSeguro().equals(TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR)) {

				if (itemCotacao.getPercentualSinistralidade() != null && BigDecimalUtil.maior(itemCotacao.getPercentualSinistralidade(),BigDecimal.ZERO)) {
					return true;
				}
				
				/*
				OBS: esta validação será feita para próxima entrega
				if(isVistoriaDentroDaValidade(itemCotacao, ultimaInspecaoPorCotacao, dataCalculo))
				{
					return hasDadosAlterados(itemCotacao);
				}
				*/
			}
			
			return existeNecessidadeProdutoInspecao(itemCotacao,dataCalculo);
			
		} else {
			
			if (existeNecessidadeInspecaoEndosso(itemCotacao,dataCalculo)) {
				return existeNecessidadeProdutoInspecao(itemCotacao,dataCalculo);
			} else {
				return false;
			}
		}
	}
	
	private boolean hasDadosAlterados(ItemCotacao itemCotacao) {
		Long codigoRubricaRenov = 0L;
		Long cepLocalRiscoRenov = 0L;
		BigDecimal valorIsRenov = BigDecimal.ZERO;
		
		if (itemCotacao.getHashRenovacao() != null) {
			codigoRubricaRenov = new Long(itemCotacao.getHashRenovacao().substring(0,10));
			cepLocalRiscoRenov = new Long(itemCotacao.getHashRenovacao().substring(10,20));
			valorIsRenov = new BigDecimal(itemCotacao.getHashRenovacao().substring(20,34)).divide(new BigDecimal("100"));
		}
		
		ItemCobertura coberturaBasica = itemCotacao.getListItemCobertura()
				.stream()
				.filter(cob -> cob.getIdTipoCobertura().equals(1))
				.findFirst()
				.orElseThrow(() -> new RuntimeException("Não possui cobertura básica"));
		
		return !(codigoRubricaRenov.equals(itemCotacao.getCodigoRubrica()) 
				&& cepLocalRiscoRenov.equals(itemCotacao.getIdCEPLocalRisco()) 
				&& valorIsRenov.compareTo(coberturaBasica.getValorImportanciaSegurada()) == 0);
	}
	
	private Boolean isVistoriaDentroDaValidade(ItemCotacao itemCotacao, Map<BigInteger, Date> ultimaInspecaoPorCotacao, Date dataCalculo) {
		Date dataRelatorio = ultimaInspecaoPorCotacao.get(itemCotacao.getNumeroItem());
		Integer validadeAno = buscaNumeroAnosValidadeInspecao(itemCotacao.getCotacao().getCodigoProduto(),itemCotacao.getCodigoRubrica(),dataCalculo);
		return dataRelatorio != null && DateUtils.addYears(dataRelatorio,validadeAno).before(new Date());
	}
	
	public Boolean existeNecessidadeInspecaoEndosso(ItemCotacao itemCotacao,Date dataCalculo) {
		Boolean necessidadeInspecaoTipoPedidoCotacao = false;
		List<AlteracaoEndosso> listAlteracaoEndossoCotacao = cotacaoService.findAlteracaoEndossoByItemCotacao(itemCotacao);
		for (AlteracaoEndosso alteracaoEndosso : listAlteracaoEndossoCotacao) {
			List<ItemRamoEmissao> listItemRamoEmissao = cotacaoService.findItemRamoEmissaoByItemCotacao(itemCotacao);
			for (ItemRamoEmissao itemRamoEmissao : listItemRamoEmissao) {
				InspecaoEndosso inspecaoEndosso = inspecaoInfraRepository.findInspecaoEndosso(
						itemRamoEmissao.getCodigoGrupoRamo(),
						itemRamoEmissao.getCodigoRamo(),
						alteracaoEndosso.getCodigoTipoAlteracao(),
						dataCalculo);
				if (inspecaoEndosso != null) {
					necessidadeInspecaoTipoPedidoCotacao = true;
					break;
				}
			}
			if (necessidadeInspecaoTipoPedidoCotacao) {
				break;
			}
		}

		return necessidadeInspecaoTipoPedidoCotacao;
	}

	public Boolean existeNecessidadeProdutoInspecao(ItemCotacao itemCotacao,Date dataCalculo) {
		Boolean necessidadeProdutoInspecao = false;
		for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
			ProdutoInspecao produtoInspecao = inspecaoInfraRepository.findProdutoInspecao(
					itemCotacao.getCotacao().getCodigoProduto(),itemCobertura.getCodigoGrupoRamoEmissao(),
					itemCobertura.getCodigoRamoCoberturaEmissao(),itemCotacao.getIdTipoSeguro(),
					itemCobertura.getCodigoCobertura(),itemCotacao.getCodigoRubrica(),
					itemCotacao.getCodigoClasseConstrucao(),itemCotacao.getCodigoLocalizacao(),
					itemCotacao.getValorRiscoBem(),dataCalculo);
			if (produtoInspecao != null) {
				necessidadeProdutoInspecao = true;
				break;
			}
		}
		return necessidadeProdutoInspecao;
	}

	public void atualizaEmailCorretorInspecao(BigInteger sequencialCotacaoProposta,String emailCorretorInspecao) {
		if (emailCorretorInspecao != null && !emailCorretorInspecao.isEmpty()) {
			Cotacao cotacao = cotacaoRepository.findCompleta(sequencialCotacaoProposta);
			cotacao.setEmailCorretorInspecao(emailCorretorInspecao);
			cotacaoRepository.update(cotacao);
		}
	}

	public Integer buscaNumeroAnosValidadeInspecao(Integer produto,Long rubrica,Date dataInicioVigencia) {
		InspecaoGrupoValidade inspecaoGrupoValidade;
		InspecaoGrupoRubrica inspecaoGrupoRubrica = inspecaoInfraRepository.findInspecaoGrupoRubrica(produto,rubrica,dataInicioVigencia);

		if (inspecaoGrupoRubrica != null && inspecaoGrupoRubrica.getGrupo() != null) {
			inspecaoGrupoValidade = inspecaoInfraRepository.findInspecaoGrupoValidade(inspecaoGrupoRubrica.getGrupo());
			if (inspecaoGrupoValidade != null && inspecaoGrupoValidade.getNumeroAnosValidade() != null) {
				return inspecaoGrupoValidade.getNumeroAnosValidade();
			}
		}

		InspecaoGrupoProduto inspecaoGrupoProduto = inspecaoInfraRepository.findInspecaoGrupoProduto(produto,dataInicioVigencia);
		if (inspecaoGrupoProduto != null && inspecaoGrupoProduto.getGrupo() != null) {
			inspecaoGrupoValidade = inspecaoInfraRepository.findInspecaoGrupoValidade(inspecaoGrupoProduto.getGrupo());
			if (inspecaoGrupoValidade != null && inspecaoGrupoValidade.getNumeroAnosValidade() != null) {
				return inspecaoGrupoValidade.getNumeroAnosValidade();
			}
		}
		
		return 0;
		
	}

	public List<ItemInspecao> buscarDuplicidadeItemInspecao(ItemCotacao itemCotacao) {
		return inspecaoRepository.buscarDuplicidadeItemInspecao(itemCotacao);
	}

	@LogPerformance
	public NecessidadeInspecaoResponse verificaNecessidadeInspecaoItemRenovacao(Cotacao cotacao) {
		List<NecessidadeInspecao> listNecessidadeInspecaoRenovacao = this.bindListNecessidadeInspecaoRenovacao(cotacao);
		return servicoNecessidadeInspecao(listNecessidadeInspecaoRenovacao);
	}
	
	private List<NecessidadeInspecao> bindListNecessidadeInspecaoRenovacao(Cotacao cotacao) {

		List<NecessidadeInspecao> listItemNecessidadeInspecaoRenovacaoTokio = new ArrayList<>();

		for (Iterator<ItemCotacao> iteratorItemCotacao = cotacao.getListItem().iterator() ; iteratorItemCotacao.hasNext() ;) {

			ItemCotacao itemCotacao = (ItemCotacao) iteratorItemCotacao.next();

			NecessidadeInspecao itemRenovacaoNecessidadeInspecao = new NecessidadeInspecao();
			
			if(itemCotacao.getSequencialItemCotacao() != null) {
				itemRenovacaoNecessidadeInspecao.setSequencialItemCotacao(itemCotacao.getSequencialItemCotacao());
			}
			
			itemRenovacaoNecessidadeInspecao.setCodigoRamoProdutoTmsr(itemCotacao.getCodigoRamoProdutoRenovada());
			itemRenovacaoNecessidadeInspecao.setCodigoApoliceTmsr(itemCotacao.getCodigoApoliceRenovada() != null ? itemCotacao.getCodigoApoliceRenovada().intValue(): null);
			itemRenovacaoNecessidadeInspecao.setCodigoItemApolice(itemCotacao.getCodigoItemRenovada());
			itemRenovacaoNecessidadeInspecao.setCodigoProduto(cotacao.getCodigoProduto());
			itemRenovacaoNecessidadeInspecao.setCodigoRubricaCtpj(itemCotacao.getCodigoRubrica().intValue());
			itemRenovacaoNecessidadeInspecao.setIdentificadorCepLocalRisco(itemCotacao.getIdCEPLocalRisco());
			itemRenovacaoNecessidadeInspecao.setNumeroEnderecoRisco(itemCotacao.getNumeroEnderecoLocalRisco() != null ? itemCotacao.getNumeroEnderecoLocalRisco(): 0L);

			for (ItemCobertura cobertura : itemCotacao.getListItemCobertura().stream().filter(cb -> cb.getIdTipoCobertura() == 1).collect(Collectors.toList())) {
				itemRenovacaoNecessidadeInspecao.setCodigoCoberturaCtpj(cobertura.getCodigoCobertura());
			}

			if (itemCotacao.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
					itemRenovacaoNecessidadeInspecao.setNumeroCgcCpfSegurado(CnpjCpfUtil.getInstance().getRaizCpf(itemCotacao.getNumeroCNPJCPFSegurado().toString()));
					itemRenovacaoNecessidadeInspecao.setNumeroEstabelecimentoSegurado(0);
					itemRenovacaoNecessidadeInspecao.setNumeroDigitoVerificador(CnpjCpfUtil.getInstance().getDigitoCpf(itemCotacao.getNumeroCNPJCPFSegurado().toString()).intValue());
			} else if (itemCotacao.getIdTipoPessoa() == TipoSeguradoEnum.JURIDICA) {
				itemRenovacaoNecessidadeInspecao.setNumeroCgcCpfSegurado(CnpjCpfUtil.getInstance().getRaizCnpj(itemCotacao.getNumeroCNPJCPFSegurado().toString()));
				itemRenovacaoNecessidadeInspecao.setNumeroEstabelecimentoSegurado(CnpjCpfUtil.getInstance().getEstabelecimentoCnpj(itemCotacao.getNumeroCNPJCPFSegurado().toString()).intValue());
				itemRenovacaoNecessidadeInspecao.setNumeroDigitoVerificador(CnpjCpfUtil.getInstance().getDigitoCnpj(itemCotacao.getNumeroCNPJCPFSegurado().toString()).intValue());
			}
			listItemNecessidadeInspecaoRenovacaoTokio.add(itemRenovacaoNecessidadeInspecao);
		}

		return listItemNecessidadeInspecaoRenovacaoTokio;
	}
	
	@LogPerformance
	public NecessidadeInspecaoResponse servicoNecessidadeInspecao(List<NecessidadeInspecao> listItemNecessidadeInspecaoRenovacao) {

		NecessidadeInspecaoResponse response = new NecessidadeInspecaoResponse();

		try {

			NecessidadeInspecaoRequest request = new NecessidadeInspecaoRequest();
			request.setListNecessidadeInspecaoResquest(listItemNecessidadeInspecaoRenovacao);

			URI uri = new URI(parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroNecessidadeInspecaoRenovacao()));
			
			logger.info("request: "+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request));
			
			ResponseEntity<NecessidadeInspecaoResponse> responseType = restTemplate.postForEntity(uri,request,NecessidadeInspecaoResponse.class);
			response = responseType.getBody();
			
			logger.info("response: "+JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));

		} catch (Exception e) {
			logger.error("Erro ao consultar o serviço de necessidade de inspeção ",e);
			List<Mensagem> mensagens = new ArrayList<>();
			Mensagem mensagem = new Mensagem();
			mensagem.setCodigo(1);
			mensagem.setDescricao(e.getMessage());
			mensagens.add(mensagem);
			response.setSucesso(false);
			response.setMensagens(mensagens);
		}
		return response;
	}
	
	@LogPerformance 
	public void existeNecessidadeInspecaoRenovacao(
			Cotacao cotacao,
			Map<BigInteger, List<ItemInspecao>> duplicidadeInspecaoPorItem,
			Map<BigInteger, Date> ultimaInspecaoPorCotacao) {
		if(cotacao.getIdDestinoEmissao() != DestinoEmissaoEnum.ACX) {
			List<NecessidadeInspecao> listItemNecessidadeInspecaoRenovacaoTokio = new ArrayList<>();
			
			/*
			 * Iteração nos itens da cotação
			 * 
			 * se o item for Renovação Tokio ou RenovaçãoTokio Corretor, é montada a request para a
			 * chamada do serviço para verificar a necessidade de inspeção.
			 * 
			 * */
			for (ItemCotacao itemCotacao: cotacao.getListItem()) {
				
				if(itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO || itemCotacao.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_TOKIO_CORRETOR) {				
					NecessidadeInspecao itemRenovacaoNecessidadeInspecao = new NecessidadeInspecao();						
					itemRenovacaoNecessidadeInspecao.setSequencialItemCotacao(itemCotacao.getSequencialItemCotacao());
					itemRenovacaoNecessidadeInspecao.setCodigoRamoProdutoTmsr(itemCotacao.getCodigoRamoProdutoRenovada());
					itemRenovacaoNecessidadeInspecao.setCodigoApoliceTmsr(itemCotacao.getCodigoApoliceRenovada().intValue());
					itemRenovacaoNecessidadeInspecao.setCodigoItemApolice(itemCotacao.getCodigoItemRenovada());
					itemRenovacaoNecessidadeInspecao.setCodigoProduto(cotacao.getCodigoProduto());
					itemRenovacaoNecessidadeInspecao.setCodigoRubricaCtpj(itemCotacao.getCodigoRubrica().intValue());
					itemRenovacaoNecessidadeInspecao.setIdentificadorCepLocalRisco(itemCotacao.getIdCEPLocalRisco());
					itemRenovacaoNecessidadeInspecao.setNumeroEnderecoRisco(itemCotacao.getNumeroEnderecoLocalRisco());
					
					for (ItemCobertura cobertura : itemCotacao.getListItemCobertura().stream().filter(cb -> cb.getIdTipoCobertura() == 1)
							.collect(Collectors.toList())) {
						itemRenovacaoNecessidadeInspecao.setCodigoCoberturaCtpj(cobertura.getCodigoCobertura());
					}
					
					bindCpfCnpjNecessidadeInspecao(itemCotacao,itemRenovacaoNecessidadeInspecao);
					listItemNecessidadeInspecaoRenovacaoTokio.add(itemRenovacaoNecessidadeInspecao);
				}
			}
			
			/*
			 * Chamada do webservice para verificaçao da 
			 * necessidade de inspeção
			 * */
			if(!listItemNecessidadeInspecaoRenovacaoTokio.isEmpty()) {

				NecessidadeInspecaoResponse response = servicoNecessidadeInspecao(listItemNecessidadeInspecaoRenovacaoTokio);
				
				if(!response.isSucesso()) {
					String jsonResponse = JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response);
					logger.error(String.format("Erro ao consultar serviço necessidade de inspeção para a cotacao - [ %s ] - response: [ %s ] ",
							cotacao.getNumeroCotacaoProposta(),
							jsonResponse));	
					throw new RuntimeException(String.format("Erro ao consultar serviço necessidade de inspeção para a cotacao - [ %s ] - response: [ %s ] ",
							cotacao.getNumeroCotacaoProposta(),
							jsonResponse));
				}
				
				/*
				 * Iteração na lista retornada pelo webservice 
				 * para atualizar a necessidade inspeção dos itens da cotação
				 * 
				 * se o retorno do serviço para aquele item retornou S ou N
				 * é atualizado a necessidade de inspeção daquele item
				 * 
				 *  se não chama a validação já existente e o item é atualizado
				 * 
				 * */
				for (NecessidadeInspecao necessidadeInspecao: response.getListNecessidadeInspecao()) {
					for (ItemCotacao itemCotacao : cotacao.getListItem()
							.stream()
							.filter(it->it.getSequencialItemCotacao().equals(necessidadeInspecao.getSequencialItemCotacao()))
							.collect(Collectors.toList())){
						
						if(itemCotacao.getCodigoItemRenovada().equals(necessidadeInspecao.getCodigoItemApolice())) {
							if(necessidadeInspecao.getIdentificadorNecessidadeInspecao() == null) {
								itemCotacao.setIdNecessidadeInspecaoOriginal(SimNaoEnum.NAO);
								itemCotacao.setIdNecessidadeInspecao(SimNaoEnum.NAO);
							}else {
								SimNaoEnum identificadorNecessidadeInspecao = SimNaoEnum.getById(necessidadeInspecao.getIdentificadorNecessidadeInspecao());
								if(itemCotacao.getIdNecessidadeInspecao() == null) {
									itemCotacao.setIdNecessidadeInspecaoOriginal(identificadorNecessidadeInspecao);
									itemCotacao.setIdNecessidadeInspecao(identificadorNecessidadeInspecao);
								}
							}
						}
					}
				}
			}
		}
	}
	
	public Date buscarDataRelatorioUltimaInspecao(ItemCotacao itemCotacao) throws ServiceException {
		try {
			return inspecaoRepository.buscarDataRelatorioUltimaInspecao(itemCotacao);
		} catch(Exception e) {
			logger.error("Erro ao buscar a data de relatorio ultima inspecao", e);
			throw new ServiceException(
					String.format("Erro ao buscar a data de relatorio ultima inspecao [cotacao = %s item = %s]", 
							itemCotacao.getCotacao().getSequencialCotacaoProposta(),itemCotacao.getSequencialItemCotacao()), e);
		}
	}
	
	public List<ItemInspecao> salvaItemInspecao(BigInteger numeroCotacaoProposta, List<ItemInspecao> itens){
		inspecaoRepository.excluiItemInspecaoPorCotacao(numeroCotacaoProposta);
		if(!itens.isEmpty()) {
			inspecaoRepository.salvaItemInspecao(itens);
		}
		return itens;
	}

	private void bindCpfCnpjNecessidadeInspecao(ItemCotacao itemCotacao, NecessidadeInspecao necessidadeInspecao) {
		if (itemCotacao.getIdTipoPessoa() ==  TipoSeguradoEnum.FISICA) {
			necessidadeInspecao.setNumeroCgcCpfSegurado(CnpjCpfUtil.getInstance().getRaizCpf(itemCotacao.getNumeroCNPJCPFSegurado().toString()));
			necessidadeInspecao.setNumeroEstabelecimentoSegurado(0);
			necessidadeInspecao.setNumeroDigitoVerificador(CnpjCpfUtil.getInstance().getDigitoCpf(itemCotacao.getNumeroCNPJCPFSegurado().toString()).intValue());
		} else {
			necessidadeInspecao.setNumeroCgcCpfSegurado(CnpjCpfUtil.getInstance().getRaizCnpj(itemCotacao.getNumeroCNPJCPFSegurado().toString()));
			necessidadeInspecao.setNumeroEstabelecimentoSegurado(CnpjCpfUtil.getInstance().getEstabelecimentoCnpj(itemCotacao.getNumeroCNPJCPFSegurado().toString()).intValue());
			necessidadeInspecao.setNumeroDigitoVerificador(CnpjCpfUtil.getInstance().getDigitoCnpj(itemCotacao.getNumeroCNPJCPFSegurado().toString()).intValue());
		}
	}

	@LogPerformance 
	public void popularDadosInspecaoComDadosInspecaoSct(Cotacao cotacao, boolean save) throws RuntimeException {
		DadosInspecaoSctResponse consultaDadosInspecaoSct = null;
		for (ItemCotacao itemCotacao : cotacao.getListItem()
				.stream()
				.filter(it -> cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.ENDOSSO && it.getIdTipoEndosso() != null))
				.collect(Collectors.toList())) {
			if (itemCotacao.getListItemInspecao().stream().count() == 0){
				if (consultaDadosInspecaoSct == null) {
					consultaDadosInspecaoSct = this.consultaDadosInspecaoSct(cotacao.getNumeroCotacaoProposta());
				}
				Set<ItemInspecao> listItemInspecao = new LinkedHashSet<>();
				ItemInspecao itemInspecao = mapper.toItemInspecao(consultaDadosInspecaoSct,cotacao,itemCotacao);
				if (itemInspecao != null) {
					listItemInspecao.add(itemInspecao); 
					itemCotacao.setListItemInspecao(listItemInspecao);
				}
			}
		}
		if(save) {
			cotacaoRepository.save(cotacao);
		}
	}

	public DadosInspecaoSctResponse consultaDadosInspecaoSct(BigInteger numeroSolicitacaoCotacao) {
		DadosInspecaoSctResponse reponseDadosInspecaoSct = new DadosInspecaoSctResponse();
		try {
			String url;

			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroSctConsultaDadosInspecao();
			if (urlEnum == null) {
				logger.error("Erro ao na busca da url, urlEnum nula: " + urlEnum);
				throw new ServiceException("Não foi possível buscar os dados de inspeção do SCT. Favor tentar novamente.");
			}

			try {
				url = parametroGeralService.getUrlByNome(urlEnum);
			} catch (ServiceException e) {
				logger.error("Erro ao recuperar url ", e);
				throw new ServiceException("Não foi possível buscar os dados de inspeção do SCT. Favor tentar novamente.");
			}
			url = url+numeroSolicitacaoCotacao;
			logger.info("URL de consultaDadosInspecaoSct " + url);

			reponseDadosInspecaoSct = restTemplate.getForObject(url,DadosInspecaoSctResponse.class);

		} catch (HttpClientErrorException e) {
			logger.info("Erro buscar os dados de inspeção do SCT:", e);
			throw new RuntimeException("Não foi possível buscar os dados de inspeção do SCT. Favor tentar novamente.");
		} catch (Exception e) {
			logger.info("Erro buscar os dados de inspeção do SCT:", e);
		}
		
		return reponseDadosInspecaoSct;
	}
	
	public Cotacao findCotacaoItemInspecaoCompletaBySeqCotacao(BigInteger cotacao) throws ServiceException {
		Cotacao cotacaoEncontrada = cotacaoRepository.findCotacaoComItemInspecao(cotacao);
		popularDadosInspecaoComDadosInspecaoSct(cotacaoEncontrada,true);
		return cotacaoEncontrada;
	}
}