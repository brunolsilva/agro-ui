package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import br.com.tokiomarine.ctpj.cotacao.validator.constraint.IncluirParaTodos;

/**
 * @author Hromenique Cezniowscki Leite Batista
 */
@IncluirParaTodos(campoIncluirParaTodos = "incluirParaTodos",campoItemCotacao = "itemCotacao",message = "Item Cotação é obrigatório")
public class ItemInspecaoView {

	private BigInteger sequencialItemInspecao;

	@NotBlank(message = "Nome do Contato é obrigatório.")
	@Length(max = 100,message = "Nome do Contato deve possuir no máximo 100 caracteres.")
	private String descricaoContato;

	@Length(max = 4000,message = "Observação para a inspeção deve possuir no máximo 4000 caracteres.")
	private String descricaoObservacao;

	@NotNull(message = "Telefone 1 é obrigatório.")
	@Length(min = 10,max = 11,message = "Telefone 1 inválido.")
	private String numeroTelefone1;

	@Length(min = 10,max = 11,message = "Telefone 2 inválido.")
	private String numeroTelefone2;

	@Length(min = 10,max = 11,message = "Telefone 3 inválido.")
	private String numeroTelefone3;

	private String numeroRelatorio;

	private String situacao;

	private String dataAgendamento;

	private String parecer;

	private String laudoSemScore;

	private String dataRelatorio;

	private BigInteger itemCotacao;

	private BigInteger sequencialCotacaoProposta;

	@NotBlank(message = "E-mail do corretor é obrigatório.")
	@Length(max = 100,message = "Campo com no máximo 100 caracteres.") 
	@Email(message = "E-mail do corretor inválido.")
	private String emailCorretorInspecao;
	
	@Length(max = 100,message = "Campo com no máximo 100 caracteres.")
	@Email(message = "Endereço de e-mail do contato inválido.")
	private String emailContatoInspecao;	

	private Boolean incluirParaTodos = false;

	private String isExcluiItemDisabled = "Disabled";

	private String isSolicitaDisabled = "Disabled";

	private String isSolicitaCancelamentoDisabled = "Disabled";

	private String isConsultaInspecaoDisabled = "Disabled";

	public ItemInspecaoView() {
		this.numeroTelefone1 = "";
	}

	public ItemInspecaoView(BigInteger sequencialItemInspecao,String descricaoContato,String descricaoObservacao,String numeroTelefone1,String numeroTelefone2,String numeroTelefone3,String emailContatoInspecao,String numeroRelatorio,String situacao,String dataAgendamento,String parecer,String laudoSemScore,String dataRelatorio,String isExcluiItemDisabled,String isSolicitaDisabled,String isCancelaSolicitacaoDisabled,String isConsultaInspecaoDisabled, BigInteger itemCotacao,BigInteger sequencialCotacaoProposta) {
		super();
		this.sequencialItemInspecao = sequencialItemInspecao;
		this.descricaoContato = descricaoContato;
		this.descricaoObservacao = descricaoObservacao;
		this.numeroTelefone1 = numeroTelefone1;
		this.numeroTelefone2 = numeroTelefone2;
		this.numeroTelefone3 = numeroTelefone3;
		this.emailContatoInspecao = emailContatoInspecao;
		this.dataRelatorio = dataRelatorio;
		this.numeroRelatorio = numeroRelatorio;
		this.situacao = situacao;
		this.dataAgendamento = dataAgendamento;
		this.parecer = parecer;
		this.laudoSemScore = laudoSemScore;
		this.dataRelatorio = dataRelatorio;
		this.isExcluiItemDisabled = isExcluiItemDisabled;
		this.isSolicitaDisabled = isSolicitaDisabled;
		this.isSolicitaCancelamentoDisabled = isCancelaSolicitacaoDisabled;
		this.isConsultaInspecaoDisabled = isConsultaInspecaoDisabled;
		this.itemCotacao = itemCotacao;
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	public BigInteger getSequencialItemInspecao() {
		return sequencialItemInspecao;
	}

	public void setSequencialItemInspecao(BigInteger sequencialItemInspecao) {
		this.sequencialItemInspecao = sequencialItemInspecao;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public String getNumeroTelefone1() {
		return numeroTelefone1;
	}

	public void setNumeroTelefone1(String numeroTelefone1) {
		this.numeroTelefone1 = numeroTelefone1;
	}

	public String getNumeroTelefone2() {
		return numeroTelefone2;
	}

	public void setNumeroTelefone2(String numeroTelefone2) {
		this.numeroTelefone2 = numeroTelefone2;
	}

	public String getNumeroTelefone3() {
		return numeroTelefone3;
	}

	public void setNumeroTelefone3(String numeroTelefone3) {
		this.numeroTelefone3 = numeroTelefone3;
	}

	public String getNumeroRelatorio() {
		return numeroRelatorio;
	}
	
	public void setNumeroRelatorio(String numeroRelatorio) {
		this.numeroRelatorio = numeroRelatorio;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getDataAgendamento() {
		return dataAgendamento;
	}

	public void setDataAgendamento(String dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}

	public String getParecer() {
		return parecer;
	}

	public void setParecer(String parecer) {
		this.parecer = parecer;
	}

	public String getLaudoSemScore() {
		return laudoSemScore;
	}

	public void setLaudoSemScore(String laudoSemScore) {
		this.laudoSemScore = laudoSemScore;
	}

	public String getDataRelatorio() {
		return dataRelatorio;
	}

	public void setDataRelatorio(String dataRelatorio) {
		this.dataRelatorio = dataRelatorio;
	}

	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public String getDescricaoContato() {
		return descricaoContato;
	}

	public void setDescricaoContato(String descricaoContato) {
		this.descricaoContato = descricaoContato;
	}

	public Boolean getIncluirParaTodos() {
		return incluirParaTodos;
	}

	public void setIncluirParaTodos(Boolean incluirParaTodos) {
		this.incluirParaTodos = incluirParaTodos;
	}

	public String getIsExcluiItemDisabled() {
		return isExcluiItemDisabled;
	}

	public void setIsExcluiItemDisabled(String isExcluiItemDisabled) {
		this.isExcluiItemDisabled = isExcluiItemDisabled;
	}

	public String getIsSolicitaDisabled() {
		return isSolicitaDisabled;
	}

	public void setIsSolicitaDisabled(String isSolicitaDisabled) {
		this.isSolicitaDisabled = isSolicitaDisabled;
	}

	public String getIsSolicitaCancelamentoDisabled() {
		return isSolicitaCancelamentoDisabled;
	}

	public void setIsSolicitaCancelamentoDisabled(String isSolicitaCancelamentoDisabled) {
		this.isSolicitaCancelamentoDisabled = isSolicitaCancelamentoDisabled;
	}

	public String getIsConsultaInspecaoDisabled() {
		return isConsultaInspecaoDisabled;
	}

	public void setIsConsultaInspecaoDisabled(String isConsultaInspecaoDisabled) {
		this.isConsultaInspecaoDisabled = isConsultaInspecaoDisabled;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}

	public String getEmailCorretorInspecao() {
		return emailCorretorInspecao;
	}

	public void setEmailCorretorInspecao(String emailCorretorInspecao) {
		this.emailCorretorInspecao = emailCorretorInspecao;
	}

	public String getEmailContatoInspecao() {
		return emailContatoInspecao;
	}

	public void setEmailContatoInspecao(String emailContatoInspecao) {
		this.emailContatoInspecao = emailContatoInspecao;
	}
	
	

}
