package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.enums.ClasseBonusEnum;
import br.com.tokiomarine.ctpj.enums.SolicitanteEndossoEnum;
import br.com.tokiomarine.ctpj.infra.enums.ClassificacaoAtividadeEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemCotacaoView implements Serializable {

	private static final long serialVersionUID = 7989564235520374411L;

	private BigInteger sequencialItemCotacao;
	private BigInteger numeroItem;
	private TipoSeguroEnum idTipoSeguro;
	private String idCEPLocalRisco;
	private String enderecoLocalRisco;
	private String nomeBairroLocalRisco;
	private Long numeroEnderecoLocalRisco;
	private String nomeComplementoEnderecoLocalRisco;
	private Integer codigoMunicipioLocalRisco;
	private String nomeMunicipioLocalRisco;
	private String idUFLocalRisco;
	private Long codigoRubrica;
	private String descricaoRubrica;
	private ClassificacaoAtividadeEnum classificacaoRubrica;
	private Integer codigoClasseLocalizacao;
	private Integer codigoClasseOcupacao;
	private Integer codigoClasseConstrucao;
	private Integer codigoBemCoberto;
	private Integer codigoLocalizacao;
	private Integer codigoAmbitoGeografico;
	private String percentualRelacaoImportanciaSeguradaValorRisco;
	private String percentualRelacaoDMPValorRisco;
	private String valorRiscoBem;
	private String valorRiscoBemCalculado;
	private String valorMaiorRiscoIsolado;
	private SimNaoEnum idNecessidadeInspecao;
	private String descricaoRubricaAlternativa;
	private Integer codigoRegiaoTarifaria;
	private Boolean idVinilona;
	private Boolean idResseguroFacultativo;

	private Integer codigoRamoProdutoRenovada;
	private BigInteger codigoApoliceRenovada;
	private Long codigoItemRenovada;
	private Integer codigoCompanhiaSeguradora;
	private String numeroApoliceCongenere;
	private Long numeroItemApoliceCongenere;
	private String percentualSinistralidade;
	private ClasseBonusEnum codigoClasseBonus;
	private boolean coberturaAvulsaDM;
	private boolean coberturaAvulsaLC;
	private SolicitanteEndossoEnum idSolicitanteEndosso;
	private Integer idTipoEndosso;
	private boolean reintegracao = false;
	private String idMongoRenovacao;

	private List<Long> protecionais;
	private List<ItemDistribuicaoView> itemsDistribuicao = new ArrayList<>();
	private List<ItemCoberturaView> listCoberturaBasica = new ArrayList<>();
	private List<ItemCoberturaView> listCoberturaAcessoriaDM = new ArrayList<>();
	private List<ItemCoberturaView> listCoberturaAcessoriaLC = new ArrayList<>();

	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}

	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}

	public BigInteger getNumeroItem() {
		return numeroItem;
	}

	public void setNumeroItem(BigInteger numeroItem) {
		this.numeroItem = numeroItem;
	}

	public TipoSeguroEnum getIdTipoSeguro() {
		return idTipoSeguro;
	}

	public void setIdTipoSeguro(TipoSeguroEnum idTipoSeguro) {
		this.idTipoSeguro = idTipoSeguro;
	}

	public String getIdCEPLocalRisco() {
		if (idCEPLocalRisco != null && !idCEPLocalRisco.isEmpty()) {
			try {
				idCEPLocalRisco = StringUtils.leftPad(idCEPLocalRisco.replaceAll("-",""),8,"0");
			} catch (Exception e) {
				idCEPLocalRisco = null;
			}
		} else {
			idCEPLocalRisco = null;
		}
		return idCEPLocalRisco;
	}

	public void setIdCEPLocalRisco(String idCEPLocalRisco) {
		this.idCEPLocalRisco = idCEPLocalRisco;
	}

	public String getEnderecoLocalRisco() {
		return enderecoLocalRisco;
	}

	public void setEnderecoLocalRisco(String enderecoLocalRisco) {
		this.enderecoLocalRisco = enderecoLocalRisco;
	}

	public String getNomeBairroLocalRisco() {
		return nomeBairroLocalRisco;
	}

	public void setNomeBairroLocalRisco(String nomeBairroLocalRisco) {
		this.nomeBairroLocalRisco = nomeBairroLocalRisco;
	}

	public Long getNumeroEnderecoLocalRisco() {
		return numeroEnderecoLocalRisco;
	}

	public void setNumeroEnderecoLocalRisco(Long numeroEnderecoLocalRisco) {
		this.numeroEnderecoLocalRisco = numeroEnderecoLocalRisco;
	}

	public String getNomeComplementoEnderecoLocalRisco() {
		return nomeComplementoEnderecoLocalRisco;
	}

	public void setNomeComplementoEnderecoLocalRisco(String nomeComplementoEnderecoLocalRisco) {
		this.nomeComplementoEnderecoLocalRisco = nomeComplementoEnderecoLocalRisco;
	}

	public Integer getCodigoMunicipioLocalRisco() {
		return codigoMunicipioLocalRisco;
	}

	public void setCodigoMunicipioLocalRisco(Integer codigoMunicipioLocalRisco) {
		this.codigoMunicipioLocalRisco = codigoMunicipioLocalRisco;
	}

	public String getNomeMunicipioLocalRisco() {
		return nomeMunicipioLocalRisco;
	}

	public void setNomeMunicipioLocalRisco(String nomeMunicipioLocalRisco) {
		this.nomeMunicipioLocalRisco = nomeMunicipioLocalRisco;
	}

	public String getIdUFLocalRisco() {
		return idUFLocalRisco;
	}

	public void setIdUFLocalRisco(String idUFLocalRisco) {
		this.idUFLocalRisco = idUFLocalRisco;
	}

	public Long getCodigoRubrica() {
		return codigoRubrica;
	}

	public void setCodigoRubrica(Long codigoRubrica) {
		this.codigoRubrica = codigoRubrica;
	}
	
	public String getDescricaoRubrica() {
		return descricaoRubrica;
	}
	
	public void setDescricaoRubrica(String descricaoRubrica) {
		this.descricaoRubrica = descricaoRubrica;
	}
	
	public ClassificacaoAtividadeEnum getClassificacaoRubrica() {
		return classificacaoRubrica;
	}

	public void setClassificacaoRubrica(ClassificacaoAtividadeEnum classificacaoRubrica) {
		this.classificacaoRubrica = classificacaoRubrica;
	}

	public Integer getCodigoRegiaoTarifaria() {
		return codigoRegiaoTarifaria;
	}

	public void setCodigoRegiaoTarifaria(Integer codigoRegiaoTarifaria) {
		this.codigoRegiaoTarifaria = codigoRegiaoTarifaria;
	}

	public Integer getCodigoClasseLocalizacao() {
		return codigoClasseLocalizacao;
	}

	public void setCodigoClasseLocalizacao(Integer codigoClasseLocalizacao) {
		this.codigoClasseLocalizacao = codigoClasseLocalizacao;
	}

	public Integer getCodigoClasseOcupacao() {
		return codigoClasseOcupacao;
	}

	public void setCodigoClasseOcupacao(Integer codigoClasseOcupacao) {
		this.codigoClasseOcupacao = codigoClasseOcupacao;
	}

	public Integer getCodigoClasseConstrucao() {
		return codigoClasseConstrucao;
	}

	public void setCodigoClasseConstrucao(Integer codigoClasseConstrucao) {
		this.codigoClasseConstrucao = codigoClasseConstrucao;
	}

	public Integer getCodigoBemCoberto() {
		return codigoBemCoberto;
	}

	public void setCodigoBemCoberto(Integer codigoBemCoberto) {
		this.codigoBemCoberto = codigoBemCoberto;
	}

	public Integer getCodigoLocalizacao() {
		return codigoLocalizacao;
	}

	public void setCodigoLocalizacao(Integer codigoLocalizacao) {
		this.codigoLocalizacao = codigoLocalizacao;
	}

	public Integer getCodigoAmbitoGeografico() {
		return codigoAmbitoGeografico;
	}

	public void setCodigoAmbitoGeografico(Integer codigoAmbitoGeografico) {
		this.codigoAmbitoGeografico = codigoAmbitoGeografico;
	}

	public String getPercentualRelacaoImportanciaSeguradaValorRisco() {
		return percentualRelacaoImportanciaSeguradaValorRisco;
	}

	public void setPercentualRelacaoImportanciaSeguradaValorRisco(String percentualRelacaoImportanciaSeguradaValorRisco) {
		this.percentualRelacaoImportanciaSeguradaValorRisco = percentualRelacaoImportanciaSeguradaValorRisco;
	}

	public String getPercentualRelacaoDMPValorRisco() {
		return percentualRelacaoDMPValorRisco;
	}

	public void setPercentualRelacaoDMPValorRisco(String percentualRelacaoDMPValorRisco) {
		this.percentualRelacaoDMPValorRisco = percentualRelacaoDMPValorRisco;
	}

	public String getValorRiscoBem() {
		return valorRiscoBem;
	}

	public void setValorRiscoBem(String valorRiscoBem) {
		this.valorRiscoBem = valorRiscoBem;
	}

	public String getValorRiscoBemCalculado() {
		return valorRiscoBemCalculado;
	}

	public void setValorRiscoBemCalculado(String valorRiscoBemCalculado) {
		this.valorRiscoBemCalculado = valorRiscoBemCalculado;
	}

	public String getValorMaiorRiscoIsolado() {
		return valorMaiorRiscoIsolado;
	}

	public void setValorMaiorRiscoIsolado(String valorMaiorRiscoIsolado) {
		this.valorMaiorRiscoIsolado = valorMaiorRiscoIsolado;
	}

	public SimNaoEnum getIdNecessidadeInspecao() {
		return idNecessidadeInspecao;
	}

	public void setIdNecessidadeInspecao(SimNaoEnum idNecessidadeInspecao) {
		this.idNecessidadeInspecao = idNecessidadeInspecao;
	}

	public String getDescricaoRubricaAlternativa() {
		return descricaoRubricaAlternativa;
	}

	public void setDescricaoRubricaAlternativa(String descricaoRubricaAlternativa) {
		this.descricaoRubricaAlternativa = descricaoRubricaAlternativa;
	}

	public Boolean getIdVinilona() {
		return idVinilona;
	}

	public void setIdVinilona(Boolean idVinilona) {
		this.idVinilona = idVinilona;
	}

	public Integer getCodigoRamoProdutoRenovada() {
		return codigoRamoProdutoRenovada;
	}

	public void setCodigoRamoProdutoRenovada(Integer codigoRamoProdutoRenovada) {
		this.codigoRamoProdutoRenovada = codigoRamoProdutoRenovada;
	}

	public BigInteger getCodigoApoliceRenovada() {
		return codigoApoliceRenovada;
	}

	public void setCodigoApoliceRenovada(BigInteger codigoApoliceRenovada) {
		this.codigoApoliceRenovada = codigoApoliceRenovada;
	}

	public Long getCodigoItemRenovada() {
		return codigoItemRenovada;
	}

	public void setCodigoItemRenovada(Long codigoItemRenovada) {
		this.codigoItemRenovada = codigoItemRenovada;
	}

	public Integer getCodigoCompanhiaSeguradora() {
		return codigoCompanhiaSeguradora;
	}

	public void setCodigoCompanhiaSeguradora(Integer codigoCompanhiaSeguradora) {
		this.codigoCompanhiaSeguradora = codigoCompanhiaSeguradora;
	}

	public String getNumeroApoliceCongenere() {
		return numeroApoliceCongenere;
	}

	public void setNumeroApoliceCongenere(String numeroApoliceCongenere) {
		this.numeroApoliceCongenere = numeroApoliceCongenere;
	}

	public Long getNumeroItemApoliceCongenere() {
		return numeroItemApoliceCongenere;
	}

	public void setNumeroItemApoliceCongenere(Long numeroItemApoliceCongenere) {
		this.numeroItemApoliceCongenere = numeroItemApoliceCongenere;
	}

	public String getPercentualSinistralidade() {
		return percentualSinistralidade;
	}

	public void setPercentualSinistralidade(String percentualSinistralidade) {
		this.percentualSinistralidade = percentualSinistralidade;
	}

	public ClasseBonusEnum getCodigoClasseBonus() {
		return codigoClasseBonus;
	}

	public List<ItemDistribuicaoView> getItemsDistribuicao() {
		return itemsDistribuicao;
	}

	public void setItemsDistribuicao(List<ItemDistribuicaoView> itemsDistribuicao) {
		this.itemsDistribuicao = itemsDistribuicao;
	}

	public List<Long> getProtecionais() {
		return protecionais;
	}

	public boolean isCoberturaAvulsaDM() {
		return coberturaAvulsaDM;
	}

	public void setCoberturaAvulsaDM(boolean coberturaAvulsaDM) {
		this.coberturaAvulsaDM = coberturaAvulsaDM;
	}

	public boolean isCoberturaAvulsaLC() {
		return coberturaAvulsaLC;
	}

	public void setCoberturaAvulsaLC(boolean coberturaAvulsaLC) {
		this.coberturaAvulsaLC = coberturaAvulsaLC;
	}

	public SolicitanteEndossoEnum getIdSolicitanteEndosso() {
		return idSolicitanteEndosso;
	}

	public void setIdSolicitanteEndosso(SolicitanteEndossoEnum idSolicitanteEndosso) {
		this.idSolicitanteEndosso = idSolicitanteEndosso;
	}

	public Integer getIdTipoEndosso() {
		return idTipoEndosso;
	}

	public void setIdTipoEndosso(Integer idTipoEndosso) {
		this.idTipoEndosso = idTipoEndosso;
	}

	/**
	 * @return the reintegracao
	 */
	public boolean isReintegracao() {
		return reintegracao;
	}

	/**
	 * @param reintegracao the reintegracao to set
	 */
	public void setReintegracao(boolean reintegracao) {
		this.reintegracao = reintegracao;
	}

	public void setProtecionais(List<Long> protecionais) {
		this.protecionais = protecionais;
	}

	public List<ItemCoberturaView> getListCoberturaBasica() {
		return listCoberturaBasica;
	}

	public void setListCoberturaBasica(List<ItemCoberturaView> listCoberturaBasica) {
		this.listCoberturaBasica = listCoberturaBasica;
	}

	public void setCodigoClasseBonus(ClasseBonusEnum codigoClasseBonus) {
		this.codigoClasseBonus = codigoClasseBonus;
	}

	public Boolean getIdResseguroFacultativo() {
		return idResseguroFacultativo;
	}

	public void setIdResseguroFacultativo(Boolean idResseguroFacultativo) {
		this.idResseguroFacultativo = idResseguroFacultativo;
	}
	
	public Long getIdCEPLocalRiscoNumero() {
		if(getIdCEPLocalRisco() != null && !getIdCEPLocalRisco().isEmpty()) {
			return Long.valueOf(idCEPLocalRisco);
		} else {
			return null;
		}
	}

	public List<ItemCoberturaView> getListCoberturaAcessoriaDM() {
		return listCoberturaAcessoriaDM;
	}

	public void setListCoberturaAcessoriaDM(List<ItemCoberturaView> listCoberturaAcessoriaDM) {
		this.listCoberturaAcessoriaDM = listCoberturaAcessoriaDM;
	}

	public List<ItemCoberturaView> getListCoberturaAcessoriaLC() {
		return listCoberturaAcessoriaLC;
	}

	public void setListCoberturaAcessoriaLC(List<ItemCoberturaView> listCoberturaAcessoriaLC) {
		this.listCoberturaAcessoriaLC = listCoberturaAcessoriaLC;
	}

	public String getIdMongoRenovacao() {
		return idMongoRenovacao;
	}

	public void setIdMongoRenovacao(String idMongoRenovacao) {
		this.idMongoRenovacao = idMongoRenovacao;
	}
}