package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import br.com.tokiomarine.cliente.dto.persistencia.EnderecoCliente;
import br.com.tokiomarine.ctpj.type.ServicosClienteEnum;

@Service
public class EnderecoClienteService extends BaseClienteService {
	public List<EnderecoCliente> consultarEnderecosCliente(Object[] parametros) {
		
		EnderecoCliente[] enderecosClienteResponse = null;
		try{
			
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_LISTA_ENDERECOS_POR_CODIGO
														, parametros);

			enderecosClienteResponse =  restTemplate.getForObject(uri,EnderecoCliente[].class);	
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Consultar Endereços Cliente ",e);
		}
		return Arrays.asList(enderecosClienteResponse);
	}
	
	public EnderecoCliente consultarEnderecoClientePorCodigoClienteEIdEndereco(Object[] parametros) {
		
		EnderecoCliente enderecoClienteResponse = null;
		try{
			
			URI uri = endpointBuilderService.obterUri(getParametroGeral(),ServicosClienteEnum.PESQUISAR_ENDERECO_POR_CODIGO_CLIENTE_E_ID_ENDERECO
														, parametros);

			enderecoClienteResponse =  restTemplate.getForObject(uri,EnderecoCliente.class);		
		} 
		catch (Exception e) {
			logger.error("Erro Geral ao chamar o servico de Consultar Endereço Cliente Por Codigo Cliente e Id Endereco",e);
		}
		return enderecoClienteResponse;
	}
}
