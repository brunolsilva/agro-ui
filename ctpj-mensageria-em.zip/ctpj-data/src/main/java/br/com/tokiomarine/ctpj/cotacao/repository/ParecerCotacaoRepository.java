package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.Calendar;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ParecerCotacao;
import br.com.tokiomarine.ctpj.exception.HibernateException;

@Repository
public class ParecerCotacaoRepository extends BaseDAO{
	
	private static final Logger logger = LogManager.getLogger(ParecerCotacaoRepository.class);
	
	@LogPerformance
	public void saveParecerCotacao(ParecerCotacao parecer) throws HibernateException{
		logger.info("Salvando Parecer Cotação");
		BigInteger numeroParecer = this.getNrParecer(parecer.getCotacao().getSequencialCotacaoProposta());
		parecer.setNumeroParecer(numeroParecer);
		parecer.setDataAtualizacao(Calendar.getInstance().getTime());
		parecer.setDataParecer(Calendar.getInstance().getTime());
		super.getCurrentSession().save(parecer);
		
	}
	
	@LogPerformance
	public void deleteParecerCotacao(BigInteger sequencialParecerCotacao) throws HibernateException{
		logger.info("Salvando Parecer Cotação");
		StringBuilder hql = new StringBuilder();
		hql.append(" delete ParecerCotacao p ");
		hql.append(" where p.sequencialParecerCotacao = :sequencialParecerCotacao");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialParecerCotacao", sequencialParecerCotacao);
		query.executeUpdate();
		
	}
	
	private BigInteger getNrParecer(BigInteger sequencialCotacaoProposta)throws HibernateException{
		StringBuilder hql = new StringBuilder();
		hql.append(" select max(p.numeroParecer) + 1 from ParecerCotacao p ");
		hql.append(" where p.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		BigInteger numeroParecer = (BigInteger) query.uniqueResult();
		
		if(numeroParecer == null){
			numeroParecer = BigInteger.ONE;
		}
		return numeroParecer;
		
	}

}
