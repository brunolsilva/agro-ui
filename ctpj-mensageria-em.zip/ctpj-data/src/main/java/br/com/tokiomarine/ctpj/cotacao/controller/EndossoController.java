package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaBasicaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaValor;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoPagamentoView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.BloqueioAlcadaService;
import br.com.tokiomarine.ctpj.cotacao.service.CalculoEndossoService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.EndossoService;
import br.com.tokiomarine.ctpj.cotacao.service.OpcaoParcelamentoService;
import br.com.tokiomarine.ctpj.cotacao.service.PerfilComercialService;
import br.com.tokiomarine.ctpj.cotacao.service.RecebimentoService;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.dto.ProdutoCaracteristicaView;
import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.ClasseBonusEnum;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.SolicitanteEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoValorRiscoDistribuidoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.CalculoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.AtividadeSegurado;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.domain.CompanhiaSeguradora;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.domain.UF;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.PrazoVigenciaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguroEnum;
import br.com.tokiomarine.ctpj.infra.mongo.service.AtividadeSeguradoService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CaracteristicaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.CoberturaService;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.infra.type.Caracteristicas;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.type.CTP;
import br.com.tokiomarine.ctpj.type.Paginas;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Controller
@RequestMapping(value = "/entrada/endosso")
public class EndossoController extends AbstractController {

	private static final Logger logger = LogManager.getLogger(EndossoController.class);

	@Autowired
	private EndossoService endossoService;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@Autowired
	private AtividadeSeguradoService atividadeSeguradoService;

	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private PerfilComercialService perfilComercialService;

	@Autowired
	private CalculoEndossoService calculoEndossoService;
	
	@Autowired
	private BloqueioAlcadaService bloqueioAlcadaService;

	@Autowired
	private CoberturaService coberturaService;

	@Autowired
	private ProdutoService produtoService;
	
	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired
	private RecebimentoService recebimentoService;
	
	

	@LogPerformance
	@PostMapping(value = "/salvar")
	public @ResponseBody ResultadoREST<String> salvar(@RequestBody CotacaoView cotacao, BindingResult result, HttpSession session) {

		ResultadoREST<String> resultado = new ResultadoREST<>();

		try {
			List<ValidacaoLote> listaValidacao = endossoService.salvar(cotacao);

			resultado.setListaValidacaoLote(listaValidacao);

			if (resultado.getListaValidacaoLote().isEmpty()) {
				resultado.setSuccess(true);
				if(cotacao.isCalculo()) {
					this.trataRetornoCalculo(cotacao, session);				
				} else {
					session.setAttribute(SUCESSO, Arrays.asList("Dados Atualizados com Sucesso!"));
				}
			} else {
				resultado.setSuccess(false);
				
			}
		} catch (Exception e) {
			logger.error("Erro ao salvar a cotação ", e);
			resultado.setSuccess(false);
			resultado.setMensagem(e.getMessage());
		}

		return resultado;
	}

	@LogPerformance
	@GetMapping(value = "/condicaoComercial/{sqCotacao}")
	public String alteracaoCondicaoComercial(@PathVariable(value = "sqCotacao") BigInteger sqCotacao, Model model, HttpSession session) throws Exception {

		String returnPage = Paginas.alteracaoCondicaoComercial.value();
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));

		try {
			Cotacao cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			CotacaoView cotacaoView = this.bindCotacaoViewToEndosso(cotacao, model);
			model.addAttribute(CTP.COTACAO.value(), cotacaoView);
			super.limpaMensagens(session);
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			returnPage = Paginas.error.value();
		}

		return returnPage;
	}

	@LogPerformance
	@GetMapping(value = "/dadosCadastrais/{sqCotacao}")
	public String endossoAlteracaoDadosCadastrais(@PathVariable(value = "sqCotacao") BigInteger sqCotacao, Model model, HttpSession session) throws Exception {

		String returnPage = Paginas.alteracaoDadosCadastrais.value();
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));

		try {
			Cotacao cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			
			CotacaoView cotacaoView = this.bindCotacaoViewToEndosso(cotacao, model);
			model.addAttribute(CTP.COTACAO.value(), cotacaoView);
			carregarDadosSeguradoAcsel(model, cotacao);
			super.limpaMensagens(session);
			
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			returnPage = Paginas.error.value();
		}

		return returnPage;
	}

	@LogPerformance
	@GetMapping(value = "/prorrogacaoVigencia/{sqCotacao}")
	public String endossoProrrogracaoVigencia(@PathVariable(value = "sqCotacao") BigInteger sqCotacao, Model model, HttpSession session) throws Exception {

		String returnPage = Paginas.prorrogacaoVigencia.value();
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));

		try {
			Cotacao	cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			CotacaoView cotacaoView = this.bindCotacaoViewToEndosso(cotacao, model);
			model.addAttribute(CTP.COTACAO.value(), cotacaoView);
			CotacaoPagamentoView pagamento = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao);		
			model.addAttribute("pagamento", pagamento);
			loadPagamentoEfetivado(cotacao, model);
			model.addAttribute("validationMessages", endossoService.validaProrrogracaoVigencia(cotacao));
			this.limpaMensagens(session);
			
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			returnPage = Paginas.error.value();
		}

		return returnPage;
	}
	
	private void loadPagamentoEfetivado(Cotacao cotacao, Model model) {
		Recebimento recebimento = recebimentoService.findRecebimentoByNumeroCotacaoProposta(cotacao);
		model.addAttribute("parcelamentoEfetivado",  recebimento != null && recebimento.getIdTipoCredito() != null ? SimNaoEnum.SIM.getId() : SimNaoEnum.NAO.getId());
	}
	
	

	@LogPerformance
	@GetMapping(value = "/cancelamentoApolice/{sqCotacao}")
	public String endossoCancelamentoApolice(@PathVariable(value = "sqCotacao") BigInteger sqCotacao, Model model, HttpSession session) throws Exception {

		String returnPage = Paginas.cancelamentoApolice.value();
		CtpjToken token = (CtpjToken) session.getAttribute(CTP.ctpjToken.value());
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));

		try {
			
			Cotacao cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			CotacaoPagamentoView pagamento = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao);		
			model.addAttribute("pagamento", pagamento);
			loadPagamentoEfetivado(cotacao, model);	
			CotacaoView cotacaoView = this.bindCotacaoViewToEndosso(cotacao, model);			
			model.addAttribute(CTP.COTACAO.value(), cotacaoView);
			
			switch	(cotacao.getIdSolicitanteEndosso())	{	
				case	FALTA_PAGAMENTO:
					Date dataAlteracao = endossoService.calculaDataAlteracao(token.getSolicitacaoCotacao().getIdMongodb(), cotacao.getIdTipoEndosso());
					cotacaoView.setDataAlteracao(dataAlteracao);
					cotacao.setDataAlteracao(dataAlteracao);					
					model.addAttribute("validationMessages", endossoService.validaCancelamentoDeApolicePorFaltaPagamento(token.getSolicitacaoCotacao().getIdMongodb()));
					break;
				case	SINISTRO:
					model.addAttribute("validationMessages", endossoService.validaCancelamentoDeApolicePorSinistro(token.getSolicitacaoCotacao().getIdMongodb()));
					break;
				case	MOTIVO_INTERNO:	
					model.addAttribute("validationMessages", endossoService.validaCancelamentoDeApolicePorMotivoInterno(token.getSolicitacaoCotacao().getIdMongodb(), cotacao));	
					break;
				default:
					break;
			}
			
			model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacao.getCodigoSituacao()).isReadOnly());
			super.limpaMensagens(session);
			
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());			
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			returnPage = Paginas.error.value();
		}

		return returnPage;
	}
	
	@LogPerformance
	@GetMapping(value = "/cancelamentoEndosso/{sqCotacao}")
	public String endossoCancelamentoEndosso(@PathVariable(value = "sqCotacao") BigInteger sqCotacao, Model model, HttpSession session) throws Exception {
		
		String returnPage = Paginas.cancelamentoEndosso.value();
		CtpjToken token = (CtpjToken) session.getAttribute(CTP.ctpjToken.value());
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));
		
		try {
				Cotacao cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			
				CotacaoView cotacaoView = this.bindCotacaoViewToEndosso(cotacao, model);			
				model.addAttribute(CTP.COTACAO.value(), cotacaoView);
				
				switch	(cotacao.getIdSolicitanteEndosso())	{	
					case	FALTA_PAGAMENTO:
						Date dataAlteracao = endossoService.calculaDataAlteracao(token.getSolicitacaoCotacao().getIdMongodb(), cotacao.getIdTipoEndosso());
						cotacaoView.setDataAlteracao(dataAlteracao);
						cotacao.setDataAlteracao(dataAlteracao);
						model.addAttribute("validationMessages", endossoService.validaCancelamentoDeEndossoPorFaltaDePagamento(token.getSolicitacaoCotacao().getIdMongodb(), cotacaoView));						
						break;
					case	MOTIVO_INTERNO:	
						model.addAttribute("validationMessages", endossoService.validaCancelamentoDeEndossoPorMotivoInterno(token.getSolicitacaoCotacao().getIdMongodb(), cotacaoView));				
						break;
					default:
						break;
				}
										
				super.limpaMensagens(session);
				
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			returnPage = Paginas.error.value();
		}

		return returnPage;
	}
	
	@LogPerformance
	@GetMapping(value = {"/alteracaoInclusaoExclusao/{sqCotacao}", "/alteracaoInclusaoExclusao/{sqCotacao}/{page}"})
	public String endossoAlteracaoInclusaoExclusao(
			@PathVariable(value = "sqCotacao") BigInteger sqCotacao,
			@PathVariable(value = "page") Optional<Integer> page,
			Model model,
			HttpSession session) throws Exception {

		String returnPage = Paginas.alteracaoInclusaoExclusao.value();
		model.addAttribute(SUCESSO,session.getAttribute(SUCESSO));
		model.addAttribute(ERRO,session.getAttribute(ERRO));

		try {
			Cotacao cotacao = cotacaoService.findCotacaoTela(sqCotacao);
			CotacaoView cotacaoView = this.bindCotacaoViewToEndossoAlteracao(cotacao, model,page.orElse(1));			
			model.addAttribute(CTP.COTACAO.value(), cotacaoView);
			limpaMensagens(session);
		} catch (final Exception e) {
			model.addAttribute("mensagem", e.getMessage());
			model.addAttribute("stacktrace", ExceptionUtils.getFullStackTrace(e));
			logger.error("Erro", e);
			returnPage = Paginas.error.value();
		}

		return returnPage;
	}

	private void carregarDadosSeguradoAcsel(Model model, Cotacao cotacao) {
		Boolean liberaFormaPagamento = false;
		if (cotacao.getIdDestinoEmissao() == DestinoEmissaoEnum.ACX && cotacao.getCodigoTipoEndossoSCT() != null
				&& cotacao.getCodigoTipoEndossoSCT().equals(TipoEndossoSctEnum.TDO_ALTERACAO_DADOS_CADASTRAIS)
				&& StringUtils.isNoneEmpty(cotacao.getIdMongoEndosso())) {			
			CotacaoPagamentoView pagamento;
			try {
				pagamento = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao);
			} catch (ServiceException e) {
				pagamento = null;
			}
			model.addAttribute("pagamento", pagamento);
			loadPagamentoEfetivado(cotacao, model);
		}
		
		model.addAttribute("liberaFormaPagamento", liberaFormaPagamento);
	}

	private CotacaoView bindCotacaoViewToEndosso(Cotacao cotacao, Model model) throws ServiceException {
		CotacaoView cotacaoView = CotacaoViewMapper.INSTANCE.toCotacaoView(cotacao);		
		//Tratar os casos de endosso de cancelamento por motivo interno cuja data de alteração gravada na cotação for diferente da data de início de vigência da apólice
		if(cotacao.getIdTipoEndosso() == TipoEndossoEnum.CANCELAMENTO_APOLICE && cotacao.getIdSolicitanteEndosso() == SolicitanteEndossoEnum.MOTIVO_INTERNO && cotacaoView.getDataAlteracao() != cotacao.getDataInicioVigencia()) {
			cotacaoView.setDataAlteracao(cotacao.getDataInicioVigencia());
		}
		else if(cotacao.getIdTipoEndosso() == TipoEndossoEnum.PRORROGACAO_VIGENCIA) {
			Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			cotacaoView.setDataAlteracao(apolice.getDataFimVigencia());
		}
		
		List<BloqueioAlcada> alcadas = bloqueioAlcadaService.listaMensagensBloqueio(cotacao.getSequencialCotacaoProposta());
		
		Map<Integer, Object> valoresPerfil = perfilComercialService.valoresPerfil(
				SecurityUtils.getCurrentUser().getCdUsuro().longValue(), cotacaoView.getCodigoProduto(),
				cotacao.getDataCotacao());

		boolean calculoVencido = false;

		if (cotacao.getDataCalculo() != null) {
			Integer diasValidadeCotacao = (Integer) valoresPerfil.get(3);
			Date dataMaximaCalculo = DateUtils.addDays(cotacao.getDataCalculo(),diasValidadeCotacao);
			
			if (new Date().after(dataMaximaCalculo)) {
				calculoVencido = true;
				model.addAttribute("alertas",Arrays.asList("A validade do cálculo desta cotação expirou! Favor calcular novamente."));
			}
		}

		if (SecurityUtils.isCorretor() && !calculoVencido) {
			model.addAttribute("bloqueio", (!alcadas.isEmpty()) ? Arrays.asList("Clique aqui para enviar a cotação para a Tokio Marine. ") : "");
		} else if (!calculoVencido && alcadas != null && !alcadas.isEmpty()) {
			model.addAttribute("bloqueio",Arrays.asList("Foram encontrados bloqueios para esta cotação. Clique aqui para visualizar."));
		}
		
		model.addAttribute("cabecalhoCotacao", cotacaoView);
		
		if ((cotacao.getCodigoSituacao() != CodigoSituacaoEnum.CALCULADA_318.getSituacao().intValue()) && (cotacao.getCodigoSituacao() != CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getSituacao().intValue())){
			model.addAttribute("liberadoTransmissao", true);
		}
		
		TreeMap<Integer, Object> versoes = cotacaoService.findVersoes(cotacao.getNumeroCotacaoProposta());
		model.addAttribute("versoes", versoes);
		
		List<Solicitante> solicitantesEndosso = null;
		if (cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.CANCELAMENTO_APOLICE_POR_SOLICITACAO_CIA) {
			solicitantesEndosso = new ArrayList<>();

			Solicitante solicitanteSegurado = new Solicitante();
			solicitanteSegurado.setId(SolicitanteEndossoEnum.SEGURADO.getId());
			solicitanteSegurado.setDescricao(SolicitanteEndossoEnum.SEGURADO.getDescricao().toUpperCase());
			
			Solicitante solicitanteCompanhia = new Solicitante();
			solicitanteCompanhia.setId(SolicitanteEndossoEnum.COMPANHIA.getId());
			solicitanteCompanhia.setDescricao(SolicitanteEndossoEnum.COMPANHIA.getDescricao().toUpperCase());

			solicitantesEndosso.add(solicitanteSegurado);
			solicitantesEndosso.add(solicitanteCompanhia);
			model.addAttribute("solicitantesEndosso", solicitantesEndosso);
		}
		
		if(versoes != null && !versoes.isEmpty()) {
			Integer ultimaVersao = versoes.lastKey();
			if(!cotacao.getVersaoCotacaoProposta().equals(ultimaVersao)) {
				model.addAttribute("restricaoCorretor", true);
			}
		}
		
		if (Arrays.asList(
				CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue(),
				CodigoSituacaoEnum.LIBERADO_PELA_GRADE_454.getSituacao().intValue(),
				CodigoSituacaoEnum.ERRO_NA_FORMALIZACAO_453.getSituacao().intValue(),
				CodigoSituacaoEnum.CANCELADA_320.getSituacao().intValue(),
				CodigoSituacaoEnum.EMITIDA_315.getSituacao().intValue()).contains(cotacao.getCodigoSituacao())) {
			//model.addAttribute("restricaoCorretor",true);
		}
		
		if (StringUtils.isEmpty(cotacaoView.getPercentualDescontoGeral())) {
			cotacaoView.setPercentualDescontoGeral(valoresPerfil.getOrDefault(2, BigDecimal.ZERO).toString());
		}

		if (cotacaoView.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			cotacaoView.setCpfSegurado		(cotacao.getNumeroCNPJCPFSegurado() != null ? String.valueOf(cotacao.getNumeroCNPJCPFSegurado()) : null); 
			cotacaoView.setNomeSeguradoPF	(cotacao.getNomeSegurado());
		} else {
			cotacaoView.setCnpjSegurado		(cotacao.getNumeroCNPJCPFSegurado() != null ? String.valueOf(cotacao.getNumeroCNPJCPFSegurado()) : null); 
			cotacaoView.setNomeSeguradoPJ	(cotacao.getNomeSegurado());
		}

		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			Optional<ComissaoCotacao> opComCot = cotacao
					.getListComissaoCotacao()
					.stream()
					.findFirst();
			cotacaoView.setPercentualComissao(opComCot.isPresent() ? opComCot.get().getPercentualComissao().setScale(2).toString() : valoresPerfil.getOrDefault(1,BigDecimal.ZERO).toString());
		} else {
			cotacaoView.setPercentualComissao(valoresPerfil.getOrDefault(1, BigDecimal.ZERO).toString());
		}
		
		this.basicModelMapToEndosso(model, cotacaoView);

		model.addAttribute("desabilitaContratacao", cotacaoView.getIdControleCalculo() == null || cotacaoView.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO 
					|| !alcadas.isEmpty() || calculoVencido || "0.00".equals(cotacaoView.getPercentualComissao()));
		
		model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly());

		return cotacaoView;
	}
	
	private void basicModelMapToEndosso(Model model, CotacaoView cotacaoView) {
		model.addAttribute("moeda", MoedaEnum.values());
		model.addAttribute("prazosVigencia", Arrays.asList(PrazoVigenciaEnum.values()).stream()
				.sorted(Comparator.comparing(PrazoVigenciaEnum::getValor)).collect(Collectors.toList()));

		AtividadeSegurado atividadeSegurado = atividadeSeguradoService.getAtividadeSegurado(cotacaoView.getCodigoAtividadePrincipal());
		if (atividadeSegurado != null) {
			model.addAttribute("codigoAtividadePrincipalOriginal", atividadeSegurado.getAtividadePrincipal());
			model.addAttribute("descricaoAtividadePrincipalOriginal", atividadeSegurado.getDescricao());
		}
		
		model.addAttribute("ufs", caracteristicaService.findUFs());
	}

	private CotacaoView bindCotacaoViewToEndossoAlteracao(Cotacao cotacao, Model model, int page) throws ServiceException {
		CotacaoView cotacaoView = CotacaoViewMapper.INSTANCE.toCotacaoView(cotacao);
		
		int firstResult = 1;
		int lastResult = 1000;
		
		if (page != 0) {
			if(page < 0) {
				page = 1;
			}
			
			int resultadosPorPagina = 20;

			if(cotacaoView.getCodigoProduto().equals(1851)) {
				resultadosPorPagina = 1;
			}

			int total = cotacao.getListItem().size();
			int paginas = (int) Math.ceil(total / (double) resultadosPorPagina);
			
			if(page - paginas > 1) {
				page = paginas;
			}

			firstResult = ((page - 1) * resultadosPorPagina) + 1;
			lastResult = (page) * resultadosPorPagina;

			if(page > paginas) {
				paginas = page;
			}

			model.addAttribute("pagina",page);
			model.addAttribute("total",total);
			model.addAttribute("paginas",paginas);
			model.addAttribute("firstResult",firstResult);
			model.addAttribute("lastResult",lastResult);
		}

		/**
		 * INICIO ENDOSSO DE INCLUSAO
		 */
		cotacaoView.setListItem(CotacaoViewMapper.INSTANCE.itemCotacaoSetToItemCotacaoViewList(
				cotacao.getListItem(),
				page));
		if(cotacao.getCodigoTipoEndossoSCT() == TipoEndossoSctEnum.REINTEGRACAO_IS) {
			endossoService.marcaReintegracao(cotacao, cotacaoView);
		}

		if (cotacaoView.getIdTipoSeguro() == TipoSeguroEnum.RENOVACAO_CONGENERE) {
			CompanhiaSeguradora cia = caracteristicaService.findCiaSeguradora(cotacao.getCodigoCompanhiaSeguradora());
			if (cia != null) {
				model.addAttribute("dadosCongenere","Nº APÓLICE: " + cotacao.getNumeroApoliceCongenere() + " - " + cia.getCodigo() + " " + cia.getNome());
			}
		}
		/**
		 * FIM ENDOSSO DE INCLUSAO
		 */
		
		List<BloqueioAlcada> bloqueios = bloqueioAlcadaService.listaMensagensBloqueio(cotacao.getSequencialCotacaoProposta());
		CotacaoPagamentoView pagamento = opcaoParcelamentoService.findOpcaoParcelamentoSelecionada(cotacao);		
		model.addAttribute("pagamento", pagamento);
		loadPagamentoEfetivado(cotacao, model);
		Map<Integer, Object> valoresPerfil = perfilComercialService.valoresPerfil(
				SecurityUtils.getCurrentUser().getCdUsuro().longValue(), cotacaoView.getCodigoProduto(),
				cotacao.getDataCotacao());

		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			Optional<ComissaoCotacao> opComCot = cotacao
					.getListComissaoCotacao()
					.stream()
					.findFirst();
			cotacaoView.setPercentualComissao(opComCot.isPresent() ? opComCot.get().getPercentualComissao().setScale(2).toString() : valoresPerfil.getOrDefault(1,BigDecimal.ZERO).toString());
		} else {
			cotacaoView.setPercentualComissao(valoresPerfil.getOrDefault(1,BigDecimal.ZERO).toString());
		}
		
		model.addAttribute("desabilitaOpcaoParcelamento", "0.00".equals(cotacaoView.getPercentualComissao()));
		boolean calculoVencido = false;

		if(!valoresPerfil.isEmpty()) {
			if (cotacao.getDataCalculo() != null) {
				Integer diasValidadeCotacao = (Integer) valoresPerfil.get(3);
				Date dataMaximaCalculo = DateUtils.addDays(cotacao.getDataCalculo(),diasValidadeCotacao);
				if (new Date().after(dataMaximaCalculo)) {
					calculoVencido = true;
					model.addAttribute("alertas",Arrays.asList("A validade do cálculo desta cotação expirou! Favor calcular novamente."));
				}
			}
		}

		if (SecurityUtils.isCorretor() && !calculoVencido) {
			model.addAttribute("bloqueio", (!bloqueios.isEmpty()) ? Arrays.asList("Clique aqui para enviar a cotação para a Tokio Marine. ") : "");
		} else if (!calculoVencido && bloqueios != null && !bloqueios.isEmpty()) {
			model.addAttribute("bloqueio",Arrays.asList("Foram encontrados bloqueios para esta cotação. Clique aqui para visualizar."));
		}
		
		model.addAttribute("cabecalhoCotacao", cotacaoView);
		
		if ((cotacao.getCodigoSituacao() != CodigoSituacaoEnum.CALCULADA_318.getSituacao().intValue()) && (cotacao.getCodigoSituacao() != CodigoSituacaoEnum.CADASTRO_DA_COTACAO_319.getSituacao().intValue())){
			model.addAttribute("liberadoTransmissao", true);
		}
		
		TreeMap<Integer, Object> versoes = cotacaoService.findVersoes(cotacao.getNumeroCotacaoProposta());
		model.addAttribute("versoes", versoes);
		if(versoes != null && !versoes.isEmpty()) {
			Integer ultimaVersao = versoes.lastKey();
			if(!cotacao.getVersaoCotacaoProposta().equals(ultimaVersao)) {
				model.addAttribute("restricaoCorretor", true);
			}
		}
		
		if (Arrays.asList(
				CodigoSituacaoEnum.LIBERADO_PARA_EMISSAO_452.getSituacao().intValue(),
				CodigoSituacaoEnum.LIBERADO_PELA_GRADE_454.getSituacao().intValue(),
				CodigoSituacaoEnum.ERRO_NA_FORMALIZACAO_453.getSituacao().intValue(),
				CodigoSituacaoEnum.CANCELADA_320.getSituacao().intValue(),
				CodigoSituacaoEnum.EMITIDA_315.getSituacao().intValue()).contains(cotacao.getCodigoSituacao())) {
			//model.addAttribute("restricaoCorretor",true);
		}

		/**
		 * INICIO ENDOSSO DE INCLUSAO
		 */
		if (StringUtils.isEmpty(cotacaoView.getPercentualDescontoGeral())) {
			cotacaoView.setPercentualDescontoGeral(valoresPerfil.getOrDefault(2, BigDecimal.ZERO).toString());
		}

		if (cotacaoView.getIdTipoPessoa() == TipoSeguradoEnum.FISICA) {
			cotacaoView.setCpfSegurado		(cotacao.getNumeroCNPJCPFSegurado() != null ? String.valueOf(cotacao.getNumeroCNPJCPFSegurado()) : null); 
			cotacaoView.setNomeSeguradoPF	(cotacao.getNomeSegurado());
		} else {
			cotacaoView.setCnpjSegurado		(cotacao.getNumeroCNPJCPFSegurado() != null ? String.valueOf(cotacao.getNumeroCNPJCPFSegurado()) : null); 
			cotacaoView.setNomeSeguradoPJ	(cotacao.getNomeSegurado());
		}
		/**
		 * FIM ENDOSSO DE INCLUSAO
		 */

		this.basicModelMapToEndossoAlteracao(model, cotacaoView);
		
		if (cotacao.getListComissaoCotacao() != null && !cotacao.getListComissaoCotacao().isEmpty()) {
			Optional<ComissaoCotacao> opComCot = cotacao
					.getListComissaoCotacao()
					.stream()
					.findFirst();
			cotacaoView.setPercentualComissao(opComCot.isPresent() ? opComCot.get().getPercentualComissao().setScale(2).toString() : valoresPerfil.getOrDefault(1,BigDecimal.ZERO).toString());
		} else {
			cotacaoView.setPercentualComissao(valoresPerfil.getOrDefault(1, BigDecimal.ZERO).toString());
		}
		
		model.addAttribute("desabilitaContratacao", cotacaoView.getIdControleCalculo() == null || cotacaoView.getIdControleCalculo() == ControleCalculoEnum.COTACAO_NAO_CALCULADO 
					|| !bloqueios.isEmpty() || calculoVencido || "0.00".equals(cotacaoView.getPercentualComissao()));
		
		model.addAttribute("readOnly",CodigoSituacaoEnum.getCodigoSituacaoEnumByCdSituc(cotacaoView.getCodigoSituacaoReadOnly()).isReadOnly());
		

		return cotacaoView;
	}

	private void basicModelMapToEndossoAlteracao(Model model, CotacaoView cotacaoView) {
		model.addAttribute("moeda", MoedaEnum.values());
		model.addAttribute("prazosVigencia", Arrays.asList(PrazoVigenciaEnum.values()).stream()
				.sorted(Comparator.comparing(PrazoVigenciaEnum::getValor)).collect(Collectors.toList()));

		AtividadeSegurado atividadeSegurado = atividadeSeguradoService.getAtividadeSegurado(cotacaoView.getCodigoAtividadePrincipal());
		if (atividadeSegurado != null) {
			model.addAttribute("codigoAtividadePrincipalOriginal", atividadeSegurado.getAtividadePrincipal());
			model.addAttribute("descricaoAtividadePrincipalOriginal", atividadeSegurado.getDescricao());
		}
		
		model.addAttribute("ufs", caracteristicaService.findUFs());
		
		/***
		 * ALTERACAO INCLUSAO EXCLUSAO
		 */
		
		model.addAttribute("tiposSeguro",TipoSeguroEnum.valoresCTPJ());
		List<ProdutoValorCarac> bensCobertos = caracteristicaService.getValoresCaracteristica(cotacaoView.getCodigoProduto(),Caracteristicas.BEM_COBERTO.codigo(),new Sort(Direction.ASC,"descricaoValor"));
		List<ProdutoValorCarac> classesConstrucao = caracteristicaService.getValoresCaracteristica(cotacaoView.getCodigoProduto(),Caracteristicas.CLASSE_CONSTRUCAO.codigo(),new Sort(Direction.ASC,"descricaoValor"));
		List<ProdutoValorCarac> localizacoes = caracteristicaService.getValoresCaracteristica(cotacaoView.getCodigoProduto(),Caracteristicas.LOCALIZACAO.codigo(),new Sort(Direction.ASC,"descricaoValor"));

		List<ProdutoValorCarac> classesOcupacao = caracteristicaService.getValoresCaracteristica(cotacaoView.getCodigoProduto(),Caracteristicas.CLASSE_OCUPACAO.codigo(),new Sort(Direction.ASC,"valorCaracteristica"));
		List<ProdutoValorCarac> classesLocalizacao = caracteristicaService.getValoresCaracteristica(cotacaoView.getCodigoProduto(),Caracteristicas.CLASSE_LOCALIZACAO.codigo(),new Sort(Direction.ASC,"valorCaracteristica"));

		List<ProdutoValorCarac> protecionais = caracteristicaService.getValoresCaracteristica(cotacaoView.getCodigoProduto(),Caracteristicas.SISTEMA_PROTECIONAL.codigo(),new Sort(Direction.ASC,"descricaoValor"));

		List<CompanhiaSeguradora> ciasSeguradora = caracteristicaService.findCiasSeguradora();

		List<UF> ufs = caracteristicaService.findUFs();
		Produto produto = produtoService.findProduto(cotacaoView.getCodigoProduto());
		Optional<ProdutoCaracteristicaView> produtoCaracteristica = produtoService.findCaracsByProduto(cotacaoView.getCodigoProduto());

		/**
		 * Recupera as Coberturas Básicas
		 */
		List<Cobertura> coberturasBasicas = coberturaService.findCoberturasBasicas(cotacaoView);

		/**
		 * Listas com a hierarquia completa das coberturas Danos Materiais e Lucros Cessantes
		 */
		List<CoberturaBasicaHierarquiaView> hierarquiaDM = new ArrayList<>();

		Map<Integer,List<CoberturaHierarquiaView>> todasDM = coberturaService.findCoberturasAdicionaisDMView(cotacaoView,coberturasBasicas.stream()
				.map(Cobertura::getCodigo)
				.collect(Collectors.toList()));

		todasDM.forEach((k,v) -> {
			CoberturaBasicaHierarquiaView estruturaCobertura = new CoberturaBasicaHierarquiaView();
			estruturaCobertura.setCoberturaBasica(k);
			estruturaCobertura.setFilhas(v);
			hierarquiaDM.add(estruturaCobertura);
		});

		/**
		 * Início da montagem da hierarquia de Danos Materiais
		 */
		montaHierarquiaDM(cotacaoView,produto,coberturasBasicas,hierarquiaDM);

		/**
		 * Models com as hierarquias completas de coberturas Danos Materiais e Lucros Cessantes
		 */
		model.addAttribute("hierarquiaDM",JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(hierarquiaDM));

		boolean lmiUnico = produto.getLmiUnico() != null ? produto.getLmiUnico().getLogical() : false;

		/**
		 * Atributos do Item/Local de Risco (caracteristicas)
		 */
		model.addAttribute("ufs",ufs);
		model.addAttribute("bensCobertos",bensCobertos);
		model.addAttribute("classesConstrucao",classesConstrucao);
		model.addAttribute("classesOcupacao",classesOcupacao);
		model.addAttribute("classesLocalizacao",classesLocalizacao);
		model.addAttribute("localizacoes",localizacoes);
		model.addAttribute("protecionais",protecionais);
		model.addAttribute("idsVRDistribuido",TipoValorRiscoDistribuidoEnum.values());
		model.addAttribute("ciasSeguradora",ciasSeguradora);
		model.addAttribute("coberturasBasicas",coberturasBasicas);
		model.addAttribute("classesBonus",ClasseBonusEnum.values());
		model.addAttribute("lmiUnico",lmiUnico);
		model.addAttribute("produto",produto);

		model.addAttribute("prazoVigenciaProduto",produto.getPrazoVigencia());
		model.addAttribute("carateristicas",produtoCaracteristica.orElseThrow(IllegalStateException::new));

		if (lmiUnico) {
			for (ItemCotacaoView item : cotacaoView.getListItem()) {
				if (!item.getNumeroItem().equals(BigInteger.ONE)) {
					item.getListCoberturaBasica().clear();
					item.getListCoberturaAcessoriaDM().clear();
					item.getListCoberturaAcessoriaLC().clear();
				}
			}
		}
		/**
		 * FIM ENDOSSO DE INCLUSAO
		 */
	}

	@LogPerformance
	public void montaHierarquiaDM(CotacaoView cotacao,Produto produto,List<Cobertura> coberturasBasicas,List<CoberturaBasicaHierarquiaView> hierarquiaDM) {
		if (cotacao.getListItem() != null && !cotacao.getListItem().isEmpty()) {
			for (ItemCotacaoView itemCotacaoView : cotacao.getListItem()) {
				if (itemCotacaoView.getListCoberturaBasica() != null && !itemCotacaoView.getListCoberturaBasica().isEmpty()) {
					Integer codigoCoberturaBasica = itemCotacaoView.getListCoberturaBasica().get(0).getCodigoCobertura();
					for (int i = 0 ; i < itemCotacaoView.getListCoberturaAcessoriaDM().size() ; i++) {
						ItemCoberturaView coberturaAtual = itemCotacaoView.getListCoberturaAcessoriaDM().get(i);

						List<CoberturaHierarquiaView> coberturasDMItem = new ArrayList<>();

						for (CoberturaBasicaHierarquiaView cbhv : hierarquiaDM) {
							if (cbhv.getCoberturaBasica().equals(codigoCoberturaBasica)) {
								coberturasDMItem.addAll(cbhv.getFilhas());
							}
						}

						for (CoberturaHierarquiaView cv : coberturasDMItem) {
							coberturaAtual.getValoresCobertura().add(new CoberturaValor(cv.getCodigoCobertura(),cv.getDescricao()));
						}

						Map<Integer,Object> infras = coberturaService.getInfrasCobertura(produto.getCodigo(),coberturaAtual.getCodigoCobertura(),cotacao.getDataCotacao(), coberturaAtual.getCoberturaPrincipal());
						if (infras.size() == 5) {
							coberturaAtual.setPeriodosIndenitarios((List<Integer>) infras.get(1));
							coberturaAtual.setExigeValorRisco((boolean) infras.get(2));
							coberturaAtual.setExigeVagasGaragem((boolean) infras.get(3));
							coberturaAtual.setExigeIS((boolean) infras.get(4));
						}

						Map<String,List<BigDecimal>> multiplos = coberturaService.getMultiplosFranquiaPrejuizo(produto.getCodigo(),coberturaAtual.getCodigoCobertura(),cotacao.getDataCotacao());

						if (multiplos.containsKey("multiplosFranquia")) {
							coberturaAtual.setMultiplosFranquia(multiplos.get("multiplosFranquia"));
						}

						if (multiplos.containsKey("multiplosPrejuizo")) {
							coberturaAtual.setMultiplosPrejuizo(multiplos.get("multiplosPrejuizo"));
						}
					}
				}

				List<Integer> todasCoberturasDM = itemCotacaoView.getListCoberturaAcessoriaDM()
						.stream()
						.map(ItemCoberturaView::getCodigoCobertura).collect(Collectors.toList());

				for (int i = 0 ; i < itemCotacaoView.getListCoberturaAcessoriaDM().size() ; i++) {
					ItemCoberturaView coberturaAtual = itemCotacaoView.getListCoberturaAcessoriaDM().get(i);
					coberturaAtual.setValoresCobertura(coberturaAtual.getValoresCobertura().stream()
							.filter(valor -> !todasCoberturasDM.contains(valor.getCodigo()) || valor.getCodigo().equals(coberturaAtual.getCodigoCobertura()))
							.collect(Collectors.toList()));
				}

				if (itemCotacaoView.getListCoberturaBasica().size() == 0) {
					ItemCoberturaView linhaCoberturaBasica = new ItemCoberturaView();
					itemCotacaoView.getListCoberturaBasica().add(linhaCoberturaBasica);
				}

				if (itemCotacaoView.getListCoberturaAcessoriaDM().size() == 0) {
					ItemCoberturaView linhaCobertura = new ItemCoberturaView();

					List<CoberturaHierarquiaView> coberturasDoItem = new ArrayList<>();

					for (CoberturaBasicaHierarquiaView cbhv : hierarquiaDM) {
						if (cbhv.getCoberturaBasica().equals(coberturasBasicas.get(0).getCodigo())) {
							coberturasDoItem.addAll(cbhv.getFilhas());
						}
					}

					for (CoberturaHierarquiaView cv : coberturasDoItem) {
						linhaCobertura.getValoresCobertura().add(new CoberturaValor(cv.getCodigoCobertura(),cv.getDescricao()));
					}

					ItemCoberturaView linhaCoberturaAvulsa = new ItemCoberturaView();
					linhaCoberturaAvulsa.setIdCoberturaAvulsa(true);

					itemCotacaoView.getListCoberturaAcessoriaDM().add(linhaCobertura);
					itemCotacaoView.getListCoberturaAcessoriaDM().add(linhaCoberturaAvulsa);
				} else {
					if (itemCotacaoView.getListCoberturaAcessoriaDM().stream().filter(ItemCoberturaView::getIdCoberturaAvulsa).count() == 0) {

						ItemCoberturaView linhaCoberturaAvulsa = new ItemCoberturaView();
						linhaCoberturaAvulsa.setIdCoberturaAvulsa(true);
						itemCotacaoView.getListCoberturaAcessoriaDM().add(linhaCoberturaAvulsa);
					} else {
						itemCotacaoView.setCoberturaAvulsaDM(true);
					}
				}
			}
		}
	}

	private void trataRetornoCalculo(CotacaoView cotacao, HttpSession session) {
		boolean calculaLmi = true;
		if (cotacao.getEndossoSCT() == TipoEndossoSctEnum.ALTERACAO_INCLUSAO_EXCLUSAO) {
			calculaLmi = validacaoCalculoLmi(cotacao);
		}
		if(!calculaLmi) {
			session.setAttribute(ERRO,Arrays.asList("Nos casos de produtos com LMI devem ser cadastrados pelo menos 2 locais de risco."));
		} else {
			try {
				ResultadoREST<List<String>> resultadoBlaze = calculoEndossoService.geraMensagemECalculaEndosso(cotacao.getSequencialCotacaoProposta(), getUser());
				
				if(resultadoBlaze.isSuccess()) {
					session.setAttribute(SUCESSO,  Arrays.asList("Cotação calculada com sucesso!"));
				} else if(resultadoBlaze.getRetornoObj() != null && !resultadoBlaze.getRetornoObj().isEmpty()){
					session.setAttribute(ERRO, resultadoBlaze.getRetornoObj());
				} else {
					session.setAttribute(ERRO,Arrays.asList(resultadoBlaze.getMensagem()));
				}
			} catch (CalculoException e) {			
				ResultadoREST<List<String>> resultadoBlaze = e.getResultado();
				if(e.getResultado().isSuccess()) {
					session.setAttribute(SUCESSO,  Arrays.asList("Cotação calculada com sucesso!"));
				} else if(e.getResultado().getRetornoObj() != null && !e.getResultado().getRetornoObj().isEmpty()) {
					session.setAttribute(ERRO, resultadoBlaze.getRetornoObj());
				} else {
					session.setAttribute(ERRO,Arrays.asList(resultadoBlaze.getMensagem()));
				}	
			}
			
		}
	}
	
	private boolean validacaoCalculoLmi(CotacaoView cotacaoView) {
		boolean produtoLmi = Arrays.asList(1850,9651,1852).contains(cotacaoView.getCodigoProduto());
		if(!produtoLmi) {
			return true;
		}

		boolean temMaisDeUmItem = cotacaoView.getListItem().stream()
				.filter(it -> TipoEndossoEnum.isItemAlteracaoInclusao(it.getIdTipoEndosso(), false) || it.getIdTipoEndosso() == null)
				.count() > 1;
		if(temMaisDeUmItem) {
			return true;
		}

		return false;
	}
	
	private void definirDataAlteracaoAcsel(CtpjToken token, Cotacao cotacao,
			CotacaoView cotacaoView) {
		if(DestinoEmissaoEnum.ACX == cotacao.getIdDestinoEmissao()) {
			Apolice apolice = apoliceRepository.findById(token.getSolicitacaoCotacao().getIdMongodb());
			if(!endossoService.isDataAlteracaoValidaEndossoCancelamentoEndossoAcsel(cotacaoView, cotacao, apolice)) {
				cotacaoView.setDataAlteracao(apolice.getDataAlteracao());
				cotacao.setDataAlteracao(apolice.getDataAlteracao());	
			}
		}
	}

	private static class Solicitante {
		private String id;
		private String descricao;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getDescricao() {
			return descricao;
		}
		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}
		@Override
		public String toString() {
			return "Solicitante [id=" + id + ", descricao=" + descricao + "]";
		}
	}
}