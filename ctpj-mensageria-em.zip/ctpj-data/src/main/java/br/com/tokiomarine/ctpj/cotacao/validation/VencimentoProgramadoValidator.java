package br.com.tokiomarine.ctpj.cotacao.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilCalculoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.PerfilComercialRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.infra.domain.PerfilCalculoCondicao;
import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialCondicao;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.DateUtil;

@Component
public class VencimentoProgramadoValidator {

	private static final Set<Integer> regraInicioVigenciaBoleto = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(11,12,13,14,15,16,17,18,19,20)));
	private static final Set<Integer> regraTransmissaoBoleto = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(2,3,4,5,6,7,8,9,10)));
	private static final Set<Integer> regraNaoTemBoleto = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(1)));

	private static final Set<Integer> regraInicioVigenciaDebito = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(11,12,13,14,15,16,17,18,19,20)));
	private static final Set<Integer> regraTransmissaoDebito = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(2,3,4,5,6,7,8,9,10)));
	private static final Set<Integer> regraNaoTemDebito = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(1)));
	
	@Autowired
	private PerfilComercialRepository perfilComercialRepository;

	@Autowired
	private PerfilCalculoRepository perfilCalculoRepository;

	public List<Validacao> validaDataVencimentoProgramado(Cotacao cotacao, Integer formaPagamento, Integer parcelamentoSelecionado) {
		List<Validacao> listaValidacao;
		User user = SecurityUtils.getCurrentUser();
		if(cotacao.getDataVencimentoProgramada() == null) {
			return Collections.emptyList();
		}
		
		if(formaPagamento.equals(FormaPagamentoEnum.CARNE.getCodigo())) {
			listaValidacao = validaBoleto(cotacao,parcelamentoSelecionado,user);
		} else {
			listaValidacao = validaDebito(cotacao,parcelamentoSelecionado,user);
		}

		return listaValidacao;
	}

	private List<Validacao> validaBoleto(Cotacao cotacao, Integer parcelamentoSelecionado,User user) {
		List<Validacao> listaValidacao = new ArrayList<>();
		Date dataInicio;
		Date dataFim;

		if(regraInicioVigenciaBoleto.contains(parcelamentoSelecionado)) {
			PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(
					user.getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			if(perfilComercialCondicao != null) {
				dataInicio = DateUtils.addDays(cotacao.getDataInicioVigencia(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMinimo());
				dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMaximo());
			} else {
				PerfilCalculoCondicao condicao = perfilCalculoRepository.findPerfilCalculoCondicao(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCotacao());
				if(condicao != null) {
					dataInicio = DateUtils.addDays(cotacao.getDataInicioVigencia(), condicao.getNumeroDiasVencimentoProgramadoMinimo());
					dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(), condicao.getNumeroDiasVencimentoProgramadoMaximo());
				} else {
					dataInicio = new Date();
					dataFim = new Date();
				}
			}

			Date dataVencimentoProgramada = cotacao.getDataVencimentoProgramada();
			boolean dataValida = DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataInicio,
					Calendar.MINUTE) >= 0
					&& DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataFim, Calendar.MINUTE) <= 0;
			if(!dataValida) {
				listaValidacao.add(new Validacao("Data de vencimento programado menor que a data mínima permitida. Período permitido : " + DateUtil.formataSemHora(dataInicio) + " a " + DateUtil.formataSemHora(dataFim)));
			}
		} else if(regraTransmissaoBoleto.contains(parcelamentoSelecionado)) {
			PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(
					user.getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			if(perfilComercialCondicao != null) {
				dataInicio = DateUtils.addDays(new Date(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMinimo());
				dataFim = DateUtils.addDays(new Date(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMaximo());
			} else {
				PerfilCalculoCondicao condicao = perfilCalculoRepository.findPerfilCalculoCondicao(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCotacao());
				if(condicao != null) {
					dataInicio = DateUtils.addDays(new Date(), condicao.getNumeroDiasVencimentoProgramadoMinimo());
					dataFim = DateUtils.addDays(new Date(), condicao.getNrDiasVencimentoProgramadoMaxComEntrada());
				} else {
					dataInicio = new Date();
					dataFim = new Date();
				}
			}

			Date dataVencimentoProgramada = cotacao.getDataVencimentoProgramada();
			boolean dataValida = DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataInicio,
					Calendar.MINUTE) >= 0
					&& DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataFim, Calendar.MINUTE) <= 0;
			if(!dataValida) {
				listaValidacao.add(new Validacao("Data de vencimento programado menor que a data mínima permitida. Período permitido : " + DateUtil.formataSemHora(dataInicio) + " a " + DateUtil.formataSemHora(dataFim)));
			}
		}

		return listaValidacao;
	}

	private List<Validacao> validaDebito(Cotacao cotacao, Integer parcelamentoSelecionado,User user) {
		List<Validacao> listaValidacao = new ArrayList<>();
		Date dataInicio;
		Date dataFim;

		if(regraInicioVigenciaDebito.contains(parcelamentoSelecionado)) {
			PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(
					user.getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			if(perfilComercialCondicao != null) {
				dataInicio = DateUtils.addDays(cotacao.getDataInicioVigencia(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMinimo());
				dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMaximo());
			} else {
				PerfilCalculoCondicao condicao = perfilCalculoRepository.findPerfilCalculoCondicao(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCotacao());
				if(condicao != null) {
					dataInicio = DateUtils.addDays(cotacao.getDataInicioVigencia(), condicao.getNumeroDiasVencimentoProgramadoMinimo());
					dataFim = DateUtils.addDays(cotacao.getDataInicioVigencia(), condicao.getNumeroDiasVencimentoProgramadoMaximo());
				} else {
					dataInicio = new Date();
					dataFim = new Date();
				}
			}

			Date dataVencimentoProgramada = cotacao.getDataVencimentoProgramada();
			boolean dataValida = DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataInicio,
					Calendar.MINUTE) >= 0
					&& DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataFim, Calendar.MINUTE) <= 0;
			if(!dataValida) {
				listaValidacao.add(new Validacao("Data de vencimento programado menor que a data mínima permitida. Período permitido : " + DateUtil.formataSemHora(dataInicio) + " a " + DateUtil.formataSemHora(dataFim)));
			}
		} else if(regraTransmissaoDebito.contains(parcelamentoSelecionado)) {
			PerfilComercialCondicao perfilComercialCondicao = perfilComercialRepository.findPerfilComercialCondicao(
					user.getCdUsuro().longValue(),
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());
			if(perfilComercialCondicao != null) {
				dataInicio = DateUtils.addDays(new Date(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMinimo());
				dataFim = DateUtils.addDays(new Date(), perfilComercialCondicao.getNumeroDiasVencimentoProgramadoMaximo());
			} else {
				PerfilCalculoCondicao condicao = perfilCalculoRepository.findPerfilCalculoCondicao(
						user.getCdUsuro().longValue(),
						cotacao.getCodigoProduto(),
						cotacao.getDataCotacao());
				if(condicao != null) {
					dataInicio = DateUtils.addDays(new Date(), condicao.getNumeroDiasVencimentoProgramadoMinimo());
					dataFim = DateUtils.addDays(new Date(), condicao.getNrDiasVencimentoProgramadoMaxComEntrada());
				} else {
					dataInicio = new Date();
					dataFim = new Date();
				}
			}

			Date dataVencimentoProgramada = cotacao.getDataVencimentoProgramada();
			boolean dataValida = DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataInicio,
					Calendar.MINUTE) >= 0
					&& DateUtils.truncatedCompareTo(dataVencimentoProgramada, dataFim, Calendar.MINUTE) <= 0;
			if(!dataValida) {
				listaValidacao.add(new Validacao("Data de vencimento programado menor que a data mínima permitida. Período permitido : " + DateUtil.formataSemHora(dataInicio) + " a " + DateUtil.formataSemHora(dataFim)));
			}
		}

		return listaValidacao;
	}
}
