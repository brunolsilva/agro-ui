package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DadosContaDebitoView implements Serializable {

	private static final long serialVersionUID = 3536630643530830268L;

	private String codigoRetorno;
	private String descricaoCodigoRetorno;
	private String p_id_conta_valida;
	private Boolean returnFuncion;

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	public Boolean getReturnFuncion() {
		return returnFuncion;
	}

	public String getP_id_conta_valida() {
		return p_id_conta_valida;
	}

	public void setP_id_conta_valida(String p_id_conta_valida) {
		this.p_id_conta_valida = p_id_conta_valida;
	}

	public void setReturnFuncion(Boolean returnFuncion) {
		this.returnFuncion = returnFuncion;
	}
}