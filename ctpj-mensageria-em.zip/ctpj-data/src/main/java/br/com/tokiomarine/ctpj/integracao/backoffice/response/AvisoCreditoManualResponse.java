package br.com.tokiomarine.ctpj.integracao.backoffice.response;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AvisoCreditoManualResponse {

	@JsonProperty("p_cd_pedido_cotacao")
	private BigInteger numeroCotacaoProposta;

	@JsonProperty("p_id_credito_bloqueado")
	private String idCreditoBloqueado;

	@JsonProperty("p_id_credito_utilizado")
	private String idCreditoUtilizado;

	@JsonProperty("p_vl_credito")
	private BigDecimal valorCredito;

	@JsonProperty("p_mens")
	private String mensagemErro;

	@JsonProperty("p_id_tipo_recebimento")
	private String idTipoRecebimento;

	@JsonProperty("codigoRetorno")
	private String codigoRetorno;

	@JsonProperty("descricaoCodigoRetorno")
	private String descricaoCodigoRetorno;

	@JsonProperty("erroBD")
	private String erroBancoDados;

	public String getIdCreditoBloqueado() {
		return idCreditoBloqueado;
	}

	public void setIdCreditoBloqueado(String idCreditoBloqueado) {
		this.idCreditoBloqueado = idCreditoBloqueado;
	}

	public String getIdCreditoUtilizado() {
		return idCreditoUtilizado;
	}

	public void setIdCreditoUtilizado(String idCreditoUtilizado) {
		this.idCreditoUtilizado = idCreditoUtilizado;
	}

	public BigDecimal getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(BigDecimal valorCredito) {
		this.valorCredito = valorCredito;
	}

	public String getMensagemErro() {
		return mensagemErro;
	}

	public void setMensagemErro(String mensagemErro) {
		this.mensagemErro = mensagemErro;
	}

	public String getIdTipoRecebimento() {
		return idTipoRecebimento;
	}

	public void setIdTipoRecebimento(String idTipoRecebimento) {
		this.idTipoRecebimento = idTipoRecebimento;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoCodigoRetorno() {
		return descricaoCodigoRetorno;
	}

	public void setDescricaoCodigoRetorno(String descricaoCodigoRetorno) {
		this.descricaoCodigoRetorno = descricaoCodigoRetorno;
	}

	public String getErroBancoDados() {
		return erroBancoDados;
	}

	public void setErroBancoDados(String erroBancoDados) {
		this.erroBancoDados = erroBancoDados;
	}

	@Override
	public String toString() {
		return "AvisoCreditoManualResponse [numeroCotacaoProposta=" + numeroCotacaoProposta + ", idCreditoBloqueado=" + idCreditoBloqueado + ", idCreditoUtilizado=" + idCreditoUtilizado + ", valorCredito=" + valorCredito + ", mensagemErro=" + mensagemErro + ", idTipoRecebimento=" + idTipoRecebimento + ", codigoRetorno=" + codigoRetorno + ", descricaoCodigoRetorno=" + descricaoCodigoRetorno + ", erroBancoDados=" + erroBancoDados + "]";
	}

}
