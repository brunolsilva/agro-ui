package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.dto.SeguradoEndereco;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Municipio;
import br.com.tokiomarine.ctpj.infra.mongo.repository.MunicipioRepository;

@Service
public class MunicipioService {

	private static final Logger logger = LogManager.getLogger(MunicipioService.class);

	@Autowired
	private MunicipioRepository municipioRepository;

	/**
	 * Busca realizada ao preencher o cep, recupera a faixa desse cep e, com a informação
	 * do município, busca a região tarifária
	 *
	 * @param seguradoEndereco obj que será populado com município e região tarifária
	 * @throws ServiceException
	 */
	public void getMunicipioByCep(SeguradoEndereco seguradoEndereco) throws ServiceException {
		try {
			municipioRepository.getMunicipioByCep(seguradoEndereco);
		} catch (Exception e) {
			logger.error("Erro ao buscar o municipio + regiao tarifaria ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	public List<Municipio> findMunicipios(String uf) throws ServiceException {
		try {
			return municipioRepository.findMunicipios(uf);
		} catch (Exception e) {
			logger.error("Erro ao buscar o municipio ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
}