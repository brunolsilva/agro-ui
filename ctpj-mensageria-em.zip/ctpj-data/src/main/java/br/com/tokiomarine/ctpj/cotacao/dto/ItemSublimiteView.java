package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemSublimiteView implements Serializable {

	private static final long serialVersionUID = -2919527505279357045L;

	private Integer numeroItem;
	private Integer codigoCobertura;
	private Integer coberturaPrincipal;
	private String valorSublimite;
	private String descricaoCobertura;
	private String valorSublimiteOriginal;
	private BigInteger sequencialItemCobertura;
	private boolean semValor = false;
	private BigInteger sqCotacao;

	public ItemSublimiteView() {

	}

	public ItemSublimiteView(Integer numeroItem, boolean semValor) {
		this.numeroItem = numeroItem;
		this.semValor = semValor;
	}

	public Integer getNumeroItem() {
		return numeroItem;
	}

	public void setNumeroItem(Integer numeroItem) {
		this.numeroItem = numeroItem;
	}

	public String getValorSublimite() {
		return valorSublimite;
	}

	public void setValorSublimite(String valorSublimite) {
		this.valorSublimite = valorSublimite;
	}

	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}

	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}

	public String getValorSublimiteOriginal() {
		return valorSublimiteOriginal;
	}

	public void setValorSublimiteOriginal(String valorSublimiteOriginal) {
		this.valorSublimiteOriginal = valorSublimiteOriginal;
	}

	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}

	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}

	public Integer getCoberturaPrincipal() {
		return coberturaPrincipal;
	}

	public void setCoberturaPrincipal(Integer coberturaPrincipal) {
		this.coberturaPrincipal = coberturaPrincipal;
	}

	public boolean isSemValor() {
		return semValor;
	}

	public void setSemValor(boolean semValor) {
		this.semValor = semValor;
	}

	public BigInteger getSequencialItemCobertura() {
		return sequencialItemCobertura;
	}

	public void setSequencialItemCobertura(BigInteger sequencialItemCobertura) {
		this.sequencialItemCobertura = sequencialItemCobertura;
	}

	public BigInteger getSqCotacao() {
		return sqCotacao;
	}

	public void setSqCotacao(BigInteger sqCotacao) {
		this.sqCotacao = sqCotacao;
	}
}