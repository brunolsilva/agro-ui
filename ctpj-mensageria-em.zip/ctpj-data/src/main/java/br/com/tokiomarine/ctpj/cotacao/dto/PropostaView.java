package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCreditoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.util.CnpjCpfUtil;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PropostaView implements Serializable {

	private static final long serialVersionUID = 1787939895474358037L;

	private BigInteger sequencialCotacaoProposta;
	private TipoSeguradoEnum idTipoPessoa;
	private Long numeroCNPJCPFSegurado;
	private String nomeSegurado;
	private Integer codigoAtividadePrincipal;
	private String descricaoAtividadePrincipal;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "America/Sao_Paulo")
	private Date dataVencimentoParcela;

	private BigDecimal valorPrimeiraParcela;
	private Integer quantidadeParcelas;
	private String formaPagamento;
	private Integer codigoFormaParcelamento;
	private boolean entrada;
	private String propostaCorretor;
	private Integer codigoFormaPagamento;
	private CotacaoView cotacao;
	private DocumentoDigitalView documentoDigital;
	
	private Long codigoRessegurador;
	private String idOficioRessegurador;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "America/Sao_Paulo")
	private Date dataEmissaoOficio;
	private Integer codigoSituacao;
	private String urlBoleto;
	private boolean possuiRecebimento;
	private TipoCreditoEnum idTipoCredito;
	
	private CartaoView cartao;

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}
	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}
	public TipoSeguradoEnum getIdTipoPessoa() {
		return idTipoPessoa;
	}
	public void setIdTipoPessoa(TipoSeguradoEnum idTipoPessoa) {
		this.idTipoPessoa = idTipoPessoa;
	}
	public Long getNumeroCNPJCPFSegurado() {
		return numeroCNPJCPFSegurado;
	}
	public void setNumeroCNPJCPFSegurado(Long numeroCNPJCPFSegurado) {
		this.numeroCNPJCPFSegurado = numeroCNPJCPFSegurado;
	}
	public String getNomeSegurado() {
		return nomeSegurado;
	}
	public void setNomeSegurado(String nomeSegurado) {
		this.nomeSegurado = nomeSegurado;
	}
	public Integer getCodigoAtividadePrincipal() {
		return codigoAtividadePrincipal;
	}
	public void setCodigoAtividadePrincipal(Integer codigoAtividadePrincipal) {
		this.codigoAtividadePrincipal = codigoAtividadePrincipal;
	}
	public String getDescricaoAtividadePrincipal() {
		return descricaoAtividadePrincipal;
	}
	public void setDescricaoAtividadePrincipal(String descricaoAtividadePrincipal) {
		this.descricaoAtividadePrincipal = descricaoAtividadePrincipal;
	}
	public boolean isExibeBoleto() {
		if(codigoFormaPagamento == 1) {
			return true;
		}
		return false;
	}
	
	public boolean isDebitoEmConta() {
		return codigoFormaPagamento != null && codigoFormaPagamento.equals(FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo());
	}
	
	public Date getDataVencimentoParcela() {
		return dataVencimentoParcela;
	}
	public void setDataVencimentoParcela(Date dataVencimentoParcela) {
		this.dataVencimentoParcela = dataVencimentoParcela;
	}
	public BigDecimal getValorPrimeiraParcela() {
		return valorPrimeiraParcela;
	}
	public void setValorPrimeiraParcela(BigDecimal valorPrimeiraParcela) {
		this.valorPrimeiraParcela = valorPrimeiraParcela;
	}
	public Integer getQuantidadeParcelas() {
		return quantidadeParcelas;
	}
	public void setQuantidadeParcelas(Integer quantidadeParcelas) {
		this.quantidadeParcelas = quantidadeParcelas;
	}
	public String getFormaPagamento() {
		return formaPagamento;
	}
	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	public String getPropostaCorretor() {
		return propostaCorretor;
	}
	public void setPropostaCorretor(String propostaCorretor) {
		this.propostaCorretor = propostaCorretor;
	}

	public String getNumeroCNPJCPF() {
		if(idTipoPessoa == TipoSeguradoEnum.FISICA) {
			return CnpjCpfUtil.getInstance().formataCPFString(numeroCNPJCPFSegurado);
		} else {
			return CnpjCpfUtil.getInstance().formataCNPJString(numeroCNPJCPFSegurado);
		}
	}

	public CotacaoView getCotacao() {
		return cotacao;
	}

	public void setCotacao(CotacaoView cotacao) {
		this.cotacao = cotacao;
	}

	public DocumentoDigitalView getDocumentoDigital() {
		return documentoDigital;
	}

	public void setDocumentoDigital(DocumentoDigitalView documentoDigital) {
		this.documentoDigital = documentoDigital;
	}
	public Integer getCodigoFormaPagamento() {
		return codigoFormaPagamento;
	}
	public void setCodigoFormaPagamento(Integer codigoFormaPagamento) {
		this.codigoFormaPagamento = codigoFormaPagamento;
	}
	public Integer getCodigoFormaParcelamento() {
		return codigoFormaParcelamento;
	}
	public void setCodigoFormaParcelamento(Integer codigoFormaParcelamento) {
		this.codigoFormaParcelamento = codigoFormaParcelamento;
	}
	public Long getCodigoRessegurador() {
		return codigoRessegurador;
	}
	public void setCodigoRessegurador(Long codigoRessegurador) {
		this.codigoRessegurador = codigoRessegurador;
	}
	public String getIdOficioRessegurador() {
		return idOficioRessegurador;
	}
	public void setIdOficioRessegurador(String idOficioRessegurador) {
		this.idOficioRessegurador = idOficioRessegurador;
	}
	public Date getDataEmissaoOficio() {
		return dataEmissaoOficio;
	}
	public void setDataEmissaoOficio(Date dataEmissaoOficio) {
		this.dataEmissaoOficio = dataEmissaoOficio;
	}
	public Integer getCodigoSituacao() {
		return codigoSituacao;
	}
	public void setCodigoSituacao(Integer codigoSituacao) {
		this.codigoSituacao = codigoSituacao;
	}
	public String getUrlBoleto() {
		return urlBoleto;
	}
	public void setUrlBoleto(String urlBoleto) {
		this.urlBoleto = urlBoleto;
	}
	public boolean isEntrada() {
		return entrada;
	}
	public void setEntrada(boolean entrada) {
		this.entrada = entrada;
	}
	public boolean isPossuiRecebimento() {
		return possuiRecebimento;
	}
	public void setPossuiRecebimento(boolean possuiRecebimento) {
		this.possuiRecebimento = possuiRecebimento;
	}
	public TipoCreditoEnum getIdTipoCredito() {
		return idTipoCredito;
	}
	public void setIdTipoCredito(TipoCreditoEnum idTipoCredito) {
		this.idTipoCredito = idTipoCredito;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public CartaoView getCartao() {
		return cartao;
	}
	public void setCartao(CartaoView cartao) {
		this.cartao = cartao;
	}
}