package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import br.com.tokiomarine.ctpj.enums.IdCessaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoResseguroEnum;

public class ResseguroFacultativoForm implements Serializable {
	private static final long serialVersionUID = 1L;

	@NotNull(message = "Broker é obrigatório")
	private BigInteger codigoBroker;

	@NotNull(message = "Tipo IS/LMG é obrigatório")
	private IdCessaoEnum idCessao;

	@NotNull(message = "Tipo do resseguro é obrigatório")
	private TipoResseguroEnum tipoResseguro;

	@NotNull(message = "Número de parcelas do seguro é obrigatório")
	@Min(value = 1, message = "Número de parcelas do seguro deve ser maior que zero")
	private Integer numeroParcelasSeguro;

	@NotNull(message = "Número de parcelas do resseguro é obrigatório")
	@Min(value = 1, message = "Número de parcelas do resseguro deve ser maior que zero")
	private Integer numeroParcelasResseguro;

	private String brokenAdicional;

	private boolean reintegracaoAutomaticaNaAP;

	@NotNull(message = "Percentual de utilização do Contrato Automático é obrigaório")
	private BigDecimal percentualUtilizacaoContratoAutomatico;

	@NotNull(message = "Percentual utilizada em Limite Técnico/Retenção é obrigaório")
	private BigDecimal percentualUtilizadoLimiteTecnico;
	
	private BigDecimal percentualCedidoIntraGrupo;  
	
	private BigDecimal percentualCessaoLocal; 

	@Valid
	@NotEmpty(message = "Distribuição para Resseguradores e Llyods é obrigatório")
	private List<ResseguroFacultativoCessaoForm> resseguroFacultativoCessaoList;

	private String observacoes;

	public BigInteger getCodigoBroker() {
		return codigoBroker;
	}

	public void setCodigoBroker(BigInteger codigoBroker) {
		this.codigoBroker = codigoBroker;
	}

	public IdCessaoEnum getIdCessao() {
		return idCessao;
	}

	public void setIdCessao(IdCessaoEnum idCessao) {
		this.idCessao = idCessao;
	}

	public TipoResseguroEnum getTipoResseguro() {
		return tipoResseguro;
	}

	public void setTipoResseguro(TipoResseguroEnum tipoResseguro) {
		this.tipoResseguro = tipoResseguro;
	}

	public Integer getNumeroParcelasSeguro() {
		return numeroParcelasSeguro;
	}

	public void setNumeroParcelasSeguro(Integer nroParcelasSeguro) {
		this.numeroParcelasSeguro = nroParcelasSeguro;
	}

	public Integer getNumeroParcelasResseguro() {
		return numeroParcelasResseguro;
	}

	public void setNumeroParcelasResseguro(Integer nroParcelasResseguro) {
		this.numeroParcelasResseguro = nroParcelasResseguro;
	}

	public String getBrokenAdicional() {
		return brokenAdicional;
	}

	public void setBrokenAdicional(String brokenAdicional) {
		this.brokenAdicional = brokenAdicional;
	}

	public boolean isReintegracaoAutomaticaNaAP() {
		return reintegracaoAutomaticaNaAP;
	}

	public void setReintegracaoAutomaticaNaAP(boolean reintegracaoAutomaticaNaAP) {
		this.reintegracaoAutomaticaNaAP = reintegracaoAutomaticaNaAP;
	}

	public BigDecimal getPercentualUtilizacaoContratoAutomatico() {
		return percentualUtilizacaoContratoAutomatico;
	}

	public void setPercentualUtilizacaoContratoAutomatico(BigDecimal porcentagemUtilizacaoContratoAutomatico) {
		this.percentualUtilizacaoContratoAutomatico = porcentagemUtilizacaoContratoAutomatico;
	}

	public BigDecimal getPercentualUtilizadoLimiteTecnico() {
		return percentualUtilizadoLimiteTecnico;
	}

	public void setPercentualUtilizadoLimiteTecnico(BigDecimal porcentagemUtilizadoEmLimiteTecnico) {
		this.percentualUtilizadoLimiteTecnico = porcentagemUtilizadoEmLimiteTecnico;
	}

	public List<ResseguroFacultativoCessaoForm> getResseguroFacultativoCessaoList() {
		return resseguroFacultativoCessaoList;
	}

	public void setResseguroFacultativoCessaoList(List<ResseguroFacultativoCessaoForm> resseguroFacultativoCessaoList) {
		this.resseguroFacultativoCessaoList = resseguroFacultativoCessaoList;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	public BigDecimal getPercentualCedidoIntraGrupo() {
		return percentualCedidoIntraGrupo;
	}

	public void setPercentualCedidoIntraGrupo(BigDecimal percentualCedidoComIntragrupo) {
		this.percentualCedidoIntraGrupo = percentualCedidoComIntragrupo;
	}

	public BigDecimal getPercentualCessaoLocal() {
		return percentualCessaoLocal;
	}

	public void setPercentualCessaoLocal(BigDecimal percentualCedidoLocal) {
		this.percentualCessaoLocal = percentualCedidoLocal;
	}

	@Override
	public String toString() {
		return "ResseguroFacultativoForm [codigoBroker=" + codigoBroker + ", idCessao=" + idCessao + ", tipoResseguro=" + tipoResseguro + ", numeroParcelasSeguro=" + numeroParcelasSeguro + ", numeroParcelasResseguro=" + numeroParcelasResseguro + ", brokenAdicional=" + brokenAdicional
				+ ", reintegracaoAutomaticaNaAP=" + reintegracaoAutomaticaNaAP + ", percentualUtilizacaoContratoAutomatico=" + percentualUtilizacaoContratoAutomatico + ", percentualUtilizadoLimiteTecnico=" + percentualUtilizadoLimiteTecnico + ", resseguroFacultativoCessaoList="
				+ resseguroFacultativoCessaoList + ", observacoes=" + observacoes + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brokenAdicional == null) ? 0 : brokenAdicional.hashCode());
		result = prime * result + ((codigoBroker == null) ? 0 : codigoBroker.hashCode());
		result = prime * result + ((numeroParcelasResseguro == null) ? 0 : numeroParcelasResseguro.hashCode());
		result = prime * result + ((numeroParcelasSeguro == null) ? 0 : numeroParcelasSeguro.hashCode());
		result = prime * result + ((observacoes == null) ? 0 : observacoes.hashCode());
		result = prime * result + ((percentualUtilizacaoContratoAutomatico == null) ? 0 : percentualUtilizacaoContratoAutomatico.hashCode());
		result = prime * result + ((percentualUtilizadoLimiteTecnico == null) ? 0 : percentualUtilizadoLimiteTecnico.hashCode());
		result = prime * result + (reintegracaoAutomaticaNaAP ? 1231 : 1237);
		result = prime * result + ((resseguroFacultativoCessaoList == null) ? 0 : resseguroFacultativoCessaoList.hashCode());
		result = prime * result + ((idCessao == null) ? 0 : idCessao.hashCode());
		result = prime * result + ((tipoResseguro == null) ? 0 : tipoResseguro.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResseguroFacultativoForm other = (ResseguroFacultativoForm) obj;
		if (brokenAdicional == null) {
			if (other.brokenAdicional != null)
				return false;
		} else if (!brokenAdicional.equals(other.brokenAdicional))
			return false;
		if (codigoBroker == null) {
			if (other.codigoBroker != null)
				return false;
		} else if (!codigoBroker.equals(other.codigoBroker))
			return false;
		if (numeroParcelasResseguro == null) {
			if (other.numeroParcelasResseguro != null)
				return false;
		} else if (!numeroParcelasResseguro.equals(other.numeroParcelasResseguro))
			return false;
		if (numeroParcelasSeguro == null) {
			if (other.numeroParcelasSeguro != null)
				return false;
		} else if (!numeroParcelasSeguro.equals(other.numeroParcelasSeguro))
			return false;
		if (observacoes == null) {
			if (other.observacoes != null)
				return false;
		} else if (!observacoes.equals(other.observacoes))
			return false;
		if (percentualUtilizacaoContratoAutomatico == null) {
			if (other.percentualUtilizacaoContratoAutomatico != null)
				return false;
		} else if (!percentualUtilizacaoContratoAutomatico.equals(other.percentualUtilizacaoContratoAutomatico))
			return false;
		if (percentualUtilizadoLimiteTecnico == null) {
			if (other.percentualUtilizadoLimiteTecnico != null)
				return false;
		} else if (!percentualUtilizadoLimiteTecnico.equals(other.percentualUtilizadoLimiteTecnico))
			return false;
		if (reintegracaoAutomaticaNaAP != other.reintegracaoAutomaticaNaAP)
			return false;
		if (resseguroFacultativoCessaoList == null) {
			if (other.resseguroFacultativoCessaoList != null)
				return false;
		} else if (!resseguroFacultativoCessaoList.equals(other.resseguroFacultativoCessaoList))
			return false;
		if (idCessao != other.idCessao)
			return false;
		if (tipoResseguro != other.tipoResseguro)
			return false;
		return true;
	}

}
