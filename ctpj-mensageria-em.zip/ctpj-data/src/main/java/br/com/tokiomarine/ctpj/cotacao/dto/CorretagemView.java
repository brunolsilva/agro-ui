package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CorretagemView implements Serializable {

	private static final long serialVersionUID = 8594526763465734492L;

	private String codigoCorretorAcsel;
	private String nomeCorretorAcsel;
	private String percentualCorretagem;
	private Boolean idCorretorLider;
	private BigInteger sequencialCotacaoProposta;

	public String getCodigoCorretorAcsel() {
		return codigoCorretorAcsel;
	}

	public void setCodigoCorretorAcsel(String codigoCorretorAcsel) {
		this.codigoCorretorAcsel = codigoCorretorAcsel;
	}

	public String getNomeCorretorAcsel() {
		return nomeCorretorAcsel;
	}

	public void setNomeCorretorAcsel(String nomeCorretorAcsel) {
		this.nomeCorretorAcsel = nomeCorretorAcsel;
	}

	public String getPercentualCorretagem() {
		return percentualCorretagem;
	}

	public void setPercentualCorretagem(String percentualCorretagem) {
		this.percentualCorretagem = percentualCorretagem;
	}

	public Boolean getIdCorretorLider() {
		return idCorretorLider;
	}

	public void setIdCorretorLider(Boolean idCorretorLider) {
		this.idCorretorLider = idCorretorLider;
	}

	public BigInteger getSequencialCotacaoProposta() {
		return sequencialCotacaoProposta;
	}

	public void setSequencialCotacaoProposta(BigInteger sequencialCotacaoProposta) {
		this.sequencialCotacaoProposta = sequencialCotacaoProposta;
	}
}