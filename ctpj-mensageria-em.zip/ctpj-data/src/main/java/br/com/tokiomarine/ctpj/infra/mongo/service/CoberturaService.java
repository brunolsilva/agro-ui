package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaHierarquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.domain.Cobertura;
import br.com.tokiomarine.ctpj.infra.domain.CoberturaAgrupamentoRestricao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracValorAtributo;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCobertura;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CoberturaRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoCaracValorAtributoRepository;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Service
public class CoberturaService {

	@Autowired
	private CoberturaRepository coberturaRepository;
	
	@Autowired
	private ProdutoCaracValorAtributoRepository produtoCaracValorAtributoRepository;

	@Autowired
	private CaracteristicaService caracteristicaService;

	@LogPerformance
	public Cobertura findCobertura(Integer codigo) {
		return coberturaRepository.findCobertura(codigo);
	}

	@LogPerformance
	public List<Cobertura> findCoberturasBasicas(CotacaoView cotacao) {
		if(cotacao.getCodigoProduto() == null || cotacao.getDataCotacao() == null) {
			return Collections.<Cobertura>emptyList();
		}
		
		List<Cobertura> coberturas = coberturaRepository.findCoberturasBasicas();
		return coberturaRepository.findCoberturasBasicas(cotacao,coberturas);
	}

	@LogPerformance
	public Map<Integer,List<CoberturaHierarquiaView>> findCoberturasAdicionaisDMView(CotacaoView cotacao, List<Integer> coberturasPrincipais){
		if(cotacao.getCodigoProduto() == null || cotacao.getDataCotacao() == null) {
			return Collections.emptyMap();
		}

		List<Cobertura> coberturas = coberturaRepository.findCoberturasAdicionais(
				TipoPedidoCotacaoEnum.ENDOSSO == cotacao.getIdTipoPedidoCotacao() ? true : false);
		//busca as rubricas para as quais as coberturas estão liberadas
		List<ProdutoCaracValorAtributo> produtoCaracValorList =  new ArrayList<>();// produtoCaracValorAtributoRepository.findProdutoCaracByProduto(cotacao.getCodigoProduto());
		Map<Integer, List<ProdutoCaracValorAtributo>> caracs = produtoCaracValorList.stream()
				.collect(Collectors.groupingBy(ProdutoCaracValorAtributo::getCobertura,HashMap::new,Collectors.toList()));
		System.out.println("dasdasd " + caracs);
		return coberturaRepository.findCoberturasAdicionaisDMView(cotacao, coberturasPrincipais, coberturas, caracs);
	}

	public Map<Integer, Object> getInfrasCobertura(Integer produto, Integer cobertura, Date dataCotacao, Integer coberturaPrincipal) {
		Map<Integer, Object> map = new HashMap<>();
		map.put(1, coberturaRepository.getPeriodosIndenitarios(produto,cobertura,dataCotacao));
		map.put(3, coberturaRepository.getExigeVagasGaragem(cobertura));
		map.putAll(coberturaRepository.getExigeValorRisco(produto,cobertura,dataCotacao,coberturaPrincipal));
		return map;
	}

	public Map<String, List<BigDecimal>> getMultiplosFranquiaPrejuizo(Integer produto, Integer cobertura, Date dataCotacao) {
		return coberturaRepository.getMultiplosFranquiaPrejuizo(produto,cobertura,dataCotacao);
	}

	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura, Integer coberturaPrincipal) {
		return coberturaRepository.findProdutoCobertura(codigoProduto, codigoCobertura, coberturaPrincipal);
	}

	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura) {
		return coberturaRepository.findProdutoCobertura(codigoProduto, codigoCobertura);
	}
	
	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura, Integer coberturaPrincipal, Date data) {
		return coberturaRepository.findProdutoCobertura(codigoProduto, codigoCobertura, coberturaPrincipal, data);
	}

	public ProdutoCobertura findProdutoCobertura(Integer codigoProduto, Integer codigoCobertura, Date data) {
		return coberturaRepository.findProdutoCobertura(codigoProduto, codigoCobertura, data);
	}

	public List<Integer> findCoberturasLiberadas(Integer produto, Long rubrica, Long bemCoberto) {
		List<Integer> coberturasPorRubrica = produtoCaracValorAtributoRepository.findProdutoCaracByValor(produto, rubrica);
		coberturasPorRubrica = coberturasPorRubrica.stream().distinct().collect(Collectors.toList());
		List<Integer> coberturasBemCoberto = caracteristicaService.findCoberturaBemCoberto(produto, bemCoberto);
		if(SecurityUtils.isCorretor()) {
			if(!coberturasBemCoberto.isEmpty()) {
				List<Integer> coberturasFiltradas = new ArrayList<>();
				for(Integer coberturaDaRubrica: coberturasPorRubrica) {
					for(Integer coberturaDoBemCoberto: coberturasBemCoberto) {
						if(coberturaDoBemCoberto.equals(coberturaDaRubrica)) {
							coberturasFiltradas.add(coberturaDoBemCoberto);
						}
					}
				}
				return coberturasFiltradas;
			}
		}

		return coberturasPorRubrica;
	}

	@LogPerformance
	public List<CoberturaAgrupamentoRestricao> findAgrupamentosRestricaoPorProduto(Cotacao cotacao) {
		try {
			return coberturaRepository.findAgrupamentosRestricaoPorProduto(cotacao);
		} catch (Exception e) {
			throw new RuntimeException(
					String.format("Erro ao buscar agrupamentos de coberturas do produto %s ",
							cotacao.getCodigoProduto()), e);
		}
	}
}