package br.com.tokiomarine.ctpj.cotacao.controller;

import java.io.IOException;
import java.math.BigInteger;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.cotacao.relatorios.RelatorioException;
import br.com.tokiomarine.ctpj.cotacao.relatorios.memoriacalculo.GeradorRelatorioMemoriaCalculo;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.MemoriaCalculoService;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaCalculo;
import br.com.tokiomarine.ctpj.enums.TipoRelatorioEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.TabelaMemoriaCalculoViewMapper;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping("/memoriaCalculo/{seqCotacao}")
public class MemoriaCalculoController {
	
	@Autowired
	private MemoriaCalculoService memoriaCalculoService;	
	@Autowired
	private CotacaoService cotacaoService;
	@Autowired
	private GeradorRelatorioMemoriaCalculo geradorRelatorioMemoriaCalculo;
	
	@GetMapping
	public String page(@PathVariable BigInteger seqCotacao, @RequestHeader(value = "referer", required = false) String referer, Model model) throws ServiceException{
		MemoriaCalculo memoriaCalculos = memoriaCalculoService.buscaMemorias(seqCotacao);
		
		if(memoriaCalculos != null){
			model.addAttribute("memoria", memoriaCalculos);
			model.addAttribute("calculos", TabelaMemoriaCalculoViewMapper.getInstance().fromMemoriaCalculoToListOfLinhaTabelaCalculoview(memoriaCalculos));
		}
		model.addAttribute("cabecalhoCotacao", cotacaoService.findCotacaoCabecalho(seqCotacao));
		model.addAttribute("seqCotacao", seqCotacao);
		model.addAttribute("origem", referer);
		
		return Paginas.memoriaCalculo.value();
	}
	
	@GetMapping(value = "/planilha")
	public void geraPlanilha(@PathVariable BigInteger seqCotacao, HttpServletResponse response) throws RelatorioException, IOException {
		MemoriaCalculo memoriaCalculo = memoriaCalculoService.buscaMemorias(seqCotacao);
		byte[] planilha = geradorRelatorioMemoriaCalculo.gera(memoriaCalculo);

		response.setContentType(TipoRelatorioEnum.XLS_CONTENT_TYPE.getText());
		String headerValue = TipoRelatorioEnum.ATTACHMENT_FILENAME.getText().concat("memoria-calculo.xls");
		response.setHeader(TipoRelatorioEnum.CONTENT_DISPOSITION.getText(), headerValue);
		response.setContentLength(planilha.length);
		response.getOutputStream().write(planilha);
		response.getOutputStream().flush();
	}	
}
