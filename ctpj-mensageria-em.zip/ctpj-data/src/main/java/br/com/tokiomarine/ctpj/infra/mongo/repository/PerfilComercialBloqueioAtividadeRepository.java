package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.PerfilComercialBloqueioAtividade;

@Repository
public class PerfilComercialBloqueioAtividadeRepository {
	@Autowired
	private MongoTemplate mongoTemplate;
	
	public List<PerfilComercialBloqueioAtividade> listarPerfilComercialBloqueio(Long perfilComercial, List<Long> categoriasContratadas,Integer local, Integer subLocal) {
		return mongoTemplate.find(
				query(
						where("ativo").is("S")
						.and("categoriaTarifaria").in(categoriasContratadas)
						/*.and("local").is(local)
						.and("subLocal").is(subLocal)*/)
						.with(new Sort(Direction.DESC,"classificacao")), 
						PerfilComercialBloqueioAtividade.class);
	}
	
	public List<PerfilComercialBloqueioAtividade> findPerfilComercialBloqueio(Long perfilComercial, Long codigoCategoria,Integer local, Integer subLocal) {
		return mongoTemplate.find(
				query(
						where("ativo").is("S")
						.and("categoriaTarifaria").is(codigoCategoria)
						/*.and("local").is(local)
						.and("subLocal").is(subLocal)*/), 
						PerfilComercialBloqueioAtividade.class);
	}
	
	public List<PerfilComercialBloqueioAtividade> list() {
		return mongoTemplate.findAll(PerfilComercialBloqueioAtividade.class);
	}
}
