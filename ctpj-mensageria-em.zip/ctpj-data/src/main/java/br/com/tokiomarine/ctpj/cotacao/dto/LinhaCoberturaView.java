package br.com.tokiomarine.ctpj.cotacao.dto;

import java.math.BigInteger;
import java.util.List;

/**
 * Objeto da camada de View que representa uma linha na tabela de coberturas
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class LinhaCoberturaView {

	private BigInteger seqItemCobertura;
	private BigInteger itemCotacao;
	private Integer codCobertura;
	private String descricaoCobertura;
	private List<ClausulaView> clausulas;
	
	public BigInteger getSeqItemCobertura() {
		return seqItemCobertura;
	}

	public void setSeqItemCobertura(BigInteger seqItemCobertura) {
		this.seqItemCobertura = seqItemCobertura;
	}
	
	public BigInteger getItemCotacao() {
		return itemCotacao;
	}

	public void setItemCotacao(BigInteger itemCotacao) {
		this.itemCotacao = itemCotacao;
	}

	public Integer getCodCobertura() {
		return codCobertura;
	}

	public void setCodCobertura(Integer codCobertura) {
		this.codCobertura = codCobertura;
	}

	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}

	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}

	public List<ClausulaView> getClausulas() {
		return clausulas;
	}

	public void setClausulas(List<ClausulaView> clausulas) {
		this.clausulas = clausulas;
	}
	
}
