package br.com.tokiomarine.ctpj.cotacao.controller;

import java.math.BigInteger;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.type.Paginas;

@Controller
@RequestMapping(value = "/detalheCalculo")
public class DetalheCalculoController extends AbstractController {

	private static final Logger logger = LogManager.getLogger(DetalheCalculoController.class);

	@Autowired
	private CotacaoService cotacaoService;
	
	@LogPerformance
	@GetMapping(value = "/{sequencialCotacaoProposta}")
	public String page(@PathVariable BigInteger sequencialCotacaoProposta, @RequestHeader(value = "referer", required = false) String referer, Model model) throws ServiceException{
		logger.info("teste");
		Cotacao cotacao = cotacaoService.findCotacaoTela(sequencialCotacaoProposta);
		CotacaoView cotacaoView = CotacaoViewMapper.INSTANCE.toCotacaoView(cotacao);
		cotacaoView.setListItemPremioFranquia(CotacaoViewMapper.INSTANCE.itemCotacaoSetToItemCotacaoPremioFranquiaViewList(cotacao.getCodigoMoeda(),cotacao.getListItem()));		
		model.addAttribute("cotacao",cotacaoView);
		model.addAttribute("cabecalhoCotacao", cotacaoView);
		model.addAttribute("origem", referer);
		
		return Paginas.detalheCalculo.value();
	}

}