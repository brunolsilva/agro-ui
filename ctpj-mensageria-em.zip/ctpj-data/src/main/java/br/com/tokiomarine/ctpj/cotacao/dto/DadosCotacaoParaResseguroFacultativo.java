package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;

public class DadosCotacaoParaResseguroFacultativo implements Serializable {
	private static final long serialVersionUID = 1L;

	public enum TipoCosseguro{
		CEDIDO("CEDIDO"), SEM_COSSEGURO("S/COSSEGURO");
		
		private TipoCosseguro(String descricao) {
			this.descricao = descricao;
		}

		private String descricao;

		public String getDescricao() {
			return descricao;
		}
	}
	
	private BigInteger seqCotacao;
	private String subscritor;
	private Integer ramo;
	private String apolice;
	private MoedaEnum moeda;
	private Date data;
	private String segurado;
	private Date inicioVigencia;
	private Date fimVigencia;
	private BigDecimal premioSeguro;
	private BigDecimal valorLmrLmg;
	private TipoCosseguro tipoCosseguro;
	private BigDecimal percentualCosseguro;

	public BigInteger getSeqCotacao() {
		return seqCotacao;
	}

	public void setSeqCotacao(BigInteger seqCotacao) {
		this.seqCotacao = seqCotacao;
	}

	public String getSubscritor() {
		return subscritor;
	}

	public void setSubscritor(String subscritor) {
		this.subscritor = subscritor;
	}

	public Integer getRamo() {
		return ramo;
	}

	public void setRamo(Integer ramo) {
		this.ramo = ramo;
	}

	public String getApolice() {
		return apolice;
	}

	public void setApolice(String apolice) {
		this.apolice = apolice;
	}

	public MoedaEnum getMoeda() {
		return moeda;
	}

	public void setMoeda(MoedaEnum moeda) {
		this.moeda = moeda;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getSegurado() {
		return segurado;
	}

	public void setSegurado(String segurado) {
		this.segurado = segurado;
	}

	public Date getInicioVigencia() {
		return inicioVigencia;
	}

	public void setInicioVigencia(Date inicioVigencia) {
		this.inicioVigencia = inicioVigencia;
	}

	public Date getFimVigencia() {
		return fimVigencia;
	}

	public void setFimVigencia(Date fimVigencia) {
		this.fimVigencia = fimVigencia;
	}

	public BigDecimal getPremioSeguro() {
		return premioSeguro;
	}

	public void setPremioSeguro(BigDecimal premioSeguro) {
		this.premioSeguro = premioSeguro;
	}

	public BigDecimal getValorLmrLmg() {
		return valorLmrLmg;
	}

	public void setValorLmrLmg(BigDecimal valorLmrLmg) {
		this.valorLmrLmg = valorLmrLmg;
	}
	
	public void setTipoCosseguro(TipoCosseguro tipo){
		this.tipoCosseguro = tipo;
	}
	
	public String getTipoCosseguro(){
		return this.tipoCosseguro.descricao;
	}

	public BigDecimal getPercentualCosseguro() {
		return percentualCosseguro;
	}

	public void setPercentualCosseguro(BigDecimal percentualCosseguro) {
		this.percentualCosseguro = percentualCosseguro;
	}

	@Override
	public String toString() {
		return "DadosCotacaoParaResseguroFacultativo [seqCotacao=" + seqCotacao + ", subscritor=" + subscritor + ", ramo=" + ramo + ", apolice=" + apolice + ", moeda=" + moeda + ", data=" + data + ", segurado=" + segurado + ", inicioVigencia=" + inicioVigencia + ", fimVigencia=" + fimVigencia + ", premioSeguro="
				+ premioSeguro + ", valorLmrLmg=" + valorLmrLmg + "]";
	}

}
