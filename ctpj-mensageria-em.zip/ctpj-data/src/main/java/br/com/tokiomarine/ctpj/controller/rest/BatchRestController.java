package br.com.tokiomarine.ctpj.controller.rest;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.tokiomarine.componente.utils.CelularUtil;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.controller.AbstractController;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.service.CalculoEndossoService;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.cotacao.service.EndossoService;
import br.com.tokiomarine.ctpj.cotacao.service.TransmissaoAcselService;
import br.com.tokiomarine.ctpj.cotacao.service.TransmissaoService;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CtpjToken;
import br.com.tokiomarine.ctpj.dto.Mensagem;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.Validacao;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.type.CTPJInfraCommons;
import br.com.tokiomarine.ctpj.jms.request.DataAlteracaoRequest;
import br.com.tokiomarine.ctpj.jms.response.CotacaoBatchResponse;
import br.com.tokiomarine.ctpj.jms.response.DataAlteracaoResponse;
import br.com.tokiomarine.ctpj.sct.form.EmailContatoSCT;
import br.com.tokiomarine.ctpj.sct.response.GeraApoliceCtpjResponse;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import br.com.tokiomarine.ctpj.sct.service.SCTService;
import br.com.tokiomarine.ctpj.security.CtpjAuthenticationToken;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationProvider;

@Controller
@RequestMapping(value="/rest/batch/")
public class BatchRestController extends AbstractController{
	
	private static Logger logger = Logger.getLogger(BatchRestController.class);
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private CalculoEndossoService calculoEndossoService;
	
	@Autowired
	private TransmissaoService transmissaoService;
	
	@Autowired
	private TransmissaoAcselService transmissaoAcselService;
	
	@Autowired
	private EndossoService endossoService;
	
	@Autowired
	private TokenAuthenticationProvider authenticationManager;
	
	@Autowired
	private SCTService sctService;

	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@PostMapping(value = "/criarCotacao")
	@ResponseBody
	public CotacaoBatchResponse criarCotacao(@RequestBody SolicitacaoCotacao solicitacaoCotacao) {
		CotacaoBatchResponse cotacaoBatchResponse = new CotacaoBatchResponse();
		try {
			cotacaoBatchResponse = cotacaoService.processaLoginBatch(solicitacaoCotacao);
		} catch (Exception e) {
			logger.error(String.format("Erro ao criar cotação: [%s]  ",solicitacaoCotacao.getNrSolctCotac()) + ExceptionUtils.getFullStackTrace(e));
			List<Mensagem> mensagens =  super.getMensagemErro(e);
			cotacaoBatchResponse.setMensagens(mensagens);
			
		}
		return cotacaoBatchResponse;
	}
	
	@GetMapping(value = "/calculo/{sequencialCotacaoProposta}")
	@ResponseBody
	public ResultadoREST<List<String>> calcularCotacao(@PathVariable BigInteger sequencialCotacaoProposta) {
		ResultadoREST<List<String>> result = new ResultadoREST<List<String>>();
		try {
			
			User user = new User();
			user.setCdUsuro(CTPJInfraCommons.USER_INTERFACE.number());
			user.setGrupoUsuario(GrupoUsuarioEnum.SUBSCRITOR_DEMAIS_RAMOS);
			result = calculoEndossoService.geraMensagemECalculaEndosso(sequencialCotacaoProposta,user);
			List<Validacao> listaValidacao = null;
			enviarContratacao(sequencialCotacaoProposta, result, user, listaValidacao);
		} catch (Exception e) {
			String msg = String.format("Erro ao calcular cotação: [%s]  ",sequencialCotacaoProposta) + ExceptionUtils.getFullStackTrace(e);
			result.setMensagem(msg);
			result.setSuccess(false);
		}
		return result;
	}

	@GetMapping(value = "/calculoApolice/{numeroApolice}/{numeroCotacao}")
	@ResponseBody
	public ResultadoREST<List<String>> calcularCotacaoRenovacao(@PathVariable Long numeroApolice, @PathVariable Long numeroCotacao, HttpServletRequest servletRequest) {
		ResultadoREST<List<String>> result = new ResultadoREST<List<String>>();
//		try {
//			ResponseEntity<GeraApoliceCtpjResponse> geraApoliceCtpjResponse = servicesController
//					.geraApoliceCtpjPlataformaRenovacaoSCT(180L,
//							numeroApolice, null, null);
//			Apolice apolice = apoliceRepository.findById(geraApoliceCtpjResponse.getBody().getIdMongodb());
//			SolicitacaoCotacao solicitacaoCotacao = sctService.getSolicitacaoCotacao(numeroCotacao);
//			solicitacaoCotacao.setIdMongodb(apolice.getId());
//
//			cotacaoBatchResponse = ctpjService.criarCotacaoCtpj(solicitacaoCotacao);
//
//			Cotacao cotacao  = cotacaoService.findCotacaoTela(sequencialCotacaoProposta);
//			SolicitacaoCotacao solicitacao = new SolicitacaoCotacao();
//			solicitacao.setSucesso(true);
//			CtpjToken ctpjToken = new CtpjToken();
//			ctpjToken.setSolicitacaoCotacao(solicitacao);
//			ctpjToken.setFake(true);
//			ctpjToken.setCdGrpEnum(GrupoUsuarioEnum.CORRETOR);
//			ctpjToken.setCdUsuro(Integer.valueOf(cotacao.getCodigoCorretorACSEL()));
//			CtpjAuthenticationToken token = new CtpjAuthenticationToken(ctpjToken);
//			token.setDetails(new WebAuthenticationDetails(servletRequest));
//			Authentication auth = authenticationManager.authenticate(token);
//			SecurityContextHolder.getContext().setAuthentication(auth);
//			HttpSession session = servletRequest.getSession(true);
//			session.setAttribute("SPRING_SECURITY_CONTEXT",SecurityContextHolder.getContext());
//			
//			List<ValidacaoLote> listaValidacaoCalculo = cotacaoService.validacaoBatch(cotacao);
//			
//			User user = new User();
//			user.setCdUsuro(CTPJInfraCommons.USER_INTERFACE.number());
//			user.setGrupoUsuario(GrupoUsuarioEnum.SUBSCRITOR_DEMAIS_RAMOS);
//			cotacao.getListItem().forEach(it -> {
//				it.setIdNecessidadeInspecao(SimNaoEnum.NAO);
//			});
//			try {
//				if(cotacao.getNumeroDDDCelularSegurado() != null
//						&& cotacao.getNumeroCelularSegurado() != null
//						&& !CelularUtil.valida(cotacao.getNumeroDDDCelularSegurado().intValue(),
//											  cotacao.getNumeroCelularSegurado().intValue(), Calendar.getInstance())) {
//					cotacao.setNumeroDDDCelularSegurado(11);
//					cotacao.setNumeroCelularSegurado(999999999L);
//				}
//			} catch(Exception e) {
//				cotacao.setNumeroDDDCelularSegurado(11);
//				cotacao.setNumeroCelularSegurado(999999999L);
//			}
//			
//			try {
//				if(cotacao.getNumeroDDDSegurado() != null
//						&& cotacao.getNumeroTelefoneSegurado() != null
//						&& cotacao.getNumeroDDDSegurado() == 0
//						&& cotacao.getNumeroTelefoneSegurado() == 0) {
//					cotacao.setNumeroDDDSegurado(11);
//					cotacao.setNumeroTelefoneSegurado(11111111L);
//				}
//			} catch(Exception e) {
//				cotacao.setNumeroDDDSegurado(11);
//				cotacao.setNumeroTelefoneSegurado(11111111L);
//			}
//			
//			if(listaValidacaoCalculo != null && listaValidacaoCalculo.isEmpty()) {
//				result = calculoCotacaoService.calcularCotacao(sequencialCotacaoProposta, user);
//			}
//
//		} catch (Exception e) {
//			String msg = String.format("Erro ao calcular cotação: [%s]  ",sequencialCotacaoProposta) + ExceptionUtils.getFullStackTrace(e);
//			result.setMensagem(msg);
//			result.setSuccess(false);
//		}
		return result;
	}

	private void enviarContratacao(BigInteger sequencialCotacaoProposta, ResultadoREST<List<String>> result, User user,
			List<Validacao> listaValidacao) throws ServiceException {
		Cotacao cotacao = cotacaoService.findById(sequencialCotacaoProposta);
		if(DestinoEmissaoEnum.ACX == cotacao.getIdDestinoEmissao()) {
			enviarContratacaoAcsel(sequencialCotacaoProposta, result, user, listaValidacao);
		}
		else {
			enviarContratacaoPlataforma(sequencialCotacaoProposta, result, user, listaValidacao);	
		}
	}

	private void enviarContratacaoPlataforma(BigInteger sequencialCotacaoProposta, ResultadoREST<List<String>> result,
			User user, List<Validacao> listaValidacao) throws ServiceException {
		if(result.isSuccess()){
			PropostaView proposta = transmissaoService.carregaDadosProposta(sequencialCotacaoProposta);
			listaValidacao = transmissaoService.enviar(proposta,user);
			
			if(listaValidacao != null && !listaValidacao.isEmpty()) {
				result.setListaValidacao(listaValidacao);
				result.setSuccess(false);
			}

			if(listaValidacao == null || listaValidacao.isEmpty()) {
				transmissaoService.enviaContratacao(proposta.getSequencialCotacaoProposta(),user);
			}
		}
		
		if(listaValidacao != null && !listaValidacao.isEmpty()){
			result.setSuccess(false);
			StringBuilder sb = new StringBuilder();
			for (Validacao validacao : listaValidacao) {
				sb.append(validacao.getDescricao());
			}
			result.setMensagem(sb.toString());
		}
	}
	
	private void enviarContratacaoAcsel(BigInteger sequencialCotacaoProposta, ResultadoREST<List<String>> result,
			User user, List<Validacao> listaValidacao) throws ServiceException {
		if(result.isSuccess()){
			PropostaView proposta = transmissaoAcselService.carregaDadosProposta(sequencialCotacaoProposta);
			listaValidacao = transmissaoAcselService.enviar(proposta,user);
			
			if(listaValidacao != null && !listaValidacao.isEmpty()) {
				result.setListaValidacao(listaValidacao);
				result.setSuccess(false);
			}

			if(listaValidacao == null || listaValidacao.isEmpty()) {
				transmissaoAcselService.enviaContratacao(proposta.getSequencialCotacaoProposta(),user);
			}
		}
		
		if(listaValidacao != null && !listaValidacao.isEmpty()){
			result.setSuccess(false);
			StringBuilder sb = new StringBuilder();
			for (Validacao validacao : listaValidacao) {
				sb.append(validacao.getDescricao());
			}
			result.setMensagem(sb.toString());
		}
	}
	
	/** 
	 * Calcula data de alteração - retroação de vigência
	 * Para processo Batch de Endosso de  Cancelamento de Por falta
	 * de pagamento
	 *
	 *@param apolice 
	 */
	@PostMapping(value = "/calculaDataAlteracao")
	@ResponseBody
	public DataAlteracaoResponse calcularCotacao(@RequestBody DataAlteracaoRequest dataAlteracaoRequest) {
		return endossoService.calculaDataAlteracaoBatch(dataAlteracaoRequest);
	}

}
