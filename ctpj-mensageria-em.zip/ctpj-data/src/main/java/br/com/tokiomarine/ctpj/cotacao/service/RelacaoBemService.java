package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemRelacaoBemView;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.RelacaoBemRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.integracao.service.CotacaoDolarService;
import br.com.tokiomarine.ctpj.mapper.ItemRelacaoBemMapper;

@Service
@Transactional(rollbackFor = Exception.class)
public class RelacaoBemService {

	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private RelacaoBemRepository relacaoBemRepository;
	
	@Autowired
	private CotacaoDolarService cotacaoDolarService;
	
	@Autowired
	private ItemRelacaoBemMapper mapper;
	
	public List<ItemRelacaoBem> listaItensRelacaoBem(BigInteger cotacao) {
		return relacaoBemRepository.buscaListaItemRelacaoBem(cotacao);
	}
	
	public ItemRelacaoBemView salvaItemRelacaoBem(ItemRelacaoBemView itemRBView) throws ServiceException{
		ItemCotacao itemCotacao;
		
		try {
			itemCotacao = cotacaoRepository.findItem(itemRBView.getItemCotacao());
		} catch (RepositoryException e) {
			throw new ServiceException(e);
		}
		
		ItemRelacaoBem itemRelacaoBem = mapper.toItemRelacaoBem(itemRBView, itemCotacao);		
		salvaItemRelacaoBem(itemRelacaoBem);		
		return mapper.toItemRelacaoBemView(itemRelacaoBem);
	}
	
	public List<ItemRelacaoBemView> salvaItemRelacaoBemParaTodosItensDaCotacao(ItemRelacaoBemView itemRBView, BigInteger seqCotacao) throws ServiceException {
		List<ItemCotacao> itensCotacao = cotacaoRepository.findItemByCotacao(seqCotacao);
		List<ItemRelacaoBem> itensRelacaoBem = mapper.toListItemRelacaoBem(itemRBView, itensCotacao, seqCotacao);

		for (ItemRelacaoBem itemRelacaoBem : itensRelacaoBem) {
			if(itemRelacaoBem.getItemCotacao().getCotacao().getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE || 
					(itemRelacaoBem.getItemCotacao().getCotacao().getIdTipoEndosso() != null
					&& Arrays.asList(1,6).contains(itemRelacaoBem.getItemCotacao().getIdTipoEndosso()))) {
				salvaItemRelacaoBem(itemRelacaoBem);
			}
		}

		return mapper.toListOfItemRelacaoBemView(itensRelacaoBem);
	}
	
	public void excluiItemRelacaoBem(BigInteger sequencialItemRelacaoBem) {
		relacaoBemRepository.excluiItemRelacaoBem(sequencialItemRelacaoBem);
	}
	
	private void salvaItemRelacaoBem(ItemRelacaoBem itemRelacaoBem) throws ServiceException {
		cotacaoDolarService.ajusteItemRelacaoBemImportanciaSeguradaMoedaEstrangeira(itemRelacaoBem);
		relacaoBemRepository.salvaItemRelacaoBem(itemRelacaoBem);
	}

	public List<ItemRelacaoBem> salvaItemRelacaoBem(BigInteger seqCotacao, List<ItemRelacaoBem> itens){
		relacaoBemRepository.excluiItemRelacaoPorCotacao(seqCotacao);
		if(!itens.isEmpty()) {
			relacaoBemRepository.salvaItemRelacaoBem(itens);
		}
		return itens;
	}
}
