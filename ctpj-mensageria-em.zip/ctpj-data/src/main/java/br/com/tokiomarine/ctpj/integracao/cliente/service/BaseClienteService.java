package br.com.tokiomarine.ctpj.integracao.cliente.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.cotacao.service.CotacaoLogService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.integracao.service.EndpointBuilderService;

public abstract class BaseClienteService {
	protected static Logger logger = LogManager.getLogger(BaseClienteService.class);
	
	@Autowired
	protected RestTemplate restTemplate;
			
	@Autowired
	protected CotacaoLogService cotacaoLogService;
	
	@Autowired
	protected EndpointBuilderService endpointBuilderService;
	
	protected ParametroGeralEnum getParametroGeral()
	{
		return ParametroGeralEnum.getParametroServicoCliente();
	}
	
	protected void tratarHttpServerErrorException(Cotacao cotacao,HttpServerErrorException se) throws ServiceException {
		HttpHeaders httpHeaders = se.getResponseHeaders();
		
		//loga o rootcauseerror
		String rootCauseError = obterInformacaoHeader(httpHeaders, "RootCauseErro");
		if(!StringUtils.isEmpty(rootCauseError)) {
			logger.error("Root Cause Error: ",se);
			logger.error(rootCauseError,se);
		}
		
		//loga a mensagem de erro sem acento
		String mensagemSemAcento = obterInformacaoHeader(httpHeaders, "MensagemErroSemAcento");
		if(!StringUtils.isEmpty(mensagemSemAcento)) {
			logger.error("Root Cause Error: ",se);
			logger.error(mensagemSemAcento,se);
		}
		
		//obtem a mensagem de erro para apresentar para o usuário
		String mensagemErro = obterInformacaoHeader(httpHeaders, "MensagemErro");
				
		if(StringUtils.isEmpty(mensagemErro)) {
			mensagemErro = "Ocorreu um erro ao salvar o cliente";
		}
		
		throw new ServiceException(mensagemErro.replace(".", "<br/><br/>"));
	}
	
	private String obterInformacaoHeader(HttpHeaders httpHeaders, String tipoInformacao) {
		
		List<String> headerInfoList = httpHeaders.get(tipoInformacao);
		StringBuilder sb = new StringBuilder();
		if(headerInfoList != null && !headerInfoList.isEmpty()){
			for (String s : headerInfoList){
				sb.append(s);
			}
		}
		return sb.toString();
	}
}
