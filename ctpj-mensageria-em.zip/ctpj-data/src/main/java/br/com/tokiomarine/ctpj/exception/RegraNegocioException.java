package br.com.tokiomarine.ctpj.exception;

import java.util.List;

import br.com.tokiomarine.ctpj.dto.ValidationMessage;
import br.com.tokiomarine.ctpj.dto.ValidationMessageList;

/**
 * Exceção que encapsula uma regra de negócio violada. Esta exceção contém uma lista de mensagens referentes às regras de negócio violadas
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class RegraNegocioException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	private ValidationMessageList messages = new ValidationMessageList();

	public RegraNegocioException() {
		super();		
	}
	
	public RegraNegocioException(ValidationMessageList messages) {
		this.messages = messages;
	}
	
	public RegraNegocioException(String message, Throwable cause) {
		super(message, cause);
	}

	public RegraNegocioException(String message) {
		super(message);
	}

	public RegraNegocioException(Throwable cause) {
		super(cause);
	}
	
	public void addMessage(ValidationMessage message){
		this.messages.add(message);
	}
	
	public void addAll(List<ValidationMessage> messages){
		this.messages.addAll(messages);
	}
	
	public ValidationMessageList getMessages(){		
		return this.messages;
	}

}
