package br.com.tokiomarine.ctpj.controller.rest;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.componente.utils.EmailUtil;
import br.com.tokiomarine.componente.utils.ExceptionUtil;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.controller.AbstractController;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosCrivo;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoService;
import br.com.tokiomarine.ctpj.crivo.response.CrivoResponse;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.dto.CorretorApoliceDigital;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.PerfilCalculoService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.infra.type.CTPJInfraCommons;
import br.com.tokiomarine.ctpj.integracao.service.ArquivoGntService;
import br.com.tokiomarine.ctpj.integracao.service.CrivoService;
import br.com.tokiomarine.ctpj.integracao.service.RecebimentoIntegracaoService;
import br.com.tokiomarine.ctpj.jms.request.CotacaoPropostaRequest;
import br.com.tokiomarine.ctpj.jms.response.VspGradeResponse;
import br.com.tokiomarine.ctpj.request.CotacaoCreditoRequest;
import br.com.tokiomarine.ctpj.request.CotacaoCrivoRequest;
import br.com.tokiomarine.ctpj.response.CotacaoCrivoResponse;

@Controller
@RequestMapping(value="/rest")
public class RestController extends AbstractController {
	
	private static Logger logger = LogManager.getLogger(RestController.class);
	
	@Autowired
	private CotacaoService cotacaoService;
	
	@Autowired
	private CrivoService crivoService;

	@Autowired
	private RecebimentoIntegracaoService recebimentoIntegracaoService;
	
	@Autowired
	private ProdutoRepository findProdutoCancelamentoFaltaPagamentobyProduto;
	
	@Autowired
	private PerfilCalculoService perfilCalculoService;

	@Autowired
	private ArquivoGntService arquivoGntService;

	@Autowired
	private ParametroGeralService parametroGeralService;

	private RestTemplate restTemplate = new RestTemplate();

	@LogPerformance
	@GetMapping(value = "/vspGrade/{sqCotacaoEscolhidaParaNovaVersao}/{codigoMatricula}")
	public ResponseEntity<VspGradeResponse> vspGrade(@PathVariable BigInteger sqCotacaoEscolhidaParaNovaVersao,@PathVariable BigInteger codigoMatricula) {
		VspGradeResponse response = new VspGradeResponse();
		try {
			User user = new User();
			user.setCdUsuro(codigoMatricula.intValue());
			user.setGrupoUsuario(GrupoUsuarioEnum.EMISSOR);
			BigInteger sqCotacaoNovaVersao = cotacaoService.geraNovaVersao(sqCotacaoEscolhidaParaNovaVersao,user,true);
			response.setSucesso(true);
			response.setSequencialCotacaoPropostaNovaVersao(sqCotacaoNovaVersao);
		} catch (Exception e) {
			logger.error("Erro ao solicitar nova versão",e);
			response.setSucesso(false);
			response.setMensagens(super.getMensagemErro(e));
		}
		return new ResponseEntity<VspGradeResponse>(response,HttpStatus.OK);
	}
	
	@LogPerformance
	@PostMapping(value = "/validaItemCrivo")
	@ResponseBody
	public ResponseEntity<CrivoResponse> validaItemCrivo(@RequestBody CotacaoPropostaRequest cotacaoPropostaRequest) {
		CrivoResponse response = new CrivoResponse();
		
		try {
			response = crivoService.validaCrivoItemContratacao(cotacaoPropostaRequest);
		} catch (Exception e) {
			logger.error("Erro ao validar Item Crivo Contratacao",e);
			response.setSucesso(false);
			response.setMensagens(super.getMensagemErro(e));
			
		}
		return new ResponseEntity<CrivoResponse>(response,HttpStatus.OK);
	}

	@LogPerformance
	@PostMapping(value = "/excluirRecebimento")
	@ResponseBody
	public ResponseEntity<?> excluiRecebimento(@RequestBody CotacaoCreditoRequest cotacaoCreditoRequest) {
		ResultadoREST<Object> resultado;
		try{
			User user = setUserInterface();
			resultado = recebimentoIntegracaoService.excluirRecebimento
					(cotacaoCreditoRequest.getNumeroCotacaoProposta(),user);
			return ResponseEntity.ok(resultado);
		} catch (Exception e) {
			logger.error("Erro ao executar exclui recebimento.", e);
			resultado = new ResultadoREST<>();
			resultado.setSuccess(false);
			return ResponseEntity.badRequest().body(resultado); 
		}
	}	
	
	@PostMapping(value = "/retornoCrivoGrade")
	@ResponseBody
	public ResponseEntity<CotacaoCrivoResponse> retornaResultadoCrivoParaGrade(@RequestBody CotacaoCrivoRequest cotacaoCrivoRequest) {
		CotacaoCrivoResponse cotacaoCrivoResponse = new CotacaoCrivoResponse(); 
		try {
			User user = setUserInterface();
			cotacaoCrivoResponse = crivoService.retornaResultadoItemCrivo(cotacaoCrivoRequest.getNumeroCotacaoProposta(),user);
		} catch (Exception e) {
			cotacaoCrivoResponse.setCodigoRetornoErro(99);
			cotacaoCrivoResponse.setMensagemErro(ExceptionUtil.getStackTrace(e));
			return new ResponseEntity<CotacaoCrivoResponse>(cotacaoCrivoResponse,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<CotacaoCrivoResponse>(cotacaoCrivoResponse,HttpStatus.OK);
	}
	
	@GetMapping(value = "/crivo/apolice/{apolice}/{produto}/{tipoPessoa}/{cpfCnpj}/{corretor}")
	public ResponseEntity<?> crivoApolice(
			@PathVariable BigInteger apolice, @PathVariable Integer produto, @PathVariable String tipoPessoa,
			@PathVariable String cpfCnpj, @PathVariable String corretor) {
		try {
			DadosCrivo dadosCrivo = crivoService.buscaDadosCrivo(apolice, 1851, TipoSeguradoEnum.getById(tipoPessoa), cpfCnpj, corretor);
			User user = new User();
			user.setCdUsuro(999999);
			user.setGrupoUsuario(GrupoUsuarioEnum.INTERFACE_RD);
			return ResponseEntity.ok(dadosCrivo);
		} catch (Exception e) {
			logger.error("Erro ao consultar o crivo ", e);
			return ResponseEntity.badRequest().build();
		}
	}

	@GetMapping(value = "/aaaa")
	public ResponseEntity<?> aaaaa() {
		try {
			cotacaoService.calcularParcelamentoRamo(BigInteger.valueOf(20733));
			return ResponseEntity.ok("ok");
		} catch (Exception e) {
			logger.error("Erro ao consultar o crivo ", e);
			return ResponseEntity.badRequest().build();
		}
	}
	
	@GetMapping(value = "/copiarPerfilCalculo/{perfilOrigem}/{perfilDestino}/{produto}")
	public ResponseEntity<?> copiarPerfilCalculo(
			@PathVariable Long perfilOrigem, @PathVariable Long perfilDestino, @PathVariable Integer produto) {
		try {
			perfilCalculoService.copiarPerfilCalculo(perfilOrigem, perfilDestino, produto);
			return (ResponseEntity<?>) ResponseEntity.ok("ok");
		} catch (Exception e) {
			logger.error("Erro ao copiar perfil de calculo "+perfilOrigem+" para "+perfilDestino+" :", e);
			return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/proposta/{numeroCotacao}/gnt")
	public ResponseEntity<?> enviarPropostaGNT(@PathVariable BigInteger numeroCotacao) {
		try {
			Cotacao cotacao = cotacaoService.findByNumeroCotacaoProposta(numeroCotacao);
			User user = new User();
			user.setCdUsuro(CTPJInfraCommons.USER_INTERFACE.number());
			user.setGrupoUsuario(GrupoUsuarioEnum.CORRETOR);
			List<String> emails = new ArrayList<>();
			String url = parametroGeralService.getUrlByNome(ParametroGeralEnum.getParametroConsultaApoliceDigital());
			CorretorApoliceDigital[] retornoApoliceDigital = restTemplate.getForObject(
					String.format(url, cotacao.getCodigoCorretorACSEL(), cotacao.getCodigoProduto()),
					CorretorApoliceDigital[].class);

			if(retornoApoliceDigital != null && retornoApoliceDigital.length > 0) {
				for(CorretorApoliceDigital c: retornoApoliceDigital) {
					emails.add(c.getEmail());
				}
			}

			return arquivoGntService.enviarMailArquivoPropostaBoleto(cotacao.getSequencialCotacaoProposta(),
					cotacao.getNumeroCotacaoProposta(), true, false, emails, user);
		} catch (Exception e) {
			logger.error("Erro ao enviar e-mail ", e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	private User setUserInterface() {
		User user = new User();
		user.setCdUsuro(999999);
		user.setGrupoUsuario(GrupoUsuarioEnum.INTERFACE_RD);
		return user;
	}
	
}