package br.com.tokiomarine.ctpj.infra.mongo.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.infra.domain.CapitalSocial;
import br.com.tokiomarine.ctpj.infra.domain.FaturamentoPresumido;
import br.com.tokiomarine.ctpj.infra.domain.PaisOrigem;
import br.com.tokiomarine.ctpj.infra.domain.Patrimonio;
import br.com.tokiomarine.ctpj.infra.domain.Profissao;
import br.com.tokiomarine.ctpj.infra.domain.Renda;

@Repository
public class PldRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	public List<CapitalSocial> listarCapitalSocial() {
		return mongoTemplate.find(
				query(
						where("inativo").is(false))
						.with(new Sort(Direction.ASC,"faixa")), 
				CapitalSocial.class);
	}

	public List<Profissao> listarProfissao() {
		return mongoTemplate.find(
				query(
						where("inativo").is(false))
						.with(new Sort(Direction.ASC,"titulo")), 
						Profissao.class);
	}

	public List<PaisOrigem> listarPais() {
		return mongoTemplate.find(
				query(
						where("inativo").is(false))
						.with(new Sort(Direction.ASC,"nome")), 
						PaisOrigem.class);
	}

	public List<FaturamentoPresumido> listarFaturamentoPresumido() {
		return mongoTemplate.find(
				query(
						where("inativo").is(false))
						.with(new Sort(Direction.ASC,"faixa")), 
						FaturamentoPresumido.class);
	}

	public List<Patrimonio> listarPatrimonio() {
		return mongoTemplate.find(
				query(
						where("inativo").is(false))
						.with(new Sort(Direction.ASC,"descricao")), 
						Patrimonio.class);
	}

	public List<Renda> listarRenda() {
		return mongoTemplate.find(
				query(
						where("inativo").is(false))
						.with(new Sort(Direction.ASC,"descricao")), 
						Renda.class);
	}
	
	public CapitalSocial findCapitalSocial(BigInteger faixa) {
		return mongoTemplate.findOne(
				query(
						where("inativo").is(false)
						.and("faixa").is(faixa.longValue())), 
				CapitalSocial.class);
	}

	public Profissao findProfissao(BigInteger codigo) {
		return mongoTemplate.findOne(
				query(
						where("inativo").is(false)
						.and("codigo").is(codigo.intValue())), 
						Profissao.class);
	}

	public PaisOrigem findPais(BigInteger codigo) {
		return mongoTemplate.findOne(
				query(
						where("inativo").is(false)
						.and("codigo").is(codigo.longValue())), 
						PaisOrigem.class);
	}

	public FaturamentoPresumido findFaturamentoPresumido(BigInteger faixa) {
		return mongoTemplate.findOne(
				query(
						where("faixa").is(faixa.longValue())), 
						FaturamentoPresumido.class);
	}

	public Patrimonio findPatrimonio(BigInteger codigo) {
		return mongoTemplate.findOne(
				query(
						where("inativo").is(false)
						.and("codigo").is(codigo.intValue())), 
						Patrimonio.class);
	}

	public Renda findRenda(BigInteger codigo) {
		return mongoTemplate.findOne(
				query(
						where("inativo").is(false)
						.and("codigo").is(codigo.intValue())), 
						Renda.class);
	}
}