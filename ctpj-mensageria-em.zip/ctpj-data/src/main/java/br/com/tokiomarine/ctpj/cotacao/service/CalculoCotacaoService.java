package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.blaze.dto.CotacaoBlaze;
import br.com.tokiomarine.ctpj.blaze.dto.ErroBlaze;
import br.com.tokiomarine.ctpj.blaze.mapper.BlazeParaCotacaoMapper;
import br.com.tokiomarine.ctpj.blaze.mapper.CotacaoParaBlazeMapper;
import br.com.tokiomarine.ctpj.cotacao.dto.BloqueioAlcadaView;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosCrivo;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemRamoEmissaoDTO;
import br.com.tokiomarine.ctpj.cotacao.repository.BloqueioAlcadaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemRamoRepository;
import br.com.tokiomarine.ctpj.cotacao.validation.LmrMinimoValidator;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamo;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.dto.RetornoIntegracao;
import br.com.tokiomarine.ctpj.enums.CodigoSituacaoEnum;
import br.com.tokiomarine.ctpj.enums.ControleCalculoEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoOrigemEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.enums.TipoValorRiscoDistribuidoEnum;
import br.com.tokiomarine.ctpj.exception.CalculoException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoSusep;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoCoberturaEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CoberturaAtividadeComplementoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.service.ProdutoService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.service.CotacaoDolarService;
import br.com.tokiomarine.ctpj.integracao.service.CrivoService;
import br.com.tokiomarine.ctpj.integracao.service.KmeService;
import br.com.tokiomarine.ctpj.sct.request.InsereHistoricoInterfaceSCTRequest;
import br.com.tokiomarine.ctpj.sct.service.SCTService;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;

/**
 * @author E107092
 *
 */
@Service
@Transactional(rollbackFor = {Exception.class})
public class CalculoCotacaoService {

	@Autowired
	protected RestTemplate restTemplate;

	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private ItemRamoRepository itemRamoRepository;

	@Autowired
	private BloqueioAlcadaRepository bloqueioAlcadaRepository;

	@Autowired
	private OpcaoParcelamentoService opcaoParcelamentoService;

	@Autowired
	private CondicaoContratualService condicaoContratualService;
	
	@Autowired
	private ServicoCotacaoService servicoCotacaoService;

	@Autowired
	private CotacaoDolarService cotacaoDolarService;

	@Autowired
	private ClausulaService clausulaService;

	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;
	
	@Autowired 
	private MemoriaCalculoService memoriaCalculoService;

	@Autowired
	private SCTService sctService;

	@Autowired
	private KmeService kmeService;
	
	@Autowired
	private CrivoService crivoService;

	@Autowired
	private LmrMinimoValidator lmrMinimoValidator;
	
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired
	private ProdutoService produtoService;
	
	@Autowired
	private CoberturaAtividadeComplementoRepository coberturaAtividadeComplementoRepository;

	private static Logger logger = LogManager.getLogger(CalculoCotacaoService.class);

	@LogPerformance
	public ResultadoREST<List<String>> calcularCotacao(BigInteger sequencialCotacaoProposta,User user) {
		logger.info("Início do cálculo da cotacao " + sequencialCotacaoProposta);
		ResultadoREST<List<String>> resultado = new ResultadoREST<>();
		try {
			
			SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
			InetSocketAddress address = new InetSocketAddress("srvwcg005.tokiomarine.com.br", 8080);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, address);
			factory.setProxy(proxy);
			restTemplate.setRequestFactory(factory);
			
			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroBlazeCalculo();
			if (urlEnum == null) {
				throw new ServiceException("Erro ao buscar URL referente ao Blaze de cálculo.");
			}

			String url = parametroGeralService.getUrlByNome(urlEnum);
			if (StringUtils.isEmpty(url)) { 
				throw new ServiceException("URL de acesso ao blaze de cálculo nula ou vazia."); 
			}

			Cotacao cotacao = cotacaoRepository.findCompleta(sequencialCotacaoProposta);
			logger.info("Começo dos deletes do cálculo da cotacao " + sequencialCotacaoProposta);

			List<ItemApolice> listItemApolice = new ArrayList<>();

			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				if(!StringUtils.isBlank(itemCotacao.getIdMongoRenovacao())) {
					Optional<ItemApolice> retorno = apoliceRepository.findItemApoliceById(itemCotacao.getIdMongoRenovacao());
					if(retorno.isPresent()) {
						listItemApolice.add(retorno.get());
					}
				}
			}

			ProdutoControle produtoControle = produtoService.findProdutoControleByCodigoAndVigencia(
					cotacao.getCodigoProduto(),
					cotacao.getDataCotacao());

			Apolice apolice = null;
			if(produtoControle.getBatente() == SimNaoEnum.SIM && cotacao.getIdMongoEndosso() != null) {
				apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
			}

			/**
			 * Se Cotação em Dolar
			 * Busca o Coeficiente para converter o retorno
			 * do Blaze de Real para Dolar
			 */
			BigDecimal coeficienteConversaoMoeda = null;
			if (cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA) {
				coeficienteConversaoMoeda = cotacao.getCoeficienteConversaoMoeda();
			}

			calcularItemPercentualRelacaoIsVr(cotacao);

			List<BloqueioAlcadaView> listBloqueioAlcadaAutorizado = new ArrayList<>();
			for(BloqueioAlcada bloqueio: cotacao.getListBloqueioAlcada()) {
				listBloqueioAlcadaAutorizado.add(new BloqueioAlcadaView(
						bloqueio.getDescricaoRestricao(),
						bloqueio.getCodigoNivelAutorizacao(),
						bloqueio.getIdAutorizacao(),
						bloqueio.getDataAutorizacao(),
						bloqueio.getCodigoFuncionarioAutorizacao()));
			}

			itemCoberturaRepository.deleteDescontoAgravacao(cotacao);
			bloqueioAlcadaRepository.delete(cotacao);
			
			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				itemRamoRepository.deleteItemsRamoEmissao(itemCotacao);
			}

			for(ItemCotacao itemCotacao: cotacao.getListItem()) {
				itemRamoRepository.deleteItemsRamo(itemCotacao);
			}
			
			logger.info("Fim dos deletes do cálculo da cotacao " + sequencialCotacaoProposta);
			
			CotacaoParaBlazeMapper cotacaoToBlazeMapper = new CotacaoParaBlazeMapper();
			BlazeParaCotacaoMapper blazeToCotacaoMapper = new BlazeParaCotacaoMapper();

			CotacaoBlaze cotacaoBlaze = cotacaoToBlazeMapper.createCotacaoBlaze(cotacao,apolice,listItemApolice,user);

			logger.info(String.format("Chamando o blaze de cálculo para a cotacao [%s] com a url [%s]", cotacao.getSequencialCotacaoProposta(), url));
			ResponseEntity<CotacaoBlaze> response = restTemplate.getForEntity("https://run.mocky.io/v3/bc9d017b-f6d0-4613-ac02-604085135b76",CotacaoBlaze.class);

			CotacaoBlaze cotacaoBlazeResponse = response.getBody();

			// O último campo null corresponde aos dados da apólice. Essas informações serão necessárias somente para endosso.
			blazeToCotacaoMapper.convertBlazeToCotacao(cotacao,cotacaoBlazeResponse,user,coeficienteConversaoMoeda, null);
			memoriaCalculoService.salvaMemoriaCalculoDe(cotacao);
			
			if (user.getGrupoUsuario() != GrupoUsuarioEnum.CORRETOR) {
				resultado.setRetornoObj(cotacaoBlaze.getListErro().stream().map(ErroBlaze::getDescricaoErro).collect(Collectors.toList()));
			}

			if (cotacaoBlaze.getListErro() != null && !cotacaoBlaze.getListErro().isEmpty()) {
				resultado.setMensagem("Erro ao calcular cotação/proposta! Entre em Contato com a Seguradora informando este problema!");
				resultado.setSuccess(false);
				return resultado;
			}

			List<String> validacaoPosCalculo = new ArrayList<>(); 
					
			validacaoPosCalculo = atualizarItemRamoCobertura(cotacao,user);
			validacaoPosCalculo.addAll(validaPremioLiquido(cotacao));
			if(!validacaoPosCalculo.isEmpty()) {
				resultado.setRetornoObj(validacaoPosCalculo);
				return resultado;
			}
			
			String msgLmrMinimoValidator = lmrMinimoValidator.validar(cotacao);
			if (msgLmrMinimoValidator != null){
				validacaoPosCalculo.add(msgLmrMinimoValidator);
				resultado.setRetornoObj(validacaoPosCalculo);
				return resultado;
			}

			if(cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
				validacaoPosCalculo.addAll(validaDistribuicaoVRLucrosCessantes(cotacao));
				if (!Arrays.asList(1852,1850,1851).contains(cotacao.getCodigoProduto())) {
					validacaoPosCalculo.addAll(validaDistribuicaoVRLMI(cotacao));
				}
			}

			validacaoPosCalculo.addAll(validaNumeracao(cotacao));

			if(!validacaoPosCalculo.isEmpty()) {
				resultado.setRetornoObj(validacaoPosCalculo);
				return resultado;
			}
			
			if (cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA) {
				cotacaoDolarService.ajusteCotacaoCoeficienteMoedaEstrangeriaRetornoBlaze(cotacao,coeficienteConversaoMoeda);
				cotacaoDolarService.validaValoresRetornoBlaze(cotacao,coeficienteConversaoMoeda);
			}
			
			/**
			 * Inicio da chamado ao Blaze de Aceitação
			 */
			RetornoIntegracao retornoCrivo = crivoService.validaCrivoItem(cotacao, user);

			if(retornoCrivo.getMensagens() != null && !retornoCrivo.getMensagens().isEmpty()) {
				List<String> mensagensCrivo = retornoCrivo.getMensagens()
						.stream()
						.map( it -> it.getItem() == null ? it.getDescricao() : it.getItem()  + " - " + it.getDescricao())
						.collect(Collectors.toList());
				if(resultado.getRetornoObj() == null) {
					resultado.setRetornoObj(mensagensCrivo);
				} else {
					resultado.getRetornoObj().addAll(mensagensCrivo);
				}
				return resultado;
			}
			
			if(resultado.getRetornoObj() != null && !resultado.getRetornoObj().isEmpty()) {
				resultado.setMensagem("Erro na aceitação cotação/proposta! Entre em Contato com a Seguradora informando este problema!");
				resultado.setSuccess(false);
			}

			ParametroGeralEnum urlAceitacaoEnum = ParametroGeralEnum.getParametroBlazeAceitacao();
			if (urlAceitacaoEnum == null) {
				throw new ServiceException("Erro ao buscar URL referente ao Blaze de aceitação.");
			}

			String urlAceitacao = parametroGeralService.getUrlByNome(urlAceitacaoEnum);
			if (StringUtils.isEmpty(urlAceitacao)) {
				throw new ServiceException("URL de acesso ao blaze de aceitação nula ou vazia.");
			}

			CotacaoBlaze cotacaoBlazeAceitacao = cotacaoToBlazeMapper.createCotacaoBlaze(cotacao,null,Collections.emptyList(),user);

			ResponseEntity<CotacaoBlaze> responseAceitacao = 
					restTemplate.getForEntity("https://run.mocky.io/v3/bc9d017b-f6d0-4613-ac02-604085135b76",CotacaoBlaze.class);

			CotacaoBlaze cotacaoBlazeAceitacaoResponse = responseAceitacao.getBody();

			if(user.getGrupoUsuario() != GrupoUsuarioEnum.CORRETOR) {
				resultado.setRetornoObj(cotacaoBlazeAceitacaoResponse.getListErro()
						.stream()
						.map(ErroBlaze::getDescricaoErro)
						.collect(Collectors.toList()));
			}

			if(cotacaoBlazeAceitacaoResponse.getListErro() != null && !cotacaoBlazeAceitacaoResponse.getListErro().isEmpty()) {
				resultado.setMensagem("Erro na aceitação cotação/proposta! Entre em Contato com a Seguradora informando este problema!");
				resultado.setSuccess(false);
				return resultado;
			}
			
			blazeToCotacaoMapper.convertBlazeToCotacaoAceitacao(cotacao,cotacaoBlazeAceitacaoResponse,listBloqueioAlcadaAutorizado,user);
			
			/**
			 * Fim da chamado ao Blaze de Aceitação
			 */
			if(SecurityUtils.isCorretor() && !cotacao.getCodigoSituacao().equals(CodigoSituacaoEnum.CALCULADA_318.getSituacao().intValue())) {
				InsereHistoricoInterfaceSCTRequest request = new InsereHistoricoInterfaceSCTRequest();
				request.setCdUsuroAtulz(user.getCdUsuro().longValue());
				request.setNrSolctCotac(cotacao.getNumeroCotacaoProposta());
				request.setCdSituc(CodigoSituacaoEnum.CALCULADA_318.getSituacao());
				request.setCdMotv(null);
				request.setDsCmploMotv(null);

				//Chama o serviço do SCT (Calculado)
				sctService.insereHistoricoInterfaceSCT(cotacao, user, request);
			}

			if(!SecurityUtils.isCorretor() ||
					(SecurityUtils.isCorretor() && (cotacao.getListBloqueioAlcada() == null || cotacao.getListBloqueioAlcada().isEmpty()))) {
				sctService.atualizaPremio(cotacao, user);
			}
			kmeService.atualizaConsultaIntegradaCalculado(cotacao);
			clausulaService.salvaOuAtualizaClausulasAutomaticas(cotacao, user);
			
			cotacao.setIdControleCalculo(ControleCalculoEnum.COTACAO_CALCULADO);
			cotacao.setDataCalculo(new Date());
			cotacao.setCodigoSituacao(CodigoSituacaoEnum.CALCULADA_318.getSituacao().intValue());
			cotacao.setNomeSituacao(CodigoSituacaoEnum.CALCULADA_318.getDescricao());
			
			if(cotacao.getIdTipoOrigem() == null) {
				if(SecurityUtils.isCorretor()) {
					cotacao.setIdTipoOrigem(TipoOrigemEnum.CORRETOR);
				} else {
					cotacao.setIdTipoOrigem(TipoOrigemEnum.INTERNO);
				}
			}

			/**
			 * Sempre zera o link da docstore dos prints da Cotação
			 */
			cotacao.setIdDocStoreDeclaracao(null);
			cotacao.setIdDocStoreCotacao(null);
			cotacao.setIdDocStoreProposta(null);
			
			appendTextoComplementarCoberturaAtividade(cotacao);

			//talvez atualizar prêmio
			cotacaoRepository.update(cotacao);
			condicaoContratualService.gerarCondicaoContratualApolice(cotacao,user);
			opcaoParcelamentoService.gerarOpcaoParcelamento(cotacao,user);
			servicoCotacaoService.gerarServicoCotacao(cotacao,user);

			resultado.setMensagem("Sucesso");
			resultado.setSuccess(true);
			
			if(cotacao.getIdTipoOrigem() == TipoOrigemEnum.WS) {
				resultado.setValorPremio(cotacao.getValorPremioContaCorrente());
				try {
					if(cotacao.getIdTipoPessoa() == TipoSeguradoEnum.JURIDICA) {
						DadosCrivo retornoControladora = crivoService.buscaDadosCrivo(
								cotacao.getNumeroCotacaoProposta(), cotacao.getCodigoProduto(),
								cotacao.getIdTipoPessoa(), String.valueOf(cotacao.getNumeroCNPJCPFSegurado()),
								cotacao.getCodigoCorretorACSEL());
						cotacao.setCodigoAtividadePrincipal(retornoControladora.getIdAtividadePrincipal());
						cotacao.setDescricaoAtividadePrincipal(retornoControladora.getAtividade());
					} else {
						cotacao.setCodigoAtividadePrincipal(null);
						cotacao.setDescricaoAtividadePrincipal(null);
					}
				} catch (Exception e) {
					logger.error("Falha na consulta a controladora ", e);
				}
			}

		} catch (RestClientException e) {
			logger.error("Erro ao fazer a conexão com o Blaze",e);
			resultado.setThrowable(e);
			resultado.setMensagem("Erro ao calcular cotação/proposta!");
			resultado.setSuccess(false);
			throw new CalculoException(e.getMessage() + " " + sequencialCotacaoProposta,e,resultado);
		} catch (Exception e) {
			logger.error("Erro ao calcular cotação/proposta",e);
			resultado.setThrowable(e);
			resultado.setMensagem("Erro ao calcular cotação/proposta!");
			resultado.setSuccess(false);
			throw new CalculoException(e.getMessage() + " " + sequencialCotacaoProposta,e,resultado);
		}
		return resultado;
	}

	private List<String> validaNumeracao(Cotacao cotacao) {

		int tamanho = cotacao.getListItem().size();

		Optional<BigInteger> optionalUltimoItem = cotacao
				.getListItem()
				.stream()
				.map(ItemCotacao::getNumeroItem)
				.max(Comparator.naturalOrder());
				
		int ultimoItem = optionalUltimoItem.isPresent() ? optionalUltimoItem.get().intValue() : 0;
		
		if(ultimoItem > tamanho) {
			return Collections.singletonList("Não é possível contratar esta proposta com essa numeração. "
					+ "Por favor, acesse a renumeração de itens e renumere para que não fiquem espaços entre os números");
		}
		
		return Collections.emptyList();
		
	}

	public void calcularItemPercentualRelacaoIsVr(Cotacao cotacao) throws ServiceException {
		try {
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				Optional<ItemCobertura> oic = itemCotacao.getListItemCobertura().stream().filter(ic -> ic.getIdTipoCobertura().equals(1)).findFirst();
				if (oic.isPresent()) {
					BigDecimal isVR = BigDecimal.ZERO; 
					BigDecimal resultado = BigDecimal.ZERO;
					if (cotacao.getIdLmiUnico().equals(SimNaoEnum.NAO)){
							isVR = BigDecimalUtil.truncComDecimais(5,BigDecimalUtil.truncComDecimais(5,oic.get().getValorImportanciaSegurada()
									.multiply(BigDecimalUtil.truncComDecimais(5,new BigDecimal("100")),MathContext.DECIMAL128)));
							resultado = BigDecimalUtil.truncComDecimais(5,isVR.divide(BigDecimalUtil.truncComDecimais(5,itemCotacao.getValorRiscoBemCalculado()),MathContext.DECIMAL128));
					}else{
						isVR = BigDecimalUtil.truncComDecimais(5,BigDecimalUtil.truncComDecimais(5,oic.get().getValorSublimite()
								.multiply(BigDecimalUtil.truncComDecimais(5,new BigDecimal("100")),MathContext.DECIMAL128)));
						resultado = BigDecimalUtil.truncComDecimais(5,isVR.divide(BigDecimalUtil.truncComDecimais(5,itemCotacao.getValorRiscoBemCalculado()),MathContext.DECIMAL128));
					}
					itemCotacao.setPercentualRelacaoImportanciaSeguradaValorRisco(resultado);
				}
			}
		} catch (Exception e) {
			logger.error("Erro ao atualizar % IS VR",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public List<String> atualizarItemRamoCobertura(Cotacao cotacao,User user) throws ServiceException {
		List<String> listaValidacao = new ArrayList<>();
		try {
			Set<ItemRamoEmissaoDTO> ramos = cotacao.getListItem().stream()
					.flatMap(item -> item.getListItemCobertura().stream())
					.map(cobertura -> new ItemRamoEmissaoDTO(cobertura.getCodigoGrupoRamoEmissao(), cobertura.getCodigoRamoCoberturaEmissao(), null, null))
					.collect(Collectors.toSet());
			Map<ItemRamoEmissaoDTO, ProdutoSusep> itemRamoProdutoSusep = new HashMap<>();
			for(ItemRamoEmissaoDTO ramo: ramos) {
				ProdutoSusep produtoSusep = produtoService.findProdutoSusepByProduto(cotacao.getCodigoProduto(),
						ramo.getCodigoGrupoRamo(),
						ramo.getCodigoRamo(),
						cotacao.getDataInicioVigencia());
				itemRamoProdutoSusep.put(ramo, produtoSusep);
			}
			
			BigDecimal valorPremioTotal = null;
			BigDecimal valorPremioVigenciaTotal = null;
			BigDecimal valorPremioReferencialTotal = null;
			for (ItemCotacao itemCotacao : cotacao.getListItem()) {
				List<ItemRamoEmissaoDTO> listItemRamoEmissao = new ArrayList<>();
				for (ItemRamoEmissao itemRamoEmissao : itemCotacao.getListItemRamoEmissao()) {
					listItemRamoEmissao.add(new ItemRamoEmissaoDTO(itemRamoEmissao.getCodigoGrupoRamo(),itemRamoEmissao.getCodigoRamo(),itemRamoEmissao.getProcessoSusep(),itemRamoEmissao.getComplementoLmr()));
				}

				for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
					atualizarDescricaoFranquia(cotacao.getCodigoProduto(),itemCotacao.getCodigoRubrica(),itemCobertura);
					if (itemCobertura.getDescricaoFranquia()==null || itemCobertura.getDescricaoFranquia().isEmpty()){
						listaValidacao.add("Item " + itemCotacao.getNumeroItem().intValue() + 
								" - Não foi possível calcular a franquia de "+itemCobertura.getDescricaoCobertura()+".");
					}

					gerarItemRamoContabil(cotacao,itemCotacao.getListItemRamo(),itemCobertura,user);
					// TODO id_exclusao_endosso criar lógica para popular esse campo
					// salvar processo susep no item ramo emissao
					gerarItemRamoEmissao(cotacao,listItemRamoEmissao,itemCotacao.getListItemRamoEmissao(),itemCobertura,user,itemRamoProdutoSusep);
					valorPremioTotal = BigDecimalUtil.safeAdd(valorPremioTotal,itemCobertura.getValorPremio());
					valorPremioVigenciaTotal = BigDecimalUtil.safeAdd(valorPremioVigenciaTotal,itemCobertura.getValorPremioVigencia());
					valorPremioReferencialTotal = BigDecimalUtil.safeAdd(valorPremioReferencialTotal,itemCobertura.getValorPremioReferencial());
					for (ItemEquipamentoFranquia equipamentoFranquia : itemCobertura.getListItemEquipamentoFranquia()){
						equipamentoFranquia.setDescricaoFranquia(equipamentoFranquia.getIdFormaFranquia().getDescricaoFranquia(
								equipamentoFranquia.getNumeroDiasFranquia(),
								equipamentoFranquia.getNumeroHorasFranquia(),
								equipamentoFranquia.getTaxaFranquia(),
								equipamentoFranquia.getValorFranquia(),
								equipamentoFranquia.getValorFranquiaMinimo(),
								equipamentoFranquia.getValorFranquiaMaximo(),
								equipamentoFranquia.getTaxaImportanciaSegurada(),
								equipamentoFranquia.getTaxaImportanciaSeguradaMinimo(),
								equipamentoFranquia.getTaxaImportanciaSeguradaMaximo(),
								itemCobertura.getValorImportanciaSegurada(),
								false));
						if (equipamentoFranquia.getDescricaoFranquia()==null || equipamentoFranquia.getDescricaoFranquia().isEmpty()){
							listaValidacao.add("Item " + itemCotacao.getNumeroItem().intValue() + 
									" - Não foi possível calcular a franquia de "+itemCobertura.getDescricaoCobertura()+", equipamento "+equipamentoFranquia.getDescricaoEquipamento()+".");
						}
					}
				}
			}

			cotacao.setValorPremioLiquido(valorPremioTotal);
			calcularDescontoComercialPorRamoEmissao(cotacao);
			calcularDescontoComercialPorCotacao(cotacao,valorPremioTotal,valorPremioVigenciaTotal,valorPremioReferencialTotal);
			return listaValidacao;
		} catch (Exception e) {
			logger.error("Erro ao gerar cotação de apólice",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	/**
	 * Valida a soma da Distribuição dos VR do tipo LC 
	 * de acordo com o valor do risco das Cobertura LC == 'S'. <br/>
	 * A soma não pode ser maior que o valor LC daquele item.</br></br>
	 * 
	 * Se o item não possui itemRamoEmissao com valor LC,
	 * é informado que não é possível preencher um ItemDistribuicao do tipo LC
	 * 
	 * @see TipoValorRiscoDistribuidoEnum
	 * @param cotacao
	 */
	private List<String> validaDistribuicaoVRLucrosCessantes(Cotacao cotacao) {
		List<String> listaValidacao = new ArrayList<>();
		for (ItemCotacao itemCotacao : cotacao.getListItem()) {
			boolean hasItemLC = false;
			if(!itemCotacao.getListItemDistribuicao().isEmpty()) {
				BigDecimal soma = BigDecimal.ZERO; 
				for(ItemDistribuicao itemDistribuicao: itemCotacao.getListItemDistribuicao()) {
					if(itemDistribuicao.getIdTipoValorRisco() == TipoValorRiscoDistribuidoEnum.LUCROS_CESSANTES) {
						if(cotacao.getCodigoMoeda() == MoedaEnum.REAL) {
							hasItemLC = true;
							soma = soma.add(itemDistribuicao.getValorRiscoBem());
						} else if(cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA) {
							hasItemLC = true;
							soma = soma.add(itemDistribuicao.getValorRiscoBemMoedaEstrangeira());
						}
					}
				}

				if(itemCotacao.getListItemCobertura().stream().filter(it -> it.getIdLucrosCessantes() == SimNaoEnum.SIM).count() == 0 && hasItemLC) {
					listaValidacao.add("Item " + itemCotacao.getNumeroItem().intValue() + 
							" - Não é possível preencher um VR do tipo Lucros Cessantes para este item. Favor remover.");
				} else {
					BigDecimal somaCobertura = BigDecimal.ZERO;
					if(cotacao.getCodigoMoeda() == MoedaEnum.REAL) {
						somaCobertura = itemCotacao.getListItemCobertura().stream()
								.filter(it -> it.getIdLucrosCessantes() == SimNaoEnum.SIM && it.getValorRiscoBem() != null)
								.map(ItemCobertura::getValorRiscoBem)
								.reduce(BigDecimal.ZERO,BigDecimal::add);
					} else if(cotacao.getCodigoMoeda() == MoedaEnum.DOLAR_VENDA) {
						somaCobertura = itemCotacao.getListItemCobertura().stream()
								.filter(it -> it.getIdLucrosCessantes() == SimNaoEnum.SIM && it.getValorRiscoBemMoedaEstrangeira() != null)
								.map(ItemCobertura::getValorRiscoBemMoedaEstrangeira)
								.reduce(BigDecimal.ZERO,BigDecimal::add);
					}

					boolean isValido = BigDecimalUtil.menorIgual(soma,somaCobertura);
					if(!isValido) {
						listaValidacao.add("Item " + itemCotacao.getNumeroItem().intValue() + 
								" - A soma da distribuição dos VR deve ser menor ou igual a " + BigDecimalUtil.formatBigDecimal(somaCobertura,2));
					}
				}
			}
		}
		return listaValidacao;
	}

	private List<String> validaDistribuicaoVRLMI(Cotacao cotacao) {
		List<String> listaValidacao = new ArrayList<>();
		boolean validaVR = false;
		if(cotacao.getListItem().stream()
				.filter(item -> item.getIdExclusaoEndosso() != SimNaoEnum.SIM)
				.flatMap(item -> item.getListItemDistribuicao().stream())
				.count() > 0) {
			validaVR = true;
		}

		if(validaVR) {
			for(ItemCotacao item: cotacao.getListItem()) {
				if(item.getListItemDistribuicao().isEmpty()) {
					listaValidacao.add("Item " + item.getNumeroItem().intValue() + " - É necessário incluir a distribuição de VR para este local de risco");
				}
			}			
		}
		return listaValidacao;
	}

	private void calcularDescontoComercialPorCotacao(Cotacao cotacao,BigDecimal valorPremioTotal,BigDecimal valorPremioVigenciaTotal,BigDecimal valorPremioReferencialTotal) throws ServiceException {
		try {
			BigDecimal percentualDescontoComercial = calcularPercentualDescontoComercial(cotacao.getIdTipoPedidoCotacao(),valorPremioTotal,valorPremioVigenciaTotal,valorPremioReferencialTotal);
			cotacao.setPercentualDescontoComercial(percentualDescontoComercial);
		} catch (Exception e) {
			logger.error("Erro ao calcular e atualizar percentual de desconto comercial.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	private void calcularDescontoComercialPorRamoEmissao(Cotacao cotacao) throws ServiceException {
		BigDecimal valorPremioTotal = null;
		BigDecimal valorPremioVigenciaTotal = null;
		BigDecimal valorPremioReferencialTotal = null;
		try {
			List<ItemRamoEmissao> listItemRamoEmissao = cotacao.getListItem().stream().flatMap(item -> item.getListItemRamoEmissao().stream()).collect(Collectors.toList());
			for (ComissaoCotacao comissaoCotacao : cotacao.getListComissaoCotacao()) {
				List<ItemRamoEmissao> listItemRamoEmissaoComissao = listItemRamoEmissao.stream().filter(it -> it.getCodigoGrupoRamo().equals(comissaoCotacao.getCodigoGrupoRamo()) && it.getCodigoRamo().equals(comissaoCotacao.getCodigoRamo())).collect(Collectors.toList());
				for (ItemRamoEmissao itemRamoEmissao : listItemRamoEmissaoComissao) {
					valorPremioTotal = BigDecimalUtil.safeAdd(valorPremioTotal,itemRamoEmissao.getValorPremio());
					valorPremioVigenciaTotal = BigDecimalUtil.safeAdd(valorPremioVigenciaTotal,itemRamoEmissao.getValorPremioVigencia());
					valorPremioReferencialTotal = BigDecimalUtil.safeAdd(valorPremioReferencialTotal,itemRamoEmissao.getValorPremioReferencial());
				}
				BigDecimal percentualDescontoComercial = calcularPercentualDescontoComercial(cotacao.getIdTipoPedidoCotacao(),valorPremioTotal,valorPremioVigenciaTotal,valorPremioReferencialTotal);
				comissaoCotacao.setPercentualDescontoComercial(percentualDescontoComercial);
			}
		} catch (Exception e) {
			logger.error("Erro ao calcular e atualizar percentual de desconto comercial por ramo.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	private void gerarItemRamoEmissao(
			Cotacao cotacao, List<ItemRamoEmissaoDTO> listItemRamoEmissaoOld,
			Set<ItemRamoEmissao> listItemRamoEmissao, ItemCobertura itemCobertura,
			User user, Map<ItemRamoEmissaoDTO, ProdutoSusep> itemRamoProdutoSusep) throws ServiceException {
		Boolean idAtualizacaoRamoEmissao = false;
		for (ItemRamoEmissao itemRamoEmissao : listItemRamoEmissao) {
			if (itemCobertura.getItemCotacao().getSequencialItemCotacao().equals(itemRamoEmissao.getItemCotacao().getSequencialItemCotacao())
					&& itemCobertura.getCodigoGrupoRamoEmissao().equals(itemRamoEmissao.getCodigoGrupoRamo())
					&& itemCobertura.getCodigoRamoCoberturaEmissao().equals(itemRamoEmissao.getCodigoRamo())) {
				atualizarItemRamoEmissao(cotacao,itemRamoEmissao,itemCobertura,user);
				idAtualizacaoRamoEmissao = true;
				break;
			}
		}
		if (!idAtualizacaoRamoEmissao) {
			ItemRamoEmissao itemRamoEmissao = incluirItemRamoEmissao(cotacao,listItemRamoEmissaoOld,itemCobertura,user,itemRamoProdutoSusep);
			listItemRamoEmissao.add(itemRamoEmissao);
		}
	}

	private void gerarItemRamoContabil(Cotacao cotacao,List<ItemRamo> listItemRamoContabil,ItemCobertura itemCobertura,User user) throws ServiceException {
		try {
			boolean idAtualizacaoRamoContabil = false;
			for (ItemRamo ir : listItemRamoContabil) {
				if (itemCobertura.getItemCotacao().getSequencialItemCotacao().equals(ir.getItemCotacao().getSequencialItemCotacao())
						&& itemCobertura.getCodigoGrupoRamoContabil().equals(ir.getCodigoGrupoRamo())
						&& itemCobertura.getCodigoRamoCoberturaContabil().equals(ir.getCodigoRamo())) {
					atualizarItemRamoContabil(cotacao,ir,itemCobertura,user);
					idAtualizacaoRamoContabil = true;
					break;
				}
			}

			if (!idAtualizacaoRamoContabil) {
				ItemRamo itemRamo = incluirItemRamoContabil(cotacao,itemCobertura,user);
				listItemRamoContabil.add(itemRamo);
			}
		} catch (Exception e) {
			logger.error("Erro ao atualizar a descrição da franquia",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	/* A mensagem "exclusivamente em caso de raio" deve ser exibir para todas as coberturas basicas do ramo 18, produto 1850 e 1851,
	 * exceto para os casos das rubricas/atividades:
	 * 65  - AUTOMÓVEL / MOTOCICLETA, AUTO-CENTER (CENTRO AUTOMOTIVO), ADMITINDO-SE INSTALAÇÃO DE PEÇAS OU COMPONENTES
	 * 552 - PLÁSTICO, DEPÓSITO (INCLUSIVE DE ARTIGOS), SEM ARMAZENAMENTO DE CELULÓIDE OU DE ARTIGOS DE CELULÓIDE
	 * 555 - PLÁSTICO, LOJA DE ARTIGOS, EXCLUÍDOS OS DE CELULÓIDE
	 * 554 - PLÁSTICO, FÁBRICA (INCLUSIVE DE ARTIGOS), SEM FABRICAÇÃO OU EMPREGO DE CELULÓIDE
	 * 560 - PNEUS, LOJA DE PNEUS NOVOS, SEM OFICINA DE CONSERTOS
	 * Jira: PPKME-488 
	 * */	
	private void atualizarDescricaoFranquia(Integer codigoProduto, Long codigoRubrica,ItemCobertura itemCobertura) throws ServiceException {
		boolean idTextoComplemento = false;
		if (Arrays.asList(1850,1851,1852).contains(codigoProduto)){
			if (itemCobertura.getIdTipoCobertura().equals(TipoCoberturaEnum.BASICA.getId()) &&
					itemCobertura.getCodigoGrupoRamoEmissao().equals(1) &&
					itemCobertura.getCodigoRamoCoberturaEmissao().equals(18)){
				if (!Arrays.asList(65L,552L,554L,555L,560L).contains(codigoRubrica)){
					idTextoComplemento = true;
				}
			}
		} 

		
		itemCobertura.setDescricaoFranquia(itemCobertura.getIdFormaFranquia().getDescricaoFranquia(
				itemCobertura.getNumeroDiasFranquia(),
				itemCobertura.getNumeroHorasFranquia(),
				itemCobertura.getTaxaFranquia(),
				itemCobertura.getValorFranquia(),
				itemCobertura.getValorFranquiaMinima(),
				itemCobertura.getValorFranquiaMaxima(),
				itemCobertura.getTaxaImportanciaSegurada(),
				itemCobertura.getTaxaImportanciaSeguradaMinima(),
				itemCobertura.getTaxaImportanciaSeguradaMaxima(),
				itemCobertura.getValorImportanciaSegurada(),
				idTextoComplemento));
	
	}
	
	private void atualizarItemRamoContabil(Cotacao cotacao, ItemRamo itemRamo,ItemCobertura itemCobertura,User user) throws ServiceException {
		try {

			if (itemCobertura.getIdDanosMateriais().equals(SimNaoEnum.SIM)) {
				itemRamo.setValorDM(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
				itemRamo.setValorDMMoedaEstrangeira(itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira());
			}
			if (itemCobertura.getIdLucrosCessantes().equals(SimNaoEnum.SIM)) {
				itemRamo.setValorLC(BigDecimalUtil.safeAdd(itemRamo.getValorLC(),itemCobertura.getValorRiscoBem()));
				itemRamo.setValorLCMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamo.getValorLCMoedaEstrangeira(),itemCobertura.getValorRiscoBemMoedaEstrangeira()));
			}

			if (itemCobertura.getIdLMR() == SimNaoEnum.SIM) {
				if (cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
					itemRamo.setValorLMR(BigDecimalUtil.safeAdd(itemRamo.getValorLMR(),itemCobertura.getValorSublimite()));
					itemRamo.setValorLMRMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamo.getValorLMRMoedaEstrangeira(),itemCobertura.getValorSublimiteMoedaEstrangeira()));
				} else {
					itemRamo.setValorLMR(BigDecimalUtil.safeAdd(itemRamo.getValorLMR(),itemCobertura.getValorImportanciaSegurada()));
					itemRamo.setValorLMRMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamo.getValorLMRMoedaEstrangeira(),itemCobertura.getValorISMoedaEstrangeira()));
				}
				itemRamo.setValorLmrIs(BigDecimalUtil.safeAdd(itemRamo.getValorLmrIs(),itemCobertura.getValorImportanciaSegurada()));
				itemRamo.setValorLmrIsMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamo.getValorLmrIsMoedaEstrangeira(),itemCobertura.getValorISMoedaEstrangeira()));
			}
			itemRamo.setValorPremio(BigDecimalUtil.safeAdd(itemRamo.getValorPremio(),itemCobertura.getValorPremio()));
			itemRamo.setValorPremioMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamo.getValorPremioMoedaEstrangeira(),itemCobertura.getValorPremioMoedaEstrangeira()));
			itemRamo.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			if (user.getCdUsuro() != null) {
				itemRamo.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			}
			itemRamo.setDataAtualizacao(new Date());
		} catch (Exception e) {
			logger.error("Erro ao atualizar atributos em itemRamoContabil.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	public ItemRamo incluirItemRamoContabil(Cotacao cotacao, ItemCobertura itemCobertura,User user) throws ServiceException {
		ItemRamo itemRamo = new ItemRamo();
		try {
			itemRamo.setNumeroCotacaoProposta(itemCobertura.getNumeroCotacaoProposta());
			itemRamo.setVersaoCotacaoProposta(itemCobertura.getVersaoCotacaoProposta());
			itemRamo.setIdExclusaoEndosso(SimNaoEnum.NAO);
			itemRamo.setItemCotacao(itemCobertura.getItemCotacao());
			itemRamo.setCodigoGrupoRamo(itemCobertura.getCodigoGrupoRamoContabil());
			itemRamo.setCodigoRamo(itemCobertura.getCodigoRamoCoberturaContabil());

			if (itemCobertura.getIdDanosMateriais().equals(SimNaoEnum.SIM)) {
				itemRamo.setValorDM(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
				itemRamo.setValorDMMoedaEstrangeira(itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira());
			}

			if (itemCobertura.getIdLucrosCessantes().equals(SimNaoEnum.SIM)) {
				itemRamo.setValorLC(itemCobertura.getValorRiscoBem());
				itemRamo.setValorLCMoedaEstrangeira(itemCobertura.getValorRiscoBemMoedaEstrangeira());
			}
			
			if (itemCobertura.getIdLMR() == SimNaoEnum.SIM) {
				if (cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
					itemRamo.setValorLMR(itemCobertura.getValorSublimite());
					itemRamo.setValorLMRMoedaEstrangeira(itemCobertura.getValorSublimiteMoedaEstrangeira());
				} else {
					itemRamo.setValorLMR(itemCobertura.getValorImportanciaSegurada());
					itemRamo.setValorLMRMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
				}
				itemRamo.setValorLmrIs(itemCobertura.getValorImportanciaSegurada());
				itemRamo.setValorLmrIsMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
			}
			itemRamo.setValorPremio(itemCobertura.getValorPremio());
			itemRamo.setValorPremioMoedaEstrangeira(itemCobertura.getValorPremioMoedaEstrangeira());

			itemRamo.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			if (user.getCdUsuro() != null) {
				itemRamo.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			}

			// FIXME verificar se dá pra salvar utilizando os cascades da vida
			// itemRamo.setItemCotacao(itemCobertura.getItemCotacao());

			itemRamo.setDataAtualizacao(new Date());
		} catch (Exception e) {
			logger.error("Erro ao incluir atributos em itemRamoContabil.",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return itemRamo;

	}

	public ItemRamoEmissao incluirItemRamoEmissao(
			Cotacao cotacao, List<ItemRamoEmissaoDTO> listItemRamoEmissaoOld,
			ItemCobertura itemCobertura, User user, 
			Map<ItemRamoEmissaoDTO, ProdutoSusep> itemRamoProdutoSusep) throws ServiceException {
		ItemRamoEmissao itemRamoEmissao = new ItemRamoEmissao();
		try {
			itemRamoEmissao.setNumeroCotacaoProposta(itemCobertura.getNumeroCotacaoProposta());
			itemRamoEmissao.setVersaoCotacaoProposta(itemCobertura.getVersaoCotacaoProposta());
			itemRamoEmissao.setItemCotacao(itemCobertura.getItemCotacao());
			itemRamoEmissao.setCodigoGrupoRamo(itemCobertura.getCodigoGrupoRamoEmissao());
			itemRamoEmissao.setCodigoRamo(itemCobertura.getCodigoRamoCoberturaEmissao());

			if (itemCobertura.getIdExclusaEndosso().equals(SimNaoEnum.NAO)) {
				if (itemCobertura.getIdDanosMateriais().equals(SimNaoEnum.SIM)) {
					itemRamoEmissao.setValorDM(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
					itemRamoEmissao.setValorDMMoedaEstrangeira(itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira());
				}
	
				if (itemCobertura.getIdLucrosCessantes().equals(SimNaoEnum.SIM)) {
					itemRamoEmissao.setValorLC(itemCobertura.getValorRiscoBem());
					itemRamoEmissao.setValorLCMoedaEstrangeira(itemCobertura.getValorRiscoBemMoedaEstrangeira());
				}
				
				if (itemCobertura.getIdLMR() == SimNaoEnum.SIM) {
					if (cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
						itemRamoEmissao.setValorLMR(itemCobertura.getValorSublimite());
						itemRamoEmissao.setValorLMRMoedaEstrangeira(itemCobertura.getValorSublimiteMoedaEstrangeira());
					} else {
						itemRamoEmissao.setValorLMR(itemCobertura.getValorImportanciaSegurada());
						itemRamoEmissao.setValorLMRMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
	 				}
					itemRamoEmissao.setValorLmrIs(itemCobertura.getValorImportanciaSegurada());
					itemRamoEmissao.setValorLmrIsMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
				}
				itemRamoEmissao.setValorIS(itemCobertura.getValorImportanciaSegurada());
				itemRamoEmissao.setValorISMoedaEstrangeira(itemCobertura.getValorISMoedaEstrangeira());
			}else{
				itemRamoEmissao.setValorIS(BigDecimal.ZERO);
				itemRamoEmissao.setValorISMoedaEstrangeira(BigDecimal.ZERO);
			}
			itemRamoEmissao.setValorPremioNet(itemCobertura.getValorPremioNET());
			itemRamoEmissao.setValorPremio(itemCobertura.getValorPremio());
			itemRamoEmissao.setValorPremioMoedaEstrangeira(itemCobertura.getValorPremioMoedaEstrangeira());
			itemRamoEmissao.setValorPremioVigencia(itemCobertura.getValorPremioVigencia());
			itemRamoEmissao.setValorPremioReferencial(itemCobertura.getValorPremioReferencial());

			for (ComissaoCotacao comissaoCotacao : cotacao.getListComissaoCotacao()) {
				if (comissaoCotacao.getCodigoGrupoRamo().equals(itemRamoEmissao.getCodigoGrupoRamo()) && comissaoCotacao.getCodigoRamo().equals(itemRamoEmissao.getCodigoRamo())) {
					itemRamoEmissao.setPercentualComissao(comissaoCotacao.getPercentualComissao());
					break;
				}
			}

			Optional<ItemRamoEmissaoDTO> oire = listItemRamoEmissaoOld
					.stream()
					.filter(ire -> ire.getCodigoGrupoRamo().equals(itemRamoEmissao.getCodigoGrupoRamo()) && 
							ire.getCodigoRamo().equals(itemRamoEmissao.getCodigoRamo()))
					.findFirst();

			if (oire.isPresent()) {
				itemRamoEmissao.setProcessoSusep(oire.get().getProcessoSusep());
				itemRamoEmissao.setComplementoLmr(oire.get().getComplementoLmr());
			}else{
				ItemRamoEmissaoDTO itemRamoEmissaoDTO = new ItemRamoEmissaoDTO();
				itemRamoEmissaoDTO.setCodigoGrupoRamo(itemRamoEmissao.getCodigoGrupoRamo());
				itemRamoEmissaoDTO.setCodigoRamo(itemRamoEmissao.getCodigoRamo());
				ProdutoSusep produtoSusep = itemRamoProdutoSusep.get(itemRamoEmissaoDTO);
				itemRamoEmissao.setProcessoSusep(produtoSusep.getDescricao());
			}
				

			BigDecimal percentualDescontoComercial = calcularPercentualDescontoComercial(cotacao.getIdTipoPedidoCotacao(),itemRamoEmissao.getValorPremio(),itemRamoEmissao.getValorPremioVigencia(),itemRamoEmissao.getValorPremioReferencial());
			itemRamoEmissao.setPercentualDescontoComercial(percentualDescontoComercial);
			itemRamoEmissao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			if (user.getCdUsuro() != null) {
				itemRamoEmissao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			}
			itemRamoEmissao.setDataAtualizacao(new Date());
		} catch (Exception e) {
			logger.error("Erro ao incluir atributos em itemRamoEmissao.",e);
			throw new ServiceException(e.getMessage(),e);
		}
		return itemRamoEmissao;
	}

	private void atualizarItemRamoEmissao(Cotacao cotacao,ItemRamoEmissao itemRamoEmissao,ItemCobertura itemCobertura,User user) throws ServiceException {
		try {
			itemRamoEmissao.setNumeroCotacaoProposta(itemCobertura.getNumeroCotacaoProposta());
			itemRamoEmissao.setVersaoCotacaoProposta(itemCobertura.getVersaoCotacaoProposta());

			if (itemCobertura.getIdExclusaEndosso().equals(SimNaoEnum.NAO)) {
				if (itemCobertura.getIdDanosMateriais().equals(SimNaoEnum.SIM)) {
					itemRamoEmissao.setValorDM(itemCobertura.getItemCotacao().getValorRiscoBemCalculado());
					itemRamoEmissao.setValorDMMoedaEstrangeira(itemCobertura.getItemCotacao().getValorCalculadoMoedaEstrangeira());
				}
				if (itemCobertura.getIdLucrosCessantes().equals(SimNaoEnum.SIM)) {
					itemRamoEmissao.setValorLC(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLC(),itemCobertura.getValorRiscoBem()));
					itemRamoEmissao.setValorLCMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLCMoedaEstrangeira(),itemCobertura.getValorRiscoBemMoedaEstrangeira()));
				}
				if (itemCobertura.getIdLMR() == SimNaoEnum.SIM) {
					if (cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
						itemRamoEmissao.setValorLMR(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLMR(),itemCobertura.getValorSublimite()));
						itemRamoEmissao.setValorLMRMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLMRMoedaEstrangeira(),itemCobertura.getValorSublimiteMoedaEstrangeira()));
					} else {
						itemRamoEmissao.setValorLMR(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLMR(),itemCobertura.getValorImportanciaSegurada()));
						itemRamoEmissao.setValorLMRMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLMRMoedaEstrangeira(),itemCobertura.getValorISMoedaEstrangeira()));
					}
					itemRamoEmissao.setValorLmrIs(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLmrIs(),itemCobertura.getValorImportanciaSegurada()));
					itemRamoEmissao.setValorLmrIsMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorLmrIsMoedaEstrangeira(),itemCobertura.getValorISMoedaEstrangeira()));
				}
				itemRamoEmissao.setValorIS(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorIS(),itemCobertura.getValorImportanciaSegurada()));
				itemRamoEmissao.setValorISMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorISMoedaEstrangeira(),itemCobertura.getValorISMoedaEstrangeira()));
			}
			itemRamoEmissao.setValorPremio(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorPremio(),itemCobertura.getValorPremio()));
			itemRamoEmissao.setValorPremioNet(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorPremioNet(),itemCobertura.getValorPremioNET()));
			itemRamoEmissao.setValorPremioMoedaEstrangeira(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorPremioMoedaEstrangeira(),itemCobertura.getValorPremioMoedaEstrangeira()));
			itemRamoEmissao.setValorPremioVigencia(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorPremioVigencia(),itemCobertura.getValorPremioVigencia()));
			itemRamoEmissao.setValorPremioReferencial(BigDecimalUtil.safeAdd(itemRamoEmissao.getValorPremioReferencial(),itemCobertura.getValorPremioReferencial()));

			BigDecimal percentualDescontoComercial = calcularPercentualDescontoComercial(cotacao.getIdTipoPedidoCotacao(),itemRamoEmissao.getValorPremio(),itemRamoEmissao.getValorPremioVigencia(),itemRamoEmissao.getValorPremioReferencial());
			itemRamoEmissao.setPercentualDescontoComercial(percentualDescontoComercial);
			itemRamoEmissao.setCodigoGrupo(user.getGrupoUsuario().getCdGrp());
			if (user.getCdUsuro() != null) {
				itemRamoEmissao.setUsuarioAtualizacao(user.getCdUsuro().longValue());
			}
			itemRamoEmissao.setDataAtualizacao(new Date());
		} catch (Exception e) {
			logger.error("Erro ao atualizar atributos em itemRamoEmissao.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}

	private BigDecimal calcularPercentualDescontoComercial(TipoPedidoCotacaoEnum tipoPedidoCotacao,BigDecimal valorPremioTotal,BigDecimal valorPremioVigenciaTotal,BigDecimal valorPremioReferencialTotal) throws ServiceException {
		try {
			BigDecimal percentualDescontoComercial = null;
			if (BigDecimalUtil.nvl(valorPremioReferencialTotal,BigDecimal.ZERO).compareTo(BigDecimal.ZERO) != 0) {
				if (tipoPedidoCotacao.equals(TipoPedidoCotacaoEnum.APOLICE)) {
					percentualDescontoComercial = BigDecimalUtil.truncComDecimais(2,BigDecimal.ONE
							.subtract(valorPremioTotal
									.divide(valorPremioReferencialTotal,MathContext.DECIMAL128)
									.multiply(new BigDecimal("100"),MathContext.DECIMAL128)));
				} else {
					if (BigDecimalUtil.nvl(valorPremioVigenciaTotal,BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 0) {
						percentualDescontoComercial = BigDecimalUtil.truncComDecimais(2,BigDecimal.ONE
								.subtract(BigDecimalUtil.nvl(valorPremioTotal,BigDecimal.ZERO)
										.divide(BigDecimalUtil.nvl(valorPremioReferencialTotal,valorPremioTotal),MathContext.DECIMAL128)
										.multiply(new BigDecimal("100"),MathContext.DECIMAL128)));
					} else {
						percentualDescontoComercial = BigDecimalUtil.truncComDecimais(2,BigDecimal.ONE
								.subtract(BigDecimalUtil.nvl(valorPremioVigenciaTotal,BigDecimal.ZERO)
										.divide(BigDecimalUtil.nvl(valorPremioReferencialTotal,valorPremioVigenciaTotal),MathContext.DECIMAL128)
										.multiply(new BigDecimal("100"),MathContext.DECIMAL128)));
					}
				}

				if (BigDecimalUtil.maior(percentualDescontoComercial,new BigDecimal("100"))) {
					percentualDescontoComercial = BigDecimal.ZERO;
				}
				if (BigDecimalUtil.menorIgual(percentualDescontoComercial,BigDecimal.ZERO)) {
					percentualDescontoComercial = null;
				}
			}
			return percentualDescontoComercial;
		} catch (Exception e) {
			logger.error("Erro ao calcular percentual desconto comercial.",e);
			throw new ServiceException(e.getMessage(),e);
		}
	}
	
	public BigDecimal calculaSomaValoresLMR(Cotacao cotacao) {
		List<ItemRamo> itensRamo = itemRamoRepository.findNaoExcluidoDoEndossoByCotacao(cotacao.getNumeroCotacaoProposta(), cotacao.getVersaoCotacaoProposta());
		BigDecimal somaValoresLMR = caluclaSomaValoresLMR(itensRamo);
		return somaValoresLMR;
	}

	public BigDecimal caluclaSomaValoresLMR(List<ItemRamo> itensRamo) {
		return itensRamo.stream()
				.filter(itemRamo -> itemRamo.getValorLMR() != null)
				.map(ItemRamo::getValorLMR)
				.reduce(BigDecimal.ZERO, (a, b) ->  a.add(b));
	}

	private List<String> validaPremioLiquido(Cotacao cotacao) {
		if (cotacao.getIdTipoPedidoCotacao() == TipoPedidoCotacaoEnum.APOLICE && BigDecimalUtil.nvl(cotacao.getValorPremioLiquido()).compareTo(BigDecimal.ZERO) == 0) {
			throw new RuntimeException("Não foi gerado prêmio para esta cotação. Entre em Contato com a Seguradora informando este problema.");
		}
		return Collections.emptyList();
	}

	private void appendTextoComplementarCoberturaAtividade(Cotacao cotacao) {
		Map<String, String> mapaValorComplemento = new HashMap<>();
		
		for (ItemCotacao itemCotacao : cotacao.getListItem()) {
			for (ItemCobertura itemCobertura : itemCotacao.getListItemCobertura()) {
				String key = itemCobertura.getCodigoCobertura() + "_" + itemCotacao.getCodigoRubrica();
				String complemento = mapaValorComplemento.computeIfAbsent(key, k -> {
					Long codigoRubrica = itemCotacao.getCodigoRubrica();
					Integer codigoCobertura = itemCobertura.getCodigoCobertura();
					return coberturaAtividadeComplementoRepository.findByProdutoAndCoberturaAndAtividade(cotacao.getCodigoProduto(), codigoCobertura, codigoRubrica);
				});

				if(!StringUtils.isBlank(complemento)) {
					StringBuilder sb = new StringBuilder();
					sb.append(complemento);
					if(itemCobertura.getDescricaoComplementoCobertura() == null) {
						itemCobertura.setDescricaoComplementoCobertura(sb.toString());
					}
				} else {
					if(!StringUtils.isBlank(itemCobertura.getDescricaoComplementoCobertura()) 
							&& StringUtils.contains(itemCobertura.getDescricaoComplementoCobertura(),
									" (Limitado em R$ 100.000,00 em caso de Incêndio ou Explosão decorrentes de danos por ataques a caixas eletrônicos)")) {
						itemCobertura.setDescricaoComplementoCobertura(
								StringUtils.remove(itemCobertura.getDescricaoComplementoCobertura(),
										" (Limitado em R$ 100.000,00 em caso de Incêndio ou Explosão decorrentes de danos por ataques a caixas eletrônicos)*"));
					}
				}
			}
		}
	}
}
