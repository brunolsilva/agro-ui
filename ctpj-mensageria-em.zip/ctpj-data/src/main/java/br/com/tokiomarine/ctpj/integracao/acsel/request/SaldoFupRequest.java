package br.com.tokiomarine.ctpj.integracao.acsel.request;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ccodramocli", "nnumapolice", "nnumendosso" })
public class SaldoFupRequest {

	@JsonProperty("ccodramocli")
	private String ramo;
	@JsonProperty("nnumapolice")
	private Integer apolice;
	@JsonProperty("nnumendosso")
	private Integer endosso;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<>();

	@JsonProperty("ccodramocli")
	public String getRamo() {
		return ramo;
	}

	@JsonProperty("ccodramocli")
	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	@JsonProperty("nnumapolice")
	public Integer getApolice() {
		return apolice;
	}

	@JsonProperty("nnumapolice")
	public void setApolice(Integer apolice) {
		this.apolice = apolice;
	}

	@JsonProperty("nnumendosso")
	public Integer getEndosso() {
		return endosso;
	}

	@JsonProperty("nnumendosso")
	public void setEndosso(Integer endosso) {
		this.endosso = endosso;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
	
	public SaldoFupRequest(String ramo, Integer apolice, Integer endosso) {
		this.ramo = ramo;
		this.apolice = apolice;
		this.endosso = endosso == null ? 0 : endosso;
	}

}