package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.apolice.repository.ApoliceRepository;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.repository.AlteracaoEndossoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.EndossoRepository;
import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.endosso.service.AlteracoesEndossoService;
import br.com.tokiomarine.ctpj.endosso.service.EndossoClausulaApoliceService;
import br.com.tokiomarine.ctpj.endosso.service.EndossoComissaoService;
import br.com.tokiomarine.ctpj.endosso.service.EndossoCondicaoContratualService;
import br.com.tokiomarine.ctpj.endosso.service.EndossoDadosCapaService;
import br.com.tokiomarine.ctpj.endosso.service.EndossoItemService;
import br.com.tokiomarine.ctpj.enums.EndossoSolicitanteMensagemEnum;
import br.com.tokiomarine.ctpj.enums.GrupoUsuarioEnum;
import br.com.tokiomarine.ctpj.enums.TipoProcessamentoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.EndossoTipoAlteracao;
import br.com.tokiomarine.ctpj.infra.domain.Produto;
import br.com.tokiomarine.ctpj.infra.mongo.repository.EndossoTipoAlteracaoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ProdutoRepository;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class})
public class GeraMensagemEndossoService {
	
	@Autowired
	private EndossoRepository endossoRepository;
	
	@Autowired
	private AlteracaoEndossoRepository alteracaoEndossoRepository;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private CotacaoLogService cotacaoLogService;
	
	@Autowired
	private ApoliceRepository apoliceRepository;
	
	@Autowired 
	private ProdutoRepository produtoRepository;
	
	@Autowired
	private EndossoDadosCapaService endossoDadosCapaService;
	
	@Autowired
	private EndossoComissaoService endossoComissaoService;
	
	@Autowired
	private EndossoCondicaoContratualService endossoCondicaoContratualService;
	
	@Autowired
	private EndossoClausulaApoliceService endossoClausulaApoliceService;
	
	@Autowired
	private EndossoItemService endossoItemService;
	
	@Autowired 
	private EndossoTipoAlteracaoRepository endossoTipoAlteracaoRepository;
				
	private static Logger logger = LogManager.getLogger(GeraMensagemEndossoService.class.getName());
	
	@LogPerformance
	public void geraMensagemEndosso(BigInteger sqCotac, String idApolice) throws ServiceException {		
		try {
			endossoRepository.geraMensagemEndosso(sqCotac, idApolice);
		} catch (Exception e) {
			logger.error("Erro ao chamar procedure geraMensagemEndosso: " + e);
			throw new ServiceException(e.getMessage(),e);
		}		
	}
	
	@LogPerformance
	public void regerarMensagensEndosso(BigInteger sequencialCotacaoProposta) throws Exception {
		
		Cotacao cotacao = cotacaoRepository.findCompleta(sequencialCotacaoProposta);
		
		// Pega a apólice
		Apolice apolice = apoliceRepository.findById(cotacao.getIdMongoEndosso());
		
		User user = new User();
		user.setCdUsuro(cotacao.getUsuarioAtualizacao().intValue());
		user.setGrupoUsuario(GrupoUsuarioEnum.getGrupoUsuariobyCdGrp(cotacao.getCodigoGrupo()));
		List<String> erros = new ArrayList<String>();
		this.geraMensagensEndosso(cotacao,apolice,user,erros);
		
	}
	
	@LogPerformance
	public void geraMensagensEndosso(Cotacao cotacao, Apolice apolice,User user,List<String> erros) throws ServiceException {		
		
		//TODO alterar o tipo da lista de erros
		try {
			logger.debug("Deletando os registros da tabela ctp0132_alter_endos para a sequencia cotação: " + cotacao.getSequencialCotacaoProposta());
			//apaga os registros da tabela ctp0132_alter_endos para a sequencia de cotação
			this.deleteAlteracaoEndosso(cotacao.getSequencialCotacaoProposta());
			
			//busca o produto
			Produto produto = produtoRepository.findByCodigo(cotacao.getCodigoProduto());
					
			logger.debug("Busca os dados da apólice no mongo backoffice, idApolice: " + cotacao.getIdMongoEndosso());

				
				logger.debug("Buscando mensagem de retorno por tipo(apolice ou endosso)/solicitante, sequencia cotação: " + cotacao.getSequencialCotacaoProposta());
				EndossoSolicitanteMensagemEnum endSolicMsgEnum = EndossoSolicitanteMensagemEnum.getByTipoEndossoAndSolicitante(cotacao.getIdTipoEndosso(), cotacao.getIdSolicitanteEndosso());
				
				if(endSolicMsgEnum != null){
					logger.debug("Mensagem de retorno por tipo(apolice ou endosso)/solicitante foi encontrada, sequencia cotação: " + cotacao.getSequencialCotacaoProposta());
					logger.debug("Tipo e descrição do endosso: " + cotacao.getIdTipoEndosso().getId() + " - " + cotacao.getIdTipoEndosso().getDescricao());
					logger.debug("Solicitante do endosso: " + cotacao.getIdSolicitanteEndosso().getId() + " - " + cotacao.getIdSolicitanteEndosso().getDescricao());
					logger.debug("Mensagem : " + endSolicMsgEnum.getTipoMensagem() + " - " + endSolicMsgEnum.getMensagem());
					logger.debug("Salvando alteração do endosso na tabela ctp0132_alter_endos");
					//busca a descricao do tipo de alteracao no mongo
					EndossoTipoAlteracao endTipoAlteracao = endossoTipoAlteracaoRepository.findEndossoTipoAlteracao(endSolicMsgEnum.getTipoMensagem().getCodigo());
					AlteracaoEndosso alteracao = alteracoesEndossoService.bindToDomain(produto, cotacao, endTipoAlteracao, endSolicMsgEnum, user);
					alteracao.setDescricaoTipoRegistro(StringUtils.substring(alteracao.getDescricaoTipoRegistro(), 0, 498));
					alteracaoEndossoRepository.save(alteracao);
				} else {
					logger.debug("Nenhuma mensagem de retorno por tipo(apolice ou endosso)/solicitante foi encontrada, sequencia cotação: " + cotacao.getSequencialCotacaoProposta());
					List<AlteracaoEndosso> alteracoesEndossoList = new ArrayList<AlteracaoEndosso>();
					
					if(cotacao.getCodigoTipoEndossoSCT().equals(TipoEndossoSctEnum.REINTEGRACAO_IS)) {
						logger.debug("Validando endosso item do sequencial Cotacao - Reintegração de IS :"+cotacao.getSequencialCotacaoProposta());
						endossoItemService.validarItensApoliceReintegracao(cotacao, apolice, alteracoesEndossoList, user);
						
					} else if(cotacao.getCodigoTipoEndossoSCT().equals(TipoEndossoSctEnum.REDUCAO_SINISTRO)){
						logger.debug("Validando endosso item do sequencial Cotacao - Redução de IS :"+cotacao.getSequencialCotacaoProposta());
						endossoItemService.validarItensApoliceReducaoIsPorSinistro(cotacao, apolice, alteracoesEndossoList, user);						
					} else {
						logger.debug("Validando dados da capa do sequencial Cotacao :"+cotacao.getSequencialCotacaoProposta());
						endossoDadosCapaService.validarDadosDaCapa(produto, cotacao, apolice, alteracoesEndossoList, user);
						
						logger.debug("Validando dados de comissão do sequencial Cotacao :"+cotacao.getSequencialCotacaoProposta());
						endossoComissaoService.validarComissao(produto, cotacao, apolice, alteracoesEndossoList, user);
						
						logger.debug("Validando condição contratual do sequencial Cotacao :"+cotacao.getSequencialCotacaoProposta());
//						endossoCondicaoContratualService.validarCondicaoContratual(produto, cotacao, apolice, alteracoesEndossoList, user);
						
						logger.debug("Validando clausula apólice do sequencial Cotacao :"+cotacao.getSequencialCotacaoProposta());
						if(AmbienteUtil.isServidorDeProducao()) {
							endossoClausulaApoliceService.validarClausulaApolice(produto, cotacao, apolice, alteracoesEndossoList, user);
						}
						
						logger.debug("Validando endosso item do sequencial Cotacao :"+cotacao.getSequencialCotacaoProposta());
						endossoItemService.validarEndossoItem(cotacao, apolice, alteracoesEndossoList, user);						
					}

					logger.debug("Gravando mensagens endosso do sequencial Cotacao :"+cotacao.getSequencialCotacaoProposta());
					this.gravarMensagens(cotacao,user,alteracoesEndossoList,erros);
				}
			
			
		} catch (Exception e) {
			logger.error("Erro ao gerar mensagens do endosso: " + e);
			throw new ServiceException(e.getMessage(),e);
		}		
	}
	
	private void gravarMensagens(Cotacao cotacao, User user, List<AlteracaoEndosso> alteracoesEndossoList, List<String> erros) throws ServiceException{
		if(alteracoesEndossoList != null && !alteracoesEndossoList.isEmpty()){
			for(AlteracaoEndosso alteracaoEndosso : alteracoesEndossoList){
				try{
					if(logger.isDebugEnabled()) {
						logarAlteracaoEndosso(alteracaoEndosso);
					}
					alteracaoEndossoRepository.save(this.tratarAlteracaoEndosso(alteracaoEndosso));
				} catch(Exception e){
					CotacaoLog cotacaoLog = cotacaoLogService.bindCotacaoLogBasicErro(cotacao,user,TipoProcessamentoEnum.GRAVACAO_MENSAGENS_ENDOSSO,e.getMessage(),JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(alteracaoEndosso),"");
					cotacaoLogService.save(cotacaoLog);
				}
			}
		} else {
			erros.add("Não houve nenhuma alteração no endosso!");
		}
	}
	
	private void logarAlteracaoEndosso(AlteracaoEndosso alteracaoEndosso){
		try {
			StringBuilder informacaoLog = new StringBuilder();
			informacaoLog.append("Insert mensagem de endosso para a sequencia cotacao " + alteracaoEndosso.getCotacao().getSequencialCotacaoProposta()+"\n");
			informacaoLog.append("Codigo Grupo: "+alteracaoEndosso.getCodigoGrupo());
			informacaoLog.append("\n");
			informacaoLog.append("Codigo Grupo Ramo: "+alteracaoEndosso.getCodigoGrupoRamo());
			informacaoLog.append("\n");
			informacaoLog.append("Codigo Ramo: "+alteracaoEndosso.getCodigoRamo());
			informacaoLog.append("\n");
			informacaoLog.append("Codigo Tipo Alteracao: "+alteracaoEndosso.getCodigoTipoAlteracao());
			informacaoLog.append("\n");
			informacaoLog.append("Descricao Tipo Registro: "+alteracaoEndosso.getDescricaoTipoRegistro());
			informacaoLog.append("\n");
			if(alteracaoEndosso.getItemCotacao() != null){
				informacaoLog.append("Codigo sequencial item cotacao: "+alteracaoEndosso.getItemCotacao().getSequencialItemCotacao());
				informacaoLog.append("\n");			
			}
			if(alteracaoEndosso.getItemCobertura() != null){
				informacaoLog.append("Codigo sequencial item cobertura: "+alteracaoEndosso.getItemCobertura().getSequencialItemCobertura());
				informacaoLog.append("\n");			
			}
			logger.debug(informacaoLog.toString());	
		} catch(Exception e){
			logger.debug("Erro log endosso"+ e.getMessage());
		}

	}
	
	private AlteracaoEndosso tratarAlteracaoEndosso(AlteracaoEndosso alteracaoEndosso){
		if(alteracaoEndosso.getDescricaoTipoRegistro().indexOf("null") >= 0){
			alteracaoEndosso.setDescricaoTipoRegistro(StringUtils.replace(alteracaoEndosso.getDescricaoTipoRegistro(), "null", "\" \""));
			alteracaoEndosso.setDescricaoTipoRegistro(StringUtils.substring(alteracaoEndosso.getDescricaoTipoRegistro(), 0, 498));

		}
		
		return alteracaoEndosso;
	}
	
	private void deleteAlteracaoEndosso(BigInteger seqCotacao){
		alteracaoEndossoRepository.delete(seqCotacao);
	}
	
	public List<AlteracaoEndosso> listAteracaoEndossoBysequencialCotacaoProposta(BigInteger sequencialCotacaoProposta)  throws Exception{
		return alteracaoEndossoRepository.listAlteracaoEndosso(sequencialCotacaoProposta);
	}
}
