package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.dto.DadosCotacaoParaResseguroFacultativo;
import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoForm;
import br.com.tokiomarine.ctpj.cotacao.relatorios.RelatorioException;
import br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo.GeradorRelatorioResseguroFacultativo;
import br.com.tokiomarine.ctpj.cotacao.repository.CotacaoRepository;
import br.com.tokiomarine.ctpj.cotacao.repository.ResseguroFacultativoRepository;
import br.com.tokiomarine.ctpj.cotacao.validator.constraintvalidators.ResseguroFacultativoValidator;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;
import br.com.tokiomarine.ctpj.dto.ValidationMessageList;
import br.com.tokiomarine.ctpj.exception.RegraNegocioException;
import br.com.tokiomarine.ctpj.exception.ResseguroFacultativoNaoEncontradoException;
import br.com.tokiomarine.ctpj.mapper.DadosCotacaoParaResseguroFacultativoMapper;
import br.com.tokiomarine.ctpj.mapper.ResseguroFacultativoMapper;

@Service
@Transactional
public class ResseguroFacultativoService {
	
	@Autowired
	private CotacaoRepository cotacaoRepository;
	
	@Autowired
	private ResseguroFacultativoRepository resseguroFacultativoRepository;
	
	@Autowired
	private ResseguroFacultativoValidator validator;
	
	@Autowired
	private ResseguroFacultativoMapper resseguroFacultativomapper;
	
	@Autowired
	private DadosCotacaoParaResseguroFacultativoMapper dadosCotacaoRessegFacultativoMapper;
	
	@Autowired
	private GeradorRelatorioResseguroFacultativo geradorRelatorio;
	
	public DadosCotacaoParaResseguroFacultativo recuperarDadosDoRisco(BigInteger seqCotacao){
		return dadosCotacaoRessegFacultativoMapper.toDadosCotacaoParaResseguroFacultativo(seqCotacao);
	}
	
	public Optional<ResseguroFacultativo> buscaPorCotacao(BigInteger seqCotacao){
		return resseguroFacultativoRepository.findByCotacao(seqCotacao);
	}
	
	/**
	 * @param form Dados do resseguro facultativo que serão salvos
	 * @param seqCotacao Representa que cotação estará ligada ao dados do resseguro facultativo salvo
	 * @throws RegraNegocioException lançada quando uma regra de negócio é violada
	 */
	public void salvaResseguroFacultativo(ResseguroFacultativoForm form, BigInteger seqCotacao){
		Cotacao cotacao = cotacaoRepository.findById(seqCotacao);
		valida(form, cotacao);
		ResseguroFacultativo resseguroFacultativo = resseguroFacultativomapper.toResseguroFacultativo(form, cotacao);		
		
		resseguroFacultativoRepository.deleteByCotacao(seqCotacao);
		resseguroFacultativoRepository.save(resseguroFacultativo);		
	}
	
	public byte[] geraResseguroFacultativoEmPDF(BigInteger seqCotacao) throws ResseguroFacultativoNaoEncontradoException, RelatorioException{
		DadosCotacaoParaResseguroFacultativo dadosCotacao = recuperarDadosDoRisco(seqCotacao);
		ResseguroFacultativo resseguroFacultativo = buscaPorCotacao(seqCotacao).orElseThrow(() -> new ResseguroFacultativoNaoEncontradoException(seqCotacao));
		
		return geradorRelatorio.gera(dadosCotacao, resseguroFacultativo);
	}

	private void valida(ResseguroFacultativoForm form, Cotacao cotacao) {
		ValidationMessageList messages = validator.valida(form, cotacao);
		
		if(!messages.isEmpty())
			throw new RegraNegocioException(messages);
	} 

}
