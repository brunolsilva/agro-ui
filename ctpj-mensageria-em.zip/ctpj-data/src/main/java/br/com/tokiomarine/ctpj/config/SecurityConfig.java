package br.com.tokiomarine.ctpj.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RegexRequestMatcher;

import br.com.tokiomarine.ctpj.auth.service.CtpjUserDetailsService;
import br.com.tokiomarine.ctpj.infra.mongo.service.MemoriaProcessamentoService;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationFailureHandler;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationFilter;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationProvider;
import br.com.tokiomarine.ctpj.security.TokenAuthenticationSuccessHandler;
import br.com.tokiomarine.ctpj.service.MailUtilService;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private CtpjUserDetailsService userDetailsService;

	@Autowired
	private MailUtilService mailService;

	@Autowired
	private MemoriaProcessamentoService memoriaProcessamentoService;

	@Autowired
	private ParametroGeralService parametroGeralService;


	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService);
		auth.authenticationProvider(new TokenAuthenticationProvider(userDetailsService, mailService,memoriaProcessamentoService,parametroGeralService));
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.addFilterBefore(createTokenAuthenticationFilter(),AnonymousAuthenticationFilter.class)
			.authorizeRequests()
			.antMatchers("/getProdutos/**", "/autentica/**", "/rest/**","falhaAutenticacao/**","/relatorio/**", 
						"/sair/**", "/entrada/sessaoExpirada/**", "/appMonitor/**", "/dashboard/**", "/dashboardFormalizacao/**",
						"/ws/**", "/ServicosAuxiliaresWs/**", "/CotacaoWs/**").permitAll()
			.anyRequest().authenticated()
			.antMatchers("/aceitacao/**", "/memoriaCalculo/**", "/recebimento/**","/detalheCalculo/**",
					"/juros/**").not().hasAuthority("_ROLE_CRTOR")
			.and().logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
			.and().exceptionHandling().accessDeniedPage("/erros/403")
			.and().csrf().disable()
			.headers().frameOptions().disable();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/resources/**","/rest/**");
	}

	protected AbstractAuthenticationProcessingFilter createTokenAuthenticationFilter() throws Exception {
		TokenAuthenticationFilter filter = new TokenAuthenticationFilter(new RegexRequestMatcher("^/token.*",null));
		filter.setAuthenticationManager(this.authenticationManagerBean());
		return filter;
	}

	@Bean
	public AuthenticationSuccessHandler authenticationSuccessHandler() {
		return new TokenAuthenticationSuccessHandler();
	}

	@Bean
	public AuthenticationFailureHandler authenticationFailureHandler() {
		return new TokenAuthenticationFailureHandler();
	}
}
