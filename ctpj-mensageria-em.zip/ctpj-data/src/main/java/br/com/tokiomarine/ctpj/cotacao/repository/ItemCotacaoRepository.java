package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;

@Repository
public class ItemCotacaoRepository extends BaseDAO {
	private static final String FIND_ITEM_BY_COTACAO = "select ic from Cotacao c join c.listItem ic where c.sequencialCotacaoProposta = :sequencialCotacaoProposta";
	
	@SuppressWarnings("unchecked")
	public List<ItemCotacao> findItemCotacaoByCotacao(BigInteger sequencialCotacaoProposta) {
		Query query = getCurrentSession().createQuery(FIND_ITEM_BY_COTACAO);
		query.setParameter("sequencialCotacaoProposta",sequencialCotacaoProposta);
		return query.list();
	}
	
	public void update(ItemCotacao itemCotacao) {
		getCurrentSession().update(itemCotacao);
		getCurrentSession().flush();
	}
}
