package br.com.tokiomarine.ctpj.cotacao.service;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.cotacao.repository.ItemSistemaProtecionalRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;

/**
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
@Service
public class ItemProtecionalService {
	
	@Autowired
	private ItemSistemaProtecionalRepository repository;
	
	public List<ItemSistemaProtecional> buscaSistemasProtecionaisPorCotacao(BigInteger seqCotacao){
		return (List<ItemSistemaProtecional>) repository.findSistemasProtecionaisByCotacao(seqCotacao);
	}
	
	public List<ItemSistemaProtecional> buscaSistemasProtecionaisPorItemCotacao(ItemCotacao itemCotacao){
		return repository.findSistemasProtecionaisByItemCotacao(itemCotacao);
	}

}
