package br.com.tokiomarine.ctpj.integracao.aceitacao.service;

import java.math.BigInteger;
import java.net.URI;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.cotacao.service.CotacaoLogService;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.dto.ResultadoREST;
import br.com.tokiomarine.ctpj.enums.FormaPagamentoEnum;
import br.com.tokiomarine.ctpj.enums.TipoProcessamentoEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.BancoCorretorPadrao;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoControle;
import br.com.tokiomarine.ctpj.infra.enums.ParametroGeralEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.mongo.repository.BancoRepository;
import br.com.tokiomarine.ctpj.infra.mongo.repository.CorretorRepository;
import br.com.tokiomarine.ctpj.infra.service.ParametroGeralService;
import br.com.tokiomarine.ctpj.integracao.aceitacao.request.NossoNumeroACTRequest;
import br.com.tokiomarine.ctpj.util.JacksonDatabindUtil;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class GerarNossoNumeroACTService {

	private static Logger logger = LogManager.getLogger(GerarNossoNumeroACTService.class);

	private static final String USER = "CTP";

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private CorretorRepository corretorRepository;

	@Autowired
	private ParametroGeralService parametroGeralService;

	@Autowired
	private BancoRepository bancoRepository;

	@Autowired
	private CotacaoLogService cotacaoLogService;

	@LogPerformance
	public ResultadoREST<String> gerarNossoNumeroACT(Cotacao cotacao, OpcaoParcelamento opcaoParcelamento,
			ProdutoControle produtoControle, User user) throws ServiceException {

		ResultadoREST<String> response = new ResultadoREST<>();
		CotacaoLog cotacaoLog = null;
		NossoNumeroACTRequest request = new NossoNumeroACTRequest();

		try {

			cotacaoLog = cotacaoLogService.bindCotacaoLogBasicSucesso(cotacao, user,
					TipoProcessamentoEnum.ACT_GERAR_NOSSO_NUMERO);

			request = this.bindNossoNumeroACT(cotacao, opcaoParcelamento, user);

			cotacaoLog.setRequest(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request));

			ParametroGeralEnum urlEnum = ParametroGeralEnum.getParametroACTGerarNossoNumero();

			if (urlEnum == null) {
				logger.error("Erro ao na busca da url, urlEnum nula: " + urlEnum);
				throw new ServiceException("Erro ao na busca da url, urlEnum nula ");
			}

			String url = null;

			try {
				url = parametroGeralService.getUrlByNome(urlEnum);
			} catch (Exception e) {
				throw new Exception("Erro ao na consulta na busca do Parametro: ", e);
			}

			if (StringUtils.isEmpty(url)) {
				throw new Exception("URL de acesso ao gerar nosso número nula ou vazia ");
			}

			HttpEntity<Object> entity = new HttpEntity<Object>(request);

			ResponseEntity<String> responseEntity = new ResponseEntity<>(HttpStatus.OK);

			try {
				
				responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				
				if(responseEntity.getStatusCode().equals(HttpStatus.OK)) {
					response.setSuccess(true);
					response.setCodigo(0);
					response.setRetornoObj(responseEntity.getBody());
				}else {
					response.setSuccess(false);
					response.setCodigo(responseEntity.getStatusCode().value());
					response.setRetornoObj(responseEntity.getBody());
				}				

			} catch (HttpServerErrorException hsee) {

				try {
					response.setCodigo(1);
					response.setSuccess(false);
					response.setRetornoObj(hsee.getResponseBodyAsString());
				} catch (Exception e) {
					logger.error("Erro ao converter resposta do serviço gerar nosso numero: " + url, e);
					throw new ServiceException(e);
				}
			} catch (RestClientException re) {
				response.setCodigo(1);
				response.setSuccess(false);
				response.setRetornoObj(re.getMessage());
				logger.error("Erro ao realizar a chamada do serviço gerar nosso numero.", re);				
			}

			cotacaoLog.setResponse(JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
			cotacaoLogService.saveLogRequiresNew(cotacaoLog);

		} catch (Exception e) {
			logger.error("Erro ao Gerar nosso numero para cotação " + cotacao.getNumeroCotacaoProposta(), e);
			response.setCodigo(1);
			response.setSuccess(false);
			response.setRetornoObj(ExceptionUtils.getStackTrace(e));

			BigInteger numeroProposta = null;

			try {

				numeroProposta = cotacao.getNumeroCotacaoProposta();
				cotacaoLog = cotacaoLogService.bindCotacaoLogBasicErro(cotacao, user,
						TipoProcessamentoEnum.ACT_GERAR_NOSSO_NUMERO, ExceptionUtils.getStackTrace(e),
						JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(request),
						JacksonDatabindUtil.getInstance().bindObjectToJsonToPrint(response));
				cotacaoLogService.saveLogRequiresNew(cotacaoLog);
			} catch (Exception e1) {
				logger.error("Erro ao log de erro Gerar nosso numero para cotação " + numeroProposta, e);
			}

		}

		return response;

	}

	private NossoNumeroACTRequest bindNossoNumeroACT(Cotacao cotacao, OpcaoParcelamento opcaoParcelamento, User user) {
		NossoNumeroACTRequest nossoNumero = new NossoNumeroACTRequest();
		nossoNumero.setFormaPagamento(bindFormaPagamento(cotacao, opcaoParcelamento));
		nossoNumero.setCodigoCorretor(Long.valueOf(cotacao.getCodigoCorretorACSEL()));
		nossoNumero.setCodigoBancoCobrador(bindBancoCobrador(cotacao, opcaoParcelamento));
		nossoNumero.setUser(USER);
		return nossoNumero;
	}

	private String bindFormaPagamento(Cotacao cotacao, OpcaoParcelamento opcaoParcelamento) {
		if (opcaoParcelamento.getIdEntrada().equals(SimNaoEnum.SIM)) {
			if (cotacao.getCodigoFormaPagamentoPrimeiraParcela() != null) {
				return FormaPagamentoEnum.getByCodigo(cotacao.getCodigoFormaPagamentoPrimeiraParcela()).getTipoDocumentoACT();
			} else {
				return FormaPagamentoEnum.getByCodigo(opcaoParcelamento.getCodigoFormaPagamento()).getTipoDocumentoACT();
			}
		}
		return null;
	}

	private Long bindBancoCobrador(Cotacao cotacao, OpcaoParcelamento opcaoParcelamento) {

		BancoCorretorPadrao bancoCorretorPadrao = corretorRepository.findBancoCorretorPadraoByCodigo(Long.valueOf(cotacao.getCodigoCorretorACSEL()));
		if (bancoCorretorPadrao != null && bancoCorretorPadrao.getBanco() != null) {
			return bancoCorretorPadrao.getBanco();
		} else {
			if (opcaoParcelamento.getIdEntrada().equals(SimNaoEnum.SIM)) {
				if (FormaPagamentoEnum.CARNE.getCodigo().equals(cotacao.getCodigoFormaPagamentoPrimeiraParcela())) {
					return bancoRepository.findBancoPrimeiraParcela().getCodigo();
				} else if (FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo().equals(cotacao.getCodigoFormaPagamentoPrimeiraParcela())) {
					return cotacao.getNumeroBancoDebito().longValue();
				} else if (FormaPagamentoEnum.CARNE.getCodigo().equals(opcaoParcelamento.getCodigoFormaPagamento())) {
					return cotacao.getNumeroBancoBoleto().longValue();
				} else if (FormaPagamentoEnum.DEBITO_EM_CONTA.getCodigo().equals(opcaoParcelamento.getCodigoFormaPagamento())) {
					return cotacao.getNumeroBancoDebito().longValue();
				} else {
					return null;
				}
			}
		}
		return null;
	}

}