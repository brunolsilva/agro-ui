package br.com.tokiomarine.ctpj.endosso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.auth.dto.User;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCobClausulaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCoberturaApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.enums.TipoMensagemEndossoEnum;
import br.com.tokiomarine.ctpj.util.AssertUtils;

@Service
public class EndossoItemCoberturaClausulaService {
	@Autowired
	private ValidacaoParametrosEndossoService validacaoParametrosEndossoService;
	
	@Autowired
	private AlteracoesEndossoService alteracoesEndossoService;
	
	/**
	 * prc_ctp0137
	 */
	public void validarItemCoberturaClausula(Cotacao endosso, ItemCotacao itemEndosso, ItemCobertura itemEndossoCobertura, ItemCoberturaApolice itemApoliceCobertura, List<AlteracaoEndosso> alteracoesEndossoList, User user){

		boolean endossoPossuiCoberturaClausula = itemEndossoCobertura.getListaItemCoberturaClausula() != null && !itemEndossoCobertura.getListaItemCoberturaClausula().isEmpty();
		boolean apolicePossuiCoberturaClausula = itemApoliceCobertura.getListItemCobClausulaApolice() != null && !itemApoliceCobertura.getListItemCobClausulaApolice().isEmpty();
		
		//1 - percorre as clausulas cobertura do itemEndossoCobertura e compara com os do itemApoliceCobertura
		if(endossoPossuiCoberturaClausula){			
			for(ItemCoberturaClausula itemEndossoCobtuClaus : itemEndossoCobertura.getListaItemCoberturaClausula()){
				boolean clausCobtuExiste = false;
				if(apolicePossuiCoberturaClausula){
					for(ItemCobClausulaApolice itemApolCobtuClaus : itemApoliceCobertura.getListItemCobClausulaApolice()){
						if(this.isEquals(itemEndossoCobtuClaus, itemApolCobtuClaus)){
							//valida descricao clausula
							validacaoParametrosEndossoService.compararParametrosCoberturaSemDePara(itemApolCobtuClaus.getDescricao(), itemEndossoCobtuClaus.getDescricaoClausula(),"",TipoMensagemEndossoEnum.ALT_CLAUSULA, endosso, itemEndosso, itemEndossoCobertura,alteracoesEndossoList, user);
							clausCobtuExiste = true;
							break;
						}						
					}
				}
				
				//se a cobertura clausula não existir
				if(!clausCobtuExiste){ 
					logarInclusaoClausula(itemEndossoCobtuClaus,itemEndosso,itemEndossoCobertura,endosso,alteracoesEndossoList,user);
				}					
			}
		}		
		//1 - fim
		
		//2 - percorre as clausulas cobertura da itemApoliceCobertura e compara com os do itemEndossoCobertura
		if(apolicePossuiCoberturaClausula){
			for(ItemCobClausulaApolice itemApolCobtuClaus : itemApoliceCobertura.getListItemCobClausulaApolice()){
				boolean clausCobtuExiste = false;
				if(endossoPossuiCoberturaClausula){
					for(ItemCoberturaClausula itemEndossoCobtuClaus : itemEndossoCobertura.getListaItemCoberturaClausula()){
						if(this.isEquals(itemEndossoCobtuClaus, itemApolCobtuClaus)){
							clausCobtuExiste = true;
							break;
						}
					}
				}
				
				if(!clausCobtuExiste){
					logarExclusaoClausula(itemApolCobtuClaus,itemEndosso,itemEndossoCobertura,endosso,alteracoesEndossoList,user);
				}
			}
		}
		//2 - fim
	}//
	
	private void logarInclusaoClausula(ItemCoberturaClausula itemEndossoCobtuClaus, ItemCotacao itemEndosso,ItemCobertura itemCobertura,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		String descricao = itemEndossoCobtuClaus.getCodigoClausula()+" do grupo "+itemEndossoCobtuClaus.getCodigoGrupoRamo()+" ramo "+itemEndossoCobtuClaus.getCodigoRamo();
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso, itemCobertura, TipoMensagemEndossoEnum.INC_CLAUSULA, descricao, user));
	}
	
		
	private void logarExclusaoClausula(ItemCobClausulaApolice itemApolCobtuClaus, ItemCotacao itemEndosso,ItemCobertura itemCobertura,Cotacao endosso,List<AlteracaoEndosso> alteracoesEndossoList, User user){
		String descricao = itemApolCobtuClaus.getCodigoClausulaNota()+" do grupo "+itemApolCobtuClaus.getCodigoGrupoRamo()+" ramo "+itemApolCobtuClaus.getCodigoRamo();
		alteracoesEndossoList.add(alteracoesEndossoService.bindToDomain(endosso, itemEndosso,itemCobertura, TipoMensagemEndossoEnum.EXC_CLAUSULA, descricao, user));
	}
	
	private boolean isEquals(ItemCoberturaClausula itemEndossoCobtuClaus, ItemCobClausulaApolice itemApolCobtuClaus){
		return  AssertUtils.compareNull(itemEndossoCobtuClaus.getCodigoGrupoRamo(), itemApolCobtuClaus.getCodigoGrupoRamo()) &&
				AssertUtils.compareNull(itemEndossoCobtuClaus.getCodigoRamo(), itemApolCobtuClaus.getCodigoRamo()) &&
				AssertUtils.compareNull(itemEndossoCobtuClaus.getCodigoClausula(), itemApolCobtuClaus.getCodigoClausulaNota());
	}

}
