
package br.com.tokiomarine.ctpj.integracao.crivo;

import javax.xml.bind.annotation.XmlRegistry;



@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.tokiomarine.ctpj.integracao.crivo
     *
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RequestGrandesRiscosHelperVO }
     *
     */
    public RequestGrandesRiscosHelperVO createRequestGrandesRiscosHelperVO() {
        return new RequestGrandesRiscosHelperVO();
    }

    /**
     * Create an instance of {@link ResponseGrandesRiscosHelperVO }
     *
     */
    public ResponseGrandesRiscosHelperVO createResponseGrandesRiscosHelperVO() {
        return new ResponseGrandesRiscosHelperVO();
    }

    /**
     * Create an instance of {@link ExecuteResponse }
     *
     */
    public ExecuteResponse createExecuteResponse() {
        return new ExecuteResponse();
    }

    /**
     * Create an instance of {@link Execute }
     *
     */
    public Execute createExecute() {
        return new Execute();
    }

}
