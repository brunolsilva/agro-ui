package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import br.com.tokiomarine.ctpj.exception.RepositoryException;

@Repository
public class CosseguroRepository extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(CosseguroRepository.class);

	public List<CosseguroCotacao> findCossegurosByCotacao(BigInteger cotacao) throws RepositoryException {
		StringBuilder hql = new StringBuilder();
		try {
			hql.append(" from CosseguroCotacao c");
			hql.append(" where c.cotacao.sequencialCotacaoProposta = :cotacao");

			Query query = getCurrentSession().createQuery(hql.toString());
			query.setParameter("cotacao", cotacao);

			return (List<CosseguroCotacao>)query.list();
		} catch(Exception e) {
			throw new RepositoryException(e.getMessage(), e);
		}
	}

	public void salvar(List<CosseguroCotacao> cosseguros) {
		for(CosseguroCotacao cosseguro: cosseguros) {
			getCurrentSession().save(cosseguro);
		}
	}

	public void deleteCosseguro(BigInteger sequencialCotacaoProposta) {
		logger.info("Início delete da lista de Cosseguros da Cotacao " + sequencialCotacaoProposta);

		Query query = getCurrentSession().createQuery("delete CosseguroCotacao c where c.cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta ");
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		query.executeUpdate();

		logger.info("Fim delete da lista de Cosseguros da Cotacao " + sequencialCotacaoProposta);
	}
}