package br.com.tokiomarine.ctpj.cotacao.validation;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.dto.ValidacaoLote;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoPedidoCotacaoEnum;
import br.com.tokiomarine.ctpj.infra.domain.ProdutoCaracteristica;
import br.com.tokiomarine.ctpj.infra.enums.MoedaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.security.SecurityUtils;
import br.com.tokiomarine.ctpj.util.BigDecimalUtil;
import br.com.tokiomarine.infra.componente.ambiente.util.AmbienteUtil;

@Component
public class LmiValidator {

	private static Logger logger = Logger.getLogger(LmiValidator.class);

	@LogPerformance
	public List<ValidacaoLote> validacaoBasica(Cotacao cotacao,Map<Integer,ProdutoCaracteristica> caracteristicasDoProduto) {

		logger.info("Inicio da validação básica do agrupamento LMI " + cotacao.getSequencialCotacaoProposta());

		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		if(cotacao.getListItem()
				.stream()
				.map(ItemCotacao::getIdTipoSeguro)
				.filter(it -> it == cotacao.getIdTipoSeguro())
				.count() == 0) {
			if(cotacao.getIdTipoPedidoCotacao() ==  TipoPedidoCotacaoEnum.APOLICE) {
				if(!cotacao.getCodigoProduto().equals(1851) || cotacao.getListItem().stream()
						.filter(it -> it.getNumeroItem().equals(BigInteger.ONE))
						.count() != 0) {
					listaValidacao.add(new ValidacaoLote(0,"É obrigatório que pelo menos um item tenha o tipo de seguro " + cotacao.getIdTipoSeguro().getDescricao()));
				}
			}
		}

		for(ItemCotacao item: cotacao.getListItem()) {
			if(item.getIdCEPLocalRisco() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o CEP do Local de Risco"));
			}

			if(StringUtils.isEmpty(item.getEnderecoLocalRisco())) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Endereço do Local de Risco"));
			}

			if(item.getCodigoMunicipioLocalRisco() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Município do Local de Risco"));
			}

			if(StringUtils.isEmpty(item.getIdUFLocalRisco())) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar a UF do Local de Risco"));
			}
			
			if(item.getPercentualRelacaoDMPValorRisco() == null || item.getPercentualRelacaoDMPValorRisco().compareTo(BigDecimal.ZERO) == 0) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o % DMP/VR do Local de Risco"));
			} 

			if(item.getCodigoRubrica() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar a Atividade do Local de Risco"));
			}

			if(item.getCodigoBemCoberto() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar os Bens Cobertos do Local de Risco"));
			}

			if(item.getCodigoClasseConstrucao() == null && cotacao.getCodigoProduto() != 9652) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar a Construção do Local de Risco"));
			}

			if(item.getCodigoLocalizacao() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar a Localização do Local de Risco"));
			}
			
			if(TipoEndossoEnum.EXCLUSAO_ITEM.getId().equals(item.getIdTipoEndosso()) && item.getIdSolicitanteEndosso() == null) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o solicitante do endosso"));
			}

			List<Long> protecionaisIncendio = Arrays.asList(12L,19L,24L);

			if (SecurityUtils.isCorretor() && 
					((item.getListItemSistemaProtecional() == null || item.getListItemSistemaProtecional().isEmpty())
					|| item.getListItemSistemaProtecional()
						.stream()
						.map(ItemSistemaProtecional::getCodigoSistemaProtecional)
						.filter((Long it) -> protecionaisIncendio.contains(it)).count() == 0 )) {
				listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório pelo menos um sistema protecional de incêndio"));
			}

			MoedaEnum moeda = item.getCotacao().getCodigoMoeda();

			if(moeda == MoedaEnum.REAL) {
//				if(item.getValorRiscoBem() == null) {
//					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Valor em Risco"));
//				}
				
				if(item.getValorRiscoBemCalculado() == null) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Valor em Risco"));
				} else if(SecurityUtils.isCorretor() && !item.getNumeroItem().equals(BigInteger.ONE) && item.getValorRiscoBemCalculado().compareTo(new BigDecimal("50000")) < 0) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"O valor em risco do item 1 não pode ser inferior a R$50.000,00"));
				}
				
				if(item.getValorRiscoBemCalculado() == null) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Valor em Risco"));
				}
			} else {
//				if(item.getValorRiscoBemMoedaEstrangeira() == null) {
//					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Valor em Risco"));
//				}
				
				if(item.getValorCalculadoMoedaEstrangeira() == null) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"Obrigatório Informar o Valor em Risco"));
				}
			}

			if(listaValidacao.isEmpty() && SecurityUtils.isCorretor()) {
				if(Arrays.asList(1851,1850,1852).contains(cotacao.getCodigoProduto())
						&& TipoSeguradoEnum.FISICA == cotacao.getIdTipoPessoa()
						&& Arrays.asList(2,3).contains(item.getCodigoBemCoberto())
						&& !Arrays.asList(
								37L,64L,99L,758L,760L,222L,
								721L,722L,753L,747L,316L,318L,
								752L,759L,230L,761L).contains(item.getCodigoRubrica())) {
					listaValidacao.add(
							new ValidacaoLote(
									item.getNumeroItem().intValue(),
									String.format("Para Segurado Pessoa Física, a contratação da atividade "
											+ "%s está limitada apenas para o bem coberto PRÉDIO.",item.getDescricaoRubrica())));
				}
			}

			validaVR(item);
		}

		if (cotacao.getCodigoCorretorACSEL().equals("49757")) {
			if (StringUtils.isBlank(cotacao.getNumeroMatriculaVendedor())) {
				listaValidacao.add(new ValidacaoLote(0,"Obrigatório Informar a Matrícula"));
			}

			if (StringUtils.isBlank(cotacao.getNumeroAgenciaVendedora())) {
				listaValidacao.add(new ValidacaoLote(0,"Obrigatório Informar a Agência"));
			}

			if (StringUtils.isBlank(cotacao.getNumeroContaCorrenteVendedora())) {
				listaValidacao.add(new ValidacaoLote(0,"Obrigatório Informar a Conta Corrente"));
			}
		}

		if(cotacao.getIdLmiUnico() == SimNaoEnum.SIM) {
			listaValidacao.addAll(validaSublimite(cotacao));
		}

		logger.info("Fim da validação básica do agrupamento LMI " + cotacao.getSequencialCotacaoProposta());

		return listaValidacao;
	}

	@LogPerformance
	public List<ValidacaoLote> validaSublimite(Cotacao cotacao) {
		logger.info("Inicio da validação de Sublimite LMI " + cotacao.getSequencialCotacaoProposta());

		List<ValidacaoLote> listaValidacao = new ArrayList<>();
		MoedaEnum moeda = cotacao.getCodigoMoeda();

		for(ItemCotacao item: cotacao.getListItem()) {
			for(ItemCobertura cobertura: item.getListItemCobertura()) {
				if(cobertura.getValorSublimite() != null || cobertura.getValorSublimiteMoedaEstrangeira() != null) {
					validaValorSublimite(listaValidacao, moeda, item, cobertura);
				}
			}
		}

		logger.info("Fim da validação de Sublimite LMI " + cotacao.getSequencialCotacaoProposta());
		return listaValidacao;
	}

	private void validaValorSublimite(List<ValidacaoLote> listaValidacao, MoedaEnum moeda, ItemCotacao item,
			ItemCobertura cobertura) {
		if(moeda == MoedaEnum.REAL) {
			if(BigDecimalUtil.maior(cobertura.getValorSublimite(), cobertura.getValorSublimiteOriginal())) {
				listaValidacao.add(
						new ValidacaoLote(item.getNumeroItem().intValue(), "O Valor do Sublimite da Cobertura "
								+ cobertura.getDescricaoCobertura() + " (" + cobertura.getValorSublimite() +") não pode ser maior que o Sublimite Original (" + cobertura.getValorSublimiteOriginal()  + ")"));
			}
		} else {
			if(BigDecimalUtil.maior(cobertura.getValorSublimiteMoedaEstrangeira(), cobertura.getValorSublimiteOriginalMoedaEstrangeira())) {
				listaValidacao.add(
						new ValidacaoLote(item.getNumeroItem().intValue(), "O Valor do Sublimite da Cobertura "
								+ cobertura.getDescricaoCobertura() + " (" + cobertura.getValorSublimiteMoedaEstrangeira() +") não pode ser maior que o Sublimite Original (" + cobertura.getValorSublimiteOriginalMoedaEstrangeira()  + ")"));
			}
		}
	}

	private List<ValidacaoLote> validaVR(ItemCotacao item) {
		List<ValidacaoLote> listaValidacao = new ArrayList<>();

		if(item.getCotacao().getCodigoMoeda() == MoedaEnum.REAL) {
			if(item.getValorRiscoBem() != null && item.getValorRiscoBemCalculado() != null) {
				if(BigDecimalUtil.menor(item.getValorRiscoBem(), item.getValorRiscoBemCalculado())) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"O Valor em Risco deve ser maior ou igual ao Valor em Risco Calculado"));
				}
			}

			if(item.getValorRiscoBem() != null && item.getValorMaiorRiscoIsolado() != null) {
				if(BigDecimalUtil.menor(item.getValorRiscoBem(), item.getValorMaiorRiscoIsolado())) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"O Valor em Risco deve ser maior ou igual ao Valor em Risco Isolado"));
				}
			}
		} else {
			if(item.getValorRiscoBemMoedaEstrangeira() != null && item.getValorCalculadoMoedaEstrangeira() != null) {
				if(BigDecimalUtil.menor(item.getValorRiscoBemMoedaEstrangeira(), item.getValorCalculadoMoedaEstrangeira())) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"O Valor em Risco deve ser maior ou igual ao Valor em Risco Calculado"));
				}
			}

			if(item.getValorRiscoBemMoedaEstrangeira() != null && item.getValorIsoladoMoedaEstrangeira() != null) {
				if(BigDecimalUtil.menor(item.getValorRiscoBemMoedaEstrangeira(), item.getValorIsoladoMoedaEstrangeira())) {
					listaValidacao.add(new ValidacaoLote(item.getNumeroItem().intValue(),"O Valor em Risco deve ser maior ou igual ao Valor em Risco Isolado"));
				}
			}
		}

		return listaValidacao;
	}
}