package br.com.tokiomarine.ctpj.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import br.com.tokiomarine.ctpj.dto.Validacao;

/**
 * Exceção que encapsula uma regra de negócio violada. Esta exceção contém uma lista de mensagens referentes às regras de negócio violadas
 * 
 * 
 * @author Hromenique Cezniowscki Leite Batista
 *
 */
public class NegocioException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private List<Validacao> validacoes = new ArrayList<>();
	
	public NegocioException() {
	
	}

	public NegocioException(String mensagem) {
		addValidacao(mensagem);
	}
	
	public NegocioException(String... mensagens){
		Arrays
		.asList(mensagens)
		.forEach(msg -> {
			addValidacao(msg);
		});
	}
	
	public NegocioException(Collection<String> mensagens){
		mensagens.forEach(msg ->{
			addValidacao(msg);
		});
	}

	/**
	 * Retorna uma lista de ValidacaoLote referentes às regras de negócio violadas
	 * @return List de Validacao referentes às regras de negócio violadas
	 */
	public List<Validacao> getValidacoes(){
		return this.validacoes;
	}
	
	/**
	 * Retorna uma lista de mensagens (Strings) referentes às regras de negócio violadas
	 * @return List de mensagens (Strings) referentes às regras de negócio violadas
	 */
	public List<String> getMensagens(){
		return this.validacoes.stream().map(Validacao::getDescricao).collect(Collectors.toList());
	}
	
	public void addValidacao(String mensagem){
		Validacao validacao = new Validacao(mensagem);
		this.validacoes.add(validacao);
	}
	

}
