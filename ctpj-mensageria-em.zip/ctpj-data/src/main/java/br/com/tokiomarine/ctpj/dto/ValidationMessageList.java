package br.com.tokiomarine.ctpj.dto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import br.com.tokiomarine.ctpj.domain.apolice.ParcelamentoApolice;
import br.com.tokiomarine.ctpj.dto.ValidationMessage.Type;

public class ValidationMessageList extends ArrayList<ValidationMessage> {
	private static final long serialVersionUID = 1L;	
	
	private List<ParcelamentoApolice> parcelasPendentes = new ArrayList<>();
	
	public ValidationMessageList() {
	}

	public ValidationMessageList(Collection<? extends ValidationMessage> messages) {
		super(messages);
	}

	public boolean add(String descricao, Type tipo){
		return super.add(new ValidationMessage(descricao, tipo));
	}
	
	public void add(int index, String descricao, Type tipo){
		super.add(index, new ValidationMessage(descricao, tipo));
	}	
	
	public boolean add(String descricaoResumida, String descricaoCompleta, Type tipo){
		return super.add(new ValidationMessage(descricaoResumida, descricaoCompleta, tipo));
	}
	
	public void add(int index, String descricaoResumida, String descricaoCompleta, Type tipo){
		super.add(index, new ValidationMessage(descricaoResumida, descricaoCompleta, tipo));
	}
	
	private List<ValidationMessage> filterBy(Type type){
		return this.stream().filter(item -> item.getType().equals(type)).collect(Collectors.toList());
	}
	
	public List<ValidationMessage> getErrorMessages(){
		return filterBy(Type.ERROR);
	}
	
	public List<ValidationMessage> getWarningMessages(){
		return filterBy(Type.WARNING);
	}
	
	public List<ValidationMessage> getSuccessMessages(){
		return filterBy(Type.SUCCESS);
	}
	
	public List<ValidationMessage> getInfoMessages(){
		return filterBy(Type.INFO);
	}
	
	public List<ValidationMessage> getDangerMessages(){
		return filterBy(Type.DANGER);
	}
	
	public boolean hasError(){
			return !filterBy(Type.ERROR).isEmpty();
		}

	public List<ParcelamentoApolice> getParcelasPendentes() {
		return parcelasPendentes;
	}

	public void addParcelaPendente(ParcelamentoApolice parcelaPendente) {
		this.parcelasPendentes.add(parcelaPendente);
	} 
	
}