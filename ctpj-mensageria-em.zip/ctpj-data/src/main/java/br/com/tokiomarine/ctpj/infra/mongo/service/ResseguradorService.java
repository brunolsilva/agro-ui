package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.repository.ItemCoberturaRepository;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.exception.RepositoryException;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.Ressegurador;
import br.com.tokiomarine.ctpj.infra.mongo.repository.ResseguradorRepository;

@Service
@Transactional(rollbackFor = {ServiceException.class, Exception.class})
public class ResseguradorService {
	
	private static Logger logger = LogManager.getLogger(ResseguradorService.class);

	@Autowired
	private ResseguradorRepository repository;
	
	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;

	public List<Ressegurador> findAll() throws ServiceException {
		try {
			return repository.findAll();
		} catch (RepositoryException e) {
			logger.error("Erro na Busca do Ressegurador",e);
			throw new ServiceException("Erro na Busca do Ressegurador",e);
		}
	}

	public void salvarRessegurador(PropostaView proposta) throws ServiceException {
		List<ItemCobertura> listaItensCobertura = itemCoberturaRepository.findCoberturasExigeOficio(proposta.getCotacao());

		if(listaItensCobertura != null && !listaItensCobertura.isEmpty()){
			for (ItemCobertura itemCobertura : listaItensCobertura) {
				itemCobertura.setCodigoRessegurador(proposta.getCodigoRessegurador());
				itemCobertura.setIdOficioRessegurador(proposta.getIdOficioRessegurador());
				itemCobertura.setDataEmissaoOficio(proposta.getDataEmissaoOficio());
			}

			itemCoberturaRepository.updateList(listaItensCobertura);
		}
	}
}