package br.com.tokiomarine.ctpj.cotacao.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import br.com.tokiomarine.ctpj.infra.enums.FormaFranquiaEnum;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemCoberturaFranquiaView implements Serializable {

	private static final long serialVersionUID = -8327847817076976869L;

	private BigInteger sequencialItemCobertura;
	private Integer codigoCobertura;
	private String descricaoCobertura;
	private FormaFranquiaEnum idFormaFranquia;
	private Integer numeroHorasFranquia;
	private Integer numeroDiasFranquia;
	private String taxaFranquia;
	private String valorFranquia;
	private String valorFranquiaMinima;
	private String valorFranquiaMaxima;
	private String taxaImportanciaSegurada;
	private String taxaImportanciaSeguradaMinima;
	private String taxaImportanciaSeguradaMaxima;
	private Integer idTextoFranquia;
	private BigInteger numeroCotacaoProposta;
	private Integer versaoCotacaoProposta;
	private String descricaoTextoFranquia;
	private SimNaoEnum idFranquiaInformado;
	private Boolean franquiaInformada;

	private List<ItemEquipamentoFranquiaView> listItemEquipamentoFranquia = new ArrayList<>();
	private List<ItemEquipamentoFranquiaView> listItemEquipamentoFranquiaDelete = new ArrayList<>();

	private BigInteger sequencialItemCotacao;

	public BigInteger getSequencialItemCobertura() {
		return sequencialItemCobertura;
	}

	public void setSequencialItemCobertura(BigInteger sequencialItemCobertura) {
		this.sequencialItemCobertura = sequencialItemCobertura;
	}

	public Integer getCodigoCobertura() {
		return codigoCobertura;
	}

	public void setCodigoCobertura(Integer codigoCobertura) {
		this.codigoCobertura = codigoCobertura;
	}

	public String getDescricaoCobertura() {
		return descricaoCobertura;
	}

	public void setDescricaoCobertura(String descricaoCobertura) {
		this.descricaoCobertura = descricaoCobertura;
	}

	public FormaFranquiaEnum getIdFormaFranquia() {
		return idFormaFranquia;
	}

	public void setIdFormaFranquia(FormaFranquiaEnum idFormaFranquia) {
		this.idFormaFranquia = idFormaFranquia;
	}

	public Integer getNumeroHorasFranquia() {
		return numeroHorasFranquia;
	}

	public void setNumeroHorasFranquia(Integer numeroHorasFranquia) {
		this.numeroHorasFranquia = numeroHorasFranquia;
	}

	public Integer getNumeroDiasFranquia() {
		return numeroDiasFranquia;
	}

	public void setNumeroDiasFranquia(Integer numeroDiasFranquia) {
		this.numeroDiasFranquia = numeroDiasFranquia;
	}

	public String getTaxaFranquia() {
		return taxaFranquia;
	}

	public void setTaxaFranquia(String taxaFranquia) {
		this.taxaFranquia = taxaFranquia;
	}

	public String getValorFranquia() {
		return valorFranquia;
	}

	public void setValorFranquia(String valorFranquia) {
		this.valorFranquia = valorFranquia;
	}

	public String getValorFranquiaMinima() {
		return valorFranquiaMinima;
	}

	public void setValorFranquiaMinima(String valorFranquiaMinima) {
		this.valorFranquiaMinima = valorFranquiaMinima;
	}

	public String getValorFranquiaMaxima() {
		return valorFranquiaMaxima;
	}

	public void setValorFranquiaMaxima(String valorFranquiaMaxima) {
		this.valorFranquiaMaxima = valorFranquiaMaxima;
	}

	public String getTaxaImportanciaSegurada() {
		return taxaImportanciaSegurada;
	}

	public void setTaxaImportanciaSegurada(String taxaImportanciaSegurada) {
		this.taxaImportanciaSegurada = taxaImportanciaSegurada;
	}

	public String getTaxaImportanciaSeguradaMinima() {
		return taxaImportanciaSeguradaMinima;
	}

	public void setTaxaImportanciaSeguradaMinima(String taxaImportanciaSeguradaMinima) {
		this.taxaImportanciaSeguradaMinima = taxaImportanciaSeguradaMinima;
	}

	public String getTaxaImportanciaSeguradaMaxima() {
		return taxaImportanciaSeguradaMaxima;
	}

	public void setTaxaImportanciaSeguradaMaxima(String taxaImportanciaSeguradaMaxima) {
		this.taxaImportanciaSeguradaMaxima = taxaImportanciaSeguradaMaxima;
	}

	public Integer getIdTextoFranquia() {
		return idTextoFranquia;
	}

	public void setIdTextoFranquia(Integer idTextoFranquia) {
		this.idTextoFranquia = idTextoFranquia;
	}

	public String getDescricaoTextoFranquia() {
		return descricaoTextoFranquia;
	}

	public void setDescricaoTextoFranquia(String descricaoTextoFranquia) {
		this.descricaoTextoFranquia = descricaoTextoFranquia;
	}

	public List<ItemEquipamentoFranquiaView> getListItemEquipamentoFranquia() {
		return listItemEquipamentoFranquia;
	}

	public void setListItemEquipamentoFranquia(List<ItemEquipamentoFranquiaView> listItemEquipamentoFranquia) {
		this.listItemEquipamentoFranquia = listItemEquipamentoFranquia;
	}

	public BigInteger getNumeroCotacaoProposta() {
		return numeroCotacaoProposta;
	}

	public void setNumeroCotacaoProposta(BigInteger numeroCotacaoProposta) {
		this.numeroCotacaoProposta = numeroCotacaoProposta;
	}

	public Integer getVersaoCotacaoProposta() {
		return versaoCotacaoProposta;
	}

	public void setVersaoCotacaoProposta(Integer versaoCotacaoProposta) {
		this.versaoCotacaoProposta = versaoCotacaoProposta;
	}

	public List<ItemEquipamentoFranquiaView> getListItemEquipamentoFranquiaDelete() {
		return listItemEquipamentoFranquiaDelete;
	}

	public void setListItemEquipamentoFranquiaDelete(List<ItemEquipamentoFranquiaView> listItemEquipamentoFranquiaDelete) {
		this.listItemEquipamentoFranquiaDelete = listItemEquipamentoFranquiaDelete;
	}

	public BigInteger getSequencialItemCotacao() {
		return sequencialItemCotacao;
	}

	public void setSequencialItemCotacao(BigInteger sequencialItemCotacao) {
		this.sequencialItemCotacao = sequencialItemCotacao;
	}

	public SimNaoEnum getIdFranquiaInformado() {
		return idFranquiaInformado;
	}

	public void setIdFranquiaInformado(SimNaoEnum idFranquiaInformado) {
		this.idFranquiaInformado = idFranquiaInformado;
	}

	public boolean getFranquiaInformada() {

		if (this.idFranquiaInformado == null || this.idFranquiaInformado.equals(SimNaoEnum.NAO)) {
			this.franquiaInformada = false;
		} else {
			this.franquiaInformada = true;
		}
		return franquiaInformada;
	}

	public void setFranquiaInformada(boolean franquiaInformada) {
		this.franquiaInformada = franquiaInformada;
	}

}
