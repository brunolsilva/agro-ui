package br.com.tokiomarine.ctpj.cotacao.repository;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.cliente.dto.ClientePessoa;
import br.com.tokiomarine.cliente.dto.FormaCobrancaCliente;
import br.com.tokiomarine.cliente.dto.FormaDevolucaoCliente;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteFisica;
import br.com.tokiomarine.cliente.dto.persistencia.ClienteJuridica;
import br.com.tokiomarine.corporate.docstore.cliente.DocStoreClientInfo;
import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.DocumentoDigitalView;
import br.com.tokiomarine.ctpj.cotacao.dto.PropostaView;
import br.com.tokiomarine.ctpj.cotacao.service.DevolucaoService;
import br.com.tokiomarine.ctpj.cotacao.service.InspecaoService;
import br.com.tokiomarine.ctpj.dao.BaseDAO;
import br.com.tokiomarine.ctpj.domain.cotacao.ControleFichaRegistrada;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DocumentoDigital;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.domain.cotacao.Recebimento;
import br.com.tokiomarine.ctpj.enums.DestinoEmissaoEnum;
import br.com.tokiomarine.ctpj.enums.FormaDevolucaoApoliceEnum;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import br.com.tokiomarine.ctpj.infra.enums.TipoSeguradoEnum;
import br.com.tokiomarine.ctpj.integracao.cliente.service.ClienteService;
import br.com.tokiomarine.ctpj.integracao.cliente.service.FormaCobrancaClienteService;
import br.com.tokiomarine.ctpj.integracao.cliente.service.FormaDevolucaoClienteService;
import br.com.tokiomarine.ctpj.mapper.CotacaoViewMapper;
import br.com.tokiomarine.ctpj.security.SecurityUtils;

@Repository
public class TransmissaoRepository extends BaseDAO {

	@Autowired
	private CotacaoRepository cotacaoRepository;

	@Autowired
	private ItemCoberturaRepository itemCoberturaRepository;

	@Autowired
	private RecebimentoRepository recebimentoRepository;

	@Autowired
	private ClienteService clienteService;
	
	@Autowired
	private FormaCobrancaClienteService formaCobrancaClienteService;
	
	@Autowired
	private DevolucaoService devolucaoService;
	
	@Autowired
	private FormaDevolucaoClienteService formaDevolucaoClienteService;
	
	@Autowired
	private InspecaoService inspecaoService;

	RestTemplate restTemplate = new RestTemplate();

	@LogPerformance
	public PropostaView carregaDadosProposta(BigInteger sequencialCotacaoProposta) {
		StringBuilder hql = new StringBuilder();
		hql.append(" select c.sequencialCotacaoProposta 		as sequencialCotacaoProposta, ");
		hql.append(" 		c.idTipoPessoa 						as idTipoPessoa, ");
		hql.append(" 		c.numeroCNPJCPFSegurado 			as numeroCNPJCPFSegurado, ");
		hql.append(" 		c.nomeSegurado 						as nomeSegurado, ");
		hql.append(" 		c.codigoAtividadePrincipal 			as codigoAtividadePrincipal, ");
		hql.append(" 		c.descricaoAtividadePrincipal 		as descricaoAtividadePrincipal, ");
		hql.append(" 		c.codigoSituacao		            as codigoSituacao ");
		hql.append(" 		from 			Cotacao 				c ");
		hql.append("		where 			c.sequencialCotacaoProposta = :sequencialCotacaoProposta ");

		Query query = getCurrentSession().createQuery(hql.toString());
		query.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		query.setResultTransformer(Transformers.aliasToBean(PropostaView.class));
		PropostaView proposta = (PropostaView) query.uniqueResult();

		hql = new StringBuilder();
		hql.append(
				" from OpcaoParcelamento op 	where op.cotacao.sequencialCotacaoProposta 		= :sequencialCotacaoProposta ");
		hql.append(" 								  and op.idParcelamentoEscolhido 	= :sim ");
		Query queryParcelamento = getCurrentSession().createQuery(hql.toString());
		queryParcelamento.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		queryParcelamento.setParameter("sim", SimNaoEnum.SIM);

		OpcaoParcelamento opcao = (OpcaoParcelamento) queryParcelamento.uniqueResult();
		if (opcao != null) {
			proposta.setDataVencimentoParcela(opcao.getDataVencimentoParcela());
			proposta.setValorPrimeiraParcela(opcao.getValorPrimeiraParcela());
			proposta.setQuantidadeParcelas(opcao.getQuantidadeParcelas());
			proposta.setCodigoFormaPagamento(opcao.getCodigoFormaPagamento());
			proposta.setCodigoFormaParcelamento(opcao.getCodigoFormaParcelamento());
			proposta.setFormaPagamento(opcao.getDescricaoFormaPagamento());
			proposta.setEntrada(opcao.getIdEntrada().getLogical());
		}

		Cotacao cotacao = cotacaoRepository.findById(sequencialCotacaoProposta);
		inspecaoService.popularDadosInspecaoComDadosInspecaoSct(cotacao,true);
		CotacaoView cotacaoView = CotacaoViewMapper.INSTANCE.toCotacaoView(cotacao);
		//
		proposta.setDocumentoDigital(mapDocumento(cotacao.getDocumentoDigital()));
		proposta.setCotacao(cotacaoView);

		/*
		 * a propriedade valorPrimeiraParcela vem com o valor que consta na tabela de
		 * opcaoParcelameto (do parcelamento escolhido), porém caso haja
		 * valorRecebimento na tabela de recebimento, substitui-se por este último
		 */
		Recebimento recebimento = recebimentoRepository
				.getRecebimentoByNumeroCotacaoProposta(cotacao.getNumeroCotacaoProposta());
		if (recebimento != null && recebimento.getValorRecebimento() != null
				&& recebimento.getValorRecebimento().compareTo(BigDecimal.ZERO) > 0) {
			proposta.setPossuiRecebimento(true);
			proposta.setIdTipoCredito(recebimento.getIdTipoCredito());
			proposta.setDataVencimentoParcela(recebimento.getDataProcessoCobranca());
			proposta.setValorPrimeiraParcela(recebimento.getValorRecebimento());
		}

		StringBuilder hqlFicha = new StringBuilder();
		hqlFicha.append(
				" from ControleFichaRegistrada where cotacao.sequencialCotacaoProposta = :sequencialCotacaoProposta");
		Query queryFicha = getCurrentSession().createQuery(hqlFicha.toString());
		queryFicha.setParameter("sequencialCotacaoProposta", sequencialCotacaoProposta);
		List<ControleFichaRegistrada> fichas = queryFicha.list();
		if (fichas != null && !fichas.isEmpty()) {
			ControleFichaRegistrada controleFichaRegistrada = fichas.get(0);
			if(!StringUtils.isEmpty(controleFichaRegistrada.getIdDocstoreBoleto())) {
				proposta.setUrlBoleto(
						DocStoreClientInfo.getDownloadAnexoURLExterna() + controleFichaRegistrada.getIdDocstoreBoleto());
			}
		}

		if (!SecurityUtils.isCorretor()) {
			Optional<ItemCobertura> cobertura = itemCoberturaRepository
					.findDadosRessegurador(cotacao.getSequencialCotacaoProposta());
			if (cobertura.isPresent()) {
				proposta.setCodigoRessegurador(cobertura.get().getCodigoRessegurador());
				proposta.setIdOficioRessegurador(cobertura.get().getIdOficioRessegurador());
				proposta.setDataEmissaoOficio(cobertura.get().getDataEmissaoOficio());
			}
		}

		if(DestinoEmissaoEnum.ACX == cotacao.getIdDestinoEmissao()) {
			carregarCodigoClienteService(proposta, cotacao);
			carregarDadosCliente(proposta, cotacao);
			carregarDadosPagamentoDebito(proposta, cotacao);

			carregarDadosDevolucaoCredito(proposta, cotacao);
		}
		
		return proposta;
	}

	private void carregarDadosDevolucaoCredito(PropostaView proposta, Cotacao cotacao) {
		if(cotacao.getIdDestinoEmissao().equals(DestinoEmissaoEnum.ACX) && devolucaoService.ehDevolucao(cotacao)) {
			CotacaoView cotacaoView = proposta.getCotacao();
			
			cotacaoView.setIdFormaDevolucao(cotacao.getCodigoFormaDevolucao() == null ? null : cotacao.getCodigoFormaDevolucao().getId());
			cotacaoView.setFormasDevolucaoLiberadas(formaDevolucaoClienteService.formasDevolucaoLiberadasCliente(cotacao,cotacaoView));
			if(formaDevolucaoClienteService.creditoEmContaLiberado(cotacaoView.getFormasDevolucaoLiberadas())){
				
				FormaDevolucaoCliente formaDevolucaoCliente = formaDevolucaoCreditoMaisRecente(cotacaoView);
				
				
				if(formaDevolucaoCliente == null) {
					cotacaoView.setTipoPessoaTitularContaCorrenteDevolucao(cotacaoView.getIdTipoPessoa().getId());
					cotacaoView.setNumeroCNPJCPFTitularContaCorrenteDevolucao(cotacaoView.getNumeroCNPJCPFSegurado());
					cotacaoView.setNometitularContaCorrenteDevolucao(cotacaoView.getNomeSegurado());
				}
				else {
					cotacaoView.setTipoPessoaTitularContaCorrenteDevolucao(formaDevolucaoCliente.getTpPesoaTtlarCc());
					cotacaoView.setNumeroCNPJCPFTitularContaCorrenteDevolucao(formaDevolucaoCliente.getNrCpfCnpjTtlarCc());
					cotacaoView.setNometitularContaCorrenteDevolucao(formaDevolucaoCliente.getNmTtlarCc());
					if(formaDevolucaoCliente.getCdBanco() != null) {
						cotacaoView.setNumeroBancoDevolucao(formaDevolucaoCliente.getCdBanco().intValue());	
					}
					cotacaoView.setNumeroAgenciaDevolucao(formaDevolucaoCliente.getCdAgencDebitConta());
					cotacaoView.setNumeroContaCorrenteDevolucao(formaDevolucaoCliente.getNrCcDebitConta());
					cotacaoView.setNumeroDigitoContaCorrenteDevolucao(formaDevolucaoCliente.getDvCcDebitConta());
				}
			}
		}
	}

	private FormaDevolucaoCliente formaDevolucaoCreditoMaisRecente(CotacaoView cotacaoView) {
		
		Optional<FormaDevolucaoCliente> optional = cotacaoView.getFormasDevolucaoClienteLiberadas()
															  .stream()
															  .filter(f -> FormaDevolucaoApoliceEnum.CREDITO_CONTA.getTiposDevolucao().contains(f.getTpDevol()))
															  .max(Comparator.comparing(FormaDevolucaoCliente::getIdFormaDevol));
		
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	private void carregarDadosCliente(PropostaView proposta, Cotacao cotacao) {
		if (cotacao.getCodigoCliente() != null) {
			if (cotacao.getIdTipoPessoa().equals(TipoSeguradoEnum.FISICA)) {
				ClienteFisica clienteFisica = clienteService.consultarClientePessoaFisicaPorCodigo(cotacao.getCodigoCliente());
				if (clienteFisica != null) {
					proposta.getCotacao().setIdProfissao(
							clienteFisica.getCdProfs() == null ? null : BigInteger.valueOf(clienteFisica.getCdProfs()));
					proposta.getCotacao().setEscolaridade(clienteFisica.getCdEscol());
					proposta.getCotacao().setIdRenda(clienteFisica.getFxRendaMensl() == null ? null
							: BigInteger.valueOf(clienteFisica.getFxRendaMensl()));
					proposta.getCotacao().setNomeOrgaoExpedidor(clienteFisica.getCdOrgaoEmsorDocto());
					proposta.getCotacao().setNumeroRG(clienteFisica.getCdDoctoIdent());
					proposta.getCotacao().setDataExpedicao(clienteFisica.getDtEmissDocto());
					proposta.getCotacao().setTipoDocumento(clienteFisica.getTpNatrzDocto());
					proposta.getCotacao().setTipoSexo(clienteFisica.getTpSexo());
					proposta.getCotacao().setDataNascimentoCliente(clienteFisica.getDtNascm());
					proposta.getCotacao().setEstadoCivil(clienteFisica.getTpEstadCivil());
					proposta.getCotacao().setDataExpedicao(clienteFisica.getDtEmissDocto());
					
					proposta.getCotacao().setEstrangeiro(StringUtils.isEmpty(clienteFisica.getIcEtrge()) ? SimNaoEnum.NAO : SimNaoEnum.getById(clienteFisica.getIcEtrge()));
					proposta.getCotacao().setPossuiRNE(StringUtils.isEmpty(clienteFisica.getIcRne()) ? SimNaoEnum.NAO : SimNaoEnum.getById(clienteFisica.getIcRne()));
					proposta.getCotacao().setNumeroRNE(clienteFisica.getNrRne());
					proposta.getCotacao().setNumeroPassaporte(clienteFisica.getNrPassp());
					proposta.getCotacao().setSiglaPais(clienteFisica.getNmPaisEmissPassp());
					proposta.getCotacao().setIdSeguradoPEP(StringUtils.isEmpty(clienteFisica.getPep()) ? SimNaoEnum.NAO : SimNaoEnum.getById(clienteFisica.getPep()));
				}

			} else {
				ClienteJuridica clienteJuridica = clienteService.consultarClientePessoaJuridicaPorCodigo(cotacao.getCodigoCliente());
				if (clienteJuridica != null) {
					proposta.getCotacao().setPatrimonioLiquido(clienteJuridica.getCdPatrmLiqui());
					proposta.getCotacao().setReceita(clienteJuridica.getCdRectaOprnlBrutaAnual());
					proposta.getCotacao().setRamoAtividade(clienteJuridica.getCdRmatv());
					proposta.getCotacao().setTipoEmpresa(clienteJuridica.getTpEmpr());
					proposta.getCotacao().setControlador(clienteJuridica.getExistContrAdmtrProcr());
					proposta.getCotacao().setQuantidadeControlador(clienteJuridica.getQtContrAdmtrProcr());
				}
			}
		}
	}

	private void carregarDadosPagamentoDebito(PropostaView proposta, Cotacao cotacao) {
		if (proposta.getCodigoFormaPagamento() != null) {
			if (!proposta.isExibeBoleto()) {
				if (cotacao.getCodigoCliente() == null) {
					if (cotacao.getIdFormaCobrancaPrimeiraParcela() == null) {
						preencheProponenteComoPagadorDebito(proposta, cotacao);
					}
				} else {
					FormaCobrancaCliente clienteFormaCobranca = formaCobrancaClienteService.consultarFormaCobrancaCliente(cotacao);
					if (clienteFormaCobranca == null) {
						preencheProponenteComoPagadorDebito(proposta, cotacao);
					} else {

						proposta.getCotacao().setNumeroBancoDebito(clienteFormaCobranca.getCdBanco() == null ? null
								: clienteFormaCobranca.getCdBanco().intValue());
						proposta.getCotacao().setNumeroAgenciaDebito(clienteFormaCobranca.getCdAgencDebitConta());
						proposta.getCotacao().setNumeroContaCorrenteDebito(clienteFormaCobranca.getNrCcDebitConta());
						proposta.getCotacao()
								.setNumeroDigitoContaCorrenteDebito(clienteFormaCobranca.getDvCcDebitConta());
						proposta.getCotacao()
								.setIdRelacaoPagadorDebito(clienteFormaCobranca.getTpPrntcTtlarCc() == null ? null
										: Integer.valueOf(clienteFormaCobranca.getTpPrntcTtlarCc()));
						proposta.getCotacao()
								.setTipoPessoaTitularContaCorrenteDebito(clienteFormaCobranca.getTpPesoaTtlarCc());
						proposta.getCotacao()
								.setCnpjCpfTitularContaCorrenteDebito(clienteFormaCobranca.getNrCpfCnpjTtlarCc() != null
										? clienteFormaCobranca.getNrCpfCnpjTtlarCc().toString()
										: null);
						proposta.getCotacao().setNometitularContaCorrenteDebito(clienteFormaCobranca.getNmTtlarCc());

					}
				}
				proposta.getCotacao().setPrimeiraParclDebit(pagamentoComPrimeiraParcelaDebito(cotacao).getId());				
			}
		}
	}

	private SimNaoEnum pagamentoComPrimeiraParcelaDebito(Cotacao cotacao) {
		SimNaoEnum resultado = SimNaoEnum.SIM;

		if (cotacao.getIdFormaCobranca() != null && cotacao.getIdFormaCobrancaPrimeiraParcela() != null
				&& cotacao.getIdFormaCobranca().compareTo(cotacao.getIdFormaCobrancaPrimeiraParcela()) != 0) {
			resultado = SimNaoEnum.NAO;
		}

		return resultado;
	}

	private void preencheProponenteComoPagadorDebito(PropostaView proposta, Cotacao cotacao) {
		proposta.getCotacao().setIdRelacaoPagadorDebito(10);
		proposta.getCotacao().setTipoPessoaTitularContaCorrenteDebito(cotacao.getIdTipoPessoa().getId());
		proposta.getCotacao().setCnpjCpfTitularContaCorrenteDebito(
				cotacao.getNumeroCNPJCPFSegurado() != null ? cotacao.getNumeroCNPJCPFSegurado().toString() : null);
		proposta.getCotacao().setNometitularContaCorrenteDebito(cotacao.getNomeSegurado());
	}

	private void carregarCodigoClienteService(PropostaView proposta, Cotacao cotacao) {
		if (cotacao.getCodigoCliente() == null) {

			try {
				ClientePessoa clientePessoa = clienteService.findCliente(cotacao, SecurityUtils.getCurrentUser());
				if (clientePessoa != null) {
					cotacao.setCodigoCliente(clientePessoa.getCdClien());
				}
			} catch (ServiceException e) {
				/**
				 * 
				 */
			}
		}
		
		proposta.getCotacao().setCodigoCliente(cotacao.getCodigoCliente());
	}

	private DocumentoDigitalView mapDocumento(DocumentoDigital documentoDigital) {
		if (documentoDigital != null) {
			DocumentoDigitalView documentoDigitalView = new DocumentoDigitalView();
			documentoDigitalView.setDestino(documentoDigital.getDestino().getId());
			documentoDigitalView.setIdEnvioSegurado(documentoDigital.getIdEnvioSegurado());
			documentoDigitalView.setEmailCorretor(documentoDigital.getEmailCorretor());
			documentoDigitalView.setEmailSegurado(documentoDigital.getEmailSegurado());
			documentoDigitalView.setFormaEnvio(documentoDigital.getFormaEnvio().getId());
			return documentoDigitalView;
		}
		return new DocumentoDigitalView();
	}

	public void salvar(Cotacao cotacao) {
		cotacaoRepository.update(cotacao);
	}

	public Optional<String> urlBoleto(BigInteger numeroCotacaoProposta) {
		StringBuilder hqlFicha = new StringBuilder();
		hqlFicha.append(" from		ControleFichaRegistrada ");
		hqlFicha.append(" where 	cotacao.numeroCotacaoProposta	=	:numeroCotacaoProposta ");
		hqlFicha.append(" and		cotacao.versaoCotacaoProposta	=	1 ");
		Query queryFicha = getCurrentSession().createQuery(hqlFicha.toString());
		queryFicha.setParameter("numeroCotacaoProposta", numeroCotacaoProposta);
		List<ControleFichaRegistrada> fichas = queryFicha.list();
		if (fichas != null && !fichas.isEmpty()) {
			return Optional.of(DocStoreClientInfo.getDownloadAnexoURLExterna() + fichas.get(0).getIdDocstoreBoleto());
		}

		return Optional.empty();
	}

	public void salvarAcsel(Cotacao cotacao) throws ServiceException {
		try {
			cotacaoRepository.updateTransmissao(cotacao);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage(), e);
		}
	}
}
