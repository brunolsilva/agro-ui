package br.com.tokiomarine.ctpj.infra.mongo.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.ctpj.aop.LogPerformance;
import br.com.tokiomarine.ctpj.exception.ServiceException;
import br.com.tokiomarine.ctpj.infra.domain.CapitalSocial;
import br.com.tokiomarine.ctpj.infra.domain.FaturamentoPresumido;
import br.com.tokiomarine.ctpj.infra.domain.PaisOrigem;
import br.com.tokiomarine.ctpj.infra.domain.Patrimonio;
import br.com.tokiomarine.ctpj.infra.domain.Profissao;
import br.com.tokiomarine.ctpj.infra.domain.Renda;
import br.com.tokiomarine.ctpj.infra.mongo.repository.PldRepository;

@Service
public class PldService {

	private static Logger logger = LogManager.getLogger(PldService.class);

	@Autowired
	private PldRepository pldRepository;

	@LogPerformance
	//@Cacheable("capitalSocial")
	public List<CapitalSocial> listarCapitalSocial() throws ServiceException {
		try {
			return pldRepository.listarCapitalSocial();
		} catch (Exception e) {
			logger.error("Erro ao listar CapitalSocial ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	//@Cacheable("profissao")
	public List<Profissao> listarProfissao() throws ServiceException {
		try {
			return pldRepository.listarProfissao();
		} catch (Exception e) {
			logger.error("Erro ao listar Profissao ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	//@Cacheable("pais")
	public List<PaisOrigem> listarPais() throws ServiceException {
		try {
			return pldRepository.listarPais();
		} catch (Exception e) {
			logger.error("Erro ao listar País ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	//@Cacheable("faturamentoPresumido")
	public List<FaturamentoPresumido> listarFaturamentoPresumido() throws ServiceException {
		try {
			return pldRepository.listarFaturamentoPresumido();
		} catch (Exception e) {
			logger.error("Erro ao listar FaturamentoPresumido ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	//@Cacheable("patrimonio")
	public List<Patrimonio> listarPatrimonio() throws ServiceException {
		try {
			return pldRepository.listarPatrimonio();
		} catch (Exception e) {
			logger.error("Erro ao listar Patrimonio ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}

	@LogPerformance
	//@Cacheable("renda")
	public List<Renda> listarRenda() throws ServiceException {
		try {
			return pldRepository.listarRenda();
		} catch (Exception e) {
			logger.error("Erro ao listar Renda ", e);
			throw new ServiceException(e.getMessage(), e);
		}
	}
}