# CTPJ

Módulo de cotação de produtos PJ.

### Rodando Local

1. Adicione as seguintes variáveis de ambiente ao Wildfly:

#### COTD: 

Variável: `AMBIENTE`
Valor: `INTERNO`

Variável: `HAZELCAST_URL`
Valor: `dev;Tokio*123;srvdocker01d.tokiomarine.com.br:5701|srvdocker02d.tokiomarine.com.br:5701|srvdocker03d.tokiomarine.com.br:5701`


Variável: `MONGO_URL`
Valor: `mongodb01d.tokiomarine.com.br:27017;mongodb01d.tokiomarine.com.br:27017;mongodb01d.tokiomarine.com.br:27017`

Variável: `CTPJ_BACKOFFICE_PASSWORD`
Valor: `tokio123`

Variável: `CTPJ_FORMALIZACAO_PASSWORD`
Valor: `tokio123`
 
Variável: `CTPJ_PASSWORD`
Valor: `tokio123`

#### PTMD:

[WIP]

### Rodando no WildFly

1. Seguir passos: [Manual de Instalação de ambiente de desenvolvimento Java 8 + Wildfly 10](http://gitlab.tokiomarine.com.br/arquitetura-sistemas/docs/wikis/wildfly)
2. Adicionar o arquivo `ctpj.war` na pasta `{wildfly_home}/standalone/deployments`
3. Acesse o sistema: `http://localhost:8080/ems_corporate_cotador/ctpj`