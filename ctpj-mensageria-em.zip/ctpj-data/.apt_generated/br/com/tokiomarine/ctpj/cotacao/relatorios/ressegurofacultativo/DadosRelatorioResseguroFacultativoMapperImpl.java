package br.com.tokiomarine.ctpj.cotacao.relatorios.ressegurofacultativo;

import br.com.tokiomarine.ctpj.cotacao.dto.DadosCotacaoParaResseguroFacultativo;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;
import br.com.tokiomarine.ctpj.infra.enums.SimNaoEnum;
import java.math.BigInteger;
import javax.annotation.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
@Component
public class DadosRelatorioResseguroFacultativoMapperImpl extends DadosRelatorioResseguroFacultativoMapper {

    @Override
    public DadosRelatorioResseguroFacultativo toDadosRelatorio(ResseguroFacultativo ressegFacul, DadosCotacaoParaResseguroFacultativo dadosCotacao) {
        if ( ressegFacul == null && dadosCotacao == null ) {
            return null;
        }

        DadosRelatorioResseguroFacultativo dadosRelatorioResseguroFacultativo = new DadosRelatorioResseguroFacultativo();

        if ( ressegFacul != null ) {
            dadosRelatorioResseguroFacultativo.setNroParcelasResseguro( ressegFacul.getNumeroParcelasResseguro() );
            dadosRelatorioResseguroFacultativo.setData( ressegFacul.getDataPreenchimento() );
            dadosRelatorioResseguroFacultativo.setBrokerAdicional( ressegFacul.getDescricaoBrokerAdicional() );
            dadosRelatorioResseguroFacultativo.setIdCessao( ressegFacul.getIdCessao() );
            dadosRelatorioResseguroFacultativo.setSecurity( ressegFacul.getDescricaoSecurity() );
            dadosRelatorioResseguroFacultativo.setPorcentagemUtilizacaoContratoAutomatico( ressegFacul.getPercentualUtilizacaoContratoAutomatico() );
            dadosRelatorioResseguroFacultativo.setSeqCotacao( ressegFaculCotacaoSequencialCotacaoProposta( ressegFacul ) );
            dadosRelatorioResseguroFacultativo.setNroParcelasSeguro( ressegFacul.getNumeroParcelasSeguro() );
            dadosRelatorioResseguroFacultativo.setReintegracaoAutomaticaNaAP( ressegFaculReintegracaoAutomaticaLogical( ressegFacul ) );
            dadosRelatorioResseguroFacultativo.setPorcentagemUtilizadoLimiteTecnico( ressegFacul.getPercentualUtilizadoLimiteTecnico() );
            dadosRelatorioResseguroFacultativo.setTipoResseguro( ressegFacul.getTipoResseguro() );
            dadosRelatorioResseguroFacultativo.setObservacoes( ressegFacul.getObservacoes() );
            dadosRelatorioResseguroFacultativo.setPercentualCedidoIntraGrupo( ressegFacul.getPercentualCedidoIntraGrupo() );
            dadosRelatorioResseguroFacultativo.setPercentualCessaoLocal( ressegFacul.getPercentualCessaoLocal() );
        }
        if ( dadosCotacao != null ) {
            dadosRelatorioResseguroFacultativo.setPorcentagemCosseguro( dadosCotacao.getPercentualCosseguro() );
            dadosRelatorioResseguroFacultativo.setCosseguro( dadosCotacao.getTipoCosseguro() );
            dadosRelatorioResseguroFacultativo.setPremioSeguro( dadosCotacao.getPremioSeguro() );
            dadosRelatorioResseguroFacultativo.setInicioVigencia( dadosCotacao.getInicioVigencia() );
            dadosRelatorioResseguroFacultativo.setApolice( dadosCotacao.getApolice() );
            dadosRelatorioResseguroFacultativo.setSegurado( dadosCotacao.getSegurado() );
            dadosRelatorioResseguroFacultativo.setRamo( dadosCotacao.getRamo() );
            dadosRelatorioResseguroFacultativo.setValorLmrLmg( dadosCotacao.getValorLmrLmg() );
            dadosRelatorioResseguroFacultativo.setFimVigencia( dadosCotacao.getFimVigencia() );
            dadosRelatorioResseguroFacultativo.setMoeda( dadosCotacao.getMoeda() );
            dadosRelatorioResseguroFacultativo.setSubscritor( dadosCotacao.getSubscritor() );
        }

        setBroker( dadosRelatorioResseguroFacultativo, ressegFacul );
        setFaixas( dadosRelatorioResseguroFacultativo, ressegFacul );
        setDistribuicoes( dadosRelatorioResseguroFacultativo, ressegFacul );

        return dadosRelatorioResseguroFacultativo;
    }

    private BigInteger ressegFaculCotacaoSequencialCotacaoProposta(ResseguroFacultativo resseguroFacultativo) {

        if ( resseguroFacultativo == null ) {
            return null;
        }
        Cotacao cotacao = resseguroFacultativo.getCotacao();
        if ( cotacao == null ) {
            return null;
        }
        BigInteger sequencialCotacaoProposta = cotacao.getSequencialCotacaoProposta();
        if ( sequencialCotacaoProposta == null ) {
            return null;
        }
        return sequencialCotacaoProposta;
    }

    private Boolean ressegFaculReintegracaoAutomaticaLogical(ResseguroFacultativo resseguroFacultativo) {

        if ( resseguroFacultativo == null ) {
            return null;
        }
        SimNaoEnum reintegracaoAutomatica = resseguroFacultativo.getReintegracaoAutomatica();
        if ( reintegracaoAutomatica == null ) {
            return null;
        }
        Boolean logical = reintegracaoAutomatica.getLogical();
        if ( logical == null ) {
            return null;
        }
        return logical;
    }
}
