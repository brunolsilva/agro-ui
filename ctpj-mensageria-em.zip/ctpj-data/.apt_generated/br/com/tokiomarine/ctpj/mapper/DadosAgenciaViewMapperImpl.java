package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.CobrancaAgenciaResponse;
import br.com.tokiomarine.ctpj.cotacao.dto.DadosAgenciaView;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class DadosAgenciaViewMapperImpl extends DadosAgenciaViewMapper {

    @Override
    public DadosAgenciaView toDadosAgenciaView(CobrancaAgenciaResponse cobrancaAgenciaResponse) {
        if ( cobrancaAgenciaResponse == null ) {
            return null;
        }

        DadosAgenciaView dadosAgenciaView = new DadosAgenciaView();

        dadosAgenciaView.setP_nr_telefone( cobrancaAgenciaResponse.getTelefone() );
        dadosAgenciaView.setP_nm_agencia( cobrancaAgenciaResponse.getNomeAgencia() );
        dadosAgenciaView.setP_ds_bairro( cobrancaAgenciaResponse.getBairro() );
        dadosAgenciaView.setP_ds_cidade( cobrancaAgenciaResponse.getCidade() );
        dadosAgenciaView.setP_cd_cep( cobrancaAgenciaResponse.getCep() );
        dadosAgenciaView.setP_ds_endereco( cobrancaAgenciaResponse.getEndereco() );

        return dadosAgenciaView;
    }
}
