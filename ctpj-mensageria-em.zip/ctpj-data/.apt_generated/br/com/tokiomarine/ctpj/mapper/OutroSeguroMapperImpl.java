package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemOutroSeguroView;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class OutroSeguroMapperImpl implements OutroSeguroMapper {

    @Override
    public ItemOutroSeguroView toOSView(ItemOutroSeguro os) {
        if ( os == null ) {
            return null;
        }

        ItemOutroSeguroView itemOutroSeguroView = new ItemOutroSeguroView();

        itemOutroSeguroView.setNumeroItem( osItemCotacaoNumeroItem( os ).intValue() );
        itemOutroSeguroView.setSequencialItemOutroSeguro( os.getSequencialItemOutroSeguro() );
        itemOutroSeguroView.setCodigoCompanhiaSeguradora( os.getCodigoCompanhiaSeguradora() );
        itemOutroSeguroView.setNomeCompanhiaSeguradora( os.getNomeCompanhiaSeguradora() );
        itemOutroSeguroView.setNumeroApolice( os.getNumeroApolice() );
        itemOutroSeguroView.setValorLMG( os.getValorLMG() );
        itemOutroSeguroView.setDataFimVigencia( os.getDataFimVigencia() );

        return itemOutroSeguroView;
    }

    @Override
    public List<ItemOutroSeguroView> toOSView(List<ItemOutroSeguro> os) {
        if ( os == null ) {
            return null;
        }

        List<ItemOutroSeguroView> list = new ArrayList<ItemOutroSeguroView>();
        for ( ItemOutroSeguro itemOutroSeguro : os ) {
            list.add( toOSView( itemOutroSeguro ) );
        }

        return list;
    }

    private BigInteger osItemCotacaoNumeroItem(ItemOutroSeguro itemOutroSeguro) {

        if ( itemOutroSeguro == null ) {
            return null;
        }
        ItemCotacao itemCotacao = itemOutroSeguro.getItemCotacao();
        if ( itemCotacao == null ) {
            return null;
        }
        BigInteger numeroItem = itemCotacao.getNumeroItem();
        if ( numeroItem == null ) {
            return null;
        }
        return numeroItem;
    }
}
