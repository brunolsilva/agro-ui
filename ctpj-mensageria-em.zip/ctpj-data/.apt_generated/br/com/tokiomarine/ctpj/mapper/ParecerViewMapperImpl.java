package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.ParecerView;
import br.com.tokiomarine.ctpj.domain.cotacao.ParecerCotacao;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class ParecerViewMapperImpl implements ParecerViewMapper {

    @Override
    public ParecerView toParecerView(ParecerCotacao parecer) {
        if ( parecer == null ) {
            return null;
        }

        ParecerView parecerView = new ParecerView();

        parecerView.setNumeroCotacaoProposta( parecer.getNumeroCotacaoProposta() );
        parecerView.setVersaoCotacaoProposta( parecer.getVersaoCotacaoProposta() );
        parecerView.setSequencialParecerCotacao( parecer.getSequencialParecerCotacao() );
        parecerView.setDescricaoParecer( parecer.getDescricaoParecer() );
        parecerView.setDataParecer( parecer.getDataParecer() );
        parecerView.setNumeroParecer( parecer.getNumeroParecer() );
        parecerView.setDataAtualizacao( parecer.getDataAtualizacao() );
        parecerView.setCodigoGrupo( parecer.getCodigoGrupo() );
        parecerView.setUsuarioAtualizacao( parecer.getUsuarioAtualizacao() );

        return parecerView;
    }

    @Override
    public List<ParecerView> toPareceresView(List<ParecerCotacao> pareceres) {
        if ( pareceres == null ) {
            return null;
        }

        List<ParecerView> list = new ArrayList<ParecerView>();
        for ( ParecerCotacao parecerCotacao : pareceres ) {
            list.add( toParecerView( parecerCotacao ) );
        }

        return list;
    }

    @Override
    public ParecerCotacao toParecerCotacao(ParecerView parecerView) {
        if ( parecerView == null ) {
            return null;
        }

        ParecerCotacao parecerCotacao = new ParecerCotacao();

        parecerCotacao.setCodigoGrupo( parecerView.getCodigoGrupo() );
        parecerCotacao.setDataAtualizacao( parecerView.getDataAtualizacao() );
        parecerCotacao.setUsuarioAtualizacao( parecerView.getUsuarioAtualizacao() );
        parecerCotacao.setNumeroCotacaoProposta( parecerView.getNumeroCotacaoProposta() );
        parecerCotacao.setVersaoCotacaoProposta( parecerView.getVersaoCotacaoProposta() );
        parecerCotacao.setDataParecer( parecerView.getDataParecer() );
        parecerCotacao.setDescricaoParecer( parecerView.getDescricaoParecer() );
        parecerCotacao.setNumeroParecer( parecerView.getNumeroParecer() );
        parecerCotacao.setSequencialParecerCotacao( parecerView.getSequencialParecerCotacao() );

        return parecerCotacao;
    }

    @Override
    public List<ParecerView> toPareceresCotacao(List<ParecerView> pareceresView) {
        if ( pareceresView == null ) {
            return null;
        }

        List<ParecerView> list = new ArrayList<ParecerView>();
        for ( ParecerView parecerView : pareceresView ) {
            list.add( parecerView );
        }

        return list;
    }
}
