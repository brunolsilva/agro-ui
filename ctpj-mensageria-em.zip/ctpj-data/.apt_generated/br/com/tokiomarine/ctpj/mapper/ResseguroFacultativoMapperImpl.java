package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoCessaoForm;
import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoFaixaForm;
import br.com.tokiomarine.ctpj.cotacao.dto.ResseguroFacultativoForm;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativo;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativoCessao;
import br.com.tokiomarine.ctpj.domain.cotacao.ResseguroFacultativoFaixa;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:14-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
@Component
public class ResseguroFacultativoMapperImpl extends ResseguroFacultativoMapper {

    @Autowired
    private SimNaoMapper2 simNaoMapper2;

    @Override
    public ResseguroFacultativo toResseguroFacultativo(ResseguroFacultativoForm source, Cotacao cotacao) {
        if ( source == null && cotacao == null ) {
            return null;
        }

        ResseguroFacultativo resseguroFacultativo = new ResseguroFacultativo();

        if ( source != null ) {
            resseguroFacultativo.setDescricaoBrokerAdicional( source.getBrokenAdicional() );
            resseguroFacultativo.setRessegurosFacultativosCessao( resseguroFacultativoCessaoFormListToResseguroFacultativoCessaoList( source.getResseguroFacultativoCessaoList() ) );
            resseguroFacultativo.setReintegracaoAutomatica( simNaoMapper2.toEnum( source.isReintegracaoAutomaticaNaAP() ) );
            resseguroFacultativo.setCodigoBroker( source.getCodigoBroker() );
            resseguroFacultativo.setIdCessao( source.getIdCessao() );
            resseguroFacultativo.setNumeroParcelasResseguro( source.getNumeroParcelasResseguro() );
            resseguroFacultativo.setNumeroParcelasSeguro( source.getNumeroParcelasSeguro() );
            resseguroFacultativo.setObservacoes( source.getObservacoes() );
            resseguroFacultativo.setPercentualCedidoIntraGrupo( source.getPercentualCedidoIntraGrupo() );
            resseguroFacultativo.setPercentualCessaoLocal( source.getPercentualCessaoLocal() );
            resseguroFacultativo.setPercentualUtilizacaoContratoAutomatico( source.getPercentualUtilizacaoContratoAutomatico() );
            resseguroFacultativo.setPercentualUtilizadoLimiteTecnico( source.getPercentualUtilizadoLimiteTecnico() );
            resseguroFacultativo.setTipoResseguro( source.getTipoResseguro() );
        }
        if ( cotacao != null ) {
            resseguroFacultativo.setCotacao( cotacao );
            resseguroFacultativo.setCodigoGrupo( cotacao.getCodigoGrupo() );
            resseguroFacultativo.setDataAtualizacao( cotacao.getDataAtualizacao() );
            resseguroFacultativo.setUsuarioAtualizacao( cotacao.getUsuarioAtualizacao() );
            resseguroFacultativo.setNumeroCotacaoProposta( cotacao.getNumeroCotacaoProposta() );
            resseguroFacultativo.setVersaoCotacaoProposta( cotacao.getVersaoCotacaoProposta() );
        }
        resseguroFacultativo.setDataPreenchimento( new java.util.Date() );

        setDadosBasicosDaCotacao( resseguroFacultativo );
        setBrokerESecurity( resseguroFacultativo );
        setRelacionamentosBidirecionais( resseguroFacultativo );
        setNumeroItemFaixa( resseguroFacultativo );

        return resseguroFacultativo;
    }

    @Override
    public ResseguroFacultativoCessao toResseguroFacultativoCessao(ResseguroFacultativoCessaoForm source) {
        if ( source == null ) {
            return null;
        }

        ResseguroFacultativoCessao resseguroFacultativoCessao_ = new ResseguroFacultativoCessao();

        resseguroFacultativoCessao_.setFaixas( resseguroFacultativoFaixaFormListToResseguroFacultativoFaixaList( source.getResseguroFacultativoFaixaList() ) );
        resseguroFacultativoCessao_.setNumeroItemFaixa( source.getNumeroItemFaixa() );
        resseguroFacultativoCessao_.setPercentualCedido( source.getPercentualCedido() );
        resseguroFacultativoCessao_.setPercentualRetido( source.getPercentualRetido() );
        resseguroFacultativoCessao_.setValorFinal( source.getValorFinal() );
        resseguroFacultativoCessao_.setValorInicial( source.getValorInicial() );

        setNumeroItemFaixa( resseguroFacultativoCessao_ );

        return resseguroFacultativoCessao_;
    }

    @Override
    public ResseguroFacultativoFaixa toResseguroFacultativoFaixa(ResseguroFacultativoFaixaForm source) {
        if ( source == null ) {
            return null;
        }

        ResseguroFacultativoFaixa resseguroFacultativoFaixa_ = new ResseguroFacultativoFaixa();

        if ( source.getCodigoRessegurador() != null ) {
            resseguroFacultativoFaixa_.setCodigoRessegurador( source.getCodigoRessegurador().longValue() );
        }
        resseguroFacultativoFaixa_.setNumeroItemFaixa( source.getNumeroItemFaixa() );
        resseguroFacultativoFaixa_.setPercentualComissaoRessegurador( source.getPercentualComissaoRessegurador() );
        resseguroFacultativoFaixa_.setPercentualParticipacao( source.getPercentualParticipacao() );
        resseguroFacultativoFaixa_.setValorPremioRessegurador( source.getValorPremioRessegurador() );

        setValorPremioLiquidoRessegurador( resseguroFacultativoFaixa_ );
        setRessegurador( resseguroFacultativoFaixa_ );

        return resseguroFacultativoFaixa_;
    }

    protected List<ResseguroFacultativoCessao> resseguroFacultativoCessaoFormListToResseguroFacultativoCessaoList(List<ResseguroFacultativoCessaoForm> list) {
        if ( list == null ) {
            return null;
        }

        List<ResseguroFacultativoCessao> list_ = new ArrayList<ResseguroFacultativoCessao>();
        for ( ResseguroFacultativoCessaoForm resseguroFacultativoCessaoForm : list ) {
            list_.add( toResseguroFacultativoCessao( resseguroFacultativoCessaoForm ) );
        }

        return list_;
    }

    protected List<ResseguroFacultativoFaixa> resseguroFacultativoFaixaFormListToResseguroFacultativoFaixaList(List<ResseguroFacultativoFaixaForm> list) {
        if ( list == null ) {
            return null;
        }

        List<ResseguroFacultativoFaixa> list_ = new ArrayList<ResseguroFacultativoFaixa>();
        for ( ResseguroFacultativoFaixaForm resseguroFacultativoFaixaForm : list ) {
            list_.add( toResseguroFacultativoFaixa( resseguroFacultativoFaixaForm ) );
        }

        return list_;
    }
}
