package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoAgravacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.mongo.ItemCoberturaRegistroMemoriaCalculo;
import br.com.tokiomarine.ctpj.domain.mongo.ItemCotacaoRegistroMemoriaCalculo;
import br.com.tokiomarine.ctpj.domain.mongo.ItemDescAgravacaoRegMemoriaCalculo;
import br.com.tokiomarine.ctpj.domain.mongo.MemoriaCalculo;
import br.com.tokiomarine.ctpj.domain.mongo.RegistroMemoriaCalculo;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class MemoriaCalculoMapperImpl extends MemoriaCalculoMapper {

    @Override
    public RegistroMemoriaCalculo toRegistroMemoriaCalculo(Cotacao source) {
        if ( source == null ) {
            return null;
        }

        RegistroMemoriaCalculo registroMemoriaCalculo = new RegistroMemoriaCalculo();

        registroMemoriaCalculo.setItensCotacao( itemCotacaoSetToItemCotacaoRegistroMemoriaCalculoList( source.getListItem() ) );

        registroMemoriaCalculo.setDataCalculo( new java.util.Date() );

        return registroMemoriaCalculo;
    }

    @Override
    protected MemoriaCalculo toMemoriaCalculo(Cotacao source) {
        if ( source == null ) {
            return null;
        }

        MemoriaCalculo memoriaCalculo = new MemoriaCalculo();

        memoriaCalculo.setDataCotacao( source.getDataCotacao() );
        memoriaCalculo.setNumeroCotacaoProposta( source.getNumeroCotacaoProposta() );
        memoriaCalculo.setSequencialCotacaoProposta( source.getSequencialCotacaoProposta() );
        memoriaCalculo.setVersaoCotacaoProposta( source.getVersaoCotacaoProposta() );

        return memoriaCalculo;
    }

    @Override
    protected ItemCotacaoRegistroMemoriaCalculo toItemCotacaoRegistroMemoriaCalculo(ItemCotacao source) {
        if ( source == null ) {
            return null;
        }

        ItemCotacaoRegistroMemoriaCalculo itemCotacaoRegistroMemoriaCalculo_ = new ItemCotacaoRegistroMemoriaCalculo();

        itemCotacaoRegistroMemoriaCalculo_.setCoberturas( itemCoberturaSetToItemCoberturaRegistroMemoriaCalculoList( source.getListItemCobertura() ) );
        itemCotacaoRegistroMemoriaCalculo_.setDescricaoAtividadePrincipal( source.getDescricaoAtividadePrincipal() );
        itemCotacaoRegistroMemoriaCalculo_.setNumeroItem( source.getNumeroItem() );
        itemCotacaoRegistroMemoriaCalculo_.setSequencialItemCotacao( source.getSequencialItemCotacao() );

        return itemCotacaoRegistroMemoriaCalculo_;
    }

    @Override
    protected ItemCoberturaRegistroMemoriaCalculo toItemCoberturaRegistroMemoriaCalculo(ItemCobertura source) {
        if ( source == null ) {
            return null;
        }

        ItemCoberturaRegistroMemoriaCalculo itemCoberturaRegistroMemoriaCalculo_ = new ItemCoberturaRegistroMemoriaCalculo();

        itemCoberturaRegistroMemoriaCalculo_.setDescontosAgravacao( descontoAgravacaoListToItemDescAgravacaoRegMemoriaCalculoList( source.getListDescontoAgravacao() ) );
        if ( source.getCodigoCobertura() != null ) {
            itemCoberturaRegistroMemoriaCalculo_.setCodigoCobertura( BigInteger.valueOf( source.getCodigoCobertura() ) );
        }
        itemCoberturaRegistroMemoriaCalculo_.setDescricaoCobertura( source.getDescricaoCobertura() );
        itemCoberturaRegistroMemoriaCalculo_.setPercentualTaxaCalculoPremio( source.getPercentualTaxaCalculoPremio() );
        itemCoberturaRegistroMemoriaCalculo_.setSequencialItemCobertura( source.getSequencialItemCobertura() );
        itemCoberturaRegistroMemoriaCalculo_.setValorImportanciaSegurada( source.getValorImportanciaSegurada() );
        itemCoberturaRegistroMemoriaCalculo_.setValorPremio( source.getValorPremio() );
        itemCoberturaRegistroMemoriaCalculo_.setValorPremioNET( source.getValorPremioNET() );
        itemCoberturaRegistroMemoriaCalculo_.setValorPremioVigencia( source.getValorPremioVigencia() );
        itemCoberturaRegistroMemoriaCalculo_.setValorRiscoBem( source.getValorRiscoBem() );
        itemCoberturaRegistroMemoriaCalculo_.setValorSublimite( source.getValorSublimite() );

        return itemCoberturaRegistroMemoriaCalculo_;
    }

    @Override
    protected ItemDescAgravacaoRegMemoriaCalculo toItemDescAgravacaoRegMemoriaCalculo(DescontoAgravacao source) {
        if ( source == null ) {
            return null;
        }

        ItemDescAgravacaoRegMemoriaCalculo itemDescAgravacaoRegMemoriaCalculo_ = new ItemDescAgravacaoRegMemoriaCalculo();

        itemDescAgravacaoRegMemoriaCalculo_.setDescricaoDescontoAgravacao( source.getDescricaoDescontoAgravacao() );
        itemDescAgravacaoRegMemoriaCalculo_.setPercentualDescontoAgravacao( source.getPercentualDescontoAgravacao() );
        itemDescAgravacaoRegMemoriaCalculo_.setSequencialItemCoberturaDescontoAgravacao( source.getSequencialItemCoberturaDescontoAgravacao() );

        return itemDescAgravacaoRegMemoriaCalculo_;
    }

    protected List<ItemCotacaoRegistroMemoriaCalculo> itemCotacaoSetToItemCotacaoRegistroMemoriaCalculoList(Set<ItemCotacao> set) {
        if ( set == null ) {
            return null;
        }

        List<ItemCotacaoRegistroMemoriaCalculo> list = new ArrayList<ItemCotacaoRegistroMemoriaCalculo>();
        for ( ItemCotacao itemCotacao : set ) {
            list.add( toItemCotacaoRegistroMemoriaCalculo( itemCotacao ) );
        }

        return list;
    }

    protected List<ItemCoberturaRegistroMemoriaCalculo> itemCoberturaSetToItemCoberturaRegistroMemoriaCalculoList(Set<ItemCobertura> set) {
        if ( set == null ) {
            return null;
        }

        List<ItemCoberturaRegistroMemoriaCalculo> list = new ArrayList<ItemCoberturaRegistroMemoriaCalculo>();
        for ( ItemCobertura itemCobertura : set ) {
            list.add( toItemCoberturaRegistroMemoriaCalculo( itemCobertura ) );
        }

        return list;
    }

    protected List<ItemDescAgravacaoRegMemoriaCalculo> descontoAgravacaoListToItemDescAgravacaoRegMemoriaCalculoList(List<DescontoAgravacao> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemDescAgravacaoRegMemoriaCalculo> list_ = new ArrayList<ItemDescAgravacaoRegMemoriaCalculo>();
        for ( DescontoAgravacao descontoAgravacao : list ) {
            list_.add( toItemDescAgravacaoRegMemoriaCalculo( descontoAgravacao ) );
        }

        return list_;
    }
}
