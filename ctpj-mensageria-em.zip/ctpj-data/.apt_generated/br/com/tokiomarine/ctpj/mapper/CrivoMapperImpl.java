package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.DadosCrivo;
import br.com.tokiomarine.ctpj.integracao.crivo.ResponseGrandesRiscosHelperVO;
import br.com.tokiomarine.ctpj.integracao.crivorest.CrivoRestResponse;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CrivoMapperImpl extends CrivoMapper {

    @Override
    public DadosCrivo toDadosCrivo(ResponseGrandesRiscosHelperVO source) {
        if ( source == null ) {
            return null;
        }

        DadosCrivo dadosCrivo = new DadosCrivo();

        dadosCrivo.setCidade( source.getCidadeSRF() );
        dadosCrivo.setIdCnae( source.getCodCNAE() );
        dadosCrivo.setBairro( source.getBairroSRF() );
        dadosCrivo.setIdEvento( source.getCodEvent() );
        dadosCrivo.setCep( source.getCepSRF() );
        dadosCrivo.setAtividade( source.getNmAtividade() );
        dadosCrivo.setUf( source.getUfSRF() );
        dadosCrivo.setEvento( source.getDscEvent() );
        dadosCrivo.setRetorno( source.getCodReturn() );
        dadosCrivo.setLogradouro( source.getLogradrouSRF() );
        dadosCrivo.setOperacao( source.getCodOperacao() );
        dadosCrivo.setNrLogradouro( source.getNrLogradouroSRF() );
        dadosCrivo.setRazaoSocial( source.getNmRazaoSocial() );

        posMapping( dadosCrivo );

        return dadosCrivo;
    }

    @Override
    public DadosCrivo toDadosCrivo(CrivoRestResponse source) {
        if ( source == null ) {
            return null;
        }

        DadosCrivo dadosCrivo = new DadosCrivo();

        dadosCrivo.setAtividade( source.getDsNaturezaJuridica() );
        dadosCrivo.setEvento( source.getMsgEvent() );
        if ( source.getCodRetorno() != null ) {
            dadosCrivo.setRetorno( String.valueOf( source.getCodRetorno() ) );
        }
        dadosCrivo.setIdCnae( source.getCnae() );
        if ( source.getCodEvento() != null ) {
            dadosCrivo.setIdEvento( String.valueOf( source.getCodEvento() ) );
        }
        dadosCrivo.setOperacao( source.getCodOperacao() );
        dadosCrivo.setRazaoSocial( source.getNmSegurado() );
        dadosCrivo.setCep( source.getCepFonteExterna() );

        posMapping( dadosCrivo );

        return dadosCrivo;
    }
}
