package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.infra.domain.Corretor;
import br.com.tokiomarine.ctpj.integracao.servicosportais.response.CorretorBaseUnica;
import br.com.tokiomarine.ctpj.ws.response.CorretorResponse;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:14-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CorretorMapperImpl extends CorretorMapper {

    @Override
    public CorretorResponse fromCorretorToCorretorResponse(Corretor corretor) {
        if ( corretor == null ) {
            return null;
        }

        CorretorResponse corretorResponse = new CorretorResponse();

        corretorResponse.setIdCorretor( corretor.getCodigo() );
        corretorResponse.setNomeCorretor( corretor.getNome() );

        return corretorResponse;
    }

    @Override
    public CorretorResponse fromCorretorBaseUnicaToCorretorResponse(CorretorBaseUnica corretorBaseUnica) {
        if ( corretorBaseUnica == null ) {
            return null;
        }

        CorretorResponse corretorResponse = new CorretorResponse();

        corretorResponse.setIdCorretor( corretorBaseUnica.getCodigoInterno() );
        corretorResponse.setNomeCorretor( corretorBaseUnica.getNomeCorretor() );

        return corretorResponse;
    }

    @Override
    public Corretor fromCorretorBaseUnicaToCorretor(CorretorBaseUnica corretorBaseUnica) {
        if ( corretorBaseUnica == null ) {
            return null;
        }

        Corretor corretor = new Corretor();

        corretor.setCodigo( corretorBaseUnica.getCodigoInterno() );
        corretor.setRegistroSusep( corretorBaseUnica.getSusep() );
        corretor.setNome( corretorBaseUnica.getNomeCorretor() );

        return corretor;
    }
}
