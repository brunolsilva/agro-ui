package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.OpcaoParcelamentoView;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:14-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class OpcaoParcelamentoMapperImpl implements OpcaoParcelamentoMapper {

    @Override
    public OpcaoParcelamentoView toView(OpcaoParcelamento opcaoParcelamento) {
        if ( opcaoParcelamento == null ) {
            return null;
        }

        OpcaoParcelamentoView opcaoParcelamentoView = new OpcaoParcelamentoView();

        opcaoParcelamentoView.setSequencialOpcaoParcelamento( opcaoParcelamento.getSequencialOpcaoParcelamento() );
        opcaoParcelamentoView.setDescricaoFormaParcelamento( opcaoParcelamento.getDescricaoFormaParcelamento() );
        opcaoParcelamentoView.setDescricaoFormaPagamento( opcaoParcelamento.getDescricaoFormaPagamento() );
        opcaoParcelamentoView.setValorPrimeiraParcela( opcaoParcelamento.getValorPrimeiraParcela() );
        opcaoParcelamentoView.setValorPremioTotal( opcaoParcelamento.getValorPremioTotal() );
        opcaoParcelamentoView.setIdParcelamentoEscolhido( opcaoParcelamento.getIdParcelamentoEscolhido() );

        return opcaoParcelamentoView;
    }

    @Override
    public List<OpcaoParcelamentoView> toView(List<OpcaoParcelamento> opcaoParcelamento) {
        if ( opcaoParcelamento == null ) {
            return null;
        }

        List<OpcaoParcelamentoView> list = new ArrayList<OpcaoParcelamentoView>();
        for ( OpcaoParcelamento opcaoParcelamento_ : opcaoParcelamento ) {
            list.add( toView( opcaoParcelamento_ ) );
        }

        return list;
    }
}
