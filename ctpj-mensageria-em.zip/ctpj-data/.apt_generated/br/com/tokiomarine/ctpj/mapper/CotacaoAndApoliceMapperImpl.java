package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.domain.apolice.Apolice;
import br.com.tokiomarine.ctpj.domain.apolice.ApoliceDocumentoDigital;
import br.com.tokiomarine.ctpj.domain.apolice.ClausulaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ComissaoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.CorretagemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.CosseguroApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemAeronaveApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemBeneficiarioApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCobClausulaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCobDescAgravApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCobEquipFranquiaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCoberturaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCoberturaSinistroApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemCosseguradoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemDadosObraApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemDistribuicaoVrApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemEmbarcacaoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemEmbarqueApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemNotaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemOutroSeguroApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemPilotoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemQbrApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemRamoEmissaoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemRelacaoBemApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemRelacaoEnderecoApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemSinistroApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ItemSistemaProtecionalApolice;
import br.com.tokiomarine.ctpj.domain.apolice.NotaApolice;
import br.com.tokiomarine.ctpj.domain.apolice.ParcelamentoApolice;
import br.com.tokiomarine.ctpj.domain.cotacao.ClausulaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ComissaoCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DescontoAgravacao;
import br.com.tokiomarine.ctpj.domain.cotacao.DocumentoDigital;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemAeronave;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemBeneficiario;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaClausula;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCoberturaSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCossegurado;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDadosObra;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarcacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEmbarque;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemOutroSeguro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemPiloto;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemQBR;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRamoEmissao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoBem;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemRelacaoEndereco;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSinistro;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemSistemaProtecional;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.OpcaoParcelamento;
import br.com.tokiomarine.ctpj.enums.SolicitanteEndossoEnum;
import br.com.tokiomarine.ctpj.enums.TipoEndossoEnum;
import br.com.tokiomarine.ctpj.enums.sct.TipoEndossoSctEnum;
import br.com.tokiomarine.ctpj.sct.response.SolicitacaoCotacao;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Generated;
import org.mapstruct.factory.Mappers;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:14-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CotacaoAndApoliceMapperImpl extends CotacaoAndApoliceMapper {

    private final FormaFranquiaEnumMapper formaFranquiaEnumMapper = Mappers.getMapper( FormaFranquiaEnumMapper.class );
    private final TipoEndossoEnumMapper tipoEndossoEnumMapper = Mappers.getMapper( TipoEndossoEnumMapper.class );

    @Override
    public Cotacao fromApoliceToCotacao(Apolice apolice, SolicitacaoCotacao solicitacaoCotacao, Integer versaoCotacaoProposta) {
        if ( apolice == null && solicitacaoCotacao == null && versaoCotacaoProposta == null ) {
            return null;
        }

        Cotacao cotacao = new Cotacao();

        if ( apolice != null ) {
            cotacao.setDocumentoDigital( apoliceDocumentoDigitalToDocumentoDigital( apolice.getApoliceEnvioDocumento() ) );
            cotacao.setListComissaoCotacao( comissaoApoliceListToComissaoCotacaoSet( apolice.getListComissaoApolice() ) );
            cotacao.setCodigoEndossoEndossado( apolice.getCodigoEndosso() );
            cotacao.setIdTipoPessoa( apolice.getIdTipoPessoaSegurado() );
            cotacao.setListCosseguroCotacao( cosseguroApoliceListToCosseguroCotacaoSet( apolice.getListCosseguroApolice() ) );
            cotacao.setListCorretagemCotacao( corretagemApoliceListToCorretagemCotacaoList( apolice.getListCorretagemApolice() ) );
            cotacao.setIdTipoSexo( apolice.getTipoSexo() );
            cotacao.setDataNascimentoCliente( apolice.getDataNascimento() );
            cotacao.setNumeroMatriculaVendedor( apolice.getMatriculaVendedor() );
            cotacao.setNumeroAgenciaVendedora( apolice.getAgencia() );
            cotacao.setListItem( itemApoliceListToItemCotacaoSet( apolice.getListItemApolice() ) );
            cotacao.setPercentualDescontoGeral( apolice.getPercentualDescontoGeral() );
            cotacao.setListClausulaCotacao( clausulaApoliceListToClausulaCotacaoList( apolice.getListClausulaApolice() ) );
            if ( apolice.getIdEndereco() != null ) {
                cotacao.setIdNovoEnderecoCliente( new BigInteger( apolice.getIdEndereco() ) );
            }
            cotacao.setNumeroContaCorrenteVendedora( apolice.getContaCorrente() );
            cotacao.setListNotaCotacao( notaApoliceListToNotaCotacaoList( apolice.getListNotaApolice() ) );
            cotacao.setCodigoTipoEndossoEndossada( apolice.getCodigoTipoEndosso() );
            if ( apolice.getIdCliente() != null ) {
                cotacao.setCodigoCliente( Long.parseLong( apolice.getIdCliente() ) );
            }
            cotacao.setCodigoProduto( apolice.getCodigoProduto() );
            if ( apolice.getIdCelular() != null ) {
                cotacao.setIdTelefone( new BigInteger( apolice.getIdCelular() ) );
            }
            cotacao.setCodigoGrupo( apolice.getCodigoGrupo() );
            cotacao.setDataAtualizacao( apolice.getDataAtualizacao() );
            if ( apolice.getUsuarioAtualizacao() != null ) {
                cotacao.setUsuarioAtualizacao( Long.parseLong( apolice.getUsuarioAtualizacao() ) );
            }
            cotacao.setCodSistemaOrigem( apolice.getCodSistemaOrigem() );
            cotacao.setCodigoApoliceRenovada( apolice.getCodigoApoliceRenovada() );
            cotacao.setCodigoAtividadePrincipal( apolice.getCodigoAtividadePrincipal() );
            cotacao.setCodigoCompanhiaSeguradora( apolice.getCodigoCompanhiaSeguradora() );
            cotacao.setCodigoMoeda( apolice.getCodigoMoeda() );
            cotacao.setCodigoPagador( apolice.getCodigoPagador() );
            cotacao.setCodigoRamoProdutoRenovada( apolice.getCodigoRamoProdutoRenovada() );
            cotacao.setDataAlteracao( apolice.getDataAlteracao() );
            cotacao.setDataFimVigencia( apolice.getDataFimVigencia() );
            cotacao.setDataInicioVigencia( apolice.getDataInicioVigencia() );
            cotacao.setDescricaoAtividadePrincipal( apolice.getDescricaoAtividadePrincipal() );
            cotacao.setEnderecoSegurado( apolice.getEnderecoSegurado() );
            cotacao.setIdCEPSegurado( apolice.getIdCEPSegurado() );
            cotacao.setIdCapitalSocial( apolice.getIdCapitalSocial() );
            cotacao.setIdContaFaturaMensal( apolice.getIdContaFaturaMensal() );
            cotacao.setIdEmailSegurado( apolice.getIdEmailSegurado() );
            cotacao.setIdEstadoCivil( apolice.getIdEstadoCivil() );
            cotacao.setIdFaturamentoPresumido( apolice.getIdFaturamentoPresumido() );
            cotacao.setIdIsencaoImposto( apolice.getIdIsencaoImposto() );
            cotacao.setIdLmiUnico( apolice.getIdLmiUnico() );
            cotacao.setIdPatrimonio( apolice.getIdPatrimonio() );
            cotacao.setIdPrazoVigencia( apolice.getIdPrazoVigencia() );
            cotacao.setIdProfissao( apolice.getIdProfissao() );
            cotacao.setIdRenda( apolice.getIdRenda() );
            cotacao.setIdResseguroFacultativo( apolice.getIdResseguroFacultativo() );
            cotacao.setIdSeguroEstipulante( apolice.getIdSeguroEstipulante() );
            cotacao.setIdTipoApolice( apolice.getIdTipoApolice() );
            cotacao.setIdTipoSeguro( apolice.getIdTipoSeguro() );
            cotacao.setIdUFSegurado( apolice.getIdUFSegurado() );
            cotacao.setNomeBairroSegurado( apolice.getNomeBairroSegurado() );
            cotacao.setNomeComplementoEnderecoSegurado( apolice.getNomeComplementoEnderecoSegurado() );
            cotacao.setNomeMunicipioSegurado( apolice.getNomeMunicipioSegurado() );
            cotacao.setNomeProduto( apolice.getNomeProduto() );
            cotacao.setNomeSegurado( apolice.getNomeSegurado() );
            cotacao.setNumeroApoliceCongenere( apolice.getNumeroApoliceCongenere() );
            cotacao.setNumeroBancoBoleto( apolice.getNumeroBancoBoleto() );
            cotacao.setNumeroCNPJCPFSegurado( apolice.getNumeroCNPJCPFSegurado() );
            cotacao.setNumeroCelularSegurado( apolice.getNumeroCelularSegurado() );
            cotacao.setNumeroDDDCelularSegurado( apolice.getNumeroDDDCelularSegurado() );
            cotacao.setNumeroDDDSegurado( apolice.getNumeroDDDSegurado() );
            cotacao.setNumeroEnderecoSegurado( apolice.getNumeroEnderecoSegurado() );
            cotacao.setNumeroRG( apolice.getNumeroRG() );
            cotacao.setNumeroTelefoneSegurado( apolice.getNumeroTelefoneSegurado() );
            cotacao.setPercentualDescontoAcordoIRB( apolice.getPercentualDescontoAcordoIRB() );
        }
        if ( solicitacaoCotacao != null ) {
            if ( solicitacaoCotacao.getCdSubct() != null ) {
                cotacao.setCodigoSubscritor( solicitacaoCotacao.getCdSubct().longValue() );
            }
            cotacao.setCodigoTipoEndossoSCT( solicitacaoCotacao.getCdTipoEndosSsc() );
            cotacao.setDataProposta( solicitacaoCotacao.getDataRecepcaoProposta() );
            cotacao.setCodigoSubLocal( solicitacaoCotacao.getCdSbloc() );
            cotacao.setIdSolicitanteEndosso( solicitacaoCotacaoCdTipoEndosSscSolicitanteEndosso( solicitacaoCotacao ) );
            cotacao.setCodigoApoliceEndossada( solicitacaoCotacao.getCdApoliTmsrEndso() );
            if ( solicitacaoCotacao.getCdProtr() != null ) {
                cotacao.setCodigoProdutor( solicitacaoCotacao.getCdProtr().longValue() );
            }
            cotacao.setNomeSubLocal( solicitacaoCotacao.getNmSbloc() );
            cotacao.setNomeProdutor( solicitacaoCotacao.getNmProtr() );
            cotacao.setCodigoLocal( solicitacaoCotacao.getCdLocal() );
            cotacao.setNumeroCotacaoProposta( solicitacaoCotacao.getNrSolctCotac() );
            cotacao.setCodigoRamoProdutoEndossada( solicitacaoCotacao.getCdRamoPrdutApoliTmsrEndso() );
            cotacao.setIdDestinoEmissao( solicitacaoCotacao.getIdDestinoEmissao() );
            cotacao.setNomeSubscritor( solicitacaoCotacao.getNmSubct() );
            cotacao.setIdMongoEndosso( solicitacaoCotacao.getIdMongodb() );
            cotacao.setNomeCorretor( solicitacaoCotacao.getNmCrtorPlatf() );
            cotacao.setEmailSubscritor( solicitacaoCotacao.getDsEmailSubct() );
            if ( solicitacaoCotacao.getCdCrtorAcsel() != null ) {
                cotacao.setCodigoCorretorACSEL( String.valueOf( solicitacaoCotacao.getCdCrtorAcsel() ) );
            }
            cotacao.setIdTipoEndosso( solicitacaoCotacaoCdTipoEndosSscTipoEndossoCTPJ( solicitacaoCotacao ) );
        }
        if ( versaoCotacaoProposta != null ) {
            cotacao.setVersaoCotacaoProposta( versaoCotacaoProposta );
        }

        postMappingCotacao( apolice, solicitacaoCotacao, cotacao );

        return cotacao;
    }

    @Override
    public ItemCotacao fromItemDadosObraApoliceToItemDadosObra(ItemApolice itemApolice) {
        if ( itemApolice == null ) {
            return null;
        }

        ItemCotacao itemCotacao_ = new ItemCotacao();

        itemCotacao_.setPercentualRelacaoDMPValorRisco( itemApolice.getPercentualRelacaoDmpVr() );
        itemCotacao_.setListItemPiloto( itemPilotoApoliceListToItemPilotoList( itemApolice.getListItemPilotoApolice() ) );
        itemCotacao_.setListItemDadosObra( itemDadosObraApoliceListToItemDadosObraList( itemApolice.getListItemDadosObraApolice() ) );
        itemCotacao_.setListItemRamoEmissao( itemRamoEmissaoApoliceListToItemRamoEmissaoSet( itemApolice.getListItemRamoEmissaoApolice() ) );
        itemCotacao_.setListItemEmbarque( itemEmbarqueApoliceListToItemEmbarqueList( itemApolice.getListItemEmbarqueApolice() ) );
        itemCotacao_.setPercentualRelacaoImportanciaSeguradaValorRisco( itemApolice.getPercentualRelacaoIsVr() );
        itemCotacao_.setListItemCossegurado( itemCosseguradoApoliceListToItemCosseguradoList( itemApolice.getListItemCosseguradoApolice() ) );
        itemCotacao_.setListItemRelacaoBem( itemRelacaoBemApoliceListToItemRelacaoBemList( itemApolice.getListItemRelacaoBemApolice() ) );
        itemCotacao_.setListItemQBR( itemQbrApoliceListToItemQBRList( itemApolice.getListItemQbrApolice() ) );
        itemCotacao_.setListItemDistribuicao( itemDistribuicaoVrApoliceListToItemDistribuicaoSet( itemApolice.getListItemDistribuicaoVrApolice() ) );
        itemCotacao_.setListItemCobertura( itemCoberturaApoliceListToItemCoberturaSet( itemApolice.getListItemCoberturaApolice() ) );
        itemCotacao_.setListItemSinistro( itemSinistroApoliceListToItemSinistroSet( itemApolice.getListItemSinistroApolice() ) );
        itemCotacao_.setListItemOutroSeguro( itemOutroSeguroApoliceListToItemOutroSeguroList( itemApolice.getListItemOutroSeguroApolice() ) );
        itemCotacao_.setListItemBeneficiario( itemBeneficiarioApoliceListToItemBeneficiarioList( itemApolice.getListItemBeneficiarioApolice() ) );
        itemCotacao_.setNomeComplementoEnderecoLocalRisco( itemApolice.getComplementoEnderecoLocalRisco() );
        itemCotacao_.setCodigoItemRenovada( itemApolice.getCodigoItemApoliceRenovada() );
        itemCotacao_.setListItemSistemaProtecional( itemSistemaProtecionalApoliceListToItemSistemaProtecionalSet( itemApolice.getListItemSistemaProtecionalApolice() ) );
        itemCotacao_.setListItemRelacaoEndereco( itemRelacaoEnderecoApoliceListToItemRelacaoEnderecoList( itemApolice.getListItemRelacaoEnderecoApolice() ) );
        itemCotacao_.setListItemNota( itemNotaApoliceListToItemNotaList( itemApolice.getListItemNotaApolice() ) );
        itemCotacao_.setNomeComplementoEnderecoSegurado( itemApolice.getComplementoEnderecoSegurado() );
        itemCotacao_.setListItemEmbarcacao( itemEmbarcacaoApoliceListToItemEmbarcacaoList( itemApolice.getListItemEmbarcacaoApolice() ) );
        itemCotacao_.setListItemAeronave( itemAeronaveApoliceListToItemAeronaveList( itemApolice.getListItemAeronaveApolice() ) );
        if ( itemApolice.getCodigoItemApolice() != null ) {
            itemCotacao_.setNumeroItem( BigInteger.valueOf( itemApolice.getCodigoItemApolice() ) );
        }
        itemCotacao_.setCodigoGrupo( itemApolice.getCodigoGrupo() );
        itemCotacao_.setDataAtualizacao( itemApolice.getDataAtualizacao() );
        if ( itemApolice.getUsuarioAtualizacao() != null ) {
            itemCotacao_.setUsuarioAtualizacao( Long.parseLong( itemApolice.getUsuarioAtualizacao() ) );
        }
        itemCotacao_.setCodigoAmbitoGeografico( itemApolice.getCodigoAmbitoGeografico() );
        itemCotacao_.setCodigoApolice( itemApolice.getCodigoApolice() );
        itemCotacao_.setCodigoApoliceRenovada( itemApolice.getCodigoApoliceRenovada() );
        itemCotacao_.setCodigoAtividadePrincipal( itemApolice.getCodigoAtividadePrincipal() );
        itemCotacao_.setCodigoBemCoberto( itemApolice.getCodigoBemCoberto() );
        itemCotacao_.setCodigoClasseBonus( itemApolice.getCodigoClasseBonus() );
        itemCotacao_.setCodigoClasseConstrucao( itemApolice.getCodigoClasseConstrucao() );
        itemCotacao_.setCodigoClasseLocalizacao( itemApolice.getCodigoClasseLocalizacao() );
        itemCotacao_.setCodigoCompanhiaSeguradora( itemApolice.getCodigoCompanhiaSeguradora() );
        itemCotacao_.setCodigoEndosso( itemApolice.getCodigoEndosso() );
        itemCotacao_.setCodigoItemApolice( itemApolice.getCodigoItemApolice() );
        itemCotacao_.setCodigoLocalizacao( itemApolice.getCodigoLocalizacao() );
        itemCotacao_.setCodigoMunicipioLocalRisco( itemApolice.getCodigoMunicipioLocalRisco() );
        itemCotacao_.setCodigoRamoProdutoApolice( itemApolice.getCodigoRamoProdutoApolice() );
        itemCotacao_.setCodigoRamoProdutoRenovada( itemApolice.getCodigoRamoProdutoRenovada() );
        itemCotacao_.setCodigoRegiaoTarifaria( itemApolice.getCodigoRegiaoTarifaria() );
        itemCotacao_.setCodigoRubrica( itemApolice.getCodigoRubrica() );
        itemCotacao_.setCodigoTipoEndosso( itemApolice.getCodigoTipoEndosso() );
        itemCotacao_.setCoeficienteConversaoMoeda( itemApolice.getCoeficienteConversaoMoeda() );
        itemCotacao_.setDataAlteracao( itemApolice.getDataAlteracao() );
        itemCotacao_.setDataConversaoValorRisco( itemApolice.getDataConversaoValorRisco() );
        itemCotacao_.setDataFimVigencia( itemApolice.getDataFimVigencia() );
        itemCotacao_.setDataInicioVigencia( itemApolice.getDataInicioVigencia() );
        itemCotacao_.setDescricaoAtividadePrincipal( itemApolice.getDescricaoAtividadePrincipal() );
        itemCotacao_.setDescricaoDescontoItem( itemApolice.getDescricaoDescontoItem() );
        itemCotacao_.setDescricaoRubricaAlternativa( itemApolice.getDescricaoRubricaAlternativa() );
        itemCotacao_.setEnderecoLocalRisco( itemApolice.getEnderecoLocalRisco() );
        itemCotacao_.setEnderecoSegurado( itemApolice.getEnderecoSegurado() );
        itemCotacao_.setIdCEPLocalRisco( itemApolice.getIdCEPLocalRisco() );
        itemCotacao_.setIdCEPSegurado( itemApolice.getIdCEPSegurado() );
        itemCotacao_.setIdEmailSegurado( itemApolice.getIdEmailSegurado() );
        itemCotacao_.setIdExclusaoEndosso( itemApolice.getIdExclusaoEndosso() );
        itemCotacao_.setIdPatrimonio( itemApolice.getIdPatrimonio() );
        itemCotacao_.setIdProfissao( itemApolice.getIdProfissao() );
        itemCotacao_.setIdRenda( itemApolice.getIdRenda() );
        itemCotacao_.setIdResseguroFacultativo( itemApolice.getIdResseguroFacultativo() );
        itemCotacao_.setIdSolicitanteEndosso( itemApolice.getIdSolicitanteEndosso() );
        itemCotacao_.setIdTipoEndosso( tipoEndossoEnumMapper.toInteger( itemApolice.getIdTipoEndosso() ) );
        itemCotacao_.setIdTipoPessoa( itemApolice.getIdTipoPessoa() );
        itemCotacao_.setIdTipoSeguro( itemApolice.getIdTipoSeguro() );
        itemCotacao_.setIdUFLocalRisco( itemApolice.getIdUFLocalRisco() );
        itemCotacao_.setIdUFSegurado( itemApolice.getIdUFSegurado() );
        itemCotacao_.setNomeBairroLocalRisco( itemApolice.getNomeBairroLocalRisco() );
        itemCotacao_.setNomeBairroSegurado( itemApolice.getNomeBairroSegurado() );
        itemCotacao_.setNomeMunicipioLocalRisco( itemApolice.getNomeMunicipioLocalRisco() );
        itemCotacao_.setNomeMunicipioSegurado( itemApolice.getNomeMunicipioSegurado() );
        itemCotacao_.setNomeSegurado( itemApolice.getNomeSegurado() );
        itemCotacao_.setNumeroApoliceCongenere( itemApolice.getNumeroApoliceCongenere() );
        itemCotacao_.setNumeroCNPJCPFSegurado( itemApolice.getNumeroCNPJCPFSegurado() );
        itemCotacao_.setNumeroCelularSegurado( itemApolice.getNumeroCelularSegurado() );
        itemCotacao_.setNumeroDDDCelularSegurado( itemApolice.getNumeroDDDCelularSegurado() );
        itemCotacao_.setNumeroDDDSegurado( itemApolice.getNumeroDDDSegurado() );
        itemCotacao_.setNumeroEnderecoLocalRisco( itemApolice.getNumeroEnderecoLocalRisco() );
        itemCotacao_.setNumeroEnderecoSegurado( itemApolice.getNumeroEnderecoSegurado() );
        itemCotacao_.setNumeroItemApoliceCongenere( itemApolice.getNumeroItemApoliceCongenere() );
        itemCotacao_.setNumeroRG( itemApolice.getNumeroRG() );
        itemCotacao_.setNumeroTelefoneSegurado( itemApolice.getNumeroTelefoneSegurado() );
        itemCotacao_.setPercentualAgravacaoItem( itemApolice.getPercentualAgravacaoItem() );
        itemCotacao_.setPercentualDescontoItem( itemApolice.getPercentualDescontoItem() );
        itemCotacao_.setPercentualPrazoCurto( itemApolice.getPercentualPrazoCurto() );
        itemCotacao_.setPercentualSinistralidade( itemApolice.getPercentualSinistralidade() );
        itemCotacao_.setQuantidadeDiasProRata( itemApolice.getQuantidadeDiasProRata() );
        itemCotacao_.setValorMaiorRiscoIsolado( itemApolice.getValorMaiorRiscoIsolado() );
        itemCotacao_.setValorRiscoBem( itemApolice.getValorRiscoBem() );
        itemCotacao_.setValorRiscoBemCalculado( itemApolice.getValorRiscoBemCalculado() );
        itemCotacao_.setValorRiscoBemMoedaEstrangeira( itemApolice.getValorRiscoBemMoedaEstrangeira() );

        return itemCotacao_;
    }

    @Override
    public NotaCotacao fromNotaApoliceToNotaCotacao(NotaApolice notaApolice) {
        if ( notaApolice == null ) {
            return null;
        }

        NotaCotacao notaCotacao_ = new NotaCotacao();

        notaCotacao_.setNota( notaApolice.getDescricaoNota() );
        notaCotacao_.setCodigoGrupo( notaApolice.getCodigoGrupo() );
        notaCotacao_.setDataAtualizacao( notaApolice.getDataAtualizacao() );
        if ( notaApolice.getUsuarioAtualizacao() != null ) {
            notaCotacao_.setUsuarioAtualizacao( Long.parseLong( notaApolice.getUsuarioAtualizacao() ) );
        }

        return notaCotacao_;
    }

    @Override
    public ComissaoCotacao fromComissaoApoliceToComissaoCotacao(ComissaoApolice comissaoApolice) {
        if ( comissaoApolice == null ) {
            return null;
        }

        ComissaoCotacao comissaoCotacao_ = new ComissaoCotacao();

        comissaoCotacao_.setCodigoGrupoRamo( comissaoApolice.getCodigoGrupoRamoEmissao() );
        comissaoCotacao_.setCodigoRamo( comissaoApolice.getCodigoRamoEmissao() );
        comissaoCotacao_.setCodigoGrupo( comissaoApolice.getCodigoGrupo() );
        comissaoCotacao_.setDataAtualizacao( comissaoApolice.getDataAtualizacao() );
        if ( comissaoApolice.getUsuarioAtualizacao() != null ) {
            comissaoCotacao_.setUsuarioAtualizacao( Long.parseLong( comissaoApolice.getUsuarioAtualizacao() ) );
        }
        comissaoCotacao_.setPercentualComissao( comissaoApolice.getPercentualComissao() );
        comissaoCotacao_.setPercentualDescontoComercial( comissaoApolice.getPercentualDescontoComercial() );

        return comissaoCotacao_;
    }

    @Override
    public CosseguroCotacao fromCosseguroApoliceToCosseguroCotacao(CosseguroApolice cosseguroApolice) {
        if ( cosseguroApolice == null ) {
            return null;
        }

        CosseguroCotacao cosseguroCotacao_ = new CosseguroCotacao();

        cosseguroCotacao_.setCodigoCompanhiaSeguradora( cosseguroApolice.getCdCiaSeguradora() );
        cosseguroCotacao_.setPercentualCosseguro( cosseguroApolice.getPcCosseguro() );
        cosseguroCotacao_.setPercentualComissaoDiferenciada( cosseguroApolice.getPcComissaoDiferenciada() );
        cosseguroCotacao_.setCodigoGrupo( cosseguroApolice.getCodigoGrupo() );
        cosseguroCotacao_.setDataAtualizacao( cosseguroApolice.getDataAtualizacao() );
        if ( cosseguroApolice.getUsuarioAtualizacao() != null ) {
            cosseguroCotacao_.setUsuarioAtualizacao( Long.parseLong( cosseguroApolice.getUsuarioAtualizacao() ) );
        }

        return cosseguroCotacao_;
    }

    @Override
    public CorretagemCotacao fromCorretagemApoliceToCorretagemCotacao(CorretagemApolice corretagemApolice) {
        if ( corretagemApolice == null ) {
            return null;
        }

        CorretagemCotacao corretagemCotacao_ = new CorretagemCotacao();

        corretagemCotacao_.setCodigoGrupo( corretagemApolice.getCodigoGrupo() );
        corretagemCotacao_.setDataAtualizacao( corretagemApolice.getDataAtualizacao() );
        if ( corretagemApolice.getUsuarioAtualizacao() != null ) {
            corretagemCotacao_.setUsuarioAtualizacao( Long.parseLong( corretagemApolice.getUsuarioAtualizacao() ) );
        }
        corretagemCotacao_.setCodigoCorretorAcsel( corretagemApolice.getCodigoCorretorAcsel() );
        corretagemCotacao_.setIdCorretorLider( corretagemApolice.getIdCorretorLider() );
        corretagemCotacao_.setPercentualCorretagem( corretagemApolice.getPercentualCorretagem() );

        return corretagemCotacao_;
    }

    @Override
    public ClausulaCotacao fromClausulaApoliceToClausulaCotacao(ClausulaApolice clausulaApolice) {
        if ( clausulaApolice == null ) {
            return null;
        }

        ClausulaCotacao clausulaCotacao_ = new ClausulaCotacao();

        clausulaCotacao_.setCodigoClausula( clausulaApolice.getCodigoClausulaNota() );
        clausulaCotacao_.setDescricaoClausula( clausulaApolice.getDescricao() );
        clausulaCotacao_.setCodigoGrupo( clausulaApolice.getCodigoGrupo() );
        clausulaCotacao_.setDataAtualizacao( clausulaApolice.getDataAtualizacao() );
        if ( clausulaApolice.getUsuarioAtualizacao() != null ) {
            clausulaCotacao_.setUsuarioAtualizacao( Long.parseLong( clausulaApolice.getUsuarioAtualizacao() ) );
        }
        clausulaCotacao_.setCodigoGrupoRamo( clausulaApolice.getCodigoGrupoRamo() );
        clausulaCotacao_.setCodigoRamo( clausulaApolice.getCodigoRamo() );

        return clausulaCotacao_;
    }

    @Override
    public OpcaoParcelamento fromParcelamentoApoliceToParcelamentoCotacao(ParcelamentoApolice parcelamentoApolice) {
        if ( parcelamentoApolice == null ) {
            return null;
        }

        OpcaoParcelamento opcaoParcelamento = new OpcaoParcelamento();

        opcaoParcelamento.setCodigoFormaPagamento( parcelamentoApolice.getCodigoFormaPagamento() );
        opcaoParcelamento.setCodigoFormaParcelamento( parcelamentoApolice.getCodigoFormaParcelamento() );
        opcaoParcelamento.setValorCustoApolice( parcelamentoApolice.getValorCustoApolice() );
        opcaoParcelamento.setValorJuros( parcelamentoApolice.getValorJuros() );

        return opcaoParcelamento;
    }

    @Override
    public ItemRelacaoBem fromItemRelacaoBemApoliceToItemRelacaoBemApolice(ItemRelacaoBemApolice itemRelacaoBemApolice) {
        if ( itemRelacaoBemApolice == null ) {
            return null;
        }

        ItemRelacaoBem itemRelacaoBem_ = new ItemRelacaoBem();

        itemRelacaoBem_.setCodigoGrupo( itemRelacaoBemApolice.getCodigoGrupo() );
        itemRelacaoBem_.setDataAtualizacao( itemRelacaoBemApolice.getDataAtualizacao() );
        if ( itemRelacaoBemApolice.getUsuarioAtualizacao() != null ) {
            itemRelacaoBem_.setUsuarioAtualizacao( Long.parseLong( itemRelacaoBemApolice.getUsuarioAtualizacao() ) );
        }
        itemRelacaoBem_.setDescricaoBem( itemRelacaoBemApolice.getDescricaoBem() );
        itemRelacaoBem_.setSequencialRelacaoBem( itemRelacaoBemApolice.getSequencialRelacaoBem() );
        itemRelacaoBem_.setValorImportanciaSegurada( itemRelacaoBemApolice.getValorImportanciaSegurada() );
        itemRelacaoBem_.setValorImportanciaSeguradaMoedaEstrangeira( itemRelacaoBemApolice.getValorImportanciaSeguradaMoedaEstrangeira() );

        return itemRelacaoBem_;
    }

    @Override
    public ItemRelacaoEndereco fromItemRelacaoEnderecoApoliceToItemRelacaoEndereco(ItemRelacaoEnderecoApolice itemRelacaoEnderecoApolice) {
        if ( itemRelacaoEnderecoApolice == null ) {
            return null;
        }

        ItemRelacaoEndereco itemRelacaoEndereco_ = new ItemRelacaoEndereco();

        itemRelacaoEndereco_.setCodigoGrupo( itemRelacaoEnderecoApolice.getCodigoGrupo() );
        itemRelacaoEndereco_.setDataAtualizacao( itemRelacaoEnderecoApolice.getDataAtualizacao() );
        if ( itemRelacaoEnderecoApolice.getUsuarioAtualizacao() != null ) {
            itemRelacaoEndereco_.setUsuarioAtualizacao( Long.parseLong( itemRelacaoEnderecoApolice.getUsuarioAtualizacao() ) );
        }
        itemRelacaoEndereco_.setCodigoClasseConstrucao( itemRelacaoEnderecoApolice.getCodigoClasseConstrucao() );
        itemRelacaoEndereco_.setEnderecoSegurado( itemRelacaoEnderecoApolice.getEnderecoSegurado() );
        itemRelacaoEndereco_.setIdCEP( itemRelacaoEnderecoApolice.getIdCEP() );
        itemRelacaoEndereco_.setIdUF( itemRelacaoEnderecoApolice.getIdUF() );
        itemRelacaoEndereco_.setNomeBairro( itemRelacaoEnderecoApolice.getNomeBairro() );
        itemRelacaoEndereco_.setNomeComplemento( itemRelacaoEnderecoApolice.getNomeComplemento() );
        itemRelacaoEndereco_.setNomeMunicipio( itemRelacaoEnderecoApolice.getNomeMunicipio() );
        itemRelacaoEndereco_.setNumeroEndereco( itemRelacaoEnderecoApolice.getNumeroEndereco() );
        itemRelacaoEndereco_.setSequencialRelacaoEndereco( itemRelacaoEnderecoApolice.getSequencialRelacaoEndereco() );

        return itemRelacaoEndereco_;
    }

    @Override
    public ItemOutroSeguro fromItemOutroSeguroApoliceToItemOutroSeguro(ItemOutroSeguroApolice itemOutroSeguroApolice) {
        if ( itemOutroSeguroApolice == null ) {
            return null;
        }

        ItemOutroSeguro itemOutroSeguro_ = new ItemOutroSeguro();

        itemOutroSeguro_.setValorLMG( itemOutroSeguroApolice.getValorLimiteMaximoGarantia() );
        itemOutroSeguro_.setSequencialItemOutroControle( itemOutroSeguroApolice.getSequencialItemOutroApoliceControle() );
        itemOutroSeguro_.setValorLMGMoedaEstrangeira( itemOutroSeguroApolice.getValorLimiteMaximoGarantiaMoedaEstrangeira() );
        itemOutroSeguro_.setCodigoGrupo( itemOutroSeguroApolice.getCodigoGrupo() );
        itemOutroSeguro_.setDataAtualizacao( itemOutroSeguroApolice.getDataAtualizacao() );
        if ( itemOutroSeguroApolice.getUsuarioAtualizacao() != null ) {
            itemOutroSeguro_.setUsuarioAtualizacao( Long.parseLong( itemOutroSeguroApolice.getUsuarioAtualizacao() ) );
        }
        itemOutroSeguro_.setCodigoCompanhiaSeguradora( itemOutroSeguroApolice.getCodigoCompanhiaSeguradora() );
        itemOutroSeguro_.setDataFimVigencia( itemOutroSeguroApolice.getDataFimVigencia() );
        itemOutroSeguro_.setNumeroApolice( itemOutroSeguroApolice.getNumeroApolice() );

        return itemOutroSeguro_;
    }

    @Override
    public ItemDadosObra fromItemOutroSeguroApoliceToItemOutroSeguro(ItemDadosObraApolice itemDadosObraApolice) {
        if ( itemDadosObraApolice == null ) {
            return null;
        }

        ItemDadosObra itemDadosObra_ = new ItemDadosObra();

        itemDadosObra_.setCodigoSeveridade( itemDadosObraApolice.getCodigoSeveridade() );
        itemDadosObra_.setCodigoTipoConstrucao( itemDadosObraApolice.getCodigoTipoConstrucao() );
        itemDadosObra_.setCodigoTipoFundacao( itemDadosObraApolice.getCodigoTipoFundacao() );
        itemDadosObra_.setDataFimObra( itemDadosObraApolice.getDataFimObra() );
        itemDadosObra_.setDataInicioObra( itemDadosObraApolice.getDataInicioObra() );
        itemDadosObra_.setIdEscavacaoSubSolo( itemDadosObraApolice.getIdEscavacaoSubSolo() );
        itemDadosObra_.setIdFundacao( itemDadosObraApolice.getIdFundacao() );
        itemDadosObra_.setIdRebaixamentoLencol( itemDadosObraApolice.getIdRebaixamentoLencol() );
        itemDadosObra_.setIdSFH( itemDadosObraApolice.getIdSFH() );
        itemDadosObra_.setNumeroSubSolo( itemDadosObraApolice.getNumeroSubSolo() );
        itemDadosObra_.setSequencialItemDadosObra( itemDadosObraApolice.getSequencialItemDadosObra() );
        itemDadosObra_.setValorTotalObra( itemDadosObraApolice.getValorTotalObra() );
        itemDadosObra_.setValorTotalObraMoedaEstrangeira( itemDadosObraApolice.getValorTotalObraMoedaEstrangeira() );

        return itemDadosObra_;
    }

    @Override
    public ItemPiloto fromItemPilotoApoliceToItemPiloto(ItemPilotoApolice itemPilotoApolice) {
        if ( itemPilotoApolice == null ) {
            return null;
        }

        ItemPiloto itemPiloto_ = new ItemPiloto();

        itemPiloto_.setCodigoGrupo( itemPilotoApolice.getCodigoGrupo() );
        itemPiloto_.setDataAtualizacao( itemPilotoApolice.getDataAtualizacao() );
        if ( itemPilotoApolice.getUsuarioAtualizacao() != null ) {
            itemPiloto_.setUsuarioAtualizacao( Long.parseLong( itemPilotoApolice.getUsuarioAtualizacao() ) );
        }
        itemPiloto_.setCodigoSequencia( itemPilotoApolice.getCodigoSequencia() );
        itemPiloto_.setIdCodigoANAC( itemPilotoApolice.getIdCodigoANAC() );
        itemPiloto_.setNomePiloto( itemPilotoApolice.getNomePiloto() );
        itemPiloto_.setNumeroCNPJCPFPiloto( itemPilotoApolice.getNumeroCNPJCPFPiloto() );
        itemPiloto_.setNumeroHorasExperiencia( itemPilotoApolice.getNumeroHorasExperiencia() );

        return itemPiloto_;
    }

    @Override
    public ItemEmbarcacao fromItemEmbarcacaoApoliceToItemEmbarcacao(ItemEmbarcacaoApolice itemEmbarcacaoApolice) {
        if ( itemEmbarcacaoApolice == null ) {
            return null;
        }

        ItemEmbarcacao itemEmbarcacao_ = new ItemEmbarcacao();

        itemEmbarcacao_.setDataRealizacaoVistoria( itemEmbarcacaoApolice.getDataRealizacaoVistoria() );
        itemEmbarcacao_.setIdAssociadoClube( itemEmbarcacaoApolice.getIdAssociadoClube() );
        itemEmbarcacao_.setIdClasseEmbarcacao( itemEmbarcacaoApolice.getIdClasseEmbarcacao() );
        itemEmbarcacao_.setIdEmpresaVistoriaServicos( itemEmbarcacaoApolice.getIdEmpresaVistoriaServicos() );
        itemEmbarcacao_.setIdPortoInscricao( itemEmbarcacaoApolice.getIdPortoInscricao() );
        itemEmbarcacao_.setIdPropulsaoMotor( itemEmbarcacaoApolice.getIdPropulsaoMotor() );
        itemEmbarcacao_.setNomeEmbarcacao( itemEmbarcacaoApolice.getNomeEmbarcacao() );
        itemEmbarcacao_.setNomeEstaleiroFabricacao( itemEmbarcacaoApolice.getNomeEstaleiroFabricacao() );
        itemEmbarcacao_.setNomeFabricanteMotor( itemEmbarcacaoApolice.getNomeFabricanteMotor() );
        itemEmbarcacao_.setNomeModelo( itemEmbarcacaoApolice.getNomeModelo() );
        itemEmbarcacao_.setNomeRazaoSocialClubeEntidadeDesportiva( itemEmbarcacaoApolice.getNomeRazaoSocialClubeEntidadeDesportiva() );
        itemEmbarcacao_.setNomeRazaoSocialLocalGuarda( itemEmbarcacaoApolice.getNomeRazaoSocialLocalGuarda() );
        itemEmbarcacao_.setNumeroInscricao( itemEmbarcacaoApolice.getNumeroInscricao() );
        itemEmbarcacao_.setNumeroLaudoVistoria( itemEmbarcacaoApolice.getNumeroLaudoVistoria() );
        itemEmbarcacao_.setNumeroSerieMotor( itemEmbarcacaoApolice.getNumeroSerieMotor() );
        itemEmbarcacao_.setTipoModeloMotor( itemEmbarcacaoApolice.getTipoModeloMotor() );
        itemEmbarcacao_.setValorCascoEmbarcacao( itemEmbarcacaoApolice.getValorCascoEmbarcacao() );
        itemEmbarcacao_.setValorCascoEmbarcacaoMoedaEstrangeira( itemEmbarcacaoApolice.getValorCascoEmbarcacaoMoedaEstrangeira() );
        itemEmbarcacao_.setValorEquipamentoAcessorioEmbarcacao( itemEmbarcacaoApolice.getValorEquipamentoAcessorioEmbarcacao() );
        itemEmbarcacao_.setValorEquipamentoEmbarcacaoMoedaEstrangeira( itemEmbarcacaoApolice.getValorEquipamentoEmbarcacaoMoedaEstrangeira() );
        itemEmbarcacao_.setValorMotorEmbarcacao( itemEmbarcacaoApolice.getValorMotorEmbarcacao() );
        itemEmbarcacao_.setValorMotorEmbarcacaoMoedaEstrangeira( itemEmbarcacaoApolice.getValorMotorEmbarcacaoMoedaEstrangeira() );
        itemEmbarcacao_.setValorVelaEmbarcacaoMoedaEstrangeira( itemEmbarcacaoApolice.getValorVelaEmbarcacaoMoedaEstrangeira() );
        itemEmbarcacao_.setValorVelaMastroEmbarcacao( itemEmbarcacaoApolice.getValorVelaMastroEmbarcacao() );

        return itemEmbarcacao_;
    }

    @Override
    public ItemEmbarque fromItemEmbarqueApoliceToItemEmbarque(ItemEmbarqueApolice itemEmbarqueApolice) {
        if ( itemEmbarqueApolice == null ) {
            return null;
        }

        ItemEmbarque itemEmbarque_ = new ItemEmbarque();

        itemEmbarque_.setDescricaoEmpresaGerenciamentoRisco( itemEmbarqueApolice.getDescricaoEmpresaGerenciamentoRisco() );
        itemEmbarque_.setNumeroEmbarqueComum( itemEmbarqueApolice.getNumeroEmbarqueComum() );
        itemEmbarque_.setNumeroEmbarquePerigosos( itemEmbarqueApolice.getNumeroEmbarquePerigosos() );
        itemEmbarque_.setPercentualDescontoMercosul( itemEmbarqueApolice.getPercentualDescontoMercosul() );
        itemEmbarque_.setPercentualEmbarqueMercosul( itemEmbarqueApolice.getPercentualEmbarqueMercosul() );
        itemEmbarque_.setValorTotalEmbarqueComum( itemEmbarqueApolice.getValorTotalEmbarqueComum() );
        itemEmbarque_.setValorTotalEmbarqueComumMoedaEstrangeira( itemEmbarqueApolice.getValorTotalEmbarqueComumMoedaEstrangeira() );
        itemEmbarque_.setValorTotalEmbarquePerigosoMoedaEstrangeira( itemEmbarqueApolice.getValorTotalEmbarquePerigosoMoedaEstrangeira() );
        itemEmbarque_.setValorTotalEmbarquePerigosos( itemEmbarqueApolice.getValorTotalEmbarquePerigosos() );

        return itemEmbarque_;
    }

    @Override
    public ItemNota fromItemNotaApoliceToItemNota(ItemNotaApolice itemNotaApolice) {
        if ( itemNotaApolice == null ) {
            return null;
        }

        ItemNota itemNota_ = new ItemNota();

        itemNota_.setCodigoGrupo( itemNotaApolice.getCodigoGrupo() );
        itemNota_.setDataAtualizacao( itemNotaApolice.getDataAtualizacao() );
        if ( itemNotaApolice.getUsuarioAtualizacao() != null ) {
            itemNota_.setUsuarioAtualizacao( Long.parseLong( itemNotaApolice.getUsuarioAtualizacao() ) );
        }
        itemNota_.setCodigoSequencia( itemNotaApolice.getCodigoSequencia() );
        itemNota_.setDescricaoNota( itemNotaApolice.getDescricaoNota() );

        return itemNota_;
    }

    @Override
    public ItemDistribuicao fromItemDistribuicaoVrApoliceToItemDistribuicao(ItemDistribuicaoVrApolice itemNotaApolice) {
        if ( itemNotaApolice == null ) {
            return null;
        }

        ItemDistribuicao itemDistribuicao_ = new ItemDistribuicao();

        itemDistribuicao_.setSequencialDistribuicaoValorRisco( itemNotaApolice.getCdSequencia() );
        itemDistribuicao_.setDescricaoRiscoBem( itemNotaApolice.getDescricaoRiscoBem() );
        itemDistribuicao_.setIdTipoValorRisco( itemNotaApolice.getIdTipoValorRisco() );
        itemDistribuicao_.setValorRiscoBem( itemNotaApolice.getValorRiscoBem() );
        itemDistribuicao_.setValorRiscoBemMoedaEstrangeira( itemNotaApolice.getValorRiscoBemMoedaEstrangeira() );

        return itemDistribuicao_;
    }

    @Override
    public ItemSistemaProtecional fromItemDistribuicaoVrApoliceToItemDistribuicao(ItemSistemaProtecionalApolice itemSistemaProtecionalApolice) {
        if ( itemSistemaProtecionalApolice == null ) {
            return null;
        }

        ItemSistemaProtecional itemSistemaProtecional_ = new ItemSistemaProtecional();

        itemSistemaProtecional_.setCodigoGrupo( itemSistemaProtecionalApolice.getCodigoGrupo() );
        itemSistemaProtecional_.setDataAtualizacao( itemSistemaProtecionalApolice.getDataAtualizacao() );
        if ( itemSistemaProtecionalApolice.getUsuarioAtualizacao() != null ) {
            itemSistemaProtecional_.setUsuarioAtualizacao( Long.parseLong( itemSistemaProtecionalApolice.getUsuarioAtualizacao() ) );
        }
        itemSistemaProtecional_.setCodigoSistemaProtecional( itemSistemaProtecionalApolice.getCodigoSistemaProtecional() );
        itemSistemaProtecional_.setPercentualDesconto( itemSistemaProtecionalApolice.getPercentualDesconto() );

        return itemSistemaProtecional_;
    }

    @Override
    public ItemAeronave fromItemAeronaveApoliceToItemAeronave(ItemAeronaveApolice itemAeronaveApolice) {
        if ( itemAeronaveApolice == null ) {
            return null;
        }

        ItemAeronave itemAeronave_ = new ItemAeronave();

        itemAeronave_.setCodigoGrupo( itemAeronaveApolice.getCodigoGrupo() );
        itemAeronave_.setDataAtualizacao( itemAeronaveApolice.getDataAtualizacao() );
        if ( itemAeronaveApolice.getUsuarioAtualizacao() != null ) {
            itemAeronave_.setUsuarioAtualizacao( Long.parseLong( itemAeronaveApolice.getUsuarioAtualizacao() ) );
        }
        itemAeronave_.setDescricaoCertificado( itemAeronaveApolice.getDescricaoCertificado() );
        itemAeronave_.setDescricaoPrefixo( itemAeronaveApolice.getDescricaoPrefixo() );
        itemAeronave_.setDescricaoTipoAeronave( itemAeronaveApolice.getDescricaoTipoAeronave() );
        itemAeronave_.setDescricaoUtilizacao( itemAeronaveApolice.getDescricaoUtilizacao() );
        itemAeronave_.setIdAnoFabricacao( itemAeronaveApolice.getIdAnoFabricacao() );
        itemAeronave_.setIdUtilizaBagagem( itemAeronaveApolice.getIdUtilizaBagagem() );
        itemAeronave_.setNomeFabricante( itemAeronaveApolice.getNomeFabricante() );
        itemAeronave_.setNomeModelo( itemAeronaveApolice.getNomeModelo() );
        itemAeronave_.setNumeroOcupantes( itemAeronaveApolice.getNumeroOcupantes() );
        itemAeronave_.setNumeroPassageiros( itemAeronaveApolice.getNumeroPassageiros() );
        itemAeronave_.setNumeroPesoMaximo( itemAeronaveApolice.getNumeroPesoMaximo() );
        itemAeronave_.setNumeroSerie( itemAeronaveApolice.getNumeroSerie() );
        itemAeronave_.setNumeroTripulantes( itemAeronaveApolice.getNumeroTripulantes() );

        return itemAeronave_;
    }

    @Override
    public ItemQBR fromItemQbrApoliceToItemQBR(ItemQbrApolice itemQbrApolice) {
        if ( itemQbrApolice == null ) {
            return null;
        }

        ItemQBR itemQBR_ = new ItemQBR();

        itemQBR_.setCodigoGrupo( itemQbrApolice.getCodigoGrupo() );
        itemQBR_.setDataAtualizacao( itemQbrApolice.getDataAtualizacao() );
        if ( itemQbrApolice.getUsuarioAtualizacao() != null ) {
            itemQBR_.setUsuarioAtualizacao( Long.parseLong( itemQbrApolice.getUsuarioAtualizacao() ) );
        }
        itemQBR_.setIdPergunta( itemQbrApolice.getIdPergunta() );
        itemQBR_.setIdResposta( itemQbrApolice.getIdResposta() );

        return itemQBR_;
    }

    @Override
    public ItemBeneficiario fromItemBeneficiarioApoliceToItemBeneficiario(ItemBeneficiarioApolice itemBeneficiarioApolice) {
        if ( itemBeneficiarioApolice == null ) {
            return null;
        }

        ItemBeneficiario itemBeneficiario_ = new ItemBeneficiario();

        itemBeneficiario_.setNumeroCPFCNPJ( itemBeneficiarioApolice.getNumeroCpfCnpj() );
        itemBeneficiario_.setNumeroBeneficiario( itemBeneficiarioApolice.getCdBeneficiario() );
        itemBeneficiario_.setCodigoGrupo( itemBeneficiarioApolice.getCodigoGrupo() );
        itemBeneficiario_.setDataAtualizacao( itemBeneficiarioApolice.getDataAtualizacao() );
        if ( itemBeneficiarioApolice.getUsuarioAtualizacao() != null ) {
            itemBeneficiario_.setUsuarioAtualizacao( Long.parseLong( itemBeneficiarioApolice.getUsuarioAtualizacao() ) );
        }
        itemBeneficiario_.setDescricaoComplemento( itemBeneficiarioApolice.getDescricaoComplemento() );
        itemBeneficiario_.setNomePessoa( itemBeneficiarioApolice.getNomePessoa() );
        itemBeneficiario_.setPercentualDistribuicao( itemBeneficiarioApolice.getPercentualDistribuicao() );
        itemBeneficiario_.setTipoPessoa( itemBeneficiarioApolice.getTipoPessoa() );
        itemBeneficiario_.setValorDistribuicao( itemBeneficiarioApolice.getValorDistribuicao() );
        itemBeneficiario_.setValorDistribuicaoMoedaEstrangeira( itemBeneficiarioApolice.getValorDistribuicaoMoedaEstrangeira() );

        return itemBeneficiario_;
    }

    @Override
    public ItemCossegurado fromItemCosseguradoApoliceToItemCossegurado(ItemCosseguradoApolice itemCosseguradoApolice) {
        if ( itemCosseguradoApolice == null ) {
            return null;
        }

        ItemCossegurado itemCossegurado_ = new ItemCossegurado();

        itemCossegurado_.setCodigoGrupo( itemCosseguradoApolice.getCodigoGrupo() );
        itemCossegurado_.setDataAtualizacao( itemCosseguradoApolice.getDataAtualizacao() );
        if ( itemCosseguradoApolice.getUsuarioAtualizacao() != null ) {
            itemCossegurado_.setUsuarioAtualizacao( Long.parseLong( itemCosseguradoApolice.getUsuarioAtualizacao() ) );
        }
        itemCossegurado_.setNomePessoa( itemCosseguradoApolice.getNomePessoa() );
        itemCossegurado_.setNumeroCPFCNPJ( itemCosseguradoApolice.getNumeroCPFCNPJ() );
        itemCossegurado_.setNumeroCossegurado( itemCosseguradoApolice.getNumeroCossegurado() );
        itemCossegurado_.setTipoPessoa( itemCosseguradoApolice.getTipoPessoa() );

        return itemCossegurado_;
    }

    @Override
    public ItemRamoEmissao fromItemRamoEmissaoApoliceToItemRamoEmissao(ItemRamoEmissaoApolice itemRamoEmissaoApolice) {
        if ( itemRamoEmissaoApolice == null ) {
            return null;
        }

        ItemRamoEmissao itemRamoEmissao_ = new ItemRamoEmissao();

        itemRamoEmissao_.setValorIS( itemRamoEmissaoApolice.getValorIs() );
        itemRamoEmissao_.setValorDMMoedaEstrangeira( itemRamoEmissaoApolice.getValorDmMoedaEstrangeira() );
        itemRamoEmissao_.setCodigoGrupoRamo( itemRamoEmissaoApolice.getCodigoGrupoRamoEmissao() );
        itemRamoEmissao_.setValorDM( itemRamoEmissaoApolice.getValorDm() );
        itemRamoEmissao_.setValorLMRMoedaEstrangeira( itemRamoEmissaoApolice.getValorLmrMoedaEstrangeira() );
        itemRamoEmissao_.setValorLCMoedaEstrangeira( itemRamoEmissaoApolice.getValorLcMoedaEstrangeira() );
        itemRamoEmissao_.setValorLMR( itemRamoEmissaoApolice.getValorLmr() );
        itemRamoEmissao_.setValorISMoedaEstrangeira( itemRamoEmissaoApolice.getValorIsMoedaEstrangeira() );
        itemRamoEmissao_.setValorLC( itemRamoEmissaoApolice.getValorLc() );
        itemRamoEmissao_.setCodigoRamo( itemRamoEmissaoApolice.getCodigoRamoEmissao() );
        itemRamoEmissao_.setCodigoGrupo( itemRamoEmissaoApolice.getCodigoGrupo() );
        itemRamoEmissao_.setDataAtualizacao( itemRamoEmissaoApolice.getDataAtualizacao() );
        if ( itemRamoEmissaoApolice.getUsuarioAtualizacao() != null ) {
            itemRamoEmissao_.setUsuarioAtualizacao( Long.parseLong( itemRamoEmissaoApolice.getUsuarioAtualizacao() ) );
        }
        itemRamoEmissao_.setComplementoLmr( itemRamoEmissaoApolice.getComplementoLmr() );
        itemRamoEmissao_.setPercentualComissao( itemRamoEmissaoApolice.getPercentualComissao() );
        itemRamoEmissao_.setProcessoSusep( itemRamoEmissaoApolice.getProcessoSusep() );
        itemRamoEmissao_.setValorPremio( itemRamoEmissaoApolice.getValorPremio() );
        itemRamoEmissao_.setValorPremioMoedaEstrangeira( itemRamoEmissaoApolice.getValorPremioMoedaEstrangeira() );
        itemRamoEmissao_.setValorPremioNet( itemRamoEmissaoApolice.getValorPremioNet() );
        itemRamoEmissao_.setValorPremioNetMoedaEstrangeira( itemRamoEmissaoApolice.getValorPremioNetMoedaEstrangeira() );

        return itemRamoEmissao_;
    }

    @Override
    public ItemCobertura fromItemCoberturaApoliceToItemCobertura(ItemCoberturaApolice itemCoberturaApolice) {
        if ( itemCoberturaApolice == null ) {
            return null;
        }

        ItemCobertura itemCobertura_ = new ItemCobertura();

        itemCobertura_.setListaItemCoberturaClausula( itemCobClausulaApoliceListToItemCoberturaClausulaList( itemCoberturaApolice.getListItemCobClausulaApolice() ) );
        itemCobertura_.setListItemEquipamentoFranquia( itemCobEquipFranquiaApoliceListToItemEquipamentoFranquiaList( itemCoberturaApolice.getListItemCobEquipFranquiaApolice() ) );
        itemCobertura_.setNumeroVagasGaragem( itemCoberturaApolice.getNumeroVagas() );
        itemCobertura_.setIdExclusaEndosso( itemCoberturaApolice.getIdExclusaoEndosso() );
        itemCobertura_.setDescricaoTextoFranquia( itemCoberturaApolice.getDescricaoComplementoFranquia() );
        itemCobertura_.setValorISMoedaEstrangeira( itemCoberturaApolice.getValorIsMoedaEstrangeira() );
        itemCobertura_.setDescricaoCobertura( itemCoberturaApolice.getDescricaoComplementoCobertura() );
        itemCobertura_.setValorSublimiteOriginal( itemCoberturaApolice.getValorSubLimiteOriginal() );
        itemCobertura_.setIdFranquiaInformado( itemCoberturaApolice.getIdFranquiaInformada() );
        itemCobertura_.setCoberturaPrincipal( itemCoberturaApolice.getCodigoCoberturaPrincipal() );
        itemCobertura_.setValorImportanciaSegurada( itemCoberturaApolice.getValorIs() );
        itemCobertura_.setValorSublimite( itemCoberturaApolice.getValorSubLimite() );
        itemCobertura_.setValorSublimiteOriginalMoedaEstrangeira( itemCoberturaApolice.getValorSubLimiteOriginalMoedaEstrangeira() );
        itemCobertura_.setListDescontoAgravacao( itemCobDescAgravApoliceListToDescontoAgravacaoList( itemCoberturaApolice.getListItemCobDescAgravApolice() ) );
        itemCobertura_.setValorSublimiteMoedaEstrangeira( itemCoberturaApolice.getValorSubLimiteMoedaEstrangeira() );
        itemCobertura_.setDescricaoFranquia( itemCoberturaApolice.getDescricaoTextoFranquia() );
        itemCobertura_.setCodigoGrupo( itemCoberturaApolice.getCodigoGrupo() );
        itemCobertura_.setDataAtualizacao( itemCoberturaApolice.getDataAtualizacao() );
        if ( itemCoberturaApolice.getUsuarioAtualizacao() != null ) {
            itemCobertura_.setUsuarioAtualizacao( Long.parseLong( itemCoberturaApolice.getUsuarioAtualizacao() ) );
        }
        itemCobertura_.setCodigoCobertura( itemCoberturaApolice.getCodigoCobertura() );
        itemCobertura_.setCodigoGrupoRamoContabil( itemCoberturaApolice.getCodigoGrupoRamoContabil() );
        itemCobertura_.setCodigoGrupoRamoEmissao( itemCoberturaApolice.getCodigoGrupoRamoEmissao() );
        itemCobertura_.setCodigoPeriodoIndenitario( itemCoberturaApolice.getCodigoPeriodoIndenitario() );
        itemCobertura_.setCodigoRamoCoberturaContabil( itemCoberturaApolice.getCodigoRamoCoberturaContabil() );
        itemCobertura_.setCodigoRamoCoberturaEmissao( itemCoberturaApolice.getCodigoRamoCoberturaEmissao() );
        itemCobertura_.setCodigoRessegurador( itemCoberturaApolice.getCodigoRessegurador() );
        itemCobertura_.setDataEmissaoOficio( itemCoberturaApolice.getDataEmissaoOficio() );
        itemCobertura_.setDescricaoComplementoCobertura( itemCoberturaApolice.getDescricaoComplementoCobertura() );
        itemCobertura_.setIdCoberturaAvulsa( itemCoberturaApolice.getIdCoberturaAvulsa() );
        itemCobertura_.setIdDanosMateriais( itemCoberturaApolice.getIdDanosMateriais() );
        itemCobertura_.setIdExigeOficio( itemCoberturaApolice.getIdExigeOficio() );
        itemCobertura_.setIdFormaFranquia( itemCoberturaApolice.getIdFormaFranquia() );
        itemCobertura_.setIdLMR( itemCoberturaApolice.getIdLMR() );
        itemCobertura_.setIdLmrDiferente( itemCoberturaApolice.getIdLmrDiferente() );
        itemCobertura_.setIdLucrosCessantes( itemCoberturaApolice.getIdLucrosCessantes() );
        itemCobertura_.setIdOficioRessegurador( itemCoberturaApolice.getIdOficioRessegurador() );
        itemCobertura_.setIdTextoFranquia( itemCoberturaApolice.getIdTextoFranquia() );
        itemCobertura_.setIdTipoCobertura( itemCoberturaApolice.getIdTipoCobertura() );
        itemCobertura_.setNumeroDiasFranquia( itemCoberturaApolice.getNumeroDiasFranquia() );
        itemCobertura_.setNumeroHorasFranquia( itemCoberturaApolice.getNumeroHorasFranquia() );
        itemCobertura_.setNumeroMultiploFranquia( itemCoberturaApolice.getNumeroMultiploFranquia() );
        itemCobertura_.setNumeroMultiploPrejuizo( itemCoberturaApolice.getNumeroMultiploPrejuizo() );
        itemCobertura_.setPercentualPremioDepositoMinimo( itemCoberturaApolice.getPercentualPremioDepositoMinimo() );
        itemCobertura_.setPercentualTaxaCalculoPremio( itemCoberturaApolice.getPercentualTaxaCalculoPremio() );
        itemCobertura_.setTaxaFranquia( itemCoberturaApolice.getTaxaFranquia() );
        itemCobertura_.setTaxaImportanciaSegurada( itemCoberturaApolice.getTaxaImportanciaSegurada() );
        itemCobertura_.setTaxaImportanciaSeguradaMaxima( itemCoberturaApolice.getTaxaImportanciaSeguradaMaxima() );
        itemCobertura_.setTaxaImportanciaSeguradaMinima( itemCoberturaApolice.getTaxaImportanciaSeguradaMinima() );
        itemCobertura_.setValorFranquia( itemCoberturaApolice.getValorFranquia() );
        itemCobertura_.setValorFranquiaMaxima( itemCoberturaApolice.getValorFranquiaMaxima() );
        itemCobertura_.setValorFranquiaMinima( itemCoberturaApolice.getValorFranquiaMinima() );
        itemCobertura_.setValorPremio( itemCoberturaApolice.getValorPremio() );
        itemCobertura_.setValorPremioMoedaEstrangeira( itemCoberturaApolice.getValorPremioMoedaEstrangeira() );
        itemCobertura_.setValorPremioNET( itemCoberturaApolice.getValorPremioNET() );
        itemCobertura_.setValorPremioReferencial( itemCoberturaApolice.getValorPremioReferencial() );
        itemCobertura_.setValorPremioVigencia( itemCoberturaApolice.getValorPremioVigencia() );
        itemCobertura_.setValorRiscoBem( itemCoberturaApolice.getValorRiscoBem() );
        itemCobertura_.setValorRiscoBemMoedaEstrangeira( itemCoberturaApolice.getValorRiscoBemMoedaEstrangeira() );

        return itemCobertura_;
    }

    @Override
    public DescontoAgravacao fromItemCobDescAgravApoliceToDescontoAgravacao(ItemCobDescAgravApolice itemCoberturaApolice) {
        if ( itemCoberturaApolice == null ) {
            return null;
        }

        DescontoAgravacao descontoAgravacao_ = new DescontoAgravacao();

        descontoAgravacao_.setCodigoGrupo( itemCoberturaApolice.getCodigoGrupo() );
        descontoAgravacao_.setDataAtualizacao( itemCoberturaApolice.getDataAtualizacao() );
        if ( itemCoberturaApolice.getUsuarioAtualizacao() != null ) {
            descontoAgravacao_.setUsuarioAtualizacao( Long.parseLong( itemCoberturaApolice.getUsuarioAtualizacao() ) );
        }
        descontoAgravacao_.setCodigoCobertura( itemCoberturaApolice.getCodigoCobertura() );
        descontoAgravacao_.setDescricaoDescontoAgravacao( itemCoberturaApolice.getDescricaoDescontoAgravacao() );
        descontoAgravacao_.setPercentualDescontoAgravacao( itemCoberturaApolice.getPercentualDescontoAgravacao() );

        return descontoAgravacao_;
    }

    @Override
    public ItemCoberturaClausula fromItemCobClausulaApoliceToItemCoberturaClausula(ItemCobClausulaApolice itemCobClausulaApolice) {
        if ( itemCobClausulaApolice == null ) {
            return null;
        }

        ItemCoberturaClausula itemCoberturaClausula_ = new ItemCoberturaClausula();

        itemCoberturaClausula_.setCodigoClausula( itemCobClausulaApolice.getCodigoClausulaNota() );
        itemCoberturaClausula_.setCodigoGrupo( itemCobClausulaApolice.getCodigoGrupo() );
        itemCoberturaClausula_.setDataAtualizacao( itemCobClausulaApolice.getDataAtualizacao() );
        if ( itemCobClausulaApolice.getUsuarioAtualizacao() != null ) {
            itemCoberturaClausula_.setUsuarioAtualizacao( Long.parseLong( itemCobClausulaApolice.getUsuarioAtualizacao() ) );
        }
        itemCoberturaClausula_.setCodigoGrupoRamo( itemCobClausulaApolice.getCodigoGrupoRamo() );
        itemCoberturaClausula_.setCodigoRamo( itemCobClausulaApolice.getCodigoRamo() );

        return itemCoberturaClausula_;
    }

    @Override
    public ItemEquipamentoFranquia itemCobEquipFranquiaApoliceToItemEquipamentoFranquia(ItemCobEquipFranquiaApolice itemCobEquipFranquiaApolice) {
        if ( itemCobEquipFranquiaApolice == null ) {
            return null;
        }

        ItemEquipamentoFranquia itemEquipamentoFranquia_ = new ItemEquipamentoFranquia();

        itemEquipamentoFranquia_.setDescricaoFranquia( itemCobEquipFranquiaApolice.getDescricaoTextoFranquia() );
        itemEquipamentoFranquia_.setDescricaoTextoFranquia( itemCobEquipFranquiaApolice.getDescricaoComplementoFranquia() );
        itemEquipamentoFranquia_.setCodigoGrupo( itemCobEquipFranquiaApolice.getCodigoGrupo() );
        itemEquipamentoFranquia_.setDataAtualizacao( itemCobEquipFranquiaApolice.getDataAtualizacao() );
        if ( itemCobEquipFranquiaApolice.getUsuarioAtualizacao() != null ) {
            itemEquipamentoFranquia_.setUsuarioAtualizacao( Long.parseLong( itemCobEquipFranquiaApolice.getUsuarioAtualizacao() ) );
        }
        itemEquipamentoFranquia_.setCodigoEquipamento( itemCobEquipFranquiaApolice.getCodigoEquipamento() );
        itemEquipamentoFranquia_.setDescricaoEquipamento( itemCobEquipFranquiaApolice.getDescricaoEquipamento() );
        itemEquipamentoFranquia_.setIdFormaFranquia( formaFranquiaEnumMapper.toEnum( itemCobEquipFranquiaApolice.getIdFormaFranquia() ) );
        itemEquipamentoFranquia_.setIdTextoFranquia( itemCobEquipFranquiaApolice.getIdTextoFranquia() );
        itemEquipamentoFranquia_.setNumeroDiasFranquia( itemCobEquipFranquiaApolice.getNumeroDiasFranquia() );
        itemEquipamentoFranquia_.setNumeroHorasFranquia( itemCobEquipFranquiaApolice.getNumeroHorasFranquia() );
        itemEquipamentoFranquia_.setTaxaFranquia( itemCobEquipFranquiaApolice.getTaxaFranquia() );
        itemEquipamentoFranquia_.setTaxaImportanciaSegurada( itemCobEquipFranquiaApolice.getTaxaImportanciaSegurada() );
        itemEquipamentoFranquia_.setTaxaImportanciaSeguradaMaximo( itemCobEquipFranquiaApolice.getTaxaImportanciaSeguradaMaximo() );
        itemEquipamentoFranquia_.setTaxaImportanciaSeguradaMinimo( itemCobEquipFranquiaApolice.getTaxaImportanciaSeguradaMinimo() );
        itemEquipamentoFranquia_.setValorFranquia( itemCobEquipFranquiaApolice.getValorFranquia() );
        itemEquipamentoFranquia_.setValorFranquiaMaximo( itemCobEquipFranquiaApolice.getValorFranquiaMaximo() );
        itemEquipamentoFranquia_.setValorFranquiaMinimo( itemCobEquipFranquiaApolice.getValorFranquiaMinimo() );

        return itemEquipamentoFranquia_;
    }

    @Override
    public ItemSinistro fromItemSinistroApoliceToItemSinistro(ItemSinistroApolice itemSinistroApolice) {
        if ( itemSinistroApolice == null ) {
            return null;
        }

        ItemSinistro itemSinistro_ = new ItemSinistro();

        itemSinistro_.setListItemCoberturaSinistro( itemCoberturaSinistroApoliceListToItemCoberturaSinistroSet( itemSinistroApolice.getListItemCoberturaSinistroApolice() ) );
        itemSinistro_.setCodigoGrupo( itemSinistroApolice.getCodigoGrupo() );
        itemSinistro_.setDataAtualizacao( itemSinistroApolice.getDataAtualizacao() );
        if ( itemSinistroApolice.getUsuarioAtualizacao() != null ) {
            itemSinistro_.setUsuarioAtualizacao( Long.parseLong( itemSinistroApolice.getUsuarioAtualizacao() ) );
        }
        itemSinistro_.setCodigoLetraSinistro( itemSinistroApolice.getCodigoLetraSinistro() );
        if ( itemSinistroApolice.getCodigoLocalSinistro() != null ) {
            itemSinistro_.setCodigoLocalSinistro( itemSinistroApolice.getCodigoLocalSinistro().intValue() );
        }
        if ( itemSinistroApolice.getCodigoRamoSinistro() != null ) {
            itemSinistro_.setCodigoRamoSinistro( itemSinistroApolice.getCodigoRamoSinistro().intValue() );
        }
        if ( itemSinistroApolice.getCodigoSinistro() != null ) {
            itemSinistro_.setCodigoSinistro( itemSinistroApolice.getCodigoSinistro().intValue() );
        }
        itemSinistro_.setDataOcorrencia( itemSinistroApolice.getDataOcorrencia() );

        return itemSinistro_;
    }

    @Override
    public ItemCoberturaSinistro fromItemCoberturaSinistroApoliceToItemCoberturaSinistro(ItemCoberturaSinistroApolice itemCoberturaSinistroApolice) {
        if ( itemCoberturaSinistroApolice == null ) {
            return null;
        }

        ItemCoberturaSinistro itemCoberturaSinistro_ = new ItemCoberturaSinistro();

        itemCoberturaSinistro_.setValorPagamentoIndenizacao( itemCoberturaSinistroApolice.getVlIsReduzida() );
        itemCoberturaSinistro_.setValorISReintegrada( itemCoberturaSinistroApolice.getVlIsReintegrada() );
        itemCoberturaSinistro_.setCodigoGrupo( itemCoberturaSinistroApolice.getCodigoGrupo() );
        itemCoberturaSinistro_.setDataAtualizacao( itemCoberturaSinistroApolice.getDataAtualizacao() );
        if ( itemCoberturaSinistroApolice.getUsuarioAtualizacao() != null ) {
            itemCoberturaSinistro_.setUsuarioAtualizacao( Long.parseLong( itemCoberturaSinistroApolice.getUsuarioAtualizacao() ) );
        }
        if ( itemCoberturaSinistroApolice.getCodigoCobertura() != null ) {
            itemCoberturaSinistro_.setCodigoCobertura( itemCoberturaSinistroApolice.getCodigoCobertura().intValue() );
        }
        itemCoberturaSinistro_.setCodigoMovimentoSinistro( itemCoberturaSinistroApolice.getCodigoMovimentoSinistro() );

        return itemCoberturaSinistro_;
    }

    @Override
    public DocumentoDigital apoliceDocumentoDigitalToDocumentoDigital(ApoliceDocumentoDigital apoliceDocumentoDigital) {
        if ( apoliceDocumentoDigital == null ) {
            return null;
        }

        DocumentoDigital documentoDigital_ = new DocumentoDigital();

        documentoDigital_.setDataAtualizacao( apoliceDocumentoDigital.getDataAtualizacao() );
        if ( apoliceDocumentoDigital.getUsuarioAtualizacao() != null ) {
            documentoDigital_.setUsuarioAtualizacao( Long.parseLong( apoliceDocumentoDigital.getUsuarioAtualizacao() ) );
        }
        documentoDigital_.setNumeroCotacaoProposta( apoliceDocumentoDigital.getNumeroCotacaoProposta() );
        documentoDigital_.setVersaoCotacaoProposta( apoliceDocumentoDigital.getVersaoCotacaoProposta() );
        documentoDigital_.setDestino( apoliceDocumentoDigital.getDestino() );
        documentoDigital_.setEmailCorretor( apoliceDocumentoDigital.getEmailCorretor() );
        documentoDigital_.setEmailSegurado( apoliceDocumentoDigital.getEmailSegurado() );
        documentoDigital_.setFormaEnvio( apoliceDocumentoDigital.getFormaEnvio() );
        documentoDigital_.setIdEnvioSegurado( apoliceDocumentoDigital.getIdEnvioSegurado() );
        documentoDigital_.setSequencialDocumentoDigital( apoliceDocumentoDigital.getSequencialDocumentoDigital() );

        return documentoDigital_;
    }

    protected Set<ComissaoCotacao> comissaoApoliceListToComissaoCotacaoSet(List<ComissaoApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ComissaoCotacao> set = new HashSet<ComissaoCotacao>();
        for ( ComissaoApolice comissaoApolice : list ) {
            set.add( fromComissaoApoliceToComissaoCotacao( comissaoApolice ) );
        }

        return set;
    }

    protected Set<CosseguroCotacao> cosseguroApoliceListToCosseguroCotacaoSet(List<CosseguroApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<CosseguroCotacao> set = new HashSet<CosseguroCotacao>();
        for ( CosseguroApolice cosseguroApolice : list ) {
            set.add( fromCosseguroApoliceToCosseguroCotacao( cosseguroApolice ) );
        }

        return set;
    }

    protected List<CorretagemCotacao> corretagemApoliceListToCorretagemCotacaoList(List<CorretagemApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<CorretagemCotacao> list_ = new ArrayList<CorretagemCotacao>();
        for ( CorretagemApolice corretagemApolice : list ) {
            list_.add( fromCorretagemApoliceToCorretagemCotacao( corretagemApolice ) );
        }

        return list_;
    }

    private SolicitanteEndossoEnum solicitacaoCotacaoCdTipoEndosSscSolicitanteEndosso(SolicitacaoCotacao solicitacaoCotacao) {

        if ( solicitacaoCotacao == null ) {
            return null;
        }
        TipoEndossoSctEnum cdTipoEndosSsc = solicitacaoCotacao.getCdTipoEndosSsc();
        if ( cdTipoEndosSsc == null ) {
            return null;
        }
        SolicitanteEndossoEnum solicitanteEndosso = cdTipoEndosSsc.getSolicitanteEndosso();
        if ( solicitanteEndosso == null ) {
            return null;
        }
        return solicitanteEndosso;
    }

    protected Set<ItemCotacao> itemApoliceListToItemCotacaoSet(List<ItemApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemCotacao> set = new HashSet<ItemCotacao>();
        for ( ItemApolice itemApolice : list ) {
            set.add( fromItemDadosObraApoliceToItemDadosObra( itemApolice ) );
        }

        return set;
    }

    protected List<ClausulaCotacao> clausulaApoliceListToClausulaCotacaoList(List<ClausulaApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ClausulaCotacao> list_ = new ArrayList<ClausulaCotacao>();
        for ( ClausulaApolice clausulaApolice : list ) {
            list_.add( fromClausulaApoliceToClausulaCotacao( clausulaApolice ) );
        }

        return list_;
    }

    protected List<NotaCotacao> notaApoliceListToNotaCotacaoList(List<NotaApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<NotaCotacao> list_ = new ArrayList<NotaCotacao>();
        for ( NotaApolice notaApolice : list ) {
            list_.add( fromNotaApoliceToNotaCotacao( notaApolice ) );
        }

        return list_;
    }

    private TipoEndossoEnum solicitacaoCotacaoCdTipoEndosSscTipoEndossoCTPJ(SolicitacaoCotacao solicitacaoCotacao) {

        if ( solicitacaoCotacao == null ) {
            return null;
        }
        TipoEndossoSctEnum cdTipoEndosSsc = solicitacaoCotacao.getCdTipoEndosSsc();
        if ( cdTipoEndosSsc == null ) {
            return null;
        }
        TipoEndossoEnum tipoEndossoCTPJ = cdTipoEndosSsc.getTipoEndossoCTPJ();
        if ( tipoEndossoCTPJ == null ) {
            return null;
        }
        return tipoEndossoCTPJ;
    }

    protected List<ItemPiloto> itemPilotoApoliceListToItemPilotoList(List<ItemPilotoApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemPiloto> list_ = new ArrayList<ItemPiloto>();
        for ( ItemPilotoApolice itemPilotoApolice : list ) {
            list_.add( fromItemPilotoApoliceToItemPiloto( itemPilotoApolice ) );
        }

        return list_;
    }

    protected List<ItemDadosObra> itemDadosObraApoliceListToItemDadosObraList(List<ItemDadosObraApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemDadosObra> list_ = new ArrayList<ItemDadosObra>();
        for ( ItemDadosObraApolice itemDadosObraApolice : list ) {
            list_.add( fromItemOutroSeguroApoliceToItemOutroSeguro( itemDadosObraApolice ) );
        }

        return list_;
    }

    protected Set<ItemRamoEmissao> itemRamoEmissaoApoliceListToItemRamoEmissaoSet(List<ItemRamoEmissaoApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemRamoEmissao> set = new HashSet<ItemRamoEmissao>();
        for ( ItemRamoEmissaoApolice itemRamoEmissaoApolice : list ) {
            set.add( fromItemRamoEmissaoApoliceToItemRamoEmissao( itemRamoEmissaoApolice ) );
        }

        return set;
    }

    protected List<ItemEmbarque> itemEmbarqueApoliceListToItemEmbarqueList(List<ItemEmbarqueApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemEmbarque> list_ = new ArrayList<ItemEmbarque>();
        for ( ItemEmbarqueApolice itemEmbarqueApolice : list ) {
            list_.add( fromItemEmbarqueApoliceToItemEmbarque( itemEmbarqueApolice ) );
        }

        return list_;
    }

    protected List<ItemCossegurado> itemCosseguradoApoliceListToItemCosseguradoList(List<ItemCosseguradoApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemCossegurado> list_ = new ArrayList<ItemCossegurado>();
        for ( ItemCosseguradoApolice itemCosseguradoApolice : list ) {
            list_.add( fromItemCosseguradoApoliceToItemCossegurado( itemCosseguradoApolice ) );
        }

        return list_;
    }

    protected List<ItemRelacaoBem> itemRelacaoBemApoliceListToItemRelacaoBemList(List<ItemRelacaoBemApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemRelacaoBem> list_ = new ArrayList<ItemRelacaoBem>();
        for ( ItemRelacaoBemApolice itemRelacaoBemApolice : list ) {
            list_.add( fromItemRelacaoBemApoliceToItemRelacaoBemApolice( itemRelacaoBemApolice ) );
        }

        return list_;
    }

    protected List<ItemQBR> itemQbrApoliceListToItemQBRList(List<ItemQbrApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemQBR> list_ = new ArrayList<ItemQBR>();
        for ( ItemQbrApolice itemQbrApolice : list ) {
            list_.add( fromItemQbrApoliceToItemQBR( itemQbrApolice ) );
        }

        return list_;
    }

    protected Set<ItemDistribuicao> itemDistribuicaoVrApoliceListToItemDistribuicaoSet(List<ItemDistribuicaoVrApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemDistribuicao> set = new HashSet<ItemDistribuicao>();
        for ( ItemDistribuicaoVrApolice itemDistribuicaoVrApolice : list ) {
            set.add( fromItemDistribuicaoVrApoliceToItemDistribuicao( itemDistribuicaoVrApolice ) );
        }

        return set;
    }

    protected Set<ItemCobertura> itemCoberturaApoliceListToItemCoberturaSet(List<ItemCoberturaApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemCobertura> set = new HashSet<ItemCobertura>();
        for ( ItemCoberturaApolice itemCoberturaApolice : list ) {
            set.add( fromItemCoberturaApoliceToItemCobertura( itemCoberturaApolice ) );
        }

        return set;
    }

    protected Set<ItemSinistro> itemSinistroApoliceListToItemSinistroSet(List<ItemSinistroApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemSinistro> set = new HashSet<ItemSinistro>();
        for ( ItemSinistroApolice itemSinistroApolice : list ) {
            set.add( fromItemSinistroApoliceToItemSinistro( itemSinistroApolice ) );
        }

        return set;
    }

    protected List<ItemOutroSeguro> itemOutroSeguroApoliceListToItemOutroSeguroList(List<ItemOutroSeguroApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemOutroSeguro> list_ = new ArrayList<ItemOutroSeguro>();
        for ( ItemOutroSeguroApolice itemOutroSeguroApolice : list ) {
            list_.add( fromItemOutroSeguroApoliceToItemOutroSeguro( itemOutroSeguroApolice ) );
        }

        return list_;
    }

    protected List<ItemBeneficiario> itemBeneficiarioApoliceListToItemBeneficiarioList(List<ItemBeneficiarioApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemBeneficiario> list_ = new ArrayList<ItemBeneficiario>();
        for ( ItemBeneficiarioApolice itemBeneficiarioApolice : list ) {
            list_.add( fromItemBeneficiarioApoliceToItemBeneficiario( itemBeneficiarioApolice ) );
        }

        return list_;
    }

    protected Set<ItemSistemaProtecional> itemSistemaProtecionalApoliceListToItemSistemaProtecionalSet(List<ItemSistemaProtecionalApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemSistemaProtecional> set = new HashSet<ItemSistemaProtecional>();
        for ( ItemSistemaProtecionalApolice itemSistemaProtecionalApolice : list ) {
            set.add( fromItemDistribuicaoVrApoliceToItemDistribuicao( itemSistemaProtecionalApolice ) );
        }

        return set;
    }

    protected List<ItemRelacaoEndereco> itemRelacaoEnderecoApoliceListToItemRelacaoEnderecoList(List<ItemRelacaoEnderecoApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemRelacaoEndereco> list_ = new ArrayList<ItemRelacaoEndereco>();
        for ( ItemRelacaoEnderecoApolice itemRelacaoEnderecoApolice : list ) {
            list_.add( fromItemRelacaoEnderecoApoliceToItemRelacaoEndereco( itemRelacaoEnderecoApolice ) );
        }

        return list_;
    }

    protected List<ItemNota> itemNotaApoliceListToItemNotaList(List<ItemNotaApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemNota> list_ = new ArrayList<ItemNota>();
        for ( ItemNotaApolice itemNotaApolice : list ) {
            list_.add( fromItemNotaApoliceToItemNota( itemNotaApolice ) );
        }

        return list_;
    }

    protected List<ItemEmbarcacao> itemEmbarcacaoApoliceListToItemEmbarcacaoList(List<ItemEmbarcacaoApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemEmbarcacao> list_ = new ArrayList<ItemEmbarcacao>();
        for ( ItemEmbarcacaoApolice itemEmbarcacaoApolice : list ) {
            list_.add( fromItemEmbarcacaoApoliceToItemEmbarcacao( itemEmbarcacaoApolice ) );
        }

        return list_;
    }

    protected List<ItemAeronave> itemAeronaveApoliceListToItemAeronaveList(List<ItemAeronaveApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemAeronave> list_ = new ArrayList<ItemAeronave>();
        for ( ItemAeronaveApolice itemAeronaveApolice : list ) {
            list_.add( fromItemAeronaveApoliceToItemAeronave( itemAeronaveApolice ) );
        }

        return list_;
    }

    protected List<ItemCoberturaClausula> itemCobClausulaApoliceListToItemCoberturaClausulaList(List<ItemCobClausulaApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemCoberturaClausula> list_ = new ArrayList<ItemCoberturaClausula>();
        for ( ItemCobClausulaApolice itemCobClausulaApolice : list ) {
            list_.add( fromItemCobClausulaApoliceToItemCoberturaClausula( itemCobClausulaApolice ) );
        }

        return list_;
    }

    protected List<ItemEquipamentoFranquia> itemCobEquipFranquiaApoliceListToItemEquipamentoFranquiaList(List<ItemCobEquipFranquiaApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemEquipamentoFranquia> list_ = new ArrayList<ItemEquipamentoFranquia>();
        for ( ItemCobEquipFranquiaApolice itemCobEquipFranquiaApolice : list ) {
            list_.add( itemCobEquipFranquiaApoliceToItemEquipamentoFranquia( itemCobEquipFranquiaApolice ) );
        }

        return list_;
    }

    protected List<DescontoAgravacao> itemCobDescAgravApoliceListToDescontoAgravacaoList(List<ItemCobDescAgravApolice> list) {
        if ( list == null ) {
            return null;
        }

        List<DescontoAgravacao> list_ = new ArrayList<DescontoAgravacao>();
        for ( ItemCobDescAgravApolice itemCobDescAgravApolice : list ) {
            list_.add( fromItemCobDescAgravApoliceToDescontoAgravacao( itemCobDescAgravApolice ) );
        }

        return list_;
    }

    protected Set<ItemCoberturaSinistro> itemCoberturaSinistroApoliceListToItemCoberturaSinistroSet(List<ItemCoberturaSinistroApolice> list) {
        if ( list == null ) {
            return null;
        }

        Set<ItemCoberturaSinistro> set = new HashSet<ItemCoberturaSinistro>();
        for ( ItemCoberturaSinistroApolice itemCoberturaSinistroApolice : list ) {
            set.add( fromItemCoberturaSinistroApoliceToItemCoberturaSinistro( itemCoberturaSinistroApolice ) );
        }

        return set;
    }
}
