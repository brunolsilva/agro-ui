package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.CoberturaValor;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaView;
import br.com.tokiomarine.ctpj.domain.cotacao.AlteracaoEndosso;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import java.math.BigDecimal;
import java.util.ArrayList;
import javax.annotation.Generated;
import org.mapstruct.factory.Mappers;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CoberturaViewMapperImpl extends CoberturaViewMapper {

    private final NumberMapper numberMapper = Mappers.getMapper( NumberMapper.class );
    private final SimNaoMapper simNaoMapper = new SimNaoMapper();

    @Override
    public void toCobertura(CotacaoView cotacaoView, ItemCoberturaView itemCoberturaBasicaView, ItemCobertura itemCobertura) {
        if ( cotacaoView == null && itemCoberturaBasicaView == null ) {
            return;
        }

        if ( cotacaoView != null ) {
            itemCobertura.setNumeroCotacaoProposta( cotacaoView.getNumeroCotacaoProposta() );
            itemCobertura.setVersaoCotacaoProposta( cotacaoView.getVersaoCotacaoProposta() );
        }
        if ( itemCoberturaBasicaView != null ) {
            itemCobertura.setCoberturaPrincipal( itemCoberturaBasicaView.getCoberturaPrincipal() );
            itemCobertura.setCodigoCobertura( itemCoberturaBasicaView.getCodigoCobertura() );
            itemCobertura.setCodigoPeriodoIndenitario( itemCoberturaBasicaView.getCodigoPeriodoIndenitario() );
            itemCobertura.setDescricaoCobertura( itemCoberturaBasicaView.getDescricaoCobertura() );
            itemCobertura.setDescricaoCoberturaAjustada( itemCoberturaBasicaView.getDescricaoCoberturaAjustada() );
            itemCobertura.setDescricaoComplementoCobertura( itemCoberturaBasicaView.getDescricaoComplementoCobertura() );
            itemCobertura.setExigeVagasGaragem( itemCoberturaBasicaView.isExigeVagasGaragem() );
            itemCobertura.setExigeValorRisco( itemCoberturaBasicaView.isExigeValorRisco() );
            if ( itemCoberturaBasicaView.getIdCoberturaAvulsa() != null ) {
                itemCobertura.setIdCoberturaAvulsa( simNaoMapper.toEnum( itemCoberturaBasicaView.getIdCoberturaAvulsa().booleanValue() ) );
            }
            if ( itemCoberturaBasicaView.getIdDanosMateriais() != null ) {
                itemCobertura.setIdDanosMateriais( simNaoMapper.toEnum( itemCoberturaBasicaView.getIdDanosMateriais().booleanValue() ) );
            }
            if ( itemCoberturaBasicaView.getIdLucrosCessantes() != null ) {
                itemCobertura.setIdLucrosCessantes( simNaoMapper.toEnum( itemCoberturaBasicaView.getIdLucrosCessantes().booleanValue() ) );
            }
            itemCobertura.setIdTipoCobertura( itemCoberturaBasicaView.getIdTipoCobertura() );
            itemCobertura.setNumeroMultiploFranquia( itemCoberturaBasicaView.getNumeroMultiploFranquia() );
            itemCobertura.setNumeroMultiploPrejuizo( itemCoberturaBasicaView.getNumeroMultiploPrejuizo() );
            itemCobertura.setNumeroVagasGaragem( itemCoberturaBasicaView.getNumeroVagasGaragem() );
            itemCobertura.setValorISMoedaEstrangeira( numberMapper.asDecimal( itemCoberturaBasicaView.getValorISMoedaEstrangeira() ) );
            itemCobertura.setValorImportanciaSegurada( numberMapper.asDecimal( itemCoberturaBasicaView.getValorImportanciaSegurada() ) );
            itemCobertura.setValorRiscoBem( numberMapper.asDecimal( itemCoberturaBasicaView.getValorRiscoBem() ) );
            itemCobertura.setValorSublimiteMoedaEstrangeira( numberMapper.asDecimal( itemCoberturaBasicaView.getValorSublimiteMoedaEstrangeira() ) );
            itemCobertura.setValorSublimiteOriginalMoedaEstrangeira( numberMapper.asDecimal( itemCoberturaBasicaView.getValorSublimiteOriginalMoedaEstrangeira() ) );
        }

        dadosCoberturaAvulsa( cotacaoView, itemCoberturaBasicaView, itemCobertura );
    }

    @Override
    public ItemCoberturaView copiaItemCobertura(ItemCoberturaView origem) {
        if ( origem == null ) {
            return null;
        }

        ItemCoberturaView itemCoberturaView = new ItemCoberturaView();

        itemCoberturaView.setSequencialItemCobertura( origem.getSequencialItemCobertura() );
        itemCoberturaView.setCodigoCobertura( origem.getCodigoCobertura() );
        itemCoberturaView.setDescricaoCobertura( origem.getDescricaoCobertura() );
        itemCoberturaView.setIdCoberturaAvulsa( origem.getIdCoberturaAvulsa() );
        itemCoberturaView.setCodigoRamoCobertura( origem.getCodigoRamoCobertura() );
        itemCoberturaView.setValorImportanciaSegurada( origem.getValorImportanciaSegurada() );
        itemCoberturaView.setValorSublimite( origem.getValorSublimite() );
        itemCoberturaView.setValorSublimiteOriginal( origem.getValorSublimiteOriginal() );
        itemCoberturaView.setIdFormaFranquia( origem.getIdFormaFranquia() );
        itemCoberturaView.setIdTextoFranquia( origem.getIdTextoFranquia() );
        itemCoberturaView.setIdLMR( origem.getIdLMR() );
        itemCoberturaView.setCodigoGrupoRamo( origem.getCodigoGrupoRamo() );
        itemCoberturaView.setValorISMoedaEstrangeira( origem.getValorISMoedaEstrangeira() );
        itemCoberturaView.setValorSublimiteMoedaEstrangeira( origem.getValorSublimiteMoedaEstrangeira() );
        itemCoberturaView.setValorSublimiteOriginalMoedaEstrangeira( origem.getValorSublimiteOriginalMoedaEstrangeira() );
        itemCoberturaView.setIdTipoCobertura( origem.getIdTipoCobertura() );
        itemCoberturaView.setPercentualTaxaCalculoPremio( origem.getPercentualTaxaCalculoPremio() );
        itemCoberturaView.setIdLucrosCessantes( origem.getIdLucrosCessantes() );
        itemCoberturaView.setIdDanosMateriais( origem.getIdDanosMateriais() );
        itemCoberturaView.setCodigoPeriodoIndenitario( origem.getCodigoPeriodoIndenitario() );
        itemCoberturaView.setNumeroMultiploFranquia( origem.getNumeroMultiploFranquia() );
        itemCoberturaView.setNumeroMultiploPrejuizo( origem.getNumeroMultiploPrejuizo() );
        itemCoberturaView.setExigeValorRisco( origem.isExigeValorRisco() );
        itemCoberturaView.setValorRiscoBem( origem.getValorRiscoBem() );
        itemCoberturaView.setDescricaoComplementoCobertura( origem.getDescricaoComplementoCobertura() );
        itemCoberturaView.setIdExclusaEndosso( origem.getIdExclusaEndosso() );
        if ( origem.getValoresCobertura() != null ) {
            itemCoberturaView.setValoresCobertura( new ArrayList<CoberturaValor>( origem.getValoresCobertura() ) );
        }
        if ( origem.getPeriodosIndenitarios() != null ) {
            itemCoberturaView.setPeriodosIndenitarios( new ArrayList<Integer>( origem.getPeriodosIndenitarios() ) );
        }
        if ( origem.getMultiplosPrejuizo() != null ) {
            itemCoberturaView.setMultiplosPrejuizo( new ArrayList<BigDecimal>( origem.getMultiplosPrejuizo() ) );
        }
        if ( origem.getMultiplosFranquia() != null ) {
            itemCoberturaView.setMultiplosFranquia( new ArrayList<BigDecimal>( origem.getMultiplosFranquia() ) );
        }
        itemCoberturaView.setNumeroVagasGaragem( origem.getNumeroVagasGaragem() );
        itemCoberturaView.setExigeVagasGaragem( origem.isExigeVagasGaragem() );
        itemCoberturaView.setExigeIS( origem.isExigeIS() );
        itemCoberturaView.setCoberturaPrincipal( origem.getCoberturaPrincipal() );
        itemCoberturaView.setDescricaoCoberturaAjustada( origem.getDescricaoCoberturaAjustada() );

        return itemCoberturaView;
    }

    @Override
    public ItemCobertura copiaItemCobertura(ItemCobertura origem) {
        if ( origem == null ) {
            return null;
        }

        ItemCobertura itemCobertura = new ItemCobertura();

        itemCobertura.setCodigoGrupo( origem.getCodigoGrupo() );
        itemCobertura.setDataAtualizacao( origem.getDataAtualizacao() );
        itemCobertura.setUsuarioAtualizacao( origem.getUsuarioAtualizacao() );
        itemCobertura.setNumeroCotacaoProposta( origem.getNumeroCotacaoProposta() );
        itemCobertura.setVersaoCotacaoProposta( origem.getVersaoCotacaoProposta() );
        itemCobertura.setCoberturaPrincipal( origem.getCoberturaPrincipal() );
        itemCobertura.setCodigoCobertura( origem.getCodigoCobertura() );
        itemCobertura.setCodigoGrupoRamoContabil( origem.getCodigoGrupoRamoContabil() );
        itemCobertura.setCodigoGrupoRamoEmissao( origem.getCodigoGrupoRamoEmissao() );
        itemCobertura.setCodigoLimiteAgrupamento( origem.getCodigoLimiteAgrupamento() );
        itemCobertura.setCodigoPeriodoIndenitario( origem.getCodigoPeriodoIndenitario() );
        itemCobertura.setCodigoRamoCoberturaContabil( origem.getCodigoRamoCoberturaContabil() );
        itemCobertura.setCodigoRamoCoberturaEmissao( origem.getCodigoRamoCoberturaEmissao() );
        itemCobertura.setCodigoRessegurador( origem.getCodigoRessegurador() );
        itemCobertura.setDataEmissaoOficio( origem.getDataEmissaoOficio() );
        itemCobertura.setDescricaoCobertura( origem.getDescricaoCobertura() );
        itemCobertura.setDescricaoCoberturaAjustada( origem.getDescricaoCoberturaAjustada() );
        itemCobertura.setDescricaoComplementoCobertura( origem.getDescricaoComplementoCobertura() );
        itemCobertura.setDescricaoFranquia( origem.getDescricaoFranquia() );
        itemCobertura.setDescricaoTextoFranquia( origem.getDescricaoTextoFranquia() );
        itemCobertura.setExigePeriodoIndenitario( origem.isExigePeriodoIndenitario() );
        itemCobertura.setExigeVagasGaragem( origem.isExigeVagasGaragem() );
        itemCobertura.setExigeValorRisco( origem.isExigeValorRisco() );
        itemCobertura.setFormaLimiteIS( origem.isFormaLimiteIS() );
        itemCobertura.setIdAjustamentoPremio( origem.getIdAjustamentoPremio() );
        itemCobertura.setIdCoberturaAvulsa( origem.getIdCoberturaAvulsa() );
        itemCobertura.setIdControleExclusaoEndosso( origem.getIdControleExclusaoEndosso() );
        itemCobertura.setIdDanosMateriais( origem.getIdDanosMateriais() );
        itemCobertura.setIdExclusaEndosso( origem.getIdExclusaEndosso() );
        itemCobertura.setIdExigeOficio( origem.getIdExigeOficio() );
        itemCobertura.setIdFormaFranquia( origem.getIdFormaFranquia() );
        itemCobertura.setIdFranquiaInformado( origem.getIdFranquiaInformado() );
        itemCobertura.setIdLMR( origem.getIdLMR() );
        itemCobertura.setIdLmrDiferente( origem.getIdLmrDiferente() );
        itemCobertura.setIdLucrosCessantes( origem.getIdLucrosCessantes() );
        itemCobertura.setIdOficioRessegurador( origem.getIdOficioRessegurador() );
        itemCobertura.setIdOrigemApolice( origem.getIdOrigemApolice() );
        itemCobertura.setIdSublimiteInformado( origem.getIdSublimiteInformado() );
        itemCobertura.setIdTextoFranquia( origem.getIdTextoFranquia() );
        itemCobertura.setIdTipoCobertura( origem.getIdTipoCobertura() );
        itemCobertura.setLiberaSublimite( origem.isLiberaSublimite() );
        if ( origem.getListAlteracaoEndosso() != null ) {
            itemCobertura.setListAlteracaoEndosso( new ArrayList<AlteracaoEndosso>( origem.getListAlteracaoEndosso() ) );
        }
        itemCobertura.setNumeroDiasFranquia( origem.getNumeroDiasFranquia() );
        itemCobertura.setNumeroHorasFranquia( origem.getNumeroHorasFranquia() );
        itemCobertura.setNumeroMultiploFranquia( origem.getNumeroMultiploFranquia() );
        itemCobertura.setNumeroMultiploPrejuizo( origem.getNumeroMultiploPrejuizo() );
        itemCobertura.setNumeroVagasGaragem( origem.getNumeroVagasGaragem() );
        itemCobertura.setPercentualPremioDepositoMinimo( origem.getPercentualPremioDepositoMinimo() );
        itemCobertura.setPercentualTaxaCalculoPremio( origem.getPercentualTaxaCalculoPremio() );
        itemCobertura.setPerfilCalculoCoberturaLimiteIs( origem.getPerfilCalculoCoberturaLimiteIs() );
        itemCobertura.setTaxaFranquia( origem.getTaxaFranquia() );
        itemCobertura.setTaxaImportanciaSegurada( origem.getTaxaImportanciaSegurada() );
        itemCobertura.setTaxaImportanciaSeguradaMaxima( origem.getTaxaImportanciaSeguradaMaxima() );
        itemCobertura.setTaxaImportanciaSeguradaMinima( origem.getTaxaImportanciaSeguradaMinima() );
        itemCobertura.setTipoIS( origem.getTipoIS() );
        itemCobertura.setValorFranquia( origem.getValorFranquia() );
        itemCobertura.setValorFranquiaEnviado( origem.getValorFranquiaEnviado() );
        itemCobertura.setValorFranquiaMaxima( origem.getValorFranquiaMaxima() );
        itemCobertura.setValorFranquiaMinima( origem.getValorFranquiaMinima() );
        itemCobertura.setValorISMoedaEstrangeira( origem.getValorISMoedaEstrangeira() );
        itemCobertura.setValorISOriginal( origem.getValorISOriginal() );
        itemCobertura.setValorImportanciaSegurada( origem.getValorImportanciaSegurada() );
        itemCobertura.setValorImportanciaSeguradaEnviado( origem.getValorImportanciaSeguradaEnviado() );
        itemCobertura.setValorPremio( origem.getValorPremio() );
        itemCobertura.setValorPremioEnviado( origem.getValorPremioEnviado() );
        itemCobertura.setValorPremioMoedaEstrangeira( origem.getValorPremioMoedaEstrangeira() );
        itemCobertura.setValorPremioNET( origem.getValorPremioNET() );
        itemCobertura.setValorPremioNETMoedaEstrangeira( origem.getValorPremioNETMoedaEstrangeira() );
        itemCobertura.setValorPremioParteAjustavel( origem.getValorPremioParteAjustavel() );
        itemCobertura.setValorPremioParteFixa( origem.getValorPremioParteFixa() );
        itemCobertura.setValorPremioReferencial( origem.getValorPremioReferencial() );
        itemCobertura.setValorPremioVigencia( origem.getValorPremioVigencia() );
        itemCobertura.setValorRiscoBem( origem.getValorRiscoBem() );
        itemCobertura.setValorRiscoBemMoedaEstrangeira( origem.getValorRiscoBemMoedaEstrangeira() );
        itemCobertura.setValorSublimite( origem.getValorSublimite() );
        itemCobertura.setValorSublimiteMoedaEstrangeira( origem.getValorSublimiteMoedaEstrangeira() );
        itemCobertura.setValorSublimiteOriginal( origem.getValorSublimiteOriginal() );
        itemCobertura.setValorSublimiteOriginalMoedaEstrangeira( origem.getValorSublimiteOriginalMoedaEstrangeira() );

        return itemCobertura;
    }
}
