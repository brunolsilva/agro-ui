package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.CosseguroView;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CosseguroMapperImpl implements CosseguroMapper {

    @Override
    public CosseguroView toView(CosseguroCotacao cossseguro) {
        if ( cossseguro == null ) {
            return null;
        }

        CosseguroView cosseguroView = new CosseguroView();

        if ( cossseguro.getPercentualCosseguro() != null ) {
            cosseguroView.setPercentualCosseguro( cossseguro.getPercentualCosseguro().toString() );
        }
        if ( cossseguro.getPercentualComissaoDiferenciada() != null ) {
            cosseguroView.setPercentualComissaoDiferenciada( cossseguro.getPercentualComissaoDiferenciada().toString() );
        }
        cosseguroView.setCodigoCompanhiaSeguradora( cossseguro.getCodigoCompanhiaSeguradora() );
        cosseguroView.setNomeCompanhiaSeguradora( cossseguro.getNomeCompanhiaSeguradora() );

        return cosseguroView;
    }

    @Override
    public List<CosseguroView> toView(List<CosseguroCotacao> cosseguro) {
        if ( cosseguro == null ) {
            return null;
        }

        List<CosseguroView> list = new ArrayList<CosseguroView>();
        for ( CosseguroCotacao cosseguroCotacao : cosseguro ) {
            list.add( toView( cosseguroCotacao ) );
        }

        return list;
    }

    private DecimalFormat createDecimalFormat( String numberFormat ) {

        DecimalFormat df = new DecimalFormat( numberFormat );
        df.setParseBigDecimal( true );
        return df;
    }
}
