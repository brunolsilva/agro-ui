package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemEquipamentoFranquiaView;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import org.mapstruct.factory.Mappers;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class FranquiaMapperImpl extends FranquiaMapper {

    private final NumberMapper numberMapper = Mappers.getMapper( NumberMapper.class );

    @Override
    public ItemCobertura toCobertura(ItemCoberturaFranquiaView franquia, ItemCobertura itemCobertura) {
        if ( franquia == null ) {
            return null;
        }

        itemCobertura.setNumeroCotacaoProposta( franquia.getNumeroCotacaoProposta() );
        itemCobertura.setVersaoCotacaoProposta( franquia.getVersaoCotacaoProposta() );
        itemCobertura.setDescricaoTextoFranquia( franquia.getDescricaoTextoFranquia() );
        itemCobertura.setIdFormaFranquia( franquia.getIdFormaFranquia() );
        itemCobertura.setIdTextoFranquia( franquia.getIdTextoFranquia() );
        itemCobertura.setNumeroDiasFranquia( franquia.getNumeroDiasFranquia() );
        itemCobertura.setNumeroHorasFranquia( franquia.getNumeroHorasFranquia() );
        itemCobertura.setTaxaFranquia( numberMapper.asDecimal( franquia.getTaxaFranquia() ) );
        itemCobertura.setTaxaImportanciaSegurada( numberMapper.asDecimal( franquia.getTaxaImportanciaSegurada() ) );
        itemCobertura.setTaxaImportanciaSeguradaMaxima( numberMapper.asDecimal( franquia.getTaxaImportanciaSeguradaMaxima() ) );
        itemCobertura.setTaxaImportanciaSeguradaMinima( numberMapper.asDecimal( franquia.getTaxaImportanciaSeguradaMinima() ) );
        itemCobertura.setValorFranquia( numberMapper.asDecimal( franquia.getValorFranquia() ) );
        itemCobertura.setValorFranquiaMaxima( numberMapper.asDecimal( franquia.getValorFranquiaMaxima() ) );
        itemCobertura.setValorFranquiaMinima( numberMapper.asDecimal( franquia.getValorFranquiaMinima() ) );

        setListItemEquipamentosFranquia( itemCobertura, franquia );

        return itemCobertura;
    }

    @Override
    public ItemCobertura toCoberturaView(ItemCoberturaFranquiaView franquia) {
        if ( franquia == null ) {
            return null;
        }

        ItemCobertura itemCobertura = new ItemCobertura();

        itemCobertura.setNumeroCotacaoProposta( franquia.getNumeroCotacaoProposta() );
        itemCobertura.setVersaoCotacaoProposta( franquia.getVersaoCotacaoProposta() );
        itemCobertura.setDescricaoTextoFranquia( franquia.getDescricaoTextoFranquia() );
        itemCobertura.setIdFormaFranquia( franquia.getIdFormaFranquia() );
        itemCobertura.setIdFranquiaInformado( franquia.getIdFranquiaInformado() );
        itemCobertura.setIdTextoFranquia( franquia.getIdTextoFranquia() );
        itemCobertura.setNumeroDiasFranquia( franquia.getNumeroDiasFranquia() );
        itemCobertura.setNumeroHorasFranquia( franquia.getNumeroHorasFranquia() );
        itemCobertura.setTaxaFranquia( numberMapper.asDecimal( franquia.getTaxaFranquia() ) );
        itemCobertura.setTaxaImportanciaSegurada( numberMapper.asDecimal( franquia.getTaxaImportanciaSegurada() ) );
        itemCobertura.setTaxaImportanciaSeguradaMaxima( numberMapper.asDecimal( franquia.getTaxaImportanciaSeguradaMaxima() ) );
        itemCobertura.setTaxaImportanciaSeguradaMinima( numberMapper.asDecimal( franquia.getTaxaImportanciaSeguradaMinima() ) );
        itemCobertura.setValorFranquia( numberMapper.asDecimal( franquia.getValorFranquia() ) );
        itemCobertura.setValorFranquiaMaxima( numberMapper.asDecimal( franquia.getValorFranquiaMaxima() ) );
        itemCobertura.setValorFranquiaMinima( numberMapper.asDecimal( franquia.getValorFranquiaMinima() ) );

        setListItemEquipamentosFranquia( itemCobertura, franquia );

        return itemCobertura;
    }

    @Override
    ItemCoberturaFranquiaView toFranquia(ItemCobertura itemCobertura) {
        if ( itemCobertura == null ) {
            return null;
        }

        ItemCoberturaFranquiaView itemCoberturaFranquiaView = new ItemCoberturaFranquiaView();

        itemCoberturaFranquiaView.setTaxaImportanciaSeguradaMaxima( numberMapper.asDecimal5( itemCobertura.getTaxaImportanciaSeguradaMaxima() ) );
        itemCoberturaFranquiaView.setTaxaImportanciaSegurada( numberMapper.asDecimal5( itemCobertura.getTaxaImportanciaSegurada() ) );
        itemCoberturaFranquiaView.setTaxaFranquia( numberMapper.asDecimal5( itemCobertura.getTaxaFranquia() ) );
        itemCoberturaFranquiaView.setValorFranquia( numberMapper.asDecimal2( itemCobertura.getValorFranquia() ) );
        itemCoberturaFranquiaView.setValorFranquiaMaxima( numberMapper.asDecimal2( itemCobertura.getValorFranquiaMaxima() ) );
        itemCoberturaFranquiaView.setValorFranquiaMinima( numberMapper.asDecimal2( itemCobertura.getValorFranquiaMinima() ) );
        itemCoberturaFranquiaView.setTaxaImportanciaSeguradaMinima( numberMapper.asDecimal5( itemCobertura.getTaxaImportanciaSeguradaMinima() ) );
        itemCoberturaFranquiaView.setSequencialItemCobertura( itemCobertura.getSequencialItemCobertura() );
        itemCoberturaFranquiaView.setCodigoCobertura( itemCobertura.getCodigoCobertura() );
        itemCoberturaFranquiaView.setDescricaoCobertura( itemCobertura.getDescricaoCobertura() );
        itemCoberturaFranquiaView.setIdFormaFranquia( itemCobertura.getIdFormaFranquia() );
        itemCoberturaFranquiaView.setNumeroHorasFranquia( itemCobertura.getNumeroHorasFranquia() );
        itemCoberturaFranquiaView.setNumeroDiasFranquia( itemCobertura.getNumeroDiasFranquia() );
        itemCoberturaFranquiaView.setIdTextoFranquia( itemCobertura.getIdTextoFranquia() );
        itemCoberturaFranquiaView.setDescricaoTextoFranquia( itemCobertura.getDescricaoTextoFranquia() );
        itemCoberturaFranquiaView.setNumeroCotacaoProposta( itemCobertura.getNumeroCotacaoProposta() );
        itemCoberturaFranquiaView.setVersaoCotacaoProposta( itemCobertura.getVersaoCotacaoProposta() );
        itemCoberturaFranquiaView.setIdFranquiaInformado( itemCobertura.getIdFranquiaInformado() );

        setListItemEquipamentosFranquiaView( itemCobertura, itemCoberturaFranquiaView );

        return itemCoberturaFranquiaView;
    }

    @Override
    public List<ItemCoberturaFranquiaView> toFranquia(List<ItemCobertura> itemCobertura) {
        if ( itemCobertura == null ) {
            return null;
        }

        List<ItemCoberturaFranquiaView> list = new ArrayList<ItemCoberturaFranquiaView>();
        for ( ItemCobertura itemCobertura_ : itemCobertura ) {
            list.add( toFranquia( itemCobertura_ ) );
        }

        return list;
    }

    @Override
    public ItemCoberturaFranquiaView toFranquiaView(ItemCoberturaFranquiaView franquia) {
        if ( franquia == null ) {
            return null;
        }

        ItemCoberturaFranquiaView itemCoberturaFranquiaView = new ItemCoberturaFranquiaView();

        itemCoberturaFranquiaView.setSequencialItemCobertura( franquia.getSequencialItemCobertura() );
        itemCoberturaFranquiaView.setCodigoCobertura( franquia.getCodigoCobertura() );
        itemCoberturaFranquiaView.setDescricaoCobertura( franquia.getDescricaoCobertura() );
        itemCoberturaFranquiaView.setIdFormaFranquia( franquia.getIdFormaFranquia() );
        itemCoberturaFranquiaView.setNumeroHorasFranquia( franquia.getNumeroHorasFranquia() );
        itemCoberturaFranquiaView.setNumeroDiasFranquia( franquia.getNumeroDiasFranquia() );
        itemCoberturaFranquiaView.setTaxaFranquia( franquia.getTaxaFranquia() );
        itemCoberturaFranquiaView.setValorFranquia( franquia.getValorFranquia() );
        itemCoberturaFranquiaView.setValorFranquiaMinima( franquia.getValorFranquiaMinima() );
        itemCoberturaFranquiaView.setValorFranquiaMaxima( franquia.getValorFranquiaMaxima() );
        itemCoberturaFranquiaView.setTaxaImportanciaSegurada( franquia.getTaxaImportanciaSegurada() );
        itemCoberturaFranquiaView.setTaxaImportanciaSeguradaMinima( franquia.getTaxaImportanciaSeguradaMinima() );
        itemCoberturaFranquiaView.setTaxaImportanciaSeguradaMaxima( franquia.getTaxaImportanciaSeguradaMaxima() );
        itemCoberturaFranquiaView.setIdTextoFranquia( franquia.getIdTextoFranquia() );
        itemCoberturaFranquiaView.setDescricaoTextoFranquia( franquia.getDescricaoTextoFranquia() );
        if ( franquia.getListItemEquipamentoFranquia() != null ) {
            itemCoberturaFranquiaView.setListItemEquipamentoFranquia( new ArrayList<ItemEquipamentoFranquiaView>( franquia.getListItemEquipamentoFranquia() ) );
        }
        itemCoberturaFranquiaView.setNumeroCotacaoProposta( franquia.getNumeroCotacaoProposta() );
        itemCoberturaFranquiaView.setVersaoCotacaoProposta( franquia.getVersaoCotacaoProposta() );
        if ( franquia.getListItemEquipamentoFranquiaDelete() != null ) {
            itemCoberturaFranquiaView.setListItemEquipamentoFranquiaDelete( new ArrayList<ItemEquipamentoFranquiaView>( franquia.getListItemEquipamentoFranquiaDelete() ) );
        }
        itemCoberturaFranquiaView.setSequencialItemCotacao( franquia.getSequencialItemCotacao() );
        itemCoberturaFranquiaView.setIdFranquiaInformado( franquia.getIdFranquiaInformado() );
        itemCoberturaFranquiaView.setFranquiaInformada( franquia.getFranquiaInformada() );

        return itemCoberturaFranquiaView;
    }
}
