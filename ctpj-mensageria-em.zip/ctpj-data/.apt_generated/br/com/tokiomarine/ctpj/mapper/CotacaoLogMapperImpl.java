package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoLogResponse;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CotacaoLog;
import java.math.BigInteger;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CotacaoLogMapperImpl extends CotacaoLogMapper {

    @Override
    public CotacaoLogResponse toCotacaoLogResponse(CotacaoLog source) {
        if ( source == null ) {
            return null;
        }

        CotacaoLogResponse cotacaoLogResponse = new CotacaoLogResponse();

        cotacaoLogResponse.setSeqCotacao( sourceCotacaoSequencialCotacaoProposta( source ) );
        cotacaoLogResponse.setSequencialCotacaoLog( source.getSequencialCotacaoLog() );
        cotacaoLogResponse.setSequencialItemCotacao( source.getSequencialItemCotacao() );
        cotacaoLogResponse.setNumeroItem( source.getNumeroItem() );
        cotacaoLogResponse.setIdTipoLog( toTipoProcessamentoEnum( source.getIdTipoLog() ) );
        cotacaoLogResponse.setRequest( source.getRequest() );
        cotacaoLogResponse.setResponse( source.getResponse() );
        cotacaoLogResponse.setSessionId( source.getSessionId() );
        cotacaoLogResponse.setStatusLog( source.getStatusLog() );
        cotacaoLogResponse.setObservacao( source.getObservacao() );
        cotacaoLogResponse.setCodigoCobertura( source.getCodigoCobertura() );

        return cotacaoLogResponse;
    }

    private BigInteger sourceCotacaoSequencialCotacaoProposta(CotacaoLog cotacaoLog) {

        if ( cotacaoLog == null ) {
            return null;
        }
        Cotacao cotacao = cotacaoLog.getCotacao();
        if ( cotacao == null ) {
            return null;
        }
        BigInteger sequencialCotacaoProposta = cotacao.getSequencialCotacaoProposta();
        if ( sequencialCotacaoProposta == null ) {
            return null;
        }
        return sequencialCotacaoProposta;
    }
}
