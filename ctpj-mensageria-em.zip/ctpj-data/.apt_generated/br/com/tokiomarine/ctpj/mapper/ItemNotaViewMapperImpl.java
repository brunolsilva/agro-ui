package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemNotaView;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemNota;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class ItemNotaViewMapperImpl implements ItemNotaViewMapper {

    @Override
    public ItemNotaView toItemNotaView(ItemNota itemNota) {
        if ( itemNota == null ) {
            return null;
        }

        ItemNotaView itemNotaView = new ItemNotaView();

        itemNotaView.setSequencialItemCotacao( itemNotaItemCotacaoSequencialItemCotacao( itemNota ) );
        itemNotaView.setSequencialItemNota( itemNota.getSequencialItemNota() );
        itemNotaView.setCodigoSequencia( itemNota.getCodigoSequencia() );
        itemNotaView.setDescricaoNota( itemNota.getDescricaoNota() );
        itemNotaView.setNumeroCotacaoProposta( itemNota.getNumeroCotacaoProposta() );
        itemNotaView.setVersaoCotacaoProposta( itemNota.getVersaoCotacaoProposta() );
        itemNotaView.setDataAtualizacao( itemNota.getDataAtualizacao() );
        itemNotaView.setCodigoGrupo( itemNota.getCodigoGrupo() );
        itemNotaView.setUsuarioAtualizacao( itemNota.getUsuarioAtualizacao() );

        return itemNotaView;
    }

    @Override
    public List<ItemNotaView> toItensNotaView(List<ItemNota> ItensNota) {
        if ( ItensNota == null ) {
            return null;
        }

        List<ItemNotaView> list = new ArrayList<ItemNotaView>();
        for ( ItemNota itemNota : ItensNota ) {
            list.add( toItemNotaView( itemNota ) );
        }

        return list;
    }

    @Override
    public ItemNota toItemNota(ItemNotaView itemNotaView) {
        if ( itemNotaView == null ) {
            return null;
        }

        ItemNota itemNota = new ItemNota();

        itemNota.setCodigoGrupo( itemNotaView.getCodigoGrupo() );
        itemNota.setDataAtualizacao( itemNotaView.getDataAtualizacao() );
        itemNota.setUsuarioAtualizacao( itemNotaView.getUsuarioAtualizacao() );
        itemNota.setNumeroCotacaoProposta( itemNotaView.getNumeroCotacaoProposta() );
        itemNota.setVersaoCotacaoProposta( itemNotaView.getVersaoCotacaoProposta() );
        itemNota.setCodigoSequencia( itemNotaView.getCodigoSequencia() );
        itemNota.setDescricaoNota( itemNotaView.getDescricaoNota() );
        itemNota.setSequencialItemNota( itemNotaView.getSequencialItemNota() );

        return itemNota;
    }

    @Override
    public List<ItemNota> toItensNota(List<ItemNotaView> itensNotaView) {
        if ( itensNotaView == null ) {
            return null;
        }

        List<ItemNota> list = new ArrayList<ItemNota>();
        for ( ItemNotaView itemNotaView : itensNotaView ) {
            list.add( toItemNota( itemNotaView ) );
        }

        return list;
    }

    private BigInteger itemNotaItemCotacaoSequencialItemCotacao(ItemNota itemNota) {

        if ( itemNota == null ) {
            return null;
        }
        ItemCotacao itemCotacao = itemNota.getItemCotacao();
        if ( itemCotacao == null ) {
            return null;
        }
        BigInteger sequencialItemCotacao = itemCotacao.getSequencialItemCotacao();
        if ( sequencialItemCotacao == null ) {
            return null;
        }
        return sequencialItemCotacao;
    }
}
