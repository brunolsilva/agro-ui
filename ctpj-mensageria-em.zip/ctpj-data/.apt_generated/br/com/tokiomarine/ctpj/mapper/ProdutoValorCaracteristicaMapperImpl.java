package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.dto.ProdutoValorCarac;
import br.com.tokiomarine.ctpj.infra.domain.CaracteristicaValor;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class ProdutoValorCaracteristicaMapperImpl implements ProdutoValorCaracteristicaMapper {

    @Override
    public ProdutoValorCarac toProdValorCaracDTO(CaracteristicaValor valorCaracteristica, Integer produto) {
        if ( valorCaracteristica == null && produto == null ) {
            return null;
        }

        ProdutoValorCarac produtoValorCarac = new ProdutoValorCarac();

        if ( valorCaracteristica != null ) {
            produtoValorCarac.setCaracteristica( valorCaracteristica.getCaracteristica() );
            produtoValorCarac.setValorCaracteristica( valorCaracteristica.getValorCaracteristica() );
            produtoValorCarac.setDescricaoValor( valorCaracteristica.getDescricaoValor() );
            produtoValorCarac.setIdKme( valorCaracteristica.getIdKme() );
        }
        if ( produto != null ) {
            produtoValorCarac.setProduto( produto );
        }

        return produtoValorCarac;
    }
}
