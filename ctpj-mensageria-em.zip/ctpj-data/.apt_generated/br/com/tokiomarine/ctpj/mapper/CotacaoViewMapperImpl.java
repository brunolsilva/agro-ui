package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.CorretagemView;
import br.com.tokiomarine.ctpj.cotacao.dto.CosseguroView;
import br.com.tokiomarine.ctpj.cotacao.dto.CotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaPremioFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCoberturaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoPremioFranquiaView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemCotacaoView;
import br.com.tokiomarine.ctpj.cotacao.dto.ItemDistribuicaoView;
import br.com.tokiomarine.ctpj.domain.cotacao.CorretagemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.CosseguroCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.Cotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCotacao;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemDistribuicao;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import javax.annotation.Generated;
import org.mapstruct.factory.Mappers;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class CotacaoViewMapperImpl extends CotacaoViewMapper {

    private final NumberMapper numberMapper = Mappers.getMapper( NumberMapper.class );
    private final SimNaoMapper simNaoMapper = new SimNaoMapper();

    @Override
    public CotacaoView toCotacaoView(Cotacao cotacao) {
        if ( cotacao == null ) {
            return null;
        }

        CotacaoView cotacaoView = new CotacaoView();

        if ( cotacao.getCodigoTipoEndossoEndossada() != null ) {
            cotacaoView.setCdTipoEndosEndso( cotacao.getCodigoTipoEndossoEndossada().longValue() );
        }
        cotacaoView.setCodigoSituacaoReadOnly( cotacao.getCodigoSituacao() );
        cotacaoView.setCdEndosEndso( cotacao.getCodigoEndossoEndossado() );
        if ( cotacao.getIdCEPSegurado() != null ) {
            cotacaoView.setIdCEPSegurado( String.valueOf( cotacao.getIdCEPSegurado() ) );
        }
        cotacaoView.setSequencialCotacaoProposta( cotacao.getSequencialCotacaoProposta() );
        cotacaoView.setDataCotacao( cotacao.getDataCotacao() );
        cotacaoView.setNumeroCNPJCPFSegurado( cotacao.getNumeroCNPJCPFSegurado() );
        cotacaoView.setIdTipoPessoa( cotacao.getIdTipoPessoa() );
        cotacaoView.setNomeSegurado( cotacao.getNomeSegurado() );
        cotacaoView.setCodigoAtividadePrincipal( cotacao.getCodigoAtividadePrincipal() );
        cotacaoView.setDescricaoAtividadePrincipal( cotacao.getDescricaoAtividadePrincipal() );
        cotacaoView.setEnderecoSegurado( cotacao.getEnderecoSegurado() );
        cotacaoView.setNomeBairroSegurado( cotacao.getNomeBairroSegurado() );
        cotacaoView.setNumeroEnderecoSegurado( cotacao.getNumeroEnderecoSegurado() );
        cotacaoView.setNomeComplementoEnderecoSegurado( cotacao.getNomeComplementoEnderecoSegurado() );
        cotacaoView.setNomeMunicipioSegurado( cotacao.getNomeMunicipioSegurado() );
        cotacaoView.setIdUFSegurado( cotacao.getIdUFSegurado() );
        cotacaoView.setIdEmailSegurado( cotacao.getIdEmailSegurado() );
        cotacaoView.setNumeroDDDSegurado( cotacao.getNumeroDDDSegurado() );
        cotacaoView.setNumeroTelefoneSegurado( cotacao.getNumeroTelefoneSegurado() );
        cotacaoView.setNumeroDDDCelularSegurado( cotacao.getNumeroDDDCelularSegurado() );
        cotacaoView.setNumeroCelularSegurado( cotacao.getNumeroCelularSegurado() );
        cotacaoView.setIdTipoSeguro( cotacao.getIdTipoSeguro() );
        cotacaoView.setCodigoCompanhiaSeguradora( cotacao.getCodigoCompanhiaSeguradora() );
        cotacaoView.setNumeroApoliceCongenere( cotacao.getNumeroApoliceCongenere() );
        cotacaoView.setCodigoLocal( cotacao.getCodigoLocal() );
        cotacaoView.setCodigoSubLocal( cotacao.getCodigoSubLocal() );
        cotacaoView.setNomeSubLocal( cotacao.getNomeSubLocal() );
        cotacaoView.setCodigoCorretorACSEL( cotacao.getCodigoCorretorACSEL() );
        cotacaoView.setNomeCorretor( cotacao.getNomeCorretor() );
        cotacaoView.setCodigoProduto( cotacao.getCodigoProduto() );
        cotacaoView.setNomeProduto( cotacao.getNomeProduto() );
        cotacaoView.setNumeroProcessoSUSEP( cotacao.getNumeroProcessoSUSEP() );
        cotacaoView.setDataInicioVigencia( cotacao.getDataInicioVigencia() );
        cotacaoView.setDataFimVigencia( cotacao.getDataFimVigencia() );
        cotacaoView.setDataAlteracao( cotacao.getDataAlteracao() );
        cotacaoView.setIdPrazoVigencia( cotacao.getIdPrazoVigencia() );
        cotacaoView.setIdResseguroFacultativo( simNaoMapper.fromEnum( cotacao.getIdResseguroFacultativo() ) );
        if ( cotacao.getValorPremioLiquido() != null ) {
            cotacaoView.setValorPremioLiquido( cotacao.getValorPremioLiquido().toString() );
        }
        cotacaoView.setCodigoMoeda( cotacao.getCodigoMoeda() );
        cotacaoView.setNumeroCotacaoProposta( cotacao.getNumeroCotacaoProposta() );
        cotacaoView.setVersaoCotacaoProposta( cotacao.getVersaoCotacaoProposta() );
        cotacaoView.setDescricaoObservacao( cotacao.getDescricaoObservacao() );
        cotacaoView.setNumeroRG( cotacao.getNumeroRG() );
        cotacaoView.setNomeOrgaoExpedidor( cotacao.getNomeOrgaoExpedidor() );
        cotacaoView.setDataExpedicao( cotacao.getDataExpedicao() );
        cotacaoView.setDataNascimentoCliente( cotacao.getDataNascimentoCliente() );
        cotacaoView.setNumeroBancoDebito( cotacao.getNumeroBancoDebito() );
        cotacaoView.setNumeroAgenciaDebito( cotacao.getNumeroAgenciaDebito() );
        cotacaoView.setNumeroDigitoAgenciaDebito( cotacao.getNumeroDigitoAgenciaDebito() );
        cotacaoView.setNumeroContaCorrenteDebito( cotacao.getNumeroContaCorrenteDebito() );
        cotacaoView.setNumeroDigitoContaCorrenteDebito( cotacao.getNumeroDigitoContaCorrenteDebito() );
        cotacaoView.setNumeroBancoBoleto( cotacao.getNumeroBancoBoleto() );
        cotacaoView.setDataVencimentoProgramada( cotacao.getDataVencimentoProgramada() );
        if ( cotacao.getPercentualDescontoGeral() != null ) {
            cotacaoView.setPercentualDescontoGeral( cotacao.getPercentualDescontoGeral().toString() );
        }
        if ( cotacao.getPercentualAgravoGeral() != null ) {
            cotacaoView.setPercentualAgravoGeral( cotacao.getPercentualAgravoGeral().toString() );
        }
        cotacaoView.setIdControleCalculo( cotacao.getIdControleCalculo() );
        cotacaoView.setEstrangeiro( cotacao.getEstrangeiro() );
        cotacaoView.setPossuiRNE( cotacao.getPossuiRNE() );
        cotacaoView.setNumeroRNE( cotacao.getNumeroRNE() );
        cotacaoView.setNumeroPassaporte( cotacao.getNumeroPassaporte() );
        cotacaoView.setIdPais( cotacao.getIdPais() );
        cotacaoView.setIdProfissao( cotacao.getIdProfissao() );
        cotacaoView.setIdCapitalSocial( cotacao.getIdCapitalSocial() );
        cotacaoView.setIdFaturamentoPresumido( cotacao.getIdFaturamentoPresumido() );
        cotacaoView.setIdPatrimonio( cotacao.getIdPatrimonio() );
        cotacaoView.setIdRenda( cotacao.getIdRenda() );
        cotacaoView.setIdSeguradoPEP( cotacao.getIdSeguradoPEP() );
        cotacaoView.setNumeroPropostaCorretor( cotacao.getNumeroPropostaCorretor() );
        cotacaoView.setNomeAgenciaDebito( cotacao.getNomeAgenciaDebito() );
        cotacaoView.setNumeroTelefoneAgencia( cotacao.getNumeroTelefoneAgencia() );
        cotacaoView.setNomeCidadeAgencia( cotacao.getNomeCidadeAgencia() );
        cotacaoView.setNomeBairroAgencia( cotacao.getNomeBairroAgencia() );
        cotacaoView.setIdCepAgencia( cotacao.getIdCepAgencia() );
        cotacaoView.setEnderecoAgencia( cotacao.getEnderecoAgencia() );
        cotacaoView.setDataConversaoValorRisco( cotacao.getDataConversaoValorRisco() );
        cotacaoView.setCoeficienteConversaoMoeda( cotacao.getCoeficienteConversaoMoeda() );
        cotacaoView.setDataCalculo( cotacao.getDataCalculo() );
        cotacaoView.setIdTipoEndosso( cotacao.getIdTipoEndosso() );
        cotacaoView.setCodigoRamoProdutoEndossada( cotacao.getCodigoRamoProdutoEndossada() );
        cotacaoView.setCodigoApoliceEndossada( cotacao.getCodigoApoliceEndossada() );
        cotacaoView.setIdSolicitanteEndosso( cotacao.getIdSolicitanteEndosso() );
        cotacaoView.setIdTipoSexo( cotacao.getIdTipoSexo() );
        cotacaoView.setIdEstadoCivil( cotacao.getIdEstadoCivil() );
        cotacaoView.setCodigoFormaDevolucao( cotacao.getCodigoFormaDevolucao() );
        cotacaoView.setNumeroBancoDevolucao( cotacao.getNumeroBancoDevolucao() );
        cotacaoView.setNumeroAgenciaDevolucao( cotacao.getNumeroAgenciaDevolucao() );
        cotacaoView.setNumeroDigitoAgenciaDevolucao( cotacao.getNumeroDigitoAgenciaDevolucao() );
        cotacaoView.setNumeroContaCorrenteDevolucao( cotacao.getNumeroContaCorrenteDevolucao() );
        cotacaoView.setNumeroDigitoContaCorrenteDevolucao( cotacao.getNumeroDigitoContaCorrenteDevolucao() );
        cotacaoView.setIdTipoPedidoCotacao( cotacao.getIdTipoPedidoCotacao() );
        cotacaoView.setCodigoTipoEndossoSCT( cotacao.getCodigoTipoEndossoSCT() );
        cotacaoView.setIdIsencaoImposto( simNaoMapper.fromEnum( cotacao.getIdIsencaoImposto() ) );
        cotacaoView.setEmailCorretorInspecao( cotacao.getEmailCorretorInspecao() );
        cotacaoView.setCodigoNicho( cotacao.getCodigoNicho() );
        cotacaoView.setIdDestinoEmissao( cotacao.getIdDestinoEmissao() );
        cotacaoView.setIdRelacaoPagadorDebito( cotacao.getIdRelacaoPagadorDebito() );
        cotacaoView.setCodigoCliente( cotacao.getCodigoCliente() );
        if ( cotacao.getValorPremioInformado() != null ) {
            cotacaoView.setValorPremioInformado( cotacao.getValorPremioInformado().toString() );
        }
        cotacaoView.setNumeroAgenciaVendedora( cotacao.getNumeroAgenciaVendedora() );
        cotacaoView.setNumeroContaCorrenteVendedora( cotacao.getNumeroContaCorrenteVendedora() );
        cotacaoView.setNumeroMatriculaVendedor( cotacao.getNumeroMatriculaVendedor() );

        return cotacaoView;
    }

    @Override
    public void toCotacao(CotacaoView cotacaoView, Cotacao cotacao) {
        if ( cotacaoView == null ) {
            return;
        }

        cotacao.setCodigoApoliceEndossada( cotacaoView.getCodigoApoliceEndossada() );
        cotacao.setCodigoAtividadePrincipal( cotacaoView.getCodigoAtividadePrincipal() );
        cotacao.setCodigoCliente( cotacaoView.getCodigoCliente() );
        cotacao.setCodigoMoeda( cotacaoView.getCodigoMoeda() );
        cotacao.setCodigoNicho( cotacaoView.getCodigoNicho() );
        cotacao.setCodigoRamoProdutoEndossada( cotacaoView.getCodigoRamoProdutoEndossada() );
        cotacao.setCodigoTipoEndossoSCT( cotacaoView.getCodigoTipoEndossoSCT() );
        cotacao.setCoeficienteConversaoMoeda( cotacaoView.getCoeficienteConversaoMoeda() );
        cotacao.setDataAlteracao( cotacaoView.getDataAlteracao() );
        cotacao.setDataConversaoValorRisco( cotacaoView.getDataConversaoValorRisco() );
        cotacao.setDataFimVigencia( cotacaoView.getDataFimVigencia() );
        cotacao.setDataInicioVigencia( cotacaoView.getDataInicioVigencia() );
        cotacao.setDataVencimentoProgramada( cotacaoView.getDataVencimentoProgramada() );
        cotacao.setDescricaoAtividadePrincipal( cotacaoView.getDescricaoAtividadePrincipal() );
        cotacao.setDescricaoObservacao( cotacaoView.getDescricaoObservacao() );
        cotacao.setEnderecoSegurado( cotacaoView.getEnderecoSegurado() );
        if ( cotacaoView.getIdCEPSegurado() != null ) {
            cotacao.setIdCEPSegurado( Long.parseLong( cotacaoView.getIdCEPSegurado() ) );
        }
        cotacao.setIdControleCalculo( cotacaoView.getIdControleCalculo() );
        cotacao.setIdEmailSegurado( cotacaoView.getIdEmailSegurado() );
        if ( cotacaoView.getIdIsencaoImposto() != null ) {
            cotacao.setIdIsencaoImposto( simNaoMapper.toEnum( cotacaoView.getIdIsencaoImposto().booleanValue() ) );
        }
        cotacao.setIdPrazoVigencia( cotacaoView.getIdPrazoVigencia() );
        cotacao.setIdRelacaoPagadorDebito( cotacaoView.getIdRelacaoPagadorDebito() );
        if ( cotacaoView.getIdResseguroFacultativo() != null ) {
            cotacao.setIdResseguroFacultativo( simNaoMapper.toEnum( cotacaoView.getIdResseguroFacultativo().booleanValue() ) );
        }
        cotacao.setIdSolicitanteEndosso( cotacaoView.getIdSolicitanteEndosso() );
        cotacao.setIdTipoPessoa( cotacaoView.getIdTipoPessoa() );
        cotacao.setIdUFSegurado( cotacaoView.getIdUFSegurado() );
        cotacao.setNomeBairroSegurado( cotacaoView.getNomeBairroSegurado() );
        cotacao.setNomeComplementoEnderecoSegurado( cotacaoView.getNomeComplementoEnderecoSegurado() );
        cotacao.setNomeMunicipioSegurado( cotacaoView.getNomeMunicipioSegurado() );
        cotacao.setNomeSegurado( cotacaoView.getNomeSegurado() );
        cotacao.setNumeroAgenciaVendedora( cotacaoView.getNumeroAgenciaVendedora() );
        cotacao.setNumeroCNPJCPFSegurado( cotacaoView.getNumeroCNPJCPFSegurado() );
        cotacao.setNumeroCelularSegurado( cotacaoView.getNumeroCelularSegurado() );
        cotacao.setNumeroContaCorrenteDebito( cotacaoView.getNumeroContaCorrenteDebito() );
        cotacao.setNumeroContaCorrenteVendedora( cotacaoView.getNumeroContaCorrenteVendedora() );
        cotacao.setNumeroDDDCelularSegurado( cotacaoView.getNumeroDDDCelularSegurado() );
        cotacao.setNumeroDDDSegurado( cotacaoView.getNumeroDDDSegurado() );
        cotacao.setNumeroEnderecoSegurado( cotacaoView.getNumeroEnderecoSegurado() );
        cotacao.setNumeroMatriculaVendedor( cotacaoView.getNumeroMatriculaVendedor() );
        cotacao.setNumeroTelefoneSegurado( cotacaoView.getNumeroTelefoneSegurado() );
        cotacao.setPercentualAgravoGeral( numberMapper.asDecimal( cotacaoView.getPercentualAgravoGeral() ) );
        cotacao.setPercentualDescontoGeral( numberMapper.asDecimal( cotacaoView.getPercentualDescontoGeral() ) );
        cotacao.setSequencialCotacaoProposta( cotacaoView.getSequencialCotacaoProposta() );
        cotacao.setValorPremioInformado( numberMapper.asDecimal( cotacaoView.getValorPremioInformado() ) );
        cotacao.setValorPremioLiquido( numberMapper.asDecimal( cotacaoView.getValorPremioLiquido() ) );
    }

    @Override
    public ItemCotacaoView toItemCotacaoView(ItemCotacao itemCotacao) {
        if ( itemCotacao == null ) {
            return null;
        }

        ItemCotacaoView itemCotacaoView = new ItemCotacaoView();

        itemCotacaoView.setListCoberturaBasica( itemCoberturaSetToItemCoberturaBasicaViewList( itemCotacao.getListItemCobertura() ) );
        itemCotacaoView.setListCoberturaAcessoriaDM( itemCoberturaSetToItemCoberturaBasicaViewListDM( itemCotacao.getListItemCobertura() ) );
        itemCotacaoView.setItemsDistribuicao( itemDistribuicaoSetToItemDistribuicaoViewList( itemCotacao.getListItemDistribuicao() ) );
        itemCotacaoView.setListCoberturaAcessoriaLC( itemCoberturaSetToItemCoberturaBasicaViewListLC( itemCotacao.getListItemCobertura() ) );
        itemCotacaoView.setSequencialItemCotacao( itemCotacao.getSequencialItemCotacao() );
        itemCotacaoView.setNumeroItem( itemCotacao.getNumeroItem() );
        itemCotacaoView.setIdTipoSeguro( itemCotacao.getIdTipoSeguro() );
        if ( itemCotacao.getIdCEPLocalRisco() != null ) {
            itemCotacaoView.setIdCEPLocalRisco( String.valueOf( itemCotacao.getIdCEPLocalRisco() ) );
        }
        itemCotacaoView.setEnderecoLocalRisco( itemCotacao.getEnderecoLocalRisco() );
        itemCotacaoView.setNomeBairroLocalRisco( itemCotacao.getNomeBairroLocalRisco() );
        itemCotacaoView.setNumeroEnderecoLocalRisco( itemCotacao.getNumeroEnderecoLocalRisco() );
        itemCotacaoView.setNomeComplementoEnderecoLocalRisco( itemCotacao.getNomeComplementoEnderecoLocalRisco() );
        itemCotacaoView.setCodigoMunicipioLocalRisco( itemCotacao.getCodigoMunicipioLocalRisco() );
        itemCotacaoView.setNomeMunicipioLocalRisco( itemCotacao.getNomeMunicipioLocalRisco() );
        itemCotacaoView.setIdUFLocalRisco( itemCotacao.getIdUFLocalRisco() );
        itemCotacaoView.setCodigoRubrica( itemCotacao.getCodigoRubrica() );
        itemCotacaoView.setDescricaoRubrica( itemCotacao.getDescricaoRubrica() );
        itemCotacaoView.setCodigoRegiaoTarifaria( itemCotacao.getCodigoRegiaoTarifaria() );
        itemCotacaoView.setCodigoClasseLocalizacao( itemCotacao.getCodigoClasseLocalizacao() );
        itemCotacaoView.setCodigoClasseConstrucao( itemCotacao.getCodigoClasseConstrucao() );
        itemCotacaoView.setCodigoBemCoberto( itemCotacao.getCodigoBemCoberto() );
        itemCotacaoView.setCodigoLocalizacao( itemCotacao.getCodigoLocalizacao() );
        itemCotacaoView.setCodigoAmbitoGeografico( itemCotacao.getCodigoAmbitoGeografico() );
        if ( itemCotacao.getPercentualRelacaoImportanciaSeguradaValorRisco() != null ) {
            itemCotacaoView.setPercentualRelacaoImportanciaSeguradaValorRisco( itemCotacao.getPercentualRelacaoImportanciaSeguradaValorRisco().toString() );
        }
        if ( itemCotacao.getPercentualRelacaoDMPValorRisco() != null ) {
            itemCotacaoView.setPercentualRelacaoDMPValorRisco( itemCotacao.getPercentualRelacaoDMPValorRisco().toString() );
        }
        if ( itemCotacao.getValorRiscoBem() != null ) {
            itemCotacaoView.setValorRiscoBem( itemCotacao.getValorRiscoBem().toString() );
        }
        if ( itemCotacao.getValorRiscoBemCalculado() != null ) {
            itemCotacaoView.setValorRiscoBemCalculado( itemCotacao.getValorRiscoBemCalculado().toString() );
        }
        if ( itemCotacao.getValorMaiorRiscoIsolado() != null ) {
            itemCotacaoView.setValorMaiorRiscoIsolado( itemCotacao.getValorMaiorRiscoIsolado().toString() );
        }
        itemCotacaoView.setIdNecessidadeInspecao( itemCotacao.getIdNecessidadeInspecao() );
        itemCotacaoView.setDescricaoRubricaAlternativa( itemCotacao.getDescricaoRubricaAlternativa() );
        itemCotacaoView.setIdVinilona( simNaoMapper.fromEnum( itemCotacao.getIdVinilona() ) );
        itemCotacaoView.setCodigoRamoProdutoRenovada( itemCotacao.getCodigoRamoProdutoRenovada() );
        itemCotacaoView.setCodigoApoliceRenovada( itemCotacao.getCodigoApoliceRenovada() );
        itemCotacaoView.setCodigoItemRenovada( itemCotacao.getCodigoItemRenovada() );
        itemCotacaoView.setCodigoCompanhiaSeguradora( itemCotacao.getCodigoCompanhiaSeguradora() );
        itemCotacaoView.setNumeroApoliceCongenere( itemCotacao.getNumeroApoliceCongenere() );
        itemCotacaoView.setNumeroItemApoliceCongenere( itemCotacao.getNumeroItemApoliceCongenere() );
        if ( itemCotacao.getPercentualSinistralidade() != null ) {
            itemCotacaoView.setPercentualSinistralidade( itemCotacao.getPercentualSinistralidade().toString() );
        }
        itemCotacaoView.setIdSolicitanteEndosso( itemCotacao.getIdSolicitanteEndosso() );
        itemCotacaoView.setIdTipoEndosso( itemCotacao.getIdTipoEndosso() );
        itemCotacaoView.setCodigoClasseBonus( itemCotacao.getCodigoClasseBonus() );
        itemCotacaoView.setIdResseguroFacultativo( simNaoMapper.fromEnum( itemCotacao.getIdResseguroFacultativo() ) );
        itemCotacaoView.setIdMongoRenovacao( itemCotacao.getIdMongoRenovacao() );

        valoresMonetariosItemCotacao( itemCotacao, itemCotacaoView );
        protecionais( itemCotacao, itemCotacaoView );

        return itemCotacaoView;
    }

    @Override
    public ItemCotacaoPremioFranquiaView toItemCotacaoPremioFranquiaView(ItemCotacao itemCotacao) {
        if ( itemCotacao == null ) {
            return null;
        }

        ItemCotacaoPremioFranquiaView itemCotacaoPremioFranquiaView = new ItemCotacaoPremioFranquiaView();

        itemCotacaoPremioFranquiaView.setListCoberturaBasica( itemCoberturaSetToItemCoberturaBasicaPremioFranquiaViewList( itemCotacao.getListItemCobertura() ) );
        if ( itemCotacaoPremioFranquiaView.getListCoberturaDemais() != null ) {
            Collection<ItemCoberturaPremioFranquiaView> targetCollection = itemCoberturaSetToItemCoberturaBasicaPremioFranquiaViewListDM( itemCotacao.getListItemCobertura() );
            if ( targetCollection != null ) {
                itemCotacaoPremioFranquiaView.getListCoberturaDemais().addAll( targetCollection );
            }
        }
        itemCotacaoPremioFranquiaView.setSequencialItemCotacao( itemCotacao.getSequencialItemCotacao() );
        itemCotacaoPremioFranquiaView.setNumeroItem( itemCotacao.getNumeroItem() );
        itemCotacaoPremioFranquiaView.setIdTipoSeguro( itemCotacao.getIdTipoSeguro() );
        if ( itemCotacao.getIdCEPLocalRisco() != null ) {
            itemCotacaoPremioFranquiaView.setIdCEPLocalRisco( String.valueOf( itemCotacao.getIdCEPLocalRisco() ) );
        }
        itemCotacaoPremioFranquiaView.setEnderecoLocalRisco( itemCotacao.getEnderecoLocalRisco() );
        itemCotacaoPremioFranquiaView.setNomeBairroLocalRisco( itemCotacao.getNomeBairroLocalRisco() );
        itemCotacaoPremioFranquiaView.setNumeroEnderecoLocalRisco( itemCotacao.getNumeroEnderecoLocalRisco() );
        itemCotacaoPremioFranquiaView.setNomeComplementoEnderecoLocalRisco( itemCotacao.getNomeComplementoEnderecoLocalRisco() );
        itemCotacaoPremioFranquiaView.setCodigoMunicipioLocalRisco( itemCotacao.getCodigoMunicipioLocalRisco() );
        itemCotacaoPremioFranquiaView.setNomeMunicipioLocalRisco( itemCotacao.getNomeMunicipioLocalRisco() );
        itemCotacaoPremioFranquiaView.setIdUFLocalRisco( itemCotacao.getIdUFLocalRisco() );

        return itemCotacaoPremioFranquiaView;
    }

    @Override
    public void toItemCotacao(ItemCotacaoView itemCotacaoView, ItemCotacao itemCotacao) {
        if ( itemCotacaoView == null ) {
            return;
        }

        itemCotacao.setIdCEPLocalRisco( itemCotacaoView.getIdCEPLocalRiscoNumero() );
        itemCotacao.setCodigoAmbitoGeografico( itemCotacaoView.getCodigoAmbitoGeografico() );
        itemCotacao.setCodigoApoliceRenovada( itemCotacaoView.getCodigoApoliceRenovada() );
        itemCotacao.setCodigoBemCoberto( itemCotacaoView.getCodigoBemCoberto() );
        itemCotacao.setCodigoClasseBonus( itemCotacaoView.getCodigoClasseBonus() );
        itemCotacao.setCodigoClasseConstrucao( itemCotacaoView.getCodigoClasseConstrucao() );
        itemCotacao.setCodigoClasseLocalizacao( itemCotacaoView.getCodigoClasseLocalizacao() );
        itemCotacao.setCodigoCompanhiaSeguradora( itemCotacaoView.getCodigoCompanhiaSeguradora() );
        itemCotacao.setCodigoItemRenovada( itemCotacaoView.getCodigoItemRenovada() );
        itemCotacao.setCodigoLocalizacao( itemCotacaoView.getCodigoLocalizacao() );
        itemCotacao.setCodigoMunicipioLocalRisco( itemCotacaoView.getCodigoMunicipioLocalRisco() );
        itemCotacao.setCodigoRamoProdutoRenovada( itemCotacaoView.getCodigoRamoProdutoRenovada() );
        itemCotacao.setCodigoRegiaoTarifaria( itemCotacaoView.getCodigoRegiaoTarifaria() );
        itemCotacao.setCodigoRubrica( itemCotacaoView.getCodigoRubrica() );
        itemCotacao.setDescricaoRubrica( itemCotacaoView.getDescricaoRubrica() );
        itemCotacao.setDescricaoRubricaAlternativa( itemCotacaoView.getDescricaoRubricaAlternativa() );
        itemCotacao.setEnderecoLocalRisco( itemCotacaoView.getEnderecoLocalRisco() );
        itemCotacao.setIdMongoRenovacao( itemCotacaoView.getIdMongoRenovacao() );
        itemCotacao.setIdNecessidadeInspecao( itemCotacaoView.getIdNecessidadeInspecao() );
        if ( itemCotacaoView.getIdResseguroFacultativo() != null ) {
            itemCotacao.setIdResseguroFacultativo( simNaoMapper.toEnum( itemCotacaoView.getIdResseguroFacultativo().booleanValue() ) );
        }
        itemCotacao.setIdSolicitanteEndosso( itemCotacaoView.getIdSolicitanteEndosso() );
        itemCotacao.setIdTipoEndosso( itemCotacaoView.getIdTipoEndosso() );
        itemCotacao.setIdTipoSeguro( itemCotacaoView.getIdTipoSeguro() );
        itemCotacao.setIdUFLocalRisco( itemCotacaoView.getIdUFLocalRisco() );
        if ( itemCotacaoView.getIdVinilona() != null ) {
            itemCotacao.setIdVinilona( simNaoMapper.toEnum( itemCotacaoView.getIdVinilona().booleanValue() ) );
        }
        itemCotacao.setNomeBairroLocalRisco( itemCotacaoView.getNomeBairroLocalRisco() );
        itemCotacao.setNomeComplementoEnderecoLocalRisco( itemCotacaoView.getNomeComplementoEnderecoLocalRisco() );
        itemCotacao.setNomeMunicipioLocalRisco( itemCotacaoView.getNomeMunicipioLocalRisco() );
        itemCotacao.setNumeroApoliceCongenere( itemCotacaoView.getNumeroApoliceCongenere() );
        itemCotacao.setNumeroEnderecoLocalRisco( itemCotacaoView.getNumeroEnderecoLocalRisco() );
        itemCotacao.setNumeroItem( itemCotacaoView.getNumeroItem() );
        itemCotacao.setNumeroItemApoliceCongenere( itemCotacaoView.getNumeroItemApoliceCongenere() );
        itemCotacao.setPercentualSinistralidade( numberMapper.asDecimal( itemCotacaoView.getPercentualSinistralidade() ) );
    }

    @Override
    public ItemCoberturaView toItemCoberturaBasicaView(ItemCobertura itemCobertura) {
        if ( itemCobertura == null ) {
            return null;
        }

        ItemCoberturaView itemCoberturaView = new ItemCoberturaView();

        itemCoberturaView.setSequencialItemCobertura( itemCobertura.getSequencialItemCobertura() );
        itemCoberturaView.setCodigoCobertura( itemCobertura.getCodigoCobertura() );
        itemCoberturaView.setDescricaoCobertura( itemCobertura.getDescricaoCobertura() );
        itemCoberturaView.setIdCoberturaAvulsa( simNaoMapper.fromEnum( itemCobertura.getIdCoberturaAvulsa() ) );
        if ( itemCobertura.getValorImportanciaSegurada() != null ) {
            itemCoberturaView.setValorImportanciaSegurada( itemCobertura.getValorImportanciaSegurada().toString() );
        }
        if ( itemCobertura.getValorSublimite() != null ) {
            itemCoberturaView.setValorSublimite( itemCobertura.getValorSublimite().toString() );
        }
        if ( itemCobertura.getValorSublimiteOriginal() != null ) {
            itemCoberturaView.setValorSublimiteOriginal( itemCobertura.getValorSublimiteOriginal().toString() );
        }
        itemCoberturaView.setIdFormaFranquia( itemCobertura.getIdFormaFranquia() );
        itemCoberturaView.setIdTextoFranquia( itemCobertura.getIdTextoFranquia() );
        itemCoberturaView.setIdLMR( simNaoMapper.fromEnum( itemCobertura.getIdLMR() ) );
        if ( itemCobertura.getValorISMoedaEstrangeira() != null ) {
            itemCoberturaView.setValorISMoedaEstrangeira( itemCobertura.getValorISMoedaEstrangeira().toString() );
        }
        if ( itemCobertura.getValorSublimiteMoedaEstrangeira() != null ) {
            itemCoberturaView.setValorSublimiteMoedaEstrangeira( itemCobertura.getValorSublimiteMoedaEstrangeira().toString() );
        }
        if ( itemCobertura.getValorSublimiteOriginalMoedaEstrangeira() != null ) {
            itemCoberturaView.setValorSublimiteOriginalMoedaEstrangeira( itemCobertura.getValorSublimiteOriginalMoedaEstrangeira().toString() );
        }
        itemCoberturaView.setIdTipoCobertura( itemCobertura.getIdTipoCobertura() );
        if ( itemCobertura.getPercentualTaxaCalculoPremio() != null ) {
            itemCoberturaView.setPercentualTaxaCalculoPremio( itemCobertura.getPercentualTaxaCalculoPremio().toString() );
        }
        itemCoberturaView.setIdLucrosCessantes( simNaoMapper.fromEnum( itemCobertura.getIdLucrosCessantes() ) );
        itemCoberturaView.setIdDanosMateriais( simNaoMapper.fromEnum( itemCobertura.getIdDanosMateriais() ) );
        itemCoberturaView.setCodigoPeriodoIndenitario( itemCobertura.getCodigoPeriodoIndenitario() );
        itemCoberturaView.setNumeroMultiploFranquia( itemCobertura.getNumeroMultiploFranquia() );
        itemCoberturaView.setNumeroMultiploPrejuizo( itemCobertura.getNumeroMultiploPrejuizo() );
        itemCoberturaView.setExigeValorRisco( itemCobertura.isExigeValorRisco() );
        if ( itemCobertura.getValorRiscoBem() != null ) {
            itemCoberturaView.setValorRiscoBem( itemCobertura.getValorRiscoBem().toString() );
        }
        itemCoberturaView.setDescricaoComplementoCobertura( itemCobertura.getDescricaoComplementoCobertura() );
        itemCoberturaView.setIdExclusaEndosso( simNaoMapper.fromEnum( itemCobertura.getIdExclusaEndosso() ) );
        itemCoberturaView.setNumeroVagasGaragem( itemCobertura.getNumeroVagasGaragem() );
        itemCoberturaView.setExigeVagasGaragem( itemCobertura.isExigeVagasGaragem() );
        itemCoberturaView.setCoberturaPrincipal( itemCobertura.getCoberturaPrincipal() );
        itemCoberturaView.setDescricaoCoberturaAjustada( itemCobertura.getDescricaoCoberturaAjustada() );

        valoresMonetariosItemCobertura( itemCobertura, itemCoberturaView );

        return itemCoberturaView;
    }

    @Override
    public ItemCoberturaPremioFranquiaView toItemCoberturaPremioFranquiaBasicaView(ItemCobertura itemCobertura) {
        if ( itemCobertura == null ) {
            return null;
        }

        ItemCoberturaPremioFranquiaView itemCoberturaPremioFranquiaView = new ItemCoberturaPremioFranquiaView();

        itemCoberturaPremioFranquiaView.setSequencialItemCobertura( itemCobertura.getSequencialItemCobertura() );
        itemCoberturaPremioFranquiaView.setCodigoCobertura( itemCobertura.getCodigoCobertura() );
        itemCoberturaPremioFranquiaView.setDescricaoCobertura( itemCobertura.getDescricaoCobertura() );
        if ( itemCobertura.getValorImportanciaSegurada() != null ) {
            itemCoberturaPremioFranquiaView.setValorImportanciaSegurada( itemCobertura.getValorImportanciaSegurada().toString() );
        }
        if ( itemCobertura.getValorPremio() != null ) {
            itemCoberturaPremioFranquiaView.setValorPremio( itemCobertura.getValorPremio().toString() );
        }
        itemCoberturaPremioFranquiaView.setDescricaoFranquia( itemCobertura.getDescricaoFranquia() );
        itemCoberturaPremioFranquiaView.setFranquia( itemCobertura.getFranquia() );

        valoresMonetariosItemCoberturaPremioFranquia( itemCobertura, itemCoberturaPremioFranquiaView );

        return itemCoberturaPremioFranquiaView;
    }

    @Override
    public ItemDistribuicaoView toItemDistribuicaoView(ItemDistribuicao itemDistribuicao) {
        if ( itemDistribuicao == null ) {
            return null;
        }

        ItemDistribuicaoView itemDistribuicaoView_ = new ItemDistribuicaoView();

        itemDistribuicaoView_.setValorRiscoBem( numberMapper.asDecimal2( itemDistribuicao.getValorRiscoBem() ) );
        itemDistribuicaoView_.setIdTipoValorRisco( itemDistribuicao.getIdTipoValorRisco() );
        itemDistribuicaoView_.setDescricaoRiscoBem( itemDistribuicao.getDescricaoRiscoBem() );

        valoresMonetariosItemDistribuicao( itemDistribuicao, itemDistribuicaoView_ );

        return itemDistribuicaoView_;
    }

    @Override
    public CosseguroView toCosseguroCotacaoView(CosseguroCotacao cosseguroCotacao) {
        if ( cosseguroCotacao == null ) {
            return null;
        }

        CosseguroView cosseguroView = new CosseguroView();

        cosseguroView.setPercentualCosseguro( numberMapper.asDecimal5( cosseguroCotacao.getPercentualCosseguro() ) );
        cosseguroView.setPercentualComissaoDiferenciada( numberMapper.asDecimal5( cosseguroCotacao.getPercentualComissaoDiferenciada() ) );
        cosseguroView.setCodigoCompanhiaSeguradora( cosseguroCotacao.getCodigoCompanhiaSeguradora() );
        cosseguroView.setNomeCompanhiaSeguradora( cosseguroCotacao.getNomeCompanhiaSeguradora() );

        return cosseguroView;
    }

    @Override
    public void toCosseguroCotacao(CosseguroView cosseguroView, CosseguroCotacao cosseguroCotacao) {
        if ( cosseguroView == null ) {
            return;
        }

        cosseguroCotacao.setCodigoCompanhiaSeguradora( cosseguroView.getCodigoCompanhiaSeguradora() );
        cosseguroCotacao.setNomeCompanhiaSeguradora( cosseguroView.getNomeCompanhiaSeguradora() );
        cosseguroCotacao.setPercentualComissaoDiferenciada( numberMapper.asDecimal( cosseguroView.getPercentualComissaoDiferenciada() ) );
        cosseguroCotacao.setPercentualCosseguro( numberMapper.asDecimal( cosseguroView.getPercentualCosseguro() ) );
    }

    @Override
    public CorretagemView toCorretagemCotacaoView(CorretagemCotacao corretagemCotacao) {
        if ( corretagemCotacao == null ) {
            return null;
        }

        CorretagemView corretagemView = new CorretagemView();

        corretagemView.setPercentualCorretagem( numberMapper.asDecimal5( corretagemCotacao.getPercentualCorretagem() ) );
        corretagemView.setCodigoCorretorAcsel( corretagemCotacao.getCodigoCorretorAcsel() );
        corretagemView.setNomeCorretorAcsel( corretagemCotacao.getNomeCorretorAcsel() );
        corretagemView.setIdCorretorLider( simNaoMapper.fromEnum( corretagemCotacao.getIdCorretorLider() ) );

        return corretagemView;
    }

    @Override
    public void toCorretagemCotacao(CorretagemView corretagemView, CorretagemCotacao corretagemCotacao) {
        if ( corretagemView == null ) {
            return;
        }

        corretagemCotacao.setCodigoCorretorAcsel( corretagemView.getCodigoCorretorAcsel() );
        if ( corretagemView.getIdCorretorLider() != null ) {
            corretagemCotacao.setIdCorretorLider( simNaoMapper.toEnum( corretagemView.getIdCorretorLider().booleanValue() ) );
        }
        corretagemCotacao.setNomeCorretorAcsel( corretagemView.getNomeCorretorAcsel() );
        corretagemCotacao.setPercentualCorretagem( numberMapper.asDecimal( corretagemView.getPercentualCorretagem() ) );
    }

    private DecimalFormat createDecimalFormat( String numberFormat ) {

        DecimalFormat df = new DecimalFormat( numberFormat );
        df.setParseBigDecimal( true );
        return df;
    }

    protected List<ItemDistribuicaoView> itemDistribuicaoSetToItemDistribuicaoViewList(Set<ItemDistribuicao> set) {
        if ( set == null ) {
            return null;
        }

        List<ItemDistribuicaoView> list = new ArrayList<ItemDistribuicaoView>();
        for ( ItemDistribuicao itemDistribuicao : set ) {
            list.add( toItemDistribuicaoView( itemDistribuicao ) );
        }

        return list;
    }
}
