package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.ItemEquipamentoFranquiaView;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemCobertura;
import br.com.tokiomarine.ctpj.domain.cotacao.ItemEquipamentoFranquia;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import org.mapstruct.factory.Mappers;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class ItemEquipamentoFranquiaMapperImpl extends ItemEquipamentoFranquiaMapper {

    private final NumberMapper numberMapper = Mappers.getMapper( NumberMapper.class );

    @Override
    ItemEquipamentoFranquia toItemEquipamentoFranquia(ItemEquipamentoFranquiaView itemEquipamentoFranquiaView) {
        if ( itemEquipamentoFranquiaView == null ) {
            return null;
        }

        ItemEquipamentoFranquia itemEquipamentoFranquia = new ItemEquipamentoFranquia();

        ItemCobertura itemCobertura = new ItemCobertura();
        itemEquipamentoFranquia.setItemCobertura( itemCobertura );

        itemCobertura.setSequencialItemCobertura( itemEquipamentoFranquiaView.getSequencialItemCobertura() );
        itemEquipamentoFranquia.setNumeroCotacaoProposta( itemEquipamentoFranquiaView.getNumeroCotacaoProposta() );
        itemEquipamentoFranquia.setVersaoCotacaoProposta( itemEquipamentoFranquiaView.getVersaoCotacaoProposta() );
        itemEquipamentoFranquia.setCodigoEquipamento( itemEquipamentoFranquiaView.getCodigoEquipamento() );
        itemEquipamentoFranquia.setDescricaoEquipamento( itemEquipamentoFranquiaView.getDescricaoEquipamento() );
        itemEquipamentoFranquia.setDescricaoTextoFranquia( itemEquipamentoFranquiaView.getDescricaoTextoFranquia() );
        itemEquipamentoFranquia.setIdFormaFranquia( itemEquipamentoFranquiaView.getIdFormaFranquia() );
        itemEquipamentoFranquia.setIdTextoFranquia( itemEquipamentoFranquiaView.getIdTextoFranquia() );
        itemEquipamentoFranquia.setNumeroDiasFranquia( itemEquipamentoFranquiaView.getNumeroDiasFranquia() );
        itemEquipamentoFranquia.setNumeroHorasFranquia( itemEquipamentoFranquiaView.getNumeroHorasFranquia() );
        itemEquipamentoFranquia.setSequencialItemEquipamantoFranquia( itemEquipamentoFranquiaView.getSequencialItemEquipamantoFranquia() );
        itemEquipamentoFranquia.setTaxaFranquia( numberMapper.asDecimal( itemEquipamentoFranquiaView.getTaxaFranquia() ) );
        itemEquipamentoFranquia.setTaxaImportanciaSegurada( numberMapper.asDecimal( itemEquipamentoFranquiaView.getTaxaImportanciaSegurada() ) );
        itemEquipamentoFranquia.setTaxaImportanciaSeguradaMaximo( numberMapper.asDecimal( itemEquipamentoFranquiaView.getTaxaImportanciaSeguradaMaximo() ) );
        itemEquipamentoFranquia.setTaxaImportanciaSeguradaMinimo( numberMapper.asDecimal( itemEquipamentoFranquiaView.getTaxaImportanciaSeguradaMinimo() ) );
        itemEquipamentoFranquia.setValorFranquia( numberMapper.asDecimal( itemEquipamentoFranquiaView.getValorFranquia() ) );
        itemEquipamentoFranquia.setValorFranquiaMaximo( numberMapper.asDecimal( itemEquipamentoFranquiaView.getValorFranquiaMaximo() ) );
        itemEquipamentoFranquia.setValorFranquiaMinimo( numberMapper.asDecimal( itemEquipamentoFranquiaView.getValorFranquiaMinimo() ) );

        setCobertura( itemEquipamentoFranquia, itemEquipamentoFranquiaView );

        return itemEquipamentoFranquia;
    }

    @Override
    List<ItemEquipamentoFranquia> toItemEquipamentoFranquiaList(List<ItemEquipamentoFranquiaView> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemEquipamentoFranquia> list_ = new ArrayList<ItemEquipamentoFranquia>();
        for ( ItemEquipamentoFranquiaView itemEquipamentoFranquiaView : list ) {
            list_.add( toItemEquipamentoFranquia( itemEquipamentoFranquiaView ) );
        }

        return list_;
    }

    @Override
    ItemEquipamentoFranquiaView toItemEquipamentoFranquia(ItemEquipamentoFranquia itemEquipamentoFranquia) {
        if ( itemEquipamentoFranquia == null ) {
            return null;
        }

        ItemEquipamentoFranquiaView itemEquipamentoFranquiaView = new ItemEquipamentoFranquiaView();

        itemEquipamentoFranquiaView.setTaxaImportanciaSegurada( numberMapper.asDecimal5( itemEquipamentoFranquia.getTaxaImportanciaSegurada() ) );
        itemEquipamentoFranquiaView.setSequencialItemCobertura( itemEquipamentoFranquiaItemCoberturaSequencialItemCobertura( itemEquipamentoFranquia ) );
        itemEquipamentoFranquiaView.setTaxaFranquia( numberMapper.asDecimal5( itemEquipamentoFranquia.getTaxaFranquia() ) );
        itemEquipamentoFranquiaView.setValorFranquiaMinimo( numberMapper.asDecimal2( itemEquipamentoFranquia.getValorFranquiaMinimo() ) );
        itemEquipamentoFranquiaView.setValorFranquia( numberMapper.asDecimal2( itemEquipamentoFranquia.getValorFranquia() ) );
        itemEquipamentoFranquiaView.setTaxaImportanciaSeguradaMinimo( numberMapper.asDecimal5( itemEquipamentoFranquia.getTaxaImportanciaSeguradaMinimo() ) );
        itemEquipamentoFranquiaView.setValorFranquiaMaximo( numberMapper.asDecimal2( itemEquipamentoFranquia.getValorFranquiaMaximo() ) );
        itemEquipamentoFranquiaView.setTaxaImportanciaSeguradaMaximo( numberMapper.asDecimal5( itemEquipamentoFranquia.getTaxaImportanciaSeguradaMaximo() ) );
        itemEquipamentoFranquiaView.setSequencialItemEquipamantoFranquia( itemEquipamentoFranquia.getSequencialItemEquipamantoFranquia() );
        itemEquipamentoFranquiaView.setCodigoEquipamento( itemEquipamentoFranquia.getCodigoEquipamento() );
        itemEquipamentoFranquiaView.setDescricaoEquipamento( itemEquipamentoFranquia.getDescricaoEquipamento() );
        itemEquipamentoFranquiaView.setIdFormaFranquia( itemEquipamentoFranquia.getIdFormaFranquia() );
        itemEquipamentoFranquiaView.setNumeroHorasFranquia( itemEquipamentoFranquia.getNumeroHorasFranquia() );
        itemEquipamentoFranquiaView.setNumeroDiasFranquia( itemEquipamentoFranquia.getNumeroDiasFranquia() );
        itemEquipamentoFranquiaView.setIdTextoFranquia( itemEquipamentoFranquia.getIdTextoFranquia() );
        itemEquipamentoFranquiaView.setDescricaoTextoFranquia( itemEquipamentoFranquia.getDescricaoTextoFranquia() );
        itemEquipamentoFranquiaView.setNumeroCotacaoProposta( itemEquipamentoFranquia.getNumeroCotacaoProposta() );
        itemEquipamentoFranquiaView.setVersaoCotacaoProposta( itemEquipamentoFranquia.getVersaoCotacaoProposta() );

        return itemEquipamentoFranquiaView;
    }

    @Override
    List<ItemEquipamentoFranquiaView> toItemEquipamentoFranquiaViewList(List<ItemEquipamentoFranquia> list) {
        if ( list == null ) {
            return null;
        }

        List<ItemEquipamentoFranquiaView> list_ = new ArrayList<ItemEquipamentoFranquiaView>();
        for ( ItemEquipamentoFranquia itemEquipamentoFranquia : list ) {
            list_.add( toItemEquipamentoFranquia( itemEquipamentoFranquia ) );
        }

        return list_;
    }

    @Override
    public ItemEquipamentoFranquiaView toEquipamentoFranquiaView(ItemEquipamentoFranquiaView itemEquipamentoFranquiaView) {
        if ( itemEquipamentoFranquiaView == null ) {
            return null;
        }

        ItemEquipamentoFranquiaView itemEquipamentoFranquiaView_ = new ItemEquipamentoFranquiaView();

        itemEquipamentoFranquiaView_.setSequencialItemEquipamantoFranquia( itemEquipamentoFranquiaView.getSequencialItemEquipamantoFranquia() );
        itemEquipamentoFranquiaView_.setCodigoEquipamento( itemEquipamentoFranquiaView.getCodigoEquipamento() );
        itemEquipamentoFranquiaView_.setDescricaoEquipamento( itemEquipamentoFranquiaView.getDescricaoEquipamento() );
        itemEquipamentoFranquiaView_.setIdFormaFranquia( itemEquipamentoFranquiaView.getIdFormaFranquia() );
        itemEquipamentoFranquiaView_.setNumeroHorasFranquia( itemEquipamentoFranquiaView.getNumeroHorasFranquia() );
        itemEquipamentoFranquiaView_.setNumeroDiasFranquia( itemEquipamentoFranquiaView.getNumeroDiasFranquia() );
        itemEquipamentoFranquiaView_.setTaxaFranquia( itemEquipamentoFranquiaView.getTaxaFranquia() );
        itemEquipamentoFranquiaView_.setValorFranquia( itemEquipamentoFranquiaView.getValorFranquia() );
        itemEquipamentoFranquiaView_.setValorFranquiaMinimo( itemEquipamentoFranquiaView.getValorFranquiaMinimo() );
        itemEquipamentoFranquiaView_.setValorFranquiaMaximo( itemEquipamentoFranquiaView.getValorFranquiaMaximo() );
        itemEquipamentoFranquiaView_.setTaxaImportanciaSegurada( itemEquipamentoFranquiaView.getTaxaImportanciaSegurada() );
        itemEquipamentoFranquiaView_.setTaxaImportanciaSeguradaMinimo( itemEquipamentoFranquiaView.getTaxaImportanciaSeguradaMinimo() );
        itemEquipamentoFranquiaView_.setTaxaImportanciaSeguradaMaximo( itemEquipamentoFranquiaView.getTaxaImportanciaSeguradaMaximo() );
        itemEquipamentoFranquiaView_.setIdTextoFranquia( itemEquipamentoFranquiaView.getIdTextoFranquia() );
        itemEquipamentoFranquiaView_.setDescricaoTextoFranquia( itemEquipamentoFranquiaView.getDescricaoTextoFranquia() );
        itemEquipamentoFranquiaView_.setNumeroCotacaoProposta( itemEquipamentoFranquiaView.getNumeroCotacaoProposta() );
        itemEquipamentoFranquiaView_.setVersaoCotacaoProposta( itemEquipamentoFranquiaView.getVersaoCotacaoProposta() );
        itemEquipamentoFranquiaView_.setSequencialItemCobertura( itemEquipamentoFranquiaView.getSequencialItemCobertura() );
        itemEquipamentoFranquiaView_.setDeleteItem( itemEquipamentoFranquiaView.isDeleteItem() );
        itemEquipamentoFranquiaView_.setSequencialItemCotacao( itemEquipamentoFranquiaView.getSequencialItemCotacao() );

        return itemEquipamentoFranquiaView_;
    }

    private BigInteger itemEquipamentoFranquiaItemCoberturaSequencialItemCobertura(ItemEquipamentoFranquia itemEquipamentoFranquia) {

        if ( itemEquipamentoFranquia == null ) {
            return null;
        }
        ItemCobertura itemCobertura = itemEquipamentoFranquia.getItemCobertura();
        if ( itemCobertura == null ) {
            return null;
        }
        BigInteger sequencialItemCobertura = itemCobertura.getSequencialItemCobertura();
        if ( sequencialItemCobertura == null ) {
            return null;
        }
        return sequencialItemCobertura;
    }
}
