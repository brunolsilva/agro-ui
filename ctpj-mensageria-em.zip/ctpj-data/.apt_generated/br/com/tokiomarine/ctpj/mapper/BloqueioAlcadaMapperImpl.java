package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.BloqueioAlcadaView;
import br.com.tokiomarine.ctpj.domain.cotacao.BloqueioAlcada;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:10-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class BloqueioAlcadaMapperImpl implements BloqueioAlcadaMapper {

    @Override
    public BloqueioAlcadaView toView(BloqueioAlcada bloqueioCotacao) {
        if ( bloqueioCotacao == null ) {
            return null;
        }

        BloqueioAlcadaView bloqueioAlcadaView = new BloqueioAlcadaView();

        bloqueioAlcadaView.setSequencialBloqueioAlcada( bloqueioCotacao.getSequencialBloqueioAlcada() );
        bloqueioAlcadaView.setDescricaoRestricao( bloqueioCotacao.getDescricaoRestricao() );
        bloqueioAlcadaView.setCodigoNivelAutorizacao( bloqueioCotacao.getCodigoNivelAutorizacao() );
        bloqueioAlcadaView.setIdAutorizacao( bloqueioCotacao.getIdAutorizacao() );
        bloqueioAlcadaView.setDataAutorizacao( bloqueioCotacao.getDataAutorizacao() );
        bloqueioAlcadaView.setCodigoFuncionarioAutorizacao( bloqueioCotacao.getCodigoFuncionarioAutorizacao() );
        bloqueioAlcadaView.setNomeFuncionarioAutorizacao( bloqueioCotacao.getNomeFuncionarioAutorizacao() );
        bloqueioAlcadaView.setObservacaoParecerLiberacaoBloqueio( bloqueioCotacao.getObservacaoParecerLiberacaoBloqueio() );
        bloqueioAlcadaView.setIdentificadorDocstorebloqueio( bloqueioCotacao.getIdentificadorDocstorebloqueio() );
        bloqueioAlcadaView.setDescricaoRestricaoCorretor( bloqueioCotacao.getDescricaoRestricaoCorretor() );
        bloqueioAlcadaView.setIdApresentaRestricao( bloqueioCotacao.getIdApresentaRestricao() );

        return bloqueioAlcadaView;
    }

    @Override
    public List<BloqueioAlcadaView> toView(List<BloqueioAlcada> bloqueioCotacao) {
        if ( bloqueioCotacao == null ) {
            return null;
        }

        List<BloqueioAlcadaView> list = new ArrayList<BloqueioAlcadaView>();
        for ( BloqueioAlcada bloqueioAlcada : bloqueioCotacao ) {
            list.add( toView( bloqueioAlcada ) );
        }

        return list;
    }
}
