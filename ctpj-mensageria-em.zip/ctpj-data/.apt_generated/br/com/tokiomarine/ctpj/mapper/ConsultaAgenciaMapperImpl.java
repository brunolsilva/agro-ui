package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.cliente.dto.Consulta;
import br.com.tokiomarine.ctpj.cotacao.dto.CobrancaAgenciaResponse;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:11-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class ConsultaAgenciaMapperImpl extends ConsultaAgenciaMapper {

    @Override
    public Consulta toConsulta(CobrancaAgenciaResponse cobrancaAgenciaResponse) {
        if ( cobrancaAgenciaResponse == null ) {
            return null;
        }

        Consulta consulta = new Consulta();

        consulta.setCidade( cobrancaAgenciaResponse.getCidade() );
        consulta.setNomeAgencia( cobrancaAgenciaResponse.getNomeAgencia() );
        consulta.setEndereco( cobrancaAgenciaResponse.getEndereco() );
        consulta.setBairro( cobrancaAgenciaResponse.getBairro() );
        consulta.setTel( cobrancaAgenciaResponse.getTelefone() );
        consulta.setCep( cobrancaAgenciaResponse.getCep() );
        if ( cobrancaAgenciaResponse.getCodigoAgencia() != null ) {
            consulta.setCodigoAgencia( String.valueOf( cobrancaAgenciaResponse.getCodigoAgencia() ) );
        }

        return consulta;
    }
}
