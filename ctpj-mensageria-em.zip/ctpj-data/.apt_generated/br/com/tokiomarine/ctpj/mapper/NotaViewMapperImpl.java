package br.com.tokiomarine.ctpj.mapper;

import br.com.tokiomarine.ctpj.cotacao.dto.NotaCotacaoView;
import br.com.tokiomarine.ctpj.domain.cotacao.NotaCotacao;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2021-08-13T16:13:12-0300",
    comments = "version: 1.1.0.CR1, compiler: Eclipse JDT (IDE) 3.15.0.v20180905-0317, environment: Java 1.8.0_201 (Oracle Corporation)"
)
public class NotaViewMapperImpl implements NotaViewMapper {

    @Override
    public NotaCotacaoView toNotaCotacaoView(NotaCotacao notaCotacao) {
        if ( notaCotacao == null ) {
            return null;
        }

        NotaCotacaoView notaCotacaoView = new NotaCotacaoView();

        notaCotacaoView.setSequencialNotaCotacao( notaCotacao.getSequencialNotaCotacao() );
        notaCotacaoView.setSequencialNotaControle( notaCotacao.getSequencialNotaControle() );
        notaCotacaoView.setNota( notaCotacao.getNota() );
        notaCotacaoView.setNumeroCotacaoProposta( notaCotacao.getNumeroCotacaoProposta() );
        notaCotacaoView.setVersaoCotacaoProposta( notaCotacao.getVersaoCotacaoProposta() );
        notaCotacaoView.setDataAtualizacao( notaCotacao.getDataAtualizacao() );
        notaCotacaoView.setCodigoGrupo( notaCotacao.getCodigoGrupo() );
        notaCotacaoView.setUsuarioAtualizacao( notaCotacao.getUsuarioAtualizacao() );

        return notaCotacaoView;
    }

    @Override
    public List<NotaCotacaoView> toNotasCotacaoView(List<NotaCotacao> notasCotacao) {
        if ( notasCotacao == null ) {
            return null;
        }

        List<NotaCotacaoView> list = new ArrayList<NotaCotacaoView>();
        for ( NotaCotacao notaCotacao : notasCotacao ) {
            list.add( toNotaCotacaoView( notaCotacao ) );
        }

        return list;
    }

    @Override
    public NotaCotacao toNotaCotacao(NotaCotacaoView notaCotacaoView) {
        if ( notaCotacaoView == null ) {
            return null;
        }

        NotaCotacao notaCotacao = new NotaCotacao();

        notaCotacao.setCodigoGrupo( notaCotacaoView.getCodigoGrupo() );
        notaCotacao.setDataAtualizacao( notaCotacaoView.getDataAtualizacao() );
        notaCotacao.setUsuarioAtualizacao( notaCotacaoView.getUsuarioAtualizacao() );
        notaCotacao.setNumeroCotacaoProposta( notaCotacaoView.getNumeroCotacaoProposta() );
        notaCotacao.setVersaoCotacaoProposta( notaCotacaoView.getVersaoCotacaoProposta() );
        notaCotacao.setNota( notaCotacaoView.getNota() );
        notaCotacao.setSequencialNotaControle( notaCotacaoView.getSequencialNotaControle() );
        notaCotacao.setSequencialNotaCotacao( notaCotacaoView.getSequencialNotaCotacao() );

        return notaCotacao;
    }

    @Override
    public List<NotaCotacao> toNotasCotacao(List<NotaCotacaoView> notasCotacaoView) {
        if ( notasCotacaoView == null ) {
            return null;
        }

        List<NotaCotacao> list = new ArrayList<NotaCotacao>();
        for ( NotaCotacaoView notaCotacaoView : notasCotacaoView ) {
            list.add( toNotaCotacao( notaCotacaoView ) );
        }

        return list;
    }
}
